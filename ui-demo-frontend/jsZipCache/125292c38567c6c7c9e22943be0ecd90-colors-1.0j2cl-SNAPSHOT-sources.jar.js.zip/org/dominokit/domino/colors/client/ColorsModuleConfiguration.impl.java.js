/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.ColorsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.colors.client.ColorsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.colors.client.ColorsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.colors.client.ColorsModuleConfiguration.$2$impl');
let ColorsPresenterContributionToComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint$impl');
let ColorsPresenter = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenter$impl');
let ColorsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');


/**
 * @implements {ModuleConfiguration}
  */
class ColorsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ColorsModuleConfiguration()'.
   * @return {!ColorsModuleConfiguration}
   * @public
   */
  static $create__() {
    ColorsModuleConfiguration.$clinit();
    let $instance = new ColorsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_colors_client_ColorsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColorsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_colors_client_ColorsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_colors_client_ColorsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(ColorsPresenter).m_getCanonicalName__(), Class.$get(ColorsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_colors_client_ColorsModuleConfiguration__java_lang_String(this, Class.$get(ColorsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(ColorsPresenterCommand).m_getCanonicalName__(), Class.$get(ColorsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(ComponentCaseExtensionPoint), ColorsPresenterContributionToComponentCaseExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColorsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColorsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ColorsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.colors.client.ColorsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.colors.client.ColorsModuleConfiguration.$2$impl');
    ColorsPresenterContributionToComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint$impl');
    ColorsPresenter = goog.module.get('org.dominokit.domino.colors.client.presenters.ColorsPresenter$impl');
    ColorsPresenterCommand = goog.module.get('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ColorsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.colors.client.ColorsModuleConfiguration'));


ModuleConfiguration.$markImplementor(ColorsModuleConfiguration);


exports = ColorsModuleConfiguration; 
//# sourceMappingURL=ColorsModuleConfiguration.js.map