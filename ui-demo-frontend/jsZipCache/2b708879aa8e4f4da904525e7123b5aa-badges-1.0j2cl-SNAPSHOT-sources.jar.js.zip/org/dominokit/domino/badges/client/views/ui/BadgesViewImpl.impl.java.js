/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.views.ui.BadgesViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.badges.client.views.ui.BadgesViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BadgesView = goog.require('org.dominokit.domino.badges.client.views.BadgesView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.badges.client.views.CodeResource$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {BadgesView}
  */
class BadgesViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'BadgesViewImpl()'.
   * @return {!BadgesViewImpl}
   * @public
   */
  static $create__() {
    BadgesViewImpl.$clinit();
    let $instance = new BadgesViewImpl();
    $instance.$ctor__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BadgesViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("BADGES").m_asElement__());
    this.m_buttonExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
    this.m_buttonExamplesWithMaterialDesignColors___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
    this.m_listExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_buttonExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(Card.m_create__java_lang_String("BUTTON EXAMPLES").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(Button.m_createSuccess__java_lang_String("SUCCESS ").m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("4").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_createPrimary__java_lang_String("PRIMARY").m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("10+").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_createDanger__java_lang_String("DANGER").m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("8").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_createWarning__java_lang_String("WARNING").m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("3").m_asElement__()).m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_buttonExample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_buttonExamplesWithMaterialDesignColors___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(Card.m_create__java_lang_String("BUTTON EXAMPLES WITH MATERIAL DESIGN COLORS").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("2").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("BLUE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("10+").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("RED").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("13").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("ORANGE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("5").m_asElement__()).m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("PINK").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("14").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("CYAN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("99+").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("TEAL").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("26").m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Button.m_create__java_lang_String("PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_large__().m_block__().m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("47").m_asElement__()).m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_buttonExamplesWithMaterialDesignColors__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_listExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    let listGroup = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Cras justo odio").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("14 new").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_asElement__());
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Dapibus ac facilisis in").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("99 unread").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__());
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Morbi leo risus").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("99+").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__());
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Porta ac consectetur ac").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("21").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__());
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Vestibulum at eros").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("18").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("LIST EXAMPLE", "You can also put badge to list and use the material design colors.").m_appendContent__elemental2_dom_Node(listGroup.m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_listExample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BadgesViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BadgesViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BadgesViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.badges.client.views.CodeResource$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ListGroup = goog.module.get('org.dominokit.domino.ui.lists.ListGroup$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BadgesViewImpl, $Util.$makeClassName('org.dominokit.domino.badges.client.views.ui.BadgesViewImpl'));


BadgesView.$markImplementor(BadgesViewImpl);


exports = BadgesViewImpl; 
//# sourceMappingURL=BadgesViewImpl.js.map