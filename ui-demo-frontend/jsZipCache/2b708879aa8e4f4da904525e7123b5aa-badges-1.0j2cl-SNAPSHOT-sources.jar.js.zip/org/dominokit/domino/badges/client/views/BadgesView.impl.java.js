/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.views.BadgesView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.badges.client.views.BadgesView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.badges.client.views.BadgesView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class BadgesView {
  /**
   * @param {?function():Content} fn
   * @return {BadgesView}
   * @public
   */
  static $adapt(fn) {
    BadgesView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_badges_client_views_BadgesView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_badges_client_views_BadgesView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_badges_client_views_BadgesView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    BadgesView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.badges.client.views.BadgesView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(BadgesView, $Util.$makeClassName('org.dominokit.domino.badges.client.views.BadgesView'));


BadgesView.$markImplementor(/** @type {Function} */ (BadgesView));


exports = BadgesView; 
//# sourceMappingURL=BadgesView.js.map