/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.views.ui.ListsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.lists.client.views.ui.ListsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _ListsView = goog.require('org.dominokit.domino.lists.client.views.ListsView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeResource = goog.require('org.dominokit.domino.lists.client.views.CodeResource');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _ListGroup = goog.require('org.dominokit.domino.ui.lists.ListGroup');
const _SimpleListGroup = goog.require('org.dominokit.domino.ui.lists.SimpleListGroup');
const _SimpleListItem = goog.require('org.dominokit.domino.ui.lists.SimpleListItem');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ListsViewImpl = goog.require('org.dominokit.domino.lists.client.views.ui.ListsViewImpl$impl');
exports = ListsViewImpl;
 