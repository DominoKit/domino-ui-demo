/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Event = goog.require('org.dominokit.domino.api.client.events.Event$impl');
const ServerFailedRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let EventProcessor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventProcessor$impl');
let ServerFailedRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext$impl');
let ServerResponseReceivedStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let FailedResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');
let GWTRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.GWTRequestEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Event}
  */
class ServerFailedRequestEvent extends ServerFailedRequestGwtEvent {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ServerRequest} */
    this.f_request__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent;
    /** @public {Throwable} */
    this.f_error__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_;
    /** @public {ClientApp} */
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_;
  }
  
  /**
   * Factory method corresponding to constructor 'ServerFailedRequestEvent(ServerRequest, Throwable)'.
   * @param {ServerRequest} request
   * @param {Throwable} error
   * @return {!ServerFailedRequestEvent}
   * @public
   */
  static $create__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(request, error) {
    ServerFailedRequestEvent.$clinit();
    let $instance = new ServerFailedRequestEvent();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(request, error);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerFailedRequestEvent(ServerRequest, Throwable)'.
   * @param {ServerRequest} request
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(request, error) {
    this.$ctor__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent__();
    this.$init__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent();
    this.f_request__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent = request;
    this.f_error__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_ = error;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_fire__() {
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_.m_getEventsBus__().m_publishEvent__org_dominokit_domino_api_client_events_EventsBus_RequestEvent(GWTRequestEvent.$create__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent(this, this));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_process__() {
    this.f_request__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent.m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(ServerResponseReceivedStateContext.$create__org_dominokit_domino_api_client_request_RequestStateContext(this.m_makeFailedContext___$p_org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent()));
  }
  
  /**
   * @return {ServerFailedRequestStateContext}
   * @public
   */
  m_makeFailedContext___$p_org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent() {
    return ServerFailedRequestStateContext.$create__org_dominokit_domino_api_shared_request_FailedResponseBean(FailedResponseBean.$create__java_lang_Throwable(this.f_error__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_));
  }
  
  /**
   * @param {EventProcessor} eventProcessor
   * @return {void}
   * @public
   */
  m_dispatch__org_dominokit_domino_api_client_events_EventProcessor(eventProcessor) {
    eventProcessor.m_process__org_dominokit_domino_api_client_events_Event(this);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_dispatch__java_lang_Object(arg0) {
    this.m_dispatch__org_dominokit_domino_api_client_events_EventProcessor(/**@type {EventProcessor} */ ($Casts.$to(arg0, EventProcessor)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent() {
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_ = ClientApp.m_make__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerFailedRequestEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerFailedRequestEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerFailedRequestEvent.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    EventProcessor = goog.module.get('org.dominokit.domino.api.client.events.EventProcessor$impl');
    ServerFailedRequestStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext$impl');
    ServerResponseReceivedStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext$impl');
    FailedResponseBean = goog.module.get('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');
    GWTRequestEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.GWTRequestEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ServerFailedRequestGwtEvent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerFailedRequestEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent'));


Event.$markImplementor(ServerFailedRequestEvent);


exports = ServerFailedRequestEvent; 
//# sourceMappingURL=ServerFailedRequestEvent.js.map