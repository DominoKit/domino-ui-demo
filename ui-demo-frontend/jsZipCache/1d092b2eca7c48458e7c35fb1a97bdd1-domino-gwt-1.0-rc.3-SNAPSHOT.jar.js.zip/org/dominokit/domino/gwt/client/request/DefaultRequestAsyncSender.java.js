/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractRequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender');
const _ServerRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ServerRequestEventFactory');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _NotImplementedException = goog.require('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender.NotImplementedException');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var DefaultRequestAsyncSender = goog.require('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender$impl');
exports = DefaultRequestAsyncSender;
 