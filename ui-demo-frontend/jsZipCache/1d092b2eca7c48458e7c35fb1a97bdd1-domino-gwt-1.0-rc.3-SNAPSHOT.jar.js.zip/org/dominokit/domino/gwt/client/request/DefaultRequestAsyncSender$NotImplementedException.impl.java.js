/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender$NotImplementedException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender.NotImplementedException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class NotImplementedException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'NotImplementedException()'.
   * @return {!NotImplementedException}
   * @public
   */
  static $create__() {
    NotImplementedException.$clinit();
    let $instance = new NotImplementedException();
    $instance.$ctor__org_dominokit_domino_gwt_client_request_DefaultRequestAsyncSender_NotImplementedException__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NotImplementedException()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_request_DefaultRequestAsyncSender_NotImplementedException__() {
    this.$ctor__java_lang_RuntimeException__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NotImplementedException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NotImplementedException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NotImplementedException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NotImplementedException, $Util.$makeClassName('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender$NotImplementedException'));




exports = NotImplementedException; 
//# sourceMappingURL=DefaultRequestAsyncSender$NotImplementedException.js.map