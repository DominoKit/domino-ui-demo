/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _ServerSuccessRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor');
const _ServerResponseReceivedStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext');
const _ServerSuccessRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');
const _GWTRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.GWTRequestEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ServerSuccessRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$impl');
exports = ServerSuccessRequestEvent;
 