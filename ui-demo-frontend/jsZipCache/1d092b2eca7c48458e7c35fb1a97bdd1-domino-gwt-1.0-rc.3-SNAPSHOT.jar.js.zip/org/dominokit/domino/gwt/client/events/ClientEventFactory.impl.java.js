/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ClientEventFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ClientEventFactory$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ClientRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory$impl');

let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');
let ClientRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ClientRequestEvent$impl');


/**
 * @implements {ClientRequestEventFactory}
  */
class ClientEventFactory extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ClientEventFactory()'.
   * @return {!ClientEventFactory}
   * @public
   */
  static $create__() {
    ClientEventFactory.$clinit();
    let $instance = new ClientEventFactory();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ClientEventFactory__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ClientEventFactory()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ClientEventFactory__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterCommand} request
   * @return {Event}
   * @public
   */
  m_make__org_dominokit_domino_api_client_request_PresenterCommand(request) {
    return ClientRequestEvent.$create__org_dominokit_domino_api_client_request_PresenterCommand(request);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientEventFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientEventFactory);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientEventFactory.$clinit = function() {};
    ClientRequestEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ClientRequestEvent$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ClientEventFactory, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ClientEventFactory'));


ClientRequestEventFactory.$markImplementor(ClientEventFactory);


exports = ClientEventFactory; 
//# sourceMappingURL=ClientEventFactory.js.map