/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');
const _HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken');
const _StateHistoryToken = goog.require('org.dominokit.domino.client.commons.history.StateHistoryToken');
const _StateHistory = goog.require('org.dominokit.domino.gwt.client.history.StateHistory');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.gwt.client.history.StateHistory.$1$impl');
exports = $1;
 