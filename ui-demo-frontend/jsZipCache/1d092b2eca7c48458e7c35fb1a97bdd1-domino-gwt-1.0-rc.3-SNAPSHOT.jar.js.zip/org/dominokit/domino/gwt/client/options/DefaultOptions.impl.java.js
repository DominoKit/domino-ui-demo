/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.options.DefaultOptions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.options.DefaultOptions$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let CanSetDominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.CanSetDominoOptions$impl');
let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');
let NotImplementedException = goog.forwardDeclare('org.dominokit.domino.gwt.client.options.DefaultOptions.NotImplementedException$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {DominoOptions}
  */
class DefaultOptions extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultOptions()'.
   * @return {!DefaultOptions}
   * @public
   */
  static $create__() {
    DefaultOptions.$clinit();
    let $instance = new DefaultOptions();
    $instance.$ctor__org_dominokit_domino_gwt_client_options_DefaultOptions__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultOptions()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_options_DefaultOptions__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_applyOptions__() {
  }
  
  /**
   * @override
   * @param {?string} defaultServiceRoot
   * @return {CanSetDominoOptions}
   * @public
   */
  m_setDefaultServiceRoot__java_lang_String(defaultServiceRoot) {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @override
   * @param {?string} defaultJsonDateFormat
   * @return {CanSetDominoOptions}
   * @public
   */
  m_setDefaultJsonDateFormat__java_lang_String(defaultJsonDateFormat) {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @override
   * @param {DynamicServiceRoot} dynamicServiceRoot
   * @return {CanSetDominoOptions}
   * @public
   */
  m_addDynamicServiceRoot__org_dominokit_domino_api_client_DynamicServiceRoot(dynamicServiceRoot) {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getDefaultServiceRoot__() {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getDefaultJsonDateFormat__() {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @override
   * @return {List<DynamicServiceRoot>}
   * @public
   */
  m_getServiceRoots__() {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultOptions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultOptions);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultOptions.$clinit = function() {};
    NotImplementedException = goog.module.get('org.dominokit.domino.gwt.client.options.DefaultOptions.NotImplementedException$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DefaultOptions, $Util.$makeClassName('org.dominokit.domino.gwt.client.options.DefaultOptions'));


DominoOptions.$markImplementor(DefaultOptions);


exports = DefaultOptions; 
//# sourceMappingURL=DefaultOptions.js.map