/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter.$1$impl');
let DatePickerView = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.DatePickerView$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<DatePickerView>}
  */
class DatePickerPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerPresenter()'.
   * @return {!DatePickerPresenter}
   * @public
   */
  static $create__() {
    DatePickerPresenter.$clinit();
    let $instance = new DatePickerPresenter();
    $instance.$ctor__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {FormsContext} context
   * @return {void}
   * @public
   */
  m_onFormsEvent__org_dominokit_domino_forms_shared_extension_FormsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_() {
    return (DatePickerPresenter.$clinit(), DatePickerPresenter.$f_LOGGER__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_(value) {
    (DatePickerPresenter.$clinit(), DatePickerPresenter.$f_LOGGER__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    DatePickerPresenter.$f_LOGGER__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(DatePickerPresenter));
  }
  
  
};

$Util.$setClassMetadata(DatePickerPresenter, $Util.$makeClassName('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter'));


/** @private {Logger} */
DatePickerPresenter.$f_LOGGER__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_;




exports = DatePickerPresenter; 
//# sourceMappingURL=DatePickerPresenter.js.map