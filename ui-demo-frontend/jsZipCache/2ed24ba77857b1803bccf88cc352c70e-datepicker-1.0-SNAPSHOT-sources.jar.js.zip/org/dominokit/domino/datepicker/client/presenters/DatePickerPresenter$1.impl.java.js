/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter.$1$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let ComponentRemoveHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
let ComponentRevealedHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler$impl');
let DatePickerPresenter = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$impl');
let DatePickerView = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.DatePickerView$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ComponentCase}
  */
class $1 extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DatePickerPresenter} */
    this.f_$outer_this__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new ComponentCase(DatePickerPresenter)'.
   * @param {DatePickerPresenter} $outer_this
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter($outer_this) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_1__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new ComponentCase(DatePickerPresenter)'.
   * @param {DatePickerPresenter} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_1__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter($outer_this) {
    this.f_$outer_this__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_1 = $outer_this;
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getHistoryToken__() {
    return "forms/datepicker";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getMenuPath__() {
    return "Forms/Date Picker";
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    return /**@type {DatePickerView} */ ($Casts.$to(this.f_$outer_this__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenter_1.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, DatePickerView)).m_getContent__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {?string}
   * @public
   */
  m_getIconName__() {
    return ComponentCase.m_getIconName__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {boolean}
   * @public
   */
  m_hasContent__() {
    return ComponentCase.m_hasContent__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {ComponentRemoveHandler}
   * @public
   */
  m_onComponentRemoved__() {
    return ComponentCase.m_onComponentRemoved__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {ComponentRevealedHandler}
   * @public
   */
  m_onComponentRevealed__() {
    return ComponentCase.m_onComponentRevealed__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase(this);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    DatePickerView = goog.module.get('org.dominokit.domino.datepicker.client.views.DatePickerView$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    ComponentCase.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$1'));


ComponentCase.$markImplementor($1);


exports = $1; 
//# sourceMappingURL=DatePickerPresenter$1.js.map