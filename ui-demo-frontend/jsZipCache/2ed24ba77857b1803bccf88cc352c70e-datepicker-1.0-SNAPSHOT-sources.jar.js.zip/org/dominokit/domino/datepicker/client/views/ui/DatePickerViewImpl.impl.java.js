/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const DatePickerView = goog.require('org.dominokit.domino.datepicker.client.views.DatePickerView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$3$impl');
let Formatter = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.Formatter$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let PickerStyle = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
let DatePicker = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let DateTimeFormatInfoImpl__fr = goog.forwardDeclare('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_fr$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {DatePickerView}
  */
class DatePickerViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerViewImpl()'.
   * @return {!DatePickerViewImpl}
   * @public
   */
  static $create__() {
    DatePickerViewImpl.$clinit();
    let $instance = new DatePickerViewImpl();
    $instance.$ctor__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(DatePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("DATE PICKERS").m_asElement__());
    this.m_inlined___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
    this.m_popups___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
    this.m_dateBox___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_inlined___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(Card.m_create__java_lang_String("INLINED").m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Header visible")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(DatePicker.m_create__().m_hideClearButton__().m_hideCloseButton__().m_fixedWidth__java_lang_String("265px").m_showBorder__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      let dateTimeFormat = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo.m_dateFormatFull__(), dateTimeFormatInfo);
      Notification.m_create__java_lang_String(dateTimeFormat.m_format__java_util_Date(date)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_show__();
    })))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$) =>{
      let dateTimeFormat$1$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$1$.m_dateFormatFull__(), dateTimeFormatInfo$1$);
      Notification.m_create__java_lang_String(dateTimeFormat$1$.m_format__java_util_Date(date$1$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    }))).m_todayButtonText__java_lang_String("aujourd'hui")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$) =>{
      let dateTimeFormat$2$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$2$.m_dateFormatFull__(), dateTimeFormatInfo$2$);
      Notification.m_create__java_lang_String(dateTimeFormat$2$.m_format__java_util_Date(date$2$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    })))), Column)))).m_appendChild__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Header hidden").m_asElement__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(DatePicker.m_create__().m_hideClearButton__().m_hideCloseButton__().m_hideHeaderPanel__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$3$, /** DateTimeFormatInfo */ dateTimeFormatInfo$3$) =>{
      let dateTimeFormat$3$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$3$.m_dateFormatFull__(), dateTimeFormatInfo$3$);
      Notification.m_create__java_lang_String(dateTimeFormat$3$.m_format__java_util_Date(date$3$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideHeaderPanel__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$4$, /** DateTimeFormatInfo */ dateTimeFormatInfo$4$) =>{
      let dateTimeFormat$4$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$4$.m_dateFormatFull__(), dateTimeFormatInfo$4$);
      Notification.m_create__java_lang_String(dateTimeFormat$4$.m_format__java_util_Date(date$4$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    }))).m_todayButtonText__java_lang_String("aujourd'hui")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideHeaderPanel__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$5$, /** DateTimeFormatInfo */ dateTimeFormatInfo$5$) =>{
      let dateTimeFormat$5$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$5$.m_dateFormatFull__(), dateTimeFormatInfo$5$);
      Notification.m_create__java_lang_String(dateTimeFormat$5$.m_format__java_util_Date(date$5$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    })))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DatePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl, "inlined").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_popups___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    let bluePopupButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let bluePopDatePicker = DatePicker.m_create__().m_showBorder__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      let dateTimeFormat = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo.m_dateFormatFull__(), dateTimeFormatInfo);
      Notification.m_create__java_lang_String(dateTimeFormat.m_format__java_util_Date(date)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let bluePopover = /**@type {Popover} */ ($Casts.$to(Popover.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(bluePopupButton, "Birth date", bluePopDatePicker).m_style__().m_setMaxWidth__java_lang_String("300px").m_get__(), Popover));
    bluePopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      bluePopover.m_close__();
    })));
    bluePopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let amberPopupButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let amberPopDatePicker = DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$) =>{
      let dateTimeFormat$1$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$1$.m_dateFormatFull__(), dateTimeFormatInfo$1$);
      Notification.m_create__java_lang_String(dateTimeFormat$1$.m_format__java_util_Date(date$1$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let amberPopover = /**@type {Popover} */ ($Casts.$to(Popover.m_createPicker__org_jboss_gwt_elemento_core_IsElement__org_jboss_gwt_elemento_core_IsElement(amberPopupButton, amberPopDatePicker).m_style__().m_setMaxWidth__java_lang_String("300px").m_get__(), Popover));
    amberPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      amberPopover.m_close__();
    })));
    amberPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenPopupButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let greenPopDatePicker = DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$) =>{
      let dateTimeFormat$2$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$2$.m_dateFormatFull__(), dateTimeFormatInfo$2$);
      Notification.m_create__java_lang_String(dateTimeFormat$2$.m_format__java_util_Date(date$2$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenPopover = /**@type {Popover} */ ($Casts.$to(Popover.m_createPicker__org_jboss_gwt_elemento_core_IsElement__org_jboss_gwt_elemento_core_IsElement(greenPopupButton, greenPopDatePicker).m_style__().m_setMaxWidth__java_lang_String("300px").m_get__(), Popover));
    greenPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenPopover.m_close__();
    })));
    greenPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let blueModalButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let blueDatePicker = DatePicker.m_create__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$3$, /** DateTimeFormatInfo */ dateTimeFormatInfo$3$) =>{
      let dateTimeFormat$3$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$3$.m_dateFormatFull__(), dateTimeFormatInfo$3$);
      Notification.m_create__java_lang_String(dateTimeFormat$3$.m_format__java_util_Date(date$3$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let blueModal = blueDatePicker.m_createModal__java_lang_String("Birth date");
    blueDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      blueModal.m_close__();
    })));
    blueDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    blueModal.m_appendChild__org_jboss_gwt_elemento_core_IsElement(blueDatePicker);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(blueModal.m_asElement__());
    blueModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      blueModal.m_open__();
    })));
    let amberModalButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let amberDatePicker = DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$4$, /** DateTimeFormatInfo */ dateTimeFormatInfo$4$) =>{
      let dateTimeFormat$4$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$4$.m_dateFormatFull__(), dateTimeFormatInfo$4$);
      Notification.m_create__java_lang_String(dateTimeFormat$4$.m_format__java_util_Date(date$4$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let amberModal = amberDatePicker.m_createModal__java_lang_String("Birth date");
    amberDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      amberModal.m_close__();
    })));
    amberDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    amberModal.m_appendChild__org_jboss_gwt_elemento_core_IsElement(amberDatePicker);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(amberModal.m_asElement__());
    amberModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      amberModal.m_open__();
    })));
    let greenModalButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let greenDatePicker = DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$5$, /** DateTimeFormatInfo */ dateTimeFormatInfo$5$) =>{
      let dateTimeFormat$5$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$5$.m_dateFormatFull__(), dateTimeFormatInfo$5$);
      Notification.m_create__java_lang_String(dateTimeFormat$5$.m_format__java_util_Date(date$5$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenModal = greenDatePicker.m_createModal__java_lang_String("Birth date");
    greenDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenModal.m_close__();
    })));
    greenDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    greenModal.m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenDatePicker);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(greenModal.m_asElement__());
    greenModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      greenModal.m_open__();
    })));
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(Card.m_create__java_lang_String("POPUP").m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("POP OVER")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(bluePopupButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(amberPopupButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenPopupButton), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("MODAL")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(blueModalButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(amberModalButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenModalButton), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DatePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl, "popups").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_dateBox___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    let column = /**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_style__().m_remove__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column));
    let dateBox1 = DateBox.m_create__java_lang_String("Birth date").m_setPattern__java_lang_String("yyyy/MM/dd");
    let dateBox2 = DateBox.m_create__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo("Birth date", Date.$create__(), DateTimeFormatInfoImpl__fr.$create__());
    dateBox2.m_getDatePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme);
    let dateBox3 = DateBox.m_create__java_lang_String("Birth date").m_setPopoverPosition__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition).m_setPickerStyle__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(PickerStyle.f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle);
    dateBox3.m_getDatePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme);
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(Card.m_create__java_lang_String("DATE BOX").m_appendChild__elemental2_dom_Node(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_deCenterContent__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(dateBox1), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_deCenterContent__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(dateBox2), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_deCenterContent__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(dateBox3), Column))), Row__12)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DatePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl, "datebox").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
    this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_ = /**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Date = goog.module.get('java.util.Date$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$3$impl');
    Formatter = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.Formatter$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    PickerStyle = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
    DatePicker = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    PickerHandler = goog.module.get('org.dominokit.domino.ui.pickers.PickerHandler$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    DateTimeFormatInfoImpl__fr = goog.module.get('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_fr$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerViewImpl, $Util.$makeClassName('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl'));


/** @public {?string} @const */
DatePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl = "datepicker";


DatePickerView.$markImplementor(DatePickerViewImpl);


exports = DatePickerViewImpl; 
//# sourceMappingURL=DatePickerViewImpl.js.map