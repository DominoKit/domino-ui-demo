/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const DatePickerView = goog.require('org.dominokit.domino.datepicker.client.views.DatePickerView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$3$impl');
let Formatter = goog.forwardDeclare('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.Formatter$impl');
let IconButton = goog.forwardDeclare('org.dominokit.domino.ui.button.IconButton$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let PickerStyle = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
let DatePicker = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let DateTimeFormatInfoImpl__fr = goog.forwardDeclare('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_fr$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {DatePickerView}
  */
class DatePickerViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerViewImpl()'.
   * @return {!DatePickerViewImpl}
   * @public
   */
  static $create__() {
    DatePickerViewImpl.$clinit();
    let $instance = new DatePickerViewImpl();
    $instance.$ctor__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("DATE PICKERS").m_asElement__());
    this.m_inlined___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
    this.m_popups___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
    this.m_dateBox___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_inlined___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(Card.m_create__java_lang_String("INLINED").m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Header visible").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(DatePicker.m_create__().m_hideClearButton__().m_hideCloseButton__().m_fixedWidth__java_lang_String("265px").m_showBorder__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      let dateTimeFormat = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo.m_dateFormatFull__(), dateTimeFormatInfo);
      Notification.m_create__java_lang_String(dateTimeFormat.m_format__java_util_Date(date)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_show__();
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$) =>{
      let dateTimeFormat$1$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$1$.m_dateFormatFull__(), dateTimeFormatInfo$1$);
      Notification.m_create__java_lang_String(dateTimeFormat$1$.m_format__java_util_Date(date$1$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    }))).m_todayButtonText__java_lang_String("aujourd'hui").m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$) =>{
      let dateTimeFormat$2$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$2$.m_dateFormatFull__(), dateTimeFormatInfo$2$);
      Notification.m_create__java_lang_String(dateTimeFormat$2$.m_format__java_util_Date(date$2$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    }))).m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Header hidden").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(DatePicker.m_create__().m_hideClearButton__().m_hideCloseButton__().m_hideHeaderPanel__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$3$, /** DateTimeFormatInfo */ dateTimeFormatInfo$3$) =>{
      let dateTimeFormat$3$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$3$.m_dateFormatFull__(), dateTimeFormatInfo$3$);
      Notification.m_create__java_lang_String(dateTimeFormat$3$.m_format__java_util_Date(date$3$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideHeaderPanel__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$4$, /** DateTimeFormatInfo */ dateTimeFormatInfo$4$) =>{
      let dateTimeFormat$4$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$4$.m_dateFormatFull__(), dateTimeFormatInfo$4$);
      Notification.m_create__java_lang_String(dateTimeFormat$4$.m_format__java_util_Date(date$4$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    }))).m_todayButtonText__java_lang_String("aujourd'hui").m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_hideClearButton__().m_hideHeaderPanel__().m_hideCloseButton__().m_showBorder__().m_fixedWidth__java_lang_String("265px").m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$5$, /** DateTimeFormatInfo */ dateTimeFormatInfo$5$) =>{
      let dateTimeFormat$5$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$5$.m_dateFormatFull__(), dateTimeFormatInfo$5$);
      Notification.m_create__java_lang_String(dateTimeFormat$5$.m_format__java_util_Date(date$5$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_darker_2__()).m_show__();
    }))).m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_inlined__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_popups___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    let bluePopupButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let bluePopDatePicker = DatePicker.m_create__().m_showBorder__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      let dateTimeFormat = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo.m_dateFormatFull__(), dateTimeFormatInfo);
      Notification.m_create__java_lang_String(dateTimeFormat.m_format__java_util_Date(date)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let bluePopover = Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(bluePopupButton.m_asElement__(), "Birth date", bluePopDatePicker.m_asElement__());
    bluePopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      bluePopover.m_close__();
    })));
    bluePopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let amberPopupButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let amberPopDatePicker = DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$) =>{
      let dateTimeFormat$1$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$1$.m_dateFormatFull__(), dateTimeFormatInfo$1$);
      Notification.m_create__java_lang_String(dateTimeFormat$1$.m_format__java_util_Date(date$1$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let amberPopover = Popover.m_createPicker__elemental2_dom_HTMLElement__elemental2_dom_Node(amberPopupButton.m_asElement__(), amberPopDatePicker.m_asElement__());
    amberPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      amberPopover.m_close__();
    })));
    amberPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenPopupButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let greenPopDatePicker = DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$) =>{
      let dateTimeFormat$2$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$2$.m_dateFormatFull__(), dateTimeFormatInfo$2$);
      Notification.m_create__java_lang_String(dateTimeFormat$2$.m_format__java_util_Date(date$2$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenPopover = Popover.m_createPicker__elemental2_dom_HTMLElement__elemental2_dom_Node(greenPopupButton.m_asElement__(), greenPopDatePicker.m_asElement__());
    greenPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenPopover.m_close__();
    })));
    greenPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let blueModalButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let blueDatePicker = DatePicker.m_create__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$3$, /** DateTimeFormatInfo */ dateTimeFormatInfo$3$) =>{
      let dateTimeFormat$3$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$3$.m_dateFormatFull__(), dateTimeFormatInfo$3$);
      Notification.m_create__java_lang_String(dateTimeFormat$3$.m_format__java_util_Date(date$3$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let blueModal = blueDatePicker.m_createModal__java_lang_String("Birth date");
    blueDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      blueModal.m_close__();
    })));
    blueDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    blueModal.m_appendContent__elemental2_dom_Node(blueDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(blueModal.m_asElement__());
    blueModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      blueModal.m_open__();
    })));
    let amberModalButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let amberDatePicker = DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$4$, /** DateTimeFormatInfo */ dateTimeFormatInfo$4$) =>{
      let dateTimeFormat$4$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$4$.m_dateFormatFull__(), dateTimeFormatInfo$4$);
      Notification.m_create__java_lang_String(dateTimeFormat$4$.m_format__java_util_Date(date$4$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let amberModal = amberDatePicker.m_createModal__java_lang_String("Birth date");
    amberDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      amberModal.m_close__();
    })));
    amberDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    amberModal.m_appendContent__elemental2_dom_Node(amberDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(amberModal.m_asElement__());
    amberModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      amberModal.m_open__();
    })));
    let greenModalButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let greenDatePicker = DatePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$5$, /** DateTimeFormatInfo */ dateTimeFormatInfo$5$) =>{
      let dateTimeFormat$5$ = Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo$5$.m_dateFormatFull__(), dateTimeFormatInfo$5$);
      Notification.m_create__java_lang_String(dateTimeFormat$5$.m_format__java_util_Date(date$5$)).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenModal = greenDatePicker.m_createModal__java_lang_String("Birth date");
    greenDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenModal.m_close__();
    })));
    greenDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    greenModal.m_appendContent__elemental2_dom_Node(greenDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(greenModal.m_asElement__());
    greenModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      greenModal.m_open__();
    })));
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(Card.m_create__java_lang_String("POPUP").m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("POP OVER").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bluePopupButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(amberPopupButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(greenPopupButton.m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("MODAL").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(blueModalButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(amberModalButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(greenModalButton.m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_popups__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_dateBox___$p_org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    let column = this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.m_copy__().m_removeCssClass__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles);
    let dateBox1 = /**@type {DateBox} */ ($Casts.$to(DateBox.m_create__().m_floating__(), DateBox)).m_setPlaceholder__java_lang_String("Birth date");
    let dateBox2 = /**@type {DateBox} */ ($Casts.$to(DateBox.m_create__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo("Birth date", Date.$create__(), DateTimeFormatInfoImpl__fr.$create__()).m_floating__(), DateBox));
    dateBox2.m_getDatePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme);
    let dateBox3 = /**@type {DateBox} */ ($Casts.$to(DateBox.m_create__().m_floating__(), DateBox)).m_setPopoverPosition__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition).m_setPickerStyle__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(PickerStyle.f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle).m_setPlaceholder__java_lang_String("Birth date");
    dateBox3.m_getDatePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme);
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(Card.m_create__java_lang_String("DATE BOX").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(dateBox1.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(dateBox2.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(dateBox3.m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_datebox__()).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl() {
    this.f_element__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
    this.f_column__org_dominokit_domino_datepicker_client_views_ui_DatePickerViewImpl_ = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall).m_addCssClass__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_centerContent__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Date = goog.module.get('java.util.Date$impl');
    CodeResource = goog.module.get('org.dominokit.domino.datepicker.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$3$impl');
    Formatter = goog.module.get('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.Formatter$impl');
    IconButton = goog.module.get('org.dominokit.domino.ui.button.IconButton$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    PickerStyle = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
    DatePicker = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    PickerHandler = goog.module.get('org.dominokit.domino.ui.pickers.PickerHandler$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    DateTimeFormatInfoImpl__fr = goog.module.get('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_fr$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerViewImpl, $Util.$makeClassName('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl'));


DatePickerView.$markImplementor(DatePickerViewImpl);


exports = DatePickerViewImpl; 
//# sourceMappingURL=DatePickerViewImpl.js.map