/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.views.DatePickerView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datepicker.client.views.DatePickerView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.datepicker.client.views.DatePickerView.$LambdaAdaptor');


// Re-exports the implementation.
var DatePickerView = goog.require('org.dominokit.domino.datepicker.client.views.DatePickerView$impl');
exports = DatePickerView;
 