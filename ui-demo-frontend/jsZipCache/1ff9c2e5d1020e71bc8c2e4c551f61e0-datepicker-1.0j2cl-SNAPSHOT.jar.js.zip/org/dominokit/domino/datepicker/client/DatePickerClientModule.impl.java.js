/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.DatePickerClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.DatePickerClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class DatePickerClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerClientModule()'.
   * @return {!DatePickerClientModule}
   * @public
   */
  static $create__() {
    DatePickerClientModule.$clinit();
    let $instance = new DatePickerClientModule();
    $instance.$ctor__org_dominokit_domino_datepicker_client_DatePickerClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_DatePickerClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    DatePickerClientModule.$f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_.m_info__java_lang_String("Initializing DatePicker frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_() {
    return (DatePickerClientModule.$clinit(), DatePickerClientModule.$f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_(value) {
    (DatePickerClientModule.$clinit(), DatePickerClientModule.$f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    DatePickerClientModule.$f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(DatePickerClientModule));
  }
  
  
};

$Util.$setClassMetadata(DatePickerClientModule, $Util.$makeClassName('org.dominokit.domino.datepicker.client.DatePickerClientModule'));


/** @private {Logger} */
DatePickerClientModule.$f_LOGGER__org_dominokit_domino_datepicker_client_DatePickerClientModule_;




exports = DatePickerClientModule; 
//# sourceMappingURL=DatePickerClientModule.js.map