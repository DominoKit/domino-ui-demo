/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration.$2$impl');
let DatePickerPresenterContributionToFormsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.datepicker.client.contributions.DatePickerPresenterContributionToFormsExtensionPoint$impl');
let DatePickerPresenter = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$impl');
let DatePickerPresenterCommand = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand$impl');
let FormsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');


/**
 * @implements {ModuleConfiguration}
  */
class DatePickerModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerModuleConfiguration()'.
   * @return {!DatePickerModuleConfiguration}
   * @public
   */
  static $create__() {
    DatePickerModuleConfiguration.$clinit();
    let $instance = new DatePickerModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_datepicker_client_DatePickerModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_DatePickerModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_datepicker_client_DatePickerModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(DatePickerPresenter).m_getCanonicalName__(), Class.$get(DatePickerPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_datepicker_client_DatePickerModuleConfiguration__java_lang_String(this, Class.$get(DatePickerPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(DatePickerPresenterCommand).m_getCanonicalName__(), Class.$get(DatePickerPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(FormsExtensionPoint), DatePickerPresenterContributionToFormsExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration.$2$impl');
    DatePickerPresenterContributionToFormsExtensionPoint = goog.module.get('org.dominokit.domino.datepicker.client.contributions.DatePickerPresenterContributionToFormsExtensionPoint$impl');
    DatePickerPresenter = goog.module.get('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$impl');
    DatePickerPresenterCommand = goog.module.get('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand$impl');
    FormsExtensionPoint = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.datepicker.client.DatePickerModuleConfiguration'));


ModuleConfiguration.$markImplementor(DatePickerModuleConfiguration);


exports = DatePickerModuleConfiguration; 
//# sourceMappingURL=DatePickerModuleConfiguration.js.map