/**
 * @fileoverview transpiled from com.google.gwt.core.client.UnsafeNativeLong$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.google.gwt.core.client.UnsafeNativeLong.$LambdaAdaptor$impl');


const UnsafeNativeLong = goog.require('com.google.gwt.core.client.UnsafeNativeLong$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Annotation = goog.forwardDeclare('java.lang.annotation.Annotation$impl');


/**
 * @implements {UnsafeNativeLong}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Class<?>} */
    this.f_$$fn__com_google_gwt_core_client_UnsafeNativeLong_$LambdaAdaptor;
    this.$ctor__com_google_gwt_core_client_UnsafeNativeLong_$LambdaAdaptor__com_google_gwt_core_client_UnsafeNativeLong_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @return {void}
   * @public
   */
  $ctor__com_google_gwt_core_client_UnsafeNativeLong_$LambdaAdaptor__com_google_gwt_core_client_UnsafeNativeLong_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__com_google_gwt_core_client_UnsafeNativeLong_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Class<?>}
   * @public
   */
  m_annotationType__() {
    let /** ?function():Class<?> */ $function;
    return ($function = this.f_$$fn__com_google_gwt_core_client_UnsafeNativeLong_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('com.google.gwt.core.client.UnsafeNativeLong$$LambdaAdaptor'));


UnsafeNativeLong.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=UnsafeNativeLong$$LambdaAdaptor.js.map