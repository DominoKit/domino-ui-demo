/**
 * @fileoverview transpiled from com.google.gwt.core.client.UnsafeNativeLong.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.google.gwt.core.client.UnsafeNativeLong');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('com.google.gwt.core.client.UnsafeNativeLong.$LambdaAdaptor');
const _Class = goog.require('java.lang.Class');


// Re-exports the implementation.
var UnsafeNativeLong = goog.require('com.google.gwt.core.client.UnsafeNativeLong$impl');
exports = UnsafeNativeLong;
 