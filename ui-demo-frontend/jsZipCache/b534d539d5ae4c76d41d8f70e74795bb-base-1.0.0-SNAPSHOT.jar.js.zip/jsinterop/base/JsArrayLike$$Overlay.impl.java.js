/**
 * @fileoverview transpiled from jsinterop.base.JsArrayLike$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('jsinterop.base.JsArrayLike.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.Any.$Overlay$impl');
let InternalJsUtil = goog.forwardDeclare('jsinterop.base.InternalJsUtil$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class JsArrayLike_$Overlay {
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @return {number}
   * @public
   */
  static m_getLength__jsinterop_base_JsArrayLike($thisArg) {
    JsArrayLike_$Overlay.$clinit();
    return InternalJsUtil.getLength($thisArg);
  }
  
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @param {number} length
   * @return {void}
   * @public
   */
  static m_setLength__jsinterop_base_JsArrayLike__int($thisArg, length) {
    JsArrayLike_$Overlay.$clinit();
    InternalJsUtil.setLength($thisArg, length);
  }
  
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @param {number} index
   * @return {C_T}
   * @public
   */
  static m_getAt__jsinterop_base_JsArrayLike__int($thisArg, index) {
    JsArrayLike_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to(InternalJsUtil.getIndexed($thisArg, index), j_l_Object));
  }
  
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @param {number} index
   * @return {*}
   * @public
   */
  static m_getAnyAt__jsinterop_base_JsArrayLike__int($thisArg, index) {
    JsArrayLike_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to(InternalJsUtil.getIndexed($thisArg, index), $Overlay));
  }
  
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @param {number} index
   * @param {C_T} value
   * @return {void}
   * @public
   */
  static m_setAt__jsinterop_base_JsArrayLike__int__java_lang_Object($thisArg, index, value) {
    JsArrayLike_$Overlay.$clinit();
    InternalJsUtil.setIndexed($thisArg, index, value);
  }
  
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @param {number} index
   * @return {void}
   * @public
   */
  static m_delete__jsinterop_base_JsArrayLike__int($thisArg, index) {
    JsArrayLike_$Overlay.$clinit();
    InternalJsUtil.deleteIndexed($thisArg, index);
  }
  
  /**
   * @template C_T
   * @param {IArrayLike<C_T>} $thisArg
   * @return {List<C_T>}
   * @public
   */
  static m_asList__jsinterop_base_JsArrayLike($thisArg) {
    JsArrayLike_$Overlay.$clinit();
    let asArray = /**@type {Array<*>} */ (Js.m_uncheckedCast__java_lang_Object($thisArg));
    return /**@type {List<*>} */ (Arrays.m_asList__arrayOf_java_lang_Object(asArray));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsArrayLike_$Overlay.$clinit = function() {};
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    $Overlay = goog.module.get('jsinterop.base.Any.$Overlay$impl');
    InternalJsUtil = goog.module.get('jsinterop.base.InternalJsUtil$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JsArrayLike_$Overlay, $Util.$makeClassName('IArrayLike'));


exports = JsArrayLike_$Overlay; 
//# sourceMappingURL=JsArrayLike$$Overlay.js.map