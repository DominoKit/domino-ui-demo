/**
 * @fileoverview transpiled from jsinterop.base.JsPropertyMap$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.JsPropertyMap.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_Object = goog.require('java.lang.Object');
const _$Overlay = goog.require('jsinterop.base.Any.$Overlay');
const _InternalJsUtil = goog.require('jsinterop.base.InternalJsUtil');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var JsPropertyMap_$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay$impl');
exports = JsPropertyMap_$Overlay;
 