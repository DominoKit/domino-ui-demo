package org.dominokit.domino.menu.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint;
import org.dominokit.domino.menu.client.presenters.MenuPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class MenuPresenterContributionToLayoutExtensionPoint implements Contribution<LayoutExtensionPoint> {
  @Override
  public void contribute(LayoutExtensionPoint extensionPoint) {
    new MenuPresenterCommand().onPresenterReady(presenter -> presenter.contributeToLayoutModule(extensionPoint.context())).send();
  }
}
