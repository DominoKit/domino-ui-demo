/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.ui.MenuViewImpl$SubMenu.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let MenuViewImpl = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu.$LambdaAdaptor$3$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
let MenuItem = goog.forwardDeclare('org.dominokit.domino.ui.menu.MenuItem$impl');


/**
 * @implements {CanAddMenuItem}
  */
class SubMenu extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {MenuViewImpl} */
    this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu;
    /** @public {MenuItem} */
    this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_;
  }
  
  /**
   * Factory method corresponding to constructor 'SubMenu(MenuViewImpl, MenuItem)'.
   * @param {MenuViewImpl} $outer_this
   * @param {MenuItem} menuItem
   * @return {!SubMenu}
   * @public
   */
  static $create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem($outer_this, menuItem) {
    SubMenu.$clinit();
    let $instance = new SubMenu();
    $instance.$ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem($outer_this, menuItem);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SubMenu(MenuViewImpl, MenuItem)'.
   * @param {MenuViewImpl} $outer_this
   * @param {MenuItem} menuItem
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem($outer_this, menuItem) {
    this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_ = menuItem;
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String(title) {
    let item = this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_.m_addMenuItem__java_lang_String(title);
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem(this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu, item);
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, selectionHandler) {
    let item = this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_.m_addMenuItem__java_lang_String(title);
    item.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$3(((/** Event */ e) =>{
      selectionHandler.m_onMenuSelected__();
    })));
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem(this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu, item);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SubMenu;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SubMenu);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SubMenu.$clinit = function() {};
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu.$LambdaAdaptor$3$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SubMenu, $Util.$makeClassName('org.dominokit.domino.menu.client.views.ui.MenuViewImpl$SubMenu'));


CanAddMenuItem.$markImplementor(SubMenu);


exports = SubMenu; 
//# sourceMappingURL=MenuViewImpl$SubMenu.js.map