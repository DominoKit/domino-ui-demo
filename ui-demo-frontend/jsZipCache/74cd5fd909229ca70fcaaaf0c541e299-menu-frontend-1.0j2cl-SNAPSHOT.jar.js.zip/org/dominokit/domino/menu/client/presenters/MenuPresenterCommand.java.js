/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.presenters.MenuPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _MenuPresenter = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenter');


// Re-exports the implementation.
var MenuPresenterCommand = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand$impl');
exports = MenuPresenterCommand;
 