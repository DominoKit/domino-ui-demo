/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.MenuView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.views.MenuView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');

let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');


/**
 * @interface
 * @extends {View}
 */
class MenuView {
  /**
   * @abstract
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @param {?string} iconName
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler) {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @param {?string} iconName
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String(title, iconName) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_menu_client_views_MenuView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_menu_client_views_MenuView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_menu_client_views_MenuView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(MenuView, $Util.$makeClassName('org.dominokit.domino.menu.client.views.MenuView'));


MenuView.$markImplementor(/** @type {Function} */ (MenuView));


exports = MenuView; 
//# sourceMappingURL=MenuView.js.map