/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ClientRequestEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ClientRequestEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _ClientRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _DefaultRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext');
const _GWTRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ClientRequestEvent.GWTRequestEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ClientRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ClientRequestEvent$impl');
exports = ClientRequestEvent;
 