/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.async.GwtAsyncRunner.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.async.GwtAsyncRunner$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const AsyncRunner = goog.require('org.dominokit.domino.api.client.async.AsyncRunner$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let AsyncTask = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {AsyncRunner}
  */
class GwtAsyncRunner extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GwtAsyncRunner()'.
   * @return {!GwtAsyncRunner}
   * @public
   */
  static $create__() {
    GwtAsyncRunner.$clinit();
    let $instance = new GwtAsyncRunner();
    $instance.$ctor__org_dominokit_domino_gwt_client_async_GwtAsyncRunner__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GwtAsyncRunner()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_async_GwtAsyncRunner__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {AsyncTask} asyncTask
   * @return {void}
   * @public
   */
  m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(asyncTask) {
    try {
      asyncTask.m_onSuccess__();
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (Throwable.$isInstance(__$exc)) {
        let reason = /**@type {Throwable} */ (__$exc);
        asyncTask.m_onFailed__java_lang_Throwable(reason);
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GwtAsyncRunner;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GwtAsyncRunner);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GwtAsyncRunner.$clinit = function() {};
    Throwable = goog.module.get('java.lang.Throwable$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GwtAsyncRunner, $Util.$makeClassName('org.dominokit.domino.gwt.client.async.GwtAsyncRunner'));


AsyncRunner.$markImplementor(GwtAsyncRunner);


exports = GwtAsyncRunner; 
//# sourceMappingURL=GwtAsyncRunner.js.map