/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ClientEventFactory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ClientEventFactory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ClientRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ClientRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ClientRequestEvent');


// Re-exports the implementation.
var ClientEventFactory = goog.require('org.dominokit.domino.gwt.client.events.ClientEventFactory$impl');
exports = ClientEventFactory;
 