/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.views.AlertsView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.alerts.client.views.AlertsView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.alerts.client.views.AlertsView.$LambdaAdaptor');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');


// Re-exports the implementation.
var AlertsView = goog.require('org.dominokit.domino.alerts.client.views.AlertsView$impl');
exports = AlertsView;
 