/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.views.AlertsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.alerts.client.views.AlertsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.alerts.client.views.AlertsView.$LambdaAdaptor$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class AlertsView {
  /**
   * @param {?function():Content} fn
   * @return {AlertsView}
   * @public
   */
  static $adapt(fn) {
    AlertsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_alerts_client_views_AlertsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_alerts_client_views_AlertsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_alerts_client_views_AlertsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.alerts.client.views.AlertsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(AlertsView, $Util.$makeClassName('org.dominokit.domino.alerts.client.views.AlertsView'));


AlertsView.$markImplementor(/** @type {Function} */ (AlertsView));


exports = AlertsView; 
//# sourceMappingURL=AlertsView.js.map