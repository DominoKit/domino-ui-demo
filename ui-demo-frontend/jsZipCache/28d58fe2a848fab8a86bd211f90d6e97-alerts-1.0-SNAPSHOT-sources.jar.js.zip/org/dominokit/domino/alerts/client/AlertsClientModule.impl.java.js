/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.AlertsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.alerts.client.AlertsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class AlertsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AlertsClientModule()'.
   * @return {!AlertsClientModule}
   * @public
   */
  static $create__() {
    AlertsClientModule.$clinit();
    let $instance = new AlertsClientModule();
    $instance.$ctor__org_dominokit_domino_alerts_client_AlertsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AlertsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_alerts_client_AlertsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    AlertsClientModule.$f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_.m_info__java_lang_String("Initializing Alerts frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_() {
    return (AlertsClientModule.$clinit(), AlertsClientModule.$f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_(value) {
    (AlertsClientModule.$clinit(), AlertsClientModule.$f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AlertsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AlertsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    AlertsClientModule.$f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AlertsClientModule));
  }
  
  
};

$Util.$setClassMetadata(AlertsClientModule, $Util.$makeClassName('org.dominokit.domino.alerts.client.AlertsClientModule'));


/** @private {Logger} */
AlertsClientModule.$f_LOGGER__org_dominokit_domino_alerts_client_AlertsClientModule_;




exports = AlertsClientModule; 
//# sourceMappingURL=AlertsClientModule.js.map