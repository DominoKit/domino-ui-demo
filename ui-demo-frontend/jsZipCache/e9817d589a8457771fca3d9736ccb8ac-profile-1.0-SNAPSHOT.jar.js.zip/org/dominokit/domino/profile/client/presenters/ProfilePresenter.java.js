/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.presenters.ProfilePresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.profile.client.presenters.ProfilePresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ProfilePresenter = goog.require('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');
exports = ProfilePresenter;
 