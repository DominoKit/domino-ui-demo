/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ProfilePresenter = goog.require('org.dominokit.domino.profile.client.presenters.ProfilePresenter');


// Re-exports the implementation.
var ProfilePresenterCommand = goog.require('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');
exports = ProfilePresenterCommand;
 