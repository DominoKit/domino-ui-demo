/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.ProfileClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.ProfileClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ProfileClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProfileClientModule()'.
   * @return {!ProfileClientModule}
   * @public
   */
  static $create__() {
    ProfileClientModule.$clinit();
    let $instance = new ProfileClientModule();
    $instance.$ctor__org_dominokit_domino_profile_client_ProfileClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfileClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_ProfileClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ProfileClientModule.$f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_.m_info__java_lang_String("Initializing Profile frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_() {
    return (ProfileClientModule.$clinit(), ProfileClientModule.$f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_(value) {
    (ProfileClientModule.$clinit(), ProfileClientModule.$f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfileClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfileClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfileClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ProfileClientModule.$f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ProfileClientModule));
  }
  
  
};

$Util.$setClassMetadata(ProfileClientModule, $Util.$makeClassName('org.dominokit.domino.profile.client.ProfileClientModule'));


/** @private {Logger} */
ProfileClientModule.$f_LOGGER__org_dominokit_domino_profile_client_ProfileClientModule_;




exports = ProfileClientModule; 
//# sourceMappingURL=ProfileClientModule.js.map