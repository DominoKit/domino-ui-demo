/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const FormsValidationsView = goog.require('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$4$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let CheckBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Radio = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio$impl');
let RadioGroup = goog.forwardDeclare('org.dominokit.domino.ui.forms.RadioGroup$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextArea = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Tooltip = goog.forwardDeclare('org.dominokit.domino.ui.popover.Tooltip$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {FormsValidationsView}
  */
class FormsValidationsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_readOnlyCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'FormsValidationsViewImpl()'.
   * @return {!FormsValidationsViewImpl}
   * @public
   */
  static $create__() {
    FormsValidationsViewImpl.$clinit();
    let $instance = new FormsValidationsViewImpl();
    $instance.$ctor__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsValidationsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("FIELDS DECORATION").m_asElement__());
    this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("HELPER TEXTS");
    this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("ADDONS");
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("WORD COUNTER");
    this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("VALIDATIONS");
    this.f_readOnlyCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("READ ONLY");
    this.m_initHelperText___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initIcons___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initWordCount___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initValidations___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initReadOnly___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl, "helper-text").m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl, "addons").m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl, "word-count").m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl, "validations").m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_readOnlyCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl, "read-only").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initReadOnly___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_readOnlyCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("TextBox").m_value__java_lang_Object("Mr. Joan"), TextBox)).m_setReadOnly__boolean(true)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("TextArea").m_value__java_lang_Object("CEO of the largest company"), TextArea)).m_setRows__int(1).m_setReadOnly__boolean(true)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Select<*>} */ (Select.m_create__java_lang_String("Select")).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<*>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("english", "English"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<*>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("france", "France"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<*>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("arabic", "Arabic"))).m_selectAt__int(0).m_setReadOnly__boolean(true)), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initHelperText___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Text Box")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TextBox.m_create__java_lang_String("Task Name").m_setHelperText__java_lang_String("Each task should have unique name.")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Text Area")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TextArea.m_create__java_lang_String("Description").m_setHelperText__java_lang_String("Less than 100 words")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Select")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Task type")).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("-- Select a type --", "-- Select a type --"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Story", "Story"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Bugfix", "Bugfix"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Hotfix", "Hotfix"))).m_setHelperText__java_lang_String("Helps with tracking the issues")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Checkbox")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(CheckBox.m_create__java_lang_String("I want to receive an news about this task").m_setHelperText__java_lang_String("news will be sent via email")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Radio")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(RadioGroup.m_create__java_lang_String__java_lang_String("estimation", "Estimation").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("storyPoint", "Story points")).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("hours", "Effective hours")).m_horizontal__().m_setHelperText__java_lang_String("Helps with sprint reports")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Switch")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(SwitchButton.m_create__().m_setOffTitle__java_lang_String("Notifications: ").m_setHelperText__java_lang_String("Notifications will be sent via the system"));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initIcons___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    let cancel = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cancel__();
    let username = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Username").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_account_circle__()), TextBox)).m_setRightAddon__org_jboss_gwt_elemento_core_IsElement(cancel), TextBox));
    /**@type {Icon} */ ($Casts.$to(cancel.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      username.m_clear__();
    }))), Icon)).m_style__().m_setCursor__java_lang_String("pointer");
    let showIcon = /**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_remove_red_eye__().m_clickable__(), Icon)).m_style__().m_setCursor__java_lang_String("pointer").m_asElement__();
    let password = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_password__java_lang_String("Password").m_setLeftAddon__elemental2_dom_Element(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_https__().m_asElement__()), TextBox)).m_setRightAddon__elemental2_dom_Element(showIcon), TextBox));
    showIcon.addEventListener("mousedown", new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      /**@type {HTMLInputElement} */ ($Casts.$to(password.m_getInputElement__().m_asElement__(), $Overlay)).type = "text";
    })));
    showIcon.addEventListener("mouseup", new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      /**@type {HTMLInputElement} */ ($Casts.$to(password.m_getInputElement__().m_asElement__(), $Overlay)).type = "password";
    })));
    let info = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_info__();
    Tooltip.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String(info, "All system pages will be shown in the selected language");
    this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(username).m_appendChild__org_jboss_gwt_elemento_core_IsElement(password).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TextArea.m_create__java_lang_String("Description").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Language")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_language__()).m_setRightAddon__org_jboss_gwt_elemento_core_IsElement(info).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("english", "English"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("france", "France"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("arabic", "Arabic"))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initWordCount___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(TextBox.m_create__java_lang_String("Name").m_setMaxLength__int(10));
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(TextArea.m_create__java_lang_String("Description").m_setMaxLength__int(100));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initValidations___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    let fieldsGrouping = FieldsGrouping.m_create__();
    let name = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Name").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), TextBox));
    let surename = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Surename").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), TextBox));
    let email = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Email").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), TextBox));
    let gender = RadioGroup.m_create__java_lang_String__java_lang_String("gender", "Gender").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("male", "Male")).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("female", "Female")).m_horizontal__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping);
    let description = /**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("Description").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), TextArea));
    let password = /**@type {TextBox} */ ($Casts.$to(TextBox.m_password__java_lang_String("Password").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), TextBox));
    let termsAndConditions = /**@type {CheckBox} */ ($Casts.$to(CheckBox.m_create__java_lang_String("I have read and accept the terms").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), CheckBox));
    let language = /**@type {Select} */ ($Casts.$to(/**@type {Select<*>} */ (Select.m_create__java_lang_String("Language")).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<*>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("english", "English"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<*>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("france", "France"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<*>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("arabic", "Arabic"))).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(fieldsGrouping), Select));
    fieldsGrouping.m_setAutoValidation__boolean(true).m_setRequired__boolean(true);
    this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(name), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(surename), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(email), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(gender), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(description), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(password), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(language), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(termsAndConditions), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("REGISTER").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt) =>{
      let validationResult = fieldsGrouping.m_validate__();
      if (validationResult.m_isValid__()) {
        fieldsGrouping.m_clear__();
      } else {
        Notification.m_createDanger__java_lang_String("Error " + j_l_String.m_valueOf__java_lang_Object(validationResult.m_getErrorMessage__())).m_show__();
      }
    })))), Column))));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsValidationsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsValidationsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsValidationsViewImpl.$clinit = function() {};
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$4$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    CheckBox = goog.module.get('org.dominokit.domino.ui.forms.CheckBox$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Radio = goog.module.get('org.dominokit.domino.ui.forms.Radio$impl');
    RadioGroup = goog.module.get('org.dominokit.domino.ui.forms.RadioGroup$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextArea = goog.module.get('org.dominokit.domino.ui.forms.TextArea$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Tooltip = goog.module.get('org.dominokit.domino.ui.popover.Tooltip$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsValidationsViewImpl, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl'));


/** @public {?string} @const */
FormsValidationsViewImpl.f_MODULE_NAME__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl = "formsvalidations";


FormsValidationsView.$markImplementor(FormsValidationsViewImpl);


exports = FormsValidationsViewImpl; 
//# sourceMappingURL=FormsValidationsViewImpl.js.map