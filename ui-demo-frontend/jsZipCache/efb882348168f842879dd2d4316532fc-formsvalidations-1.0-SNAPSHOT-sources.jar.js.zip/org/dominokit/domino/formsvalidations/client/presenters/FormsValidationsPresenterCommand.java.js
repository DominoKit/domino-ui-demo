/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _FormsValidationsPresenter = goog.require('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter');


// Re-exports the implementation.
var FormsValidationsPresenterCommand = goog.require('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand$impl');
exports = FormsValidationsPresenterCommand;
 