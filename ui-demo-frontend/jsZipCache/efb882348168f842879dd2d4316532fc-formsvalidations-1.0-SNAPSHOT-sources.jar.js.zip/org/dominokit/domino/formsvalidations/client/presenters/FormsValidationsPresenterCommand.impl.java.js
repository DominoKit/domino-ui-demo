/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let FormsValidationsPresenter = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter$impl');


/**
 * @extends {PresenterCommand<FormsValidationsPresenter>}
  */
class FormsValidationsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsValidationsPresenterCommand()'.
   * @return {!FormsValidationsPresenterCommand}
   * @public
   */
  static $create__() {
    FormsValidationsPresenterCommand.$clinit();
    let $instance = new FormsValidationsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsValidationsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsValidationsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsValidationsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsValidationsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsValidationsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand'));




exports = FormsValidationsPresenterCommand; 
//# sourceMappingURL=FormsValidationsPresenterCommand.js.map