package org.dominokit.domino.formsvalidations.client.views;

import org.dominokit.domino.api.client.mvp.view.ContentView;
import org.dominokit.domino.api.shared.extension.Content;

public interface FormsValidationsView extends ContentView {
    Content getContent();
}