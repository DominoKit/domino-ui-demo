/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.FormsValidationsModuleConfiguration$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsvalidations.client.FormsValidationsModuleConfiguration.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _FormsValidationsModuleConfiguration = goog.require('org.dominokit.domino.formsvalidations.client.FormsValidationsModuleConfiguration');
const _FormsValidationsViewImpl = goog.require('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.formsvalidations.client.FormsValidationsModuleConfiguration.$2$impl');
exports = $2;
 