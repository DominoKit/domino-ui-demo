/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormsValidationsView = goog.require('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @implements {FormsValidationsView}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Content} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Content} */
    this.f_$$fn__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$LambdaAdaptor__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Content} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$LambdaAdaptor__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Content}
   * @public
   */
  m_getContent__() {
    let /** ?function():Content */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView_$LambdaAdaptor, $function());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    j_l_Object.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$$LambdaAdaptor'));


FormsValidationsView.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=FormsValidationsView$$LambdaAdaptor.js.map