/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter.$1$impl');
let FormsValidationsView = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<FormsValidationsView>}
  */
class FormsValidationsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsValidationsPresenter()'.
   * @return {!FormsValidationsPresenter}
   * @public
   */
  static $create__() {
    FormsValidationsPresenter.$clinit();
    let $instance = new FormsValidationsPresenter();
    $instance.$ctor__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsValidationsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {FormsContext} context
   * @return {void}
   * @public
   */
  m_onFormsEvent__org_dominokit_domino_forms_shared_extension_FormsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter_() {
    return (FormsValidationsPresenter.$clinit(), FormsValidationsPresenter.$f_LOGGER__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter_(value) {
    (FormsValidationsPresenter.$clinit(), FormsValidationsPresenter.$f_LOGGER__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsValidationsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsValidationsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsValidationsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    FormsValidationsPresenter.$f_LOGGER__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormsValidationsPresenter));
  }
  
  
};

$Util.$setClassMetadata(FormsValidationsPresenter, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter'));


/** @private {Logger} */
FormsValidationsPresenter.$f_LOGGER__org_dominokit_domino_formsvalidations_client_presenters_FormsValidationsPresenter_;




exports = FormsValidationsPresenter; 
//# sourceMappingURL=FormsValidationsPresenter.js.map