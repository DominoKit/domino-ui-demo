/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ColorsPresenter = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenter$impl');


/**
 * @extends {PresenterCommand<ColorsPresenter>}
  */
class ColorsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ColorsPresenterCommand()'.
   * @return {!ColorsPresenterCommand}
   * @public
   */
  static $create__() {
    ColorsPresenterCommand.$clinit();
    let $instance = new ColorsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_colors_client_presenters_ColorsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColorsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_colors_client_presenters_ColorsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColorsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColorsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ColorsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ColorsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand'));




exports = ColorsPresenterCommand; 
//# sourceMappingURL=ColorsPresenterCommand.js.map