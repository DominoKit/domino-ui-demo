/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.views.ColorsView$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.colors.client.views.ColorsView.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ColorsView = goog.require('org.dominokit.domino.colors.client.views.ColorsView');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.colors.client.views.ColorsView.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 