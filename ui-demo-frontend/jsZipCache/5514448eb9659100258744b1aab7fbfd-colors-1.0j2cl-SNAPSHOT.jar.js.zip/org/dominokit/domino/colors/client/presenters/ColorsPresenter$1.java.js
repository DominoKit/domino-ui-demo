/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.presenters.ColorsPresenter$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.colors.client.presenters.ColorsPresenter.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _ColorsPresenter = goog.require('org.dominokit.domino.colors.client.presenters.ColorsPresenter');
const _ColorsView = goog.require('org.dominokit.domino.colors.client.views.ColorsView');
const _ComponentRemoveHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler');
const _ComponentRevealedHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.colors.client.presenters.ColorsPresenter.$1$impl');
exports = $1;
 