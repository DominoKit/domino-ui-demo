/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ColorsPresenter = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenter$impl');
let ColorsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentCaseExtensionPoint>}
  */
class ColorsPresenterContributionToComponentCaseExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ColorsPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {!ColorsPresenterContributionToComponentCaseExtensionPoint}
   * @public
   */
  static $create__() {
    ColorsPresenterContributionToComponentCaseExtensionPoint.$clinit();
    let $instance = new ColorsPresenterContributionToComponentCaseExtensionPoint();
    $instance.$ctor__org_dominokit_domino_colors_client_contributions_ColorsPresenterContributionToComponentCaseExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColorsPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_colors_client_contributions_ColorsPresenterContributionToComponentCaseExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(extensionPoint) {
    ColorsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ColorsPresenter */ presenter) =>{
      presenter.m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(/**@type {ComponentCaseExtensionPoint} */ ($Casts.$to(arg0, ComponentCaseExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColorsPresenterContributionToComponentCaseExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColorsPresenterContributionToComponentCaseExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ColorsPresenterContributionToComponentCaseExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ColorsPresenterCommand = goog.module.get('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ColorsPresenterContributionToComponentCaseExtensionPoint, $Util.$makeClassName('org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint'));


Contribution.$markImplementor(ColorsPresenterContributionToComponentCaseExtensionPoint);


exports = ColorsPresenterContributionToComponentCaseExtensionPoint; 
//# sourceMappingURL=ColorsPresenterContributionToComponentCaseExtensionPoint.js.map