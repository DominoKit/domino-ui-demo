/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ColorsPresenter = goog.require('org.dominokit.domino.colors.client.presenters.ColorsPresenter');
const _ColorsPresenterCommand = goog.require('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ColorsPresenterContributionToComponentCaseExtensionPoint = goog.require('org.dominokit.domino.colors.client.contributions.ColorsPresenterContributionToComponentCaseExtensionPoint$impl');
exports = ColorsPresenterContributionToComponentCaseExtensionPoint;
 