package org.dominokit.domino.themes.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint;
import org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class ThemesPresenterContributionToLayoutExtensionPoint implements Contribution<LayoutExtensionPoint> {
  @Override
  public void contribute(LayoutExtensionPoint extensionPoint) {
    new ThemesPresenterCommand().onPresenterReady(presenter -> presenter.contributeToLayoutModule(extensionPoint.context())).send();
  }
}
