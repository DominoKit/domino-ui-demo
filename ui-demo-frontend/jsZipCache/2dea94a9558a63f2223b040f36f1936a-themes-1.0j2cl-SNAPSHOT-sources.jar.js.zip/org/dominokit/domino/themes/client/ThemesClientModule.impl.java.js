/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.ThemesClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.ThemesClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ThemesClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThemesClientModule()'.
   * @return {!ThemesClientModule}
   * @public
   */
  static $create__() {
    ThemesClientModule.$clinit();
    let $instance = new ThemesClientModule();
    $instance.$ctor__org_dominokit_domino_themes_client_ThemesClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThemesClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_ThemesClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ThemesClientModule.$f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_.m_info__java_lang_String("Initializing Themes frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_() {
    return (ThemesClientModule.$clinit(), ThemesClientModule.$f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_(value) {
    (ThemesClientModule.$clinit(), ThemesClientModule.$f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ThemesClientModule.$f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ThemesClientModule));
  }
  
  
};

$Util.$setClassMetadata(ThemesClientModule, $Util.$makeClassName('org.dominokit.domino.themes.client.ThemesClientModule'));


/** @private {Logger} */
ThemesClientModule.$f_LOGGER__org_dominokit_domino_themes_client_ThemesClientModule_;




exports = ThemesClientModule; 
//# sourceMappingURL=ThemesClientModule.js.map