/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ThemesPresenter = goog.forwardDeclare('org.dominokit.domino.themes.client.presenters.ThemesPresenter$impl');


/**
 * @extends {PresenterCommand<ThemesPresenter>}
  */
class ThemesPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThemesPresenterCommand()'.
   * @return {!ThemesPresenterCommand}
   * @public
   */
  static $create__() {
    ThemesPresenterCommand.$clinit();
    let $instance = new ThemesPresenterCommand();
    $instance.$ctor__org_dominokit_domino_themes_client_presenters_ThemesPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThemesPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_presenters_ThemesPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThemesPresenterCommand, $Util.$makeClassName('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand'));




exports = ThemesPresenterCommand; 
//# sourceMappingURL=ThemesPresenterCommand.js.map