/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.presenters.ThemesPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.themes.client.presenters.ThemesPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _ThemeAppliedHandler = goog.require('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler');
const _Class = goog.require('java.lang.Class');
const _Objects = goog.require('java.util.Objects');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DirectUrlHandler = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');
const _StateListener = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _ThemesView = goog.require('org.dominokit.domino.themes.client.views.ThemesView');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ThemesPresenter = goog.require('org.dominokit.domino.themes.client.presenters.ThemesPresenter$impl');
exports = ThemesPresenter;
 