package org.dominokit.domino.themes.client.views.ui;

import elemental2.dom.DomGlobal;
import org.jboss.gwt.elemento.template.TemplateUtil;

import javax.annotation.Generated;

/*
 * WARNING! This class is generated. Do not modify.
 */
@Generated("org.jboss.gwt.elemento.processor.TemplatedProcessor")
public final class Templated_ThemesPanel extends ThemesPanel {

    private final elemental2.dom.HTMLDivElement templated_themespanel_root_element;

 public Templated_ThemesPanel() {

        this.templated_themespanel_root_element = (elemental2.dom.HTMLDivElement)DomGlobal.document.createElement("div");
        this.templated_themespanel_root_element.setAttribute("class", "slimScrollDiv");
        this.templated_themespanel_root_element.setAttribute("style", "position: relative; width: auto;");
        this.templated_themespanel_root_element.innerHTML = "<ul data-element=\"themesContainer\" class=\"demo-choose-skin\" style=\"width: auto;\"> </ul>";

        if (this.themesContainer == null) {
            this.themesContainer = TemplateUtil.<elemental2.dom.HTMLUListElement>resolveElementAs(templated_themespanel_root_element, "themesContainer");
        } else {
            TemplateUtil.replaceElement(templated_themespanel_root_element, "themesContainer", themesContainer);
        }
    }

    @Override
    public elemental2.dom.HTMLDivElement asElement() {
        return templated_themespanel_root_element;
    }
}
