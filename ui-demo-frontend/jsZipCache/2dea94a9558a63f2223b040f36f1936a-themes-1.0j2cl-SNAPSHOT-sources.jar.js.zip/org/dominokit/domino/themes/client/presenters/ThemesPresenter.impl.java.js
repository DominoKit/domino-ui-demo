/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.presenters.ThemesPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.presenters.ThemesPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');
const ThemeAppliedHandler = goog.require('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let DirectUrlHandler = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');
let State = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');
let StateListener = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
let TokenFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let ThemesView = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ThemesView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseClientPresenter<ThemesView>}
 * @implements {ThemeAppliedHandler}
  */
class ThemesPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThemesPresenter()'.
   * @return {!ThemesPresenter}
   * @public
   */
  static $create__() {
    ThemesPresenter.$clinit();
    let $instance = new ThemesPresenter();
    $instance.$ctor__org_dominokit_domino_themes_client_presenters_ThemesPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThemesPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_presenters_ThemesPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ThemesView} view
   * @return {void}
   * @public
   */
  m_initView__org_dominokit_domino_themes_client_views_ThemesView(view) {
    view.m_onThemeApplied__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler(this);
    view.m_registerTheme__java_lang_String("red");
    view.m_registerTheme__java_lang_String("pink");
    view.m_registerTheme__java_lang_String("purple");
    view.m_registerTheme__java_lang_String("deep_purple");
    view.m_registerTheme__java_lang_String__boolean("indigo", !this.m_history__().m_currentToken__().m_hasQueryParameter__java_lang_String("theme"));
    view.m_registerTheme__java_lang_String("blue");
    view.m_registerTheme__java_lang_String("light_blue");
    view.m_registerTheme__java_lang_String("cyan");
    view.m_registerTheme__java_lang_String("teal");
    view.m_registerTheme__java_lang_String("green");
    view.m_registerTheme__java_lang_String("light_green");
    view.m_registerTheme__java_lang_String("lime");
    view.m_registerTheme__java_lang_String("yellow");
    view.m_registerTheme__java_lang_String("amber");
    view.m_registerTheme__java_lang_String("orange");
    view.m_registerTheme__java_lang_String("deep_orange");
    view.m_registerTheme__java_lang_String("brown");
    view.m_registerTheme__java_lang_String("grey");
    view.m_registerTheme__java_lang_String("blue_grey");
    view.m_registerTheme__java_lang_String("black");
    this.m_history__().m_listen__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(TokenFilter.m_contains__java_lang_String("theme="), StateListener.$adapt(((/** State */ arg0) =>{
      this.m_applyTheme__org_dominokit_domino_api_shared_history_DominoHistory_State_$p_org_dominokit_domino_themes_client_presenters_ThemesPresenter(arg0);
    }))).m_onDirectUrl__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler(DirectUrlHandler.$adapt(((/** State */ arg0$1$) =>{
      this.m_applyTheme__org_dominokit_domino_api_shared_history_DominoHistory_State_$p_org_dominokit_domino_themes_client_presenters_ThemesPresenter(arg0$1$);
    })));
  }
  
  /**
   * @param {State} state
   * @return {void}
   * @public
   */
  m_applyTheme__org_dominokit_domino_api_shared_history_DominoHistory_State_$p_org_dominokit_domino_themes_client_presenters_ThemesPresenter(state) {
    let theme = state.m_token__().m_parameterValue__java_lang_String("theme");
    if (Objects.m_nonNull__java_lang_Object(theme)) {
      /**@type {ThemesView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter, ThemesView)).m_applyTheme__java_lang_String(theme);
    }
  }
  
  /**
   * @param {LayoutContext} context
   * @return {void}
   * @public
   */
  m_contributeToLayoutModule__org_dominokit_domino_layout_shared_extension_LayoutContext(context) {
    /**@type {ThemesView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter, ThemesView)).m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(context.m_getLayout__());
  }
  
  /**
   * @override
   * @param {?string} theme
   * @return {void}
   * @public
   */
  m_onThemeApplied__java_lang_String(theme) {
    let token = this.m_history__().m_currentToken__();
    if (this.m_history__().m_currentToken__().m_hasQueryParameter__java_lang_String("theme")) {
      token.m_queryParameters__().put("theme", theme);
    } else {
      token.m_appendParameter__java_lang_String__java_lang_String("theme", theme);
    }
    this.m_history__().m_pushState__java_lang_String(token.m_value__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {View} arg0
   * @return {void}
   * @public
   */
  m_initView__org_dominokit_domino_api_client_mvp_view_View(arg0) {
    this.m_initView__org_dominokit_domino_themes_client_views_ThemesView(/**@type {ThemesView} */ ($Casts.$to(arg0, ThemesView)));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_themes_client_presenters_ThemesPresenter_() {
    return (ThemesPresenter.$clinit(), ThemesPresenter.$f_LOGGER__org_dominokit_domino_themes_client_presenters_ThemesPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_themes_client_presenters_ThemesPresenter_(value) {
    (ThemesPresenter.$clinit(), ThemesPresenter.$f_LOGGER__org_dominokit_domino_themes_client_presenters_ThemesPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    DirectUrlHandler = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');
    StateListener = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
    TokenFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter$impl');
    ThemesView = goog.module.get('org.dominokit.domino.themes.client.views.ThemesView$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseClientPresenter.$clinit();
    ThemesPresenter.$f_LOGGER__org_dominokit_domino_themes_client_presenters_ThemesPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ThemesPresenter));
  }
  
  
};

$Util.$setClassMetadata(ThemesPresenter, $Util.$makeClassName('org.dominokit.domino.themes.client.presenters.ThemesPresenter'));


/** @private {Logger} */
ThemesPresenter.$f_LOGGER__org_dominokit_domino_themes_client_presenters_ThemesPresenter_;


ThemeAppliedHandler.$markImplementor(ThemesPresenter);


exports = ThemesPresenter; 
//# sourceMappingURL=ThemesPresenter.js.map