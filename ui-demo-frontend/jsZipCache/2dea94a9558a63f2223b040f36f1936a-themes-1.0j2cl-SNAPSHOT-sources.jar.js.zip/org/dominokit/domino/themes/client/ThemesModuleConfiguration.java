package org.dominokit.domino.themes.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint;
import org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint;
import org.dominokit.domino.themes.client.presenters.ThemesPresenter;
import org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand;
import org.dominokit.domino.themes.client.views.ui.ThemesViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ThemesModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(ThemesPresenter.class.getCanonicalName(), ThemesPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new ThemesPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(ThemesPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new ThemesViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(ThemesPresenterCommand.class.getCanonicalName(), ThemesPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(LayoutExtensionPoint.class, new ThemesPresenterContributionToLayoutExtensionPoint());
  }
}
