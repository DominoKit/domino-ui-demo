package org.dominokit.domino.cards.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.cards.client.contributions.CardsPresenterContributionToComponentsExtensionPoint;
import org.dominokit.domino.cards.client.presenters.CardsPresenter;
import org.dominokit.domino.cards.client.presenters.CardsPresenterCommand;
import org.dominokit.domino.cards.client.views.ui.CardsViewImpl;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class CardsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(CardsPresenter.class.getCanonicalName(), CardsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new CardsPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(CardsPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new CardsViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(CardsPresenterCommand.class.getCanonicalName(), CardsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentsExtensionPoint.class, new CardsPresenterContributionToComponentsExtensionPoint());
  }
}
