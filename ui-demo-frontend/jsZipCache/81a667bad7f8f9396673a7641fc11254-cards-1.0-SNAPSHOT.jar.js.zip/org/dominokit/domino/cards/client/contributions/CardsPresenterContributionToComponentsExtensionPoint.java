package org.dominokit.domino.cards.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.cards.client.presenters.CardsPresenterCommand;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class CardsPresenterContributionToComponentsExtensionPoint implements Contribution<ComponentsExtensionPoint> {
  @Override
  public void contribute(ComponentsExtensionPoint extensionPoint) {
    new CardsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentsModule(extensionPoint.context())).send();
  }
}
