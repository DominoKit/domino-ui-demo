/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$NoRootMenuException.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.NoRootMenuException');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentCasePresenter = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter');


// Re-exports the implementation.
var NoRootMenuException = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.NoRootMenuException$impl');
exports = NoRootMenuException;
 