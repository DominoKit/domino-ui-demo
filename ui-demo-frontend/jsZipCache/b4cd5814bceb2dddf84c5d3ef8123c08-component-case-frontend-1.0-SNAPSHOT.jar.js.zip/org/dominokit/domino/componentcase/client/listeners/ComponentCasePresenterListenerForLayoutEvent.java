package org.dominokit.domino.componentcase.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand;
import org.dominokit.domino.layout.shared.extension.LayoutEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class ComponentCasePresenterListenerForLayoutEvent implements DominoEventListener<LayoutEvent> {
  @Override
  public void listen(LayoutEvent event) {
    new ComponentCasePresenterCommand().onPresenterReady(presenter -> presenter.onLayoutEvent(event.context())).send();
  }
}
