/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.views.ComponentCaseView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.views.ComponentCaseView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');


/**
 * @interface
 * @extends {ContentView}
 */
class ComponentCaseView {
  /**
   * @abstract
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_scrollTop__() {
  }
  
  /**
   * @abstract
   * @param {Content} content
   * @return {void}
   * @public
   */
  m_showContent__org_dominokit_domino_api_shared_extension_Content(content) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ContentView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_client_views_ComponentCaseView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_client_views_ComponentCaseView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_client_views_ComponentCaseView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseView.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentCaseView, $Util.$makeClassName('org.dominokit.domino.componentcase.client.views.ComponentCaseView'));


ComponentCaseView.$markImplementor(/** @type {Function} */ (ComponentCaseView));


exports = ComponentCaseView; 
//# sourceMappingURL=ComponentCaseView.js.map