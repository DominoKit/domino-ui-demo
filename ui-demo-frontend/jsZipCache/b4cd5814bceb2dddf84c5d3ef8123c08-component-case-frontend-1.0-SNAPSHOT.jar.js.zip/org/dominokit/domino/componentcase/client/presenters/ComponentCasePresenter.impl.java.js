/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');
const ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ContextAggregator = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator$impl');
let ContextWait = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');
let ReadyHandler = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let DirectUrlHandler = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');
let State = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');
let StateListener = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
let TokenFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter$impl');
let MenuBranch = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.MenuBranch$impl');
let NoRootMenuException = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.NoRootMenuException$impl');
let ComponentCaseView = goog.forwardDeclare('org.dominokit.domino.componentcase.client.views.ComponentCaseView$impl');
let ComponentCase = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let MenuContext = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @extends {ViewBaseClientPresenter<ComponentCaseView>}
 * @implements {ComponentCaseContext}
  */
class ComponentCasePresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContextWait<MenuContext>} */
    this.f_menuContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_;
    /** @public {ContextWait<LayoutContext>} */
    this.f_layoutContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_;
    /** @public {ComponentCase} */
    this.f_currentSample__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_;
    /** @public {Map<?string, MenuBranch>} */
    this.f_roots__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_;
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCasePresenter()'.
   * @return {!ComponentCasePresenter}
   * @public
   */
  static $create__() {
    ComponentCasePresenter.$clinit();
    let $instance = new ComponentCasePresenter();
    $instance.$ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCasePresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
    this.$init__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter();
  }
  
  /**
   * @param {ComponentCaseView} view
   * @return {void}
   * @public
   */
  m_initView__org_dominokit_domino_componentcase_client_views_ComponentCaseView(view) {
    ContextAggregator.m_waitFor__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(this.f_menuContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_).m_and__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(this.f_layoutContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_).m_onReady__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(ReadyHandler.$adapt((() =>{
      view.m_init__org_dominokit_domino_layout_shared_extension_IsLayout(/**@type {LayoutContext} */ ($Casts.$to(this.f_layoutContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_get__(), LayoutContext)).m_getLayout__());
      this.m_fireEvent__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEvent(Class.$get(ComponentCaseEvent), ComponentCaseEvent.$adapt((() =>{
        return this;
      })));
      if (j_l_String.m_isEmpty__java_lang_String(this.m_history__().m_currentToken__().m_fragment__())) {
        let historyToken = this.m_history__().m_currentToken__();
        historyToken.m_appendFragment__java_lang_String("home");
        this.m_history__().m_pushState__java_lang_String(historyToken.m_value__());
        this.m_history__().m_forward__();
      }
    })));
  }
  
  /**
   * @param {MenuContext} context
   * @return {void}
   * @public
   */
  m_onMenuEvent__org_dominokit_domino_menu_shared_extension_MenuContext(context) {
    this.f_menuContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_receiveContext__java_lang_Object(context);
  }
  
  /**
   * @param {LayoutContext} context
   * @return {void}
   * @public
   */
  m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(context) {
    this.f_layoutContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_receiveContext__java_lang_Object(context);
  }
  
  /**
   * @override
   * @param {ComponentCase} componentCase
   * @return {void}
   * @public
   */
  m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase(componentCase) {
    let rootPage = j_l_String.m_split__java_lang_String__java_lang_String(componentCase.m_getMenuPath__(), "/").length <= 1;
    if (componentCase.m_hasContent__()) {
      this.m_history__().m_listen__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(TokenFilter.m_startsWithFragment__java_lang_String(componentCase.m_getHistoryToken__()), StateListener.$adapt(((/** State */ state) =>{
        this.m_showPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
      }))).m_onDirectUrl__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler(DirectUrlHandler.$adapt(((/** State */ state$1$) =>{
        this.m_showPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
      })));
    }
    if (rootPage) {
      this.m_addRootPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
    } else {
      this.m_addSubPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
    }
  }
  
  /**
   * @param {ComponentCase} componentCase
   * @return {void}
   * @public
   */
  m_addSubPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase) {
    let pathElements = j_l_String.m_split__java_lang_String__java_lang_String(componentCase.m_getMenuPath__(), "/");
    if (Objects.m_isNull__java_lang_Object(this.f_roots__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.get(pathElements[0]))) {
      throw $Exceptions.toJs(NoRootMenuException.$create__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String(this, "No root menu : " + j_l_String.m_valueOf__java_lang_Object(pathElements[0])));
    }
    let root = /**@type {MenuBranch} */ ($Casts.$to(this.f_roots__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.get(pathElements[0]), MenuBranch));
    for (let index = 1; index < pathElements.length - 1; index++) {
      root = this.m_getOrAddMenuBranch__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch__java_lang_String_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(root, pathElements[index]);
    }
    this.m_addSubPageToRoot__java_lang_String__org_dominokit_domino_componentcase_shared_extension_ComponentCase__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(pathElements[pathElements.length - 1], componentCase, root);
  }
  
  /**
   * @param {?string} path
   * @param {ComponentCase} componentCase
   * @param {MenuBranch} root
   * @return {void}
   * @public
   */
  m_addSubPageToRoot__java_lang_String__org_dominokit_domino_componentcase_shared_extension_ComponentCase__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(path, componentCase, root) {
    let /** CanAddMenuItem */ canAddMenuItem;
    if (componentCase.m_hasContent__()) {
      canAddMenuItem = root.f_menuItem__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(path, componentCase.m_getIconName__(), OnMenuSelectedHandler.$adapt((() =>{
        this.m_applyHistory__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
        this.m_showPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
      })));
    } else {
      canAddMenuItem = root.f_menuItem__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.m_addMenuItem__java_lang_String(path);
    }
    root.f_leaves__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.put(path, MenuBranch.$create__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem(this, path, canAddMenuItem));
  }
  
  /**
   * @param {ComponentCase} componentCase
   * @return {void}
   * @public
   */
  m_applyHistory__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase) {
    this.m_history__().m_pushState__java_lang_String(this.m_history__().m_currentToken__().m_replaceAllFragments__java_lang_String(componentCase.m_getHistoryToken__()).m_value__());
  }
  
  /**
   * @param {MenuBranch} root
   * @param {?string} pathElement
   * @return {MenuBranch}
   * @public
   */
  m_getOrAddMenuBranch__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch__java_lang_String_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(root, pathElement) {
    if (!root.f_leaves__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.containsKey(pathElement)) {
      let menuItem = root.f_menuItem__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.m_addMenuItem__java_lang_String(pathElement);
      root.f_leaves__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.put(pathElement, MenuBranch.$create__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem(this, pathElement, menuItem));
    }
    return /**@type {MenuBranch} */ ($Casts.$to(root.f_leaves__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_.get(pathElement), MenuBranch));
  }
  
  /**
   * @param {ComponentCase} componentCase
   * @return {void}
   * @public
   */
  m_addRootPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase) {
    let /** CanAddMenuItem */ canAddMenuItem;
    if (componentCase.m_hasContent__()) {
      canAddMenuItem = /**@type {MenuContext} */ ($Casts.$to(this.f_menuContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_get__(), MenuContext)).m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(componentCase.m_getMenuPath__(), componentCase.m_getIconName__(), OnMenuSelectedHandler.$adapt((() =>{
        this.m_applyHistory__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
        this.m_showPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase);
      })));
    } else {
      canAddMenuItem = /**@type {MenuContext} */ ($Casts.$to(this.f_menuContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_get__(), MenuContext)).m_addMenuItem__java_lang_String__java_lang_String(componentCase.m_getMenuPath__(), componentCase.m_getIconName__());
    }
    this.f_roots__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.put(componentCase.m_getMenuPath__(), MenuBranch.$create__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem(this, componentCase.m_getMenuPath__(), canAddMenuItem));
  }
  
  /**
   * @param {ComponentCase} componentCase
   * @return {void}
   * @public
   */
  m_showPage__org_dominokit_domino_componentcase_shared_extension_ComponentCase_$p_org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter(componentCase) {
    if (Objects.m_nonNull__java_lang_Object(this.f_currentSample__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_)) {
      this.f_currentSample__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_onComponentRemoved__().m_onBeforeRemove__();
    }
    /**@type {ComponentCaseView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, ComponentCaseView)).m_clear__();
    /**@type {LayoutContext} */ ($Casts.$to(this.f_layoutContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_.m_get__(), LayoutContext)).m_getLayout__().m_hideLeftPanel__();
    /**@type {ComponentCaseView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, ComponentCaseView)).m_showContent__org_dominokit_domino_api_shared_extension_Content(componentCase.m_getContent__());
    /**@type {ComponentCaseView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, ComponentCaseView)).m_scrollTop__();
    componentCase.m_onComponentRevealed__().m_onRevealed__();
    this.f_currentSample__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_ = componentCase;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {View} arg0
   * @return {void}
   * @public
   */
  m_initView__org_dominokit_domino_api_client_mvp_view_View(arg0) {
    this.m_initView__org_dominokit_domino_componentcase_client_views_ComponentCaseView(/**@type {ComponentCaseView} */ ($Casts.$to(arg0, ComponentCaseView)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter() {
    this.f_menuContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_ = /**@type {ContextWait<MenuContext>} */ (ContextWait.m_create__());
    this.f_layoutContext__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_ = /**@type {ContextWait<LayoutContext>} */ (ContextWait.m_create__());
    this.f_roots__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_ = /**@type {!HashMap<?string, MenuBranch>} */ (HashMap.$create__());
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_() {
    return (ComponentCasePresenter.$clinit(), ComponentCasePresenter.$f_LOGGER__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_(value) {
    (ComponentCasePresenter.$clinit(), ComponentCasePresenter.$f_LOGGER__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCasePresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCasePresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCasePresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    ContextAggregator = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator$impl');
    ContextWait = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');
    ReadyHandler = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');
    DirectUrlHandler = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');
    StateListener = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
    TokenFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter$impl');
    MenuBranch = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.MenuBranch$impl');
    NoRootMenuException = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.NoRootMenuException$impl');
    ComponentCaseView = goog.module.get('org.dominokit.domino.componentcase.client.views.ComponentCaseView$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    MenuContext = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
    OnMenuSelectedHandler = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    ViewBaseClientPresenter.$clinit();
    ComponentCasePresenter.$f_LOGGER__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ComponentCasePresenter));
  }
  
  
};

$Util.$setClassMetadata(ComponentCasePresenter, $Util.$makeClassName('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter'));


/** @private {Logger} */
ComponentCasePresenter.$f_LOGGER__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_;


ComponentCaseContext.$markImplementor(ComponentCasePresenter);


exports = ComponentCasePresenter; 
//# sourceMappingURL=ComponentCasePresenter.js.map