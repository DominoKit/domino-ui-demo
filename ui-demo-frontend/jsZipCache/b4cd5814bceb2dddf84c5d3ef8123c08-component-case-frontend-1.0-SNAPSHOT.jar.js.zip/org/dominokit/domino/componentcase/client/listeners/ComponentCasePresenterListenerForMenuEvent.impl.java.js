/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
let ComponentCasePresenterCommand = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
let MenuContext = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
let MenuEvent = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<MenuEvent>}
  */
class ComponentCasePresenterListenerForMenuEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCasePresenterListenerForMenuEvent()'.
   * @return {!ComponentCasePresenterListenerForMenuEvent}
   * @public
   */
  static $create__() {
    ComponentCasePresenterListenerForMenuEvent.$clinit();
    let $instance = new ComponentCasePresenterListenerForMenuEvent();
    $instance.$ctor__org_dominokit_domino_componentcase_client_listeners_ComponentCasePresenterListenerForMenuEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCasePresenterListenerForMenuEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_listeners_ComponentCasePresenterListenerForMenuEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {MenuEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_menu_shared_extension_MenuEvent(event) {
    ComponentCasePresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ComponentCasePresenter */ presenter) =>{
      presenter.m_onMenuEvent__org_dominokit_domino_menu_shared_extension_MenuContext(/**@type {MenuContext} */ ($Casts.$to(event.m_context__(), MenuContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_menu_shared_extension_MenuEvent(/**@type {MenuEvent} */ ($Casts.$to(arg0, MenuEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCasePresenterListenerForMenuEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCasePresenterListenerForMenuEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCasePresenterListenerForMenuEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCasePresenterCommand = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
    MenuContext = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
    MenuEvent = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCasePresenterListenerForMenuEvent, $Util.$makeClassName('org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent'));


DominoEventListener.$markImplementor(ComponentCasePresenterListenerForMenuEvent);


exports = ComponentCasePresenterListenerForMenuEvent; 
//# sourceMappingURL=ComponentCasePresenterListenerForMenuEvent.js.map