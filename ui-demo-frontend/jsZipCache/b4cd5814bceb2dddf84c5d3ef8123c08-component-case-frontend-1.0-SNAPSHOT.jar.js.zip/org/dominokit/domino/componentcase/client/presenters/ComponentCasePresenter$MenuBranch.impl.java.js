/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$MenuBranch.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.MenuBranch$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');


class MenuBranch extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ComponentCasePresenter} */
    this.f_$outer_this__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch;
    /** @public {?string} */
    this.f_title__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_;
    /** @public {CanAddMenuItem} */
    this.f_menuItem__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_;
    /** @public {Map<?string, MenuBranch>} */
    this.f_leaves__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_;
  }
  
  /**
   * Factory method corresponding to constructor 'MenuBranch(ComponentCasePresenter, String, CanAddMenuItem)'.
   * @param {ComponentCasePresenter} $outer_this
   * @param {?string} title
   * @param {CanAddMenuItem} menuItem
   * @return {!MenuBranch}
   * @public
   */
  static $create__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem($outer_this, title, menuItem) {
    MenuBranch.$clinit();
    let $instance = new MenuBranch();
    $instance.$ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem($outer_this, title, menuItem);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuBranch(ComponentCasePresenter, String, CanAddMenuItem)'.
   * @param {ComponentCasePresenter} $outer_this
   * @param {?string} title
   * @param {CanAddMenuItem} menuItem
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem($outer_this, title, menuItem) {
    this.f_$outer_this__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch = $outer_this;
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch();
    this.f_title__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_ = title;
    this.f_menuItem__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_ = menuItem;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch() {
    this.f_leaves__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_MenuBranch_ = /**@type {!HashMap<?string, MenuBranch>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuBranch;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuBranch);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuBranch.$clinit = function() {};
    HashMap = goog.module.get('java.util.HashMap$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuBranch, $Util.$makeClassName('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$MenuBranch'));




exports = MenuBranch; 
//# sourceMappingURL=ComponentCasePresenter$MenuBranch.js.map