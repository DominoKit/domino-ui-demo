/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentCasePresenter = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter');
const _ComponentCasePresenterCommand = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _MenuEvent = goog.require('org.dominokit.domino.menu.shared.extension.MenuEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ComponentCasePresenterListenerForMenuEvent = goog.require('org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent$impl');
exports = ComponentCasePresenterListenerForMenuEvent;
 