package org.dominokit.domino.componentcase.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand;
import org.dominokit.domino.menu.shared.extension.MenuEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class ComponentCasePresenterListenerForMenuEvent implements DominoEventListener<MenuEvent> {
  @Override
  public void listen(MenuEvent event) {
    new ComponentCasePresenterCommand().onPresenterReady(presenter -> presenter.onMenuEvent(event.context())).send();
  }
}
