/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForLayoutEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForLayoutEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
let ComponentCasePresenterCommand = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutEvent = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<LayoutEvent>}
  */
class ComponentCasePresenterListenerForLayoutEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCasePresenterListenerForLayoutEvent()'.
   * @return {!ComponentCasePresenterListenerForLayoutEvent}
   * @public
   */
  static $create__() {
    ComponentCasePresenterListenerForLayoutEvent.$clinit();
    let $instance = new ComponentCasePresenterListenerForLayoutEvent();
    $instance.$ctor__org_dominokit_domino_componentcase_client_listeners_ComponentCasePresenterListenerForLayoutEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCasePresenterListenerForLayoutEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_listeners_ComponentCasePresenterListenerForLayoutEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(event) {
    ComponentCasePresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ComponentCasePresenter */ presenter) =>{
      presenter.m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(event.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(/**@type {LayoutEvent} */ ($Casts.$to(arg0, LayoutEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCasePresenterListenerForLayoutEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCasePresenterListenerForLayoutEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCasePresenterListenerForLayoutEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCasePresenterCommand = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutEvent = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCasePresenterListenerForLayoutEvent, $Util.$makeClassName('org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForLayoutEvent'));


DominoEventListener.$markImplementor(ComponentCasePresenterListenerForLayoutEvent);


exports = ComponentCasePresenterListenerForLayoutEvent; 
//# sourceMappingURL=ComponentCasePresenterListenerForLayoutEvent.js.map