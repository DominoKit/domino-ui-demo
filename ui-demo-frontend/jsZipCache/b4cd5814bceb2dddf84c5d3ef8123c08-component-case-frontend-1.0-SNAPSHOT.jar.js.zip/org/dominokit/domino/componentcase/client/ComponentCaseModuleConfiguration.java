package org.dominokit.domino.componentcase.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForLayoutEvent;
import org.dominokit.domino.componentcase.client.listeners.ComponentCasePresenterListenerForMenuEvent;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand;
import org.dominokit.domino.layout.shared.extension.LayoutEvent;
import org.dominokit.domino.menu.shared.extension.MenuEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ComponentCaseModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(ComponentCasePresenter.class.getCanonicalName(), ComponentCasePresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new ComponentCasePresenter();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(ComponentCasePresenterCommand.class.getCanonicalName(), ComponentCasePresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(LayoutEvent.class, new ComponentCasePresenterListenerForLayoutEvent());
    registry.addListener(MenuEvent.class, new ComponentCasePresenterListenerForMenuEvent());
  }
}
