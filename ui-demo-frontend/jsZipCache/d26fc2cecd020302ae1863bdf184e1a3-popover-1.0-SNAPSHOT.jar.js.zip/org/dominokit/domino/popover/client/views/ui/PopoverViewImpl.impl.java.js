/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.views.ui.PopoverViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.popover.client.views.ui.PopoverViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const PopoverView = goog.require('org.dominokit.domino.popover.client.views.PopoverView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Tooltip = goog.forwardDeclare('org.dominokit.domino.ui.popover.Tooltip$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {PopoverView}
  */
class PopoverViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'PopoverViewImpl()'.
   * @return {!PopoverViewImpl}
   * @public
   */
  static $create__() {
    PopoverViewImpl.$clinit();
    let $instance = new PopoverViewImpl();
    $instance.$ctor__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PopoverViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(PopoverViewImpl.f_MODULE_NAME__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("TOOLTIPS & POPOVER").m_asElement__());
    this.m_tooltips___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl();
    this.m_popover___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_tooltips___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl() {
    let tooltip_on_right = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("TOOLTIP ON RIGHT").m_block__(), Button));
    Tooltip.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String(tooltip_on_right, "Tooltip on right").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_RIGHT__org_dominokit_domino_ui_popover_PopupPosition);
    let tooltip_on_top = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("TOOLTIP ON TOP").m_block__(), Button));
    Tooltip.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String(tooltip_on_top, "Tooltip on top").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition);
    let tooltip_on_bottom = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("TOOLTIP ON BOTTOM").m_block__(), Button));
    Tooltip.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String(tooltip_on_bottom, "Tooltip on bottom").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_BOTTOM__org_dominokit_domino_ui_popover_PopupPosition);
    let tooltip_on_left = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("TOOLTIP ON LEFT").m_block__(), Button));
    Tooltip.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String(tooltip_on_left, "Tooltip on left").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_LEFT__org_dominokit_domino_ui_popover_PopupPosition);
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(Card.m_create__java_lang_String("TOOLTIPS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(tooltip_on_right), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(tooltip_on_top), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(tooltip_on_bottom), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(tooltip_on_left), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PopoverViewImpl.f_MODULE_NAME__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl, "tooltips").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_popover___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl() {
    let popover_on_right = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("POPOVER ON RIGHT").m_block__(), Button));
    Popover.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(popover_on_right, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.")).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_RIGHT__org_dominokit_domino_ui_popover_PopupPosition);
    let popover_on_top = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("POPOVER ON TOP").m_block__(), Button));
    Popover.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(popover_on_top, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.")).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition);
    let popover_on_bottom = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("POPOVER ON BOTTOM").m_block__(), Button));
    Popover.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(popover_on_bottom, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.")).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_BOTTOM__org_dominokit_domino_ui_popover_PopupPosition);
    let popover_on_left = /**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("POPOVER ON LEFT").m_block__(), Button));
    Popover.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(popover_on_left, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.")).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_LEFT__org_dominokit_domino_ui_popover_PopupPosition);
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(Card.m_create__java_lang_String("POPOVER").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(popover_on_right), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(popover_on_top), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(popover_on_bottom), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(popover_on_left), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PopoverViewImpl.f_MODULE_NAME__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl, "popover").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl() {
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PopoverViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PopoverViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PopoverViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Tooltip = goog.module.get('org.dominokit.domino.ui.popover.Tooltip$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PopoverViewImpl, $Util.$makeClassName('org.dominokit.domino.popover.client.views.ui.PopoverViewImpl'));


/** @public {?string} @const */
PopoverViewImpl.f_MODULE_NAME__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl = "popover";


PopoverView.$markImplementor(PopoverViewImpl);


exports = PopoverViewImpl; 
//# sourceMappingURL=PopoverViewImpl.js.map