/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.views.ui.PopoverViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.popover.client.views.ui.PopoverViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _PopoverView = goog.require('org.dominokit.domino.popover.client.views.PopoverView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Popover = goog.require('org.dominokit.domino.ui.popover.Popover');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _Tooltip = goog.require('org.dominokit.domino.ui.popover.Tooltip');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PopoverViewImpl = goog.require('org.dominokit.domino.popover.client.views.ui.PopoverViewImpl$impl');
exports = PopoverViewImpl;
 