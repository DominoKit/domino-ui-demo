/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuEvent$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuEvent.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _MenuEvent = goog.require('org.dominokit.domino.menu.shared.extension.MenuEvent');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.menu.shared.extension.MenuEvent.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 