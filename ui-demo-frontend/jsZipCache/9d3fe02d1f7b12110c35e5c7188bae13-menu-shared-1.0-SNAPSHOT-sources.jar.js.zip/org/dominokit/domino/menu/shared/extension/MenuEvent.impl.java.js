/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let MenuContext = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuEvent.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {DominoEvent<MenuContext>}
 */
class MenuEvent {
  /**
   * @param {?function():MenuContext} fn
   * @return {MenuEvent}
   * @public
   */
  static $adapt(fn) {
    MenuEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_menu_shared_extension_MenuEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MenuEvent, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuEvent'));


MenuEvent.$markImplementor(/** @type {Function} */ (MenuEvent));


exports = MenuEvent; 
//# sourceMappingURL=MenuEvent.js.map