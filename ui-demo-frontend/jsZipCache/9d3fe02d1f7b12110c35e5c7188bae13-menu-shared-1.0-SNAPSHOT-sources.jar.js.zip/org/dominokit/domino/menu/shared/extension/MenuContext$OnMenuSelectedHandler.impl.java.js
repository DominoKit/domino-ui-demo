/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuContext$OnMenuSelectedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class OnMenuSelectedHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onMenuSelected__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {OnMenuSelectedHandler}
   * @public
   */
  static $adapt(fn) {
    OnMenuSelectedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    OnMenuSelectedHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(OnMenuSelectedHandler, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuContext$OnMenuSelectedHandler'));


OnMenuSelectedHandler.$markImplementor(/** @type {Function} */ (OnMenuSelectedHandler));


exports = OnMenuSelectedHandler; 
//# sourceMappingURL=MenuContext$OnMenuSelectedHandler.js.map