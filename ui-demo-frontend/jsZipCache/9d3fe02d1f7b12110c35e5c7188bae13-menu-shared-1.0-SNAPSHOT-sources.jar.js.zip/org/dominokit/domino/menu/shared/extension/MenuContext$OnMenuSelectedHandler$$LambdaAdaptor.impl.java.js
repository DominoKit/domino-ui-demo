/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuContext$OnMenuSelectedHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const OnMenuSelectedHandler = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');


/**
 * @implements {OnMenuSelectedHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():void} */
    this.f_$$fn__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$LambdaAdaptor__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$LambdaAdaptor__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onMenuSelected__() {
    {
      let $function = this.f_$$fn__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler_$LambdaAdaptor;
      $function();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuContext$OnMenuSelectedHandler$$LambdaAdaptor'));


OnMenuSelectedHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=MenuContext$OnMenuSelectedHandler$$LambdaAdaptor.js.map