/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext$impl');

let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');


/**
 * @interface
 * @extends {EventContext}
 */
class MenuContext {
  /**
   * @abstract
   * @param {?string} title
   * @return {void}
   * @public
   */
  m_setMainTitle__java_lang_String(title) {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @param {?string} iconName
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler) {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @param {?string} iconName
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String(title, iconName) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_menu_shared_extension_MenuContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(MenuContext, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuContext'));


MenuContext.$markImplementor(/** @type {Function} */ (MenuContext));


exports = MenuContext; 
//# sourceMappingURL=MenuContext.js.map