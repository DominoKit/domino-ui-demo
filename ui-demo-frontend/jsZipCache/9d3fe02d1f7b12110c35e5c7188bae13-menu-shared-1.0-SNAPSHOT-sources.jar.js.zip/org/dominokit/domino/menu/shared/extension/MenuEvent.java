package org.dominokit.domino.menu.shared.extension;

import org.dominokit.domino.api.shared.extension.DominoEvent;

public interface MenuEvent extends DominoEvent<MenuContext> {
}
