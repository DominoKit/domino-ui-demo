/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.menu.shared.extension.MenuEvent.$LambdaAdaptor');


// Re-exports the implementation.
var MenuEvent = goog.require('org.dominokit.domino.menu.shared.extension.MenuEvent$impl');
exports = MenuEvent;
 