package org.dominokit.domino.timepicker.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.forms.shared.extension.FormsEvent;
import org.dominokit.domino.timepicker.client.presenters.TimePickerPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class TimePickerPresenterListenerForFormsEvent implements DominoEventListener<FormsEvent> {
  @Override
  public void listen(FormsEvent event) {
    new TimePickerPresenterCommand().onPresenterReady(presenter -> presenter.onFormsEvent(event.context())).send();
  }
}
