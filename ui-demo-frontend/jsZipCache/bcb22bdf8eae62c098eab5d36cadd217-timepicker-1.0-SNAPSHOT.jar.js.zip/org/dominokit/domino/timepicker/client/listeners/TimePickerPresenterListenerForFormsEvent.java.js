/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.listeners.TimePickerPresenterListenerForFormsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.timepicker.client.listeners.TimePickerPresenterListenerForFormsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext');
const _FormsEvent = goog.require('org.dominokit.domino.forms.shared.extension.FormsEvent');
const _TimePickerPresenter = goog.require('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter');
const _TimePickerPresenterCommand = goog.require('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TimePickerPresenterListenerForFormsEvent = goog.require('org.dominokit.domino.timepicker.client.listeners.TimePickerPresenterListenerForFormsEvent$impl');
exports = TimePickerPresenterListenerForFormsEvent;
 