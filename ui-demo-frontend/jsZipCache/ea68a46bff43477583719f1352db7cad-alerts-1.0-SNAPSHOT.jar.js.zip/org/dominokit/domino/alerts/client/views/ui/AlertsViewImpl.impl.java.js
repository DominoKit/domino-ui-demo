/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.views.ui.AlertsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.alerts.client.views.ui.AlertsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AlertsView = goog.require('org.dominokit.domino.alerts.client.views.AlertsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Strong = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Strong$impl');
let Alert = goog.forwardDeclare('org.dominokit.domino.ui.alerts.Alert$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {AlertsView}
  */
class AlertsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'AlertsViewImpl()'.
   * @return {!AlertsViewImpl}
   * @public
   */
  static $create__() {
    AlertsViewImpl.$clinit();
    let $instance = new AlertsViewImpl();
    $instance.$ctor__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AlertsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(AlertsViewImpl.f_MODULE_NAME__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl, Class.$get(AlertsViewImpl)).m_asElement__());
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("Alerts").m_asElement__());
    this.m_basicAlerts___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl();
    this.m_customBackground___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl();
    this.m_dismissibleAlerts___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl();
    this.m_linksInAlerts___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicAlerts___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl() {
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("BASIC ALERTS", "Use one of the pre-customized alert types.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_success__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Well done! ")).m_appendChild__java_lang_String("You successfully read this important alert message.")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_info__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Heads up! ")).m_appendChild__java_lang_String("This alert needs your attention, but it's not super important.")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_warning__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Warning! ")).m_appendChild__java_lang_String("Better check yourself, you're not looking too good.")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_error__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Oh snap! ")).m_appendChild__java_lang_String("Change a few things up and try submitting again.")).m_asElement__());
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AlertsViewImpl.f_MODULE_NAME__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl, "basicAlerts").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_customBackground___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl() {
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("MATERIAL DESIGN ALERTS", "ou can use material design colors backgrounds").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id")).m_asElement__());
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AlertsViewImpl.f_MODULE_NAME__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl, "customBackgrounds").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_dismissibleAlerts___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl() {
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DISMISSIBLE ALERTS", "Add a close button to any alert by making it dismissible").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_warning__().m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id").m_dismissible__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id").m_dismissible__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id").m_dismissible__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id").m_dismissible__()).m_asElement__());
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AlertsViewImpl.f_MODULE_NAME__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl, "dismissibleAlerts").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_linksInAlerts___$p_org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl() {
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("LINKS IN ALERTS", "Use the appendLink utility class to quickly provide matching colored links within any alert.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_success__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Well done! ")).m_appendChild__java_lang_String("You successfully read ").m_appendChild__elemental2_dom_HTMLAnchorElement(/**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__java_lang_String("important alert message."), HtmlContentBuilder)).m_asElement__(), $Overlay)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_info__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Heads up! ")).m_appendChild__java_lang_String("This ").m_appendChild__elemental2_dom_HTMLAnchorElement(/**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__java_lang_String("alert needs your attention, "), HtmlContentBuilder)).m_asElement__(), $Overlay))).m_appendChild__java_lang_String("but it's not super important.")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_warning__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Warning! ")).m_appendChild__java_lang_String("Better check yourself, ").m_appendChild__elemental2_dom_HTMLAnchorElement(/**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__java_lang_String("you're not looking too good."), HtmlContentBuilder)).m_asElement__(), $Overlay)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_error__().m_appendChild__org_dominokit_domino_ui_Typography_Strong(Strong.m_of__java_lang_String("Oh snap! ")).m_appendChild__elemental2_dom_HTMLAnchorElement(/**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__java_lang_String("Change a few things up"), HtmlContentBuilder)).m_asElement__(), $Overlay))).m_appendChild__java_lang_String(" and try submitting again.")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Alert.m_create__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String("Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id ").m_appendChild__elemental2_dom_HTMLAnchorElement(/**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__java_lang_String("alert link."), HtmlContentBuilder)).m_asElement__(), $Overlay)))).m_asElement__());
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AlertsViewImpl.f_MODULE_NAME__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl, "linksInAlerts").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl() {
    this.f_element__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AlertsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AlertsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Class = goog.module.get('java.lang.Class$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Strong = goog.module.get('org.dominokit.domino.ui.Typography.Strong$impl');
    Alert = goog.module.get('org.dominokit.domino.ui.alerts.Alert$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AlertsViewImpl, $Util.$makeClassName('org.dominokit.domino.alerts.client.views.ui.AlertsViewImpl'));


/** @public {?string} @const */
AlertsViewImpl.f_MODULE_NAME__org_dominokit_domino_alerts_client_views_ui_AlertsViewImpl = "alerts";


AlertsView.$markImplementor(AlertsViewImpl);


exports = AlertsViewImpl; 
//# sourceMappingURL=AlertsViewImpl.js.map