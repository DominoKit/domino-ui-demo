/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.presenters.AlertsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.alerts.client.presenters.AlertsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let AlertsPresenter = goog.forwardDeclare('org.dominokit.domino.alerts.client.presenters.AlertsPresenter$impl');


/**
 * @extends {PresenterCommand<AlertsPresenter>}
  */
class AlertsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AlertsPresenterCommand()'.
   * @return {!AlertsPresenterCommand}
   * @public
   */
  static $create__() {
    AlertsPresenterCommand.$clinit();
    let $instance = new AlertsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_alerts_client_presenters_AlertsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AlertsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_alerts_client_presenters_AlertsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AlertsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AlertsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AlertsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.alerts.client.presenters.AlertsPresenterCommand'));




exports = AlertsPresenterCommand; 
//# sourceMappingURL=AlertsPresenterCommand.js.map