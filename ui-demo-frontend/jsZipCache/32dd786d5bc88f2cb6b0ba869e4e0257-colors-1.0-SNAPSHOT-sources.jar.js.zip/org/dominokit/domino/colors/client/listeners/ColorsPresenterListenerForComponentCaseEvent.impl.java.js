/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.listeners.ColorsPresenterListenerForComponentCaseEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.colors.client.listeners.ColorsPresenterListenerForComponentCaseEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ColorsPresenter = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenter$impl');
let ColorsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentCaseEvent>}
  */
class ColorsPresenterListenerForComponentCaseEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ColorsPresenterListenerForComponentCaseEvent()'.
   * @return {!ColorsPresenterListenerForComponentCaseEvent}
   * @public
   */
  static $create__() {
    ColorsPresenterListenerForComponentCaseEvent.$clinit();
    let $instance = new ColorsPresenterListenerForComponentCaseEvent();
    $instance.$ctor__org_dominokit_domino_colors_client_listeners_ColorsPresenterListenerForComponentCaseEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColorsPresenterListenerForComponentCaseEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_colors_client_listeners_ColorsPresenterListenerForComponentCaseEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(event) {
    ColorsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ColorsPresenter */ presenter) =>{
      presenter.m_onComponentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(event.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(/**@type {ComponentCaseEvent} */ ($Casts.$to(arg0, ComponentCaseEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColorsPresenterListenerForComponentCaseEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColorsPresenterListenerForComponentCaseEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ColorsPresenterListenerForComponentCaseEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ColorsPresenterCommand = goog.module.get('org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ColorsPresenterListenerForComponentCaseEvent, $Util.$makeClassName('org.dominokit.domino.colors.client.listeners.ColorsPresenterListenerForComponentCaseEvent'));


DominoEventListener.$markImplementor(ColorsPresenterListenerForComponentCaseEvent);


exports = ColorsPresenterListenerForComponentCaseEvent; 
//# sourceMappingURL=ColorsPresenterListenerForComponentCaseEvent.js.map