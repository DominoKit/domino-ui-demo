package org.dominokit.domino.colors.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface ColorsView extends View, DemoView{
}