package org.dominokit.domino.formsvalidations.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.forms.shared.extension.FormsExtensionPoint;
import org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class FormsValidationsPresenterContributionToFormsExtensionPoint implements Contribution<FormsExtensionPoint> {
  @Override
  public void contribute(FormsExtensionPoint extensionPoint) {
    new FormsValidationsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToFormsModule(extensionPoint.context())).send();
  }
}
