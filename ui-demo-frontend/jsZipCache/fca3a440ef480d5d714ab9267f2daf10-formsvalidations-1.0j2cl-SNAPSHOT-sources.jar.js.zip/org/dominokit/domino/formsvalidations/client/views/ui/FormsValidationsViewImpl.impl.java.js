/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const FormsValidationsView = goog.require('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$4$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let CheckBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox$impl');
let Radio = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio$impl');
let RadioGroup = goog.forwardDeclare('org.dominokit.domino.ui.forms.RadioGroup$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextArea = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {FormsValidationsView}
  */
class FormsValidationsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
    /** @public {Card} */
    this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'FormsValidationsViewImpl()'.
   * @return {!FormsValidationsViewImpl}
   * @public
   */
  static $create__() {
    FormsValidationsViewImpl.$clinit();
    let $instance = new FormsValidationsViewImpl();
    $instance.$ctor__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsValidationsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("FIELDS DECORATION").m_asElement__());
    this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("HELPER TEXTS");
    this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("ADDONS");
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("WORD COUNTER");
    this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = Card.m_create__java_lang_String("VALIDATIONS");
    this.m_initHelperText___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initIcons___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initWordCount___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.m_initValidations___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl();
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_helperText__()).m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_addons__()).m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_wordCount__()).m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_validations__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initHelperText___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_helperTextCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Text Box").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Task Name").m_setHelperText__java_lang_String("Each task should have unique name."), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_hr__().m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Text Area").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("Description").m_setHelperText__java_lang_String("Less than 100 words"), TextArea)).m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_hr__().m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Select").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {Select} */ ($Casts.$to(Select.m_create__java_lang_String("Task type").m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("-- Select a type --")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("Story")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("Bugfix")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("Hotfix")).m_setHelperText__java_lang_String("Helps with tracking the issues"), Select)).m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_hr__().m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Checkbox").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {CheckBox} */ ($Casts.$to(CheckBox.m_create__java_lang_String("I want to receive an news about this task").m_setHelperText__java_lang_String("news will be sent via email"), CheckBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_hr__().m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Radio").m_asElement__()).m_appendContent__elemental2_dom_Node(RadioGroup.m_create__java_lang_String__java_lang_String("estimation", "Estimation").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("storyPoint", "Story points")).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("hours", "Effective hours")).m_horizontal__().m_setHelperText__java_lang_String("Helps with sprint reports").m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_hr__().m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Switch").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {SwitchButton} */ ($Casts.$to(SwitchButton.m_create__java_lang_String("Notifications: ").m_setHelperText__java_lang_String("Notifications will be sent via the system"), SwitchButton)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initIcons___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    let cancel = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cancel__().m_asElement__();
    let username = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Username").m_setLeftAddon__elemental2_dom_Element(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_account_circle__().m_asElement__()), TextBox)).m_setRightAddon__elemental2_dom_Element(cancel), TextBox));
    cancel.style.cursor = "pointer";
    cancel.addEventListener("click", new $LambdaAdaptor$1(((/** Event */ evt) =>{
      username.m_clear__();
    })));
    let showIcon = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_remove_red_eye__().m_asElement__();
    let password = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_password__java_lang_String("Password").m_setLeftAddon__elemental2_dom_Element(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_https__().m_asElement__()), TextBox)).m_setRightAddon__elemental2_dom_Element(showIcon), TextBox));
    showIcon.style.cursor = "pointer";
    showIcon.addEventListener("mousedown", new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      /**@type {HTMLInputElement} */ ($Casts.$to(password.m_getInputElement__(), $Overlay)).type = "text";
    })));
    showIcon.addEventListener("mouseup", new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      /**@type {HTMLInputElement} */ ($Casts.$to(password.m_getInputElement__(), $Overlay)).type = "password";
    })));
    this.f_iconsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendContent__elemental2_dom_Node(username.m_asElement__()).m_appendContent__elemental2_dom_Node(password.m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("Description").m_setLeftAddon__elemental2_dom_Element(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__().m_asElement__()), TextArea)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initWordCount___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Name").m_setLength__int(10), TextBox)).m_asElement__());
    this.f_countsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("Description").m_setLength__int(100), TextArea)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initValidations___$p_org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    let name = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Name").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox));
    let surename = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Surename").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox));
    let email = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Email").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox));
    let gender = RadioGroup.m_create__java_lang_String__java_lang_String("gender", "Gender").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("male", "Male")).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("female", "Female")).m_horizontal__().m_setRequired__boolean(true).m_setAutoValidation__boolean(true);
    let description = /**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("Description").m_setRequired__boolean(true), TextArea)).m_setAutoValidation__boolean(true), TextArea));
    let password = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_password__java_lang_String("Password").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox));
    let termsAndConditions = /**@type {CheckBox} */ ($Casts.$to(CheckBox.m_create__java_lang_String("I have read and accept the terms").m_setRequired__boolean(true), CheckBox)).m_setAutoValidation__boolean(true);
    let language = /**@type {Select} */ ($Casts.$to(Select.m_create__java_lang_String("Language").m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("english", "English")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("france", "France")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("arabic", "Arabic")).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select));
    this.f_validationsCard__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_.m_appendContent__elemental2_dom_Node(name.m_asElement__()).m_appendContent__elemental2_dom_Node(surename.m_asElement__()).m_appendContent__elemental2_dom_Node(email.m_asElement__()).m_appendContent__elemental2_dom_Node(gender.m_asElement__()).m_appendContent__elemental2_dom_Node(description.m_asElement__()).m_appendContent__elemental2_dom_Node(password.m_asElement__()).m_appendContent__elemental2_dom_Node(language.m_asElement__()).m_appendContent__elemental2_dom_Node(termsAndConditions.m_asElement__()).m_appendContent__elemental2_dom_Node(Button.m_createPrimary__java_lang_String("REGISTER").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt) =>{
      if (!!(+!!(+!!(+!!(+!!(+!!(+!!(+name.m_validate__() & +surename.m_validate__()) & +email.m_validate__()) & +gender.m_validate__()) & +description.m_validate__()) & +password.m_validate__()) & +language.m_validate__()) & +termsAndConditions.m_validate__())) {
        name.m_clear__();
        surename.m_clear__();
        email.m_clear__();
        gender.m_clear__();
        description.m_clear__();
        password.m_clear__();
        language.m_clear__();
        termsAndConditions.m_clear__();
      }
    }))).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl() {
    this.f_element__org_dominokit_domino_formsvalidations_client_views_ui_FormsValidationsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsValidationsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsValidationsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsValidationsViewImpl.$clinit = function() {};
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.formsvalidations.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl.$LambdaAdaptor$4$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    CheckBox = goog.module.get('org.dominokit.domino.ui.forms.CheckBox$impl');
    Radio = goog.module.get('org.dominokit.domino.ui.forms.Radio$impl');
    RadioGroup = goog.module.get('org.dominokit.domino.ui.forms.RadioGroup$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextArea = goog.module.get('org.dominokit.domino.ui.forms.TextArea$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsValidationsViewImpl, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.views.ui.FormsValidationsViewImpl'));


FormsValidationsView.$markImplementor(FormsValidationsViewImpl);


exports = FormsValidationsViewImpl; 
//# sourceMappingURL=FormsValidationsViewImpl.js.map