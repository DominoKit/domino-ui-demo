/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext');
const _$1 = goog.require('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter.$1');
const _FormsValidationsView = goog.require('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var FormsValidationsPresenter = goog.require('org.dominokit.domino.formsvalidations.client.presenters.FormsValidationsPresenter$impl');
exports = FormsValidationsPresenter;
 