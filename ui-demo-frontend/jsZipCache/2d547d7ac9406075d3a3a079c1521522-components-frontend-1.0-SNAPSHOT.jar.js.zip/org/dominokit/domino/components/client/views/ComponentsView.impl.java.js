/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.views.ComponentsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.views.ComponentsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.components.client.views.ComponentsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ContentView}
 */
class ComponentsView {
  /**
   * @param {?function():Content} fn
   * @return {ComponentsView}
   * @public
   */
  static $adapt(fn) {
    ComponentsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ContentView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_components_client_views_ComponentsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_components_client_views_ComponentsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_components_client_views_ComponentsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsView.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.components.client.views.ComponentsView.$LambdaAdaptor$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentsView, $Util.$makeClassName('org.dominokit.domino.components.client.views.ComponentsView'));


ComponentsView.$markImplementor(/** @type {Function} */ (ComponentsView));


exports = ComponentsView; 
//# sourceMappingURL=ComponentsView.js.map