package org.dominokit.domino.components.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;
import org.dominokit.domino.components.client.listeners.ComponentsPresenterListenerForComponentCaseEvent;
import org.dominokit.domino.components.client.presenters.ComponentsPresenter;
import org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ComponentsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(ComponentsPresenter.class.getCanonicalName(), ComponentsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new ComponentsPresenter();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(ComponentsPresenterCommand.class.getCanonicalName(), ComponentsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentCaseEvent.class, new ComponentsPresenterListenerForComponentCaseEvent());
  }
}
