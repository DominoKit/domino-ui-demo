package org.dominokit.domino.components.client.views;

import org.dominokit.domino.api.client.mvp.view.ContentView;

public interface ComponentsView extends ContentView {
}