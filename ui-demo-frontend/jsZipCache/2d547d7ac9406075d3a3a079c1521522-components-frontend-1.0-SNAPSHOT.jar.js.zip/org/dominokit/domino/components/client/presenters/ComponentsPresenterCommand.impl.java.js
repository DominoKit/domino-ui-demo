/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ComponentsPresenter = goog.forwardDeclare('org.dominokit.domino.components.client.presenters.ComponentsPresenter$impl');


/**
 * @extends {PresenterCommand<ComponentsPresenter>}
  */
class ComponentsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentsPresenterCommand()'.
   * @return {!ComponentsPresenterCommand}
   * @public
   */
  static $create__() {
    ComponentsPresenterCommand.$clinit();
    let $instance = new ComponentsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_components_client_presenters_ComponentsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_client_presenters_ComponentsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand'));




exports = ComponentsPresenterCommand; 
//# sourceMappingURL=ComponentsPresenterCommand.js.map