/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.ComponentsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.ComponentsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ComponentsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentsClientModule()'.
   * @return {!ComponentsClientModule}
   * @public
   */
  static $create__() {
    ComponentsClientModule.$clinit();
    let $instance = new ComponentsClientModule();
    $instance.$ctor__org_dominokit_domino_components_client_ComponentsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_client_ComponentsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ComponentsClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_.m_info__java_lang_String("Initializing Components frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_() {
    return (ComponentsClientModule.$clinit(), ComponentsClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_(value) {
    (ComponentsClientModule.$clinit(), ComponentsClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ComponentsClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ComponentsClientModule));
  }
  
  
};

$Util.$setClassMetadata(ComponentsClientModule, $Util.$makeClassName('org.dominokit.domino.components.client.ComponentsClientModule'));


/** @private {Logger} */
ComponentsClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsClientModule_;




exports = ComponentsClientModule; 
//# sourceMappingURL=ComponentsClientModule.js.map