/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.views.ui.InfoBoxViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.infobox.client.views.ui.InfoBoxViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const InfoBoxView = goog.require('org.dominokit.domino.infobox.client.views.InfoBoxView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.infobox.client.views.CodeResource$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let Counter = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter$impl');
let CountHandler = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let InfoBox = goog.forwardDeclare('org.dominokit.domino.ui.infoboxes.InfoBox$impl');
let HoverEffect = goog.forwardDeclare('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {InfoBoxView}
  */
class InfoBoxViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_;
    /** @public {Counter} */
    this.f_counter__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'InfoBoxViewImpl()'.
   * @return {!InfoBoxViewImpl}
   * @public
   */
  static $create__() {
    InfoBoxViewImpl.$clinit();
    let $instance = new InfoBoxViewImpl();
    $instance.$ctor__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InfoBoxViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_restartCounters__() {
    this.f_counter__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.m_startCounting__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.m_basicInfoBoxes___$p_org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl();
    this.m_hoverZoomEffect___$p_org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl();
    this.m_rightAligned___$p_org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicInfoBoxes___$p_org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl() {
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("BASIC INFO BOX AND COUNTERS", "Simple info box without effects, and counters to update the value.").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_shopping_cart__(), "NEW ORDERS", "125").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_face__(), "NEW MEMBERS", "257").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_shopping_cart__(), "BOOKMARKS", "117").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_favorite__(), "LIKES", "1432").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__())).m_asElement__());
    let new_orders = InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_shopping_cart__(), "NEW ORDERS", "0");
    let new_members = InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_face__(), "NEW MEMBERS", "0");
    let bookmarks = InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_shopping_cart__(), "BOOKMARKS", "0");
    let likes = InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_favorite__(), "LIKES", "0");
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(new_orders.m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(new_members.m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(bookmarks.m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(likes.m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__())).m_asElement__());
    this.f_counter__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_ = Counter.m_countFrom__int(0).m_countTo__int(125).m_every__int(40).m_incrementBy__int(5).m_onCount__org_dominokit_domino_ui_counter_Counter_CountHandler(CountHandler.$adapt(((/** number */ count) =>{
      new_orders.m_getValueElement__().textContent = Integer.m_toString__int(count);
      new_members.m_getValueElement__().textContent = Integer.m_toString__int(count);
      bookmarks.m_getValueElement__().textContent = Integer.m_toString__int(count);
      likes.m_getValueElement__().textContent = Integer.m_toString__int(count);
    })));
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_basicInfoBoxes__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_hoverZoomEffect___$p_org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl() {
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("HOVER EFFECTS", "Apply Zoom or Expand effects on hover").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__(), "MESSAGES", "15").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_devices__(), "CPU USAGE", "92%").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_alarm__(), "ALARM", "07:00 AM").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_gps_fixed__(), "LOCATION", "Jordan").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_equalizer__(), "BOUNCE RATE", "62%").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_flight_takeoff__(), "FLIGHT", "02:59 PM").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_battery_charging_full__(), "BATTERY", "Charging").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_brightness_low__(), "BRIGHTNESS RATE", "40%").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_hoverZoomEffect__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_rightAligned___$p_org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl() {
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("ICON ALIGN AND COUNTERS", "Change icon position, and update info value with counters").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__(), "MESSAGES", "15").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_devices__(), "CPU USAGE", "92%").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_alarm__(), "ALARM", "07:00 AM").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_gps_fixed__(), "LOCATION", "Jordan").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_equalizer__(), "BOUNCE RATE", "62%").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_flight_takeoff__(), "FLIGHT", "02:59 PM").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_battery_charging_full__(), "BATTERY", "Charging").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(InfoBox.m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_brightness_low__(), "BRIGHTNESS RATE", "40%").m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_flip__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_rightAligned__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl() {
    this.f_element__org_dominokit_domino_infobox_client_views_ui_InfoBoxViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InfoBoxViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InfoBoxViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InfoBoxViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    CodeResource = goog.module.get('org.dominokit.domino.infobox.client.views.CodeResource$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    Counter = goog.module.get('org.dominokit.domino.ui.counter.Counter$impl');
    CountHandler = goog.module.get('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    InfoBox = goog.module.get('org.dominokit.domino.ui.infoboxes.InfoBox$impl');
    HoverEffect = goog.module.get('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InfoBoxViewImpl, $Util.$makeClassName('org.dominokit.domino.infobox.client.views.ui.InfoBoxViewImpl'));


InfoBoxView.$markImplementor(InfoBoxViewImpl);


exports = InfoBoxViewImpl; 
//# sourceMappingURL=InfoBoxViewImpl.js.map