/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.InfoBoxClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.infobox.client.InfoBoxClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class InfoBoxClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'InfoBoxClientModule()'.
   * @return {!InfoBoxClientModule}
   * @public
   */
  static $create__() {
    InfoBoxClientModule.$clinit();
    let $instance = new InfoBoxClientModule();
    $instance.$ctor__org_dominokit_domino_infobox_client_InfoBoxClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InfoBoxClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_infobox_client_InfoBoxClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    InfoBoxClientModule.$f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_.m_info__java_lang_String("Initializing InfoBox frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_() {
    return (InfoBoxClientModule.$clinit(), InfoBoxClientModule.$f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_(value) {
    (InfoBoxClientModule.$clinit(), InfoBoxClientModule.$f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InfoBoxClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InfoBoxClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InfoBoxClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    InfoBoxClientModule.$f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(InfoBoxClientModule));
  }
  
  
};

$Util.$setClassMetadata(InfoBoxClientModule, $Util.$makeClassName('org.dominokit.domino.infobox.client.InfoBoxClientModule'));


/** @private {Logger} */
InfoBoxClientModule.$f_LOGGER__org_dominokit_domino_infobox_client_InfoBoxClientModule_;




exports = InfoBoxClientModule; 
//# sourceMappingURL=InfoBoxClientModule.js.map