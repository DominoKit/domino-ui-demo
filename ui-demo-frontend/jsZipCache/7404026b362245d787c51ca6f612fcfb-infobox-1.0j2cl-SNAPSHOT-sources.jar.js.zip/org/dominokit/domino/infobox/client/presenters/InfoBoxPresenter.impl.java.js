/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter.$1$impl');
let InfoBoxView = goog.forwardDeclare('org.dominokit.domino.infobox.client.views.InfoBoxView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<InfoBoxView>}
  */
class InfoBoxPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'InfoBoxPresenter()'.
   * @return {!InfoBoxPresenter}
   * @public
   */
  static $create__() {
    InfoBoxPresenter.$clinit();
    let $instance = new InfoBoxPresenter();
    $instance.$ctor__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InfoBoxPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter_() {
    return (InfoBoxPresenter.$clinit(), InfoBoxPresenter.$f_LOGGER__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter_(value) {
    (InfoBoxPresenter.$clinit(), InfoBoxPresenter.$f_LOGGER__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InfoBoxPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InfoBoxPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InfoBoxPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    InfoBoxPresenter.$f_LOGGER__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(InfoBoxPresenter));
  }
  
  
};

$Util.$setClassMetadata(InfoBoxPresenter, $Util.$makeClassName('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter'));


/** @private {Logger} */
InfoBoxPresenter.$f_LOGGER__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenter_;




exports = InfoBoxPresenter; 
//# sourceMappingURL=InfoBoxPresenter.js.map