/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ImportSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');


/**
 * @interface
 * @extends {IsElement<HTMLElement>}
 */
class ImportSection {
  /**
   * @abstract
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_validate__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    IsElement.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_formsamples_client_views_ui_section_ImportSection = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_formsamples_client_views_ui_section_ImportSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_formsamples_client_views_ui_section_ImportSection;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ImportSection.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ImportSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection'));


ImportSection.$markImplementor(/** @type {Function} */ (ImportSection));


exports = ImportSection; 
//# sourceMappingURL=ImportSection.js.map