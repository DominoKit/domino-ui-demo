/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ToIntFunction = goog.forwardDeclare('java.util.function.ToIntFunction$impl');
let Constants = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.$LambdaAdaptor$7$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let PaymentScheduleItem = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.PaymentScheduleItem$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Collapsible = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Radio = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio$impl');
let RadioGroup = goog.forwardDeclare('org.dominokit.domino.ui.forms.RadioGroup$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let ValidationResult = goog.forwardDeclare('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class PaymentScheduleSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_validationMessageElement__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {TextBox} */
    this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {Select<?string>} */
    this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {TextBox} */
    this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {RadioGroup} */
    this.f_paymentScheduleRadioGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {ListGroup<PaymentScheduleItem>} */
    this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {Button} */
    this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {Collapsible} */
    this.f_valuesContainerCollapsible__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {Card} */
    this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
    /** @public {Row} */
    this.f_paymentSchedulerListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'PaymentScheduleSection()'.
   * @return {!PaymentScheduleSection}
   * @public
   */
  static $create__() {
    PaymentScheduleSection.$clinit();
    let $instance = new PaymentScheduleSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PaymentScheduleSection()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection();
    this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("No. Of Days").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_looks_one__()), TextBox)).m_setHelperText__java_lang_String(Constants.f_NUMBERS_ONLY__org_dominokit_domino_formsamples_client_views_ui_Constants), TextBox))), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), TextBox)).m_setAutoValidation__boolean(true), TextBox));
    let numberOfDaysColumn = /**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), Column)).m_collapse__(), Column));
    this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("After")).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Presentation Of Documents", "Presentation Of Documents"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Bill Of Lading Date", "Bill Of Lading Date"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Commercial Invoice", "Commercial Invoice"))).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_redo__()).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), Select)).m_setAutoValidation__boolean(true);
    let paymentScheduleAfterColumn = /**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), Column)).m_collapse__(), Column));
    this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String("Percentage")), TextBox)).m_setHelperText__java_lang_String("Numbers only"), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_value__java_lang_Object("100"), TextBox)).m_setRequired__boolean(true), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas", "fa-percent", "fa-sm"], j_l_String)))), TextBox)).m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(Validator.$adapt((() =>{
      let percentage = Integer.m_parseInt__java_lang_String(this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getValue__());
      let remainingPercentage = this.m_remainingPercentage___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection();
      if (percentage > 0 && percentage <= remainingPercentage) {
        return ValidationResult.m_valid__();
      }
      return ValidationResult.m_invalid__java_lang_String("Maximum allowed percentage is " + remainingPercentage);
    }))), TextBox));
    this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {ListGroup<PaymentScheduleItem>} */ (ListGroup.m_create__()).m_setSelectable__boolean(false);
    this.f_paymentScheduleRadioGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = RadioGroup.m_create__java_lang_String("paymentSchedule").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("SIGHT", "Payment Sight").m_withGap__().m_check__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("NEGOTIATION", "Negotiation").m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("ACCEPTANCE", "Acceptance at").m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("DEFERRED", "Deferred Payment").m_withGap__()).m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** Radio */ selectedRadio) =>{
      if (j_l_String.m_equals__java_lang_String__java_lang_Object(selectedRadio.m_getValue__(), "DEFERRED") || j_l_String.m_equals__java_lang_String__java_lang_Object(selectedRadio.m_getValue__(), "ACCEPTANCE")) {
        numberOfDaysColumn.m_expand__();
        paymentScheduleAfterColumn.m_expand__();
        this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_setRequired__boolean(true);
        this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_setRequired__boolean(true);
      } else {
        numberOfDaysColumn.m_collapse__();
        paymentScheduleAfterColumn.m_collapse__();
        this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_setRequired__boolean(false);
        this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_setRequired__boolean(false);
      }
    }))).m_horizontal__();
    this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = Card.m_create__java_lang_String("Payment Schedule *");
    this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_add__()).m_setContent__java_lang_String("ADD"), Button)).m_linkify__(), Button)).m_style__().m_setMarginTop__java_lang_String("-10px").m_get__(), Button));
    this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getHeaderBar__().m_appendChild__elemental2_dom_Node(/**@type {Button} */ ($Casts.$to(this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$6(((/** Event */ evt) =>{
      if (this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_validate__().m_isValid__()) {
        this.m_addPaymentSchedule___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection();
      }
    }))), Button)).m_asElement__());
    let paymentTypeRow = Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_paymentScheduleRadioGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), Column)));
    let paymentValuesRow = /**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(numberOfDaysColumn), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(paymentScheduleAfterColumn);
    let valuesContainer = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__org_jboss_gwt_elemento_core_IsElement(paymentTypeRow), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(paymentValuesRow), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_valuesContainerCollapsible__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = Collapsible.m_create__elemental2_dom_HTMLElement(valuesContainer).m_expand__();
    this.f_paymentSchedulerListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = Row.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.appendChild(this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_appendChild__elemental2_dom_Node(valuesContainer).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_paymentSchedulerListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_), Column))).m_collapse__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addPaymentSchedule___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection() {
    let item = PaymentScheduleItem.$create__();
    item.m_setType__java_lang_String(this.f_paymentScheduleRadioGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getValue__());
    if (this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_isRequired__()) {
      item.m_setAfterIncident__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getValue__(), j_l_String)));
    }
    if (this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_isRequired__()) {
      item.m_setNumberOfDays__int(Integer.m_parseInt__java_lang_String(this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getValue__()));
    }
    item.m_setPercentage__int(Integer.m_parseInt__java_lang_String(this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getValue__()));
    let listItem = this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_addItem__java_lang_Object__java_lang_String(item, this.f_paymentScheduleRadioGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getSelectedRadio__().m_getLabel__());
    let delete$1$ = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_delete__();
    delete$1$.m_asElement__().addEventListener("click", new $LambdaAdaptor$7(((/** Event */ evt1) =>{
      this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_removeItem__org_dominokit_domino_ui_lists_ListItem(listItem);
      this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_setValue__java_lang_Object(this.m_remainingPercentage___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection() + "");
      this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_expand__();
      this.f_valuesContainerCollapsible__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_expand__();
      if (this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getAllValues__().size() == 0) {
        this.f_paymentSchedulerListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_collapse__();
      }
      this.m_revalidate__();
    })));
    listItem.m_appendChild__elemental2_dom_Node(delete$1$.m_style__().m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_setMarginTop__java_lang_String("-3px").m_setMarginLeft__java_lang_String("10px").m_asElement__());
    if (this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_isRequired__()) {
      listItem.m_appendChild__elemental2_dom_Node(Badge.m_create__java_lang_String(item.m_getNumberOfDays__() + " days after " + j_l_String.m_valueOf__java_lang_Object(j_l_String.m_toLowerCase__java_lang_String(item.m_getAfterIncident__()))).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_style__().m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_asElement__());
    }
    listItem.m_appendChild__elemental2_dom_Node(Badge.m_create__java_lang_String(item.m_getPercentage__() + "%").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_style__().m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_asElement__());
    let remainingPercentage = this.m_remainingPercentage___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection();
    if (remainingPercentage == 0) {
      this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_collapse__();
      this.f_valuesContainerCollapsible__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_collapse__();
    } else {
      if (this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_isCollapsed__()) {
        this.f_addButton__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_expand__();
      }
      if (this.f_valuesContainerCollapsible__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_isCollapsed__()) {
        this.f_valuesContainerCollapsible__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_expand__();
      }
      this.f_percentageTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_setValue__java_lang_Object(remainingPercentage + "");
    }
    this.f_numberOfDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_clear__();
    this.f_paymentScheduleAfterSelect__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_clear__();
    this.f_paymentSchedulerListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_expand__();
    this.m_revalidate__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_) && this.m_remainingPercentage___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection() == 0) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_, true, false);
      this.m_markWithValidationMessage__boolean_$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection(true);
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_remainingPercentage___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection() == 0;
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_, valid);
    this.m_markWithValidationMessage__boolean_$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection(valid);
    return valid;
  }
  
  /**
   * @param {boolean} valid
   * @return {void}
   * @public
   */
  m_markWithValidationMessage__boolean_$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection(valid) {
    if (!valid) {
      this.f_paymentScheduleCard__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_validationMessageElement__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_);
    } else {
      this.f_validationMessageElement__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.remove();
    }
  }
  
  /**
   * @return {number}
   * @public
   */
  m_remainingPercentage___$p_org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection() {
    let allValues = this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getAllValues__();
    return 100 - allValues.m_stream__().m_mapToInt__java_util_function_ToIntFunction(ToIntFunction.$adapt(((/** PaymentScheduleItem */ arg0) =>{
      return arg0.m_getPercentage__();
    }))).m_sum__();
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    letterOfCredit.m_getPaymentSchedule__().addAll(this.f_paymentScheduleItemsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_.m_getAllValues__());
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection() {
    this.f_validationMessageElement__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_small__().m_textContent__java_lang_String("Total payment schedules should be 100%"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_PaymentScheduleSection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PaymentScheduleSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PaymentScheduleSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaymentScheduleSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ToIntFunction = goog.module.get('java.util.function.ToIntFunction$impl');
    Constants = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.$LambdaAdaptor$7$impl');
    PaymentScheduleItem = goog.module.get('org.dominokit.domino.formsamples.shared.model.PaymentScheduleItem$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Collapsible = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Radio = goog.module.get('org.dominokit.domino.ui.forms.Radio$impl');
    RadioGroup = goog.module.get('org.dominokit.domino.ui.forms.RadioGroup$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    ValidationResult = goog.module.get('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ListGroup = goog.module.get('org.dominokit.domino.ui.lists.ListGroup$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Validator = goog.module.get('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PaymentScheduleSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection'));


ImportSection.$markImplementor(PaymentScheduleSection);


exports = PaymentScheduleSection; 
//# sourceMappingURL=PaymentScheduleSection.js.map