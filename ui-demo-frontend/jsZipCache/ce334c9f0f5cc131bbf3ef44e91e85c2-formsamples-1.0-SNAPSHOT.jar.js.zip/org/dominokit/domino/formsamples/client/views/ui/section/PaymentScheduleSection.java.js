/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _ToIntFunction = goog.require('java.util.function.ToIntFunction');
const _Constants = goog.require('org.dominokit.domino.formsamples.client.views.ui.Constants');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _$LambdaAdaptor$6 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.$LambdaAdaptor$6');
const _$LambdaAdaptor$7 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection.$LambdaAdaptor$7');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _PaymentScheduleItem = goog.require('org.dominokit.domino.formsamples.shared.model.PaymentScheduleItem');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Collapsible = goog.require('org.dominokit.domino.ui.collapsible.Collapsible');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _Radio = goog.require('org.dominokit.domino.ui.forms.Radio');
const _RadioGroup = goog.require('org.dominokit.domino.ui.forms.RadioGroup');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _ValidationResult = goog.require('org.dominokit.domino.ui.forms.validations.ValidationResult');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ListGroup = goog.require('org.dominokit.domino.ui.lists.ListGroup');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Validator = goog.require('org.dominokit.domino.ui.utils.HasValidation.Validator');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PaymentScheduleSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection$impl');
exports = PaymentScheduleSection;
 