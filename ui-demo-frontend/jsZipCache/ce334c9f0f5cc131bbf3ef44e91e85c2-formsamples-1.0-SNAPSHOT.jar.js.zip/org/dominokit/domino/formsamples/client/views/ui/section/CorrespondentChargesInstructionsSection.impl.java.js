/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let CorporateAccountsSelect = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
let CorporateAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class CorrespondentChargesInstructionsSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {SwitchButton} */
    this.f_correspondentChargesSwitch__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_;
    /** @public {CorporateAccountsSelect} */
    this.f_corporateAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_;
    /** @public {Card} */
    this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'CorrespondentChargesInstructionsSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {!CorrespondentChargesInstructionsSection}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    CorrespondentChargesInstructionsSection.$clinit();
    let $instance = new CorrespondentChargesInstructionsSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CorrespondentChargesInstructionsSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection();
    this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_ = Card.m_create__java_lang_String__java_lang_String("Correspondent Charges Instructions", "").m_collapse__();
    this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_bodyStyle__().m_setPaddingTop__java_lang_String("40px");
    this.f_correspondentChargesSwitch__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_ = /**@type {SwitchButton} */ ($Casts.$to(SwitchButton.m_create__().m_style__().m_setMarginBottom__java_lang_String("0px").m_get__(), SwitchButton)).m_setOnTitle__java_lang_String("Applicant").m_setOffTitle__java_lang_String("Beneficiary").m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_expand__();
      } else {
        this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_correspondentChargesSwitch__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_asElement__());
    this.f_corporateAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_ = CorporateAccountsSelect.m_create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile("Charges Instructions", corporateProfile);
    /**@type {Select<CorporateAccount>} */ ($Casts.$to(this.f_corporateAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_getAccountSelect__().m_dropup__().m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<CorporateAccount> */ option) =>{
      this.m_revalidate__();
    })));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.appendChild(this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_corporateAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let chargesInstructions = letterOfCredit.m_getChargesInstructions__();
    chargesInstructions.m_setOutsideCountryChargesOn__java_lang_String(Boolean.m_booleanValue__java_lang_Boolean(this.f_correspondentChargesSwitch__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_getValue__()) ? "APPLICANT" : "BENEFICIARIES");
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_) && this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_correspondentChargesInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_, true, false);
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection() {
    return !Boolean.m_booleanValue__java_lang_Boolean(this.f_correspondentChargesSwitch__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_getValue__()) || this.f_corporateAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_.m_getAccountSelect__().m_validate__().m_isValid__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CorrespondentChargesInstructionsSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CorrespondentChargesInstructionsSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CorrespondentChargesInstructionsSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CorrespondentChargesInstructionsSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    CorporateAccountsSelect = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CorrespondentChargesInstructionsSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection'));


ImportSection.$markImplementor(CorrespondentChargesInstructionsSection);


exports = CorrespondentChargesInstructionsSection; 
//# sourceMappingURL=CorrespondentChargesInstructionsSection.js.map