/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let CurrenciesComponent = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.$LambdaAdaptor$4$impl');
let CurrencyData = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CurrencyData$impl');
let LcAmount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcAmount$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let CheckBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let ValidationResult = goog.forwardDeclare('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class CreditAmountAndToleranceSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_amountFieldTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
    /** @public {Select<CurrencyData>} */
    this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
    /** @public {TextBox} */
    this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
    /** @public {CheckBox} */
    this.f_maximumCheckBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'CreditAmountAndToleranceSection(List)'.
   * @param {List<CurrencyData>} currencies
   * @return {!CreditAmountAndToleranceSection}
   * @public
   */
  static $create__java_util_List(currencies) {
    CreditAmountAndToleranceSection.$clinit();
    let $instance = new CreditAmountAndToleranceSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection__java_util_List(currencies);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CreditAmountAndToleranceSection(List)'.
   * @param {List<CurrencyData>} currencies
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection__java_util_List(currencies) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.appendChild(BlockHeader.m_create__java_lang_String("Credit Amount And Tolerance *").m_asElement__());
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = Card.m_create__();
    let currenciesComponent = CurrenciesComponent.m_create__().m_setCurrencies__java_util_List(currencies);
    this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    this.f_amountFieldTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(currenciesComponent.m_getAmountField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox));
    this.f_amountFieldTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$3(((/** Event */ evt) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    })));
    this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = /**@type {Select<CurrencyData>} */ ($Casts.$to(/**@type {Select<CurrencyData>} */ ($Casts.$to(currenciesComponent.m_getCurrencySelect__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<CurrencyData> */ option) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    })));
    this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String("Tolerance")), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(Validator.$adapt((() =>{
      return this.m_validateTolerance___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    }))), TextBox));
    this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$4(((/** Event */ evt$1$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    })));
    this.f_maximumCheckBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = CheckBox.m_create__java_lang_String("Maximum");
    this.f_maximumCheckBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_collapse__();
        this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_setRequired__boolean(false);
      } else {
        this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_expand__();
        this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_setRequired__boolean(true);
        this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_setAutoValidation__boolean(true);
        this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_validate__();
      }
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection();
    })));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.appendChild(/**@type {Card} */ ($Casts.$to(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_amountFieldTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_maximumCheckBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas", "fa-percent", "fa-sm"], j_l_String))))), Column)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_) && this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_validate__().m_isValid__()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_, true, false);
    }
  }
  
  /**
   * @return {ValidationResult}
   * @public
   */
  m_validateTolerance___$p_org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection() {
    if (Boolean.m_booleanValue__java_lang_Boolean(this.f_maximumCheckBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getValue__())) {
      return ValidationResult.m_valid__();
    }
    return CustomElements.m_validatePercent__org_dominokit_domino_ui_forms_TextBox(this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_, valid);
    return valid;
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let creditAmount = letterOfCredit.m_getCreditAmount__();
    creditAmount.m_setMaximum__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_maximumCheckBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getValue__()));
    if (!creditAmount.m_isMaximum__()) {
      creditAmount.m_setTolerance__double(Double.m_parseDouble__java_lang_String(this.f_toleranceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getValue__()));
    }
    let lcAmount = LcAmount.$create__();
    lcAmount.m_setCurrency__java_lang_String(/**@type {CurrencyData} */ ($Casts.$to(this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getValue__(), CurrencyData)).m_getCurrencyCode__());
    let amount = Number.parseFloat(this.f_amountFieldTextBox__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_.m_getValue__());
    lcAmount.m_setValue__double(amount);
    creditAmount.m_setLcAmount__org_dominokit_domino_formsamples_shared_model_LcAmount(lcAmount);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_CreditAmountAndToleranceSection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CreditAmountAndToleranceSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CreditAmountAndToleranceSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CreditAmountAndToleranceSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CurrenciesComponent = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.$LambdaAdaptor$4$impl');
    CurrencyData = goog.module.get('org.dominokit.domino.formsamples.shared.model.CurrencyData$impl');
    LcAmount = goog.module.get('org.dominokit.domino.formsamples.shared.model.LcAmount$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    CheckBox = goog.module.get('org.dominokit.domino.ui.forms.CheckBox$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    ValidationResult = goog.module.get('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Validator = goog.module.get('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CreditAmountAndToleranceSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection'));


ImportSection.$markImplementor(CreditAmountAndToleranceSection);


exports = CreditAmountAndToleranceSection; 
//# sourceMappingURL=CreditAmountAndToleranceSection.js.map