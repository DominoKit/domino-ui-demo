/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.AccountDetails.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetails$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CorporateAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class AccountDetails extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_accountNumberHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_;
    /** @public {TextBox} */
    this.f_ibanHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_;
    /** @public {TextBox} */
    this.f_currencyHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_;
  }
  
  /**
   * Factory method corresponding to constructor 'AccountDetails()'.
   * @return {!AccountDetails}
   * @public
   */
  static $create__() {
    AccountDetails.$clinit();
    let $instance = new AccountDetails();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccountDetails()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails__() {
    this.$ctor__java_lang_Object__();
    this.f_accountNumberHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Account number").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_account_balance_wallet__()), TextBox)).m_setReadOnly__boolean(true), TextBox));
    this.f_ibanHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("IBAN").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_code__()), TextBox)).m_setReadOnly__boolean(true), TextBox));
    this.f_currencyHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Currency").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attach_money__()), TextBox)).m_setReadOnly__boolean(true), TextBox));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_ = /**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_accountNumberHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_ibanHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_currencyHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_), Column))), Row__12)).m_asElement__();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_;
  }
  
  /**
   * @param {CorporateAccount} account
   * @return {void}
   * @public
   */
  m_setAccount__org_dominokit_domino_formsamples_shared_model_CorporateAccount(account) {
    this.f_accountNumberHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_.m_setValue__java_lang_Object(account.m_getAccountNumber__());
    this.f_ibanHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_.m_setValue__java_lang_Object(account.m_getIban__());
    this.f_currencyHeader__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetails_.m_setValue__java_lang_Object(account.m_getCurrency__().m_getCurrencyCode__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AccountDetails;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AccountDetails);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AccountDetails.$clinit = function() {};
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AccountDetails, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetails'));


IsElement.$markImplementor(AccountDetails);


exports = AccountDetails; 
//# sourceMappingURL=AccountDetails.js.map