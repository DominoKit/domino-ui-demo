/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection.$LambdaAdaptor$5$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let TextArea = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class GoodsDescriptionSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TextArea} */
    this.f_goodsDescriptionTextArea__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'GoodsDescriptionSection()'.
   * @return {!GoodsDescriptionSection}
   * @public
   */
  static $create__() {
    GoodsDescriptionSection.$clinit();
    let $instance = new GoodsDescriptionSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GoodsDescriptionSection()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_.appendChild(BlockHeader.m_create__java_lang_String("Goods Description *").m_asElement__());
    this.f_goodsDescriptionTextArea__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_ = /**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("Goods Description").m_setAutoValidation__boolean(true), TextArea)).m_setRequired__boolean(true), TextArea)).m_autoSize__().m_setRows__int(3).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()), TextArea));
    this.f_goodsDescriptionTextArea__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$5(((/** Event */ evt) =>{
      this.m_revalidate__();
    })));
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_ = /**@type {Card} */ ($Casts.$to(Card.m_create__().m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_.appendChild(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_goodsDescriptionTextArea__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    letterOfCredit.m_setDescriptionOfGoods__java_lang_String(this.f_goodsDescriptionTextArea__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_.m_getValue__());
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_) && this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_, true, false);
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection() {
    return this.f_goodsDescriptionTextArea__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_.m_validate__().m_isValid__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GoodsDescriptionSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GoodsDescriptionSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GoodsDescriptionSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GoodsDescriptionSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection.$LambdaAdaptor$5$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    TextArea = goog.module.get('org.dominokit.domino.ui.forms.TextArea$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GoodsDescriptionSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection'));


ImportSection.$markImplementor(GoodsDescriptionSection);


exports = GoodsDescriptionSection; 
//# sourceMappingURL=GoodsDescriptionSection.js.map