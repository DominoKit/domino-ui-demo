/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.FormSamplesView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.FormSamplesView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasUiHandlers = goog.require('org.dominokit.domino.api.client.mvp.view.HasUiHandlers');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView');
const _FormSamplesUIHandlers = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers');


// Re-exports the implementation.
var FormSamplesView = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView$impl');
exports = FormSamplesView;
 