/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ApplicantSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ApplicantSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let CorporateAccountsSelect = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let CollateralSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccount$impl');
let CorporateAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let FeesAndChargesSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount$impl');
let LcSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class ApplicantSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {CorporateAccountsSelect} */
    this.f_lcSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
    /** @public {CorporateAccountsSelect} */
    this.f_collateralSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
    /** @public {CorporateAccountsSelect} */
    this.f_feesAndChargesAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'ApplicantSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {!ApplicantSection}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    ApplicantSection.$clinit();
    let $instance = new ApplicantSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ApplicantSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.appendChild(BlockHeader.m_create__java_lang_String("Buyer (Applicant) *").m_asElement__());
    this.f_lcSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_ = CorporateAccountsSelect.m_create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile("LC settlement accounts", corporateProfile);
    this.f_collateralSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_ = CorporateAccountsSelect.m_create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile("Collateral settlement accounts", corporateProfile);
    this.f_feesAndChargesAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_ = CorporateAccountsSelect.m_create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile("Fees and charges accounts", corporateProfile);
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_ = Card.m_create__();
    let corporateAccountSelectionHandler = SelectionHandler.$adapt(((/** SelectOption<CorporateAccount> */ option) =>{
      if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_) && this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_validate__().m_isValid__()) {
        CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_, true, false);
      }
    }));
    /**@type {Select<CorporateAccount>} */ ($Casts.$to(/**@type {Select<CorporateAccount>} */ ($Casts.$to(this.f_lcSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_getAccountSelect__().m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(corporateAccountSelectionHandler);
    /**@type {Select<CorporateAccount>} */ ($Casts.$to(/**@type {Select<CorporateAccount>} */ ($Casts.$to(this.f_collateralSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_getAccountSelect__().m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(corporateAccountSelectionHandler);
    /**@type {Select<CorporateAccount>} */ ($Casts.$to(/**@type {Select<CorporateAccount>} */ ($Casts.$to(this.f_feesAndChargesAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_getAccountSelect__().m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(corporateAccountSelectionHandler);
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.appendChild(/**@type {Card} */ ($Casts.$to(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_lcSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_collateralSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_feesAndChargesAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_, valid);
    return valid;
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let applicant = letterOfCredit.m_getApplicant__();
    this.m_setLcAccount__org_dominokit_domino_formsamples_shared_model_Applicant_$p_org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection(applicant);
    this.m_setCollateralAccount__org_dominokit_domino_formsamples_shared_model_Applicant_$p_org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection(applicant);
    this.m_setFeesAndChargesAccount__org_dominokit_domino_formsamples_shared_model_Applicant_$p_org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection(applicant);
  }
  
  /**
   * @param {Applicant} applicant
   * @return {void}
   * @public
   */
  m_setFeesAndChargesAccount__org_dominokit_domino_formsamples_shared_model_Applicant_$p_org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection(applicant) {
    let feesAndChargesSettlementAccount = FeesAndChargesSettlementAccount.$create__();
    let feesAndChargesAccount = /**@type {CorporateAccount} */ ($Casts.$to(this.f_feesAndChargesAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_getAccountSelect__().m_getValue__(), CorporateAccount));
    feesAndChargesSettlementAccount.m_setAccountAlias__java_lang_String(feesAndChargesAccount.m_getAccountAlias__());
    feesAndChargesSettlementAccount.m_setAccountNumber__java_lang_String(feesAndChargesAccount.m_getAccountNumber__());
    feesAndChargesSettlementAccount.m_setIban__java_lang_String(feesAndChargesAccount.m_getIban__());
    applicant.m_setFeesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_FeesAndChargesSettlementAccount(feesAndChargesSettlementAccount);
  }
  
  /**
   * @param {Applicant} applicant
   * @return {void}
   * @public
   */
  m_setCollateralAccount__org_dominokit_domino_formsamples_shared_model_Applicant_$p_org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection(applicant) {
    let collateralSettlementAccount = CollateralSettlementAccount.$create__();
    let collateralAccount = /**@type {CorporateAccount} */ ($Casts.$to(this.f_collateralSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_getAccountSelect__().m_getValue__(), CorporateAccount));
    collateralSettlementAccount.m_setAccountAlias__java_lang_String(collateralAccount.m_getAccountAlias__());
    collateralSettlementAccount.m_setAccountNumber__java_lang_String(collateralAccount.m_getAccountNumber__());
    collateralSettlementAccount.m_setIban__java_lang_String(collateralAccount.m_getIban__());
    applicant.m_setCollateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_CollateralSettlementAccount(collateralSettlementAccount);
  }
  
  /**
   * @param {Applicant} applicant
   * @return {void}
   * @public
   */
  m_setLcAccount__org_dominokit_domino_formsamples_shared_model_Applicant_$p_org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection(applicant) {
    let lcSettlementAccount = LcSettlementAccount.$create__();
    let lcAccount = /**@type {CorporateAccount} */ ($Casts.$to(this.f_lcSettlementAccountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_.m_getAccountSelect__().m_getValue__(), CorporateAccount));
    lcSettlementAccount.m_setAccountAlias__java_lang_String(lcAccount.m_getAccountAlias__());
    lcSettlementAccount.m_setAccountNumber__java_lang_String(lcAccount.m_getAccountNumber__());
    lcSettlementAccount.m_setIban__java_lang_String(lcAccount.m_getIban__());
    applicant.m_setLcSettlementAccount__org_dominokit_domino_formsamples_shared_model_LcSettlementAccount(lcSettlementAccount);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ApplicantSection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ApplicantSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ApplicantSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ApplicantSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    CorporateAccountsSelect = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
    CollateralSettlementAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccount$impl');
    CorporateAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
    FeesAndChargesSettlementAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount$impl');
    LcSettlementAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ApplicantSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.ApplicantSection'));


ImportSection.$markImplementor(ApplicantSection);


exports = ApplicantSection; 
//# sourceMappingURL=ApplicantSection.js.map