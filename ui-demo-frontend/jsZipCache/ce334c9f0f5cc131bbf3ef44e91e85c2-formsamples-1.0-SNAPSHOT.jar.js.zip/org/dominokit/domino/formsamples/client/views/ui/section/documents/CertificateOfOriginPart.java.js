/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _Integer = goog.require('java.lang.Integer');
const _List = goog.require('java.util.List');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart.$LambdaAdaptor$15');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart.$LambdaAdaptor$16');
const _CertificateOfOrigin = goog.require('org.dominokit.domino.formsamples.shared.model.CertificateOfOrigin');
const _Country = goog.require('org.dominokit.domino.formsamples.shared.model.Country');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CertificateOfOriginPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart$impl');
exports = CertificateOfOriginPart;
 