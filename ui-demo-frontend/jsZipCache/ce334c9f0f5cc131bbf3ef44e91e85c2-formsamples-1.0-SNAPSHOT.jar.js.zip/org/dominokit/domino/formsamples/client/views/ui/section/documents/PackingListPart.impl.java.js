/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$23 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart.$LambdaAdaptor$23$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart.$LambdaAdaptor$24$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let PackingList = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.PackingList$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class PackingListPart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_packingListCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
    /** @public {SwitchButton} */
    this.f_packingListRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
    /** @public {TextBox} */
    this.f_packingListTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
    /** @public {Card} */
    this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
  }
  
  /**
   * Factory method corresponding to constructor 'PackingListPart()'.
   * @return {!PackingListPart}
   * @public
   */
  static $create__() {
    PackingListPart.$clinit();
    let $instance = new PackingListPart();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PackingListPart()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart();
    this.f_packingListCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_ = /**@type {TextBox} */ ($Casts.$to(CustomElements.m_createCopiesField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_), TextBox));
    this.f_packingListCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$23(((/** Event */ evt) =>{
      this.m_revalidate__();
    })));
    this.f_packingListTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_ = /**@type {TextBox} */ ($Casts.$to(CustomElements.m_createDescriptionField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_), TextBox));
    this.f_packingListTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$24(((/** Event */ evt$1$) =>{
      this.m_revalidate__();
    })));
    this.f_packingListRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_ = CustomElements.m_createRequiredField__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_expand__();
      } else {
        this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_ = Card.m_create__java_lang_String("Packing list in").m_setBodyPaddingTop__java_lang_String("40px").m_collapse__();
    this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_packingListRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.appendChild(this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextBox} */ ($Casts.$to(this.f_packingListCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextBox} */ ($Casts.$to(this.f_packingListTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true)), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let documentsRequired = letterOfCredit.m_getDocumentsRequired__();
    let packingList = PackingList.$create__();
    packingList.m_setRequired__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_packingListRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getValue__()));
    if (packingList.m_isRequired__()) {
      packingList.m_setDescription__java_lang_String(this.f_packingListTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getValue__());
      packingList.m_setNumberOfCopies__int(Integer.m_parseInt__java_lang_String(this.f_packingListCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getValue__()));
    }
    documentsRequired.m_setPackingList__org_dominokit_domino_formsamples_shared_model_PackingList(packingList);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_) && this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_packingListCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_, true, false);
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart() {
    return !Boolean.m_booleanValue__java_lang_Boolean(this.f_packingListRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_getValue__()) || this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_.m_validate__().m_isValid__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_PackingListPart_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PackingListPart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PackingListPart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PackingListPart.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$23 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart.$LambdaAdaptor$23$impl');
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart.$LambdaAdaptor$24$impl');
    PackingList = goog.module.get('org.dominokit.domino.formsamples.shared.model.PackingList$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PackingListPart, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart'));


ImportSection.$markImplementor(PackingListPart);


exports = PackingListPart; 
//# sourceMappingURL=PackingListPart.js.map