/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AuthorizationSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection$impl');
exports = AuthorizationSection;
 