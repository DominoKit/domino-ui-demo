/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.IssuerBankSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.IssuerBankSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let BanksComponent = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.BanksComponent$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let Branch = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Branch$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class IssuerBankSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<Bank>} */
    this.f_issuerBanksSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {Select<Branch>} */
    this.f_issuerBranchesSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {TextBox} */
    this.f_issuerAddressTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {TextBox} */
    this.f_issuerContactPersonTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {Row} */
    this.f_issuerBankInfoRow__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'IssuerBankSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {!IssuerBankSection}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    IssuerBankSection.$clinit();
    let $instance = new IssuerBankSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IssuerBankSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.appendChild(BlockHeader.m_create__java_lang_String("Issuer Bank *").m_asElement__());
    let banks = corporateProfile.m_getBanks__();
    let banksComponent = BanksComponent.m_create__java_util_List(banks);
    this.f_issuerBranchesSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = /**@type {Select<Branch>} */ ($Casts.$to(/**@type {Select<Branch>} */ ($Casts.$to(banksComponent.m_getBranchesSelect__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true);
    this.f_issuerBanksSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = /**@type {Select<Bank>} */ ($Casts.$to(/**@type {Select<Bank>} */ ($Casts.$to(banksComponent.m_getBanksSelect__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true);
    this.f_issuerAddressTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = TextBox.m_create__java_lang_String("Address");
    this.f_issuerContactPersonTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = TextBox.m_create__java_lang_String("Contact Person");
    this.f_issuerBankInfoRow__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = /**@type {Row} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextBox} */ ($Casts.$to(this.f_issuerAddressTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_on__()), TextBox)).m_setReadOnly__boolean(true)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextBox} */ ($Casts.$to(this.f_issuerContactPersonTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_person__()), TextBox)).m_setReadOnly__boolean(true)), Column))), Row__12)).m_collapse__(), Row));
    this.f_issuerBranchesSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Branch> */ option) =>{
      this.f_issuerBankInfoRow__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_expand__();
    })));
    this.f_issuerBanksSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Bank> */ option$1$) =>{
      this.f_issuerBankInfoRow__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_collapse__();
    })));
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = Card.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.appendChild(/**@type {Card} */ ($Casts.$to(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_issuerBanksSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_issuerBranchesSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_issuerBankInfoRow__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_).m_asElement__());
    this.f_issuerBanksSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_focus__();
    this.f_issuerBranchesSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Branch> */ option$2$) =>{
      let branch = /**@type {Branch} */ ($Casts.$to(option$2$.m_getValue__(), Branch));
      this.f_issuerAddressTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_setValue__java_lang_Object(j_l_String.m_valueOf__java_lang_Object(branch.m_getAddress__().m_getCountryISOCode__()) + " - " + j_l_String.m_valueOf__java_lang_Object(branch.m_getAddress__().m_getCity__()));
      this.f_issuerContactPersonTextBox__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_setValue__java_lang_Object(branch.m_getContactPerson__().m_getName__());
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_, true, false);
    })));
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let issuer = letterOfCredit.m_getIssuer__();
    issuer.m_setBank__java_lang_String(/**@type {Bank} */ ($Casts.$to(this.f_issuerBanksSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_getValue__(), Bank)).m_getSwiftCode__());
    issuer.m_setBranch__java_lang_String(/**@type {Branch} */ ($Casts.$to(this.f_issuerBranchesSelect__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_getValue__(), Branch)).m_getName__());
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_, valid);
    return valid;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_IssuerBankSection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IssuerBankSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IssuerBankSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IssuerBankSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    BanksComponent = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.BanksComponent$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    Branch = goog.module.get('org.dominokit.domino.formsamples.shared.model.Branch$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IssuerBankSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.IssuerBankSection'));


ImportSection.$markImplementor(IssuerBankSection);


exports = IssuerBankSection; 
//# sourceMappingURL=IssuerBankSection.js.map