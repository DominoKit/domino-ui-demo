/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.FormSamplesView$FormSamplesUIHandlers$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _FormSamplesUIHandlers = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 