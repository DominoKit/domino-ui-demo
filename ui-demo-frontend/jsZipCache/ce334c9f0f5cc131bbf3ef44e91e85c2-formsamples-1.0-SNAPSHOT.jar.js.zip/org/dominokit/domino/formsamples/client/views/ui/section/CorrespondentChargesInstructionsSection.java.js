/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _CorporateAccountsSelect = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect');
const _CorporateAccount = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateAccount');
const _CorporateProfile = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateProfile');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CorrespondentChargesInstructionsSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection$impl');
exports = CorrespondentChargesInstructionsSection;
 