/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter.$1$impl');
let FormSamplesView = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.FormSamplesView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<FormSamplesView>}
  */
class FormSamplesPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormSamplesPresenter()'.
   * @return {!FormSamplesPresenter}
   * @public
   */
  static $create__() {
    FormSamplesPresenter.$clinit();
    let $instance = new FormSamplesPresenter();
    $instance.$ctor__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormSamplesPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {FormsContext} context
   * @return {void}
   * @public
   */
  m_onFormsEvent__org_dominokit_domino_forms_shared_extension_FormsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter_() {
    return (FormSamplesPresenter.$clinit(), FormSamplesPresenter.$f_LOGGER__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter_(value) {
    (FormSamplesPresenter.$clinit(), FormSamplesPresenter.$f_LOGGER__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormSamplesPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormSamplesPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormSamplesPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    FormSamplesPresenter.$f_LOGGER__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormSamplesPresenter));
  }
  
  
};

$Util.$setClassMetadata(FormSamplesPresenter, $Util.$makeClassName('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter'));


/** @private {Logger} */
FormSamplesPresenter.$f_LOGGER__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenter_;




exports = FormSamplesPresenter; 
//# sourceMappingURL=FormSamplesPresenter.js.map