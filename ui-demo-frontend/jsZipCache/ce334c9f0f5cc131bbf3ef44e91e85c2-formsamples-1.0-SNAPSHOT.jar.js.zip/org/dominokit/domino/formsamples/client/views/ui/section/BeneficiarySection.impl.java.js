/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.BeneficiarySection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.BeneficiarySection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let Account = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Account$impl');
let Beneficiary = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
let ContactPerson = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class BeneficiarySection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<Beneficiary>} */
    this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_;
    /** @public {Select<Account>} */
    this.f_accountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_;
  }
  
  /**
   * Factory method corresponding to constructor 'BeneficiarySection(List)'.
   * @param {List<Beneficiary>} beneficiaries
   * @return {!BeneficiarySection}
   * @public
   */
  static $create__java_util_List(beneficiaries) {
    BeneficiarySection.$clinit();
    let $instance = new BeneficiarySection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection__java_util_List(beneficiaries);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BeneficiarySection(List)'.
   * @param {List<Beneficiary>} beneficiaries
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection__java_util_List(beneficiaries) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.appendChild(BlockHeader.m_create__java_lang_String("Seller(Beneficiary) *").m_asElement__());
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_ = Card.m_create__();
    this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_ = /**@type {Select<Beneficiary>} */ ($Casts.$to(/**@type {Select<Beneficiary>} */ ($Casts.$to(/**@type {Select<Beneficiary>} */ (Select.m_create__java_lang_String("Beneficiary Name")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_label__()).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Beneficiary> */ option) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection();
    })));
    this.f_accountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_ = /**@type {Select<Account>} */ ($Casts.$to(/**@type {Select<Account>} */ ($Casts.$to(/**@type {Select<Account>} */ (Select.m_create__java_lang_String("Through")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_business__()).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Account> */ option$1$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection();
    })));
    for (let $iterator = beneficiaries.m_iterator__(); $iterator.m_hasNext__(); ) {
      let beneficiary = /**@type {Beneficiary} */ ($Casts.$to($iterator.m_next__(), Beneficiary));
      this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Beneficiary>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(beneficiary, beneficiary.m_getName__())));
    }
    this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Beneficiary> */ option$2$) =>{
      this.f_accountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_removeAllOptions__();
      let beneficiary$1$ = /**@type {Beneficiary} */ ($Casts.$to(this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_getValue__(), Beneficiary));
      let accounts = beneficiary$1$.m_getAccounts__();
      for (let $iterator$1$ = accounts.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
        let account = /**@type {Account} */ ($Casts.$to($iterator$1$.m_next__(), Account));
        this.f_accountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Account>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(account, account.m_getAccountAlias__())));
      }
    })));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.appendChild(/**@type {Card} */ ($Casts.$to(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_accountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_), Column)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_) && this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_validate__().m_isValid__()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_, true, false);
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_, valid);
    return valid;
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let beneficiary = letterOfCredit.m_getBeneficiary__();
    let selectedBeneficiary = /**@type {Beneficiary} */ ($Casts.$to(this.f_beneficiariesSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_getValue__(), Beneficiary));
    beneficiary.m_setReference__java_lang_String(selectedBeneficiary.m_getId__());
    beneficiary.m_setName__java_lang_String(selectedBeneficiary.m_getName__());
    beneficiary.m_setAddress__org_dominokit_domino_formsamples_shared_model_Address(selectedBeneficiary.m_getAddress__());
    let contactPerson = ContactPerson.$create__();
    contactPerson.m_setAddress__org_dominokit_domino_formsamples_shared_model_Address(selectedBeneficiary.m_getContactPerson__().m_getAddress__());
    contactPerson.m_setEmail__java_lang_String(selectedBeneficiary.m_getContactPerson__().m_getEmail__());
    contactPerson.m_setName__java_lang_String(selectedBeneficiary.m_getContactPerson__().m_getName__());
    beneficiary.m_setContactPerson__org_dominokit_domino_formsamples_shared_model_ContactPerson(contactPerson);
    beneficiary.m_setAccount__org_dominokit_domino_formsamples_shared_model_Account(/**@type {Account} */ ($Casts.$to(this.f_accountsSelect__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_.m_getValue__(), Account)));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_BeneficiarySection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BeneficiarySection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BeneficiarySection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BeneficiarySection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    Account = goog.module.get('org.dominokit.domino.formsamples.shared.model.Account$impl');
    Beneficiary = goog.module.get('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
    ContactPerson = goog.module.get('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BeneficiarySection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.BeneficiarySection'));


ImportSection.$markImplementor(BeneficiarySection);


exports = BeneficiarySection; 
//# sourceMappingURL=BeneficiarySection.js.map