/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _AccountDetails = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetails');
const _AccountDetailsPopupPosition = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition');
const _CorporateAccount = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateAccount');
const _CorporateProfile = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateProfile');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Popover = goog.require('org.dominokit.domino.ui.popover.Popover');
const _Tooltip = goog.require('org.dominokit.domino.ui.popover.Tooltip');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CorporateAccountsSelect = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
exports = CorporateAccountsSelect;
 