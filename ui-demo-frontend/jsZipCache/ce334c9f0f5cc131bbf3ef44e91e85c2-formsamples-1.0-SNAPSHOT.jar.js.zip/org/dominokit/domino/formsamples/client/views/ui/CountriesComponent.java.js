/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.CountriesComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.CountriesComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _Country = goog.require('org.dominokit.domino.formsamples.shared.model.Country');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CountriesComponent = goog.require('org.dominokit.domino.formsamples.client.views.ui.CountriesComponent$impl');
exports = CountriesComponent;
 