/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _Double = goog.require('java.lang.Double');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _CurrenciesComponent = goog.require('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.$LambdaAdaptor$3');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection.$LambdaAdaptor$4');
const _CurrencyData = goog.require('org.dominokit.domino.formsamples.shared.model.CurrencyData');
const _LcAmount = goog.require('org.dominokit.domino.formsamples.shared.model.LcAmount');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _CheckBox = goog.require('org.dominokit.domino.ui.forms.CheckBox');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _ValidationResult = goog.require('org.dominokit.domino.ui.forms.validations.ValidationResult');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Validator = goog.require('org.dominokit.domino.ui.utils.HasValidation.Validator');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CreditAmountAndToleranceSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection$impl');
exports = CreditAmountAndToleranceSection;
 