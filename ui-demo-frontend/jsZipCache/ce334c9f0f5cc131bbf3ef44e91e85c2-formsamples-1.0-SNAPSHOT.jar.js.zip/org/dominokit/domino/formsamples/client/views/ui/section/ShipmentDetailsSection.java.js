/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _j_l_String = goog.require('java.lang.String');
const _Date = goog.require('java.util.Date');
const _Constants = goog.require('org.dominokit.domino.formsamples.client.views.ui.Constants');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _$LambdaAdaptor$10 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$10');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$11');
const _$LambdaAdaptor$8 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$8');
const _$LambdaAdaptor$9 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$9');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _DateBox = goog.require('org.dominokit.domino.ui.datepicker.DateBox');
const _DateSelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _DateTimeFormat = goog.require('org.gwtproject.i18n.client.DateTimeFormat');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ShipmentDetailsSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection$impl');
exports = ShipmentDetailsSection;
 