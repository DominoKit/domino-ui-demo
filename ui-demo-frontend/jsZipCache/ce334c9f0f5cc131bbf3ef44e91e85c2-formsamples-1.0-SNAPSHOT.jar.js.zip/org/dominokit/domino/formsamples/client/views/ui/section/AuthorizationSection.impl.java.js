/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class AuthorizationSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'AuthorizationSection()'.
   * @return {!AuthorizationSection}
   * @public
   */
  static $create__() {
    AuthorizationSection.$clinit();
    let $instance = new AuthorizationSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AuthorizationSection()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection();
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(Elements.m_p__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_LEAD__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String("Authorization Request"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_p__().m_textContent__java_lang_String("We Hereby Request you to issue this irrevocable Documentary Credit for our full account.risk and responsibility , and in accordance with the conditions below stated by us in this application confirm that we are familiar with and accept the standard terms and conditions of issuance of documentary credits as reflected on the last page of this application.\n" + "\n" + "This Documentary Credit is subject to the ICC publication Uniform Customs and Practice 600"), IsElement)));
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    return true;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection_.m_asElement__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection() {
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_AuthorizationSection_ = Card.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AuthorizationSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AuthorizationSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AuthorizationSection.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AuthorizationSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection'));


ImportSection.$markImplementor(AuthorizationSection);


exports = AuthorizationSection; 
//# sourceMappingURL=AuthorizationSection.js.map