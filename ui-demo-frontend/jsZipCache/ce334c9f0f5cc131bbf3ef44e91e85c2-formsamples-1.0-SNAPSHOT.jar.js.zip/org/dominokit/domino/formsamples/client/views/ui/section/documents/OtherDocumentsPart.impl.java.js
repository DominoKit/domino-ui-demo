/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart.$LambdaAdaptor$22$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let OtherDocumentsItem = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.OtherDocumentsItem$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class OtherDocumentsPart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Row} */
    this.f_otherDocumentListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
    /** @public {ListGroup<OtherDocumentsItem>} */
    this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
    /** @public {TextBox} */
    this.f_otherDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
    /** @public {TextBox} */
    this.f_otherDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
  }
  
  /**
   * Factory method corresponding to constructor 'OtherDocumentsPart()'.
   * @return {!OtherDocumentsPart}
   * @public
   */
  static $create__() {
    OtherDocumentsPart.$clinit();
    let $instance = new OtherDocumentsPart();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'OtherDocumentsPart()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart();
    this.f_otherDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_ = /**@type {TextBox} */ ($Casts.$to(CustomElements.m_createCopiesField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_), TextBox));
    this.f_otherDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_ = /**@type {TextBox} */ ($Casts.$to(CustomElements.m_createDescriptionField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_), TextBox));
    this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_ = /**@type {ListGroup<OtherDocumentsItem>} */ (ListGroup.m_create__()).m_setSelectable__boolean(false);
    let otherDocumentsCard = Card.m_create__java_lang_String("Other documents").m_setBodyPaddingTop__java_lang_String("40px");
    otherDocumentsCard.m_getHeaderBar__().m_appendChild__elemental2_dom_Node(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_add__()).m_setContent__java_lang_String("ADD"), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style) =>{
      style.m_setMarginTop__java_lang_String("-10px");
    }))), Button)).m_linkify__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$21(((/** Event */ evt) =>{
      if (this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_validate__().m_isValid__()) {
        this.m_addOtherDocumentItem___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart();
      }
    }))), Button)).m_asElement__());
    this.f_otherDocumentListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_ = /**@type {Row} */ ($Casts.$to(Row.m_create__().m_collapse__(), Row));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.appendChild(otherDocumentsCard.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_otherDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_setRequired__boolean(true)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_otherDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_setRequired__boolean(true)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_otherDocumentListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_), Column)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addOtherDocumentItem___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart() {
    let item = this.m_makeNewOtherDocument___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart();
    let listItem = this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_addItem__java_lang_Object__java_lang_String(item, item.m_getDescription__());
    let delete$1$ = /**@type {Icon} */ ($Casts.$to(/**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_delete__())).m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_setMarginTop__java_lang_String("-3px").m_setMarginLeft__java_lang_String("10px").m_get__(), Icon));
    delete$1$.m_asElement__().addEventListener("click", new $LambdaAdaptor$22(((/** Event */ evt1) =>{
      this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_removeItem__org_dominokit_domino_ui_lists_ListItem(listItem);
      if (this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_getAllValues__().size() == 0) {
        this.f_otherDocumentListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_collapse__();
      }
    })));
    if (this.f_otherDocumentListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_isCollapsed__()) {
      this.f_otherDocumentListGroupRow__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_expand__();
    }
    listItem.m_appendChild__org_jboss_gwt_elemento_core_IsElement(delete$1$).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createCopiesBadge__org_dominokit_domino_formsamples_shared_model_OtherDocumentsItem_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart(item));
    this.f_otherDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_clear__();
    this.f_otherDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_clearInvalid__();
    this.f_otherDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_clear__();
    this.f_otherDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_clearInvalid__();
  }
  
  /**
   * @param {OtherDocumentsItem} item
   * @return {Badge}
   * @public
   */
  m_createCopiesBadge__org_dominokit_domino_formsamples_shared_model_OtherDocumentsItem_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart(item) {
    return /**@type {Badge} */ ($Casts.$to(Badge.m_create__java_lang_String(item.m_getNumberOfCopies__() + " Copies").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_style__().m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_get__(), Badge));
  }
  
  /**
   * @return {OtherDocumentsItem}
   * @public
   */
  m_makeNewOtherDocument___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart() {
    return OtherDocumentsItem.$create__int__java_lang_String(Integer.m_parseInt__java_lang_String(this.f_otherDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_getValue__()), this.f_otherDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_getValue__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let documentsRequired = letterOfCredit.m_getDocumentsRequired__();
    documentsRequired.m_setOtherDocuments__java_util_List(this.f_otherDocumentsItemListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_.m_getAllValues__());
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    return true;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart() {
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_ = FieldsGrouping.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_OtherDocumentsPart_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof OtherDocumentsPart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, OtherDocumentsPart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    OtherDocumentsPart.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart.$LambdaAdaptor$22$impl');
    OtherDocumentsItem = goog.module.get('org.dominokit.domino.formsamples.shared.model.OtherDocumentsItem$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ListGroup = goog.module.get('org.dominokit.domino.ui.lists.ListGroup$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(OtherDocumentsPart, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart'));


ImportSection.$markImplementor(OtherDocumentsPart);


exports = OtherDocumentsPart; 
//# sourceMappingURL=OtherDocumentsPart.js.map