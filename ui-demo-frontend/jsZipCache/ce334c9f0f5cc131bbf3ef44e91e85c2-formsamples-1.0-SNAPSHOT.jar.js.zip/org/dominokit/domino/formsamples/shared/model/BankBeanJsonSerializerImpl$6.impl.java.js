/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$6.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$6$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Collection = goog.forwardDeclare('java.util.Collection$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let BankBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$impl');
let Branch = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Branch$impl');
let BranchBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BranchBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let CollectionJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.CollectionJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Bank, List<Branch>>}
  */
class $6 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {BankBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_6;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(BankBeanJsonSerializerImpl, String)'.
   * @param {BankBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$6}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $6.$clinit();
    let $instance = new $6();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_6__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(BankBeanJsonSerializerImpl, String)'.
   * @param {BankBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_6__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_6 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return /**@type {CollectionJsonSerializer<Collection<*>, ?>} */ (CollectionJsonSerializer.m_newInstance__org_dominokit_jacksonapt_JsonSerializer(BranchBeanJsonSerializerImpl.$create__()));
  }
  
  /**
   * @param {Bank} bean
   * @param {JsonSerializationContext} ctx
   * @return {List<Branch>}
   * @public
   */
  m_getValue__org_dominokit_domino_formsamples_shared_model_Bank__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getBranches__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {List<Branch>}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_formsamples_shared_model_Bank__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Bank} */ ($Casts.$to(arg0, Bank)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $6;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $6);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $6.$clinit = function() {};
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    BranchBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.BranchBeanJsonSerializerImpl$impl');
    CollectionJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.CollectionJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($6, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$6'));




exports = $6; 
//# sourceMappingURL=BankBeanJsonSerializerImpl$6.js.map