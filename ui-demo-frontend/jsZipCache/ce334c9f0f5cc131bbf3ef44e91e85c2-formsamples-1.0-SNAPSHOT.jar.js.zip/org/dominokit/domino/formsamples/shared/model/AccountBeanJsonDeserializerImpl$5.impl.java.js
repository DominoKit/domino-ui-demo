/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl$5.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$5$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Account = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Account$impl');
let AccountBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let StringJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Account, ?string>}
  */
class $5 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AccountBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl_5;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(AccountBeanJsonDeserializerImpl)'.
   * @param {AccountBeanJsonDeserializerImpl} $outer_this
   * @return {!$5}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl($outer_this) {
    $5.$clinit();
    let $instance = new $5();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl_5__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(AccountBeanJsonDeserializerImpl)'.
   * @param {AccountBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl_5__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl_5 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return StringJsonDeserializer.m_getInstance__();
  }
  
  /**
   * @param {Account} bean
   * @param {?string} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Account__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setProcessInstanceId__java_lang_String(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Account__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Account} */ ($Casts.$to(arg0, Account)), /**@type {?string} */ ($Casts.$to(arg1, j_l_String)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $5;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $5);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $5.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Account = goog.module.get('org.dominokit.domino.formsamples.shared.model.Account$impl');
    StringJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($5, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl$5'));




exports = $5; 
//# sourceMappingURL=AccountBeanJsonDeserializerImpl$5.js.map