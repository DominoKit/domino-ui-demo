/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$5$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Applicant>}
  */
class ApplicantBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ApplicantBeanJsonDeserializerImpl()'.
   * @return {!ApplicantBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    ApplicantBeanJsonDeserializerImpl.$clinit();
    let $instance = new ApplicantBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ApplicantBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Applicant);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Applicant>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Applicant, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Applicant, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("lcSettlementAccount", $2.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("feesAndChargesSettlementAccount", $3.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("value", $4.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("collateralSettlementAccount", $5.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ApplicantBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ApplicantBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ApplicantBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Applicant = goog.module.get('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$5$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ApplicantBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl'));




exports = ApplicantBeanJsonDeserializerImpl; 
//# sourceMappingURL=ApplicantBeanJsonDeserializerImpl.js.map