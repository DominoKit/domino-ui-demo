/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl$3.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$3$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Address = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Address$impl');
let AddressBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl$impl');
let Beneficiary = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
let BeneficiaryBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Beneficiary, Address>}
  */
class $3 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {BeneficiaryBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl_3;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(BeneficiaryBeanJsonDeserializerImpl)'.
   * @param {BeneficiaryBeanJsonDeserializerImpl} $outer_this
   * @return {!$3}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl($outer_this) {
    $3.$clinit();
    let $instance = new $3();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(BeneficiaryBeanJsonDeserializerImpl)'.
   * @param {BeneficiaryBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl_3 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return AddressBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @param {Beneficiary} bean
   * @param {Address} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Beneficiary__org_dominokit_domino_formsamples_shared_model_Address__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setAddress__org_dominokit_domino_formsamples_shared_model_Address(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Beneficiary__org_dominokit_domino_formsamples_shared_model_Address__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Beneficiary} */ ($Casts.$to(arg0, Beneficiary)), /**@type {Address} */ ($Casts.$to(arg1, Address)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $3;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $3);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $3.$clinit = function() {};
    Address = goog.module.get('org.dominokit.domino.formsamples.shared.model.Address$impl');
    AddressBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl$impl');
    Beneficiary = goog.module.get('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($3, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl$3'));




exports = $3; 
//# sourceMappingURL=BeneficiaryBeanJsonDeserializerImpl$3.js.map