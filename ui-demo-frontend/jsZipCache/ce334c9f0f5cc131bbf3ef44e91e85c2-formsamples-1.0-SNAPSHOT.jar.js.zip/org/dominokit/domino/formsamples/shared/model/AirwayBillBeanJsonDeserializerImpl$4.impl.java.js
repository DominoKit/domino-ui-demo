/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$4.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$4$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let AirwayBill = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
let AirwayBillBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let BooleanJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<AirwayBill, ?boolean>}
  */
class $4 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AirwayBillBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_4;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(AirwayBillBeanJsonDeserializerImpl)'.
   * @param {AirwayBillBeanJsonDeserializerImpl} $outer_this
   * @return {!$4}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl($outer_this) {
    $4.$clinit();
    let $instance = new $4();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_4__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(AirwayBillBeanJsonDeserializerImpl)'.
   * @param {AirwayBillBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_4__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_4 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return BooleanJsonDeserializer.m_getInstance__();
  }
  
  /**
   * @param {AirwayBill} bean
   * @param {?boolean} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_AirwayBill__java_lang_Boolean__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setRequired__boolean(Boolean.m_booleanValue__java_lang_Boolean(value));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_AirwayBill__java_lang_Boolean__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {AirwayBill} */ ($Casts.$to(arg0, AirwayBill)), /**@type {?boolean} */ ($Casts.$to(arg1, Boolean)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $4;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $4);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $4.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    AirwayBill = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
    BooleanJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($4, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$4'));




exports = $4; 
//# sourceMappingURL=AirwayBillBeanJsonDeserializerImpl$4.js.map