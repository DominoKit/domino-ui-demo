/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Agreement = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
let AgreementBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let IntegerJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.BaseNumberJsonSerializer.IntegerJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Agreement, Integer>}
  */
class $2 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AgreementBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(AgreementBeanJsonSerializerImpl, String)'.
   * @param {AgreementBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl_2__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(AgreementBeanJsonSerializerImpl, String)'.
   * @param {AgreementBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl_2__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonSerializerImpl_2 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return IntegerJsonSerializer.m_getInstance__();
  }
  
  /**
   * @param {Agreement} bean
   * @param {JsonSerializationContext} ctx
   * @return {Integer}
   * @public
   */
  m_getValue__org_dominokit_domino_formsamples_shared_model_Agreement__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return Integer.m_valueOf__int(bean.m_getAmount__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {Integer}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_formsamples_shared_model_Agreement__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Agreement} */ ($Casts.$to(arg0, Agreement)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    Agreement = goog.module.get('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
    IntegerJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.BaseNumberJsonSerializer.IntegerJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl$2'));




exports = $2; 
//# sourceMappingURL=AgreementBeanJsonSerializerImpl$2.js.map