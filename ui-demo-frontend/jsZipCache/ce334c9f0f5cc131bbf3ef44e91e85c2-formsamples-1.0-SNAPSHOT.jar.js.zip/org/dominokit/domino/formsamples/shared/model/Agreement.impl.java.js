/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Agreement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Agreement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Agreement extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {number} */
    this.f_amount__org_dominokit_domino_formsamples_shared_model_Agreement_ = 0;
    /** @public {?string} */
    this.f_code__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_toDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_description__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_fromDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_reference__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_profileId__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {?string} */
    this.f_currency__org_dominokit_domino_formsamples_shared_model_Agreement_;
    /** @public {number} */
    this.f_remainingBalance__org_dominokit_domino_formsamples_shared_model_Agreement_ = 0;
    /** @public {?string} */
    this.f_id__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * Factory method corresponding to constructor 'Agreement()'.
   * @return {!Agreement}
   * @public
   */
  static $create__() {
    Agreement.$clinit();
    let $instance = new Agreement();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Agreement__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Agreement()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Agreement__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} processInstanceId
   * @return {void}
   * @public
   */
  m_setProcessInstanceId__java_lang_String(processInstanceId) {
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Agreement_ = processInstanceId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getProcessInstanceId__() {
    return this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {number} amount
   * @return {void}
   * @public
   */
  m_setAmount__int(amount) {
    this.f_amount__org_dominokit_domino_formsamples_shared_model_Agreement_ = amount;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getAmount__() {
    return this.f_amount__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} code
   * @return {void}
   * @public
   */
  m_setCode__java_lang_String(code) {
    this.f_code__org_dominokit_domino_formsamples_shared_model_Agreement_ = code;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCode__() {
    return this.f_code__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} updatedBy
   * @return {void}
   * @public
   */
  m_setUpdatedBy__java_lang_String(updatedBy) {
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Agreement_ = updatedBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedBy__() {
    return this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} toDate
   * @return {void}
   * @public
   */
  m_setToDate__java_lang_String(toDate) {
    this.f_toDate__org_dominokit_domino_formsamples_shared_model_Agreement_ = toDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getToDate__() {
    return this.f_toDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} description
   * @return {void}
   * @public
   */
  m_setDescription__java_lang_String(description) {
    this.f_description__org_dominokit_domino_formsamples_shared_model_Agreement_ = description;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDescription__() {
    return this.f_description__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} updatedDate
   * @return {void}
   * @public
   */
  m_setUpdatedDate__java_lang_String(updatedDate) {
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Agreement_ = updatedDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedDate__() {
    return this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} fromDate
   * @return {void}
   * @public
   */
  m_setFromDate__java_lang_String(fromDate) {
    this.f_fromDate__org_dominokit_domino_formsamples_shared_model_Agreement_ = fromDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getFromDate__() {
    return this.f_fromDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} reference
   * @return {void}
   * @public
   */
  m_setReference__java_lang_String(reference) {
    this.f_reference__org_dominokit_domino_formsamples_shared_model_Agreement_ = reference;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getReference__() {
    return this.f_reference__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} createdDate
   * @return {void}
   * @public
   */
  m_setCreatedDate__java_lang_String(createdDate) {
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Agreement_ = createdDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedDate__() {
    return this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} createdBy
   * @return {void}
   * @public
   */
  m_setCreatedBy__java_lang_String(createdBy) {
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Agreement_ = createdBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedBy__() {
    return this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} profileId
   * @return {void}
   * @public
   */
  m_setProfileId__java_lang_String(profileId) {
    this.f_profileId__org_dominokit_domino_formsamples_shared_model_Agreement_ = profileId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getProfileId__() {
    return this.f_profileId__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} tenantId
   * @return {void}
   * @public
   */
  m_setTenantId__java_lang_String(tenantId) {
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Agreement_ = tenantId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTenantId__() {
    return this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} currency
   * @return {void}
   * @public
   */
  m_setCurrency__java_lang_String(currency) {
    this.f_currency__org_dominokit_domino_formsamples_shared_model_Agreement_ = currency;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCurrency__() {
    return this.f_currency__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {number} remainingBalance
   * @return {void}
   * @public
   */
  m_setRemainingBalance__int(remainingBalance) {
    this.f_remainingBalance__org_dominokit_domino_formsamples_shared_model_Agreement_ = remainingBalance;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getRemainingBalance__() {
    return this.f_remainingBalance__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?string} id
   * @return {void}
   * @public
   */
  m_setId__java_lang_String(id) {
    this.f_id__org_dominokit_domino_formsamples_shared_model_Agreement_ = id;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getId__() {
    return this.f_id__org_dominokit_domino_formsamples_shared_model_Agreement_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Agreement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Agreement);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Agreement.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Agreement, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Agreement'));




exports = Agreement; 
//# sourceMappingURL=Agreement.js.map