/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let AirwayBill = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$4$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<AirwayBill>}
  */
class AirwayBillBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AirwayBillBeanJsonDeserializerImpl()'.
   * @return {!AirwayBillBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    AirwayBillBeanJsonDeserializerImpl.$clinit();
    let $instance = new AirwayBillBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AirwayBillBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(AirwayBill);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<AirwayBill>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<AirwayBill, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<AirwayBill, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("description", $2.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("numberOfCopies", $3.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("required", $4.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AirwayBillBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AirwayBillBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AirwayBillBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    AirwayBill = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$4$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AirwayBillBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl'));




exports = AirwayBillBeanJsonDeserializerImpl; 
//# sourceMappingURL=AirwayBillBeanJsonDeserializerImpl.js.map