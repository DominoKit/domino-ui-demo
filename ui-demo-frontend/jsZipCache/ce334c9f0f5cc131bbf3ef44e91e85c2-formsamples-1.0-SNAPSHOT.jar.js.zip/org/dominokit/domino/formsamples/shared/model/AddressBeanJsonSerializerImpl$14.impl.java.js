/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl$14.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$14$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Address = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Address$impl');
let AddressBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let StringJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Address, ?string>}
  */
class $14 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AddressBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl_14;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(AddressBeanJsonSerializerImpl, String)'.
   * @param {AddressBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$14}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $14.$clinit();
    let $instance = new $14();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl_14__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(AddressBeanJsonSerializerImpl, String)'.
   * @param {AddressBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl_14__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl_14 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return StringJsonSerializer.m_getInstance__();
  }
  
  /**
   * @param {Address} bean
   * @param {JsonSerializationContext} ctx
   * @return {?string}
   * @public
   */
  m_getValue__org_dominokit_domino_formsamples_shared_model_Address__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getPhoneNumber__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {?string}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_formsamples_shared_model_Address__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Address} */ ($Casts.$to(arg0, Address)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $14;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $14);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $14.$clinit = function() {};
    Address = goog.module.get('org.dominokit.domino.formsamples.shared.model.Address$impl');
    StringJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($14, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl$14'));




exports = $14; 
//# sourceMappingURL=AddressBeanJsonSerializerImpl$14.js.map