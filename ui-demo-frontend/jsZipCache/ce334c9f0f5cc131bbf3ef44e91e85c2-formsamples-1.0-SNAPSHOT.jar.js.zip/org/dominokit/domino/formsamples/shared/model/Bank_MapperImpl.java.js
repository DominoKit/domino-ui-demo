/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _BankBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl');
const _BankBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');


// Re-exports the implementation.
var Bank__MapperImpl = goog.require('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl$impl');
exports = Bank__MapperImpl;
 