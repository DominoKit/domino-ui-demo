/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer');
const _Class = goog.require('java.lang.Class');
const _AirwayBill = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBill');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$1');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$3');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var AirwayBillBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl$impl');
exports = AirwayBillBeanJsonSerializerImpl;
 