/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$4$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<Applicant>}
  */
class ApplicantBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ApplicantBeanJsonSerializerImpl()'.
   * @return {!ApplicantBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    ApplicantBeanJsonSerializerImpl.$clinit();
    let $instance = new ApplicantBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ApplicantBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(Applicant);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([4], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String(this, "lcSettlementAccount"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String(this, "feesAndChargesSettlementAccount"));
    $Arrays.$set(result, 2, $3.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String(this, "value"));
    $Arrays.$set(result, 3, $4.$create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String(this, "collateralSettlementAccount"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ApplicantBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ApplicantBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ApplicantBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Applicant = goog.module.get('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$4$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ApplicantBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl'));




exports = ApplicantBeanJsonSerializerImpl; 
//# sourceMappingURL=ApplicantBeanJsonSerializerImpl.js.map