/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Bank.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Bank$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Address = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Address$impl');
let Bank__MapperImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl$impl');
let Branch = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Branch$impl');
let ContactPerson = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');


class Bank extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Address} */
    this.f_address__org_dominokit_domino_formsamples_shared_model_Bank_;
    /** @public {ContactPerson} */
    this.f_contactPerson__org_dominokit_domino_formsamples_shared_model_Bank_;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_formsamples_shared_model_Bank_;
    /** @public {?string} */
    this.f_shortName__org_dominokit_domino_formsamples_shared_model_Bank_;
    /** @public {?string} */
    this.f_swiftCode__org_dominokit_domino_formsamples_shared_model_Bank_;
    /** @public {List<Branch>} */
    this.f_branches__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * Factory method corresponding to constructor 'Bank()'.
   * @return {!Bank}
   * @public
   */
  static $create__() {
    Bank.$clinit();
    let $instance = new Bank();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Bank__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Bank()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Bank__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {Address}
   * @public
   */
  m_getAddress__() {
    return this.f_address__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * @param {Address} address
   * @return {void}
   * @public
   */
  m_setAddress__org_dominokit_domino_formsamples_shared_model_Address(address) {
    this.f_address__org_dominokit_domino_formsamples_shared_model_Bank_ = address;
  }
  
  /**
   * @return {ContactPerson}
   * @public
   */
  m_getContactPerson__() {
    return this.f_contactPerson__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * @param {ContactPerson} contactPerson
   * @return {void}
   * @public
   */
  m_setContactPerson__org_dominokit_domino_formsamples_shared_model_ContactPerson(contactPerson) {
    this.f_contactPerson__org_dominokit_domino_formsamples_shared_model_Bank_ = contactPerson;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_domino_formsamples_shared_model_Bank_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getShortName__() {
    return this.f_shortName__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * @param {?string} shortName
   * @return {void}
   * @public
   */
  m_setShortName__java_lang_String(shortName) {
    this.f_shortName__org_dominokit_domino_formsamples_shared_model_Bank_ = shortName;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getSwiftCode__() {
    return this.f_swiftCode__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * @param {?string} swiftCode
   * @return {void}
   * @public
   */
  m_setSwiftCode__java_lang_String(swiftCode) {
    this.f_swiftCode__org_dominokit_domino_formsamples_shared_model_Bank_ = swiftCode;
  }
  
  /**
   * @return {List<Branch>}
   * @public
   */
  m_getBranches__() {
    return this.f_branches__org_dominokit_domino_formsamples_shared_model_Bank_;
  }
  
  /**
   * @param {List<Branch>} branches
   * @return {void}
   * @public
   */
  m_setBranches__java_util_List(branches) {
    this.f_branches__org_dominokit_domino_formsamples_shared_model_Bank_ = branches;
  }
  
  /**
   * @return {Bank__MapperImpl}
   * @public
   */
  static get f_MAPPER__org_dominokit_domino_formsamples_shared_model_Bank() {
    return (Bank.$clinit(), Bank.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Bank);
  }
  
  /**
   * @param {Bank__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_MAPPER__org_dominokit_domino_formsamples_shared_model_Bank(value) {
    (Bank.$clinit(), Bank.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Bank = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Bank;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Bank);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Bank.$clinit = function() {};
    Bank__MapperImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl$impl');
    j_l_Object.$clinit();
    Bank.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Bank = Bank__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(Bank, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Bank'));


/** @private {Bank__MapperImpl} */
Bank.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Bank;




exports = Bank; 
//# sourceMappingURL=Bank.js.map