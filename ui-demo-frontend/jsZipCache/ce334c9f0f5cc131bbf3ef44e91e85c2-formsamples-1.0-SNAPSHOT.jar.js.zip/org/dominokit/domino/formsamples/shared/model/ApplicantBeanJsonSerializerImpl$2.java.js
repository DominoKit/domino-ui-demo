/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Applicant = goog.require('org.dominokit.domino.formsamples.shared.model.Applicant');
const _ApplicantBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl');
const _FeesAndChargesSettlementAccount = goog.require('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount');
const _FeesAndChargesSettlementAccountBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccountBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$2$impl');
exports = $2;
 