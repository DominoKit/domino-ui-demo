package org.dominokit.domino.formsamples.shared.model;

import java.lang.Boolean;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.BaseNumberJsonSerializer;
import org.dominokit.jacksonapt.ser.BooleanJsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class AirwayBillBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<AirwayBill> {
  public AirwayBillBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return AirwayBill.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[3];
    result[0] = new BeanPropertySerializer<AirwayBill, String>("description") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(AirwayBill bean, JsonSerializationContext ctx) {
        return bean.getDescription();
      }
    };
    result[1] = new BeanPropertySerializer<AirwayBill, Integer>("numberOfCopies") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BaseNumberJsonSerializer.IntegerJsonSerializer.getInstance();
      }

      @Override
      public Integer getValue(AirwayBill bean, JsonSerializationContext ctx) {
        return bean.getNumberOfCopies();
      }
    };
    result[2] = new BeanPropertySerializer<AirwayBill, Boolean>("required") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BooleanJsonSerializer.getInstance();
      }

      @Override
      public Boolean getValue(AirwayBill bean, JsonSerializationContext ctx) {
        return bean.isRequired();
      }
    };
    return result;
  }
}
