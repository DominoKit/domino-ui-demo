/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl$3.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$3$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Agreement = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
let AgreementBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let IntegerJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Agreement, Integer>}
  */
class $3 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AgreementBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl_3;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(AgreementBeanJsonDeserializerImpl)'.
   * @param {AgreementBeanJsonDeserializerImpl} $outer_this
   * @return {!$3}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl($outer_this) {
    $3.$clinit();
    let $instance = new $3();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(AgreementBeanJsonDeserializerImpl)'.
   * @param {AgreementBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl_3 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return IntegerJsonDeserializer.m_getInstance__();
  }
  
  /**
   * @param {Agreement} bean
   * @param {Integer} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Agreement__java_lang_Integer__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setAmount__int(value.m_intValue__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Agreement__java_lang_Integer__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Agreement} */ ($Casts.$to(arg0, Agreement)), /**@type {Integer} */ ($Casts.$to(arg1, Integer)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $3;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $3);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $3.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    Agreement = goog.module.get('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
    IntegerJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($3, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl$3'));




exports = $3; 
//# sourceMappingURL=AgreementBeanJsonDeserializerImpl$3.js.map