/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$3.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$3$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let ApplicantBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$impl');
let FeesAndChargesSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount$impl');
let FeesAndChargesSettlementAccountBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccountBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Applicant, FeesAndChargesSettlementAccount>}
  */
class $3 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ApplicantBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_3;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ApplicantBeanJsonDeserializerImpl)'.
   * @param {ApplicantBeanJsonDeserializerImpl} $outer_this
   * @return {!$3}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this) {
    $3.$clinit();
    let $instance = new $3();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ApplicantBeanJsonDeserializerImpl)'.
   * @param {ApplicantBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_3 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return FeesAndChargesSettlementAccountBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @param {Applicant} bean
   * @param {FeesAndChargesSettlementAccount} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_domino_formsamples_shared_model_FeesAndChargesSettlementAccount__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setFeesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_FeesAndChargesSettlementAccount(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_domino_formsamples_shared_model_FeesAndChargesSettlementAccount__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Applicant} */ ($Casts.$to(arg0, Applicant)), /**@type {FeesAndChargesSettlementAccount} */ ($Casts.$to(arg1, FeesAndChargesSettlementAccount)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $3;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $3);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $3.$clinit = function() {};
    Applicant = goog.module.get('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
    FeesAndChargesSettlementAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount$impl');
    FeesAndChargesSettlementAccountBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccountBeanJsonDeserializerImpl$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($3, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$3'));




exports = $3; 
//# sourceMappingURL=ApplicantBeanJsonDeserializerImpl$3.js.map