/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Account.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Account$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Account extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_accountAlias__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_accountState__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_country__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_bicCode__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_accountNumber__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_bank__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_iban__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_currency__org_dominokit_domino_formsamples_shared_model_Account_;
    /** @public {?string} */
    this.f_id__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * Factory method corresponding to constructor 'Account()'.
   * @return {!Account}
   * @public
   */
  static $create__() {
    Account.$clinit();
    let $instance = new Account();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Account__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Account()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Account__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} accountAlias
   * @return {void}
   * @public
   */
  m_setAccountAlias__java_lang_String(accountAlias) {
    this.f_accountAlias__org_dominokit_domino_formsamples_shared_model_Account_ = accountAlias;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getAccountAlias__() {
    return this.f_accountAlias__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} accountState
   * @return {void}
   * @public
   */
  m_setAccountState__java_lang_String(accountState) {
    this.f_accountState__org_dominokit_domino_formsamples_shared_model_Account_ = accountState;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getAccountState__() {
    return this.f_accountState__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} country
   * @return {void}
   * @public
   */
  m_setCountry__java_lang_String(country) {
    this.f_country__org_dominokit_domino_formsamples_shared_model_Account_ = country;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCountry__() {
    return this.f_country__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} processInstanceId
   * @return {void}
   * @public
   */
  m_setProcessInstanceId__java_lang_String(processInstanceId) {
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Account_ = processInstanceId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getProcessInstanceId__() {
    return this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} updatedBy
   * @return {void}
   * @public
   */
  m_setUpdatedBy__java_lang_String(updatedBy) {
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Account_ = updatedBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedBy__() {
    return this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} bicCode
   * @return {void}
   * @public
   */
  m_setBicCode__java_lang_String(bicCode) {
    this.f_bicCode__org_dominokit_domino_formsamples_shared_model_Account_ = bicCode;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getBicCode__() {
    return this.f_bicCode__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} updatedDate
   * @return {void}
   * @public
   */
  m_setUpdatedDate__java_lang_String(updatedDate) {
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Account_ = updatedDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedDate__() {
    return this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} accountNumber
   * @return {void}
   * @public
   */
  m_setAccountNumber__java_lang_String(accountNumber) {
    this.f_accountNumber__org_dominokit_domino_formsamples_shared_model_Account_ = accountNumber;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getAccountNumber__() {
    return this.f_accountNumber__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} bank
   * @return {void}
   * @public
   */
  m_setBank__java_lang_String(bank) {
    this.f_bank__org_dominokit_domino_formsamples_shared_model_Account_ = bank;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getBank__() {
    return this.f_bank__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} createdDate
   * @return {void}
   * @public
   */
  m_setCreatedDate__java_lang_String(createdDate) {
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Account_ = createdDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedDate__() {
    return this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} createdBy
   * @return {void}
   * @public
   */
  m_setCreatedBy__java_lang_String(createdBy) {
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Account_ = createdBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedBy__() {
    return this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} iban
   * @return {void}
   * @public
   */
  m_setIban__java_lang_String(iban) {
    this.f_iban__org_dominokit_domino_formsamples_shared_model_Account_ = iban;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getIban__() {
    return this.f_iban__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} tenantId
   * @return {void}
   * @public
   */
  m_setTenantId__java_lang_String(tenantId) {
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Account_ = tenantId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTenantId__() {
    return this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} currency
   * @return {void}
   * @public
   */
  m_setCurrency__java_lang_String(currency) {
    this.f_currency__org_dominokit_domino_formsamples_shared_model_Account_ = currency;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCurrency__() {
    return this.f_currency__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?string} id
   * @return {void}
   * @public
   */
  m_setId__java_lang_String(id) {
    this.f_id__org_dominokit_domino_formsamples_shared_model_Account_ = id;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getId__() {
    return this.f_id__org_dominokit_domino_formsamples_shared_model_Account_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Account;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Account);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Account.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Account, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Account'));




exports = Account; 
//# sourceMappingURL=Account.js.map