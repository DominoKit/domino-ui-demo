/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Applicant.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Applicant$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CollateralSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccount$impl');
let FeesAndChargesSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount$impl');
let LcSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount$impl');


class Applicant extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {LcSettlementAccount} */
    this.f_lcSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_;
    /** @public {FeesAndChargesSettlementAccount} */
    this.f_feesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_;
    /** @public {?string} */
    this.f_value__org_dominokit_domino_formsamples_shared_model_Applicant_;
    /** @public {CollateralSettlementAccount} */
    this.f_collateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_;
  }
  
  /**
   * Factory method corresponding to constructor 'Applicant()'.
   * @return {!Applicant}
   * @public
   */
  static $create__() {
    Applicant.$clinit();
    let $instance = new Applicant();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Applicant__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Applicant()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Applicant__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LcSettlementAccount} lcSettlementAccount
   * @return {void}
   * @public
   */
  m_setLcSettlementAccount__org_dominokit_domino_formsamples_shared_model_LcSettlementAccount(lcSettlementAccount) {
    this.f_lcSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_ = lcSettlementAccount;
  }
  
  /**
   * @return {LcSettlementAccount}
   * @public
   */
  m_getLcSettlementAccount__() {
    return this.f_lcSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_;
  }
  
  /**
   * @param {FeesAndChargesSettlementAccount} feesAndChargesSettlementAccount
   * @return {void}
   * @public
   */
  m_setFeesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_FeesAndChargesSettlementAccount(feesAndChargesSettlementAccount) {
    this.f_feesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_ = feesAndChargesSettlementAccount;
  }
  
  /**
   * @return {FeesAndChargesSettlementAccount}
   * @public
   */
  m_getFeesAndChargesSettlementAccount__() {
    return this.f_feesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_;
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_String(value) {
    this.f_value__org_dominokit_domino_formsamples_shared_model_Applicant_ = value;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return this.f_value__org_dominokit_domino_formsamples_shared_model_Applicant_;
  }
  
  /**
   * @param {CollateralSettlementAccount} collateralSettlementAccount
   * @return {void}
   * @public
   */
  m_setCollateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_CollateralSettlementAccount(collateralSettlementAccount) {
    this.f_collateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_ = collateralSettlementAccount;
  }
  
  /**
   * @return {CollateralSettlementAccount}
   * @public
   */
  m_getCollateralSettlementAccount__() {
    return this.f_collateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "Applicant{" + "lcSettlementAccount = '" + j_l_String.m_valueOf__java_lang_Object(this.f_lcSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_) + j_l_String.m_valueOf__char(39 /* '\'' */) + ",feesAndChargesSettlementAccount = '" + j_l_String.m_valueOf__java_lang_Object(this.f_feesAndChargesSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_) + j_l_String.m_valueOf__char(39 /* '\'' */) + ",value = '" + j_l_String.m_valueOf__java_lang_Object(this.f_value__org_dominokit_domino_formsamples_shared_model_Applicant_) + j_l_String.m_valueOf__char(39 /* '\'' */) + ",collateralSettlementAccount = '" + j_l_String.m_valueOf__java_lang_Object(this.f_collateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_Applicant_) + j_l_String.m_valueOf__char(39 /* '\'' */) + "}";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Applicant;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Applicant);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Applicant.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Applicant, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Applicant'));




exports = Applicant; 
//# sourceMappingURL=Applicant.js.map