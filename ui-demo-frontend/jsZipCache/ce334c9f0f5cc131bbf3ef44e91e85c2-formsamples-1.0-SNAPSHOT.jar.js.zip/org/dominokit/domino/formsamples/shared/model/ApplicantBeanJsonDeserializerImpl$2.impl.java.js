/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let ApplicantBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$impl');
let LcSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount$impl');
let LcSettlementAccountBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcSettlementAccountBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Applicant, LcSettlementAccount>}
  */
class $2 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ApplicantBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ApplicantBeanJsonDeserializerImpl)'.
   * @param {ApplicantBeanJsonDeserializerImpl} $outer_this
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_2__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ApplicantBeanJsonDeserializerImpl)'.
   * @param {ApplicantBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_2__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_2 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return LcSettlementAccountBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @param {Applicant} bean
   * @param {LcSettlementAccount} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_domino_formsamples_shared_model_LcSettlementAccount__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setLcSettlementAccount__org_dominokit_domino_formsamples_shared_model_LcSettlementAccount(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_domino_formsamples_shared_model_LcSettlementAccount__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Applicant} */ ($Casts.$to(arg0, Applicant)), /**@type {LcSettlementAccount} */ ($Casts.$to(arg1, LcSettlementAccount)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    Applicant = goog.module.get('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
    LcSettlementAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount$impl');
    LcSettlementAccountBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.LcSettlementAccountBeanJsonDeserializerImpl$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$2'));




exports = $2; 
//# sourceMappingURL=ApplicantBeanJsonDeserializerImpl$2.js.map