/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl$8.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$8$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Account = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Account$impl');
let AccountBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let StringJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Account, ?string>}
  */
class $8 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AccountBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl_8;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(AccountBeanJsonSerializerImpl, String)'.
   * @param {AccountBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$8}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $8.$clinit();
    let $instance = new $8();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl_8__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(AccountBeanJsonSerializerImpl, String)'.
   * @param {AccountBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl_8__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl_8 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return StringJsonSerializer.m_getInstance__();
  }
  
  /**
   * @param {Account} bean
   * @param {JsonSerializationContext} ctx
   * @return {?string}
   * @public
   */
  m_getValue__org_dominokit_domino_formsamples_shared_model_Account__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getAccountNumber__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {?string}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_formsamples_shared_model_Account__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Account} */ ($Casts.$to(arg0, Account)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $8;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $8);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $8.$clinit = function() {};
    Account = goog.module.get('org.dominokit.domino.formsamples.shared.model.Account$impl');
    StringJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($8, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl$8'));




exports = $8; 
//# sourceMappingURL=AccountBeanJsonSerializerImpl$8.js.map