/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Agreement = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$14$impl');
let $15 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$15$impl');
let $16 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$16$impl');
let $17 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$17$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$9$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Agreement>}
  */
class AgreementBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AgreementBeanJsonDeserializerImpl()'.
   * @return {!AgreementBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    AgreementBeanJsonDeserializerImpl.$clinit();
    let $instance = new AgreementBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AgreementBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Agreement);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Agreement>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Agreement, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Agreement, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("processInstanceId", $2.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("amount", $3.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("code", $4.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedBy", $5.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("toDate", $6.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("description", $7.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedDate", $8.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("fromDate", $9.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("reference", $10.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdDate", $11.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdBy", $12.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("profileId", $13.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("tenantId", $14.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("currency", $15.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("remainingBalance", $16.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("id", $17.$create__org_dominokit_domino_formsamples_shared_model_AgreementBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AgreementBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AgreementBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AgreementBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Agreement = goog.module.get('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$14$impl');
    $15 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$15$impl');
    $16 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$16$impl');
    $17 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$17$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$9$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AgreementBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl'));




exports = AgreementBeanJsonDeserializerImpl; 
//# sourceMappingURL=AgreementBeanJsonDeserializerImpl.js.map