package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.BaseNumberJsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class AgreementBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Agreement> {
  public AgreementBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Agreement.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[16];
    result[0] = new BeanPropertySerializer<Agreement, String>("processInstanceId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getProcessInstanceId();
      }
    };
    result[1] = new BeanPropertySerializer<Agreement, Integer>("amount") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BaseNumberJsonSerializer.IntegerJsonSerializer.getInstance();
      }

      @Override
      public Integer getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getAmount();
      }
    };
    result[2] = new BeanPropertySerializer<Agreement, String>("code") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getCode();
      }
    };
    result[3] = new BeanPropertySerializer<Agreement, String>("updatedBy") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getUpdatedBy();
      }
    };
    result[4] = new BeanPropertySerializer<Agreement, String>("toDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getToDate();
      }
    };
    result[5] = new BeanPropertySerializer<Agreement, String>("description") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getDescription();
      }
    };
    result[6] = new BeanPropertySerializer<Agreement, String>("updatedDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getUpdatedDate();
      }
    };
    result[7] = new BeanPropertySerializer<Agreement, String>("fromDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getFromDate();
      }
    };
    result[8] = new BeanPropertySerializer<Agreement, String>("reference") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getReference();
      }
    };
    result[9] = new BeanPropertySerializer<Agreement, String>("createdDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getCreatedDate();
      }
    };
    result[10] = new BeanPropertySerializer<Agreement, String>("createdBy") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getCreatedBy();
      }
    };
    result[11] = new BeanPropertySerializer<Agreement, String>("profileId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getProfileId();
      }
    };
    result[12] = new BeanPropertySerializer<Agreement, String>("tenantId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getTenantId();
      }
    };
    result[13] = new BeanPropertySerializer<Agreement, String>("currency") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getCurrency();
      }
    };
    result[14] = new BeanPropertySerializer<Agreement, Integer>("remainingBalance") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BaseNumberJsonSerializer.IntegerJsonSerializer.getInstance();
      }

      @Override
      public Integer getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getRemainingBalance();
      }
    };
    result[15] = new BeanPropertySerializer<Agreement, String>("id") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Agreement bean, JsonSerializationContext ctx) {
        return bean.getId();
      }
    };
    return result;
  }
}
