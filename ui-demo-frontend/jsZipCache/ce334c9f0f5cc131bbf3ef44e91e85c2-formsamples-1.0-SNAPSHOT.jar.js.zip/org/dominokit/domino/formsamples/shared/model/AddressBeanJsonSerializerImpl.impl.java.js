/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Address = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Address$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$14$impl');
let $15 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$15$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$9$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<Address>}
  */
class AddressBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AddressBeanJsonSerializerImpl()'.
   * @return {!AddressBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    AddressBeanJsonSerializerImpl.$clinit();
    let $instance = new AddressBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AddressBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(Address);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([15], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "processInstanceId"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "zipCode"));
    $Arrays.$set(result, 2, $3.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "updatedBy"));
    $Arrays.$set(result, 3, $4.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "city"));
    $Arrays.$set(result, 4, $5.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "countryISOCode"));
    $Arrays.$set(result, 5, $6.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "updatedDate"));
    $Arrays.$set(result, 6, $7.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "createdDate"));
    $Arrays.$set(result, 7, $8.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "mailBox"));
    $Arrays.$set(result, 8, $9.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "createdBy"));
    $Arrays.$set(result, 9, $10.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "street"));
    $Arrays.$set(result, 10, $11.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "tenantId"));
    $Arrays.$set(result, 11, $12.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "id"));
    $Arrays.$set(result, 12, $13.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "apartment"));
    $Arrays.$set(result, 13, $14.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "phoneNumber"));
    $Arrays.$set(result, 14, $15.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonSerializerImpl__java_lang_String(this, "faxNumber"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AddressBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AddressBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AddressBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Address = goog.module.get('org.dominokit.domino.formsamples.shared.model.Address$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$14$impl');
    $15 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$15$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl.$9$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AddressBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonSerializerImpl'));




exports = AddressBeanJsonSerializerImpl; 
//# sourceMappingURL=AddressBeanJsonSerializerImpl.js.map