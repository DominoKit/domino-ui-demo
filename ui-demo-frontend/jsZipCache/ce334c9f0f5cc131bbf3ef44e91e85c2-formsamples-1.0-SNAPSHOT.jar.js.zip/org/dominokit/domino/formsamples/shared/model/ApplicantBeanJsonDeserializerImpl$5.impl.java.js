/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$5.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$5$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let ApplicantBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$impl');
let CollateralSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccount$impl');
let CollateralSettlementAccountBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccountBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Applicant, CollateralSettlementAccount>}
  */
class $5 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ApplicantBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_5;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ApplicantBeanJsonDeserializerImpl)'.
   * @param {ApplicantBeanJsonDeserializerImpl} $outer_this
   * @return {!$5}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this) {
    $5.$clinit();
    let $instance = new $5();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_5__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ApplicantBeanJsonDeserializerImpl)'.
   * @param {ApplicantBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_5__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonDeserializerImpl_5 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return CollateralSettlementAccountBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @param {Applicant} bean
   * @param {CollateralSettlementAccount} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_domino_formsamples_shared_model_CollateralSettlementAccount__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setCollateralSettlementAccount__org_dominokit_domino_formsamples_shared_model_CollateralSettlementAccount(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_domino_formsamples_shared_model_CollateralSettlementAccount__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Applicant} */ ($Casts.$to(arg0, Applicant)), /**@type {CollateralSettlementAccount} */ ($Casts.$to(arg1, CollateralSettlementAccount)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $5;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $5);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $5.$clinit = function() {};
    Applicant = goog.module.get('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
    CollateralSettlementAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccount$impl');
    CollateralSettlementAccountBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccountBeanJsonDeserializerImpl$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($5, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$5'));




exports = $5; 
//# sourceMappingURL=ApplicantBeanJsonDeserializerImpl$5.js.map