package org.dominokit.domino.waves.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface WavesView extends View, DemoView{
}