/**
 * @fileoverview transpiled from org.dominokit.domino.waves.client.presenters.WavesPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.waves.client.presenters.WavesPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _$1 = goog.require('org.dominokit.domino.waves.client.presenters.WavesPresenter.$1');
const _WavesView = goog.require('org.dominokit.domino.waves.client.views.WavesView');


// Re-exports the implementation.
var WavesPresenter = goog.require('org.dominokit.domino.waves.client.presenters.WavesPresenter$impl');
exports = WavesPresenter;
 