package org.dominokit.domino.progress.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.progress.client.contributions.ProgressPresenterContributionToComponentsExtensionPoint;
import org.dominokit.domino.progress.client.presenters.ProgressPresenter;
import org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand;
import org.dominokit.domino.progress.client.views.ui.ProgressViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ProgressModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(ProgressPresenter.class.getCanonicalName(), ProgressPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new ProgressPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(ProgressPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new ProgressViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(ProgressPresenterCommand.class.getCanonicalName(), ProgressPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentsExtensionPoint.class, new ProgressPresenterContributionToComponentsExtensionPoint());
  }
}
