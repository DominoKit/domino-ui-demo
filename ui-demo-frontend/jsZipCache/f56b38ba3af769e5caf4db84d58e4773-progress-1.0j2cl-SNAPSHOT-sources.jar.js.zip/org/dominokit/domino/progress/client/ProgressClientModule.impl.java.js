/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.ProgressClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.progress.client.ProgressClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ProgressClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProgressClientModule()'.
   * @return {!ProgressClientModule}
   * @public
   */
  static $create__() {
    ProgressClientModule.$clinit();
    let $instance = new ProgressClientModule();
    $instance.$ctor__org_dominokit_domino_progress_client_ProgressClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProgressClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_progress_client_ProgressClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ProgressClientModule.$f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_.m_info__java_lang_String("Initializing Progress frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_() {
    return (ProgressClientModule.$clinit(), ProgressClientModule.$f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_(value) {
    (ProgressClientModule.$clinit(), ProgressClientModule.$f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProgressClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProgressClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProgressClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ProgressClientModule.$f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ProgressClientModule));
  }
  
  
};

$Util.$setClassMetadata(ProgressClientModule, $Util.$makeClassName('org.dominokit.domino.progress.client.ProgressClientModule'));


/** @private {Logger} */
ProgressClientModule.$f_LOGGER__org_dominokit_domino_progress_client_ProgressClientModule_;




exports = ProgressClientModule; 
//# sourceMappingURL=ProgressClientModule.js.map