/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.views.ui.ProgressViewImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Timer = goog.require('org.gwtproject.timer.client.Timer$impl');

let ProgressViewImpl = goog.forwardDeclare('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl$impl');


class $1 extends Timer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ProgressViewImpl} */
    this.f_$outer_this__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new Timer(ProgressViewImpl)'.
   * @param {ProgressViewImpl} $outer_this
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl($outer_this) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_1__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new Timer(ProgressViewImpl)'.
   * @param {ProgressViewImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_1__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_1 = $outer_this;
    this.$ctor__org_gwtproject_timer_client_Timer__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_run__() {
    window.requestAnimationFrame(this.f_$outer_this__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_1.f_animationFrameCallback__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    Timer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl$1'));




exports = $1; 
//# sourceMappingURL=ProgressViewImpl$1.js.map