/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.views.ui.ProgressViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _ProgressView = goog.require('org.dominokit.domino.progress.client.views.ProgressView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _ComponentRevealedHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler');
const _CodeResource = goog.require('org.dominokit.domino.progress.client.views.CodeResource');
const _$1 = goog.require('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl.$1');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Progress = goog.require('org.dominokit.domino.ui.progress.Progress');
const _ProgressBar = goog.require('org.dominokit.domino.ui.progress.ProgressBar');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ProgressViewImpl = goog.require('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl$impl');
exports = ProgressViewImpl;
 