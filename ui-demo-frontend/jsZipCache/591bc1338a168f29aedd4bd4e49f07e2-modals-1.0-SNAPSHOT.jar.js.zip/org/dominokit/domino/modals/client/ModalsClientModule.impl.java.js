/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.ModalsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.ModalsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ModalsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ModalsClientModule()'.
   * @return {!ModalsClientModule}
   * @public
   */
  static $create__() {
    ModalsClientModule.$clinit();
    let $instance = new ModalsClientModule();
    $instance.$ctor__org_dominokit_domino_modals_client_ModalsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_modals_client_ModalsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ModalsClientModule.$f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_.m_info__java_lang_String("Initializing Modals frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_() {
    return (ModalsClientModule.$clinit(), ModalsClientModule.$f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_(value) {
    (ModalsClientModule.$clinit(), ModalsClientModule.$f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ModalsClientModule.$f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ModalsClientModule));
  }
  
  
};

$Util.$setClassMetadata(ModalsClientModule, $Util.$makeClassName('org.dominokit.domino.modals.client.ModalsClientModule'));


/** @private {Logger} */
ModalsClientModule.$f_LOGGER__org_dominokit_domino_modals_client_ModalsClientModule_;




exports = ModalsClientModule; 
//# sourceMappingURL=ModalsClientModule.js.map