/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ModalsPresenter = goog.forwardDeclare('org.dominokit.domino.modals.client.presenters.ModalsPresenter$impl');


/**
 * @extends {PresenterCommand<ModalsPresenter>}
  */
class ModalsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ModalsPresenterCommand()'.
   * @return {!ModalsPresenterCommand}
   * @public
   */
  static $create__() {
    ModalsPresenterCommand.$clinit();
    let $instance = new ModalsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_modals_client_presenters_ModalsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_modals_client_presenters_ModalsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ModalsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand'));




exports = ModalsPresenterCommand; 
//# sourceMappingURL=ModalsPresenterCommand.js.map