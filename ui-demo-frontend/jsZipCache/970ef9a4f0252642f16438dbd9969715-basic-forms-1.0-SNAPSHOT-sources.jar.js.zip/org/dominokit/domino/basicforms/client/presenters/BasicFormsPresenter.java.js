/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _$1 = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter.$1');
const _BasicFormsView = goog.require('org.dominokit.domino.basicforms.client.views.BasicFormsView');
const _FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var BasicFormsPresenter = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter$impl');
exports = BasicFormsPresenter;
 