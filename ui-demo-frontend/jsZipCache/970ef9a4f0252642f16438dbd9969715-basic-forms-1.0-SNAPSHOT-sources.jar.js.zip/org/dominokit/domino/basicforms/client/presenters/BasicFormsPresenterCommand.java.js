/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _BasicFormsPresenter = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter');


// Re-exports the implementation.
var BasicFormsPresenterCommand = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand$impl');
exports = BasicFormsPresenterCommand;
 