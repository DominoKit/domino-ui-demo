/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let BasicFormsPresenter = goog.forwardDeclare('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter$impl');


/**
 * @extends {PresenterCommand<BasicFormsPresenter>}
  */
class BasicFormsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BasicFormsPresenterCommand()'.
   * @return {!BasicFormsPresenterCommand}
   * @public
   */
  static $create__() {
    BasicFormsPresenterCommand.$clinit();
    let $instance = new BasicFormsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BasicFormsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BasicFormsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BasicFormsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BasicFormsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BasicFormsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand'));




exports = BasicFormsPresenterCommand; 
//# sourceMappingURL=BasicFormsPresenterCommand.js.map