/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MenuExtensionPoint = goog.require('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$impl');

let MenuContext = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {MenuExtensionPoint}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():MenuContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():MenuContext} */
    this.f_$$fn__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$LambdaAdaptor__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():MenuContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$LambdaAdaptor__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {MenuContext}
   * @public
   */
  m_context__() {
    let /** ?function():MenuContext */ $function;
    return /**@type {MenuContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint_$LambdaAdaptor, $function()), MenuContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    MenuContext = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$$LambdaAdaptor'));


MenuExtensionPoint.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=MenuExtensionPoint$$LambdaAdaptor.js.map