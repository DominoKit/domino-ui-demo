/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuContext$CanAddMenuItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');


/**
 * @interface
 */
class CanAddMenuItem {
  /**
   * @abstract
   * @param {?string} title
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String(title) {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, selectionHandler) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuContext_CanAddMenuItem;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanAddMenuItem.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(CanAddMenuItem, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuContext$CanAddMenuItem'));


CanAddMenuItem.$markImplementor(/** @type {Function} */ (CanAddMenuItem));


exports = CanAddMenuItem; 
//# sourceMappingURL=MenuContext$CanAddMenuItem.js.map