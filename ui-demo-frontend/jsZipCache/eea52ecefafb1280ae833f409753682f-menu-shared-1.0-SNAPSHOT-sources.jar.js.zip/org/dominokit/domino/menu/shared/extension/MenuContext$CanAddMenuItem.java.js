/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuContext$CanAddMenuItem.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _OnMenuSelectedHandler = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler');


// Re-exports the implementation.
var CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
exports = CanAddMenuItem;
 