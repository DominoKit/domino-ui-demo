/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ui.ProfileViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView$impl');

let HeightUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ProfileView}
  */
class ProfileViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Card} */
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ProfileViewImpl()'.
   * @return {!ProfileViewImpl}
   * @public
   */
  static $create__() {
    ProfileViewImpl.$clinit();
    let $instance = new ProfileViewImpl();
    $instance.$ctor__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfileViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl();
  }
  
  /**
   * @override
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
    let leftPanel = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(layout.m_getLeftPanel__().m_get__()), $Overlay));
    if (leftPanel.childElementCount > 0) {
      leftPanel.insertBefore(this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_asElement__(), leftPanel.firstChild);
    } else {
      leftPanel.appendChild(this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_asElement__());
    }
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getBody__().appendChild(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("static/images/user.png").m_style__java_lang_String("border-radius:50%;"), EmptyContentBuilder)).m_asElement__());
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getHeaderBar__().appendChild(this.m_createIcon__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_profile_client_views_ui_ProfileViewImpl(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__()));
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_asElement__().style.height = HeightUnionType_$Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(300));
  }
  
  /**
   * @param {Icon} icon
   * @return {HTMLLIElement}
   * @public
   */
  m_createIcon__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_profile_client_views_ui_ProfileViewImpl(icon) {
    return /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__elemental2_dom_Node(icon.m_asElement__()), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl() {
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_ = Card.m_createProfile__java_lang_String__java_lang_String("Vegegoku", "vegegoku@bo3.com");
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfileViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfileViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfileViewImpl.$clinit = function() {};
    HeightUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProfileViewImpl, $Util.$makeClassName('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl'));


ProfileView.$markImplementor(ProfileViewImpl);


exports = ProfileViewImpl; 
//# sourceMappingURL=ProfileViewImpl.js.map