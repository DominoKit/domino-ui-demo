/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ui.ProfileViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView');
const _HeightUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.HeightUnionType.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLImageElement_$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _Js = goog.require('jsinterop.base.Js');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _EmptyContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ProfileViewImpl = goog.require('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl$impl');
exports = ProfileViewImpl;
 