/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.contributions.ProfilePresenterContributionToLayoutExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.contributions.ProfilePresenterContributionToLayoutExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
let ProfilePresenter = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');
let ProfilePresenterCommand = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<LayoutExtensionPoint>}
  */
class ProfilePresenterContributionToLayoutExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProfilePresenterContributionToLayoutExtensionPoint()'.
   * @return {!ProfilePresenterContributionToLayoutExtensionPoint}
   * @public
   */
  static $create__() {
    ProfilePresenterContributionToLayoutExtensionPoint.$clinit();
    let $instance = new ProfilePresenterContributionToLayoutExtensionPoint();
    $instance.$ctor__org_dominokit_domino_profile_client_contributions_ProfilePresenterContributionToLayoutExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfilePresenterContributionToLayoutExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_contributions_ProfilePresenterContributionToLayoutExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(extensionPoint) {
    ProfilePresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ProfilePresenter */ presenter) =>{
      presenter.m_contributeToLayoutModule__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(extensionPoint.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(/**@type {LayoutExtensionPoint} */ ($Casts.$to(arg0, LayoutExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfilePresenterContributionToLayoutExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfilePresenterContributionToLayoutExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfilePresenterContributionToLayoutExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutExtensionPoint = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
    ProfilePresenterCommand = goog.module.get('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProfilePresenterContributionToLayoutExtensionPoint, $Util.$makeClassName('org.dominokit.domino.profile.client.contributions.ProfilePresenterContributionToLayoutExtensionPoint'));


Contribution.$markImplementor(ProfilePresenterContributionToLayoutExtensionPoint);


exports = ProfilePresenterContributionToLayoutExtensionPoint; 
//# sourceMappingURL=ProfilePresenterContributionToLayoutExtensionPoint.js.map