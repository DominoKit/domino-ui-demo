/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LayoutView = goog.require('org.dominokit.domino.layout.client.views.LayoutView$impl');

let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLParagraphElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let MouseEvent_$Overlay = goog.forwardDeclare('elemental2.dom.MouseEvent.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$2$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Layout = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout$impl');
let ScrollTop = goog.forwardDeclare('org.dominokit.domino.ui.scroll.ScrollTop$impl');
let Search = goog.forwardDeclare('org.dominokit.domino.ui.search.Search$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Theme = goog.forwardDeclare('org.dominokit.domino.ui.themes.Theme$impl');
let ThemeChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.themes.Theme.ThemeChangeHandler$impl');
let SafeHtmlBuilder = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtmlBuilder$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {LayoutView}
  */
class LayoutViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Layout} */
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_;
    /** @public {Content} */
    this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutViewImpl()'.
   * @return {!LayoutViewImpl}
   * @public
   */
  static $create__() {
    LayoutViewImpl.$clinit();
    let $instance = new LayoutViewImpl();
    $instance.$ctor__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl();
    let search = Search.m_create__();
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getNavigationBar__().m_insertBefore__org_dominokit_domino_ui_utils_BaseDominoElement__elemental2_dom_Node(search, this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getNavigationBar__().m_firstChild__());
    let searchButton = /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["js-right-sidebar"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_search__()), HtmlContentBuilder));
    searchButton.m_on__org_jboss_gwt_elemento_core_EventType__org_jboss_gwt_elemento_core_EventCallbackFn(EventType.f_click__org_jboss_gwt_elemento_core_EventType, ((/** MouseEvent */ event) =>{
      search.m_open__();
    }));
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getTopBar__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_pull_right__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(searchButton), HtmlContentBuilder)).m_asElement__());
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getTopBar__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_pull_right__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("padding-top: 3px;"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.m_makeGithubLink___$p_org_dominokit_domino_layout_client_ui_views_LayoutViewImpl()), HtmlContentBuilder)).m_asElement__());
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_showFooter__();
    let copyrightsElement = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Theme.f_currentTheme__org_dominokit_domino_ui_themes_Theme.m_getScheme__().m_darker_3__().m_getBackground__()], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(Elements.m_p__().m_style__java_lang_String("line-height: 45px; height: 45px; margin: 0px;"), HtmlContentBuilder)).m_textContent__java_lang_String("\u00A9 2018 Copyright DominoKit"), IsElement))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    let footerRow = this.m_createFooterRow___$p_org_dominokit_domino_layout_client_ui_views_LayoutViewImpl();
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getFooter__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(footerRow);
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getFooter__().m_appendChild__elemental2_dom_Node(copyrightsElement);
    Theme.m_addThemeChangeHandler__org_dominokit_domino_ui_themes_Theme_ThemeChangeHandler(ThemeChangeHandler.$adapt(((/** Theme */ oldTheme, /** Theme */ newTheme) =>{
      /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(copyrightsElement)).m_remove__java_lang_String(oldTheme.m_getScheme__().m_darker_3__().m_getBackground__()).m_add__java_lang_String(newTheme.m_getScheme__().m_darker_3__().m_getBackground__());
    })));
    DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(ScrollTop.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_arrow_upward__()).m_setBottom__int(60).m_asElement__());
  }
  
  /**
   * @return {Row}
   * @public
   */
  m_createFooterRow___$p_org_dominokit_domino_layout_client_ui_views_LayoutViewImpl() {
    return /**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_style__().m_setMargin__java_lang_String("0px").m_add__java_lang_String("demo-footer").m_get__(), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_style__().m_setMarginBottom__java_lang_String("20px").m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Support us"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_p__().m_textContent__java_lang_String("Your donation will help us to continue working on domino-ui and let it grow to meet your needs, and is highly appreciated."), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_div__().m_innerHtml__org_gwtproject_safehtml_shared_SafeHtml(SafeHtmlBuilder.$create__().m_appendHtmlConstant__java_lang_String("<form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\" target=\"_top\">\n" + "<input type=\"hidden\" name=\"cmd\" value=\"_s-xclick\">\n" + "<input type=\"hidden\" name=\"hosted_button_id\" value=\"H4SM3EKUT4C7E\">\n" + "<input type=\"image\" src=\"https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif\" border=\"0\" name=\"submit\" alt=\"PayPal - The safer, easier way to pay online!\">\n" + "<img alt=\"\" border=\"0\" src=\"https://www.paypalobjects.com/en_US/i/scr/pixel.gif\" width=\"1\" height=\"1\">\n" + "</form>").m_toSafeHtml__()), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_style__().m_setMarginBottom__java_lang_String("20px").m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Join discussions"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_p__().m_textContent__java_lang_String("Join our Gitter channel for positive discussions, feedback, announcements and ask questions, it is lively in there."), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_p__().m_innerHtml__org_gwtproject_safehtml_shared_SafeHtml(SafeHtmlBuilder.$create__().m_appendHtmlConstant__java_lang_String("<a title=\"Gitter\" href=\"https://gitter.im/domino-gwt/domino-ui\" rel=\"nofollow\"><img src=\"https://camo.githubusercontent.com/da2edb525cde1455a622c58c0effc3a90b9a181c/68747470733a2f2f6261646765732e6769747465722e696d2f4a6f696e253230436861742e737667\" data-canonical-src=\"https://badges.gitter.im/Join%20Chat.svg\" style=\"max-width:100%;\"></a>").m_toSafeHtml__()), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_style__().m_setMarginBottom__java_lang_String("20px").m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Our repository"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_p__().m_textContent__java_lang_String("Contribute to our library at our official Domino-ui Github repository by forking, making pull requests or filing issues."), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLDivElement, HtmlContentBuilder<HTMLDivElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_innerHtml__org_gwtproject_safehtml_shared_SafeHtml(SafeHtmlBuilder.$create__().m_appendHtmlConstant__java_lang_String("<iframe src=\"https://ghbtns.com/github-btn.html?user=DominoKit&amp;repo=domino-ui&amp;type=star&amp;count=true&amp;size=large\" frameborder=\"0\" scrolling=\"0\" width=\"125px\" height=\"30px\"></iframe>").m_toSafeHtml__()), HtmlContentBuilder))))), Column)));
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  m_makeGithubLink___$p_org_dominokit_domino_layout_client_ui_views_LayoutViewImpl() {
    let githubLink = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fab fa-github fa-2x", "js-right-sidebar"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLAnchorElement_$Overlay));
    githubLink.addEventListener("click", new $LambdaAdaptor$1(((/** Event */ evt) =>{
      window.window.open("https://github.com/DominoKit/domino-ui", "_blank");
    })));
    return githubLink;
  }
  
  /**
   * @override
   * @param {?string} iconName
   * @param {SelectionHandler} selectionHandler
   * @return {void}
   * @public
   */
  m_addActionItem__java_lang_String__org_dominokit_domino_layout_shared_extension_LayoutContext_SelectionHandler(iconName, selectionHandler) {
    let actionItem = this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_addActionItem__org_dominokit_domino_ui_icons_BaseIcon(Icon.m_create__java_lang_String(iconName));
    actionItem.addEventListener("click", new $LambdaAdaptor$2(((/** Event */ evt) =>{
      selectionHandler.m_onSelected__();
    })));
  }
  
  /**
   * @override
   * @param {Content} content
   * @return {void}
   * @public
   */
  m_setRightPanelContent__org_dominokit_domino_api_shared_extension_Content(content) {
    if (Objects.m_nonNull__java_lang_Object(this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_) && !$Objects.m_equals__java_lang_Object__java_lang_Object(this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_, content)) {
      this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getRightPanel__().m_removeChild__elemental2_dom_Node(/**@type {HTMLDivElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_get__()), $Overlay)));
    }
    this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_ = content;
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getRightPanel__().m_appendChild__elemental2_dom_Node(/**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(content.m_get__()), HTMLElement_$Overlay)));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_toggleRightPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_toggleRightPanel__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_toggleLeftPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_toggleLeftPanel__();
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_showLeftPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_showLeftPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_hideLeftPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_hideLeftPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getRightPanel__() {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getRightPanel__().m_asElement__();
    })), Content));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getLeftPanel__() {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getLeftPanel__().m_asElement__();
    })), Content));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContentPanel__() {
    return /**@type {Content<HTMLDivElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getContentPanel__().m_asElement__(), $Overlay));
    })), Content));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getTopBar__() {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getTopBar__().m_asElement__();
    })), Content));
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {IsLayout}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_setTitle__java_lang_String(title);
    return this;
  }
  
  /**
   * @override
   * @param {?string} icon
   * @return {Content}
   * @public
   */
  m_addActionItem__java_lang_String(icon) {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_addActionItem__org_dominokit_domino_ui_icons_BaseIcon(Icon.m_create__java_lang_String(icon));
    })), Content));
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_show__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_show__boolean(false);
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_showRightPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_showRightPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_hideRightPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_hideRightPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_fixLeftPanelPosition__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_fixLeftPanelPosition__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_unfixLeftPanelPosition__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_unfixLeftPanelPosition__();
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_ = Layout.$create__().m_setTitle__java_lang_String("Domino UI demo").m_fixLeftPanelMode__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutViewImpl.$clinit = function() {};
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLElement_$Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    Content = goog.module.get('org.dominokit.domino.api.shared.extension.Content$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$2$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Layout = goog.module.get('org.dominokit.domino.ui.layout.Layout$impl');
    ScrollTop = goog.module.get('org.dominokit.domino.ui.scroll.ScrollTop$impl');
    Search = goog.module.get('org.dominokit.domino.ui.search.Search$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Theme = goog.module.get('org.dominokit.domino.ui.themes.Theme$impl');
    ThemeChangeHandler = goog.module.get('org.dominokit.domino.ui.themes.Theme.ThemeChangeHandler$impl');
    SafeHtmlBuilder = goog.module.get('org.gwtproject.safehtml.shared.SafeHtmlBuilder$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutViewImpl, $Util.$makeClassName('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl'));


LayoutView.$markImplementor(LayoutViewImpl);


exports = LayoutViewImpl; 
//# sourceMappingURL=LayoutViewImpl.js.map