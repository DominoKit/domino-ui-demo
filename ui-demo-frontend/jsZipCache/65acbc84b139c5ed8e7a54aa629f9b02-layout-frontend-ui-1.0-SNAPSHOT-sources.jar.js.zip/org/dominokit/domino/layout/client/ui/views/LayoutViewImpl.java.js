/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _LayoutView = goog.require('org.dominokit.domino.layout.client.views.LayoutView');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _HTMLParagraphElement_$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _MouseEvent_$Overlay = goog.require('elemental2.dom.MouseEvent.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Js = goog.require('jsinterop.base.Js');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$2');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _SelectionHandler = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Layout = goog.require('org.dominokit.domino.ui.layout.Layout');
const _ScrollTop = goog.require('org.dominokit.domino.ui.scroll.ScrollTop');
const _Search = goog.require('org.dominokit.domino.ui.search.Search');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Theme = goog.require('org.dominokit.domino.ui.themes.Theme');
const _ThemeChangeHandler = goog.require('org.dominokit.domino.ui.themes.Theme.ThemeChangeHandler');
const _SafeHtmlBuilder = goog.require('org.gwtproject.safehtml.shared.SafeHtmlBuilder');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var LayoutViewImpl = goog.require('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl$impl');
exports = LayoutViewImpl;
 