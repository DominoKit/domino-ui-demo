/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.LayoutUIClientModule.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.LayoutUIClientModule');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var LayoutUIClientModule = goog.require('org.dominokit.domino.layout.client.LayoutUIClientModule$impl');
exports = LayoutUIClientModule;
 