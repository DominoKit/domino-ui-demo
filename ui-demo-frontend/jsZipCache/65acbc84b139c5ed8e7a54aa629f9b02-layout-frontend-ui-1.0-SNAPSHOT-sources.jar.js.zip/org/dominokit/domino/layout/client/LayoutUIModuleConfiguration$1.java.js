/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.LayoutUIModuleConfiguration$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.LayoutUIModuleConfiguration.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _LayoutUIModuleConfiguration = goog.require('org.dominokit.domino.layout.client.LayoutUIModuleConfiguration');
const _LayoutViewImpl = goog.require('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.layout.client.LayoutUIModuleConfiguration.$1$impl');
exports = $1;
 