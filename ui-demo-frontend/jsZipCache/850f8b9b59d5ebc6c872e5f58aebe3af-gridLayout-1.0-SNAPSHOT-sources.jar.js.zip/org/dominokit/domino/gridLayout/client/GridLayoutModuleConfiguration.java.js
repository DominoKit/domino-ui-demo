/**
 * @fileoverview transpiled from org.dominokit.domino.gridLayout.client.GridLayoutModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gridLayout.client.GridLayoutModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _$1 = goog.require('org.dominokit.domino.gridLayout.client.GridLayoutModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.gridLayout.client.GridLayoutModuleConfiguration.$2');
const _GridLayoutPresenterListenerForLayoutsEvent = goog.require('org.dominokit.domino.gridLayout.client.listeners.GridLayoutPresenterListenerForLayoutsEvent');
const _GridLayoutPresenter = goog.require('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenter');
const _GridLayoutPresenterCommand = goog.require('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand');
const _LayoutsEvent = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent');


// Re-exports the implementation.
var GridLayoutModuleConfiguration = goog.require('org.dominokit.domino.gridLayout.client.GridLayoutModuleConfiguration$impl');
exports = GridLayoutModuleConfiguration;
 