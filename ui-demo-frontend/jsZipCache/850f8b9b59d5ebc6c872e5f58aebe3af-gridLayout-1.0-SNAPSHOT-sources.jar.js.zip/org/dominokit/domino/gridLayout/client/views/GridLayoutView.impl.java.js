/**
 * @fileoverview transpiled from org.dominokit.domino.gridLayout.client.views.GridLayoutView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gridLayout.client.views.GridLayoutView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.gridLayout.client.views.GridLayoutView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class GridLayoutView {
  /**
   * @param {?function():Content} fn
   * @return {GridLayoutView}
   * @public
   */
  static $adapt(fn) {
    GridLayoutView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_gridLayout_client_views_GridLayoutView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_gridLayout_client_views_GridLayoutView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_gridLayout_client_views_GridLayoutView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridLayoutView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.gridLayout.client.views.GridLayoutView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(GridLayoutView, $Util.$makeClassName('org.dominokit.domino.gridLayout.client.views.GridLayoutView'));


GridLayoutView.$markImplementor(/** @type {Function} */ (GridLayoutView));


exports = GridLayoutView; 
//# sourceMappingURL=GridLayoutView.js.map