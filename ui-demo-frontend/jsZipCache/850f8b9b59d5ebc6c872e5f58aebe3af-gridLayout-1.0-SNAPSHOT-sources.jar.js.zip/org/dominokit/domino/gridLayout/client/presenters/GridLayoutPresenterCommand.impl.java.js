/**
 * @fileoverview transpiled from org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let GridLayoutPresenter = goog.forwardDeclare('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenter$impl');


/**
 * @extends {PresenterCommand<GridLayoutPresenter>}
  */
class GridLayoutPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GridLayoutPresenterCommand()'.
   * @return {!GridLayoutPresenterCommand}
   * @public
   */
  static $create__() {
    GridLayoutPresenterCommand.$clinit();
    let $instance = new GridLayoutPresenterCommand();
    $instance.$ctor__org_dominokit_domino_gridLayout_client_presenters_GridLayoutPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GridLayoutPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gridLayout_client_presenters_GridLayoutPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GridLayoutPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GridLayoutPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridLayoutPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GridLayoutPresenterCommand, $Util.$makeClassName('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand'));




exports = GridLayoutPresenterCommand; 
//# sourceMappingURL=GridLayoutPresenterCommand.js.map