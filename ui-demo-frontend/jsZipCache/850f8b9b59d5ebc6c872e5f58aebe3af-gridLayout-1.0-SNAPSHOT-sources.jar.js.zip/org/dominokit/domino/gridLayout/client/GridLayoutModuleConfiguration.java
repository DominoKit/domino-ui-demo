package org.dominokit.domino.gridLayout.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.gridLayout.client.listeners.GridLayoutPresenterListenerForLayoutsEvent;
import org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenter;
import org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand;
import org.dominokit.domino.gridLayout.client.views.ui.GridLayoutViewImpl;
import org.dominokit.domino.layouts.shared.extension.LayoutsEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class GridLayoutModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(GridLayoutPresenter.class.getCanonicalName(), GridLayoutPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new GridLayoutPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(GridLayoutPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new GridLayoutViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(GridLayoutPresenterCommand.class.getCanonicalName(), GridLayoutPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(LayoutsEvent.class, new GridLayoutPresenterListenerForLayoutsEvent());
  }
}
