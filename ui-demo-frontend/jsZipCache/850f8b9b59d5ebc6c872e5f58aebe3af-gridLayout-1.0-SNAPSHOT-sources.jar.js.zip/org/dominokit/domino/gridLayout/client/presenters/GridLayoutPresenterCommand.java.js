/**
 * @fileoverview transpiled from org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _GridLayoutPresenter = goog.require('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenter');


// Re-exports the implementation.
var GridLayoutPresenterCommand = goog.require('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand$impl');
exports = GridLayoutPresenterCommand;
 