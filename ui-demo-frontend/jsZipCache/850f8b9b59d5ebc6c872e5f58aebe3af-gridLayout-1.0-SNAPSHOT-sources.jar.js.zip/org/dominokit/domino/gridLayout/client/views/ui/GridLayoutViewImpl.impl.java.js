/**
 * @fileoverview transpiled from org.dominokit.domino.gridLayout.client.views.ui.GridLayoutViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gridLayout.client.views.ui.GridLayoutViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const GridLayoutView = goog.require('org.dominokit.domino.gridLayout.client.views.GridLayoutView$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Code = goog.forwardDeclare('org.dominokit.domino.ui.code.Code$impl');
let CheckBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let GridLayout = goog.forwardDeclare('org.dominokit.domino.ui.grid.GridLayout$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let SectionSpan = goog.forwardDeclare('org.dominokit.domino.ui.grid.SectionSpan$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Slider = goog.forwardDeclare('org.dominokit.domino.ui.sliders.Slider$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {GridLayoutView}
  */
class GridLayoutViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'GridLayoutViewImpl()'.
   * @return {!GridLayoutViewImpl}
   * @public
   */
  static $create__() {
    GridLayoutViewImpl.$clinit();
    let $instance = new GridLayoutViewImpl();
    $instance.$ctor__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GridLayoutViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(GridLayoutViewImpl.f_MODULE_NAME__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("GRID LAYOUT", "12 Columns based custom layout.").m_asElement__());
    this.m_initLayoutSamples___$p_org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initLayoutSamples___$p_org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl() {
    let gridLayout = /**@type {GridLayout} */ ($Casts.$to(GridLayout.m_create__().m_style__().m_setHeight__java_lang_String("500px").m_get__(), GridLayout));
    gridLayout.m_getContentElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-layout-section", "demo-content"], j_l_String)));
    gridLayout.m_getHeaderElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-layout-section", "demo-header"], j_l_String)));
    gridLayout.m_getFooterElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-layout-section", "demo-l-footer"], j_l_String)));
    gridLayout.m_getLeftElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-layout-section", "demo-left"], j_l_String)));
    gridLayout.m_getRightElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-layout-section", "demo-right"], j_l_String)));
    gridLayout.m_getContentElement__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Content"), HtmlContentBuilder)).m_asElement__());
    gridLayout.m_getHeaderElement__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Header"), HtmlContentBuilder)).m_asElement__());
    gridLayout.m_getFooterElement__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Footer"), HtmlContentBuilder)).m_asElement__());
    gridLayout.m_getLeftElement__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Left"), HtmlContentBuilder)).m_asElement__());
    gridLayout.m_getRightElement__().m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Right"), HtmlContentBuilder)).m_asElement__());
    let headerSlider = Slider.m_create__double__double__double(6, 0, 0).m_withThumb__().m_setStep__double(1);
    headerSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value) =>{
      if (Double.m_doubleValue__java_lang_Double(value) == 0) {
        gridLayout.m_hideHeader__();
      } else {
        gridLayout.m_setHeaderSpan__org_dominokit_domino_ui_grid_SectionSpan(SectionSpan.m_valueOf__java_lang_String("_" + j_l_String.m_valueOf__java_lang_Object(value)));
      }
    })));
    let leftSlider = Slider.m_create__double__double__double(6, 0, 0).m_withThumb__().m_setStep__double(1);
    let leftSpanUpCheck = CheckBox.m_create__java_lang_String("Span Up");
    let leftSpanDownCheck = CheckBox.m_create__java_lang_String("Span Down");
    leftSpanUpCheck.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value$1$) =>{
      if (leftSlider.m_getValue__() > 0) {
        gridLayout.m_setLeftSpan__org_dominokit_domino_ui_grid_SectionSpan__boolean__boolean(SectionSpan.m_valueOf__java_lang_String("_" + leftSlider.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(value$1$), Boolean.m_booleanValue__java_lang_Boolean(leftSpanDownCheck.m_getValue__()));
      }
    })));
    leftSpanDownCheck.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value$2$) =>{
      if (leftSlider.m_getValue__() > 0) {
        gridLayout.m_setLeftSpan__org_dominokit_domino_ui_grid_SectionSpan__boolean__boolean(SectionSpan.m_valueOf__java_lang_String("_" + leftSlider.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(leftSpanUpCheck.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(value$2$));
      }
    })));
    leftSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$3$) =>{
      if (Double.m_doubleValue__java_lang_Double(value$3$) == 0) {
        gridLayout.m_hideLeft__();
      } else {
        gridLayout.m_setLeftSpan__org_dominokit_domino_ui_grid_SectionSpan__boolean__boolean(SectionSpan.m_valueOf__java_lang_String("_" + j_l_String.m_valueOf__java_lang_Object(value$3$)), Boolean.m_booleanValue__java_lang_Boolean(leftSpanUpCheck.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(leftSpanDownCheck.m_getValue__()));
      }
    })));
    let rightSlider = Slider.m_create__double__double__double(6, 0, 0).m_withThumb__().m_setStep__double(1);
    let rightSpanUpCheck = CheckBox.m_create__java_lang_String("Span Up");
    let rightSpanDownCheck = CheckBox.m_create__java_lang_String("Span Down");
    rightSpanUpCheck.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value$4$) =>{
      if (rightSlider.m_getValue__() > 0) {
        gridLayout.m_setRightSpan__org_dominokit_domino_ui_grid_SectionSpan__boolean__boolean(SectionSpan.m_valueOf__java_lang_String("_" + rightSlider.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(value$4$), Boolean.m_booleanValue__java_lang_Boolean(rightSpanDownCheck.m_getValue__()));
      }
    })));
    rightSpanDownCheck.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value$5$) =>{
      if (rightSlider.m_getValue__() > 0) {
        gridLayout.m_setRightSpan__org_dominokit_domino_ui_grid_SectionSpan__boolean__boolean(SectionSpan.m_valueOf__java_lang_String("_" + rightSlider.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(rightSpanUpCheck.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(value$5$));
      }
    })));
    rightSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$6$) =>{
      if (Double.m_doubleValue__java_lang_Double(value$6$) == 0) {
        gridLayout.m_hideRight__();
      } else {
        gridLayout.m_setRightSpan__org_dominokit_domino_ui_grid_SectionSpan__boolean__boolean(SectionSpan.m_valueOf__java_lang_String("_" + j_l_String.m_valueOf__java_lang_Object(value$6$)), Boolean.m_booleanValue__java_lang_Boolean(rightSpanUpCheck.m_getValue__()), Boolean.m_booleanValue__java_lang_Boolean(rightSpanDownCheck.m_getValue__()));
      }
    })));
    let footerSlider = Slider.m_create__double__double__double(6, 0, 0).m_withThumb__().m_setStep__double(1);
    footerSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$7$) =>{
      if (Double.m_doubleValue__java_lang_Double(value$7$) == 0) {
        gridLayout.m_hideFooter__();
      } else {
        gridLayout.m_setFooterSpan__org_dominokit_domino_ui_grid_SectionSpan(SectionSpan.m_valueOf__java_lang_String("_" + j_l_String.m_valueOf__java_lang_Object(value$7$)));
      }
    })));
    let gapSlider = Slider.m_create__double__double__double(10, 0, 0).m_withThumb__().m_setStep__double(1).m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$8$) =>{
      gridLayout.m_setGap__java_lang_String(j_l_String.m_valueOf__java_lang_Object(value$8$) + "px");
    })));
    this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_.appendChild(Card.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(headerSlider), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Header"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(leftSlider), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Left"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(leftSpanUpCheck), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(leftSpanDownCheck), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(rightSlider), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Right"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(rightSpanUpCheck), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(rightSpanDownCheck), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(footerSlider), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Footer"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(gapSlider), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Gap"), IsElement))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(gridLayout).m_asElement__());
    this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_.appendChild(Card.m_create__java_lang_String("USAGE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("Basic", "Grid layout is a 12 columns grid based layout with a content section and another 4 optional sections: Header. Footer, Left and Right. ").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://developer.mozilla.org/en-US/docs/Web/CSS/grid"), HtmlContentBuilder)).m_textContent__java_lang_String("Please checkout css grid on MDN"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__())).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("The GridLayout is a single div element that can hold up to 5 other divs for each section"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("The Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Content section is the only section in the GridLayout by default, it covers all 12 rows and columns of the grid by default."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Creating a grid layout"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("GridLayout gridLayout = GridLayout.create()\n" + "                .style()\n" + "                .setHeight(\"500px\").get();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will create a gridlayout of 500px."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Changing a section size"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("gridLayout.setHeaderSpan(SectionSpan._2);\n" + "gridLayout.setLeftSpan(SectionSpan._3);\n" + "gridLayout.setRightSpan(SectionSpan._4);\n" + "gridLayout.setFooterSpan(SectionSpan._2);")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("You can span a section to cover up to 6 rows or columns."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Adding elements to the gridLayout sections"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("gridLayout.getContentElement().appendChild(otherElement);\n" + "gridLayout.getHeaderElement().appendChild(otherElement);\n" + "gridLayout.getLeftElement().appendChild(otherElement);\n" + "gridLayout.getRightElement().appendChild(otherElement);\n" + "gridLayout.getFooterElement().appendChild(otherElement);\n")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("You have to span a section to make the appended elements show up."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Hiding a section"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("gridLayout.hideHeader();\n" + "gridLayout.hideLeft();\n" + "gridLayout.hideRight();\n" + "gridLayout.hideFooter();\n")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("You can hide all sections except the content section."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl() {
    this.f_element__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GridLayoutViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GridLayoutViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridLayoutViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Code = goog.module.get('org.dominokit.domino.ui.code.Code$impl');
    CheckBox = goog.module.get('org.dominokit.domino.ui.forms.CheckBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    GridLayout = goog.module.get('org.dominokit.domino.ui.grid.GridLayout$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    SectionSpan = goog.module.get('org.dominokit.domino.ui.grid.SectionSpan$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Slider = goog.module.get('org.dominokit.domino.ui.sliders.Slider$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GridLayoutViewImpl, $Util.$makeClassName('org.dominokit.domino.gridLayout.client.views.ui.GridLayoutViewImpl'));


/** @public {?string} @const */
GridLayoutViewImpl.f_MODULE_NAME__org_dominokit_domino_gridLayout_client_views_ui_GridLayoutViewImpl = "gridLayout";


GridLayoutView.$markImplementor(GridLayoutViewImpl);


exports = GridLayoutViewImpl; 
//# sourceMappingURL=GridLayoutViewImpl.js.map