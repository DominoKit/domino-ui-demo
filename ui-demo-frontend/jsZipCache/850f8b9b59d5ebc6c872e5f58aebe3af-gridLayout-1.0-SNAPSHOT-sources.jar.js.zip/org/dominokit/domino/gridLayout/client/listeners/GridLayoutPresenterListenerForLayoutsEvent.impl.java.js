/**
 * @fileoverview transpiled from org.dominokit.domino.gridLayout.client.listeners.GridLayoutPresenterListenerForLayoutsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gridLayout.client.listeners.GridLayoutPresenterListenerForLayoutsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let GridLayoutPresenter = goog.forwardDeclare('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenter$impl');
let GridLayoutPresenterCommand = goog.forwardDeclare('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand$impl');
let LayoutsEvent = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<LayoutsEvent>}
  */
class GridLayoutPresenterListenerForLayoutsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GridLayoutPresenterListenerForLayoutsEvent()'.
   * @return {!GridLayoutPresenterListenerForLayoutsEvent}
   * @public
   */
  static $create__() {
    GridLayoutPresenterListenerForLayoutsEvent.$clinit();
    let $instance = new GridLayoutPresenterListenerForLayoutsEvent();
    $instance.$ctor__org_dominokit_domino_gridLayout_client_listeners_GridLayoutPresenterListenerForLayoutsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GridLayoutPresenterListenerForLayoutsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gridLayout_client_listeners_GridLayoutPresenterListenerForLayoutsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_layouts_shared_extension_LayoutsEvent(event) {
    GridLayoutPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** GridLayoutPresenter */ presenter) =>{
      presenter.m_listenToLayoutsEvent__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext(/**@type {LayoutsEventContext} */ ($Casts.$to(event.m_context__(), LayoutsEventContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_layouts_shared_extension_LayoutsEvent(/**@type {LayoutsEvent} */ ($Casts.$to(arg0, LayoutsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GridLayoutPresenterListenerForLayoutsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GridLayoutPresenterListenerForLayoutsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridLayoutPresenterListenerForLayoutsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    GridLayoutPresenterCommand = goog.module.get('org.dominokit.domino.gridLayout.client.presenters.GridLayoutPresenterCommand$impl');
    LayoutsEvent = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
    LayoutsEventContext = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GridLayoutPresenterListenerForLayoutsEvent, $Util.$makeClassName('org.dominokit.domino.gridLayout.client.listeners.GridLayoutPresenterListenerForLayoutsEvent'));


DominoEventListener.$markImplementor(GridLayoutPresenterListenerForLayoutsEvent);


exports = GridLayoutPresenterListenerForLayoutsEvent; 
//# sourceMappingURL=GridLayoutPresenterListenerForLayoutsEvent.js.map