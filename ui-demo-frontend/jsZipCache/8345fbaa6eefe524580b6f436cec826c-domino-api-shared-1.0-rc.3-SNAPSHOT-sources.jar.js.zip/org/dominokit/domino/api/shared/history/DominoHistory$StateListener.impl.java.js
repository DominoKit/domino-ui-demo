/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$StateListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let State = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.StateListener.$LambdaAdaptor$impl');


/**
 * @interface
 */
class StateListener {
  /**
   * @abstract
   * @param {State} state
   * @return {void}
   * @public
   */
  m_onPopState__org_dominokit_domino_api_shared_history_DominoHistory_State(state) {
  }
  
  /**
   * @param {?function(State):void} fn
   * @return {StateListener}
   * @public
   */
  static $adapt(fn) {
    StateListener.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_StateListener = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_DominoHistory_StateListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_StateListener;
  }
  
  /**
   * @public
   */
  static $clinit() {
    StateListener.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.StateListener.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(StateListener, $Util.$makeClassName('org.dominokit.domino.api.shared.history.DominoHistory$StateListener'));


StateListener.$markImplementor(/** @type {Function} */ (StateListener));


exports = StateListener; 
//# sourceMappingURL=DominoHistory$StateListener.js.map