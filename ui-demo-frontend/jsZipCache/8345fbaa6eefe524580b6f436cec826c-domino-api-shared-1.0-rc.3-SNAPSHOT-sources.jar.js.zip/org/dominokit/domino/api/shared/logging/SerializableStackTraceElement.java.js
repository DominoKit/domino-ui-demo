/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.logging.SerializableStackTraceElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.logging.SerializableStackTraceElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var SerializableStackTraceElement = goog.require('org.dominokit.domino.api.shared.logging.SerializableStackTraceElement$impl');
exports = SerializableStackTraceElement;
 