/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.Contribution.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.Contribution$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution.$LambdaAdaptor$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');


/**
 * @interface
 * @template C_E
 */
class Contribution {
  /**
   * @abstract
   * @param {C_E} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPoint) {
  }
  
  /**
   * @template C_E
   * @param {?function(C_E):void} fn
   * @return {Contribution<C_E>}
   * @public
   */
  static $adapt(fn) {
    Contribution.$clinit();
    return /**@type {!$LambdaAdaptor<ExtensionPoint>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_Contribution = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_Contribution;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_Contribution;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Contribution.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.extension.Contribution.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Contribution, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.Contribution'));


Contribution.$markImplementor(/** @type {Function} */ (Contribution));


exports = Contribution; 
//# sourceMappingURL=Contribution.js.map