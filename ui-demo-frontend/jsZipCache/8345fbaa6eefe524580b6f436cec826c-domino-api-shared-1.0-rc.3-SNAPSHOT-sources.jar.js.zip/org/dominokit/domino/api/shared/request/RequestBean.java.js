/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.RequestBean.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.request.RequestBean');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _$Util = goog.require('nativebootstrap.Util');
const _VoidRequest = goog.require('org.dominokit.domino.api.shared.request.VoidRequest');


// Re-exports the implementation.
var RequestBean = goog.require('org.dominokit.domino.api.shared.request.RequestBean$impl');
exports = RequestBean;
 