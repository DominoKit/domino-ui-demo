/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.Context.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.Context$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class Context {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_Context = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_Context;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_Context;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Context.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Context, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.Context'));


Context.$markImplementor(/** @type {Function} */ (Context));


exports = Context; 
//# sourceMappingURL=Context.js.map