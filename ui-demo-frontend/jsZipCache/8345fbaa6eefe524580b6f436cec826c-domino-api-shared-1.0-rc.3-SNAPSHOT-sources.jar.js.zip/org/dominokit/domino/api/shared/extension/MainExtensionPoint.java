package org.dominokit.domino.api.shared.extension;

public interface MainExtensionPoint extends ExtensionPoint<MainContext>{
}
