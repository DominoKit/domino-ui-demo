/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.logging.SerializableThrowable.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.logging.SerializableThrowable$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let SerializableStackTraceElement = goog.forwardDeclare('org.dominokit.domino.api.shared.logging.SerializableStackTraceElement$impl');


/**
 * @implements {Serializable}
  */
class SerializableThrowable extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_type__org_dominokit_domino_api_shared_logging_SerializableThrowable;
    /** @public {?string} */
    this.f_message__org_dominokit_domino_api_shared_logging_SerializableThrowable;
    /** @public {SerializableThrowable} */
    this.f_cause__org_dominokit_domino_api_shared_logging_SerializableThrowable;
    /** @public {Array<SerializableStackTraceElement>} */
    this.f_stackTrace__org_dominokit_domino_api_shared_logging_SerializableThrowable;
  }
  
  /**
   * Factory method corresponding to constructor 'SerializableThrowable()'.
   * @return {!SerializableThrowable}
   * @public
   */
  static $create__() {
    SerializableThrowable.$clinit();
    let $instance = new SerializableThrowable();
    $instance.$ctor__org_dominokit_domino_api_shared_logging_SerializableThrowable__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SerializableThrowable()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_logging_SerializableThrowable__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SerializableThrowable;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SerializableThrowable);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SerializableThrowable.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SerializableThrowable, $Util.$makeClassName('org.dominokit.domino.api.shared.logging.SerializableThrowable'));


Serializable.$markImplementor(SerializableThrowable);


exports = SerializableThrowable; 
//# sourceMappingURL=SerializableThrowable.js.map