/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.logging.SerializableStackTraceElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.logging.SerializableStackTraceElement$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @implements {Serializable}
  */
class SerializableStackTraceElement extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_className__org_dominokit_domino_api_shared_logging_SerializableStackTraceElement;
    /** @public {?string} */
    this.f_fileName__org_dominokit_domino_api_shared_logging_SerializableStackTraceElement;
    /** @public {?string} */
    this.f_methodName__org_dominokit_domino_api_shared_logging_SerializableStackTraceElement;
    /** @public {number} */
    this.f_lineNumber__org_dominokit_domino_api_shared_logging_SerializableStackTraceElement = 0;
  }
  
  /**
   * Factory method corresponding to constructor 'SerializableStackTraceElement()'.
   * @return {!SerializableStackTraceElement}
   * @public
   */
  static $create__() {
    SerializableStackTraceElement.$clinit();
    let $instance = new SerializableStackTraceElement();
    $instance.$ctor__org_dominokit_domino_api_shared_logging_SerializableStackTraceElement__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SerializableStackTraceElement()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_logging_SerializableStackTraceElement__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SerializableStackTraceElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SerializableStackTraceElement);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SerializableStackTraceElement.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SerializableStackTraceElement, $Util.$makeClassName('org.dominokit.domino.api.shared.logging.SerializableStackTraceElement'));


Serializable.$markImplementor(SerializableStackTraceElement);


exports = SerializableStackTraceElement; 
//# sourceMappingURL=SerializableStackTraceElement.js.map