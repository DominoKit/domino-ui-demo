/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$DirectUrlHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler.$LambdaAdaptor$impl');
let State = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');


/**
 * @interface
 */
class DirectUrlHandler {
  /**
   * @abstract
   * @param {State} state
   * @return {void}
   * @public
   */
  m_handle__org_dominokit_domino_api_shared_history_DominoHistory_State(state) {
  }
  
  /**
   * @param {?function(State):void} fn
   * @return {DirectUrlHandler}
   * @public
   */
  static $adapt(fn) {
    DirectUrlHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DirectUrlHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DirectUrlHandler, $Util.$makeClassName('org.dominokit.domino.api.shared.history.DominoHistory$DirectUrlHandler'));


DirectUrlHandler.$markImplementor(/** @type {Function} */ (DirectUrlHandler));


exports = DirectUrlHandler; 
//# sourceMappingURL=DominoHistory$DirectUrlHandler.js.map