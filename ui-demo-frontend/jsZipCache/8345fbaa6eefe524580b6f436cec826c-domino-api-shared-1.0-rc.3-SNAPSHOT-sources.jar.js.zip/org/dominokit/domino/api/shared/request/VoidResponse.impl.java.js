/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.VoidResponse.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.request.VoidResponse$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @implements {ResponseBean}
  */
class VoidResponse extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'VoidResponse()'.
   * @return {!VoidResponse}
   * @public
   */
  static $create__() {
    VoidResponse.$clinit();
    let $instance = new VoidResponse();
    $instance.$ctor__org_dominokit_domino_api_shared_request_VoidResponse__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'VoidResponse()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_request_VoidResponse__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof VoidResponse;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, VoidResponse);
  }
  
  /**
   * @public
   */
  static $clinit() {
    VoidResponse.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(VoidResponse, $Util.$makeClassName('org.dominokit.domino.api.shared.request.VoidResponse'));


ResponseBean.$markImplementor(VoidResponse);


exports = VoidResponse; 
//# sourceMappingURL=VoidResponse.js.map