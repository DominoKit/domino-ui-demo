/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.MainExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');

let MainContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ExtensionPoint<MainContext>}
 */
class MainExtensionPoint {
  /**
   * @param {?function():MainContext} fn
   * @return {MainExtensionPoint}
   * @public
   */
  static $adapt(fn) {
    MainExtensionPoint.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ExtensionPoint.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_MainExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MainExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.extension.MainExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MainExtensionPoint, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.MainExtensionPoint'));


MainExtensionPoint.$markImplementor(/** @type {Function} */ (MainExtensionPoint));


exports = MainExtensionPoint; 
//# sourceMappingURL=MainExtensionPoint.js.map