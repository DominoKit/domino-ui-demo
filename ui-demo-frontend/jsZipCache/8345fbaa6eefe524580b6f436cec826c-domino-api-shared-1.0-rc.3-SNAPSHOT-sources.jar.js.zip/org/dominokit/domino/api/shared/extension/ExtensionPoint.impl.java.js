/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.ExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Context = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Context$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_C
 */
class ExtensionPoint {
  /**
   * @abstract
   * @return {C_C}
   * @public
   */
  m_context__() {
  }
  
  /**
   * @template C_C
   * @param {?function():C_C} fn
   * @return {ExtensionPoint<C_C>}
   * @public
   */
  static $adapt(fn) {
    ExtensionPoint.$clinit();
    return /**@type {!$LambdaAdaptor<Context>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_ExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_ExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_ExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.extension.ExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ExtensionPoint, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.ExtensionPoint'));


ExtensionPoint.$markImplementor(/** @type {Function} */ (ExtensionPoint));


exports = ExtensionPoint; 
//# sourceMappingURL=ExtensionPoint.js.map