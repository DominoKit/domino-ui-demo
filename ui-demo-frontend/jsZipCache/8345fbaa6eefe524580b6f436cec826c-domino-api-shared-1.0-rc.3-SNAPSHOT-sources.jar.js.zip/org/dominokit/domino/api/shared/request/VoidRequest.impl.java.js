/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.VoidRequest.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.request.VoidRequest$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestBean = goog.require('org.dominokit.domino.api.shared.request.RequestBean$impl');


/**
 * @implements {RequestBean}
  */
class VoidRequest extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'VoidRequest()'.
   * @return {!VoidRequest}
   * @public
   */
  static $create__() {
    VoidRequest.$clinit();
    let $instance = new VoidRequest();
    $instance.$ctor__org_dominokit_domino_api_shared_request_VoidRequest__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'VoidRequest()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_request_VoidRequest__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof VoidRequest;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, VoidRequest);
  }
  
  /**
   * @public
   */
  static $clinit() {
    VoidRequest.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(VoidRequest, $Util.$makeClassName('org.dominokit.domino.api.shared.request.VoidRequest'));


RequestBean.$markImplementor(VoidRequest);


exports = VoidRequest; 
//# sourceMappingURL=VoidRequest.js.map