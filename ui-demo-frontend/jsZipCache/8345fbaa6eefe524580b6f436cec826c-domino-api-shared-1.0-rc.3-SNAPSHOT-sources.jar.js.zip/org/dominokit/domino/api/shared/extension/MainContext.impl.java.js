/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.MainContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.MainContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Context = goog.require('org.dominokit.domino.api.shared.extension.Context$impl');


/**
 * @interface
 * @extends {Context}
 */
class MainContext {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Context.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_MainContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MainContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(MainContext, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.MainContext'));


MainContext.$markImplementor(/** @type {Function} */ (MainContext));


exports = MainContext; 
//# sourceMappingURL=MainContext.js.map