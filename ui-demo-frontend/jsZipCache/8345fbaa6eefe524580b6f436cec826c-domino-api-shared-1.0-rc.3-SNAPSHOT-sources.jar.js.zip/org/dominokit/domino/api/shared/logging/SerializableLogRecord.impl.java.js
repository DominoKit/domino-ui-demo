/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.logging.SerializableLogRecord.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.logging.SerializableLogRecord$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let SerializableThrowable = goog.forwardDeclare('org.dominokit.domino.api.shared.logging.SerializableThrowable$impl');


/**
 * @implements {Serializable}
  */
class SerializableLogRecord extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_level__org_dominokit_domino_api_shared_logging_SerializableLogRecord;
    /** @public {?string} */
    this.f_message__org_dominokit_domino_api_shared_logging_SerializableLogRecord;
    /** @public {!$Long} */
    this.f_millis__org_dominokit_domino_api_shared_logging_SerializableLogRecord = $Long.fromInt(0);
    /** @public {SerializableThrowable} */
    this.f_thrown__org_dominokit_domino_api_shared_logging_SerializableLogRecord;
    /** @public {?string} */
    this.f_loggerName__org_dominokit_domino_api_shared_logging_SerializableLogRecord;
    /** @public {?string} */
    this.f_permutationStrongName__org_dominokit_domino_api_shared_logging_SerializableLogRecord;
  }
  
  /**
   * Factory method corresponding to constructor 'SerializableLogRecord()'.
   * @return {!SerializableLogRecord}
   * @public
   */
  static $create__() {
    SerializableLogRecord.$clinit();
    let $instance = new SerializableLogRecord();
    $instance.$ctor__org_dominokit_domino_api_shared_logging_SerializableLogRecord__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SerializableLogRecord()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_logging_SerializableLogRecord__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SerializableLogRecord;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SerializableLogRecord);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SerializableLogRecord.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SerializableLogRecord, $Util.$makeClassName('org.dominokit.domino.api.shared.logging.SerializableLogRecord'));


Serializable.$markImplementor(SerializableLogRecord);


exports = SerializableLogRecord; 
//# sourceMappingURL=SerializableLogRecord.js.map