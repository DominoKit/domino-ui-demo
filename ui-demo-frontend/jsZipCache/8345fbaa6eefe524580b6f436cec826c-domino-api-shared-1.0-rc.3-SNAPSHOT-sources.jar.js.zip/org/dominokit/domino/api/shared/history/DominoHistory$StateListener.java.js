/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$StateListener.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.StateListener');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener.$LambdaAdaptor');


// Re-exports the implementation.
var StateListener = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
exports = StateListener;
 