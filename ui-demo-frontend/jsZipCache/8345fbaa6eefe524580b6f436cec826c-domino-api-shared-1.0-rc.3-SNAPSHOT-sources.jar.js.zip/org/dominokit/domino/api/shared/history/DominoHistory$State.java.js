/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$State.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.State');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken');


// Re-exports the implementation.
var State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');
exports = State;
 