/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DirectState = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectState');
const _StateListener = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener');
const _HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');


// Re-exports the implementation.
var DominoHistory = goog.require('org.dominokit.domino.api.shared.history.DominoHistory$impl');
exports = DominoHistory;
 