/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.logging.SerializableLogRecord.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.logging.SerializableLogRecord');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');
const _SerializableThrowable = goog.require('org.dominokit.domino.api.shared.logging.SerializableThrowable');


// Re-exports the implementation.
var SerializableLogRecord = goog.require('org.dominokit.domino.api.shared.logging.SerializableLogRecord$impl');
exports = SerializableLogRecord;
 