/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$DirectUrlHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler.$LambdaAdaptor');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');


// Re-exports the implementation.
var DirectUrlHandler = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');
exports = DirectUrlHandler;
 