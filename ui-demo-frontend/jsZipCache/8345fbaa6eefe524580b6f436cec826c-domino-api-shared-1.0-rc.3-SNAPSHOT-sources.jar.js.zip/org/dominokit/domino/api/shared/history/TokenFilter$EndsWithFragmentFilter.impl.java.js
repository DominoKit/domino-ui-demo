/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$EndsWithFragmentFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFragmentFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class EndsWithFragmentFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_postfix__org_dominokit_domino_api_shared_history_TokenFilter_EndsWithFragmentFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'EndsWithFragmentFilter(String)'.
   * @param {?string} postfix
   * @return {!EndsWithFragmentFilter}
   * @public
   */
  static $create__java_lang_String(postfix) {
    EndsWithFragmentFilter.$clinit();
    let $instance = new EndsWithFragmentFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_EndsWithFragmentFilter__java_lang_String(postfix);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EndsWithFragmentFilter(String)'.
   * @param {?string} postfix
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_EndsWithFragmentFilter__java_lang_String(postfix) {
    this.$ctor__java_lang_Object__();
    this.f_postfix__org_dominokit_domino_api_shared_history_TokenFilter_EndsWithFragmentFilter_ = postfix;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_endsWith__java_lang_String__java_lang_String(token.m_fragment__(), this.f_postfix__org_dominokit_domino_api_shared_history_TokenFilter_EndsWithFragmentFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EndsWithFragmentFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EndsWithFragmentFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EndsWithFragmentFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EndsWithFragmentFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$EndsWithFragmentFilter'));


TokenFilter.$markImplementor(EndsWithFragmentFilter);


exports = EndsWithFragmentFilter; 
//# sourceMappingURL=TokenFilter$EndsWithFragmentFilter.js.map