/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$DirectState.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.DirectState$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectState.$LambdaAdaptor$impl');
let DirectUrlHandler = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');


/**
 * @interface
 */
class DirectState {
  /**
   * @abstract
   * @param {DirectUrlHandler} handler
   * @return {void}
   * @public
   */
  m_onDirectUrl__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler(handler) {
  }
  
  /**
   * @param {?function(DirectUrlHandler):void} fn
   * @return {DirectState}
   * @public
   */
  static $adapt(fn) {
    DirectState.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_DirectState = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_DominoHistory_DirectState;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_DirectState;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DirectState.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory.DirectState.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DirectState, $Util.$makeClassName('org.dominokit.domino.api.shared.history.DominoHistory$DirectState'));


DirectState.$markImplementor(/** @type {Function} */ (DirectState));


exports = DirectState; 
//# sourceMappingURL=DominoHistory$DirectState.js.map