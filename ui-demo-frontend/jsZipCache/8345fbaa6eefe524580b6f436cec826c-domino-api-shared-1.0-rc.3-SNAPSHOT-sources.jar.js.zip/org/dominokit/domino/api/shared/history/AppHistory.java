package org.dominokit.domino.api.shared.history;

public interface AppHistory extends DominoHistory, CurrentStateHistory{
}
