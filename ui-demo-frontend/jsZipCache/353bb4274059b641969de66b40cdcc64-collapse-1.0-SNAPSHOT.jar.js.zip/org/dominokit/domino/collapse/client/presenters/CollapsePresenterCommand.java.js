/**
 * @fileoverview transpiled from org.dominokit.domino.collapse.client.presenters.CollapsePresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.collapse.client.presenters.CollapsePresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _CollapsePresenter = goog.require('org.dominokit.domino.collapse.client.presenters.CollapsePresenter');


// Re-exports the implementation.
var CollapsePresenterCommand = goog.require('org.dominokit.domino.collapse.client.presenters.CollapsePresenterCommand$impl');
exports = CollapsePresenterCommand;
 