/**
 * @fileoverview transpiled from org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const CollapseView = goog.require('org.dominokit.domino.collapse.client.views.CollapseView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl.$LambdaAdaptor$1$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Accordion = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Accordion$impl');
let AccordionPanel = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');
let Collapsible = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {CollapseView}
  */
class CollapseViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'CollapseViewImpl()'.
   * @return {!CollapseViewImpl}
   * @public
   */
  static $create__() {
    CollapseViewImpl.$clinit();
    let $instance = new CollapseViewImpl();
    $instance.$ctor__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CollapseViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(CollapseViewImpl.f_MODULE_NAME__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl, this.m_getClass__()).m_asElement__());
    this.m_example___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl();
    this.m_accordionSample___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl();
    this.m_colorFullWithIcons___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl();
    this.m_multiOpenItems___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_example___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl() {
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("COLLAPSE").m_asElement__());
    let well = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["well"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_asElement__(), $Overlay));
    let collapsible = Collapsible.m_create__elemental2_dom_HTMLElement(well);
    let collapsibleListener = new $LambdaAdaptor$1(((/** Event */ evt) =>{
      collapsible.m_toggleDisplay__();
    }));
    let anchorButton = Button.m_create__java_lang_String("LINK WITH HREF");
    anchorButton.m_getClickableElement__().addEventListener("click", collapsibleListener);
    let button = Button.m_create__java_lang_String("BUTTON");
    button.m_getClickableElement__().addEventListener("click", collapsibleListener);
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("EXAMPLE", "click the buttons below to show and hide another element via class changes.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(anchorButton.m_builder__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_m_b_15__org_dominokit_domino_ui_style_Styles], j_l_String))).m_build__(), Button)).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String("\n")).m_appendChild__elemental2_dom_Node(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(button.m_builder__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_m_b_15__org_dominokit_domino_ui_style_Styles], j_l_String))).m_build__(), Button)).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color), Button)).m_asElement__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(collapsible)), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(CollapseViewImpl.f_MODULE_NAME__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl, "example").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_accordionSample___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl() {
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("ACCORDION").m_asElement__());
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("BASIC EXAMPLES", "Extend the default collapse behavior to create an accordion with the panel component.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Primary"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Success"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_success__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Warning"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_warning__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Danger"), HtmlContentBuilder)).m_asElement__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_danger__())), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("FULL BODY EXAMPLES", "If you want to also colorful body, you need to use fullBody method.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Primary"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_fullBody__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Success"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_fullBody__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_success__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Warning"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_fullBody__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_warning__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Danger"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_fullBody__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_))).m_danger__())), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(CollapseViewImpl.f_MODULE_NAME__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl, "accordionSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_colorFullWithIcons___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl() {
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String("COLORFUL PANEL ITEMS WITH ICON").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Primary"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_perm_contact_calendar__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_download__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_contact_phone__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 4", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_shared__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String("FULL BODY COLORFUL PANEL ITEMS WITH ICON").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Panel Primary"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_fullBody__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_perm_contact_calendar__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_download__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_contact_phone__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 4", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_shared__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(CollapseViewImpl.f_MODULE_NAME__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl, "colorFullWithIcons").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_multiOpenItems___$p_org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl() {
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String("MULTIPLE ITEMS TO BE OPEN").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Accordion.m_create__().m_multiOpen__().m_fullBody__().m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 1", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_perm_contact_calendar__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 2", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_download__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(/**@type {AccordionPanel} */ ($Casts.$to(/**@type {AccordionPanel} */ ($Casts.$to(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 3", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_expand__(), AccordionPanel)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_contact_phone__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_expand__(), AccordionPanel))).m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(AccordionPanel.m_create__java_lang_String__elemental2_dom_Node("Collapsible item 4", TextNode.m_of__java_lang_String(CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_)).m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_shared__()).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(CollapseViewImpl.f_MODULE_NAME__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl, "multiOpenItems").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl() {
    this.f_element__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CollapseViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CollapseViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CollapseViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl.$LambdaAdaptor$1$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Accordion = goog.module.get('org.dominokit.domino.ui.collapsible.Accordion$impl');
    AccordionPanel = goog.module.get('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');
    Collapsible = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CollapseViewImpl, $Util.$makeClassName('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl'));


/** @public {?string} @const */
CollapseViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl_ = "Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.";


/** @public {?string} @const */
CollapseViewImpl.f_MODULE_NAME__org_dominokit_domino_collapse_client_views_ui_CollapseViewImpl = "collapse";


CollapseView.$markImplementor(CollapseViewImpl);


exports = CollapseViewImpl; 
//# sourceMappingURL=CollapseViewImpl.js.map