/**
 * @fileoverview transpiled from org.dominokit.domino.collapse.client.views.CollapseView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.collapse.client.views.CollapseView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.collapse.client.views.CollapseView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class CollapseView {
  /**
   * @param {?function():Content} fn
   * @return {CollapseView}
   * @public
   */
  static $adapt(fn) {
    CollapseView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_collapse_client_views_CollapseView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_collapse_client_views_CollapseView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_collapse_client_views_CollapseView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CollapseView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.collapse.client.views.CollapseView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CollapseView, $Util.$makeClassName('org.dominokit.domino.collapse.client.views.CollapseView'));


CollapseView.$markImplementor(/** @type {Function} */ (CollapseView));


exports = CollapseView; 
//# sourceMappingURL=CollapseView.js.map