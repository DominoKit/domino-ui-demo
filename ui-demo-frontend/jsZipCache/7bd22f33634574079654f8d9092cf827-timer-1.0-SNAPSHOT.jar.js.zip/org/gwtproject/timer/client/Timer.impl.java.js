/**
 * @fileoverview transpiled from org.gwtproject.timer.client.Timer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.timer.client.Timer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
  */
class Timer extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_isRepeating__org_gwtproject_timer_client_Timer_ = false;
    /** @public {?number} */
    this.f_timerId__org_gwtproject_timer_client_Timer_;
    /** @public {number} */
    this.f_cancelCounter__org_gwtproject_timer_client_Timer_ = 0;
  }
  
  /**
   * Initialization from constructor 'Timer()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_timer_client_Timer__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_gwtproject_timer_client_Timer();
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isRunning__() {
    return !$Equality.$same(this.f_timerId__org_gwtproject_timer_client_Timer_, null);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_cancel__() {
    if (!this.m_isRunning__()) {
      return;
    }
    this.f_cancelCounter__org_gwtproject_timer_client_Timer_++;
    if (this.f_isRepeating__org_gwtproject_timer_client_Timer_) {
      this.m_clearInterval__double_$p_org_gwtproject_timer_client_Timer(Double.m_doubleValue__java_lang_Double(this.f_timerId__org_gwtproject_timer_client_Timer_));
    } else {
      this.m_clearTimeout__double_$p_org_gwtproject_timer_client_Timer(Double.m_doubleValue__java_lang_Double(this.f_timerId__org_gwtproject_timer_client_Timer_));
    }
    this.f_timerId__org_gwtproject_timer_client_Timer_ = null;
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_run__() {
  }
  
  /**
   * @param {number} delayMillis
   * @return {void}
   * @public
   */
  m_schedule__int(delayMillis) {
    if (delayMillis < 0) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("must be non-negative"));
    }
    if (this.m_isRunning__()) {
      this.m_cancel__();
    }
    this.f_isRepeating__org_gwtproject_timer_client_Timer_ = false;
    this.f_timerId__org_gwtproject_timer_client_Timer_ = this.m_setTimeout__elemental2_dom_DomGlobal_SetTimeoutCallbackFn__int_$p_org_gwtproject_timer_client_Timer(this.m_createTimeoutCallback__org_gwtproject_timer_client_Timer__int_$p_org_gwtproject_timer_client_Timer(this, this.f_cancelCounter__org_gwtproject_timer_client_Timer_), delayMillis);
  }
  
  /**
   * @param {number} periodMillis
   * @return {void}
   * @public
   */
  m_scheduleRepeating__int(periodMillis) {
    if (periodMillis <= 0) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("must be positive"));
    }
    if (this.m_isRunning__()) {
      this.m_cancel__();
    }
    this.f_isRepeating__org_gwtproject_timer_client_Timer_ = true;
    this.f_timerId__org_gwtproject_timer_client_Timer_ = this.m_setInterval__elemental2_dom_DomGlobal_SetIntervalCallbackFn__int_$p_org_gwtproject_timer_client_Timer(this.m_createIntervalCallback__org_gwtproject_timer_client_Timer__int_$p_org_gwtproject_timer_client_Timer(this, this.f_cancelCounter__org_gwtproject_timer_client_Timer_), periodMillis);
  }
  
  /**
   * @param {number} scheduleCancelCounter
   * @return {void}
   * @public
   */
  m_fire__int_$pp_org_gwtproject_timer_client(scheduleCancelCounter) {
    if (scheduleCancelCounter != this.f_cancelCounter__org_gwtproject_timer_client_Timer_) {
      return;
    }
    if (!this.f_isRepeating__org_gwtproject_timer_client_Timer_) {
      this.f_timerId__org_gwtproject_timer_client_Timer_ = null;
    }
    this.m_run__();
  }
  
  /**
   * @param {Timer} timer
   * @param {number} cancelCounter
   * @return {?function(...*):void}
   * @public
   */
  m_createTimeoutCallback__org_gwtproject_timer_client_Timer__int_$p_org_gwtproject_timer_client_Timer(timer, cancelCounter) {
    return (/** @param {...*} callback */ (...callback) =>{
      timer.m_fire__int_$pp_org_gwtproject_timer_client(cancelCounter);
    });
  }
  
  /**
   * @param {Timer} timer
   * @param {number} cancelCounter
   * @return {?function(...*):void}
   * @public
   */
  m_createIntervalCallback__org_gwtproject_timer_client_Timer__int_$p_org_gwtproject_timer_client_Timer(timer, cancelCounter) {
    return (/** @param {...*} callback */ (...callback) =>{
      timer.m_fire__int_$pp_org_gwtproject_timer_client(cancelCounter);
    });
  }
  
  /**
   * @param {?function(...*):void} callback
   * @param {number} time
   * @return {number}
   * @public
   */
  m_setInterval__elemental2_dom_DomGlobal_SetIntervalCallbackFn__int_$p_org_gwtproject_timer_client_Timer(callback, time) {
    return $Overlay.m_setInterval__elemental2_dom_DomGlobal_SetIntervalCallbackFn__double__arrayOf_java_lang_Object(callback, time, []);
  }
  
  /**
   * @param {?function(...*):void} callback
   * @param {number} time
   * @return {number}
   * @public
   */
  m_setTimeout__elemental2_dom_DomGlobal_SetTimeoutCallbackFn__int_$p_org_gwtproject_timer_client_Timer(callback, time) {
    return $Overlay.m_setTimeout__elemental2_dom_DomGlobal_SetTimeoutCallbackFn__double__arrayOf_java_lang_Object(callback, time, []);
  }
  
  /**
   * @param {number} timerId
   * @return {void}
   * @public
   */
  m_clearInterval__double_$p_org_gwtproject_timer_client_Timer(timerId) {
    window.clearInterval(timerId);
  }
  
  /**
   * @param {number} timerId
   * @return {void}
   * @public
   */
  m_clearTimeout__double_$p_org_gwtproject_timer_client_Timer(timerId) {
    window.clearTimeout(timerId);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_gwtproject_timer_client_Timer() {
    this.f_timerId__org_gwtproject_timer_client_Timer_ = null;
    this.f_cancelCounter__org_gwtproject_timer_client_Timer_ = 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Timer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Timer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Timer.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Timer, $Util.$makeClassName('org.gwtproject.timer.client.Timer'));




exports = Timer; 
//# sourceMappingURL=Timer.js.map