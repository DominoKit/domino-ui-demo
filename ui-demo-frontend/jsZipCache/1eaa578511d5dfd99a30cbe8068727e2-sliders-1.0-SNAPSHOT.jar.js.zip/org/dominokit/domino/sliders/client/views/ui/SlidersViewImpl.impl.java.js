/**
 * @fileoverview transpiled from org.dominokit.domino.sliders.client.views.ui.SlidersViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.sliders.client.views.ui.SlidersViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const SlidersView = goog.require('org.dominokit.domino.sliders.client.views.SlidersView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Slider = goog.forwardDeclare('org.dominokit.domino.ui.sliders.Slider$impl');
let SlideHandler = goog.forwardDeclare('org.dominokit.domino.ui.sliders.Slider.SlideHandler$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {SlidersView}
  */
class SlidersViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_;
    /** @public {Card} */
    this.f_basicCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_;
    /** @public {Card} */
    this.f_colorsSlidersCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_;
    /** @public {Card} */
    this.f_sampleCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'SlidersViewImpl()'.
   * @return {!SlidersViewImpl}
   * @public
   */
  static $create__() {
    SlidersViewImpl.$clinit();
    let $instance = new SlidersViewImpl();
    $instance.$ctor__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SlidersViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(SlidersViewImpl.f_MODULE_NAME__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl, this.m_getClass__()).m_asElement__());
    this.f_basicCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_ = Card.m_create__java_lang_String("BASIC SLIDERS");
    this.f_colorsSlidersCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_ = Card.m_create__java_lang_String("SLIDERS WITH COLORS");
    this.f_sampleCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_ = Card.m_create__java_lang_String("SLIDERS EXAMPLE");
    this.m_initBasic___$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl();
    this.m_initColors___$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl();
    this.m_initExample___$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl();
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("SLIDERS").m_asElement__());
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(this.f_basicCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SlidersViewImpl.f_MODULE_NAME__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl, "basic").m_asElement__());
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(this.f_colorsSlidersCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SlidersViewImpl.f_MODULE_NAME__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl, "colors").m_asElement__());
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(this.f_sampleCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SlidersViewImpl.f_MODULE_NAME__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl, "example").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initBasic___$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl() {
    this.f_basicCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("SIMPLE SLIDERS")), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(200).m_withoutThumb__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ arg0) =>{
      this.m_showNotification__java_lang_Double_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(arg0);
    })))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("SLIDERS WITH THUMB")), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double__double(200, 20).m_setValue__double(50).m_withThumb__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ arg0$1$) =>{
      this.m_showNotification__java_lang_Double_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(arg0$1$);
    })))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("SLIDERS CAN HAVE MIN AND MAX VALUES").m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Min: 100"), HtmlContentBuilder)).m_asElement__()).m_appendChild__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Max: 200"), HtmlContentBuilder)).m_asElement__())), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double__double(200, 100).m_setValue__double(150).m_withThumb__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ arg0$2$) =>{
      this.m_showNotification__java_lang_Double_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(arg0$2$);
    })))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("SLIDERS WITH STEP").m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("MIN: 100"), HtmlContentBuilder)).m_asElement__()).m_appendChild__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("MAX: 200"), HtmlContentBuilder)).m_asElement__()).m_appendChild__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("STEP: 10"), HtmlContentBuilder)).m_asElement__())), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double__double(200, 100).m_setStep__double(10).m_withThumb__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ arg0$3$) =>{
      this.m_showNotification__java_lang_Double_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(arg0$3$);
    })))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("SLIDERS WITH ANY STEP").m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("MIN: 100"), HtmlContentBuilder)).m_asElement__()).m_appendChild__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("MAX: 200"), HtmlContentBuilder)).m_asElement__()).m_appendChild__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("STEP: ANY"), HtmlContentBuilder)).m_asElement__())), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double__double(200, 100).m_anyStep__().m_withoutThumb__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ arg0$4$) =>{
      this.m_showNotification__java_lang_Double_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(arg0$4$);
    })))), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initColors___$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl() {
    this.f_colorsSlidersCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_RED_LIGHTEN_4__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_RED_DARKEN_4__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN_LIGHTEN_4__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN_DARKEN_4__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_LIGHTEN_4__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_DARKEN_4__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE_LIGHTEN_4__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE_DARKEN_4__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE_LIGHTEN_4__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE_DARKEN_4__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN_LIGHTEN_4__org_dominokit_domino_ui_style_Color).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN_DARKEN_4__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Slider.m_create__double(100).m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color)), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initExample___$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl() {
    let rgbColorsDiv = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("height: 190px;"), HtmlContentBuilder)).m_asElement__(), $Overlay));
    let redSlider = /**@type {Slider} */ ($Casts.$to(Slider.m_create__double__double(255, 0).m_style__().m_setMarginTop__java_lang_String("17px").m_get__(), Slider)).m_anyStep__().m_withoutThumb__().m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_RED_DARKEN_2__org_dominokit_domino_ui_style_Color).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_RED_LIGHTEN_3__org_dominokit_domino_ui_style_Color);
    let greenSlider = /**@type {Slider} */ ($Casts.$to(Slider.m_create__double__double(255, 0).m_style__().m_setMarginTop__java_lang_String("17px").m_get__(), Slider)).m_anyStep__().m_withoutThumb__().m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN_DARKEN_2__org_dominokit_domino_ui_style_Color).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN_LIGHTEN_3__org_dominokit_domino_ui_style_Color);
    let blueSlider = /**@type {Slider} */ ($Casts.$to(Slider.m_create__double__double(255, 0).m_style__().m_setMarginTop__java_lang_String("17px").m_get__(), Slider)).m_anyStep__().m_withoutThumb__().m_setThumbColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_DARKEN_2__org_dominokit_domino_ui_style_Color).m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_LIGHTEN_3__org_dominokit_domino_ui_style_Color);
    let redTextBox = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?string */ value) =>{
      redSlider.m_setValue__double__boolean(Double.m_parseDouble__java_lang_String(value), true);
      this.m_updateBackgroundColor__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider);
    }))), TextBox));
    let greenTextBox = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?string */ value$1$) =>{
      greenSlider.m_setValue__double__boolean(Double.m_parseDouble__java_lang_String(value$1$), true);
      this.m_updateBackgroundColor__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider);
    }))), TextBox));
    let blueTextBox = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?string */ value$2$) =>{
      blueSlider.m_setValue__double__boolean(Double.m_parseDouble__java_lang_String(value$2$), true);
      this.m_updateBackgroundColor__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider);
    }))), TextBox));
    let colorsDiv = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(rgbColorsDiv), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_style__().m_setMarginTop__java_lang_String("20px").m_get__(), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("R"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span10__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(redTextBox), Column)))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("G"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span10__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenTextBox), Column)))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("B"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span10__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(blueTextBox), Column)))), Column))), Row__12)).m_asElement__()), HtmlContentBuilder)).m_asElement__(), $Overlay));
    redSlider.m_addSlideHandler__org_dominokit_domino_ui_sliders_Slider_SlideHandler(SlideHandler.$adapt(((/** number */ value$3$) =>{
      this.m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox);
    })));
    redSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$4$) =>{
      this.m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox);
    })));
    greenSlider.m_addSlideHandler__org_dominokit_domino_ui_sliders_Slider_SlideHandler(SlideHandler.$adapt(((/** number */ value$5$) =>{
      this.m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox);
    })));
    greenSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$6$) =>{
      this.m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox);
    })));
    blueSlider.m_addSlideHandler__org_dominokit_domino_ui_sliders_Slider_SlideHandler(SlideHandler.$adapt(((/** number */ value$7$) =>{
      this.m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox);
    })));
    blueSlider.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?number */ value$8$) =>{
      this.m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox);
    })));
    redSlider.m_setValue__double(255);
    greenSlider.m_setValue__double(0);
    blueSlider.m_setValue__double(0);
    let stepTextBox = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("STEP").m_value__java_lang_Object("any"), TextBox)).m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?string */ value$9$) =>{
      if (j_l_String.m_equalsIgnoreCase__java_lang_String__java_lang_String("any", value$9$)) {
        redSlider.m_anyStep__();
        greenSlider.m_anyStep__();
        blueSlider.m_anyStep__();
      } else {
        redSlider.m_setStep__double(Double.m_parseDouble__java_lang_String(value$9$));
        greenSlider.m_setStep__double(Double.m_parseDouble__java_lang_String(value$9$));
        blueSlider.m_setStep__double(Double.m_parseDouble__java_lang_String(value$9$));
      }
    }))), TextBox));
    let thumbSwitch = SwitchButton.m_create__().m_setOffTitle__java_lang_String("Without thumb").m_setOnTitle__java_lang_String("With thumb").m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value$10$) =>{
      redSlider.m_setWithThumb__boolean(Boolean.m_booleanValue__java_lang_Boolean(value$10$));
      greenSlider.m_setWithThumb__boolean(Boolean.m_booleanValue__java_lang_Boolean(value$10$));
      blueSlider.m_setWithThumb__boolean(Boolean.m_booleanValue__java_lang_Boolean(value$10$));
    })));
    this.f_sampleCard__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_.m_setBodyPaddingTop__java_lang_String("40px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(stepTextBox), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(thumbSwitch), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span1__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("R"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span11__().m_centerContent__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(redSlider), Column)))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span1__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("G"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span11__().m_centerContent__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenSlider), Column)))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span1__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("B"), IsElement))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span11__().m_centerContent__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(blueSlider), Column)))), Column)))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__elemental2_dom_Node(colorsDiv), Column))));
  }
  
  /**
   * @param {HTMLDivElement} rgbColorsDiv
   * @param {Slider} redSlider
   * @param {Slider} greenSlider
   * @param {Slider} blueSlider
   * @param {TextBox} redTextBox
   * @param {TextBox} greenTextBox
   * @param {TextBox} blueTextBox
   * @return {void}
   * @public
   */
  m_updateColorAndTextBoxes__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox__org_dominokit_domino_ui_forms_TextBox_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider, redTextBox, greenTextBox, blueTextBox) {
    this.m_updateBackgroundColor__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider);
    redTextBox.m_setValue__java_lang_Object(redSlider.m_getValue__() + "");
    greenTextBox.m_setValue__java_lang_Object(greenSlider.m_getValue__() + "");
    blueTextBox.m_setValue__java_lang_Object(blueSlider.m_getValue__() + "");
  }
  
  /**
   * @param {HTMLDivElement} rgbColorsDiv
   * @param {Slider} redSlider
   * @param {Slider} greenSlider
   * @param {Slider} blueSlider
   * @return {void}
   * @public
   */
  m_updateBackgroundColor__elemental2_dom_HTMLDivElement__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider__org_dominokit_domino_ui_sliders_Slider_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(rgbColorsDiv, redSlider, greenSlider, blueSlider) {
    rgbColorsDiv.style.background = "rgb(" + redSlider.m_getValue__() + ", " + greenSlider.m_getValue__() + ", " + blueSlider.m_getValue__() + ")";
  }
  
  /**
   * @param {?number} value
   * @return {void}
   * @public
   */
  m_showNotification__java_lang_Double_$p_org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl(value) {
    Notification.m_createInfo__java_lang_String("Value " + j_l_String.m_valueOf__java_lang_Object(value) + " out of 200").m_show__();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl() {
    this.f_element__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SlidersViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SlidersViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SlidersViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Slider = goog.module.get('org.dominokit.domino.ui.sliders.Slider$impl');
    SlideHandler = goog.module.get('org.dominokit.domino.ui.sliders.Slider.SlideHandler$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SlidersViewImpl, $Util.$makeClassName('org.dominokit.domino.sliders.client.views.ui.SlidersViewImpl'));


/** @public {?string} @const */
SlidersViewImpl.f_MODULE_NAME__org_dominokit_domino_sliders_client_views_ui_SlidersViewImpl = "sliders";


SlidersView.$markImplementor(SlidersViewImpl);


exports = SlidersViewImpl; 
//# sourceMappingURL=SlidersViewImpl.js.map