/**
 * @fileoverview transpiled from org.dominokit.domino.sliders.client.presenters.SlidersPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.sliders.client.presenters.SlidersPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let SlidersPresenter = goog.forwardDeclare('org.dominokit.domino.sliders.client.presenters.SlidersPresenter$impl');


/**
 * @extends {PresenterCommand<SlidersPresenter>}
  */
class SlidersPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SlidersPresenterCommand()'.
   * @return {!SlidersPresenterCommand}
   * @public
   */
  static $create__() {
    SlidersPresenterCommand.$clinit();
    let $instance = new SlidersPresenterCommand();
    $instance.$ctor__org_dominokit_domino_sliders_client_presenters_SlidersPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SlidersPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_sliders_client_presenters_SlidersPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SlidersPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SlidersPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SlidersPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SlidersPresenterCommand, $Util.$makeClassName('org.dominokit.domino.sliders.client.presenters.SlidersPresenterCommand'));




exports = SlidersPresenterCommand; 
//# sourceMappingURL=SlidersPresenterCommand.js.map