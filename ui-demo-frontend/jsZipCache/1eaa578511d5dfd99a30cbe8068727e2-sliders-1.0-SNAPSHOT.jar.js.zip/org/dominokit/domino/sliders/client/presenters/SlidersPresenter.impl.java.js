/**
 * @fileoverview transpiled from org.dominokit.domino.sliders.client.presenters.SlidersPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.sliders.client.presenters.SlidersPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.sliders.client.presenters.SlidersPresenter.$1$impl');
let SlidersView = goog.forwardDeclare('org.dominokit.domino.sliders.client.views.SlidersView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<SlidersView>}
  */
class SlidersPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SlidersPresenter()'.
   * @return {!SlidersPresenter}
   * @public
   */
  static $create__() {
    SlidersPresenter.$clinit();
    let $instance = new SlidersPresenter();
    $instance.$ctor__org_dominokit_domino_sliders_client_presenters_SlidersPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SlidersPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_sliders_client_presenters_SlidersPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_onComponentsEvent__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_sliders_client_presenters_SlidersPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_sliders_client_presenters_SlidersPresenter_() {
    return (SlidersPresenter.$clinit(), SlidersPresenter.$f_LOGGER__org_dominokit_domino_sliders_client_presenters_SlidersPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_sliders_client_presenters_SlidersPresenter_(value) {
    (SlidersPresenter.$clinit(), SlidersPresenter.$f_LOGGER__org_dominokit_domino_sliders_client_presenters_SlidersPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SlidersPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SlidersPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SlidersPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.sliders.client.presenters.SlidersPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    SlidersPresenter.$f_LOGGER__org_dominokit_domino_sliders_client_presenters_SlidersPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SlidersPresenter));
  }
  
  
};

$Util.$setClassMetadata(SlidersPresenter, $Util.$makeClassName('org.dominokit.domino.sliders.client.presenters.SlidersPresenter'));


/** @private {Logger} */
SlidersPresenter.$f_LOGGER__org_dominokit_domino_sliders_client_presenters_SlidersPresenter_;




exports = SlidersPresenter; 
//# sourceMappingURL=SlidersPresenter.js.map