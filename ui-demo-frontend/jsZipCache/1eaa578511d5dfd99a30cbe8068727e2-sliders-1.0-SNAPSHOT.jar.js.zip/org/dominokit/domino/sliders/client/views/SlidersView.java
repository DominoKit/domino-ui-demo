package org.dominokit.domino.sliders.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface SlidersView extends View, DemoView {
}