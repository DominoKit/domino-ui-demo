/**
 * @fileoverview transpiled from org.dominokit.domino.sliders.client.presenters.SlidersPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.sliders.client.presenters.SlidersPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _SlidersPresenter = goog.require('org.dominokit.domino.sliders.client.presenters.SlidersPresenter');


// Re-exports the implementation.
var SlidersPresenterCommand = goog.require('org.dominokit.domino.sliders.client.presenters.SlidersPresenterCommand$impl');
exports = SlidersPresenterCommand;
 