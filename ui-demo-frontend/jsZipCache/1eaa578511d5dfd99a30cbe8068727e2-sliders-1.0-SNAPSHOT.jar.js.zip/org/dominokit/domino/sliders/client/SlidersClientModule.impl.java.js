/**
 * @fileoverview transpiled from org.dominokit.domino.sliders.client.SlidersClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.sliders.client.SlidersClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class SlidersClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SlidersClientModule()'.
   * @return {!SlidersClientModule}
   * @public
   */
  static $create__() {
    SlidersClientModule.$clinit();
    let $instance = new SlidersClientModule();
    $instance.$ctor__org_dominokit_domino_sliders_client_SlidersClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SlidersClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_sliders_client_SlidersClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    SlidersClientModule.$f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_.m_info__java_lang_String("Initializing Sliders frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_() {
    return (SlidersClientModule.$clinit(), SlidersClientModule.$f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_(value) {
    (SlidersClientModule.$clinit(), SlidersClientModule.$f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SlidersClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SlidersClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SlidersClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    SlidersClientModule.$f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SlidersClientModule));
  }
  
  
};

$Util.$setClassMetadata(SlidersClientModule, $Util.$makeClassName('org.dominokit.domino.sliders.client.SlidersClientModule'));


/** @private {Logger} */
SlidersClientModule.$f_LOGGER__org_dominokit_domino_sliders_client_SlidersClientModule_;




exports = SlidersClientModule; 
//# sourceMappingURL=SlidersClientModule.js.map