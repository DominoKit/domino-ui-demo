/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const TimePickerView = goog.require('org.dominokit.domino.timepicker.client.views.TimePickerView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$3$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ClockStyle = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.ClockStyle$impl');
let TimeBox = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimeBox$impl');
let PickerStyle = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimeBox.PickerStyle$impl');
let TimePicker = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimePicker$impl');
let TimeSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimePicker.TimeSelectionHandler$impl');
let DateTimeFormatInfoImpl__de = goog.forwardDeclare('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_de$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {TimePickerView}
  */
class TimePickerViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'TimePickerViewImpl()'.
   * @return {!TimePickerViewImpl}
   * @public
   */
  static $create__() {
    TimePickerViewImpl.$clinit();
    let $instance = new TimePickerViewImpl();
    $instance.$ctor__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TimePickerViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(TimePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("TIME PICKERS").m_asElement__());
    this.m_inlined___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
    this.m_popups___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
    this.m_timeBox___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_inlined___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(Card.m_create__java_lang_String("INLINED").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TimePicker.m_create__().m_fixedWidth__java_lang_String("270px").m_showBorder__().m_hideClearButton__().m_hideCloseButton__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time, /** DateTimeFormatInfo */ dateTimeFormatInfo, /** TimePicker */ timePicker) =>{
      window.console.info(timePicker.m_getFormattedTime__());
    })))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TimePicker.m_create__org_gwtproject_i18n_shared_DateTimeFormatInfo(DateTimeFormatInfoImpl__de.$create__()).m_fixedWidth__java_lang_String("270px").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_showBorder__().m_hideClearButton__().m_setShowSwitchers__boolean(true).m_hideCloseButton__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$, /** TimePicker */ timePicker$1$) =>{
      window.console.info(timePicker$1$.m_getFormattedTime__());
    }))).m_todayButtonText__java_lang_String("nu")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TimePicker.m_create__().m_fixedWidth__java_lang_String("270px").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_setClockStyle__org_dominokit_domino_ui_timepicker_ClockStyle(ClockStyle.f__24__org_dominokit_domino_ui_timepicker_ClockStyle).m_showBorder__().m_hideClearButton__().m_hideCloseButton__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$, /** TimePicker */ timePicker$2$) =>{
      window.console.info(timePicker$2$.m_getFormattedTime__());
    })))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TimePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl, "inlined").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_popups___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    let bluePopupButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let bluePopTimePicker = TimePicker.m_create__().m_showBorder__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time, /** DateTimeFormatInfo */ dateTimeFormatInfo, /** TimePicker */ picker) =>{
      window.console.info(picker.m_getFormattedTime__());
    })));
    let bluePopover = Popover.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(bluePopupButton, "Wakeup", bluePopTimePicker);
    bluePopTimePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      bluePopover.m_close__();
    })));
    bluePopTimePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let pinkPopupButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let pinkPopDatePicker = TimePicker.m_create__org_gwtproject_i18n_shared_DateTimeFormatInfo(DateTimeFormatInfoImpl__de.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$, /** TimePicker */ picker$1$) =>{
      window.console.info(picker$1$.m_getFormattedTime__());
    })));
    let pinkPopover = Popover.m_createPicker__org_jboss_gwt_elemento_core_IsElement__org_jboss_gwt_elemento_core_IsElement(pinkPopupButton, pinkPopDatePicker);
    pinkPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      pinkPopover.m_close__();
    })));
    pinkPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenPopupButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let greenPopDatePicker = TimePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$, /** TimePicker */ picker$2$) =>{
      window.console.info(picker$2$.m_getFormattedTime__());
    })));
    let greenPopover = Popover.m_createPicker__org_jboss_gwt_elemento_core_IsElement__org_jboss_gwt_elemento_core_IsElement(greenPopupButton, greenPopDatePicker);
    greenPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenPopover.m_close__();
    })));
    greenPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let blueModalButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let blueDatePicker = TimePicker.m_create__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$3$, /** DateTimeFormatInfo */ dateTimeFormatInfo$3$, /** TimePicker */ picker$3$) =>{
      window.console.info(picker$3$.m_getFormattedTime__());
    })));
    let blueModal = blueDatePicker.m_createModal__java_lang_String("Wakeup");
    blueDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      blueModal.m_close__();
    })));
    blueDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    blueModal.m_appendChild__elemental2_dom_Node(blueDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(blueModal.m_asElement__());
    blueModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      blueModal.m_open__();
    })));
    let pinkModalButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let pinkDatePicker = TimePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$4$, /** DateTimeFormatInfo */ dateTimeFormatInfo$4$, /** TimePicker */ picker$4$) =>{
      window.console.info(picker$4$.m_getFormattedTime__());
    })));
    let pinkModal = pinkDatePicker.m_createModal__java_lang_String("Wakeup");
    pinkDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      pinkModal.m_close__();
    })));
    pinkDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    pinkModal.m_appendChild__org_jboss_gwt_elemento_core_IsElement(pinkDatePicker);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(pinkModal.m_asElement__());
    pinkModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      pinkModal.m_open__();
    })));
    let greenModalButton = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()), Button));
    let greenDatePicker = TimePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Date */ time$5$, /** DateTimeFormatInfo */ dateTimeFormatInfo$5$, /** TimePicker */ picker$5$) =>{
      window.console.info(picker$5$.m_getFormattedTime__());
    })));
    let greenModal = greenDatePicker.m_createModal__java_lang_String("Wakeup");
    greenDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenModal.m_close__();
    })));
    greenDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    greenModal.m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenDatePicker);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(greenModal.m_asElement__());
    greenModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      greenModal.m_open__();
    })));
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(Card.m_create__java_lang_String("POPUP").m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("POP OVER")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(bluePopupButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(pinkPopupButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenPopupButton), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("MODAL")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(blueModalButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(pinkModalButton), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(greenModalButton), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TimePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl, "popups").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_timeBox___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    let column = /**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_style__().m_remove__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column));
    let timeBox1 = /**@type {TimeBox} */ ($Casts.$to(TimeBox.m_create__().m_setLabel__java_lang_String("Wakeup"), TimeBox));
    let timeBox2 = TimeBox.m_create__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo("Wakeup", Date.$create__(), DateTimeFormatInfoImpl__de.$create__());
    timeBox2.m_getTimePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme);
    let timeBox3 = TimeBox.m_create__().m_setPopoverPosition__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition).m_setPickerStyle__org_dominokit_domino_ui_timepicker_TimeBox_PickerStyle(PickerStyle.f_POPOVER__org_dominokit_domino_ui_timepicker_TimeBox_PickerStyle).m_setPlaceholder__java_lang_String("Wakeup");
    timeBox3.m_getTimePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme);
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(Card.m_create__java_lang_String("TIME BOX").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(timeBox1), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(timeBox2), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(timeBox3), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TimePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl, "timebox").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
    this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_ = /**@type {Column} */ ($Casts.$to(Column.m_span4__().m_centerContent__().m_style__().m_add__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_get__(), Column));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TimePickerViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TimePickerViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TimePickerViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Date = goog.module.get('java.util.Date$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$3$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    PickerHandler = goog.module.get('org.dominokit.domino.ui.pickers.PickerHandler$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ClockStyle = goog.module.get('org.dominokit.domino.ui.timepicker.ClockStyle$impl');
    TimeBox = goog.module.get('org.dominokit.domino.ui.timepicker.TimeBox$impl');
    PickerStyle = goog.module.get('org.dominokit.domino.ui.timepicker.TimeBox.PickerStyle$impl');
    TimePicker = goog.module.get('org.dominokit.domino.ui.timepicker.TimePicker$impl');
    TimeSelectionHandler = goog.module.get('org.dominokit.domino.ui.timepicker.TimePicker.TimeSelectionHandler$impl');
    DateTimeFormatInfoImpl__de = goog.module.get('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_de$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TimePickerViewImpl, $Util.$makeClassName('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl'));


/** @public {?string} @const */
TimePickerViewImpl.f_MODULE_NAME__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl = "timepicker";


TimePickerView.$markImplementor(TimePickerViewImpl);


exports = TimePickerViewImpl; 
//# sourceMappingURL=TimePickerViewImpl.js.map