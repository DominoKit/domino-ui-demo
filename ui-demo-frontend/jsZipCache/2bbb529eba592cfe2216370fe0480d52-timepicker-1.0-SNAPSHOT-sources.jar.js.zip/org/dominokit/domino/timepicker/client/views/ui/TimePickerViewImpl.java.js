/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _TimePickerView = goog.require('org.dominokit.domino.timepicker.client.views.TimePickerView');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Date = goog.require('java.util.Date');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$3');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _PickerHandler = goog.require('org.dominokit.domino.ui.pickers.PickerHandler');
const _Popover = goog.require('org.dominokit.domino.ui.popover.Popover');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _ClockStyle = goog.require('org.dominokit.domino.ui.timepicker.ClockStyle');
const _TimeBox = goog.require('org.dominokit.domino.ui.timepicker.TimeBox');
const _PickerStyle = goog.require('org.dominokit.domino.ui.timepicker.TimeBox.PickerStyle');
const _TimePicker = goog.require('org.dominokit.domino.ui.timepicker.TimePicker');
const _TimeSelectionHandler = goog.require('org.dominokit.domino.ui.timepicker.TimePicker.TimeSelectionHandler');
const _DateTimeFormatInfoImpl__de = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_de');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TimePickerViewImpl = goog.require('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl$impl');
exports = TimePickerViewImpl;
 