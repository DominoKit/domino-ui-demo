package org.dominokit.domino.timepicker.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface TimePickerView extends View, DemoView {
}