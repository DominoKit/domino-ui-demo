/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');
const _ThumbnailsPresenter = goog.require('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter');
const _ThumbnailsPresenterCommand = goog.require('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ThumbnailsPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent$impl');
exports = ThumbnailsPresenterListenerForComponentsEvent;
 