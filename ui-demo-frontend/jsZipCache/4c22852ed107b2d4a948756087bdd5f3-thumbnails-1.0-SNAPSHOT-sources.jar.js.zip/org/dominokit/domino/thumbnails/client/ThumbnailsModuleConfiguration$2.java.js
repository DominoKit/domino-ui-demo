/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _ThumbnailsModuleConfiguration = goog.require('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration');
const _ThumbnailsViewImpl = goog.require('org.dominokit.domino.thumbnails.client.views.ui.ThumbnailsViewImpl');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration.$2$impl');
exports = $2;
 