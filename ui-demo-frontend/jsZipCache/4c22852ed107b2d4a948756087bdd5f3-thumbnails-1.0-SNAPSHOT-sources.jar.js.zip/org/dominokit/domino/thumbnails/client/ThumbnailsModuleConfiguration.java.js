/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');
const _$1 = goog.require('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration.$2');
const _ThumbnailsPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent');
const _ThumbnailsPresenter = goog.require('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter');
const _ThumbnailsPresenterCommand = goog.require('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand');


// Re-exports the implementation.
var ThumbnailsModuleConfiguration = goog.require('org.dominokit.domino.thumbnails.client.ThumbnailsModuleConfiguration$impl');
exports = ThumbnailsModuleConfiguration;
 