/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
let ThumbnailsPresenter = goog.forwardDeclare('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter$impl');
let ThumbnailsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentsEvent>}
  */
class ThumbnailsPresenterListenerForComponentsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThumbnailsPresenterListenerForComponentsEvent()'.
   * @return {!ThumbnailsPresenterListenerForComponentsEvent}
   * @public
   */
  static $create__() {
    ThumbnailsPresenterListenerForComponentsEvent.$clinit();
    let $instance = new ThumbnailsPresenterListenerForComponentsEvent();
    $instance.$ctor__org_dominokit_domino_thumbnails_client_listeners_ThumbnailsPresenterListenerForComponentsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThumbnailsPresenterListenerForComponentsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_thumbnails_client_listeners_ThumbnailsPresenterListenerForComponentsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_components_shared_extension_ComponentsEvent(event) {
    ThumbnailsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ThumbnailsPresenter */ presenter) =>{
      presenter.m_onComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(event.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_components_shared_extension_ComponentsEvent(/**@type {ComponentsEvent} */ ($Casts.$to(arg0, ComponentsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThumbnailsPresenterListenerForComponentsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThumbnailsPresenterListenerForComponentsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThumbnailsPresenterListenerForComponentsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    ThumbnailsPresenterCommand = goog.module.get('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThumbnailsPresenterListenerForComponentsEvent, $Util.$makeClassName('org.dominokit.domino.thumbnails.client.listeners.ThumbnailsPresenterListenerForComponentsEvent'));


DominoEventListener.$markImplementor(ThumbnailsPresenterListenerForComponentsEvent);


exports = ThumbnailsPresenterListenerForComponentsEvent; 
//# sourceMappingURL=ThumbnailsPresenterListenerForComponentsEvent.js.map