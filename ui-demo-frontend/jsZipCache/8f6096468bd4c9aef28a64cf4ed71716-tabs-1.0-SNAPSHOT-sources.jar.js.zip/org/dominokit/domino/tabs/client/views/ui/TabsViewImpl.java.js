/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.views.ui.TabsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _TabsView = goog.require('org.dominokit.domino.tabs.client.views.TabsView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Tab = goog.require('org.dominokit.domino.ui.tabs.Tab');
const _TabsPanel = goog.require('org.dominokit.domino.ui.tabs.TabsPanel');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TabsViewImpl = goog.require('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl$impl');
exports = TabsViewImpl;
 