/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.TabsModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tabs.client.TabsModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');
const _$1 = goog.require('org.dominokit.domino.tabs.client.TabsModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.tabs.client.TabsModuleConfiguration.$2');
const _TabsPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.tabs.client.listeners.TabsPresenterListenerForComponentsEvent');
const _TabsPresenter = goog.require('org.dominokit.domino.tabs.client.presenters.TabsPresenter');
const _TabsPresenterCommand = goog.require('org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand');


// Re-exports the implementation.
var TabsModuleConfiguration = goog.require('org.dominokit.domino.tabs.client.TabsModuleConfiguration$impl');
exports = TabsModuleConfiguration;
 