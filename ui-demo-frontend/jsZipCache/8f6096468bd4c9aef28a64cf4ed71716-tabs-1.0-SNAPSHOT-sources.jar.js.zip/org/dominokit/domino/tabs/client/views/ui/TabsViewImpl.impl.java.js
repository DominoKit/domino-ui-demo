/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.views.ui.TabsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const TabsView = goog.require('org.dominokit.domino.tabs.client.views.TabsView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Tab = goog.forwardDeclare('org.dominokit.domino.ui.tabs.Tab$impl');
let TabsPanel = goog.forwardDeclare('org.dominokit.domino.ui.tabs.TabsPanel$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {TabsView}
  */
class TabsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'TabsViewImpl()'.
   * @return {!TabsViewImpl}
   * @public
   */
  static $create__() {
    TabsViewImpl.$clinit();
    let $instance = new TabsViewImpl();
    $instance.$ctor__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TabsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("TABS").m_asElement__());
    this.m_basicSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
    this.m_iconsOnly___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
    this.m_withIconsAndTextSamlple___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
    this.m_materialDesignColorsSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
    this.m_backgroundSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
    this.m_initDifferentContentSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
    this.m_withAnimation___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("EXAMPLE TAB", "Add quick, dynamic tab functionality to transition through panes of local content").m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Home Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Profile Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Messages Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)).m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Settings Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)))).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "basicSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_iconsOnly___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String("TABS WITH ONLY ICON TITLE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Home Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_face__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Profile Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Messages Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)).m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_settings__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Settings Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)))).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "iconsOnly").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_withIconsAndTextSamlple___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String("TABS WITH ICON TITLE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " HOME").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Home Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_face__(), " PROFILE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Profile Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__(), " MESSAGES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Messages Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)).m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_settings__(), " SETTINGS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Settings Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)))).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "withIconsAndTextSamlple").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_materialDesignColorsSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("TABS WITH MATERIAL DESIGN COLORS", "You can use Material Design Colors").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS")).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS")).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS")).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS")).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS")).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS")).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color)), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "materialDesignColorsSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_backgroundSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("TABS WITH MATERIAL DESIGN BACKGROUNDS", "You can use Material Design backgrounds").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setBackgroundColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE")).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS"))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "materialDesignBackgroundsSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDifferentContentSample___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    let contentContainer = /**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__())).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("TAB CONTENT")), DominoElement)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, DominoElement<HTMLDivElement>> */ style) =>{
      style.m_setMarginTop__java_lang_String("40px").m_setPadding__java_lang_String("20px").m_add__java_lang_String(Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles);
    }))), DominoElement));
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("TABS WITH CONTENT CONTAINER", "Tabs can have different content container").m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_setContentContainer__org_jboss_gwt_elemento_core_IsElement(contentContainer).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("HOME").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Home Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("PROFILE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Profile Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("MESSAGES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Messages Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)).m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__java_lang_String("SETTINGS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Settings Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(contentContainer).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "differentContentContainerSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_withAnimation___$p_org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("TABS WITH CUSTOM ANIMATIONS", "Animate the tabs content when they show up.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " HOME").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Home Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_face__(), " PROFILE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Profile Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__(), " MESSAGES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Messages Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)).m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_settings__(), " SETTINGS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Settings Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_setTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TabsPanel.m_create__().m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " HOME").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Home Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_face__(), " PROFILE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Profile Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__(), " MESSAGES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Messages Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_)).m_activate__()).m_appendChild__org_dominokit_domino_ui_tabs_Tab(Tab.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_settings__(), " SETTINGS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Settings Content"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_))).m_setTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition)), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl, "withAnimation").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl() {
    this.f_element__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TabsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TabsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TabsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Tab = goog.module.get('org.dominokit.domino.ui.tabs.Tab$impl');
    TabsPanel = goog.module.get('org.dominokit.domino.ui.tabs.TabsPanel$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TabsViewImpl, $Util.$makeClassName('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl'));


/** @public {?string} @const */
TabsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl_ = "Lorem ipsum dolor sit amet, ut duo atqui exerci dicunt, ius impedit mediocritatem an. Pri ut tation electram moderatius. Per te suavitate democritum. Duis nemore probatus ne quo, ad liber essent aliquid pro. Et eos nusquam accumsan, vide mentitum fabellas ne est, eu munere gubergren sadipscing mel.";


/** @public {?string} @const */
TabsViewImpl.f_MODULE_NAME__org_dominokit_domino_tabs_client_views_ui_TabsViewImpl = "tabs";


TabsView.$markImplementor(TabsViewImpl);


exports = TabsViewImpl; 
//# sourceMappingURL=TabsViewImpl.js.map