/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.TabsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tabs.client.TabsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class TabsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TabsClientModule()'.
   * @return {!TabsClientModule}
   * @public
   */
  static $create__() {
    TabsClientModule.$clinit();
    let $instance = new TabsClientModule();
    $instance.$ctor__org_dominokit_domino_tabs_client_TabsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TabsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tabs_client_TabsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    TabsClientModule.$f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_.m_info__java_lang_String("Initializing Tabs frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_() {
    return (TabsClientModule.$clinit(), TabsClientModule.$f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_(value) {
    (TabsClientModule.$clinit(), TabsClientModule.$f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TabsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TabsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TabsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    TabsClientModule.$f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(TabsClientModule));
  }
  
  
};

$Util.$setClassMetadata(TabsClientModule, $Util.$makeClassName('org.dominokit.domino.tabs.client.TabsClientModule'));


/** @private {Logger} */
TabsClientModule.$f_LOGGER__org_dominokit_domino_tabs_client_TabsClientModule_;




exports = TabsClientModule; 
//# sourceMappingURL=TabsClientModule.js.map