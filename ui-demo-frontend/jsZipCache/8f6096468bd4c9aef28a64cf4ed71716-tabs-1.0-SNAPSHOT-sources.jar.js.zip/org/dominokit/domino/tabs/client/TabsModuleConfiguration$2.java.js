/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.TabsModuleConfiguration$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tabs.client.TabsModuleConfiguration.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _TabsModuleConfiguration = goog.require('org.dominokit.domino.tabs.client.TabsModuleConfiguration');
const _TabsViewImpl = goog.require('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.tabs.client.TabsModuleConfiguration.$2$impl');
exports = $2;
 