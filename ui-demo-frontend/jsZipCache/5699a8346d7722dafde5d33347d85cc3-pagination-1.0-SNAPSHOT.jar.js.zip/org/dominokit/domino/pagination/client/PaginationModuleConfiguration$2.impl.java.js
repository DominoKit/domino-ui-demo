/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.PaginationModuleConfiguration$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.PaginationModuleConfiguration.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');

let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let PaginationModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.pagination.client.PaginationModuleConfiguration$impl');
let PaginationViewImpl = goog.forwardDeclare('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl$impl');


class $2 extends LazyViewLoader {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {PaginationModuleConfiguration} */
    this.f_$outer_this__org_dominokit_domino_pagination_client_PaginationModuleConfiguration_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new LazyViewLoader(PaginationModuleConfiguration, String)'.
   * @param {PaginationModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_pagination_client_PaginationModuleConfiguration__java_lang_String($outer_this, $_0) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_pagination_client_PaginationModuleConfiguration_2__org_dominokit_domino_pagination_client_PaginationModuleConfiguration__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new LazyViewLoader(PaginationModuleConfiguration, String)'.
   * @param {PaginationModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_PaginationModuleConfiguration_2__org_dominokit_domino_pagination_client_PaginationModuleConfiguration__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_pagination_client_PaginationModuleConfiguration_2 = $outer_this;
    this.$ctor__org_dominokit_domino_api_client_mvp_view_LazyViewLoader__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {View}
   * @public
   */
  m_make__() {
    return PaginationViewImpl.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    PaginationViewImpl = goog.module.get('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl$impl');
    LazyViewLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.pagination.client.PaginationModuleConfiguration$2'));




exports = $2; 
//# sourceMappingURL=PaginationModuleConfiguration$2.js.map