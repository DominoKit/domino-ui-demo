/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const PaginationView = goog.require('org.dominokit.domino.pagination.client.views.PaginationView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let AdvancedPagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.AdvancedPagination$impl');
let PageChangedCallBack = goog.forwardDeclare('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack$impl');
let Pager = goog.forwardDeclare('org.dominokit.domino.ui.pagination.Pager$impl');
let PagerChangeCallback = goog.forwardDeclare('org.dominokit.domino.ui.pagination.Pager.PagerChangeCallback$impl');
let ScrollingPagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.ScrollingPagination$impl');
let SimplePagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.SimplePagination$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {PaginationView}
  */
class PaginationViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'PaginationViewImpl()'.
   * @return {!PaginationViewImpl}
   * @public
   */
  static $create__() {
    PaginationViewImpl.$clinit();
    let $instance = new PaginationViewImpl();
    $instance.$ctor__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PaginationViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("PAGINATION").m_asElement__());
    this.m_defaultPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.m_activePageSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.m_sizesSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.m_initScrollerPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.m_initAdvancedPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("PAGER").m_asElement__());
    this.m_pagerNexPrevSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_defaultPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DEFAULT PAGINATION", "Simple pagination inspired by Rdio, great for apps and search results. The large block is hard to miss, easily scalable, and provides large click areas.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(SimplePagination.m_create__int(5).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(pageNumber + "");
    })))).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, "defaultPagination").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_activePageSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ACTIVE PAGE", "You can mark the current active page.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {SimplePagination} */ ($Casts.$to(/**@type {SimplePagination} */ ($Casts.$to(SimplePagination.m_create__int(5).m_markActivePage__(), SimplePagination)).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(pageNumber + "");
    }))), SimplePagination)).m_gotoPage__int(3)).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, "activePageSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_sizesSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("PAGINATION SIZE", "There is three sizes for pagination").m_appendChild__elemental2_dom_Node(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Large"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {SimplePagination} */ ($Casts.$to(/**@type {SimplePagination} */ ($Casts.$to(/**@type {SimplePagination} */ ($Casts.$to(SimplePagination.m_create__int(5).m_markActivePage__(), SimplePagination)).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(pageNumber + "");
    }))), SimplePagination)).m_gotoPage__int(3), SimplePagination)).m_large__()), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Default"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {SimplePagination} */ ($Casts.$to(/**@type {SimplePagination} */ ($Casts.$to(SimplePagination.m_create__int(5).m_markActivePage__(), SimplePagination)).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber$1$) =>{
      window.console.info(pageNumber$1$ + "");
    }))), SimplePagination)).m_gotoPage__int(3)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Small"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {SimplePagination} */ ($Casts.$to(/**@type {SimplePagination} */ ($Casts.$to(/**@type {SimplePagination} */ ($Casts.$to(SimplePagination.m_create__int(5).m_markActivePage__(), SimplePagination)).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber$2$) =>{
      window.console.info(pageNumber$2$ + "");
    }))), SimplePagination)).m_gotoPage__int(3), SimplePagination)).m_small__()), Column))), Row__12)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, "sizesSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initScrollerPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SCROLLING PAGINATION", "For large number of pages scrolling pagiation allow viewing a set of pages at a time.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(ScrollingPagination.m_create__int__int__int(50, 10, 5).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(pageNumber + "");
    })))).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, "scrollingPagination").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initAdvancedPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ADVANCED PAGINATION", "Old style pagination with advanced page select.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(AdvancedPagination.m_create__int__int(50, 10).m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(pageNumber + "");
    })))).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, "advancedPagination").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_pagerNexPrevSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DEFAULT PAGER", "By default, the pager centers links.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_nextText__java_lang_String("Newer").m_previousText__java_lang_String("Older").m_showArrows__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("PAGER ALIGNED TO EDGES", "Use expand to align the pager to the edges.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_nextText__java_lang_String("Newer").m_previousText__java_lang_String("Older").m_showArrows__().m_expand__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("PAGER WITH DISABLED LINK", "You can Disable/Enable pager links.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_nextText__java_lang_String("Newer").m_previousText__java_lang_String("Older").m_showArrows__().m_expand__().m_disablePrevious__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl, "pagerSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PaginationViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PaginationViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaginationViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    AdvancedPagination = goog.module.get('org.dominokit.domino.ui.pagination.AdvancedPagination$impl');
    PageChangedCallBack = goog.module.get('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack$impl');
    Pager = goog.module.get('org.dominokit.domino.ui.pagination.Pager$impl');
    PagerChangeCallback = goog.module.get('org.dominokit.domino.ui.pagination.Pager.PagerChangeCallback$impl');
    ScrollingPagination = goog.module.get('org.dominokit.domino.ui.pagination.ScrollingPagination$impl');
    SimplePagination = goog.module.get('org.dominokit.domino.ui.pagination.SimplePagination$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PaginationViewImpl, $Util.$makeClassName('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl'));


/** @public {?string} @const */
PaginationViewImpl.f_MODULE_NAME__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl = "pagination";


PaginationView.$markImplementor(PaginationViewImpl);


exports = PaginationViewImpl; 
//# sourceMappingURL=PaginationViewImpl.js.map