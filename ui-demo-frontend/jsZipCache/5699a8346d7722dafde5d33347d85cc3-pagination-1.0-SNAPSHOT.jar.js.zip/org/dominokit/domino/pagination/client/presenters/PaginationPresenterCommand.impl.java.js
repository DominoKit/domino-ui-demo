/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let PaginationPresenter = goog.forwardDeclare('org.dominokit.domino.pagination.client.presenters.PaginationPresenter$impl');


/**
 * @extends {PresenterCommand<PaginationPresenter>}
  */
class PaginationPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PaginationPresenterCommand()'.
   * @return {!PaginationPresenterCommand}
   * @public
   */
  static $create__() {
    PaginationPresenterCommand.$clinit();
    let $instance = new PaginationPresenterCommand();
    $instance.$ctor__org_dominokit_domino_pagination_client_presenters_PaginationPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PaginationPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_presenters_PaginationPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PaginationPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PaginationPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaginationPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PaginationPresenterCommand, $Util.$makeClassName('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand'));




exports = PaginationPresenterCommand; 
//# sourceMappingURL=PaginationPresenterCommand.js.map