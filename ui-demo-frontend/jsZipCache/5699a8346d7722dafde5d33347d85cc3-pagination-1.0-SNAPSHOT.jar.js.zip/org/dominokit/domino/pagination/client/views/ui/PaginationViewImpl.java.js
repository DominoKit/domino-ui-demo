/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _PaginationView = goog.require('org.dominokit.domino.pagination.client.views.PaginationView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _AdvancedPagination = goog.require('org.dominokit.domino.ui.pagination.AdvancedPagination');
const _PageChangedCallBack = goog.require('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack');
const _Pager = goog.require('org.dominokit.domino.ui.pagination.Pager');
const _PagerChangeCallback = goog.require('org.dominokit.domino.ui.pagination.Pager.PagerChangeCallback');
const _ScrollingPagination = goog.require('org.dominokit.domino.ui.pagination.ScrollingPagination');
const _SimplePagination = goog.require('org.dominokit.domino.ui.pagination.SimplePagination');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PaginationViewImpl = goog.require('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl$impl');
exports = PaginationViewImpl;
 