/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.listeners.PaginationPresenterListenerForComponentsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.listeners.PaginationPresenterListenerForComponentsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
let PaginationPresenter = goog.forwardDeclare('org.dominokit.domino.pagination.client.presenters.PaginationPresenter$impl');
let PaginationPresenterCommand = goog.forwardDeclare('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentsEvent>}
  */
class PaginationPresenterListenerForComponentsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PaginationPresenterListenerForComponentsEvent()'.
   * @return {!PaginationPresenterListenerForComponentsEvent}
   * @public
   */
  static $create__() {
    PaginationPresenterListenerForComponentsEvent.$clinit();
    let $instance = new PaginationPresenterListenerForComponentsEvent();
    $instance.$ctor__org_dominokit_domino_pagination_client_listeners_PaginationPresenterListenerForComponentsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PaginationPresenterListenerForComponentsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_listeners_PaginationPresenterListenerForComponentsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_components_shared_extension_ComponentsEvent(event) {
    PaginationPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** PaginationPresenter */ presenter) =>{
      presenter.m_onComponentsEvent__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(event.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_components_shared_extension_ComponentsEvent(/**@type {ComponentsEvent} */ ($Casts.$to(arg0, ComponentsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PaginationPresenterListenerForComponentsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PaginationPresenterListenerForComponentsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaginationPresenterListenerForComponentsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    PaginationPresenterCommand = goog.module.get('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PaginationPresenterListenerForComponentsEvent, $Util.$makeClassName('org.dominokit.domino.pagination.client.listeners.PaginationPresenterListenerForComponentsEvent'));


DominoEventListener.$markImplementor(PaginationPresenterListenerForComponentsEvent);


exports = PaginationPresenterListenerForComponentsEvent; 
//# sourceMappingURL=PaginationPresenterListenerForComponentsEvent.js.map