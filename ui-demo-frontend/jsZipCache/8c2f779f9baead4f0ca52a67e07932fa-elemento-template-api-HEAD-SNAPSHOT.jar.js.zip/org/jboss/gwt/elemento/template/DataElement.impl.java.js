/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.DataElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.template.DataElement$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class DataElement {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_template_DataElement = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_template_DataElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_template_DataElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DataElement.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(DataElement, $Util.$makeClassName('org.jboss.gwt.elemento.template.DataElement'));


DataElement.$markImplementor(/** @type {Function} */ (DataElement));


exports = DataElement; 
//# sourceMappingURL=DataElement.js.map