/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.ContactUiUtils.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _EyeColor = goog.require('org.dominokit.domino.datatable.client.views.model.EyeColor');
const _Gender = goog.require('org.dominokit.domino.datatable.client.views.model.Gender');
const _Tooltip = goog.require('org.dominokit.domino.ui.popover.Tooltip');
const _Progress = goog.require('org.dominokit.domino.ui.progress.Progress');
const _ProgressBar = goog.require('org.dominokit.domino.ui.progress.ProgressBar');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var ContactUiUtils = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils$impl');
exports = ContactUiUtils;
 