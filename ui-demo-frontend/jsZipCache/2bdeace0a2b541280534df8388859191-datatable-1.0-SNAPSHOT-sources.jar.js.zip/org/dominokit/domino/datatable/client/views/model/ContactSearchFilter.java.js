/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactSearchFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SearchFilter = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter');
const _Boolean = goog.require('java.lang.Boolean');
const _Double = goog.require('java.lang.Double');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Predicate = goog.require('java.util.function.Predicate');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _EyeColor = goog.require('org.dominokit.domino.datatable.client.views.model.EyeColor');
const _Gender = goog.require('org.dominokit.domino.datatable.client.views.model.Gender');
const _SearchEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchEvent');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var ContactSearchFilter = goog.require('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter$impl');
exports = ContactSearchFilter;
 