/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$4.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$4');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _ContactBeanJsonSerializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _StringJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.StringJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $4 = goog.require('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$4$impl');
exports = $4;
 