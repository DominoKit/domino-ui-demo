/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$10.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$10$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let StringJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Contact, ?string>}
  */
class $10 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl_10;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(ContactBeanJsonSerializerImpl, String)'.
   * @param {ContactBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$10}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $10.$clinit();
    let $instance = new $10();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl_10__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(ContactBeanJsonSerializerImpl, String)'.
   * @param {ContactBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl_10__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl_10 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return StringJsonSerializer.m_getInstance__();
  }
  
  /**
   * @param {Contact} bean
   * @param {JsonSerializationContext} ctx
   * @return {?string}
   * @public
   */
  m_getValue__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getEmail__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {?string}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Contact} */ ($Casts.$to(arg0, Contact)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $10;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $10);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $10.$clinit = function() {};
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    StringJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($10, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$10'));




exports = $10; 
//# sourceMappingURL=ContactBeanJsonSerializerImpl$10.js.map