/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper$impl');

let ContactList = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
let ContactListBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl$impl');
let ContactListBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');


/**
 * @extends {AbstractObjectMapper<ContactList>}
  */
class ContactList__MapperImpl extends AbstractObjectMapper {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactList_MapperImpl()'.
   * @return {!ContactList__MapperImpl}
   * @public
   */
  static $create__() {
    ContactList__MapperImpl.$clinit();
    let $instance = new ContactList__MapperImpl();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactList_MapperImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl__() {
    this.$ctor__org_dominokit_jacksonapt_AbstractObjectMapper__java_lang_String("ContactList");
  }
  
  /**
   * @override
   * @return {JsonDeserializer<ContactList>}
   * @public
   */
  m_newDeserializer__() {
    return ContactListBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return ContactListBeanJsonSerializerImpl.$create__();
  }
  
  /**
   * @return {ContactList__MapperImpl}
   * @public
   */
  static get f_INSTANCE__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl() {
    return (ContactList__MapperImpl.$clinit(), ContactList__MapperImpl.$f_INSTANCE__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl);
  }
  
  /**
   * @param {ContactList__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl(value) {
    (ContactList__MapperImpl.$clinit(), ContactList__MapperImpl.$f_INSTANCE__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactList__MapperImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactList__MapperImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactList__MapperImpl.$clinit = function() {};
    ContactListBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl$impl');
    ContactListBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$impl');
    AbstractObjectMapper.$clinit();
    ContactList__MapperImpl.$f_INSTANCE__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl = ContactList__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(ContactList__MapperImpl, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl'));


/** @private {ContactList__MapperImpl} */
ContactList__MapperImpl.$f_INSTANCE__org_dominokit_domino_datatable_client_views_model_ContactList_MapperImpl;




exports = ContactList__MapperImpl; 
//# sourceMappingURL=ContactList_MapperImpl.js.map