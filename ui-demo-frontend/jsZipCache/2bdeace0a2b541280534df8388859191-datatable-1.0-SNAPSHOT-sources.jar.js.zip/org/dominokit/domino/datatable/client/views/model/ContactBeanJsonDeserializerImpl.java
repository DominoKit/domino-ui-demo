package org.dominokit.domino.datatable.client.views.model;

import java.lang.Boolean;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Object;
import java.lang.Override;
import java.lang.Short;
import java.lang.String;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer;
import org.dominokit.jacksonapt.deser.BooleanJsonDeserializer;
import org.dominokit.jacksonapt.deser.EnumJsonDeserializer;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class ContactBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Contact> {
  public ContactBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Contact.class;
  }

  @Override
  protected InstanceBuilder<Contact> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Contact>() {
      @Override
      public Instance<Contact> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Contact>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Contact create() {
        return new Contact();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Contact, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Contact, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("index", new BeanPropertyDeserializer<Contact, Integer>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BaseNumberJsonDeserializer.IntegerJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, Integer value, JsonDeserializationContext ctx) {
        bean.setIndex(value);
      }
    });
    map.put("active", new BeanPropertyDeserializer<Contact, Boolean>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BooleanJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, Boolean value, JsonDeserializationContext ctx) {
        bean.setActive(value);
      }
    });
    map.put("balance", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setBalance(value);
      }
    });
    map.put("picture", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setPicture(value);
      }
    });
    map.put("age", new BeanPropertyDeserializer<Contact, Short>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BaseNumberJsonDeserializer.ShortJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, Short value, JsonDeserializationContext ctx) {
        bean.setAge(value);
      }
    });
    map.put("eyeColor", new BeanPropertyDeserializer<Contact, EyeColor>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return EnumJsonDeserializer.newInstance(EyeColor.class);
      }

      @Override
      public void setValue(Contact bean, EyeColor value, JsonDeserializationContext ctx) {
        bean.setEyeColor(value);
      }
    });
    map.put("name", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setName(value);
      }
    });
    map.put("gender", new BeanPropertyDeserializer<Contact, Gender>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return EnumJsonDeserializer.newInstance(Gender.class);
      }

      @Override
      public void setValue(Contact bean, Gender value, JsonDeserializationContext ctx) {
        bean.setGender(value);
      }
    });
    map.put("company", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setCompany(value);
      }
    });
    map.put("email", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setEmail(value);
      }
    });
    map.put("phone", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setPhone(value);
      }
    });
    map.put("address", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setAddress(value);
      }
    });
    map.put("about", new BeanPropertyDeserializer<Contact, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Contact bean, String value, JsonDeserializationContext ctx) {
        bean.setAbout(value);
      }
    });
    return map;
  }
}
