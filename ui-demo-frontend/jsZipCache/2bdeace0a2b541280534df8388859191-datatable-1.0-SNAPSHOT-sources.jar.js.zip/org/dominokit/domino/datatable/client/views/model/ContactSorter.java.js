/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactSorter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactSorter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RecordsSorter = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter');
const _Double = goog.require('java.lang.Double');
const _j_l_String = goog.require('java.lang.String');
const _Comparator = goog.require('java.util.Comparator');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _ToDoubleFunction = goog.require('java.util.function.ToDoubleFunction');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _SortDirection = goog.require('org.dominokit.domino.ui.datatable.plugins.SortDirection');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var ContactSorter = goog.require('org.dominokit.domino.datatable.client.views.model.ContactSorter$impl');
exports = ContactSorter;
 