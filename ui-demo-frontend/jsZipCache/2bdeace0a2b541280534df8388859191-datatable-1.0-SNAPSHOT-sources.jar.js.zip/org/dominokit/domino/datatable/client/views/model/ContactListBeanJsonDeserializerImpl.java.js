/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList');
const _$1 = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$1');
const _$2 = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$2');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var ContactListBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl$impl');
exports = ContactListBeanJsonDeserializerImpl;
 