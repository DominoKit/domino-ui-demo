/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$10.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$10$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let StringJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Contact, ?string>}
  */
class $10 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_10;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {!$10}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    $10.$clinit();
    let $instance = new $10();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_10__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_10__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_10 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return StringJsonDeserializer.m_getInstance__();
  }
  
  /**
   * @param {Contact} bean
   * @param {?string} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setCompany__java_lang_String(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Contact} */ ($Casts.$to(arg0, Contact)), /**@type {?string} */ ($Casts.$to(arg1, j_l_String)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $10;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $10);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $10.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    StringJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($10, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$10'));




exports = $10; 
//# sourceMappingURL=ContactBeanJsonDeserializerImpl$10.js.map