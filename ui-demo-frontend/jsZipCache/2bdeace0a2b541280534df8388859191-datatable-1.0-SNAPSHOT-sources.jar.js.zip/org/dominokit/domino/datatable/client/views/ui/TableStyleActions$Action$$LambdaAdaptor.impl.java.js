/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Action$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Action = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action$impl');


/**
 * @implements {Action}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():void} */
    this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$LambdaAdaptor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$LambdaAdaptor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_execute__() {
    {
      let $function = this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action_$LambdaAdaptor;
      $function();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Action$$LambdaAdaptor'));


Action.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=TableStyleActions$Action$$LambdaAdaptor.js.map