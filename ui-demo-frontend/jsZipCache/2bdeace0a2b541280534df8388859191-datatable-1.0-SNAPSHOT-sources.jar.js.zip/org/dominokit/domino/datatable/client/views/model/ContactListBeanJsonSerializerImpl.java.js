/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer');
const _Class = goog.require('java.lang.Class');
const _ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList');
const _$1 = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.$1');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var ContactListBeanJsonSerializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$impl');
exports = ContactListBeanJsonSerializerImpl;
 