/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$9.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$9$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$impl');
let Gender = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Gender$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let EnumJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Contact, Gender>}
  */
class $9 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_9;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {!$9}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    $9.$clinit();
    let $instance = new $9();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_9__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_9__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_9 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return /**@type {EnumJsonDeserializer<Gender>} */ (EnumJsonDeserializer.m_newInstance__java_lang_Class(Class.$get(Gender)));
  }
  
  /**
   * @param {Contact} bean
   * @param {Gender} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_datatable_client_views_model_Gender__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setGender__org_dominokit_domino_datatable_client_views_model_Gender(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_datatable_client_views_model_Gender__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Contact} */ ($Casts.$to(arg0, Contact)), /**@type {Gender} */ ($Casts.$to(arg1, Gender)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $9;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $9);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $9.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    Gender = goog.module.get('org.dominokit.domino.datatable.client.views.model.Gender$impl');
    EnumJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($9, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$9'));




exports = $9; 
//# sourceMappingURL=ContactBeanJsonDeserializerImpl$9.js.map