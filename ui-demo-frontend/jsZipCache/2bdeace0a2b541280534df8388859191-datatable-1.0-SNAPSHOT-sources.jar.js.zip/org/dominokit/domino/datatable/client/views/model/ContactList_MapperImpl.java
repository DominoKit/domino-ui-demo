package org.dominokit.domino.datatable.client.views.model;

import java.lang.Override;
import org.dominokit.jacksonapt.AbstractObjectMapper;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonSerializer;

public final class ContactList_MapperImpl extends AbstractObjectMapper<ContactList> {
  public static final ContactList_MapperImpl INSTANCE = new ContactList_MapperImpl();

  public ContactList_MapperImpl() {
    super("ContactList");
  }

  @Override
  protected JsonDeserializer<ContactList> newDeserializer() {
    return new ContactListBeanJsonDeserializerImpl();
  }

  @Override
  protected JsonSerializer<?> newSerializer() {
    return new ContactListBeanJsonSerializerImpl();
  }
}
