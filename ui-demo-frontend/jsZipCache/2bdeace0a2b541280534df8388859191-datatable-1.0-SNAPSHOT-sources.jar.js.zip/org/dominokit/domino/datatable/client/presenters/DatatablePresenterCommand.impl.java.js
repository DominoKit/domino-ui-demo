/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let DatatablePresenter = goog.forwardDeclare('org.dominokit.domino.datatable.client.presenters.DatatablePresenter$impl');


/**
 * @extends {PresenterCommand<DatatablePresenter>}
  */
class DatatablePresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatatablePresenterCommand()'.
   * @return {!DatatablePresenterCommand}
   * @public
   */
  static $create__() {
    DatatablePresenterCommand.$clinit();
    let $instance = new DatatablePresenterCommand();
    $instance.$ctor__org_dominokit_domino_datatable_client_presenters_DatatablePresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatatablePresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_presenters_DatatablePresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatatablePresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatatablePresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatatablePresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatatablePresenterCommand, $Util.$makeClassName('org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand'));




exports = DatatablePresenterCommand; 
//# sourceMappingURL=DatatablePresenterCommand.js.map