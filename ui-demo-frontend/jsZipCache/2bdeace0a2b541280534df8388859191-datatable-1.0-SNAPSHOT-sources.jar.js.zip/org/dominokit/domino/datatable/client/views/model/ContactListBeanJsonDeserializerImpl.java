package org.dominokit.domino.datatable.client.views.model;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.deser.collection.ListJsonDeserializer;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class ContactListBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<ContactList> {
  public ContactListBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return ContactList.class;
  }

  @Override
  protected InstanceBuilder<ContactList> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<ContactList>() {
      @Override
      public Instance<ContactList> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<ContactList>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private ContactList create() {
        return new ContactList();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<ContactList, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<ContactList, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("contacts", new BeanPropertyDeserializer<ContactList, List<Contact>>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return ListJsonDeserializer.newInstance(new ContactBeanJsonDeserializerImpl());
      }

      @Override
      public void setValue(ContactList bean, List<Contact> value, JsonDeserializationContext ctx) {
        bean.setContacts(value);
      }
    });
    return map;
  }
}
