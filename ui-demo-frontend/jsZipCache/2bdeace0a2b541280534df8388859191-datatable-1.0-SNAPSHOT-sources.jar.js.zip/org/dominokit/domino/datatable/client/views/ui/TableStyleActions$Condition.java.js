/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Condition.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition.$LambdaAdaptor');


// Re-exports the implementation.
var Condition = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition$impl');
exports = Condition;
 