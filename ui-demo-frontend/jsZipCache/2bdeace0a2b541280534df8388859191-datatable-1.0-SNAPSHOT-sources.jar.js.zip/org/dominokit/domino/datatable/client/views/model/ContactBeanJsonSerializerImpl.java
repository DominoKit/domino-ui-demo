package org.dominokit.domino.datatable.client.views.model;

import java.lang.Boolean;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Override;
import java.lang.Short;
import java.lang.String;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.BaseNumberJsonSerializer;
import org.dominokit.jacksonapt.ser.BooleanJsonSerializer;
import org.dominokit.jacksonapt.ser.EnumJsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class ContactBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Contact> {
  public ContactBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Contact.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[13];
    result[0] = new BeanPropertySerializer<Contact, Integer>("index") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BaseNumberJsonSerializer.IntegerJsonSerializer.getInstance();
      }

      @Override
      public Integer getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getIndex();
      }
    };
    result[1] = new BeanPropertySerializer<Contact, Boolean>("active") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BooleanJsonSerializer.getInstance();
      }

      @Override
      public Boolean getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.isActive();
      }
    };
    result[2] = new BeanPropertySerializer<Contact, String>("balance") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getBalance();
      }
    };
    result[3] = new BeanPropertySerializer<Contact, String>("picture") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getPicture();
      }
    };
    result[4] = new BeanPropertySerializer<Contact, Short>("age") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return BaseNumberJsonSerializer.ShortJsonSerializer.getInstance();
      }

      @Override
      public Short getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getAge();
      }
    };
    result[5] = new BeanPropertySerializer<Contact, EyeColor>("eyeColor") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return EnumJsonSerializer.getInstance();
      }

      @Override
      public EyeColor getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getEyeColor();
      }
    };
    result[6] = new BeanPropertySerializer<Contact, String>("name") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getName();
      }
    };
    result[7] = new BeanPropertySerializer<Contact, Gender>("gender") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return EnumJsonSerializer.getInstance();
      }

      @Override
      public Gender getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getGender();
      }
    };
    result[8] = new BeanPropertySerializer<Contact, String>("company") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getCompany();
      }
    };
    result[9] = new BeanPropertySerializer<Contact, String>("email") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getEmail();
      }
    };
    result[10] = new BeanPropertySerializer<Contact, String>("phone") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getPhone();
      }
    };
    result[11] = new BeanPropertySerializer<Contact, String>("address") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getAddress();
      }
    };
    result[12] = new BeanPropertySerializer<Contact, String>("about") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Contact bean, JsonSerializationContext ctx) {
        return bean.getAbout();
      }
    };
    return result;
  }
}
