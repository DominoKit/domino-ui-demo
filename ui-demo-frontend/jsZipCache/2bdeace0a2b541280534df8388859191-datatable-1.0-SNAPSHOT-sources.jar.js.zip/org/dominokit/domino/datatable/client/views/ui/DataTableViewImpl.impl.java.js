/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const DatatableView = goog.require('org.dominokit.domino.datatable.client.views.DatatableView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLTableCellElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactList = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
let ContactSearchFilter = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter$impl');
let ContactSorter = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactSorter$impl');
let Gender = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Gender$impl');
let ContactDetails = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.ContactDetails$impl');
let ContactUiUtils = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils$impl');
let ContactsTopPanel = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$2$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$4$impl');
let ContactListParseHandler = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler$impl');
let TableStyleActions = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let CellRenderer = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let CellStyler = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let SelectionChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');
let TableConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableConfig$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let SimplePaginationPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SimplePaginationPlugin$impl');
let AdvancedPaginationPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.AdvancedPaginationPlugin$impl');
let BodyScrollPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin$impl');
let ColumnHeaderFilterPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin$impl');
let HeaderActionElement = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');
let HeaderBarPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$impl');
let ClearSearch = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.ClearSearch$impl');
let SearchTableAction = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction$impl');
let RecordDetailsPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$impl');
let RowMarkerPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$impl');
let MarkerColor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor$impl');
let ScrollingPaginationPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin$impl');
let SelectionPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin$impl');
let SortPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortPlugin$impl');
let BooleanHeaderFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.filter.header.BooleanHeaderFilter$impl');
let DoubleHeaderFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.filter.header.DoubleHeaderFilter$impl');
let EnumHeaderFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter$impl');
let SelectHeaderFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.filter.header.SelectHeaderFilter$impl');
let TextHeaderFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.filter.header.TextHeaderFilter$impl');
let LocalListDataStore = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.LocalListDataStore$impl');
let LocalListScrollingDataSource = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Response = goog.forwardDeclare('org.dominokit.rest.shared.Response$impl');
let RestfulRequest = goog.forwardDeclare('org.dominokit.rest.shared.RestfulRequest$impl');
let SuccessHandler = goog.forwardDeclare('org.dominokit.rest.shared.RestfulRequest.SuccessHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {DatatableView}
  */
class DataTableViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_;
    /** @public {List<ContactListParseHandler>} */
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'DataTableViewImpl()'.
   * @return {!DataTableViewImpl}
   * @public
   */
  static $create__() {
    DataTableViewImpl.$clinit();
    let $instance = new DataTableViewImpl();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DataTableViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("DATA TABLES", "For detailed demo code please visit: ").m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/DominoKit/domino-ui-demo/tree/master/datatable"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_textContent__java_lang_String("Data table demo source code"), HtmlContentBuilder)).m_asElement__()).m_asElement__());
    this.m_basicTable___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_basicFixedTable___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_selectionPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_markerPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_recordDetailsPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_tableHeaderBarPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_sortAndSearch___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_simplePagination___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_scrollingPagination___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_advancedPagination___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_scrollableTable___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_topPanelPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    this.m_allInOne___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    RestfulRequest.m_get__java_lang_String("https://raw.githubusercontent.com/DominoKit/domino-ui-demo/master/" + j_l_String.m_valueOf__java_lang_Object(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl) + "/src/main/java/org/dominokit/domino/" + j_l_String.m_valueOf__java_lang_Object(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl) + "/client/views/generated.json").m_onSuccess__org_dominokit_rest_shared_RestfulRequest_SuccessHandler(SuccessHandler.$adapt(((/** Response */ response) =>{
      let contactList = /**@type {ContactList} */ ($Casts.$to(ContactList.f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList.m_read__java_lang_String(response.m_getBodyAsString__()), ContactList));
      this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ContactListParseHandler */ contactListParseHandler) =>{
        contactListParseHandler.m_onContactsParsed__java_util_List(contactList.m_getContacts__());
      })));
    }))).m_send__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicTable___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = this.m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__()).m_setAutoSort__boolean(true).m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("BASIC TABLE", "By default a table will auto fit columns and allow custom cell content").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      table.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "basicTable").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicFixedTable___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = /**@type {!TableConfig<Contact>} */ (TableConfig.$create__());
    tableConfig.m_setFixed__boolean(true).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("id", "#")).m_textAlign__java_lang_String("right").m_asHeader__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell.m_getTableRow__().m_getRecord__(), Contact)).m_getIndex__() + 1 + "");
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("status", "Status")).m_textAlign__java_lang_String("center").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$1$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$1$.m_getTableRow__().m_getRecord__(), Contact)).m_isActive__()) {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__())).m_setColor__java_lang_String(Color.f_GREEN_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      } else {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__())).m_setColor__java_lang_String(Color.f_RED_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      }
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("firstName", "First name")).m_setWidth__java_lang_String("200px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$2$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$2$.m_getTableRow__().m_getRecord__(), Contact)).m_getName__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("gender", "Gender")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$3$) =>{
      return ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$3$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("eyeColor", "Eye color")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$4$) =>{
      return ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$4$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("balance", "Balance")).m_setWidth__java_lang_String("250px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cellInfo) =>{
      return ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo.m_getRecord__(), Contact)));
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("email", "Email")).m_setWidth__java_lang_String("300px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$5$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$5$.m_getTableRow__().m_getRecord__(), Contact)).m_getEmail__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("phone", "Phone")).m_setWidth__java_lang_String("150px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$6$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$6$.m_getTableRow__().m_getRecord__(), Contact)).m_getPhone__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("badges", "Badges")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$7$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$7$.m_getTableRow__().m_getRecord__(), Contact)).m_getAge__() < 35) {
        return Badge.m_create__java_lang_String("Young").m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_asElement__();
      }
      return TextNode.m_of__java_lang_String("");
    }))));
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    let defaultTable = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("BASIC TABLE - FIXED", "Fixed tables will use the specified column width and will have scrolls when elements exceeds the body height. ").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(defaultTable)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(defaultTable).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      defaultTable.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "fixedBasicTable").m_asElement__());
  }
  
  /**
   * @param {List<Contact>} contacts
   * @return {List<Contact>}
   * @public
   */
  m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts) {
    return this.m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, 0, 15);
  }
  
  /**
   * @param {List<Contact>} contacts
   * @param {number} from
   * @param {number} to
   * @return {List<Contact>}
   * @public
   */
  m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, from, to) {
    return /**@type {List<Contact>} */ ($Casts.$to(/**@type {Stream<Contact>} */ (contacts.subList(from, to).m_stream__().m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** Contact */ arg0) =>{
      return Contact.$create__org_dominokit_domino_datatable_client_views_model_Contact(arg0);
    })))).m_collect__java_util_stream_Collector(/**@type {Collector<Contact, ?, List<Contact>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_selectionPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let singleSelectionTableConfig = this.m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    singleSelectionTableConfig.m_setMultiSelect__boolean(false);
    singleSelectionTableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SelectionPlugin<Contact>} */ (SelectionPlugin.$create__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_LIGHT_BLUE__org_dominokit_domino_ui_style_ColorScheme)));
    let singleLocalStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    let singleSelectionTable = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(singleSelectionTableConfig, singleLocalStore));
    singleSelectionTable.m_addSelectionListener__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener(SelectionChangeListener.$adapt(((/** List<TableRow<Contact>> */ selectedTableRows, /** List<Contact> */ selectedRecords) =>{
      Notification.m_create__java_lang_String(selectedRecords.size() + "").m_show__();
    })));
    let multiSelectionTableConfig = this.m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    multiSelectionTableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SelectionPlugin<Contact>} */ (SelectionPlugin.$create__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_LIGHT_BLUE__org_dominokit_domino_ui_style_ColorScheme)));
    let multiLocalStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    let multiSelectionTable = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(multiSelectionTableConfig, multiLocalStore));
    multiSelectionTable.m_addSelectionListener__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener(SelectionChangeListener.$adapt(((/** List<TableRow<Contact>> */ selectedTableRows$1$, /** List<Contact> */ selectedRecords$1$) =>{
      Notification.m_create__java_lang_String(selectedRecords$1$.size() + "").m_show__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SELECTION PLUGIN", "Enable row selection by adding the selection plugin, pass different selection style colors in the constructor.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("SINGLE SELECTION")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(singleSelectionTable)).m_appendChild__elemental2_dom_Node(singleSelectionTable.m_asElement__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("MULTI SELECTION")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(multiSelectionTable)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(multiSelectionTable).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      singleLocalStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      singleLocalStore.m_load__();
      multiLocalStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      multiSelectionTable.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "selectionPlugin").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_markerPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = this.m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!RowMarkerPlugin<Contact>} */ (RowMarkerPlugin.$create__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor(MarkerColor.$adapt(((/** CellInfo<Contact> */ tableCellInfo) =>{
      return ContactUiUtils.m_getBalanceColor__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(tableCellInfo.m_getRecord__(), Contact)));
    })))));
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    let defaultTable = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("MARKER PLUGIN", "Mark the left side of the row with custom colors").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(defaultTable)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(defaultTable).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      defaultTable.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "markerPlugin").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_recordDetailsPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = this.m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!RecordDetailsPlugin<Contact>} */ (RecordDetailsPlugin.$create__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return ContactDetails.$create__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell).m_asElement__();
    })))));
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    let defaultTable = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("RECORD DETAILS PLUGIN", "Enable inline record details for rows.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(defaultTable)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(defaultTable).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      defaultTable.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "recordDetailsPlugin").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_tableHeaderBarPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = this.m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SelectionPlugin<Contact>} */ (SelectionPlugin.$create__()));
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!HeaderBarPlugin<Contact>} */ (HeaderBarPlugin.$create__java_lang_String__java_lang_String("Demo table", "this a sample table with all features")).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(HeaderActionElement.$adapt(((/** DataTable<Contact> */ dataTable) =>{
      let selectInactiveIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__().m_clickable__(), Icon)).m_setTooltip__java_lang_String("Select Inactive"), Icon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
        dataTable.m_getItems__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<Contact> */ item) =>{
          if (!/**@type {Contact} */ ($Casts.$to(item.m_getRecord__(), Contact)).m_isActive__()) {
            item.m_select__();
          } else {
            item.m_deselect__();
          }
        })));
      }))), Icon));
      return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(selectInactiveIcon), HtmlContentBuilder)).m_asElement__();
    }))).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(HeaderActionElement.$adapt(((/** DataTable<Contact> */ dataTable$1$) =>{
      let selectInactiveIcon$1$ = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__().m_clickable__(), Icon)).m_setTooltip__java_lang_String("Select Active"), Icon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
        dataTable$1$.m_getItems__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<Contact> */ tableRow) =>{
          if (/**@type {Contact} */ ($Casts.$to(tableRow.m_getRecord__(), Contact)).m_isActive__()) {
            tableRow.m_select__();
          } else {
            tableRow.m_deselect__();
          }
        })));
      }))), Icon));
      return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(selectInactiveIcon$1$), HtmlContentBuilder)).m_asElement__();
    }))));
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    let defaultTable = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("HEADER BAR PLUGIN", "Adds a title and description for the table, and allow adding elements to the top right side of the table").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(defaultTable)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(defaultTable).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      defaultTable.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "headerBarPlugin").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_sortAndSearch___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = this.m_createSortableTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {ColumnHeaderFilterPlugin<Contact>} */ (ColumnHeaderFilterPlugin.m_create__()).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("firstName", /**@type {TextHeaderFilter<Contact>} */ (TextHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("email", /**@type {TextHeaderFilter<Contact>} */ (TextHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("phone", /**@type {TextHeaderFilter<Contact>} */ (TextHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("status", /**@type {BooleanHeaderFilter<Contact>} */ (BooleanHeaderFilter.m_create__java_lang_String__java_lang_String__java_lang_String("Active", "Inactive", "Both"))).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("gender", /**@type {EnumHeaderFilter<Contact, Gender>} */ (EnumHeaderFilter.m_create__arrayOf_java_lang_Enum(Gender.m_values__()))).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("balance", /**@type {DoubleHeaderFilter<Contact>} */ (DoubleHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("eyeColor", /**@type {SelectHeaderFilter<Contact>} */ (SelectHeaderFilter.m_create__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("blue", "Blue"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("brown", "Brown"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("green", "Green")))));
    let listStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    listStore.m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    listStore.m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, listStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SORT PLUGIN & SEARCH HEADER ACTION", "Allows the table to fire events useful for datasource to sort and search the data").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      listStore.m_setData__java_util_List(this.m_subList__java_util_List_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts));
      table.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "sortAndSearch").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_simplePagination___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let simplePaginationPlugin = /**@type {!SimplePaginationPlugin<Contact>} */ (SimplePaginationPlugin.$create__int(10));
    let tableConfig = this.m_createSortableTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(simplePaginationPlugin);
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    localListDataStore.m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    localListDataStore.m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__());
    localListDataStore.m_setPagination__org_dominokit_domino_ui_pagination_HasPagination(simplePaginationPlugin.m_getSimplePagination__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SIMPLE PAGINATION", "Simple pagination plugin allows the table to fire pagination events helpful for the datasource").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, 0, 100));
      table.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "simplePagination").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_scrollingPagination___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let scrollingPagination = /**@type {!ScrollingPaginationPlugin<Contact>} */ (ScrollingPaginationPlugin.$create__int__int(10, 5));
    let tableConfig = this.m_createSortableTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(scrollingPagination);
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    localListDataStore.m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    localListDataStore.m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__());
    localListDataStore.m_setPagination__org_dominokit_domino_ui_pagination_HasPagination(scrollingPagination.m_getPagination__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SCROLLING PAGINATION", "Scrolling pagination plugin allows navigation through a set of page at a time in datatable").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, 0, 100));
      table.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "scrollingPagination").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_advancedPagination___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let advancedPagination = /**@type {!AdvancedPaginationPlugin<Contact>} */ (AdvancedPaginationPlugin.$create__int(10));
    let tableConfig = this.m_createSortableTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl();
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(advancedPagination);
    let localListDataStore = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__());
    localListDataStore.m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    localListDataStore.m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__());
    localListDataStore.m_setPagination__org_dominokit_domino_ui_pagination_HasPagination(advancedPagination.m_getPagination__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataStore));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ADVANCED PAGINATION", "Advanced pagination plugin allows navigation through pages from a dropdown list").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      localListDataStore.m_setData__java_util_List(this.m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, 0, 100));
      table.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "advancedPagination").m_asElement__());
  }
  
  /**
   * @return {TableConfig<Contact>}
   * @public
   */
  m_createSortableTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = /**@type {!TableConfig<Contact>} */ (TableConfig.$create__());
    tableConfig.m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("id", "#")).m_textAlign__java_lang_String("right").m_asHeader__().m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell.m_getTableRow__().m_getRecord__(), Contact)).m_getIndex__() + 1 + "");
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("status", "Status")).m_textAlign__java_lang_String("center").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$1$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$1$.m_getTableRow__().m_getRecord__(), Contact)).m_isActive__()) {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__())).m_setColor__java_lang_String(Color.f_GREEN_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      } else {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__())).m_setColor__java_lang_String(Color.f_RED_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      }
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("firstName", "First name")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$2$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$2$.m_getTableRow__().m_getRecord__(), Contact)).m_getName__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("gender", "Gender")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$3$) =>{
      return ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$3$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("eyeColor", "Eye color")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$4$) =>{
      return ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$4$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("balance", "Balance")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cellInfo) =>{
      return ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo.m_getRecord__(), Contact)));
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("email", "Email")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$5$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$5$.m_getTableRow__().m_getRecord__(), Contact)).m_getEmail__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("phone", "Phone")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$6$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$6$.m_getTableRow__().m_getRecord__(), Contact)).m_getPhone__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("badges", "Badges")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$7$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$7$.m_getTableRow__().m_getRecord__(), Contact)).m_getAge__() < 35) {
        return Badge.m_create__java_lang_String("Young").m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_asElement__();
      }
      return TextNode.m_of__java_lang_String("");
    }))));
    tableConfig.m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SortPlugin<Contact>} */ (SortPlugin.$create__())).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!HeaderBarPlugin<Contact>} */ (HeaderBarPlugin.$create__java_lang_String__java_lang_String("Demo table", "this a sample table with all features")).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(/**@type {!ClearSearch<Contact>} */ (ClearSearch.$create__())).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(/**@type {!SearchTableAction<Contact>} */ (SearchTableAction.$create__())));
    return tableConfig;
  }
  
  /**
   * @return {TableConfig<Contact>}
   * @public
   */
  m_createBasicTableConfig___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = /**@type {!TableConfig<Contact>} */ (TableConfig.$create__());
    tableConfig.m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("id", "#")).m_textAlign__java_lang_String("right").m_asHeader__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell.m_getTableRow__().m_getRecord__(), Contact)).m_getIndex__() + 1 + "");
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("status", "Status")).m_textAlign__java_lang_String("center").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$1$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$1$.m_getTableRow__().m_getRecord__(), Contact)).m_isActive__()) {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__())).m_setColor__java_lang_String(Color.f_GREEN_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      } else {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__())).m_setColor__java_lang_String(Color.f_RED_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      }
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("firstName", "First name")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$2$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$2$.m_getTableRow__().m_getRecord__(), Contact)).m_getName__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("gender", "Gender")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$3$) =>{
      return ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$3$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("eyeColor", "Eye color")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$4$) =>{
      return ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$4$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("balance", "Balance")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cellInfo) =>{
      return ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo.m_getRecord__(), Contact)));
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("email", "Email")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$5$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$5$.m_getTableRow__().m_getRecord__(), Contact)).m_getEmail__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("phone", "Phone")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$6$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$6$.m_getTableRow__().m_getRecord__(), Contact)).m_getPhone__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("badges", "Badges")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$7$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$7$.m_getTableRow__().m_getRecord__(), Contact)).m_getAge__() < 35) {
        return Badge.m_create__java_lang_String("Young").m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_asElement__();
      }
      return TextNode.m_of__java_lang_String("");
    }))));
    return tableConfig;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_scrollableTable___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let tableConfig = /**@type {!TableConfig<Contact>} */ (TableConfig.$create__());
    tableConfig.m_setFixed__boolean(true).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("id", "#")).m_sortable__().m_styleCell__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(CellStyler.$adapt(((/** HTMLTableCellElement */ cellElement) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(cellElement)).m_setProperty__java_lang_String__java_lang_String("vertical-align", "middle");
    }))).m_textAlign__java_lang_String("right").m_asHeader__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell.m_getTableRow__().m_getRecord__(), Contact)).m_getIndex__() + 1 + "");
    }))).m_setWidth__java_lang_String("70px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("status", "Status")).m_setWidth__java_lang_String("80px").m_textAlign__java_lang_String("center").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$1$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$1$.m_getTableRow__().m_getRecord__(), Contact)).m_isActive__()) {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__())).m_setColor__java_lang_String(Color.f_GREEN_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      } else {
        return /**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__())).m_setColor__java_lang_String(Color.f_RED_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      }
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("firstName", "First name")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$2$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$2$.m_getTableRow__().m_getRecord__(), Contact)).m_getName__());
    }))).m_setWidth__java_lang_String("200px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("gender", "Gender")).m_setWidth__java_lang_String("100px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$3$) =>{
      return ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$3$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("eyeColor", "Eye color")).m_styleHeader__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(CellStyler.$adapt(((/** HTMLTableCellElement */ head) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(head)).m_setWidth__java_lang_String("100px");
    }))).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$4$) =>{
      return ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$4$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center").m_maxWidth__java_lang_String("120px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("balance", "Balance")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cellInfo) =>{
      return ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo.m_getRecord__(), Contact)));
    }))).m_setWidth__java_lang_String("200px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("email", "Email")).m_setWidth__java_lang_String("250px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$5$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$5$.m_getTableRow__().m_getRecord__(), Contact)).m_getEmail__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("phone", "Phone")).m_setWidth__java_lang_String("200px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$6$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$6$.m_getTableRow__().m_getRecord__(), Contact)).m_getPhone__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("badges", "Badges")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$7$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$7$.m_getTableRow__().m_getRecord__(), Contact)).m_getAge__() < 35) {
        return Badge.m_create__java_lang_String("Young").m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_asElement__();
      }
      return TextNode.m_of__java_lang_String("");
    })))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!BodyScrollPlugin<Contact>} */ (BodyScrollPlugin.$create__())).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!HeaderBarPlugin<Contact>} */ (HeaderBarPlugin.$create__java_lang_String__java_lang_String("Demo table", "this a sample table with all features")).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(/**@type {!SearchTableAction<Contact>} */ (SearchTableAction.$create__()))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SortPlugin<Contact>} */ (SortPlugin.$create__()));
    let scrollingDataSource = /**@type {!LocalListScrollingDataSource<Contact>} */ (LocalListScrollingDataSource.$create__int(10)).m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__()).m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, scrollingDataSource));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SCROLL LOADING", "Scroll loading requires the table to be fixed. use the Body scroll plugin to fire scroll events.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      scrollingDataSource.m_setData__java_util_List(contacts.subList(0, 100));
      table.m_load__();
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "scrollLoading").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_topPanelPlugin___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let topPanel = /**@type {!ContactsTopPanel<Contact>} */ (ContactsTopPanel.$create__());
    let tableConfig = /**@type {!TableConfig<Contact>} */ (TableConfig.$create__());
    tableConfig.m_setFixed__boolean(true).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("id", "#")).m_sortable__().m_styleCell__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(CellStyler.$adapt(((/** HTMLTableCellElement */ cellElement) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(cellElement)).m_setProperty__java_lang_String__java_lang_String("vertical-align", "middle");
    }))).m_textAlign__java_lang_String("right").m_asHeader__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell.m_getTableRow__().m_getRecord__(), Contact)).m_getIndex__() + 1 + "");
    }))).m_setWidth__java_lang_String("70px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("status", "Status")).m_setWidth__java_lang_String("80px").m_textAlign__java_lang_String("center").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$1$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$1$.m_getTableRow__().m_getRecord__(), Contact)).m_isActive__()) {
        return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__().m_asElement__())).m_setColor__java_lang_String(Color.f_GREEN_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      } else {
        return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__().m_asElement__())).m_setColor__java_lang_String(Color.f_RED_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      }
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("firstName", "First name")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$2$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$2$.m_getTableRow__().m_getRecord__(), Contact)).m_getName__());
    }))).m_setWidth__java_lang_String("200px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("gender", "Gender")).m_setWidth__java_lang_String("100px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$3$) =>{
      return ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$3$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("eyeColor", "Eye color")).m_styleHeader__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(CellStyler.$adapt(((/** HTMLTableCellElement */ head) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(head)).m_setWidth__java_lang_String("100px");
    }))).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$4$) =>{
      return ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$4$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center").m_maxWidth__java_lang_String("120px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("balance", "Balance")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cellInfo) =>{
      return ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo.m_getRecord__(), Contact)));
    }))).m_setWidth__java_lang_String("200px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("email", "Email")).m_setWidth__java_lang_String("250px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$5$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$5$.m_getTableRow__().m_getRecord__(), Contact)).m_getEmail__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("phone", "Phone")).m_setWidth__java_lang_String("200px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$6$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$6$.m_getTableRow__().m_getRecord__(), Contact)).m_getPhone__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("badges", "Badges")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$7$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$7$.m_getTableRow__().m_getRecord__(), Contact)).m_getAge__() < 35) {
        return Badge.m_create__java_lang_String("Young").m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_asElement__();
      }
      return TextNode.m_of__java_lang_String("");
    })))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!BodyScrollPlugin<Contact>} */ (BodyScrollPlugin.$create__())).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin($1.$create__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel(this, topPanel)).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!HeaderBarPlugin<Contact>} */ (HeaderBarPlugin.$create__java_lang_String__java_lang_String("Demo table", "this a sample table with all features")).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(/**@type {!SearchTableAction<Contact>} */ (SearchTableAction.$create__()))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SortPlugin<Contact>} */ (SortPlugin.$create__()));
    let scrollingDataSource = /**@type {!LocalListScrollingDataSource<Contact>} */ (LocalListScrollingDataSource.$create__int(10)).m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__()).m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, scrollingDataSource));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("TOP PANEL PLUGIN", "A simple panel that listens to datatable events and update its content accordingly.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      let data = this.m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, 0, 100);
      scrollingDataSource.m_setData__java_util_List(data);
      table.m_load__();
      topPanel.m_update__java_util_List(data);
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "topPanelPlugin").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_allInOne___$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    let topPanel = /**@type {!ContactsTopPanel<Contact>} */ (ContactsTopPanel.$create__());
    let scrollingPaginationPlugin = /**@type {!ScrollingPaginationPlugin<Contact>} */ (ScrollingPaginationPlugin.$create__int__int(10, 5));
    let tableConfig = /**@type {!TableConfig<Contact>} */ (TableConfig.$create__());
    tableConfig.m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("id", "#")).m_sortable__().m_styleCell__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(CellStyler.$adapt(((/** HTMLTableCellElement */ cellElement) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(cellElement)).m_setProperty__java_lang_String__java_lang_String("vertical-align", "middle");
    }))).m_textAlign__java_lang_String("right").m_asHeader__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell.m_getTableRow__().m_getRecord__(), Contact)).m_getIndex__() + 1 + "");
    }))).m_setWidth__java_lang_String("70px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("status", "Status")).m_setWidth__java_lang_String("80px").m_textAlign__java_lang_String("center").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$1$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$1$.m_getTableRow__().m_getRecord__(), Contact)).m_isActive__()) {
        return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__().m_asElement__())).m_setColor__java_lang_String(Color.f_GREEN_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      } else {
        return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__().m_asElement__())).m_setColor__java_lang_String(Color.f_RED_DARKEN_3__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
      }
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("firstName", "First name")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$2$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$2$.m_getTableRow__().m_getRecord__(), Contact)).m_getName__());
    }))).m_setWidth__java_lang_String("200px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("gender", "Gender")).m_setWidth__java_lang_String("100px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$3$) =>{
      return ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$3$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("eyeColor", "Eye color")).m_styleHeader__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(CellStyler.$adapt(((/** HTMLTableCellElement */ head) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(head)).m_setWidth__java_lang_String("100px");
    }))).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$4$) =>{
      return ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cell$4$.m_getRecord__(), Contact)));
    }))).m_textAlign__java_lang_String("center").m_maxWidth__java_lang_String("120px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("balance", "Balance")).m_sortable__().m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cellInfo) =>{
      return ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo.m_getRecord__(), Contact)));
    }))).m_setWidth__java_lang_String("200px")).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("email", "Email")).m_setWidth__java_lang_String("250px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$5$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$5$.m_getTableRow__().m_getRecord__(), Contact)).m_getEmail__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("phone", "Phone")).m_setWidth__java_lang_String("200px").m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$6$) =>{
      return TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(cell$6$.m_getTableRow__().m_getRecord__(), Contact)).m_getPhone__());
    })))).m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<Contact>} */ (ColumnConfig.m_create__java_lang_String__java_lang_String("badges", "Badges")).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$7$) =>{
      if (/**@type {Contact} */ ($Casts.$to(cell$7$.m_getTableRow__().m_getRecord__(), Contact)).m_getAge__() < 35) {
        return Badge.m_create__java_lang_String("Young").m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_asElement__();
      }
      return TextNode.m_of__java_lang_String("");
    })))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(scrollingPaginationPlugin).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin($2.$create__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel(this, topPanel)).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!HeaderBarPlugin<Contact>} */ (HeaderBarPlugin.$create__java_lang_String__java_lang_String("Demo table", "this a sample table with all features")).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(HeaderActionElement.$adapt(((/** DataTable<Contact> */ dataTable) =>{
      let selectInactiveIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_highlight_off__().m_clickable__(), Icon)).m_setTooltip__java_lang_String("Select Inactive"), Icon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt) =>{
        dataTable.m_getItems__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<Contact> */ item) =>{
          if (!/**@type {Contact} */ ($Casts.$to(item.m_getRecord__(), Contact)).m_isActive__()) {
            item.m_select__();
          } else {
            item.m_deselect__();
          }
        })));
      }))), Icon));
      return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(selectInactiveIcon), HtmlContentBuilder)).m_asElement__();
    }))).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(HeaderActionElement.$adapt(((/** DataTable<Contact> */ dataTable$1$) =>{
      let selectInactiveIcon$1$ = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check_circle__().m_clickable__(), Icon)).m_setTooltip__java_lang_String("Select Active"), Icon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt$1$) =>{
        dataTable$1$.m_getItems__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<Contact> */ tableRow) =>{
          if (/**@type {Contact} */ ($Casts.$to(tableRow.m_getRecord__(), Contact)).m_isActive__()) {
            tableRow.m_select__();
          } else {
            tableRow.m_deselect__();
          }
        })));
      }))), Icon));
      return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(selectInactiveIcon$1$), HtmlContentBuilder)).m_asElement__();
    }))).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(/**@type {!ClearSearch<Contact>} */ (ClearSearch.$create__())).m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(/**@type {!SearchTableAction<Contact>} */ (SearchTableAction.$create__()))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!RecordDetailsPlugin<Contact>} */ (RecordDetailsPlugin.$create__org_dominokit_domino_ui_datatable_CellRenderer(CellRenderer.$adapt(((/** CellInfo<Contact> */ cell$8$) =>{
      return ContactDetails.$create__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell$8$).m_asElement__();
    }))))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SelectionPlugin<Contact>} */ (SelectionPlugin.$create__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!RowMarkerPlugin<Contact>} */ (RowMarkerPlugin.$create__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor(MarkerColor.$adapt(((/** CellInfo<Contact> */ cellInfo$1$) =>{
      return ContactUiUtils.m_getBalanceColor__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(cellInfo$1$.m_getRecord__(), Contact)));
    }))))).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {!SortPlugin<Contact>} */ (SortPlugin.$create__())).m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(/**@type {ColumnHeaderFilterPlugin<Contact>} */ (ColumnHeaderFilterPlugin.m_create__()).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("firstName", /**@type {TextHeaderFilter<Contact>} */ (TextHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("email", /**@type {TextHeaderFilter<Contact>} */ (TextHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("phone", /**@type {TextHeaderFilter<Contact>} */ (TextHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("status", /**@type {BooleanHeaderFilter<Contact>} */ (BooleanHeaderFilter.m_create__java_lang_String__java_lang_String__java_lang_String("Active", "Inactive", "Both"))).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("gender", /**@type {EnumHeaderFilter<Contact, Gender>} */ (EnumHeaderFilter.m_create__arrayOf_java_lang_Enum(Gender.m_values__()))).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("balance", /**@type {DoubleHeaderFilter<Contact>} */ (DoubleHeaderFilter.m_create__())).m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter("eyeColor", /**@type {SelectHeaderFilter<Contact>} */ (SelectHeaderFilter.m_create__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("blue", "Blue"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("brown", "Brown"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("green", "Green")))));
    let localListDataSource = /**@type {!LocalListDataStore<Contact>} */ (LocalListDataStore.$create__()).m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(ContactSearchFilter.$create__()).m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(ContactSorter.$create__()).m_setPagination__org_dominokit_domino_ui_pagination_HasPagination(scrollingPaginationPlugin.m_getPagination__());
    let table = /**@type {!DataTable<Contact>} */ (DataTable.$create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, localListDataSource));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ALL IN ONE", "Try all plugins and feature works together.").m_setCollapsible__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TableStyleActions.$create__org_dominokit_domino_ui_datatable_DataTable(table)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(table).m_asElement__());
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.add(ContactListParseHandler.$adapt(((/** List<Contact> */ contacts) =>{
      let data = this.m_subList__java_util_List__int__int_$p_org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl(contacts, 0, 100);
      localListDataSource.m_setData__java_util_List(data);
      table.m_load__();
      topPanel.m_update__java_util_List(data);
    })));
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl, "allInOne").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl() {
    this.f_element__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_contactListParseHandlers__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ = /**@type {!ArrayList<ContactListParseHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DataTableViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DataTableViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DataTableViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    List = goog.module.get('java.util.List$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    ContactList = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
    ContactSearchFilter = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter$impl');
    ContactSorter = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactSorter$impl');
    Gender = goog.module.get('org.dominokit.domino.datatable.client.views.model.Gender$impl');
    ContactDetails = goog.module.get('org.dominokit.domino.datatable.client.views.ui.ContactDetails$impl');
    ContactUiUtils = goog.module.get('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils$impl');
    ContactsTopPanel = goog.module.get('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel$impl');
    $1 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$2$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$4$impl');
    ContactListParseHandler = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler$impl');
    TableStyleActions = goog.module.get('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    CellRenderer = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer$impl');
    ColumnConfig = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
    CellStyler = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');
    DataTable = goog.module.get('org.dominokit.domino.ui.datatable.DataTable$impl');
    SelectionChangeListener = goog.module.get('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');
    TableConfig = goog.module.get('org.dominokit.domino.ui.datatable.TableConfig$impl');
    SimplePaginationPlugin = goog.module.get('org.dominokit.domino.ui.datatable.events.SimplePaginationPlugin$impl');
    AdvancedPaginationPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.AdvancedPaginationPlugin$impl');
    BodyScrollPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin$impl');
    ColumnHeaderFilterPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin$impl');
    HeaderActionElement = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');
    HeaderBarPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$impl');
    ClearSearch = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.ClearSearch$impl');
    SearchTableAction = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction$impl');
    RecordDetailsPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$impl');
    RowMarkerPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$impl');
    MarkerColor = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor$impl');
    ScrollingPaginationPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin$impl');
    SelectionPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin$impl');
    SortPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SortPlugin$impl');
    BooleanHeaderFilter = goog.module.get('org.dominokit.domino.ui.datatable.plugins.filter.header.BooleanHeaderFilter$impl');
    DoubleHeaderFilter = goog.module.get('org.dominokit.domino.ui.datatable.plugins.filter.header.DoubleHeaderFilter$impl');
    EnumHeaderFilter = goog.module.get('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter$impl');
    SelectHeaderFilter = goog.module.get('org.dominokit.domino.ui.datatable.plugins.filter.header.SelectHeaderFilter$impl');
    TextHeaderFilter = goog.module.get('org.dominokit.domino.ui.datatable.plugins.filter.header.TextHeaderFilter$impl');
    LocalListDataStore = goog.module.get('org.dominokit.domino.ui.datatable.store.LocalListDataStore$impl');
    LocalListScrollingDataSource = goog.module.get('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    RestfulRequest = goog.module.get('org.dominokit.rest.shared.RestfulRequest$impl');
    SuccessHandler = goog.module.get('org.dominokit.rest.shared.RestfulRequest.SuccessHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DataTableViewImpl, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl'));


/** @public {?string} @const */
DataTableViewImpl.f_MODULE_NAME__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl = "datatable";


DatatableView.$markImplementor(DataTableViewImpl);


exports = DataTableViewImpl; 
//# sourceMappingURL=DataTableViewImpl.js.map