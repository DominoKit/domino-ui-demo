package org.dominokit.domino.datatable.client.views.model;

public enum Gender {
    female, male
}
