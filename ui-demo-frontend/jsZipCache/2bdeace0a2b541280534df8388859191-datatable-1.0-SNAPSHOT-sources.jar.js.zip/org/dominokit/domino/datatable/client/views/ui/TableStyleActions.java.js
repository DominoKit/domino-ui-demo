/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.$LambdaAdaptor$5');
const _Action = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action');
const _Condition = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TableStyleActions = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$impl');
exports = TableStyleActions;
 