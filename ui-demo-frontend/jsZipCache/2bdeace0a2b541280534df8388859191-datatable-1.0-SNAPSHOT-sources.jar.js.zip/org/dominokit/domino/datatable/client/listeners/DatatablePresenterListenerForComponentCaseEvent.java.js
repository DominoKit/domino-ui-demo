/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.listeners.DatatablePresenterListenerForComponentCaseEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.listeners.DatatablePresenterListenerForComponentCaseEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');
const _DatatablePresenter = goog.require('org.dominokit.domino.datatable.client.presenters.DatatablePresenter');
const _DatatablePresenterCommand = goog.require('org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DatatablePresenterListenerForComponentCaseEvent = goog.require('org.dominokit.domino.datatable.client.listeners.DatatablePresenterListenerForComponentCaseEvent$impl');
exports = DatatablePresenterListenerForComponentCaseEvent;
 