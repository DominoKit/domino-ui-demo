package org.dominokit.domino.datatable.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;
import org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class DatatablePresenterListenerForComponentCaseEvent implements DominoEventListener<ComponentCaseEvent> {
  @Override
  public void listen(ComponentCaseEvent event) {
    new DatatablePresenterCommand().onPresenterReady(presenter -> presenter.onComponentCaseEvent(event.context())).send();
  }
}
