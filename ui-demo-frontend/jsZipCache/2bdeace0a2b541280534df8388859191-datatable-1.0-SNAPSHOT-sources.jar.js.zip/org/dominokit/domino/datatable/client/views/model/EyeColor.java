package org.dominokit.domino.datatable.client.views.model;

public enum EyeColor {
    blue, brown, green;
}
