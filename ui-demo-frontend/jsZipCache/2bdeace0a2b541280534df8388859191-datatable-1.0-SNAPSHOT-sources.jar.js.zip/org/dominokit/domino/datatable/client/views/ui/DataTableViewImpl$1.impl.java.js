/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const TopPanelPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactsTopPanel = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel$impl');
let DataTableViewImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableDataUpdatedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let DataTablePlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {TopPanelPlugin<Contact>}
  */
class $1 extends TopPanelPlugin {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DataTableViewImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_1;
    /** @public {ContactsTopPanel<Contact>} */
    this.$c_topPanel;
  }
  
  /**
   * Factory method corresponding to constructor 'new TopPanelPlugin(DataTableViewImpl, ContactsTopPanel)'.
   * @param {DataTableViewImpl} $outer_this
   * @param {ContactsTopPanel<Contact>} $c_topPanel
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel($outer_this, $c_topPanel) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_1__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel($outer_this, $c_topPanel);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new TopPanelPlugin(DataTableViewImpl, ContactsTopPanel)'.
   * @param {DataTableViewImpl} $outer_this
   * @param {ContactsTopPanel<Contact>} $c_topPanel
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_1__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel($outer_this, $c_topPanel) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_1 = $outer_this;
    this.$c_topPanel = $c_topPanel;
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_TopPanelPlugin__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.$c_topPanel.m_asElement__();
  }
  
  /**
   * @override
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
    if (j_l_String.m_equals__java_lang_String__java_lang_Object(TableDataUpdatedEvent.f_DATA_UPDATED__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent, event.m_getType__())) {
      this.$c_topPanel.m_update__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent(/**@type {TableDataUpdatedEvent<Contact>} */ ($Casts.$to(event, TableDataUpdatedEvent)));
    }
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @param {TableRow<Contact>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @param {ColumnConfig<Contact>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<Contact>} arg0
   * @param {TableRow<Contact>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    TableDataUpdatedEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent$impl');
    DataTablePlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    TopPanelPlugin.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$1'));




exports = $1; 
//# sourceMappingURL=DataTableViewImpl$1.js.map