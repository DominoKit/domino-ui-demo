/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$7.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$7$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$impl');
let EyeColor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let EnumJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Contact, EyeColor>}
  */
class $7 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_7;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {!$7}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    $7.$clinit();
    let $instance = new $7();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_7__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_7__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_7 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return /**@type {EnumJsonDeserializer<EyeColor>} */ (EnumJsonDeserializer.m_newInstance__java_lang_Class(Class.$get(EyeColor)));
  }
  
  /**
   * @param {Contact} bean
   * @param {EyeColor} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_datatable_client_views_model_EyeColor__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setEyeColor__org_dominokit_domino_datatable_client_views_model_EyeColor(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_datatable_client_views_model_EyeColor__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Contact} */ ($Casts.$to(arg0, Contact)), /**@type {EyeColor} */ ($Casts.$to(arg1, EyeColor)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $7;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $7);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $7.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    EyeColor = goog.module.get('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
    EnumJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($7, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$7'));




exports = $7; 
//# sourceMappingURL=ContactBeanJsonDeserializerImpl$7.js.map