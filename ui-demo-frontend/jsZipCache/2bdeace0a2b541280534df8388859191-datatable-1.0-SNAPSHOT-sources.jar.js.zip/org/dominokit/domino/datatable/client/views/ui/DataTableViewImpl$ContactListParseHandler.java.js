/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$ContactListParseHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _List = goog.require('java.util.List');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler.$LambdaAdaptor');


// Re-exports the implementation.
var ContactListParseHandler = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler$impl');
exports = ContactListParseHandler;
 