/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$ContactListParseHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ContactListParseHandler {
  /**
   * @abstract
   * @param {List<Contact>} contacts
   * @return {void}
   * @public
   */
  m_onContactsParsed__java_util_List(contacts) {
  }
  
  /**
   * @param {?function(List<Contact>):void} fn
   * @return {ContactListParseHandler}
   * @public
   */
  static $adapt(fn) {
    ContactListParseHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactListParseHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ContactListParseHandler, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$ContactListParseHandler'));


ContactListParseHandler.$markImplementor(/** @type {Function} */ (ContactListParseHandler));


exports = ContactListParseHandler; 
//# sourceMappingURL=DataTableViewImpl$ContactListParseHandler.js.map