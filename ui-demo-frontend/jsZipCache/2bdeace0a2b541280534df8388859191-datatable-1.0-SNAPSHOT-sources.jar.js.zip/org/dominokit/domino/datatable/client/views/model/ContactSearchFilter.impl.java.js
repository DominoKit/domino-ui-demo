/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactSearchFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SearchFilter = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let EyeColor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
let Gender = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Gender$impl');
let SearchEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {SearchFilter<Contact>}
  */
class ContactSearchFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactSearchFilter()'.
   * @return {!ContactSearchFilter}
   * @public
   */
  static $create__() {
    ContactSearchFilter.$clinit();
    let $instance = new ContactSearchFilter();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactSearchFilter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactSearchFilter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactSearchFilter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {SearchEvent} searchEvent
   * @param {Contact} contact
   * @return {boolean}
   * @public
   */
  m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__org_dominokit_domino_datatable_client_views_model_Contact(searchEvent, contact) {
    let searchFilters = searchEvent.m_getByCategory__org_dominokit_domino_ui_datatable_model_Category(Category.f_SEARCH__org_dominokit_domino_ui_datatable_model_Category);
    let headerFilters = searchEvent.m_getByCategory__org_dominokit_domino_ui_datatable_model_Category(Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
    let foundBySearch = searchFilters.isEmpty() || this.m_foundBySearch__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_ui_datatable_model_Filter_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {Filter} */ ($Casts.$to(searchFilters.getAtIndex(0), Filter)));
    let foundByHeaderFilter = headerFilters.m_stream__().m_allMatch__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ filter) =>{
      return this.m_findByHeaderFilter__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_ui_datatable_model_Filter_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, filter);
    })));
    return foundBySearch && foundByHeaderFilter;
  }
  
  /**
   * @param {Contact} contact
   * @param {Filter} filter
   * @return {boolean}
   * @public
   */
  m_findByHeaderFilter__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_ui_datatable_model_Filter_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, filter) {
    if (Objects.m_nonNull__java_lang_Object(filter.m_getValues__().getAtIndex(0)) && !j_l_String.m_isEmpty__java_lang_String(/**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)))) {
      switch ($InternalPreconditions.m_checkNotNull__java_lang_Object(filter.m_getFieldName__())) {
        case "firstName": 
          return this.m_filterByName__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        case "email": 
          return this.m_filterByEmail__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        case "status": 
          return this.m_filterByStatus__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        case "gender": 
          return this.m_filterByGender__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        case "eyeColor": 
          return this.m_filterByEyeColor__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        case "balance": 
          return this.m_filterByEyeBalance__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        case "phone": 
          return this.m_filterByEyePhone__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(filter.m_getValues__().getAtIndex(0), j_l_String)));
        default: 
          return false;
      }
    }
    return false;
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchContext
   * @return {boolean}
   * @public
   */
  m_filterByEyePhone__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchContext) {
    return j_l_String.m_contains__java_lang_String__java_lang_CharSequence(contact.m_getPhone__(), searchContext);
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchText
   * @return {boolean}
   * @public
   */
  m_filterByEyeBalance__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) {
    return contact.m_getDoubleBalance__() == Double.m_parseDouble__java_lang_String(searchText);
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchText
   * @return {boolean}
   * @public
   */
  m_filterByEyeColor__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) {
    return $Objects.m_equals__java_lang_Object__java_lang_Object(contact.m_getEyeColor__(), EyeColor.m_valueOf__java_lang_String(searchText));
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchText
   * @return {boolean}
   * @public
   */
  m_filterByGender__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) {
    return $Objects.m_equals__java_lang_Object__java_lang_Object(contact.m_getGender__(), Gender.m_valueOf__java_lang_String(searchText));
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchValue
   * @return {boolean}
   * @public
   */
  m_filterByStatus__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchValue) {
    return contact.m_isActive__() == Boolean.m_booleanValue__java_lang_Boolean(Boolean.m_valueOf__java_lang_String(searchValue));
  }
  
  /**
   * @param {Contact} contact
   * @param {Filter} searchFilter
   * @return {boolean}
   * @public
   */
  m_foundBySearch__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_ui_datatable_model_Filter_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchFilter) {
    if (Objects.m_nonNull__java_lang_Object(searchFilter.m_getValues__().getAtIndex(0)) && !j_l_String.m_isEmpty__java_lang_String(/**@type {?string} */ ($Casts.$to(searchFilter.m_getValues__().getAtIndex(0), j_l_String)))) {
      return this.m_filterByAll__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, /**@type {?string} */ ($Casts.$to(searchFilter.m_getValues__().getAtIndex(0), j_l_String)));
    }
    return true;
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchText
   * @return {boolean}
   * @public
   */
  m_filterByAll__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) {
    return this.m_filterByName__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) || this.m_filterByEmail__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText);
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchText
   * @return {boolean}
   * @public
   */
  m_filterByEmail__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) {
    return j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(contact.m_getEmail__()), j_l_String.m_toLowerCase__java_lang_String(searchText));
  }
  
  /**
   * @param {Contact} contact
   * @param {?string} searchText
   * @return {boolean}
   * @public
   */
  m_filterByName__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_String_$p_org_dominokit_domino_datatable_client_views_model_ContactSearchFilter(contact, searchText) {
    return j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(contact.m_getName__()), j_l_String.m_toLowerCase__java_lang_String(searchText));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {SearchEvent} arg0
   * @param {*} arg1
   * @return {boolean}
   * @public
   */
  m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__java_lang_Object(arg0, arg1) {
    return this.m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__org_dominokit_domino_datatable_client_views_model_Contact(arg0, /**@type {Contact} */ ($Casts.$to(arg1, Contact)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactSearchFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactSearchFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactSearchFilter.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    EyeColor = goog.module.get('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
    Gender = goog.module.get('org.dominokit.domino.datatable.client.views.model.Gender$impl');
    Category = goog.module.get('org.dominokit.domino.ui.datatable.model.Category$impl');
    Filter = goog.module.get('org.dominokit.domino.ui.datatable.model.Filter$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactSearchFilter, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter'));


SearchFilter.$markImplementor(ContactSearchFilter);


exports = ContactSearchFilter; 
//# sourceMappingURL=ContactSearchFilter.js.map