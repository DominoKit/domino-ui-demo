/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactList.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactList');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _List = goog.require('java.util.List');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _ContactList__MapperImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl');


// Re-exports the implementation.
var ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
exports = ContactList;
 