/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$3.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$3$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let BooleanJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Contact, ?boolean>}
  */
class $3 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_3;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {!$3}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    $3.$clinit();
    let $instance = new $3();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_3__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_3__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_3 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return BooleanJsonDeserializer.m_getInstance__();
  }
  
  /**
   * @param {Contact} bean
   * @param {?boolean} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_Boolean__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setActive__boolean(Boolean.m_booleanValue__java_lang_Boolean(value));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_Boolean__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Contact} */ ($Casts.$to(arg0, Contact)), /**@type {?boolean} */ ($Casts.$to(arg1, Boolean)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $3;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $3);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $3.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    BooleanJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($3, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$3'));




exports = $3; 
//# sourceMappingURL=ContactBeanJsonDeserializerImpl$3.js.map