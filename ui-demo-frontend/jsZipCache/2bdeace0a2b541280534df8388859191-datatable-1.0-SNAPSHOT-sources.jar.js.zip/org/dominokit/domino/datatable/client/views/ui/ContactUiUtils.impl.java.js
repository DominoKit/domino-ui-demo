/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.ContactUiUtils.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let EyeColor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
let Gender = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Gender$impl');
let Tooltip = goog.forwardDeclare('org.dominokit.domino.ui.popover.Tooltip$impl');
let Progress = goog.forwardDeclare('org.dominokit.domino.ui.progress.Progress$impl');
let ProgressBar = goog.forwardDeclare('org.dominokit.domino.ui.progress.ProgressBar$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


class ContactUiUtils extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactUiUtils()'.
   * @return {!ContactUiUtils}
   * @public
   */
  static $create__() {
    ContactUiUtils.$clinit();
    let $instance = new ContactUiUtils();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_ui_ContactUiUtils__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactUiUtils()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_ContactUiUtils__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {Contact} contact
   * @return {HTMLElement}
   * @public
   */
  static m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    let doubleBalance = contact.m_getDoubleBalance__();
    let progress = /**@type {Progress} */ ($Casts.$to(Progress.m_create__().m_addBar__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(4000).m_setValue__double(doubleBalance).m_setBackground__org_dominokit_domino_ui_style_Color(ContactUiUtils.m_getBalanceColor__double(doubleBalance).m_color__())).m_style__().m_setMargin__java_lang_String("0px").m_get__(), Progress));
    Tooltip.m_create__org_jboss_gwt_elemento_core_IsElement__java_lang_String(progress, contact.m_getBalance__());
    return progress.m_asElement__();
  }
  
  /**
   * @param {number} balance
   * @return {ColorScheme}
   * @public
   */
  static m_getBalanceColor__double(balance) {
    ContactUiUtils.$clinit();
    if (balance > 3000) {
      return ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme;
    } else if (balance > 2000) {
      return ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme;
    } else if (balance > 1000) {
      return ColorScheme.f_ORANGE__org_dominokit_domino_ui_style_ColorScheme;
    } else {
      return ColorScheme.f_RED__org_dominokit_domino_ui_style_ColorScheme;
    }
  }
  
  /**
   * @param {Contact} contact
   * @return {ColorScheme}
   * @public
   */
  static m_getBalanceColor__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    return ContactUiUtils.m_getBalanceColor__double(contact.m_getDoubleBalance__());
  }
  
  /**
   * @param {Contact} contact
   * @return {HTMLElement}
   * @public
   */
  static m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(Gender.f_male__org_dominokit_domino_datatable_client_views_model_Gender, contact.m_getGender__())) {
      return /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas fa-male fa-lg"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    } else {
      return /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas fa-female fa-lg"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    }
  }
  
  /**
   * @param {Contact} contact
   * @return {HTMLElement}
   * @public
   */
  static m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    let element = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas fa-eye fa-lg"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(EyeColor.f_blue__org_dominokit_domino_datatable_client_views_model_EyeColor, contact.m_getEyeColor__())) {
      return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element)).m_setColor__java_lang_String(Color.f_BLUE__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
    } else if ($Objects.m_equals__java_lang_Object__java_lang_Object(EyeColor.f_green__org_dominokit_domino_datatable_client_views_model_EyeColor, contact.m_getEyeColor__())) {
      return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element)).m_setColor__java_lang_String(Color.f_GREEN__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
    } else if ($Objects.m_equals__java_lang_Object__java_lang_Object(EyeColor.f_brown__org_dominokit_domino_datatable_client_views_model_EyeColor, contact.m_getEyeColor__())) {
      return /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element)).m_setColor__java_lang_String(Color.f_BROWN__org_dominokit_domino_ui_style_Color.m_getHex__()).m_asElement__();
    }
    return element;
  }
  
  /**
   * @param {Contact} contact
   * @return {Color}
   * @public
   */
  static m_getColor__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(EyeColor.f_brown__org_dominokit_domino_datatable_client_views_model_EyeColor, contact.m_getEyeColor__())) {
      return Color.f_BROWN__org_dominokit_domino_ui_style_Color;
    }
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(EyeColor.f_blue__org_dominokit_domino_datatable_client_views_model_EyeColor, contact.m_getEyeColor__())) {
      return Color.f_BLUE__org_dominokit_domino_ui_style_Color;
    }
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(EyeColor.f_green__org_dominokit_domino_datatable_client_views_model_EyeColor, contact.m_getEyeColor__())) {
      return Color.f_GREEN__org_dominokit_domino_ui_style_Color;
    }
    return Color.f_BROWN__org_dominokit_domino_ui_style_Color;
  }
  
  /**
   * @param {Contact} contact
   * @return {?string}
   * @public
   */
  static m_getAvatarIndex__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    return $Primitives.$coerceDivision(contact.m_getIndex__() % 99) + "";
  }
  
  /**
   * @param {Contact} contact
   * @return {?string}
   * @public
   */
  static m_getGenderIconName__org_dominokit_domino_datatable_client_views_model_Contact(contact) {
    ContactUiUtils.$clinit();
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(Gender.f_male__org_dominokit_domino_datatable_client_views_model_Gender, contact.m_getGender__())) {
      return "men";
    }
    return "women";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactUiUtils;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactUiUtils);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactUiUtils.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    EyeColor = goog.module.get('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
    Gender = goog.module.get('org.dominokit.domino.datatable.client.views.model.Gender$impl');
    Tooltip = goog.module.get('org.dominokit.domino.ui.popover.Tooltip$impl');
    Progress = goog.module.get('org.dominokit.domino.ui.progress.Progress$impl');
    ProgressBar = goog.module.get('org.dominokit.domino.ui.progress.ProgressBar$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactUiUtils, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils'));




exports = ContactUiUtils; 
//# sourceMappingURL=ContactUiUtils.js.map