/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.DatatableClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.DatatableClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class DatatableClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatatableClientModule()'.
   * @return {!DatatableClientModule}
   * @public
   */
  static $create__() {
    DatatableClientModule.$clinit();
    let $instance = new DatatableClientModule();
    $instance.$ctor__org_dominokit_domino_datatable_client_DatatableClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatatableClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_DatatableClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    DatatableClientModule.$f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_.m_info__java_lang_String("Initializing Datatable frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_() {
    return (DatatableClientModule.$clinit(), DatatableClientModule.$f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_(value) {
    (DatatableClientModule.$clinit(), DatatableClientModule.$f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatatableClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatatableClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatatableClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    DatatableClientModule.$f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(DatatableClientModule));
  }
  
  
};

$Util.$setClassMetadata(DatatableClientModule, $Util.$makeClassName('org.dominokit.domino.datatable.client.DatatableClientModule'));


/** @private {Logger} */
DatatableClientModule.$f_LOGGER__org_dominokit_domino_datatable_client_DatatableClientModule_;




exports = DatatableClientModule; 
//# sourceMappingURL=DatatableClientModule.js.map