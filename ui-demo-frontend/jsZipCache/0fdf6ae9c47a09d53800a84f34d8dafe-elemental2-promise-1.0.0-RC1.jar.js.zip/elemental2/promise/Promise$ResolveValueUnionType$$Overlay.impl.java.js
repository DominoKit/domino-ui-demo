/**
 * @fileoverview transpiled from elemental2.promise.Promise$ResolveValueUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.promise.Promise.ResolveValueUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.promise.IThenable.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ResolveValueUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ResolveValueUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ResolveValueUnionType_$Overlay));
  }
  
  /**
   * @template C_ResolveValueUnionType_V
   * @param {?} $thisArg
   * @return {IThenable<C_ResolveValueUnionType_V>}
   * @public
   */
  static m_asIThenable__elemental2_promise_Promise_ResolveValueUnionType($thisArg) {
    ResolveValueUnionType_$Overlay.$clinit();
    return /**@type {IThenable<*>} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @template C_ResolveValueUnionType_V
   * @param {?} $thisArg
   * @return {C_ResolveValueUnionType_V}
   * @public
   */
  static m_asV__elemental2_promise_Promise_ResolveValueUnionType($thisArg) {
    ResolveValueUnionType_$Overlay.$clinit();
    return Js.m_cast__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ResolveValueUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.promise.IThenable.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ResolveValueUnionType_$Overlay, $Util.$makeClassName('?'));


exports = ResolveValueUnionType_$Overlay; 
//# sourceMappingURL=Promise$ResolveValueUnionType$$Overlay.js.map