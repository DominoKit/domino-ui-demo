/**
 * @fileoverview transpiled from elemental2.promise.IThenable$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.promise.IThenable.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface($Overlay, $Util.$makeClassName('IThenable'));


exports = $Overlay; 
//# sourceMappingURL=IThenable$$Overlay.js.map