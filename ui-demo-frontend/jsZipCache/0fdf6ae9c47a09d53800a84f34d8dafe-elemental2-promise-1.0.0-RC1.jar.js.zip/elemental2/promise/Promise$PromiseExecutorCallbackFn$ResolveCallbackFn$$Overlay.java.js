/**
 * @fileoverview transpiled from elemental2.promise.Promise$PromiseExecutorCallbackFn$ResolveCallbackFn$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.promise.Promise.PromiseExecutorCallbackFn.ResolveCallbackFn.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IThenable_$Overlay = goog.require('elemental2.promise.IThenable.$Overlay');
const _$Overlay = goog.require('elemental2.promise.Promise.PromiseExecutorCallbackFn.ResolveCallbackFn.ResolveUnionType.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var ResolveCallbackFn_$Overlay = goog.require('elemental2.promise.Promise.PromiseExecutorCallbackFn.ResolveCallbackFn.$Overlay$impl');
exports = ResolveCallbackFn_$Overlay;
 