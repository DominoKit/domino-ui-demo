/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.shared.impl.cldr.DateTimeFormatInfoImpl$impl');


class org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl extends DateTimeFormatInfoImpl {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl()'.
   * @return {!org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl}
   * @public
   */
  static $create__() {
    org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl.$clinit();
    let $instance = new org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__() {
    this.$ctor__org_gwtproject_i18n_shared_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl.$clinit = function() {};
    DateTimeFormatInfoImpl.$clinit();
  }
  
  
};

$Util.$setClassMetadata(org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl'));




exports = org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl; 
//# sourceMappingURL=DateTimeFormatInfoImpl.js.map