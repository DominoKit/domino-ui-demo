/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da_GL.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da_GL$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__da = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da$impl');


class DateTimeFormatInfoImpl__da__GL extends DateTimeFormatInfoImpl__da {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_da_GL()'.
   * @return {!DateTimeFormatInfoImpl__da__GL}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__da__GL.$clinit();
    let $instance = new DateTimeFormatInfoImpl__da__GL();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_da_GL__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_da_GL()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_da_GL__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_da__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__da__GL;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__da__GL);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__da__GL.$clinit = function() {};
    DateTimeFormatInfoImpl__da.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__da__GL, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da_GL'));




exports = DateTimeFormatInfoImpl__da__GL; 
//# sourceMappingURL=DateTimeFormatInfoImpl_da_GL.js.map