/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da_GL.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da_GL');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__da = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__da__GL = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_da_GL$impl');
exports = DateTimeFormatInfoImpl__da__GL;
 