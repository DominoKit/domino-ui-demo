/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_AI.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_AI$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__en__001 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_001$impl');


class DateTimeFormatInfoImpl__en__AI extends DateTimeFormatInfoImpl__en__001 {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_en_AI()'.
   * @return {!DateTimeFormatInfoImpl__en__AI}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__en__AI.$clinit();
    let $instance = new DateTimeFormatInfoImpl__en__AI();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_AI__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_en_AI()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_AI__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_001__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatFull__() {
    return "HH:mm:ss zzzz";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatLong__() {
    return "HH:mm:ss z";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatMedium__() {
    return "HH:mm:ss";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatShort__() {
    return "HH:mm";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__en__AI;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__en__AI);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__en__AI.$clinit = function() {};
    DateTimeFormatInfoImpl__en__001.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__en__AI, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_AI'));




exports = DateTimeFormatInfoImpl__en__AI; 
//# sourceMappingURL=DateTimeFormatInfoImpl_en_AI.js.map