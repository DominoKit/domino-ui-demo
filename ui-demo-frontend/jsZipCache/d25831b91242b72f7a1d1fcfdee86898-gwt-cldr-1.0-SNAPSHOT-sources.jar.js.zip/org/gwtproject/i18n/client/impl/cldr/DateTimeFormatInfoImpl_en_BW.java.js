/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_BW.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_BW');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__en__001 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_001');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__en__BW = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_BW$impl');
exports = DateTimeFormatInfoImpl__en__BW;
 