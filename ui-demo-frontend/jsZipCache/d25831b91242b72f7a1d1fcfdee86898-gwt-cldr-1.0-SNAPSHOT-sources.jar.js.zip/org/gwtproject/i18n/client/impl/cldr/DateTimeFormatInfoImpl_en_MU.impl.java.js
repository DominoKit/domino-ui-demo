/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_MU.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_MU$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__en__001 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_001$impl');


class DateTimeFormatInfoImpl__en__MU extends DateTimeFormatInfoImpl__en__001 {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_en_MU()'.
   * @return {!DateTimeFormatInfoImpl__en__MU}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__en__MU.$clinit();
    let $instance = new DateTimeFormatInfoImpl__en__MU();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_MU__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_en_MU()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_MU__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_001__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatFull__() {
    return "HH:mm:ss zzzz";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatLong__() {
    return "HH:mm:ss z";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatMedium__() {
    return "HH:mm:ss";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatShort__() {
    return "HH:mm";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__en__MU;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__en__MU);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__en__MU.$clinit = function() {};
    DateTimeFormatInfoImpl__en__001.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__en__MU, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_MU'));




exports = DateTimeFormatInfoImpl__en__MU; 
//# sourceMappingURL=DateTimeFormatInfoImpl_en_MU.js.map