/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_az.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_az$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


class DateTimeFormatInfoImpl__az extends DateTimeFormatInfoImpl {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_az()'.
   * @return {!DateTimeFormatInfoImpl__az}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__az.$clinit();
    let $instance = new DateTimeFormatInfoImpl__az();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_az__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_az()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_az__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatFull__() {
    return "d MMMM y, EEEE";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatLong__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatMedium__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatShort__() {
    return "dd.MM.yy";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["eram\u0131zdan \u0259vv\u0259l", "yeni era"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["e.\u0259.", "y.e."], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthAbbrevDay__() {
    return "d MMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullDay__() {
    return "d MMMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullWeekdayDay__() {
    return "d MMMM, EEEE";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthNumDay__() {
    return "dd.MM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrev__() {
    return "MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrevDay__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFull__() {
    return "MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFullDay__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNum__() {
    return "MM.y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNumDay__() {
    return "dd.MM.y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthWeekdayDay__() {
    return "d MMM y, EEE";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr", "oktyabr", "noyabr", "dekabr"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsFullStandalone__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Yanvar", "Fevral", "Mart", "Aprel", "May", "\u0130yun", "\u0130yul", "Avqust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["yan", "fev", "mar", "apr", "may", "iyn", "iyl", "avq", "sen", "okt", "noy", "dek"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["1-ci kvartal", "2-ci kvartal", "3-c\u00FC kvartal", "4-c\u00FC kvartal"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["1-ci kv.", "2-ci kv.", "3-c\u00FC kv.", "4-c\u00FC kv."], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["bazar", "bazar ert\u0259si", "\u00E7\u0259r\u015F\u0259nb\u0259 ax\u015Fam\u0131", "\u00E7\u0259r\u015F\u0259nb\u0259", "c\u00FCm\u0259 ax\u015Fam\u0131", "c\u00FCm\u0259", "\u015F\u0259nb\u0259"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["7", "1", "2", "3", "4", "5", "6"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["B.", "B.E.", "\u00C7.A.", "\u00C7.", "C.A.", "C.", "\u015E."], j_l_String));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__az;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__az);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__az.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    DateTimeFormatInfoImpl.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__az, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_az'));




exports = DateTimeFormatInfoImpl__az; 
//# sourceMappingURL=DateTimeFormatInfoImpl_az.js.map