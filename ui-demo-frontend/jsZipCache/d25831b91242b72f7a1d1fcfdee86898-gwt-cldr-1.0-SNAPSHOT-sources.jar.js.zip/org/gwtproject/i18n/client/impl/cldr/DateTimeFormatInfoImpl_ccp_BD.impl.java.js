/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp_BD.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp_BD$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__ccp = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp$impl');


class DateTimeFormatInfoImpl__ccp__BD extends DateTimeFormatInfoImpl__ccp {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_ccp_BD()'.
   * @return {!DateTimeFormatInfoImpl__ccp__BD}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__ccp__BD.$clinit();
    let $instance = new DateTimeFormatInfoImpl__ccp__BD();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ccp_BD__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_ccp_BD()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ccp_BD__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ccp__();
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_weekendStart__() {
    return 6;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__ccp__BD;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__ccp__BD);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__ccp__BD.$clinit = function() {};
    DateTimeFormatInfoImpl__ccp.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__ccp__BD, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp_BD'));




exports = DateTimeFormatInfoImpl__ccp__BD; 
//# sourceMappingURL=DateTimeFormatInfoImpl_ccp_BD.js.map