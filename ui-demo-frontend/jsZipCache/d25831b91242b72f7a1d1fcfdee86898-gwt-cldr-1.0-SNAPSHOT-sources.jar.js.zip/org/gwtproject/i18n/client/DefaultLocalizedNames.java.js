/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.DefaultLocalizedNames.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.DefaultLocalizedNames');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DefaultLocalizedNamesBase = goog.require('org.gwtproject.i18n.client.DefaultLocalizedNamesBase');
const _j_l_String = goog.require('java.lang.String');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var DefaultLocalizedNames = goog.require('org.gwtproject.i18n.client.DefaultLocalizedNames$impl');
exports = DefaultLocalizedNames;
 