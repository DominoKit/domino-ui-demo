/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlUtils$JvmImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlUtils.JvmImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsImpl = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils.JsImpl$impl');


class JvmImpl extends JsImpl {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'JvmImpl()'.
   * @return {!JvmImpl}
   * @public
   */
  static $create__() {
    JvmImpl.$clinit();
    let $instance = new JvmImpl();
    $instance.$ctor__org_gwtproject_safehtml_shared_SafeHtmlUtils_JvmImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JvmImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_safehtml_shared_SafeHtmlUtils_JvmImpl__() {
    this.$ctor__org_gwtproject_safehtml_shared_SafeHtmlUtils_JsImpl__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JvmImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JvmImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JvmImpl.$clinit = function() {};
    JsImpl.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JvmImpl, $Util.$makeClassName('org.gwtproject.safehtml.shared.SafeHtmlUtils$JvmImpl'));




exports = JvmImpl; 
//# sourceMappingURL=SafeHtmlUtils$JvmImpl.js.map