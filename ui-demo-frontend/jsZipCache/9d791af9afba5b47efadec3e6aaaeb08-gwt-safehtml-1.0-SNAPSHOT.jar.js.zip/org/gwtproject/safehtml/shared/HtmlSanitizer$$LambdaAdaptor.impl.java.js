/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.HtmlSanitizer$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.safehtml.shared.HtmlSanitizer.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HtmlSanitizer = goog.require('org.gwtproject.safehtml.shared.HtmlSanitizer$impl');

let SafeHtml = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtml$impl');


/**
 * @implements {HtmlSanitizer}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string):SafeHtml} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string):SafeHtml} */
    this.f_$$fn__org_gwtproject_safehtml_shared_HtmlSanitizer_$LambdaAdaptor;
    this.$ctor__org_gwtproject_safehtml_shared_HtmlSanitizer_$LambdaAdaptor__org_gwtproject_safehtml_shared_HtmlSanitizer_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string):SafeHtml} fn
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_safehtml_shared_HtmlSanitizer_$LambdaAdaptor__org_gwtproject_safehtml_shared_HtmlSanitizer_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_gwtproject_safehtml_shared_HtmlSanitizer_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @return {SafeHtml}
   * @public
   */
  m_sanitize__java_lang_String(arg0) {
    let /** ?function(?string):SafeHtml */ $function;
    return ($function = this.f_$$fn__org_gwtproject_safehtml_shared_HtmlSanitizer_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.gwtproject.safehtml.shared.HtmlSanitizer$$LambdaAdaptor'));


HtmlSanitizer.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=HtmlSanitizer$$LambdaAdaptor.js.map