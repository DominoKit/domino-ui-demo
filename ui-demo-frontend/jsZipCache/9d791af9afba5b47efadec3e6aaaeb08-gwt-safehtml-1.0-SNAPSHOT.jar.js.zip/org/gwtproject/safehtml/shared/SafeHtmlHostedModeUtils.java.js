/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JreImpl = goog.require('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils.JreImpl');


// Re-exports the implementation.
var SafeHtmlHostedModeUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils$impl');
exports = SafeHtmlHostedModeUtils;
 