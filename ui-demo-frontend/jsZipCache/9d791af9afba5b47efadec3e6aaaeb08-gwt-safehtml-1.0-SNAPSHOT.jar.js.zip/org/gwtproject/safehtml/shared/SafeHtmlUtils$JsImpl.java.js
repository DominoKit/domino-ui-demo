/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlUtils$JsImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlUtils.JsImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsRegExp_$Overlay = goog.require('elemental2.core.JsRegExp.$Overlay');
const _$Overlay = goog.require('elemental2.core.JsString.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _SafeHtmlUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils');


// Re-exports the implementation.
var JsImpl = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils.JsImpl$impl');
exports = JsImpl;
 