/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _$Long = goog.require('nativebootstrap.Long');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');
const _SafeHtmlHostedModeUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils');
const _SafeHtmlString = goog.require('org.gwtproject.safehtml.shared.SafeHtmlString');
const _SafeHtmlUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils');


// Re-exports the implementation.
var SafeHtmlBuilder = goog.require('org.gwtproject.safehtml.shared.SafeHtmlBuilder$impl');
exports = SafeHtmlBuilder;
 