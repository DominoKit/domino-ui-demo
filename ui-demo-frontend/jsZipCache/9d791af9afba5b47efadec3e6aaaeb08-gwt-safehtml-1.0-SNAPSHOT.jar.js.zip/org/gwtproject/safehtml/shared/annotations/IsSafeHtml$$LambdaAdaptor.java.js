/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.annotations.IsSafeHtml$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.annotations.IsSafeHtml.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsSafeHtml = goog.require('org.gwtproject.safehtml.shared.annotations.IsSafeHtml');
const _Class = goog.require('java.lang.Class');
const _Annotation = goog.require('java.lang.annotation.Annotation');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.annotations.IsSafeHtml.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 