/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.annotations.IsSafeUri.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.annotations.IsSafeUri');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.annotations.IsSafeUri.$LambdaAdaptor');


// Re-exports the implementation.
var IsSafeUri = goog.require('org.gwtproject.safehtml.shared.annotations.IsSafeUri$impl');
exports = IsSafeUri;
 