/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlUtils.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlUtils');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');
const _SafeHtmlHostedModeUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils');
const _SafeHtmlString = goog.require('org.gwtproject.safehtml.shared.SafeHtmlString');
const _JvmImpl = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils.JvmImpl');


// Re-exports the implementation.
var SafeHtmlUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils$impl');
exports = SafeHtmlUtils;
 