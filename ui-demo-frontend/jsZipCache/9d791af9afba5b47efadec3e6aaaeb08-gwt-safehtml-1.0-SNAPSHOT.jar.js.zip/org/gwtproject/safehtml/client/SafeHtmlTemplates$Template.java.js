/**
 * @fileoverview transpiled from org.gwtproject.safehtml.client.SafeHtmlTemplates$Template.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.client.SafeHtmlTemplates.Template');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var Template = goog.require('org.gwtproject.safehtml.client.SafeHtmlTemplates.Template$impl');
exports = Template;
 