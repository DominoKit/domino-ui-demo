/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutEvent = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
let MenuPresenter = goog.forwardDeclare('org.dominokit.domino.menu.client.presenters.MenuPresenter$impl');
let MenuPresenterCommand = goog.forwardDeclare('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<LayoutEvent>}
  */
class MenuPresenterListenerForLayoutEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MenuPresenterListenerForLayoutEvent()'.
   * @return {!MenuPresenterListenerForLayoutEvent}
   * @public
   */
  static $create__() {
    MenuPresenterListenerForLayoutEvent.$clinit();
    let $instance = new MenuPresenterListenerForLayoutEvent();
    $instance.$ctor__org_dominokit_domino_menu_client_listeners_MenuPresenterListenerForLayoutEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuPresenterListenerForLayoutEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_listeners_MenuPresenterListenerForLayoutEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(event) {
    MenuPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** MenuPresenter */ presenter) =>{
      presenter.m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(event.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(/**@type {LayoutEvent} */ ($Casts.$to(arg0, LayoutEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuPresenterListenerForLayoutEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuPresenterListenerForLayoutEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuPresenterListenerForLayoutEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutEvent = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
    MenuPresenterCommand = goog.module.get('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuPresenterListenerForLayoutEvent, $Util.$makeClassName('org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent'));


DominoEventListener.$markImplementor(MenuPresenterListenerForLayoutEvent);


exports = MenuPresenterListenerForLayoutEvent; 
//# sourceMappingURL=MenuPresenterListenerForLayoutEvent.js.map