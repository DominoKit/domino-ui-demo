/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.ui.MenuViewImpl$SubMenu.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let MenuViewImpl = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu.$LambdaAdaptor$3$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let TreeItem = goog.forwardDeclare('org.dominokit.domino.ui.tree.TreeItem$impl');


/**
 * @implements {CanAddMenuItem}
  */
class SubMenu extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {MenuViewImpl} */
    this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu;
    /** @public {TreeItem} */
    this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_;
  }
  
  /**
   * Factory method corresponding to constructor 'SubMenu(MenuViewImpl, TreeItem)'.
   * @param {MenuViewImpl} $outer_this
   * @param {TreeItem} menuItem
   * @return {!SubMenu}
   * @public
   */
  static $create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem($outer_this, menuItem) {
    SubMenu.$clinit();
    let $instance = new SubMenu();
    $instance.$ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem($outer_this, menuItem);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SubMenu(MenuViewImpl, TreeItem)'.
   * @param {MenuViewImpl} $outer_this
   * @param {TreeItem} menuItem
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem($outer_this, menuItem) {
    this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_ = menuItem;
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String(title) {
    return this.m_addMenuItem__java_lang_String__java_lang_String(title, "");
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String(title, iconName) {
    let item = TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(title, Icon.m_create__java_lang_String(iconName)).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_right__());
    this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_.m_appendChild__org_dominokit_domino_ui_tree_TreeItem(item);
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem(this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu, item);
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, selectionHandler) {
    return this.m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, "", selectionHandler);
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler) {
    let item = TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(title, Icon.m_create__java_lang_String(iconName)).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_right__());
    this.f_menuItem__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu_.m_appendChild__org_dominokit_domino_ui_tree_TreeItem(item);
    item.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ e) =>{
      selectionHandler.m_onMenuSelected__();
    })));
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem(this.f_$outer_this__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_SubMenu, item);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SubMenu;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SubMenu);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SubMenu.$clinit = function() {};
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu.$LambdaAdaptor$3$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    TreeItem = goog.module.get('org.dominokit.domino.ui.tree.TreeItem$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SubMenu, $Util.$makeClassName('org.dominokit.domino.menu.client.views.ui.MenuViewImpl$SubMenu'));


CanAddMenuItem.$markImplementor(SubMenu);


exports = SubMenu; 
//# sourceMappingURL=MenuViewImpl$SubMenu.js.map