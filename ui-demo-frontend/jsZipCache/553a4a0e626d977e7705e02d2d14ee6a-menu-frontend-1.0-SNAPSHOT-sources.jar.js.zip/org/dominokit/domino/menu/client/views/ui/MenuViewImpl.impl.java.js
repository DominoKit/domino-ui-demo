/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.ui.MenuViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.views.ui.MenuViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MenuView = goog.require('org.dominokit.domino.menu.client.views.MenuView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$2$impl');
let SubMenu = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');
let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
let Collapsible = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let MediaQuery = goog.forwardDeclare('org.dominokit.domino.ui.mediaquery.MediaQuery$impl');
let MediaQueryListener = goog.forwardDeclare('org.dominokit.domino.ui.mediaquery.MediaQuery.MediaQueryListener$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Calc = goog.forwardDeclare('org.dominokit.domino.ui.style.Calc$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Unit = goog.forwardDeclare('org.dominokit.domino.ui.style.Unit$impl');
let Tree = goog.forwardDeclare('org.dominokit.domino.ui.tree.Tree$impl');
let TreeItem = goog.forwardDeclare('org.dominokit.domino.ui.tree.TreeItem$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {MenuView}
  */
class MenuViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Tree} */
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_;
    /** @public {Icon} */
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_;
    /** @public {boolean} */
    this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
    /** @public {Collapsible} */
    this.f_lockCollapsible__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'MenuViewImpl()'.
   * @return {!MenuViewImpl}
   * @public
   */
  static $create__() {
    MenuViewImpl.$clinit();
    let $instance = new MenuViewImpl();
    $instance.$ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_menu_client_views_ui_MenuViewImpl();
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {void}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_getTitle__().m_setTextContent__java_lang_String(title);
  }
  
  /**
   * @override
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = Tree.m_create__java_lang_String("Demo menu");
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_getHeader__().m_appendChild__elemental2_dom_Node(this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__());
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_enableSearch__().m_autoExpandFound__().m_style__().m_setHeight__java_lang_String(Calc.m_sub__java_lang_String__java_lang_String(Unit.f_vh__org_dominokit_domino_ui_style_Unit.m_of__java_lang_Number(Integer.m_valueOf__int(100)), Unit.f_px__org_dominokit_domino_ui_style_Unit.m_of__java_lang_Number(Integer.m_valueOf__int(267)))).m_get__();
    let leftPanel = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(layout.m_getLeftPanel__().m_get__()), $Overlay));
    leftPanel.appendChild(this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__());
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      if (this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_) {
        layout.m_unfixLeftPanelPosition__();
        this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock__().m_getName__();
        layout.m_hideLeftPanel__();
        this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
      } else {
        layout.m_fixLeftPanelPosition__();
        this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock_open__().m_getName__();
        this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = true;
      }
    })));
    MediaQuery.m_addOnXLargeListener__org_dominokit_domino_ui_mediaquery_MediaQuery_MediaQueryListener(MediaQueryListener.$adapt((() =>{
      this.m_fixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout);
      Notification.m_create__java_lang_String("Switched to XLarge screen").m_show__();
    })));
    MediaQuery.m_addOnLargeListener__org_dominokit_domino_ui_mediaquery_MediaQuery_MediaQueryListener(MediaQueryListener.$adapt((() =>{
      this.m_fixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout);
      Notification.m_create__java_lang_String("Switched to Large screen").m_show__();
    })));
    MediaQuery.m_addOnMediumListener__org_dominokit_domino_ui_mediaquery_MediaQuery_MediaQueryListener(MediaQueryListener.$adapt((() =>{
      this.m_unfixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout);
      Notification.m_create__java_lang_String("Switched to Medium screen").m_show__();
    })));
    MediaQuery.m_addOnSmallListener__org_dominokit_domino_ui_mediaquery_MediaQuery_MediaQueryListener(MediaQueryListener.$adapt((() =>{
      this.m_unfixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout);
      Notification.m_create__java_lang_String("Switched to Small screen").m_show__();
    })));
    MediaQuery.m_addOnXSmallListener__org_dominokit_domino_ui_mediaquery_MediaQuery_MediaQueryListener(MediaQueryListener.$adapt((() =>{
      this.m_unfixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout);
      Notification.m_create__java_lang_String("Switched to XSmall screen").m_show__();
    })));
  }
  
  /**
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_fixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout) {
    layout.m_fixLeftPanelPosition__();
    this.f_lockCollapsible__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_expand__();
    this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = true;
  }
  
  /**
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_unfixLeftPanel__org_dominokit_domino_layout_shared_extension_IsLayout_$p_org_dominokit_domino_menu_client_views_ui_MenuViewImpl(layout) {
    layout.m_unfixLeftPanelPosition__();
    layout.m_hideLeftPanel__();
    this.f_lockCollapsible__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_collapse__();
    this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler) {
    let menuItem = TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(title, Icon.m_create__java_lang_String(iconName));
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_appendChild__org_dominokit_domino_ui_tree_TreeItem(menuItem);
    menuItem.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ e) =>{
      selectionHandler.m_onMenuSelected__();
    })));
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem(this, menuItem);
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String(title, iconName) {
    let menuItem = TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(title, Icon.m_create__java_lang_String(iconName));
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_appendChild__org_dominokit_domino_ui_tree_TreeItem(menuItem);
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_tree_TreeItem(this, menuItem);
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    return Content.$adapt((() =>{
      return this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__();
    }));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_menu_client_views_ui_MenuViewImpl() {
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock_open__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color), Icon)).m_style__().m_setMarginBottom__java_lang_String("0px").m_setMarginTop__java_lang_String("0px").m_setCursor__java_lang_String("pointer").m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_get__(), Icon));
    this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
    this.f_lockCollapsible__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = Collapsible.m_create__org_jboss_gwt_elemento_core_IsElement(this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_).m_expand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    Content = goog.module.get('org.dominokit.domino.api.shared.extension.Content$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$2$impl');
    SubMenu = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');
    Collapsible = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    MediaQuery = goog.module.get('org.dominokit.domino.ui.mediaquery.MediaQuery$impl');
    MediaQueryListener = goog.module.get('org.dominokit.domino.ui.mediaquery.MediaQuery.MediaQueryListener$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Calc = goog.module.get('org.dominokit.domino.ui.style.Calc$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Unit = goog.module.get('org.dominokit.domino.ui.style.Unit$impl');
    Tree = goog.module.get('org.dominokit.domino.ui.tree.Tree$impl');
    TreeItem = goog.module.get('org.dominokit.domino.ui.tree.TreeItem$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuViewImpl, $Util.$makeClassName('org.dominokit.domino.menu.client.views.ui.MenuViewImpl'));


MenuView.$markImplementor(MenuViewImpl);


exports = MenuViewImpl; 
//# sourceMappingURL=MenuViewImpl.js.map