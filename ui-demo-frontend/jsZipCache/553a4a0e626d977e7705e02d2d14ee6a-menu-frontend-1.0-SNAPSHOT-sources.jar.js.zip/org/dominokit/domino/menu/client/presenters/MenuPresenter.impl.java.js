/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.presenters.MenuPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.presenters.MenuPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');
const MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let MenuView = goog.forwardDeclare('org.dominokit.domino.menu.client.views.MenuView$impl');
let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
let MenuEvent = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuEvent$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ViewBaseClientPresenter<MenuView>}
 * @implements {MenuContext}
  */
class MenuPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MenuPresenter()'.
   * @return {!MenuPresenter}
   * @public
   */
  static $create__() {
    MenuPresenter.$clinit();
    let $instance = new MenuPresenter();
    $instance.$ctor__org_dominokit_domino_menu_client_presenters_MenuPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_presenters_MenuPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {LayoutContext} context
   * @return {void}
   * @public
   */
  m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(context) {
    /**@type {MenuView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, MenuView)).m_init__org_dominokit_domino_layout_shared_extension_IsLayout(context.m_getLayout__());
    this.m_fireEvent__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEvent(Class.$get(MenuEvent), MenuEvent.$adapt((() =>{
      return this;
    })));
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler) {
    return /**@type {MenuView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, MenuView)).m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler);
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String(title, iconName) {
    return /**@type {MenuView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, MenuView)).m_addMenuItem__java_lang_String__java_lang_String(title, iconName);
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {void}
   * @public
   */
  m_setMainTitle__java_lang_String(title) {
    /**@type {MenuView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, MenuView)).m_setTitle__java_lang_String(title);
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_menu_client_presenters_MenuPresenter_() {
    return (MenuPresenter.$clinit(), MenuPresenter.$f_LOGGER__org_dominokit_domino_menu_client_presenters_MenuPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_menu_client_presenters_MenuPresenter_(value) {
    (MenuPresenter.$clinit(), MenuPresenter.$f_LOGGER__org_dominokit_domino_menu_client_presenters_MenuPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    MenuView = goog.module.get('org.dominokit.domino.menu.client.views.MenuView$impl');
    MenuEvent = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuEvent$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ViewBaseClientPresenter.$clinit();
    MenuPresenter.$f_LOGGER__org_dominokit_domino_menu_client_presenters_MenuPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(MenuPresenter));
  }
  
  
};

$Util.$setClassMetadata(MenuPresenter, $Util.$makeClassName('org.dominokit.domino.menu.client.presenters.MenuPresenter'));


/** @private {Logger} */
MenuPresenter.$f_LOGGER__org_dominokit_domino_menu_client_presenters_MenuPresenter_;


MenuContext.$markImplementor(MenuPresenter);


exports = MenuPresenter; 
//# sourceMappingURL=MenuPresenter.js.map