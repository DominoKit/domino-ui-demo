/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.presenters.MenuPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let MenuPresenter = goog.forwardDeclare('org.dominokit.domino.menu.client.presenters.MenuPresenter$impl');


/**
 * @extends {PresenterCommand<MenuPresenter>}
  */
class MenuPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MenuPresenterCommand()'.
   * @return {!MenuPresenterCommand}
   * @public
   */
  static $create__() {
    MenuPresenterCommand.$clinit();
    let $instance = new MenuPresenterCommand();
    $instance.$ctor__org_dominokit_domino_menu_client_presenters_MenuPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_presenters_MenuPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuPresenterCommand, $Util.$makeClassName('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand'));




exports = MenuPresenterCommand; 
//# sourceMappingURL=MenuPresenterCommand.js.map