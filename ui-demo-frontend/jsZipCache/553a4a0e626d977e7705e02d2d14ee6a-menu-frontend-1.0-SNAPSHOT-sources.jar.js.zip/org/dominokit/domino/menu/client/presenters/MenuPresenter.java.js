/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.presenters.MenuPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.client.presenters.MenuPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _Class = goog.require('java.lang.Class');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _MenuView = goog.require('org.dominokit.domino.menu.client.views.MenuView');
const _CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem');
const _OnMenuSelectedHandler = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler');
const _MenuEvent = goog.require('org.dominokit.domino.menu.shared.extension.MenuEvent');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MenuPresenter = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenter$impl');
exports = MenuPresenter;
 