/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _LayoutEvent = goog.require('org.dominokit.domino.layout.shared.extension.LayoutEvent');
const _MenuPresenter = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenter');
const _MenuPresenterCommand = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MenuPresenterListenerForLayoutEvent = goog.require('org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent$impl');
exports = MenuPresenterListenerForLayoutEvent;
 