package org.dominokit.domino.menu.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.layout.shared.extension.LayoutEvent;
import org.dominokit.domino.menu.client.listeners.MenuPresenterListenerForLayoutEvent;
import org.dominokit.domino.menu.client.presenters.MenuPresenter;
import org.dominokit.domino.menu.client.presenters.MenuPresenterCommand;
import org.dominokit.domino.menu.client.views.ui.MenuViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class MenuModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(MenuPresenter.class.getCanonicalName(), MenuPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new MenuPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(MenuPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new MenuViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(MenuPresenterCommand.class.getCanonicalName(), MenuPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(LayoutEvent.class, new MenuPresenterListenerForLayoutEvent());
  }
}
