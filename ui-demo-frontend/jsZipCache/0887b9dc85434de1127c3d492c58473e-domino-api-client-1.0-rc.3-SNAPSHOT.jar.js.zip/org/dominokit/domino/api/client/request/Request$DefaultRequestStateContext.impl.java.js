/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$DefaultRequestStateContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext$impl');


/**
 * @implements {RequestStateContext}
  */
class DefaultRequestStateContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultRequestStateContext()'.
   * @return {!DefaultRequestStateContext}
   * @public
   */
  static $create__() {
    DefaultRequestStateContext.$clinit();
    let $instance = new DefaultRequestStateContext();
    $instance.$ctor__org_dominokit_domino_api_client_request_Request_DefaultRequestStateContext__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultRequestStateContext()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Request_DefaultRequestStateContext__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultRequestStateContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultRequestStateContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultRequestStateContext.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DefaultRequestStateContext, $Util.$makeClassName('org.dominokit.domino.api.client.request.Request$DefaultRequestStateContext'));


RequestStateContext.$markImplementor(DefaultRequestStateContext);


exports = DefaultRequestStateContext; 
//# sourceMappingURL=Request$DefaultRequestStateContext.js.map