/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasAsyncRunner.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner.$LambdaAdaptor$impl');
let HasOptions = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasOptions$impl');
let MainExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');


/**
 * @interface
 */
class HasAsyncRunner {
  /**
   * @abstract
   * @param {MainExtensionPoint} mainExtensionPoint
   * @return {HasOptions}
   * @public
   */
  m_mainExtensionPoint__org_dominokit_domino_api_shared_extension_MainExtensionPoint(mainExtensionPoint) {
  }
  
  /**
   * @param {?function(MainExtensionPoint):HasOptions} fn
   * @return {HasAsyncRunner}
   * @public
   */
  static $adapt(fn) {
    HasAsyncRunner.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasAsyncRunner.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasAsyncRunner, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasAsyncRunner'));


HasAsyncRunner.$markImplementor(/** @type {Function} */ (HasAsyncRunner));


exports = HasAsyncRunner; 
//# sourceMappingURL=ClientApp$HasAsyncRunner.js.map