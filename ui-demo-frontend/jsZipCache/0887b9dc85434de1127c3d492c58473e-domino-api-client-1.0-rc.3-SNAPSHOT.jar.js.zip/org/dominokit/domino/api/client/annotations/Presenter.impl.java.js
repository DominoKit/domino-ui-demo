/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.Presenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.Presenter$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class Presenter {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_hasCommand__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_Presenter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_Presenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_Presenter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Presenter.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Presenter, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.Presenter'));


Presenter.$markImplementor(/** @type {Function} */ (Presenter));


exports = Presenter; 
//# sourceMappingURL=Presenter.js.map