/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.CanSetDominoOptions.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.CanSetDominoOptions');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DynamicServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot');


// Re-exports the implementation.
var CanSetDominoOptions = goog.require('org.dominokit.domino.api.client.CanSetDominoOptions$impl');
exports = CanSetDominoOptions;
 