/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasRequestRestSendersRepository$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasRequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository$impl');

let HasHistory = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasHistory$impl');
let AppHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.AppHistory$impl');


/**
 * @implements {HasRequestRestSendersRepository}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(AppHistory):HasHistory} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(AppHistory):HasHistory} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(AppHistory):HasHistory} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {AppHistory} arg0
   * @return {HasHistory}
   * @public
   */
  m_history__org_dominokit_domino_api_shared_history_AppHistory(arg0) {
    let /** ?function(AppHistory):HasHistory */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasRequestRestSendersRepository$$LambdaAdaptor'));


HasRequestRestSendersRepository.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasRequestRestSendersRepository$$LambdaAdaptor.js.map