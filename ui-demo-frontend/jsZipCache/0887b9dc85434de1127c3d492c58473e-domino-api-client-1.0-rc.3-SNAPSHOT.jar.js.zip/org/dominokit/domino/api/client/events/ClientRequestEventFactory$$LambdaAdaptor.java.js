/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.ClientRequestEventFactory$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.events.ClientRequestEventFactory.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ClientRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 