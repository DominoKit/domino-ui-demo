/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSendersRepository$SenderNotFoundException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderNotFoundException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class SenderNotFoundException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SenderNotFoundException(String)'.
   * @param {?string} requestName
   * @return {!SenderNotFoundException}
   * @public
   */
  static $create__java_lang_String(requestName) {
    SenderNotFoundException.$clinit();
    let $instance = new SenderNotFoundException();
    $instance.$ctor__org_dominokit_domino_api_client_request_RequestRestSendersRepository_SenderNotFoundException__java_lang_String(requestName);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SenderNotFoundException(String)'.
   * @param {?string} requestName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_RequestRestSendersRepository_SenderNotFoundException__java_lang_String(requestName) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(requestName);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SenderNotFoundException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SenderNotFoundException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SenderNotFoundException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SenderNotFoundException, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestRestSendersRepository$SenderNotFoundException'));




exports = SenderNotFoundException; 
//# sourceMappingURL=RequestRestSendersRepository$SenderNotFoundException.js.map