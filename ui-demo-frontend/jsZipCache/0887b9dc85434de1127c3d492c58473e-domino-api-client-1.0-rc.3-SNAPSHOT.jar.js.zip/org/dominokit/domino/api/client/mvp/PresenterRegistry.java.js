/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.PresenterRegistry.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.PresenterRegistry');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry.$LambdaAdaptor');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');


// Re-exports the implementation.
var PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
exports = PresenterRegistry;
 