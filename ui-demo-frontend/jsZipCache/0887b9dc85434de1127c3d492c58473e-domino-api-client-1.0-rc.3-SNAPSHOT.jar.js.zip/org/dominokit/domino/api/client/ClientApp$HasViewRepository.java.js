/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasViewRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasViewRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasContributionsRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasContributionsRepository');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasViewRepository.$LambdaAdaptor');
const _ContributionsRepository = goog.require('org.dominokit.domino.api.client.extension.ContributionsRepository');


// Re-exports the implementation.
var HasViewRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');
exports = HasViewRepository;
 