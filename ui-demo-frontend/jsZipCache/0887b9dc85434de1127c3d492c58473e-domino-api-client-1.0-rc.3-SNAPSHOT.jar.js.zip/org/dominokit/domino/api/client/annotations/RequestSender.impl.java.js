/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.RequestSender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.RequestSender$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class RequestSender {
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_customServiceRoot__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_RequestSender = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_RequestSender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_RequestSender;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestSender.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestSender, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.RequestSender'));


RequestSender.$markImplementor(/** @type {Function} */ (RequestSender));


exports = RequestSender; 
//# sourceMappingURL=RequestSender.js.map