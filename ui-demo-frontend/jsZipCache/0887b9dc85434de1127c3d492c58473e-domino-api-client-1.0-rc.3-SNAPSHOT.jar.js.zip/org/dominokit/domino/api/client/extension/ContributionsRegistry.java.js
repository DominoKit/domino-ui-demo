/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContributionsRegistry.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.extension.ContributionsRegistry');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry.$LambdaAdaptor');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');


// Re-exports the implementation.
var ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
exports = ContributionsRegistry;
 