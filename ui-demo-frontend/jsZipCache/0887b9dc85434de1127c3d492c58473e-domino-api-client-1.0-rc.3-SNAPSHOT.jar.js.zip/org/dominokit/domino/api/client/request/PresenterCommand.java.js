/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.PresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.PresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseRequest = goog.require('org.dominokit.domino.api.client.request.BaseRequest');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DefaultRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext');
const _RequestState = goog.require('org.dominokit.domino.api.client.request.RequestState');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');
exports = PresenterCommand;
 