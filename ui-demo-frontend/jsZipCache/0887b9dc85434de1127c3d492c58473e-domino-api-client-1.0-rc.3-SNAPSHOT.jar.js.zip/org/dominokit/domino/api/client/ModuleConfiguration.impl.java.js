/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ModuleConfiguration$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');


/**
 * @interface
 */
class ModuleConfiguration {
  /**
   * @abstract
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
  }
  
  /**
   * @abstract
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
  }
  
  /**
   * @abstract
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
  }
  
  /**
   * @abstract
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
  }
  
  /**
   * @abstract
   * @param {InitialTaskRegistry} registry
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(registry) {
  }
  
  /**
   * @abstract
   * @param {RequestRestSendersRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(registry) {
  }
  
  /**
   * @param {ModuleConfiguration} $thisArg
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  static m_registerPresenters__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_PresenterRegistry($thisArg, registry) {
    ModuleConfiguration.$clinit();
  }
  
  /**
   * @param {ModuleConfiguration} $thisArg
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  static m_registerRequests__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_CommandRegistry($thisArg, registry) {
    ModuleConfiguration.$clinit();
  }
  
  /**
   * @param {ModuleConfiguration} $thisArg
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  static m_registerViews__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_ViewRegistry($thisArg, registry) {
    ModuleConfiguration.$clinit();
  }
  
  /**
   * @param {ModuleConfiguration} $thisArg
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  static m_registerContributions__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_extension_ContributionsRegistry($thisArg, registry) {
    ModuleConfiguration.$clinit();
  }
  
  /**
   * @param {ModuleConfiguration} $thisArg
   * @param {InitialTaskRegistry} registry
   * @return {void}
   * @public
   */
  static m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry($thisArg, registry) {
    ModuleConfiguration.$clinit();
  }
  
  /**
   * @param {ModuleConfiguration} $thisArg
   * @param {RequestRestSendersRegistry} registry
   * @return {void}
   * @public
   */
  static m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry($thisArg, registry) {
    ModuleConfiguration.$clinit();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ModuleConfiguration = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ModuleConfiguration;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModuleConfiguration.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.api.client.ModuleConfiguration'));


ModuleConfiguration.$markImplementor(/** @type {Function} */ (ModuleConfiguration));


exports = ModuleConfiguration; 
//# sourceMappingURL=ModuleConfiguration.js.map