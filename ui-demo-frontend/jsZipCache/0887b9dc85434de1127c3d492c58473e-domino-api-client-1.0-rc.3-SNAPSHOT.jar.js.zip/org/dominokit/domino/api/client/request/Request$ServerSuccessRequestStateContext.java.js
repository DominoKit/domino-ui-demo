/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$ServerSuccessRequestStateContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');


// Re-exports the implementation.
var ServerSuccessRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext$impl');
exports = ServerSuccessRequestStateContext;
 