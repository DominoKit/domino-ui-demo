/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContributionsRegistry$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContributionsRegistry.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Contribution = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');


/**
 * @implements {ContributionsRegistry}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(Class<?>, Contribution):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(Class<?>, Contribution):void} */
    this.f_$$fn__org_dominokit_domino_api_client_extension_ContributionsRegistry_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_extension_ContributionsRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_extension_ContributionsRegistry_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(Class<?>, Contribution):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_ContributionsRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_extension_ContributionsRegistry_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_extension_ContributionsRegistry_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {Class<?>} arg0
   * @param {Contribution} arg1
   * @return {void}
   * @public
   */
  m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_extension_ContributionsRegistry_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContributionsRegistry$$LambdaAdaptor'));


ContributionsRegistry.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ContributionsRegistry$$LambdaAdaptor.js.map