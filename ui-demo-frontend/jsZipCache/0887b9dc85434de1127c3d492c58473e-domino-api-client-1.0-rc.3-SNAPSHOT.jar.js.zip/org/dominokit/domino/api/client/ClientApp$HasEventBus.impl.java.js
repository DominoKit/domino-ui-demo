/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasEventBus.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasEventBus$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasEventBus.$LambdaAdaptor$impl');
let HasRequestRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasRequestRepository$impl');
let CommandsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository$impl');


/**
 * @interface
 */
class HasEventBus {
  /**
   * @abstract
   * @param {CommandsRepository} requestRepository
   * @return {HasRequestRepository}
   * @public
   */
  m_requestRepository__org_dominokit_domino_api_client_request_CommandsRepository(requestRepository) {
  }
  
  /**
   * @param {?function(CommandsRepository):HasRequestRepository} fn
   * @return {HasEventBus}
   * @public
   */
  static $adapt(fn) {
    HasEventBus.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasEventBus = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasEventBus;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasEventBus;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasEventBus.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasEventBus.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasEventBus, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasEventBus'));


HasEventBus.$markImplementor(/** @type {Function} */ (HasEventBus));


exports = HasEventBus; 
//# sourceMappingURL=ClientApp$HasEventBus.js.map