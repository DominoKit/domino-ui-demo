/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestStateContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestStateContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class RequestStateContext {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestStateContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_RequestStateContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestStateContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestStateContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestStateContext, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestStateContext'));


RequestStateContext.$markImplementor(/** @type {Function} */ (RequestStateContext));


exports = RequestStateContext; 
//# sourceMappingURL=RequestStateContext.js.map