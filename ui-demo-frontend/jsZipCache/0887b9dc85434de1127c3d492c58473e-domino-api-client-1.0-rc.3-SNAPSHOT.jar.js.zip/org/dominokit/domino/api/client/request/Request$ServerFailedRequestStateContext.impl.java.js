/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$ServerFailedRequestStateContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext$impl');

let FailedResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');


/**
 * @implements {RequestStateContext}
  */
class ServerFailedRequestStateContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {FailedResponseBean} */
    this.f_response__org_dominokit_domino_api_client_request_Request_ServerFailedRequestStateContext;
  }
  
  /**
   * Factory method corresponding to constructor 'ServerFailedRequestStateContext(FailedResponseBean)'.
   * @param {FailedResponseBean} response
   * @return {!ServerFailedRequestStateContext}
   * @public
   */
  static $create__org_dominokit_domino_api_shared_request_FailedResponseBean(response) {
    ServerFailedRequestStateContext.$clinit();
    let $instance = new ServerFailedRequestStateContext();
    $instance.$ctor__org_dominokit_domino_api_client_request_Request_ServerFailedRequestStateContext__org_dominokit_domino_api_shared_request_FailedResponseBean(response);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerFailedRequestStateContext(FailedResponseBean)'.
   * @param {FailedResponseBean} response
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Request_ServerFailedRequestStateContext__org_dominokit_domino_api_shared_request_FailedResponseBean(response) {
    this.$ctor__java_lang_Object__();
    this.f_response__org_dominokit_domino_api_client_request_Request_ServerFailedRequestStateContext = response;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerFailedRequestStateContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerFailedRequestStateContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerFailedRequestStateContext.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerFailedRequestStateContext, $Util.$makeClassName('org.dominokit.domino.api.client.request.Request$ServerFailedRequestStateContext'));


RequestStateContext.$markImplementor(ServerFailedRequestStateContext);


exports = ServerFailedRequestStateContext; 
//# sourceMappingURL=Request$ServerFailedRequestStateContext.js.map