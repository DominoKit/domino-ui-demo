/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasPresentersRepository$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasPresentersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository$impl');

let HasViewRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');
let ViewsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');


/**
 * @implements {HasPresentersRepository}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ViewsRepository):HasViewRepository} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(ViewsRepository):HasViewRepository} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ViewsRepository):HasViewRepository} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {ViewsRepository} arg0
   * @return {HasViewRepository}
   * @public
   */
  m_viewsRepository__org_dominokit_domino_api_client_mvp_view_ViewsRepository(arg0) {
    let /** ?function(ViewsRepository):HasViewRepository */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasPresentersRepository$$LambdaAdaptor'));


HasPresentersRepository.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasPresentersRepository$$LambdaAdaptor.js.map