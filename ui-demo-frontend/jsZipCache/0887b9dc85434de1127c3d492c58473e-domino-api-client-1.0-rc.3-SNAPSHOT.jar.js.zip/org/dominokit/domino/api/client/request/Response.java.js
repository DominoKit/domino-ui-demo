/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Response.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.Response');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CanFailOrSend = goog.require('org.dominokit.domino.api.client.request.CanFailOrSend');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.request.Response.$LambdaAdaptor');
const _Success = goog.require('org.dominokit.domino.api.client.request.Success');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');


// Re-exports the implementation.
var Response = goog.require('org.dominokit.domino.api.client.request.Response$impl');
exports = Response;
 