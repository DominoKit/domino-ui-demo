/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasEventBus$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasEventBus.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasEventBus = goog.require('org.dominokit.domino.api.client.ClientApp.HasEventBus$impl');

let HasRequestRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasRequestRepository$impl');
let CommandsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository$impl');


/**
 * @implements {HasEventBus}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(CommandsRepository):HasRequestRepository} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(CommandsRepository):HasRequestRepository} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasEventBus_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasEventBus_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasEventBus_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(CommandsRepository):HasRequestRepository} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasEventBus_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasEventBus_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasEventBus_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {CommandsRepository} arg0
   * @return {HasRequestRepository}
   * @public
   */
  m_requestRepository__org_dominokit_domino_api_client_request_CommandsRepository(arg0) {
    let /** ?function(CommandsRepository):HasRequestRepository */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasEventBus_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasEventBus$$LambdaAdaptor'));


HasEventBus.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasEventBus$$LambdaAdaptor.js.map