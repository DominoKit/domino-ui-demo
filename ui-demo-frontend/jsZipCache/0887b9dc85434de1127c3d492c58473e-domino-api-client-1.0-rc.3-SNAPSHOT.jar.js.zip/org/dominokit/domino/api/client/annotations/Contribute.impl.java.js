/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.Contribute.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.Contribute$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.annotations.Contribute.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class Contribute {
  /**
   * @param {?function():Class<?>} fn
   * @return {Contribute}
   * @public
   */
  static $adapt(fn) {
    Contribute.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_Contribute = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_Contribute;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_Contribute;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Contribute.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.annotations.Contribute.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Contribute, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.Contribute'));


Contribute.$markImplementor(/** @type {Function} */ (Contribute));


exports = Contribute; 
//# sourceMappingURL=Contribute.js.map