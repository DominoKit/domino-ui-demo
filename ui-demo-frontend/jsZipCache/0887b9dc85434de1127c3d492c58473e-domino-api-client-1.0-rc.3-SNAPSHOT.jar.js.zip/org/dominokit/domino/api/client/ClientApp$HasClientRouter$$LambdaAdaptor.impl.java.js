/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasClientRouter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasClientRouter.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasClientRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasClientRouter$impl');

let HasServerRouter = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasServerRouter$impl');
let RequestRouter = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRouter$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');


/**
 * @implements {HasClientRouter}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(RequestRouter<ServerRequest>):HasServerRouter} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(RequestRouter<ServerRequest>):HasServerRouter} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(RequestRouter<ServerRequest>):HasServerRouter} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {RequestRouter<ServerRequest>} arg0
   * @return {HasServerRouter}
   * @public
   */
  m_serverRouter__org_dominokit_domino_api_client_request_RequestRouter(arg0) {
    let /** ?function(RequestRouter<ServerRequest>):HasServerRouter */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasClientRouter_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasClientRouter$$LambdaAdaptor'));


HasClientRouter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasClientRouter$$LambdaAdaptor.js.map