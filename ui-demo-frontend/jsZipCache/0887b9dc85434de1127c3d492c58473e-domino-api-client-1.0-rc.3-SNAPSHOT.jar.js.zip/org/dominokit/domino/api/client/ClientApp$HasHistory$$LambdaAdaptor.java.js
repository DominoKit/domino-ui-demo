/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasHistory$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasHistory.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasHistory = goog.require('org.dominokit.domino.api.client.ClientApp.HasHistory');
const _HasAsyncRunner = goog.require('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner');
const _AsyncRunner = goog.require('org.dominokit.domino.api.client.async.AsyncRunner');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasHistory.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 