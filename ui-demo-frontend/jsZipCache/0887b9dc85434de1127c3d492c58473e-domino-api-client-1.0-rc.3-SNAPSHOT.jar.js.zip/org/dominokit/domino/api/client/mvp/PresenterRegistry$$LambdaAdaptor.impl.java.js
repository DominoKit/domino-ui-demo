/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.PresenterRegistry$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.PresenterRegistry.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');

let LazyPresenterLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');


/**
 * @implements {PresenterRegistry}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(LazyPresenterLoader):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(LazyPresenterLoader):void} */
    this.f_$$fn__org_dominokit_domino_api_client_mvp_PresenterRegistry_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_mvp_PresenterRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_PresenterRegistry_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(LazyPresenterLoader):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_PresenterRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_PresenterRegistry_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_mvp_PresenterRegistry_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {LazyPresenterLoader} arg0
   * @return {void}
   * @public
   */
  m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_mvp_PresenterRegistry_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.PresenterRegistry$$LambdaAdaptor'));


PresenterRegistry.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=PresenterRegistry$$LambdaAdaptor.js.map