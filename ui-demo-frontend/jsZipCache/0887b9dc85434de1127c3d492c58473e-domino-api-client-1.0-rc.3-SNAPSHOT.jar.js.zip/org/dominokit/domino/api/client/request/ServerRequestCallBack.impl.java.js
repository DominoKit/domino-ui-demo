/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.ServerRequestCallBack.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.ServerRequestCallBack$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @interface
 */
class ServerRequestCallBack {
  /**
   * @abstract
   * @param {Throwable} throwable
   * @return {void}
   * @public
   */
  m_onFailure__java_lang_Throwable(throwable) {
  }
  
  /**
   * @abstract
   * @param {ResponseBean} response
   * @return {void}
   * @public
   */
  m_onSuccess__org_dominokit_domino_api_shared_request_ResponseBean(response) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_ServerRequestCallBack = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_ServerRequestCallBack;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_ServerRequestCallBack;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerRequestCallBack.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ServerRequestCallBack, $Util.$makeClassName('org.dominokit.domino.api.client.request.ServerRequestCallBack'));


ServerRequestCallBack.$markImplementor(/** @type {Function} */ (ServerRequestCallBack));


exports = ServerRequestCallBack; 
//# sourceMappingURL=ServerRequestCallBack.js.map