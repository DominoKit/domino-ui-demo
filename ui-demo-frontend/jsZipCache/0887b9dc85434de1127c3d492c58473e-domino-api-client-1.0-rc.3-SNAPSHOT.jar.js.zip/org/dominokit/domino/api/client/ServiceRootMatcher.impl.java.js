/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ServiceRootMatcher.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ServiceRootMatcher$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');
let HasServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot$impl');
let PathMatcher = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ServiceRootMatcher extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ServiceRootMatcher()'.
   * @return {!ServiceRootMatcher}
   * @public
   */
  static $create__() {
    ServiceRootMatcher.$clinit();
    let $instance = new ServiceRootMatcher();
    $instance.$ctor__org_dominokit_domino_api_client_ServiceRootMatcher__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServiceRootMatcher()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ServiceRootMatcher__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} path
   * @return {?string}
   * @public
   */
  static m_matchedServiceRoot__java_lang_String(path) {
    ServiceRootMatcher.$clinit();
    let serviceRoots = ClientApp.m_make__().m_dominoOptions__().m_getServiceRoots__();
    return /**@type {DynamicServiceRoot} */ ($Casts.$to(serviceRoots.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** DynamicServiceRoot */ r) =>{
      return r.m_isMatchingPath__java_lang_String(path);
    }))).m_findFirst__().m_orElse__java_lang_Object(ServiceRootMatcher.$f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_), DynamicServiceRoot)).m_onMatchingPath__();
  }
  
  /**
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  static m_hasServiceRoot__java_lang_String(path) {
    ServiceRootMatcher.$clinit();
    let serviceRoots = ClientApp.m_make__().m_dominoOptions__().m_getServiceRoots__();
    return serviceRoots.m_stream__().m_anyMatch__java_util_function_Predicate(Predicate.$adapt(((/** DynamicServiceRoot */ r) =>{
      return r.m_isMatchingPath__java_lang_String(path);
    })));
  }
  
  /**
   * @return {DynamicServiceRoot}
   * @public
   */
  static get f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_() {
    return (ServiceRootMatcher.$clinit(), ServiceRootMatcher.$f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_);
  }
  
  /**
   * @param {DynamicServiceRoot} value
   * @return {void}
   * @public
   */
  static set f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_(value) {
    (ServiceRootMatcher.$clinit(), ServiceRootMatcher.$f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServiceRootMatcher;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServiceRootMatcher);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServiceRootMatcher.$clinit = function() {};
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    DynamicServiceRoot = goog.module.get('org.dominokit.domino.api.client.DynamicServiceRoot$impl');
    HasServiceRoot = goog.module.get('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot$impl');
    PathMatcher = goog.module.get('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    ServiceRootMatcher.$f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_ = DynamicServiceRoot.m_pathMatcher__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher(PathMatcher.$adapt(((/** ?string */ path) =>{
      return true;
    }))).m_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot(HasServiceRoot.$adapt((() =>{
      return ClientApp.m_make__().m_dominoOptions__().m_getDefaultServiceRoot__();
    })));
  }
  
  
};

$Util.$setClassMetadata(ServiceRootMatcher, $Util.$makeClassName('org.dominokit.domino.api.client.ServiceRootMatcher'));


/** @private {DynamicServiceRoot} */
ServiceRootMatcher.$f_defaultRoot__org_dominokit_domino_api_client_ServiceRootMatcher_;




exports = ServiceRootMatcher; 
//# sourceMappingURL=ServiceRootMatcher.js.map