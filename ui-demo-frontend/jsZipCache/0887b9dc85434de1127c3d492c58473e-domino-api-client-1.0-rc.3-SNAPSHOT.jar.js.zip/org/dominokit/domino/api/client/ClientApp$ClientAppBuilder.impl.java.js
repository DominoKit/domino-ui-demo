/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$ClientAppBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.ClientAppBuilder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CanBuildClientApp = goog.require('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp$impl');
const HasAsyncRunner = goog.require('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner$impl');
const HasClientRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasClientRouter$impl');
const HasContributionsRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasContributionsRepository$impl');
const HasEventBus = goog.require('org.dominokit.domino.api.client.ClientApp.HasEventBus$impl');
const HasHistory = goog.require('org.dominokit.domino.api.client.ClientApp.HasHistory$impl');
const HasOptions = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions$impl');
const HasPresentersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository$impl');
const HasRequestRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRepository$impl');
const HasRequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository$impl');
const HasServerRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasServerRouter$impl');
const HasViewRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');

let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let ClientStartupTask = goog.forwardDeclare('org.dominokit.domino.api.client.ClientStartupTask$impl');
let DominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.DominoOptions$impl');
let AsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner$impl');
let EventsBus = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus$impl');
let ContributionsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');
let PresentersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');
let ViewsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');
let CommandsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');
let RequestRestSendersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRepository$impl');
let RequestRouter = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRouter$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let MainExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');
let AppHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.AppHistory$impl');


/**
 * @implements {HasClientRouter}
 * @implements {HasServerRouter}
 * @implements {HasEventBus}
 * @implements {HasRequestRepository}
 * @implements {HasPresentersRepository}
 * @implements {HasViewRepository}
 * @implements {HasContributionsRepository}
 * @implements {HasRequestRestSendersRepository}
 * @implements {HasHistory}
 * @implements {HasAsyncRunner}
 * @implements {HasOptions}
 * @implements {CanBuildClientApp}
  */
class ClientAppBuilder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {RequestRouter<PresenterCommand>} */
    this.f_clientRouter__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {RequestRouter<ServerRequest>} */
    this.f_serverRouter__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {EventsBus} */
    this.f_eventsBus__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {CommandsRepository} */
    this.f_requestRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {PresentersRepository} */
    this.f_presentersRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {ViewsRepository} */
    this.f_viewsRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {ContributionsRepository} */
    this.f_contributionsRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {RequestRestSendersRepository} */
    this.f_requestRestSendersRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {MainExtensionPoint} */
    this.f_mainExtensionPoint__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {AppHistory} */
    this.f_history__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {AsyncRunner} */
    this.f_asyncRunner__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
    /** @public {DominoOptions} */
    this.f_dominoOptions__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_;
  }
  
  /**
   * Factory method corresponding to constructor 'ClientAppBuilder(RequestRouter)'.
   * @param {RequestRouter<PresenterCommand>} clientRouter
   * @return {!ClientAppBuilder}
   * @public
   */
  static $create__org_dominokit_domino_api_client_request_RequestRouter(clientRouter) {
    ClientAppBuilder.$clinit();
    let $instance = new ClientAppBuilder();
    $instance.$ctor__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder__org_dominokit_domino_api_client_request_RequestRouter(clientRouter);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ClientAppBuilder(RequestRouter)'.
   * @param {RequestRouter<PresenterCommand>} clientRouter
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder__org_dominokit_domino_api_client_request_RequestRouter(clientRouter) {
    this.$ctor__java_lang_Object__();
    this.f_clientRouter__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = clientRouter;
  }
  
  /**
   * @param {RequestRouter<PresenterCommand>} clientRouter
   * @return {HasClientRouter}
   * @public
   */
  static m_clientRouter__org_dominokit_domino_api_client_request_RequestRouter(clientRouter) {
    ClientAppBuilder.$clinit();
    return ClientAppBuilder.$create__org_dominokit_domino_api_client_request_RequestRouter(clientRouter);
  }
  
  /**
   * @override
   * @param {RequestRouter<ServerRequest>} serverRouter
   * @return {HasServerRouter}
   * @public
   */
  m_serverRouter__org_dominokit_domino_api_client_request_RequestRouter(serverRouter) {
    this.f_serverRouter__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = serverRouter;
    return this;
  }
  
  /**
   * @override
   * @param {EventsBus} eventsBus
   * @return {HasEventBus}
   * @public
   */
  m_eventsBus__org_dominokit_domino_api_client_events_EventsBus(eventsBus) {
    this.f_eventsBus__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = eventsBus;
    return this;
  }
  
  /**
   * @override
   * @param {CommandsRepository} requestRepository
   * @return {HasRequestRepository}
   * @public
   */
  m_requestRepository__org_dominokit_domino_api_client_request_CommandsRepository(requestRepository) {
    this.f_requestRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = requestRepository;
    return this;
  }
  
  /**
   * @override
   * @param {PresentersRepository} presentersRepository
   * @return {HasPresentersRepository}
   * @public
   */
  m_presentersRepository__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository(presentersRepository) {
    this.f_presentersRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = presentersRepository;
    return this;
  }
  
  /**
   * @override
   * @param {ViewsRepository} viewsRepository
   * @return {HasViewRepository}
   * @public
   */
  m_viewsRepository__org_dominokit_domino_api_client_mvp_view_ViewsRepository(viewsRepository) {
    this.f_viewsRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = viewsRepository;
    return this;
  }
  
  /**
   * @override
   * @param {ContributionsRepository} contributionsRepository
   * @return {HasContributionsRepository}
   * @public
   */
  m_contributionsRepository__org_dominokit_domino_api_client_extension_ContributionsRepository(contributionsRepository) {
    this.f_contributionsRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = contributionsRepository;
    return this;
  }
  
  /**
   * @override
   * @param {RequestRestSendersRepository} requestRestSendersRepository
   * @return {HasRequestRestSendersRepository}
   * @public
   */
  m_requestSendersRepository__org_dominokit_domino_api_client_request_RequestRestSendersRepository(requestRestSendersRepository) {
    this.f_requestRestSendersRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = requestRestSendersRepository;
    return this;
  }
  
  /**
   * @override
   * @param {AppHistory} history
   * @return {HasHistory}
   * @public
   */
  m_history__org_dominokit_domino_api_shared_history_AppHistory(history) {
    this.f_history__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = history;
    return this;
  }
  
  /**
   * @override
   * @param {AsyncRunner} asyncRunner
   * @return {HasAsyncRunner}
   * @public
   */
  m_asyncRunner__org_dominokit_domino_api_client_async_AsyncRunner(asyncRunner) {
    this.f_asyncRunner__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = asyncRunner;
    return this;
  }
  
  /**
   * @override
   * @param {MainExtensionPoint} mainExtensionPoint
   * @return {HasOptions}
   * @public
   */
  m_mainExtensionPoint__org_dominokit_domino_api_shared_extension_MainExtensionPoint(mainExtensionPoint) {
    this.f_mainExtensionPoint__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = mainExtensionPoint;
    return this;
  }
  
  /**
   * @override
   * @param {DominoOptions} dominoOptions
   * @return {CanBuildClientApp}
   * @public
   */
  m_dominoOptions__org_dominokit_domino_api_client_DominoOptions(dominoOptions) {
    this.f_dominoOptions__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_ = dominoOptions;
    return this;
  }
  
  /**
   * @override
   * @return {ClientApp}
   * @public
   */
  m_build__() {
    this.m_initClientApp___$p_org_dominokit_domino_api_client_ClientApp_ClientAppBuilder();
    return ClientApp.$create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initClientApp___$p_org_dominokit_domino_api_client_ClientApp_ClientAppBuilder() {
    ClientApp.f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_clientRouter__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_serverRouter__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_eventsBus__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_requestRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_presentersRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_viewsRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_contributionsRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_requestRestSendersRepository__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_mainExtensionPoint__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_history__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(/**@type {!LinkedList<ClientStartupTask>} */ (LinkedList.$create__()));
    ClientApp.f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_asyncRunner__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
    ClientApp.f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_.m_hold__java_lang_Object(this.f_dominoOptions__org_dominokit_domino_api_client_ClientApp_ClientAppBuilder_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientAppBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientAppBuilder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientAppBuilder.$clinit = function() {};
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ClientAppBuilder, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$ClientAppBuilder'));


HasClientRouter.$markImplementor(ClientAppBuilder);
HasServerRouter.$markImplementor(ClientAppBuilder);
HasEventBus.$markImplementor(ClientAppBuilder);
HasRequestRepository.$markImplementor(ClientAppBuilder);
HasPresentersRepository.$markImplementor(ClientAppBuilder);
HasViewRepository.$markImplementor(ClientAppBuilder);
HasContributionsRepository.$markImplementor(ClientAppBuilder);
HasRequestRestSendersRepository.$markImplementor(ClientAppBuilder);
HasHistory.$markImplementor(ClientAppBuilder);
HasAsyncRunner.$markImplementor(ClientAppBuilder);
HasOptions.$markImplementor(ClientAppBuilder);
CanBuildClientApp.$markImplementor(ClientAppBuilder);


exports = ClientAppBuilder; 
//# sourceMappingURL=ClientApp$ClientAppBuilder.js.map