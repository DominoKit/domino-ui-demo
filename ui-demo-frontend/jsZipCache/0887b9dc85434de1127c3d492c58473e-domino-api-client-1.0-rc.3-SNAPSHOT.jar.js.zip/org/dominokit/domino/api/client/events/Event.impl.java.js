/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.Event.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.Event$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class Event {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_fire__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_process__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_Event = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_events_Event;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_Event;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Event.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Event, $Util.$makeClassName('org.dominokit.domino.api.client.events.Event'));


Event.$markImplementor(/** @type {Function} */ (Event));


exports = Event; 
//# sourceMappingURL=Event.js.map