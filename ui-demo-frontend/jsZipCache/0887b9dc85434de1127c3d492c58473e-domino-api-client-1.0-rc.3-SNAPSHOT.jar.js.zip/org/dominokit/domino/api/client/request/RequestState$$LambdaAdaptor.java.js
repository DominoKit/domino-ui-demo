/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestState$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.RequestState.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestState = goog.require('org.dominokit.domino.api.client.request.RequestState');
const _RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.request.RequestState.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 