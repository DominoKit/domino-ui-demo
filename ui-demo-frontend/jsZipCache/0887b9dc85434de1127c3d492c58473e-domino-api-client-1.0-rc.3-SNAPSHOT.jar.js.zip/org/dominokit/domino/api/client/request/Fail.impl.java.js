/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Fail.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Fail$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.Fail.$LambdaAdaptor$impl');
let FailedResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');


/**
 * @interface
 */
class Fail {
  /**
   * @abstract
   * @param {FailedResponseBean} failedResponse
   * @return {void}
   * @public
   */
  m_onFail__org_dominokit_domino_api_shared_request_FailedResponseBean(failedResponse) {
  }
  
  /**
   * @param {?function(FailedResponseBean):void} fn
   * @return {Fail}
   * @public
   */
  static $adapt(fn) {
    Fail.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Fail = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_Fail;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Fail;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Fail.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.Fail.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Fail, $Util.$makeClassName('org.dominokit.domino.api.client.request.Fail'));


Fail.$markImplementor(/** @type {Function} */ (Fail));


exports = Fail; 
//# sourceMappingURL=Fail.js.map