/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.LoadersClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.loaders.client.LoadersClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class LoadersClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LoadersClientModule()'.
   * @return {!LoadersClientModule}
   * @public
   */
  static $create__() {
    LoadersClientModule.$clinit();
    let $instance = new LoadersClientModule();
    $instance.$ctor__org_dominokit_domino_loaders_client_LoadersClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoadersClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_loaders_client_LoadersClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    LoadersClientModule.$f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_.m_info__java_lang_String("Initializing Loaders frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_() {
    return (LoadersClientModule.$clinit(), LoadersClientModule.$f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_(value) {
    (LoadersClientModule.$clinit(), LoadersClientModule.$f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoadersClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoadersClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoadersClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    LoadersClientModule.$f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LoadersClientModule));
  }
  
  
};

$Util.$setClassMetadata(LoadersClientModule, $Util.$makeClassName('org.dominokit.domino.loaders.client.LoadersClientModule'));


/** @private {Logger} */
LoadersClientModule.$f_LOGGER__org_dominokit_domino_loaders_client_LoadersClientModule_;




exports = LoadersClientModule; 
//# sourceMappingURL=LoadersClientModule.js.map