/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Timer = goog.require('org.gwtproject.timer.client.Timer$impl');

let LoadersViewImpl = goog.forwardDeclare('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl$impl');
let Loader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.Loader$impl');


class $1 extends Timer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {LoadersViewImpl} */
    this.f_$outer_this__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_1;
    /** @public {Loader} */
    this.$c_loader;
  }
  
  /**
   * Factory method corresponding to constructor 'new Timer(LoadersViewImpl, Loader)'.
   * @param {LoadersViewImpl} $outer_this
   * @param {Loader} $c_loader
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl__org_dominokit_domino_ui_loaders_Loader($outer_this, $c_loader) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_1__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl__org_dominokit_domino_ui_loaders_Loader($outer_this, $c_loader);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new Timer(LoadersViewImpl, Loader)'.
   * @param {LoadersViewImpl} $outer_this
   * @param {Loader} $c_loader
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_1__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl__org_dominokit_domino_ui_loaders_Loader($outer_this, $c_loader) {
    this.f_$outer_this__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_1 = $outer_this;
    this.$c_loader = $c_loader;
    this.$ctor__org_gwtproject_timer_client_Timer__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_run__() {
    this.$c_loader.m_stop__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    Timer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl$1'));




exports = $1; 
//# sourceMappingURL=LoadersViewImpl$1.js.map