/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _LoadersView = goog.require('org.dominokit.domino.loaders.client.views.LoadersView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeResource = goog.require('org.dominokit.domino.loaders.client.views.CodeResource');
const _$1 = goog.require('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$1');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$LambdaAdaptor$1');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Loader = goog.require('org.dominokit.domino.ui.loaders.Loader');
const _LoaderEffect = goog.require('org.dominokit.domino.ui.loaders.LoaderEffect');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LoadersViewImpl = goog.require('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl$impl');
exports = LoadersViewImpl;
 