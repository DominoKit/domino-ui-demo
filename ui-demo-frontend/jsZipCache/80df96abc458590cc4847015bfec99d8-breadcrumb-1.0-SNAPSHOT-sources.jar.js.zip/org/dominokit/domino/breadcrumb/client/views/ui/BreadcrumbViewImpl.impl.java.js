/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BreadcrumbView = goog.require('org.dominokit.domino.breadcrumb.client.views.BreadcrumbView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$17$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$18$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$20$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$22$impl');
let $LambdaAdaptor$23 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$23$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$24$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$25$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$26$impl');
let $LambdaAdaptor$27 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$27$impl');
let $LambdaAdaptor$28 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$28$impl');
let $LambdaAdaptor$29 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$29$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$30 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$30$impl');
let $LambdaAdaptor$31 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$31$impl');
let $LambdaAdaptor$32 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$32$impl');
let $LambdaAdaptor$33 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$33$impl');
let $LambdaAdaptor$34 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$34$impl');
let $LambdaAdaptor$35 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$35$impl');
let $LambdaAdaptor$36 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$36$impl');
let $LambdaAdaptor$37 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$37$impl');
let $LambdaAdaptor$38 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$38$impl');
let $LambdaAdaptor$39 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$39$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$40 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$40$impl');
let $LambdaAdaptor$41 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$41$impl');
let $LambdaAdaptor$42 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$42$impl');
let $LambdaAdaptor$43 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$43$impl');
let $LambdaAdaptor$44 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$44$impl');
let $LambdaAdaptor$45 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$45$impl');
let $LambdaAdaptor$46 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$46$impl');
let $LambdaAdaptor$47 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$47$impl');
let $LambdaAdaptor$48 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$48$impl');
let $LambdaAdaptor$49 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$49$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$50 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$50$impl');
let $LambdaAdaptor$51 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$51$impl');
let $LambdaAdaptor$52 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$52$impl');
let $LambdaAdaptor$53 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$53$impl');
let $LambdaAdaptor$54 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$54$impl');
let $LambdaAdaptor$55 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$55$impl');
let $LambdaAdaptor$56 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$56$impl');
let $LambdaAdaptor$57 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$57$impl');
let $LambdaAdaptor$58 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$58$impl');
let $LambdaAdaptor$59 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$59$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$60 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$60$impl');
let $LambdaAdaptor$61 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$61$impl');
let $LambdaAdaptor$62 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$62$impl');
let $LambdaAdaptor$63 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$63$impl');
let $LambdaAdaptor$64 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$64$impl');
let $LambdaAdaptor$65 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$65$impl');
let $LambdaAdaptor$66 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$66$impl');
let $LambdaAdaptor$67 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$67$impl');
let $LambdaAdaptor$68 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$68$impl');
let $LambdaAdaptor$69 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$69$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$70 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$70$impl');
let $LambdaAdaptor$71 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$71$impl');
let $LambdaAdaptor$72 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$72$impl');
let $LambdaAdaptor$73 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$73$impl');
let $LambdaAdaptor$74 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$74$impl');
let $LambdaAdaptor$75 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$75$impl');
let $LambdaAdaptor$76 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$76$impl');
let $LambdaAdaptor$77 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$77$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$9$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Breadcrumb = goog.forwardDeclare('org.dominokit.domino.ui.breadcrumbs.Breadcrumb$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {BreadcrumbView}
  */
class BreadcrumbViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbViewImpl()'.
   * @return {!BreadcrumbViewImpl}
   * @public
   */
  static $create__() {
    BreadcrumbViewImpl.$clinit();
    let $instance = new BreadcrumbViewImpl();
    $instance.$ctor__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("BREADCRUMBS").m_asElement__());
    this.m_basicBreadcrumb___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl();
    this.m_coloredBreadcrumb___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl();
    this.m_breadcrumbWithBackground___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl();
    this.m_alignment___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicBreadcrumb___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl() {
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(BreadcrumbViewImpl.f_MODULE_NAME__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("BASIC EXAMPLES", "Separators are automatically added for breadcrumb elements").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$1(((/** Event */ evt) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$4(((/** Event */ evt$3$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$5(((/** Event */ evt$4$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$6(((/** Event */ evt$5$) =>{
    }))))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String("WITH ICONS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$7(((/** Event */ evt$6$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$8(((/** Event */ evt$7$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$9(((/** Event */ evt$8$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$10(((/** Event */ evt$9$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$11(((/** Event */ evt$10$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$12(((/** Event */ evt$11$) =>{
    }))))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BreadcrumbViewImpl.f_MODULE_NAME__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl, "basicBreadcrumb").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_coloredBreadcrumb___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl() {
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("WITH MATERIAL DESIGN COLORS", "You can use material design colors").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$13(((/** Event */ evt) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$14(((/** Event */ evt$1$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$15(((/** Event */ evt$2$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$16(((/** Event */ evt$3$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$17(((/** Event */ evt$4$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$18(((/** Event */ evt$5$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$19(((/** Event */ evt$6$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$20(((/** Event */ evt$7$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" File ", new $LambdaAdaptor$21(((/** Event */ evt$8$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$22(((/** Event */ evt$9$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$23(((/** Event */ evt$10$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$24(((/** Event */ evt$11$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" File ", new $LambdaAdaptor$25(((/** Event */ evt$12$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Extensions ", new $LambdaAdaptor$26(((/** Event */ evt$13$) =>{
    }))))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String("WITH ICONS & MATERIAL DESIGN COLORS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$27(((/** Event */ evt$14$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$28(((/** Event */ evt$15$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$29(((/** Event */ evt$16$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$30(((/** Event */ evt$17$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$31(((/** Event */ evt$18$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$32(((/** Event */ evt$19$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$33(((/** Event */ evt$20$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$34(((/** Event */ evt$21$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__(), " File ", new $LambdaAdaptor$35(((/** Event */ evt$22$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$36(((/** Event */ evt$23$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$37(((/** Event */ evt$24$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$38(((/** Event */ evt$25$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__(), " File ", new $LambdaAdaptor$39(((/** Event */ evt$26$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_extension__(), " Extensions ", new $LambdaAdaptor$40(((/** Event */ evt$27$) =>{
    }))))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BreadcrumbViewImpl.f_MODULE_NAME__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl, "coloredBreadcrumb").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_breadcrumbWithBackground___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl() {
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("WITH MATERIAL DESIGN COLORS", "You can use material design colors").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$41(((/** Event */ evt) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$42(((/** Event */ evt$1$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$43(((/** Event */ evt$2$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$44(((/** Event */ evt$3$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$45(((/** Event */ evt$4$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$46(((/** Event */ evt$5$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$47(((/** Event */ evt$6$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$48(((/** Event */ evt$7$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" File ", new $LambdaAdaptor$49(((/** Event */ evt$8$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Home ", new $LambdaAdaptor$50(((/** Event */ evt$9$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Library ", new $LambdaAdaptor$51(((/** Event */ evt$10$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Data ", new $LambdaAdaptor$52(((/** Event */ evt$11$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" File ", new $LambdaAdaptor$53(((/** Event */ evt$12$) =>{
    }))).m_appendChild__java_lang_String__elemental2_dom_EventListener(" Extensions ", new $LambdaAdaptor$54(((/** Event */ evt$13$) =>{
    }))))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String("WITH ICONS & MATERIAL DESIGN COLORS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$55(((/** Event */ evt$14$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$56(((/** Event */ evt$15$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$57(((/** Event */ evt$16$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$58(((/** Event */ evt$17$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$59(((/** Event */ evt$18$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$60(((/** Event */ evt$19$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$61(((/** Event */ evt$20$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$62(((/** Event */ evt$21$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__(), " File ", new $LambdaAdaptor$63(((/** Event */ evt$22$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$64(((/** Event */ evt$23$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$65(((/** Event */ evt$24$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$66(((/** Event */ evt$25$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__(), " File ", new $LambdaAdaptor$67(((/** Event */ evt$26$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_extension__(), " Extensions ", new $LambdaAdaptor$68(((/** Event */ evt$27$) =>{
    }))))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BreadcrumbViewImpl.f_MODULE_NAME__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl, "breadcrumbWithBackground").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_alignment___$p_org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl() {
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(Card.m_create__java_lang_String("ALIGNMENTS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$69(((/** Event */ evt) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$70(((/** Event */ evt$1$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_alignCenter__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$71(((/** Event */ evt$2$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$72(((/** Event */ evt$3$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$73(((/** Event */ evt$4$) =>{
    })))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Breadcrumb.m_create__().m_alignRight__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__(), " Home ", new $LambdaAdaptor$74(((/** Event */ evt$5$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_library_books__(), " Library ", new $LambdaAdaptor$75(((/** Event */ evt$6$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_archive__(), " Data ", new $LambdaAdaptor$76(((/** Event */ evt$7$) =>{
    }))).m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__(), " File ", new $LambdaAdaptor$77(((/** Event */ evt$8$) =>{
    })))).m_asElement__());
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BreadcrumbViewImpl.f_MODULE_NAME__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl, "alignment").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl() {
    this.f_element__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BreadcrumbViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BreadcrumbViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BreadcrumbViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$17$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$18$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$20$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$22$impl');
    $LambdaAdaptor$23 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$23$impl');
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$24$impl');
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$25$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$26$impl');
    $LambdaAdaptor$27 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$27$impl');
    $LambdaAdaptor$28 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$28$impl');
    $LambdaAdaptor$29 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$29$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$30 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$30$impl');
    $LambdaAdaptor$31 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$31$impl');
    $LambdaAdaptor$32 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$32$impl');
    $LambdaAdaptor$33 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$33$impl');
    $LambdaAdaptor$34 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$34$impl');
    $LambdaAdaptor$35 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$35$impl');
    $LambdaAdaptor$36 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$36$impl');
    $LambdaAdaptor$37 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$37$impl');
    $LambdaAdaptor$38 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$38$impl');
    $LambdaAdaptor$39 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$39$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$40 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$40$impl');
    $LambdaAdaptor$41 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$41$impl');
    $LambdaAdaptor$42 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$42$impl');
    $LambdaAdaptor$43 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$43$impl');
    $LambdaAdaptor$44 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$44$impl');
    $LambdaAdaptor$45 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$45$impl');
    $LambdaAdaptor$46 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$46$impl');
    $LambdaAdaptor$47 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$47$impl');
    $LambdaAdaptor$48 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$48$impl');
    $LambdaAdaptor$49 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$49$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$50 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$50$impl');
    $LambdaAdaptor$51 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$51$impl');
    $LambdaAdaptor$52 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$52$impl');
    $LambdaAdaptor$53 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$53$impl');
    $LambdaAdaptor$54 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$54$impl');
    $LambdaAdaptor$55 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$55$impl');
    $LambdaAdaptor$56 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$56$impl');
    $LambdaAdaptor$57 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$57$impl');
    $LambdaAdaptor$58 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$58$impl');
    $LambdaAdaptor$59 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$59$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$60 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$60$impl');
    $LambdaAdaptor$61 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$61$impl');
    $LambdaAdaptor$62 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$62$impl');
    $LambdaAdaptor$63 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$63$impl');
    $LambdaAdaptor$64 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$64$impl');
    $LambdaAdaptor$65 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$65$impl');
    $LambdaAdaptor$66 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$66$impl');
    $LambdaAdaptor$67 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$67$impl');
    $LambdaAdaptor$68 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$68$impl');
    $LambdaAdaptor$69 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$69$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$70 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$70$impl');
    $LambdaAdaptor$71 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$71$impl');
    $LambdaAdaptor$72 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$72$impl');
    $LambdaAdaptor$73 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$73$impl');
    $LambdaAdaptor$74 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$74$impl');
    $LambdaAdaptor$75 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$75$impl');
    $LambdaAdaptor$76 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$76$impl');
    $LambdaAdaptor$77 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$77$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$9$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Breadcrumb = goog.module.get('org.dominokit.domino.ui.breadcrumbs.Breadcrumb$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BreadcrumbViewImpl, $Util.$makeClassName('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl'));


/** @public {?string} @const */
BreadcrumbViewImpl.f_MODULE_NAME__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl = "breadcrumb";


BreadcrumbView.$markImplementor(BreadcrumbViewImpl);


exports = BreadcrumbViewImpl; 
//# sourceMappingURL=BreadcrumbViewImpl.js.map