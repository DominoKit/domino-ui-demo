/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.views.ui.HomeViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.home.client.views.ui.HomeViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const HomeView = goog.require('org.dominokit.domino.home.client.views.HomeView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let HTMLParagraphElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let AppHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.AppHistory$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$1$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$3$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Direction = goog.forwardDeclare('org.dominokit.domino.ui.spin.Direction$impl');
let HSpinSelect = goog.forwardDeclare('org.dominokit.domino.ui.spin.HSpinSelect$impl');
let NavigationHandler = goog.forwardDeclare('org.dominokit.domino.ui.spin.NavigationHandler$impl');
let SpinItem = goog.forwardDeclare('org.dominokit.domino.ui.spin.SpinItem$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Timer = goog.forwardDeclare('org.gwtproject.timer.client.Timer$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {HomeView}
  */
class HomeViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_;
    /** @public {number} */
    this.f_direction__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = 0;
    /** @public {Timer} */
    this.f_timer__org_dominokit_domino_home_client_views_ui_HomeViewImpl_;
    /** @public {HSpinSelect<?string>} */
    this.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'HomeViewImpl()'.
   * @return {!HomeViewImpl}
   * @public
   */
  static $create__() {
    HomeViewImpl.$clinit();
    let $instance = new HomeViewImpl();
    $instance.$ctor__org_dominokit_domino_home_client_views_ui_HomeViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HomeViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_home_client_views_ui_HomeViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_home_client_views_ui_HomeViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("DOMINO-UI").m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {Paragraph} */ ($Casts.$to(Paragraph.m_create__java_lang_String("Java based lightweight UI library that in addition to performance and functionality brings elegance to enterprise web applications.").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLParagraphElement, Paragraph> */ style) =>{
      style.m_setColor__java_lang_String("#666").m_setMarginBottom__java_lang_String("30px");
    }))), Paragraph)).m_asElement__());
    this.m_initCards___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_quickInsight___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_initAuthors___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_initSponsors___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_initHelpAndSupport___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_initWhatOthersSay___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_initFollowUs___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
    this.m_initPoweredBy___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initPoweredBy___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("margin-top: 10px; margin-left: 13px;"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Powered by GWT")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "http://www.gwtproject.org/"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/home/gwt-logo.png").m_style__java_lang_String("width: 64px;")), IsElement))), HtmlContentBuilder)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFollowUs___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://twitter.com/dominokit"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/home/Twitter-Logo.png").m_style__java_lang_String("width: 64px;")), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://www.facebook.com/orgdomino"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/home/facebook_circle-512.png").m_style__java_lang_String("width: 50px;")), IsElement))), HtmlContentBuilder)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initHelpAndSupport___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("HELP & SUPPORT").m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_add__java_lang_String("classy-card");
    }))), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("We will help you learn domino-ui and will support you when use domino-ui through")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("If you need to asking a question ,troubleshoot an issue or fix a bug reach us at our gitter channel or open an issue at github ")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/DominoKit/domino-ui/issues"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {DominoElement<HTMLImageElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/home/github-circle.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_style__java_lang_String("width: 128px; display: inline-block; margin-right: 5px;"))).m_setTooltip__java_lang_String("Github Issues")), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://gitter.im/domino-gwt/domino-ui"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {DominoElement<HTMLImageElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/home/gitter.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_style__java_lang_String("width: 116px; display: inline-block;border-radius: 50%; margin-left: 5px;"))).m_setTooltip__java_lang_String("Gitter chat")), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("COMMERCIAL SERVICES"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Official Developer Support"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Need help troubleshooting or improving your code? Work directly with the engineers behind the Domino-ui.")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Or you want custom components or new features?")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://www.vertispan.com/services"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Get paid support"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_font_under_line__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {DominoElement<HTMLImageElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/vertispan.png").m_style__java_lang_String("width: 128px;"))).m_setTooltip__java_lang_String("Vertispan")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {DominoElement<HTMLImageElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/domino-logo-2.png").m_style__java_lang_String("width: 50px;"))).m_setTooltip__java_lang_String("Dominokit")), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initWhatOthersSay___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("WHAT OTHERS SAY").m_asElement__());
    this.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = /**@type {HSpinSelect<?string>} */ (HSpinSelect.m_create__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_add__java_lang_String("classy-card");
    }))), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {HSpinSelect<?string>} */ ($Casts.$to(/**@type {HSpinSelect<?string>} */ ($Casts.$to(/**@type {HSpinSelect<?string>} */ ($Casts.$to(this.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_appendChild__org_dominokit_domino_ui_spin_SpinItem(/**@type {SpinItem<?string>} */ (SpinItem.m_create__java_lang_Object__org_jboss_gwt_elemento_core_IsElement("", /**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://secure.gravatar.com/avatar/7ec73ac46e7215d35633a18d134f44e7").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, "person-pic", "quote-pic", Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Flavio Castro"), IsElement))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("After years working with GWT, Domino-ui came to the rescue, making the developers lives easier while providing a better and faster experience to the users.")), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Paragraph} */ ($Casts.$to(Paragraph.m_create__java_lang_String("- Tech Leader / Architect @ Ardan1").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLParagraphElement, Paragraph> */ style$1$) =>{
      style$1$.m_add__java_lang_String(Styles.f_font_12__org_dominokit_domino_ui_style_Styles).m_add__java_lang_String(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme.m_darker_3__().m_getStyle__());
    }))), Paragraph)).m_italic__())))), HSpinSelect)).m_appendChild__org_dominokit_domino_ui_spin_SpinItem(/**@type {SpinItem<?string>} */ (SpinItem.m_create__java_lang_Object__org_jboss_gwt_elemento_core_IsElement("", /**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/raul.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, "person-pic", "quote-pic", Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Ra\u00FAl Pampliega Mayoral"), IsElement))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("After trying out several ways to modernize our UI layer, Domino-ui make us really fast and it looks and feel amazing.")), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Paragraph} */ ($Casts.$to(Paragraph.m_create__java_lang_String("- Software Engineer @ Babcock MCS Spain").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLParagraphElement, Paragraph> */ style$2$) =>{
      style$2$.m_add__java_lang_String(Styles.f_font_12__org_dominokit_domino_ui_style_Styles).m_add__java_lang_String(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme.m_darker_3__().m_getStyle__());
    }))), Paragraph)).m_italic__())))), HSpinSelect)).m_appendChild__org_dominokit_domino_ui_spin_SpinItem(/**@type {SpinItem<?string>} */ (SpinItem.m_create__java_lang_Object__org_jboss_gwt_elemento_core_IsElement("", /**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/anas-zahran.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, "person-pic", "quote-pic", Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Anas Zahran"), IsElement))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Domino-ui can smoothly reduce the lines of code required to create a cross browser web application.")), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Paragraph} */ ($Casts.$to(Paragraph.m_create__java_lang_String("- Technologist @ Progressoft").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLParagraphElement, Paragraph> */ style$3$) =>{
      style$3$.m_add__java_lang_String(Styles.f_font_12__org_dominokit_domino_ui_style_Styles).m_add__java_lang_String(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme.m_darker_3__().m_getStyle__());
    }))), Paragraph)).m_italic__())))), HSpinSelect)).m_appendChild__org_dominokit_domino_ui_spin_SpinItem(/**@type {SpinItem<?string>} */ (SpinItem.m_create__java_lang_Object__org_jboss_gwt_elemento_core_IsElement("", /**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles], j_l_String))))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/saif-badran.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, "person-pic", "quote-pic", Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Saif Badran"), IsElement))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Domino-ui made it so simple. It's a real pleasure working on it, the way it generates professional, user-friendly interfaces is impressive!.")), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Paragraph} */ ($Casts.$to(Paragraph.m_create__java_lang_String("- Software Engineer @ Progressoft").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLParagraphElement, Paragraph> */ style$4$) =>{
      style$4$.m_add__java_lang_String(Styles.f_font_12__org_dominokit_domino_ui_style_Styles).m_add__java_lang_String(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme.m_darker_3__().m_getStyle__());
    }))), Paragraph)).m_italic__()))))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String)))).m_asElement__());
    this.f_timer__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = $1.$create__org_dominokit_domino_home_client_views_ui_HomeViewImpl(this);
    this.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_onNavigate__org_dominokit_domino_ui_spin_NavigationHandler(NavigationHandler.$adapt(((/** Direction */ direction) =>{
      if (this.f_timer__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_isRunning__()) {
        this.f_timer__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_cancel__();
        this.f_timer__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_scheduleRepeating__int(10000);
      }
    })));
    this.f_timer__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_scheduleRepeating__int(10000);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSponsors___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("SPONSORS").m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_add__java_lang_String("classy-card");
    }))), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span5__().m_offset1__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$1$) =>{
      style$1$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://www.vertispan.com/"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/vertispan.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span5__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$2$) =>{
      style$2$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://www.progressoft.com/"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/sponsors/ProgressSoft.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initAuthors___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("AUTHORS").m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_add__java_lang_String(Color.f_BLACK__org_dominokit_domino_ui_style_Color.m_getBackground__()).m_add__java_lang_String("classy-card");
    }))), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span5__().m_offset1__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$1$) =>{
      style$1$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/authors/Ahmad.Bawaneh.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, "person-pic"], j_l_String)))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Ahmad Bawaneh"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Java developer with 11 years experience in building enterprise web application, works on both frontend and backend, and is big fan of GWT")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://www.linkedin.com/in/ahmad-bawaneh"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/authors/linkedin.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/vegegoku"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/authors/github.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), IsElement))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span5__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$2$) =>{
      style$2$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/authors/Rafat.albarouki.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles, "person-pic"], j_l_String)))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Rafat Al-Barouki"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Java developer with 5 years experience in building enterprise web application, works on both frontend and backend, and is big fan of GWT")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://www.linkedin.com/in/rafat-al-barouki"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/authors/linkedin.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/rjeeb"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./images/authors/github.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))), IsElement))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initCards___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_add__java_lang_String("demo-nav-card");
    }))), Card)).m_setBodyPadding__java_lang_String("0px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["gs-background", "demo-getting-started"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("border-bottom:1px solid #dae7f8; background-image: linear-gradient(to left bottom, #d54b57, #a73763, #712f61, #3c264f, #111832);"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/home/rocket.png").m_style__java_lang_String("margin: auto; width: 200px;"), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("padding: 20px;"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("GETTING STARTED", "A guid to create and setup a new project")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column) =>{
      /**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(column.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$1$) =>{
        style$1$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
      }))), Column)).m_condenced__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$2$) =>{
        style$2$.m_setMarginTop__java_lang_String("20px");
      }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("GO").m_linkify__(), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style$3$) =>{
        style$3$.m_setMinWidth__java_lang_String("120px");
      }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
        window.window.open("https://github.com/DominoKit/domino-ui/wiki/Getting-started", "_blank");
      }))));
    })))), IsElement)))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style$4$) =>{
      style$4$.m_add__java_lang_String("demo-nav-card");
    }))), Card)).m_setBodyPadding__java_lang_String("0px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["gs-background", "demo-docs"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("border-bottom:1px solid #dae7f8; background-image: linear-gradient(to left bottom, #52b46b, #009a8d, #007a8e, #425a70, #414045);"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/home/documents.png").m_style__java_lang_String("margin: auto; width: 200px;"), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("padding: 20px;"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("DOCUMENTATION", "Detailed guid for every component.. coming soon")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$1$) =>{
      /**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(column$1$.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$5$) =>{
        style$5$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
      }))), Column)).m_condenced__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$6$) =>{
        style$6$.m_setMarginTop__java_lang_String("20px");
      }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("GO").m_linkify__(), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style$7$) =>{
        style$7$.m_setMinWidth__java_lang_String("120px");
      }))));
    })))), IsElement)))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style$8$) =>{
      style$8$.m_add__java_lang_String("demo-nav-card");
    }))), Card)).m_setBodyPadding__java_lang_String("0px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["gs-background", "demo-sample-apps"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("border-bottom:1px solid #dae7f8; background-image: linear-gradient(to left bottom, #dff5fe, #a8c2d1, #7492a6, #45637d, #183856);"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/home/apps-2.png").m_style__java_lang_String("margin: auto; width: 200px;"), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("padding: 20px;"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("SAMPLE APPS", "List of sample application built with domino-ui")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$2$) =>{
      /**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(column$2$.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$9$) =>{
        style$9$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
      }))), Column)).m_condenced__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$10$) =>{
        style$10$.m_setMarginTop__java_lang_String("20px");
      }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("GO").m_linkify__(), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style$11$) =>{
        style$11$.m_setMinWidth__java_lang_String("120px");
      }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
        let history = /**@type {AppHistory} */ (Js.m_uncheckedCast__java_lang_Object(ClientApp.m_make__().m_getHistory__()));
        let samples = history.m_currentToken__().m_replaceLastFragment__java_lang_String("samples");
        history.m_pushState__java_lang_String(samples.m_value__());
        history.m_fireCurrentStateHistory__();
      }))));
    })))), IsElement)))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style$12$) =>{
      style$12$.m_add__java_lang_String("demo-nav-card");
    }))), Card)).m_setBodyPadding__java_lang_String("0px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["gs-background", "demo-github"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("border-bottom:1px solid #dae7f8;     background-image: linear-gradient(to left bottom, #f4cab1, #bc9a8c, #856d67, #504442, #201f1f);"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/home/github.png").m_style__java_lang_String("margin: auto; height: 200px;"), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("padding: 20px;"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("GITHUB PROJECT", "Our project at github")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$3$) =>{
      /**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(column$3$.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$13$) =>{
        style$13$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
      }))), Column)).m_condenced__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$14$) =>{
        style$14$.m_setMarginTop__java_lang_String("20px");
      }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("GO").m_linkify__(), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style$15$) =>{
        style$15$.m_setMinWidth__java_lang_String("120px");
      }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
        window.window.open("https://github.com/DominoKit/domino-ui", "_blank");
      }))));
    })))), IsElement)))), Column)))), HtmlContentBuilder)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_quickInsight___$p_org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("QUICK INSIGHT").m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["home-sections", "gs-background", "demo-docs"], j_l_String)));
    }))), Card)).m_setBodyPadding__java_lang_String("0px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["home-section"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["slide-1"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/insight/domino-ui-slide-1.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Type safe")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Domino-ui is Java based compiled to JavaScript, which means during development of the application you have the power to refactor and keep your app maintainable all the time, but also you develop your application with the mature set of all tool chain java can provide, this include extremely powerful IDEs and mature build tools like maven and gradle, use domino-ui and bring your java team to the frontend world.")), Column)))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["breaker"], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["home-section"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["slide-2"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["odd"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Elegant")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Domino-ui cares about performance and functionality, but also cares about elegance, enterprise applications could be rich and crowded but when you use domino-ui rich components you will also have neat smooth friendly screens, with proper spacing, consistent color palette and just the right amount of effects and animations you bring the users of the application to love it.")), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/insight/domino-ui-slide-2.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), Column)))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["breaker"], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["home-section"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["slide-3"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/insight/domino-ui-slide-3.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Rich data table")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Almost every enterprise application uses data tables, domino-ui realise this fact and provides a rich, functional and elegant data table which is extendable with a rich set of ready to use plugins like selection plugin, marker plugin, record details plugin, search plugin and more, but this is not limited since the user can write his own plugins, and even better we are continuously adding more plugins.")), Column)))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["breaker"], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["home-section"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["slide-4"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["odd"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Rich Forms")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Having rich interactive forms is essential for enterprise applications, domino-ui has a rich set of form controls that enables the developer to easily implement both simple and complex form, with the smooth easy to use API making the forms interactive is an easy task, validating user input is a simple call, and of course with a proper data binding mechanism to read and fill form from data objects.")), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/insight/domino-ui-slide-4.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), Column)))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["breaker"], j_l_String)))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["home-section"], j_l_String))), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["slide-5"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/insight/domino-ui-slide-5.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Typography & Font icons")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Icons and Typography can enhance the user experience of the application, domino-ui has a very good of font icons that can bring forms and other elements in the page into life, and this not only applies for enterprise applications but also for simple application like blogs, in domino-ui creating typography elements is very easy and stylish.")), Column)))), IsElement))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_direction__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = 1;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HomeViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HomeViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HomeViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    $1 = goog.module.get('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$1$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$3$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    HSpinSelect = goog.module.get('org.dominokit.domino.ui.spin.HSpinSelect$impl');
    NavigationHandler = goog.module.get('org.dominokit.domino.ui.spin.NavigationHandler$impl');
    SpinItem = goog.module.get('org.dominokit.domino.ui.spin.SpinItem$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HomeViewImpl, $Util.$makeClassName('org.dominokit.domino.home.client.views.ui.HomeViewImpl'));


HomeView.$markImplementor(HomeViewImpl);


exports = HomeViewImpl; 
//# sourceMappingURL=HomeViewImpl.js.map