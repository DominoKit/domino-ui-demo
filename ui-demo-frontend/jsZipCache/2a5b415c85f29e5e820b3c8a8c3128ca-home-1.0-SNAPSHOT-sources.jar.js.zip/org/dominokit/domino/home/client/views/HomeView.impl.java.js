/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.views.HomeView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.home.client.views.HomeView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.home.client.views.HomeView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class HomeView {
  /**
   * @param {?function():Content} fn
   * @return {HomeView}
   * @public
   */
  static $adapt(fn) {
    HomeView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_home_client_views_HomeView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_home_client_views_HomeView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_home_client_views_HomeView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HomeView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.home.client.views.HomeView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HomeView, $Util.$makeClassName('org.dominokit.domino.home.client.views.HomeView'));


HomeView.$markImplementor(/** @type {Function} */ (HomeView));


exports = HomeView; 
//# sourceMappingURL=HomeView.js.map