/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.views.ui.HomeViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.home.client.views.ui.HomeViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _HomeView = goog.require('org.dominokit.domino.home.client.views.HomeView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _HTMLImageElement_$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _HTMLParagraphElement_$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Consumer = goog.require('java.util.function.Consumer');
const _Js = goog.require('jsinterop.base.Js');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _AppHistory = goog.require('org.dominokit.domino.api.shared.history.AppHistory');
const _$1 = goog.require('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$1');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$LambdaAdaptor$3');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Direction = goog.require('org.dominokit.domino.ui.spin.Direction');
const _HSpinSelect = goog.require('org.dominokit.domino.ui.spin.HSpinSelect');
const _NavigationHandler = goog.require('org.dominokit.domino.ui.spin.NavigationHandler');
const _SpinItem = goog.require('org.dominokit.domino.ui.spin.SpinItem');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Timer = goog.require('org.gwtproject.timer.client.Timer');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _EmptyContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var HomeViewImpl = goog.require('org.dominokit.domino.home.client.views.ui.HomeViewImpl$impl');
exports = HomeViewImpl;
 