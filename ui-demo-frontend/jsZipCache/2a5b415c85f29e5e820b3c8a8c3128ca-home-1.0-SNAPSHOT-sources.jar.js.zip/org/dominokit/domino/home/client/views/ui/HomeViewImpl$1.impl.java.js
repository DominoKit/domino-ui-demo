/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.views.ui.HomeViewImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.home.client.views.ui.HomeViewImpl.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Timer = goog.require('org.gwtproject.timer.client.Timer$impl');

let HomeViewImpl = goog.forwardDeclare('org.dominokit.domino.home.client.views.ui.HomeViewImpl$impl');


class $1 extends Timer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HomeViewImpl} */
    this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new Timer(HomeViewImpl)'.
   * @param {HomeViewImpl} $outer_this
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_home_client_views_ui_HomeViewImpl($outer_this) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1__org_dominokit_domino_home_client_views_ui_HomeViewImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new Timer(HomeViewImpl)'.
   * @param {HomeViewImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1__org_dominokit_domino_home_client_views_ui_HomeViewImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1 = $outer_this;
    this.$ctor__org_gwtproject_timer_client_Timer__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_run__() {
    let activeItem = this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_getActiveItem__();
    if (this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_isLastItem__org_dominokit_domino_ui_spin_SpinItem(activeItem)) {
      this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_direction__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = 2;
    } else if (this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_isFirstItem__org_dominokit_domino_ui_spin_SpinItem(activeItem)) {
      this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_direction__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = 1;
    }
    if (this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_direction__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ == 1) {
      this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_moveForward__();
    } else {
      this.f_$outer_this__org_dominokit_domino_home_client_views_ui_HomeViewImpl_1.f_spinSelect__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.m_moveBack__();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    Timer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.home.client.views.ui.HomeViewImpl$1'));




exports = $1; 
//# sourceMappingURL=HomeViewImpl$1.js.map