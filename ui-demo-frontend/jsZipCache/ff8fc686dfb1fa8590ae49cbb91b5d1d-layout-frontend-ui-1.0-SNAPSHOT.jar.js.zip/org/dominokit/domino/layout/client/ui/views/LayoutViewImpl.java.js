/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _LayoutView = goog.require('org.dominokit.domino.layout.client.views.LayoutView');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _Js = goog.require('jsinterop.base.Js');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$1');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _SelectionHandler = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Layout = goog.require('org.dominokit.domino.ui.layout.Layout');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var LayoutViewImpl = goog.require('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl$impl');
exports = LayoutViewImpl;
 