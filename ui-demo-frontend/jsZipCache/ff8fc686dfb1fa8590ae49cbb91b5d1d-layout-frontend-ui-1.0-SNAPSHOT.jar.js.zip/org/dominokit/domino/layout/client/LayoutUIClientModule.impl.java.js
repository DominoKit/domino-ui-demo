/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.LayoutUIClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.LayoutUIClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class LayoutUIClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutUIClientModule()'.
   * @return {!LayoutUIClientModule}
   * @public
   */
  static $create__() {
    LayoutUIClientModule.$clinit();
    let $instance = new LayoutUIClientModule();
    $instance.$ctor__org_dominokit_domino_layout_client_LayoutUIClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutUIClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_LayoutUIClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    LayoutUIClientModule.$f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_.m_info__java_lang_String("Initializing Layout frontend UI module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_() {
    return (LayoutUIClientModule.$clinit(), LayoutUIClientModule.$f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_(value) {
    (LayoutUIClientModule.$clinit(), LayoutUIClientModule.$f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutUIClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutUIClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutUIClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    LayoutUIClientModule.$f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LayoutUIClientModule));
  }
  
  
};

$Util.$setClassMetadata(LayoutUIClientModule, $Util.$makeClassName('org.dominokit.domino.layout.client.LayoutUIClientModule'));


/** @private {Logger} */
LayoutUIClientModule.$f_LOGGER__org_dominokit_domino_layout_client_LayoutUIClientModule_;




exports = LayoutUIClientModule; 
//# sourceMappingURL=LayoutUIClientModule.js.map