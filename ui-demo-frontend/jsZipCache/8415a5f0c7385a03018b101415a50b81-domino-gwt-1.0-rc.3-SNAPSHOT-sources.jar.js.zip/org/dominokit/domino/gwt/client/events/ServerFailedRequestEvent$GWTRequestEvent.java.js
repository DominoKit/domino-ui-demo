/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$GWTRequestEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.GWTRequestEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestEvent = goog.require('org.dominokit.domino.api.client.events.EventsBus.RequestEvent');
const _ServerFailedRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent');
const _ServerFailedRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent');


// Re-exports the implementation.
var GWTRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.GWTRequestEvent$impl');
exports = GWTRequestEvent;
 