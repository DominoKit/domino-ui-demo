/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.Cookies.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.request.Cookies$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Exception = goog.forwardDeclare('java.lang.Exception$impl');
let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $LongUtils = goog.forwardDeclare('vmbootstrap.LongUtils$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


class Cookies extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @param {?string} name
   * @return {?string}
   * @public
   */
  static m_getCookie__java_lang_String(name) {
    Cookies.$clinit();
    let cookiesMap = Cookies.m_ensureCookies___$p_org_dominokit_domino_gwt_client_request_Cookies();
    return /**@type {?string} */ ($Casts.$to(cookiesMap.get(name), j_l_String));
  }
  
  /**
   * @return {Collection<?string>}
   * @public
   */
  static m_getCookieNames__() {
    Cookies.$clinit();
    return Cookies.m_ensureCookies___$p_org_dominokit_domino_gwt_client_request_Cookies().keySet();
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static m_getUriEncode__() {
    Cookies.$clinit();
    return Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static m_isCookieEnabled__() {
    Cookies.$clinit();
    if (!Cookies.$f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_) {
      Cookies.$f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_ = true;
      Cookies.m_setCookie__java_lang_String__java_lang_String("__gwtCookieCheck", "isEnabled");
      Cookies.$f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_ = j_l_String.m_equals__java_lang_String__java_lang_Object("isEnabled", Cookies.m_getCookie__java_lang_String("__gwtCookieCheck"));
      Cookies.m_removeCookie__java_lang_String("__gwtCookieCheck");
    }
    return Cookies.$f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  static m_removeCookie__java_lang_String(name) {
    Cookies.$clinit();
    if (Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
      name = Cookies.m_uriEncode__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name);
    }
    Cookies.m_removeCookieNative__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name);
  }
  
  /**
   * @param {?string} name
   * @param {?string} path
   * @return {void}
   * @public
   */
  static m_removeCookie__java_lang_String__java_lang_String(name, path) {
    Cookies.$clinit();
    if (Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
      name = Cookies.m_uriEncode__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name);
    }
    Cookies.m_removeCookieNative__java_lang_String__java_lang_String(name, path);
  }
  
  /**
   * @param {?string} name
   * @param {?string} path
   * @return {void}
   * @public
   */
  static m_removeCookieNative__java_lang_String__java_lang_String(name, path) {
    Cookies.$clinit();
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.cookie = j_l_String.m_valueOf__java_lang_Object(name) + "=;path=" + j_l_String.m_valueOf__java_lang_Object(path) + ";expires=Fri, 02-Jan-1970 00:00:00 GMT";
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @return {void}
   * @public
   */
  static m_setCookie__java_lang_String__java_lang_String(name, value) {
    Cookies.$clinit();
    Cookies.m_setCookie__java_lang_String__java_lang_String__java_util_Date__java_lang_String__java_lang_String__boolean(name, value, null, null, null, false);
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @param {Date} expires
   * @return {void}
   * @public
   */
  static m_setCookie__java_lang_String__java_lang_String__java_util_Date(name, value, expires) {
    Cookies.$clinit();
    Cookies.m_setCookie__java_lang_String__java_lang_String__java_util_Date__java_lang_String__java_lang_String__boolean(name, value, expires, null, null, false);
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @param {Date} expires
   * @param {?string} domain
   * @param {?string} path
   * @param {boolean} secure
   * @return {void}
   * @public
   */
  static m_setCookie__java_lang_String__java_lang_String__java_util_Date__java_lang_String__java_lang_String__boolean(name, value, expires, domain, path, secure) {
    Cookies.$clinit();
    if (Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
      name = Cookies.m_uriEncode__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name);
      value = Cookies.m_uriEncode__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(value);
    } else if (!Cookies.m_isValidCookieName__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("Illegal cookie format: " + j_l_String.m_valueOf__java_lang_Object(name) + " is not a valid cookie name."));
    } else if (!Cookies.m_isValidCookieValue__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(value)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("Illegal cookie format: " + j_l_String.m_valueOf__java_lang_Object(value) + " is not a valid cookie value."));
    }
    Cookies.m_setCookieImpl__java_lang_String__java_lang_String__long__java_lang_String__java_lang_String__boolean_$p_org_dominokit_domino_gwt_client_request_Cookies(name, value, $Equality.$same(expires, null) ? $Long.fromInt(0) : expires.m_getTime__(), domain, path, secure);
  }
  
  /**
   * @param {boolean} encode
   * @return {void}
   * @public
   */
  static m_setUriEncode__boolean(encode) {
    Cookies.$clinit();
    if (encode != Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
      Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_ = encode;
      Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies = null;
    }
  }
  
  /**
   * @param {HashMap<?string, ?string>} map
   * @return {void}
   * @public
   */
  static m_loadCookies__java_util_HashMap_$pp_org_dominokit_domino_gwt_client_request(map) {
    Cookies.$clinit();
    let docCookie = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.cookie;
    if (Objects.m_nonNull__java_lang_Object(docCookie) && !j_l_String.m_isEmpty__java_lang_String(docCookie)) {
      let crumbs = j_l_String.m_split__java_lang_String__java_lang_String(docCookie, "; ");
      for (let i = crumbs.length - 1; i >= 0; --i) {
        let /** ?string */ name, /** ?string */ value;
        let eqIdx = j_l_String.m_indexOf__java_lang_String__int(crumbs[i], 61 /* '=' */);
        if (eqIdx == -1) {
          name = crumbs[i];
          value = "";
        } else {
          name = j_l_String.m_substring__java_lang_String__int__int(crumbs[i], 0, eqIdx);
          value = j_l_String.m_substring__java_lang_String__int(crumbs[i], eqIdx + 1);
        }
        if (Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
          try {
            name = window.decodeURIComponent(name);
          } catch (__$exc) {
            __$exc = $Exceptions.toJava(__$exc);
            if (Exception.$isInstance(__$exc)) {
              let e = /**@type {Exception} */ (__$exc);
            } else {
              throw $Exceptions.toJs(__$exc);
            }
          }
          try {
            value = window.decodeURIComponent(value);
          } catch (__$exc$1$) {
            __$exc$1$ = $Exceptions.toJava(__$exc$1$);
            if (Exception.$isInstance(__$exc$1$)) {
              let e$1$ = /**@type {Exception} */ (__$exc$1$);
            } else {
              throw $Exceptions.toJs(__$exc$1$);
            }
          }
        }
        map.put(name, value);
      }
    }
  }
  
  /**
   * @return {HashMap<?string, ?string>}
   * @public
   */
  static m_ensureCookies___$p_org_dominokit_domino_gwt_client_request_Cookies() {
    Cookies.$clinit();
    if ($Equality.$same(Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies, null) || Cookies.m_needsRefresh___$p_org_dominokit_domino_gwt_client_request_Cookies()) {
      let newCachedCookies = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
      Cookies.m_loadCookies__java_util_HashMap_$pp_org_dominokit_domino_gwt_client_request(newCachedCookies);
      Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies = newCachedCookies;
    }
    return Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies;
  }
  
  /**
   * @param {?string} name
   * @return {boolean}
   * @public
   */
  static m_isValidCookieName__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name) {
    Cookies.$clinit();
    if (Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
      return true;
    } else if (j_l_String.m_contains__java_lang_String__java_lang_CharSequence(name, "=") || j_l_String.m_contains__java_lang_String__java_lang_CharSequence(name, ";") || j_l_String.m_contains__java_lang_String__java_lang_CharSequence(name, ",") || j_l_String.m_startsWith__java_lang_String__java_lang_String(name, "$") || j_l_String.m_matches__java_lang_String__java_lang_String(name, ".*\\s+.*")) {
      return false;
    } else {
      return true;
    }
  }
  
  /**
   * @param {?string} value
   * @return {boolean}
   * @public
   */
  static m_isValidCookieValue__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(value) {
    Cookies.$clinit();
    if (Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_) {
      return true;
    }
    if (j_l_String.m_contains__java_lang_String__java_lang_CharSequence(value, "=") || j_l_String.m_contains__java_lang_String__java_lang_CharSequence(value, ";")) {
      return false;
    } else {
      return true;
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static m_needsRefresh___$p_org_dominokit_domino_gwt_client_request_Cookies() {
    Cookies.$clinit();
    let docCookie = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.cookie;
    if (!j_l_String.m_equals__java_lang_String__java_lang_Object(docCookie, Cookies.$f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies)) {
      Cookies.$f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies = docCookie;
      return true;
    } else {
      return false;
    }
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  static m_removeCookieNative__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(name) {
    Cookies.$clinit();
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.cookie = j_l_String.m_valueOf__java_lang_Object(name) + "=;expires=Fri, 02-Jan-1970 00:00:00 GMT";
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @param {!$Long} expires
   * @param {?string} domain
   * @param {?string} path
   * @param {boolean} secure
   * @return {void}
   * @public
   */
  static m_setCookieImpl__java_lang_String__java_lang_String__long__java_lang_String__java_lang_String__boolean_$p_org_dominokit_domino_gwt_client_request_Cookies(name, value, expires, domain, path, secure) {
    Cookies.$clinit();
    let c = j_l_String.m_valueOf__java_lang_Object(name) + "=" + j_l_String.m_valueOf__java_lang_Object(value);
    if ($LongUtils.$greater(expires, $Primitives.$widenIntToLong(0))) {
      c = j_l_String.m_valueOf__java_lang_Object(c) + j_l_String.m_valueOf__java_lang_Object((";expires=" + j_l_String.m_valueOf__java_lang_Object(Date.$create__long(expires).m_toGMTString__())));
    }
    if (Objects.m_nonNull__java_lang_Object(domain) && !j_l_String.m_isEmpty__java_lang_String(domain)) {
      c = j_l_String.m_valueOf__java_lang_Object(c) + j_l_String.m_valueOf__java_lang_Object((";domain=" + j_l_String.m_valueOf__java_lang_Object(domain)));
    }
    if (Objects.m_nonNull__java_lang_Object(path) && !j_l_String.m_isEmpty__java_lang_String(path)) {
      c = j_l_String.m_valueOf__java_lang_Object(c) + j_l_String.m_valueOf__java_lang_Object((";path=" + j_l_String.m_valueOf__java_lang_Object(path)));
    }
    if (secure) {
      c = j_l_String.m_valueOf__java_lang_Object(c) + j_l_String.m_valueOf__java_lang_Object(";secure");
    }
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.cookie = c;
  }
  
  /**
   * @param {?string} s
   * @return {?string}
   * @public
   */
  static m_uriEncode__java_lang_String_$p_org_dominokit_domino_gwt_client_request_Cookies(s) {
    Cookies.$clinit();
    return window.encodeURIComponent(s);
  }
  
  /**
   * Factory method corresponding to constructor 'Cookies()'.
   * @return {!Cookies}
   * @public
   */
  static $create__() {
    Cookies.$clinit();
    let $instance = new Cookies();
    $instance.$ctor__org_dominokit_domino_gwt_client_request_Cookies__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Cookies()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_request_Cookies__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {HashMap<?string, ?string>}
   * @public
   */
  static get f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies() {
    return (Cookies.$clinit(), Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies);
  }
  
  /**
   * @param {HashMap<?string, ?string>} value
   * @return {void}
   * @public
   */
  static set f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies(value) {
    (Cookies.$clinit(), Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies = value);
  }
  
  /**
   * @return {?string}
   * @public
   */
  static get f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies() {
    return (Cookies.$clinit(), Cookies.$f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies);
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  static set f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies(value) {
    (Cookies.$clinit(), Cookies.$f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies = value);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static get f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_() {
    return (Cookies.$clinit(), Cookies.$f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_);
  }
  
  /**
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static set f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_(value) {
    (Cookies.$clinit(), Cookies.$f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_ = value);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static get f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_() {
    return (Cookies.$clinit(), Cookies.$f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_);
  }
  
  /**
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static set f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_(value) {
    (Cookies.$clinit(), Cookies.$f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_ = value);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static get f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_() {
    return (Cookies.$clinit(), Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_);
  }
  
  /**
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static set f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_(value) {
    (Cookies.$clinit(), Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Cookies;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Cookies);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Cookies.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Exception = goog.module.get('java.lang.Exception$impl');
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Date = goog.module.get('java.util.Date$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Long = goog.module.get('nativebootstrap.Long$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $LongUtils = goog.module.get('vmbootstrap.LongUtils$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    j_l_Object.$clinit();
    Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies = null;
    Cookies.$f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_ = false;
    Cookies.$f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_ = false;
    Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_ = true;
  }
  
  
};

$Util.$setClassMetadata(Cookies, $Util.$makeClassName('org.dominokit.domino.gwt.client.request.Cookies'));


/** @private {HashMap<?string, ?string>} */
Cookies.$f_cachedCookies__org_dominokit_domino_gwt_client_request_Cookies;


/** @private {?string} */
Cookies.$f_rawCookies__org_dominokit_domino_gwt_client_request_Cookies;


/** @private {boolean} */
Cookies.$f_isCookieEnabled__org_dominokit_domino_gwt_client_request_Cookies_ = false;


/** @private {boolean} */
Cookies.$f_isCookieChecked__org_dominokit_domino_gwt_client_request_Cookies_ = false;


/** @private {boolean} */
Cookies.$f_uriEncoding__org_dominokit_domino_gwt_client_request_Cookies_ = false;




exports = Cookies; 
//# sourceMappingURL=Cookies.js.map