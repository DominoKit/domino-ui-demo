/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.app.CoreModule.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.app.CoreModule');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ClientAppBuilder = goog.require('org.dominokit.domino.api.client.ClientApp.ClientAppBuilder');
const _CoreMainExtensionPoint = goog.require('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint');
const _InMemoryDominoEventsListenerRepository = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository');
const _InMemoryPresentersRepository = goog.require('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository');
const _InMemoryViewRepository = goog.require('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository');
const _ClientRouter = goog.require('org.dominokit.domino.client.commons.request.ClientRouter');
const _InMemoryCommandsRepository = goog.require('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository');
const _InMemoryRequestRestSendersRepository = goog.require('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository');
const _ServerRouter = goog.require('org.dominokit.domino.client.commons.request.ServerRouter');
const _GwtAsyncRunner = goog.require('org.dominokit.domino.gwt.client.async.GwtAsyncRunner');
const _ClientEventFactory = goog.require('org.dominokit.domino.gwt.client.events.ClientEventFactory');
const _RequestEventProcessor = goog.require('org.dominokit.domino.gwt.client.events.RequestEventProcessor');
const _ServerEventFactory = goog.require('org.dominokit.domino.gwt.client.events.ServerEventFactory');
const _SimpleEventsBus = goog.require('org.dominokit.domino.gwt.client.events.SimpleEventsBus');
const _StateHistory = goog.require('org.dominokit.domino.gwt.client.history.StateHistory');
const _DefaultDominoOptions = goog.require('org.dominokit.domino.gwt.client.options.DefaultDominoOptions');
const _GwtRequestAsyncSender = goog.require('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender');


// Re-exports the implementation.
var CoreModule = goog.require('org.dominokit.domino.gwt.client.app.CoreModule$impl');
exports = CoreModule;
 