/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.options.DefaultDominoOptions.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.options.DefaultDominoOptions');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _CanSetDominoOptions = goog.require('org.dominokit.domino.api.client.CanSetDominoOptions');
const _DynamicServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot');


// Re-exports the implementation.
var DefaultDominoOptions = goog.require('org.dominokit.domino.gwt.client.options.DefaultDominoOptions$impl');
exports = DefaultDominoOptions;
 