/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory$DominoHistoryState.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory.DominoHistoryState$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');

let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');
let StateHistoryToken = goog.forwardDeclare('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
let StateHistory = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory$impl');


/**
 * @implements {State}
  */
class DominoHistoryState extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {StateHistory} */
    this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState;
    /** @public {HistoryToken} */
    this.f_token__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_;
    /** @public {?string} */
    this.f_data__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_;
    /** @public {?string} */
    this.f_title__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_;
  }
  
  /**
   * Factory method corresponding to constructor 'DominoHistoryState(StateHistory, String, String, String)'.
   * @param {StateHistory} $outer_this
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {!DominoHistoryState}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String($outer_this, token, title, data) {
    DominoHistoryState.$clinit();
    let $instance = new DominoHistoryState();
    $instance.$ctor__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String($outer_this, token, title, data);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DominoHistoryState(StateHistory, String, String, String)'.
   * @param {StateHistory} $outer_this
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String($outer_this, token, title, data) {
    this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_token__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_ = StateHistoryToken.$create__java_lang_String(token);
    this.f_data__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_ = data;
    this.f_title__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_ = title;
  }
  
  /**
   * @override
   * @return {HistoryToken}
   * @public
   */
  m_token__() {
    return this.f_token__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_data__() {
    return this.f_data__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_title__() {
    return this.f_title__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DominoHistoryState;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DominoHistoryState);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoHistoryState.$clinit = function() {};
    StateHistoryToken = goog.module.get('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DominoHistoryState, $Util.$makeClassName('org.dominokit.domino.gwt.client.history.StateHistory$DominoHistoryState'));


State.$markImplementor(DominoHistoryState);


exports = DominoHistoryState; 
//# sourceMappingURL=StateHistory$DominoHistoryState.js.map