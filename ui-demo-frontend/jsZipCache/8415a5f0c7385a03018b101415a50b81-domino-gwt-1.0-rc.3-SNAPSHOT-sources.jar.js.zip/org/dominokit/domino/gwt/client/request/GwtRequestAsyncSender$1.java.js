/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ServerRequestCallBack = goog.require('org.dominokit.domino.api.client.request.ServerRequestCallBack');
const _Throwable = goog.require('java.lang.Throwable');
const _ServerRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ServerRequestEventFactory');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');
const _GwtRequestAsyncSender = goog.require('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.$1$impl');
exports = $1;
 