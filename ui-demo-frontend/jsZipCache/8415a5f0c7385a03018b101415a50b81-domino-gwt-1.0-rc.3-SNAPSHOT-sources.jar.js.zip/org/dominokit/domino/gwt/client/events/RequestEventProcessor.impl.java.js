/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.RequestEventProcessor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.RequestEventProcessor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const GwtEventProcessor = goog.require('org.dominokit.domino.gwt.client.events.GwtEventProcessor$impl');

let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');


/**
 * @implements {GwtEventProcessor}
  */
class RequestEventProcessor extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'RequestEventProcessor()'.
   * @return {!RequestEventProcessor}
   * @public
   */
  static $create__() {
    RequestEventProcessor.$clinit();
    let $instance = new RequestEventProcessor();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_RequestEventProcessor__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RequestEventProcessor()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_RequestEventProcessor__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {Event} event
   * @return {void}
   * @public
   */
  m_process__org_dominokit_domino_api_client_events_Event(event) {
    event.m_process__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RequestEventProcessor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RequestEventProcessor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestEventProcessor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(RequestEventProcessor, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.RequestEventProcessor'));


GwtEventProcessor.$markImplementor(RequestEventProcessor);


exports = RequestEventProcessor; 
//# sourceMappingURL=RequestEventProcessor.js.map