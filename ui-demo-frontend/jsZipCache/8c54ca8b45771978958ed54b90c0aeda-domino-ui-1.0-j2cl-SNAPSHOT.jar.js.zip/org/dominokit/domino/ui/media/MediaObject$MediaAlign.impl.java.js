/**
 * @fileoverview transpiled from org.dominokit.domino.ui.media.MediaObject$MediaAlign.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.media.MediaObject.MediaAlign$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<MediaAlign>}
  */
class MediaAlign extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_media_MediaObject_MediaAlign_;
  }
  
  /**
   * Factory method corresponding to constructor 'MediaAlign(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!MediaAlign}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new MediaAlign();
    $instance.$ctor__org_dominokit_domino_ui_media_MediaObject_MediaAlign__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaAlign(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_media_MediaObject_MediaAlign__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_media_MediaObject_MediaAlign_ = style;
  }
  
  /**
   * @param {string} name
   * @return {!MediaAlign}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    MediaAlign.$clinit();
    if ($Equality.$same(MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_, null)) {
      MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_ = $Enums.createMapFromValues(MediaAlign.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_);
  }
  
  /**
   * @return {!Array<!MediaAlign>}
   * @public
   */
  static m_values__() {
    MediaAlign.$clinit();
    return /**@type {!Array<MediaAlign>} */ ($Arrays.$init([MediaAlign.$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign, MediaAlign.$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign, MediaAlign.$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign], MediaAlign));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {MediaAlign} */ ($Casts.$to(arg0, MediaAlign)));
  }
  
  /**
   * @return {!MediaAlign}
   * @public
   */
  static get f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign() {
    return (MediaAlign.$clinit(), MediaAlign.$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign);
  }
  
  /**
   * @param {!MediaAlign} value
   * @return {void}
   * @public
   */
  static set f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign(value) {
    (MediaAlign.$clinit(), MediaAlign.$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign = value);
  }
  
  /**
   * @return {!MediaAlign}
   * @public
   */
  static get f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign() {
    return (MediaAlign.$clinit(), MediaAlign.$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign);
  }
  
  /**
   * @param {!MediaAlign} value
   * @return {void}
   * @public
   */
  static set f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign(value) {
    (MediaAlign.$clinit(), MediaAlign.$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign = value);
  }
  
  /**
   * @return {!MediaAlign}
   * @public
   */
  static get f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign() {
    return (MediaAlign.$clinit(), MediaAlign.$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign);
  }
  
  /**
   * @param {!MediaAlign} value
   * @return {void}
   * @public
   */
  static set f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign(value) {
    (MediaAlign.$clinit(), MediaAlign.$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign = value);
  }
  
  /**
   * @return {Map<?string, !MediaAlign>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_() {
    return (MediaAlign.$clinit(), MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_);
  }
  
  /**
   * @param {Map<?string, !MediaAlign>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_(value) {
    (MediaAlign.$clinit(), MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaAlign;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaAlign);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaAlign.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    MediaAlign.$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign = MediaAlign.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("MIDDLE"), MediaAlign.$ordinal$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign, "media-middle");
    MediaAlign.$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign = MediaAlign.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("BOTTOM"), MediaAlign.$ordinal$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign, "media-bottom");
    MediaAlign.$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign = MediaAlign.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("TOP"), MediaAlign.$ordinal$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign, "media-top");
    MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(MediaAlign, $Util.$makeClassName('org.dominokit.domino.ui.media.MediaObject$MediaAlign'));


/** @private {!MediaAlign} */
MediaAlign.$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign;


/** @private {!MediaAlign} */
MediaAlign.$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign;


/** @private {!MediaAlign} */
MediaAlign.$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign;


/** @private {Map<?string, !MediaAlign>} */
MediaAlign.$f_namesToValuesMap__org_dominokit_domino_ui_media_MediaObject_MediaAlign_;


/** @public {number} @const */
MediaAlign.$ordinal$f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign = 0;


/** @public {number} @const */
MediaAlign.$ordinal$f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign = 1;


/** @public {number} @const */
MediaAlign.$ordinal$f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign = 2;




exports = MediaAlign; 
//# sourceMappingURL=MediaObject$MediaAlign.js.map