/**
 * @fileoverview transpiled from org.dominokit.domino.ui.media.MediaObject.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.media.MediaObject$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let MediaAlign = goog.forwardDeclare('org.dominokit.domino.ui.media.MediaObject.MediaAlign$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class MediaObject extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLHeadingElement} */
    this.f_mediaHeader__org_dominokit_domino_ui_media_MediaObject_;
    /** @public {HTMLDivElement} */
    this.f_mediaBody__org_dominokit_domino_ui_media_MediaObject_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_media_MediaObject_;
    /** @public {HTMLDivElement} */
    this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_;
    /** @public {HTMLDivElement} */
    this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_;
    /** @public {MediaAlign} */
    this.f_leftAlign__org_dominokit_domino_ui_media_MediaObject_;
    /** @public {MediaAlign} */
    this.f_rightAlign__org_dominokit_domino_ui_media_MediaObject_;
  }
  
  /**
   * Factory method corresponding to constructor 'MediaObject()'.
   * @return {!MediaObject}
   * @public
   */
  static $create__() {
    MediaObject.$clinit();
    let $instance = new MediaObject();
    $instance.$ctor__org_dominokit_domino_ui_media_MediaObject__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaObject()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_media_MediaObject__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_media_MediaObject();
  }
  
  /**
   * @return {MediaObject}
   * @public
   */
  static m_create__() {
    MediaObject.$clinit();
    return MediaObject.$create__();
  }
  
  /**
   * @param {?string} header
   * @return {MediaObject}
   * @public
   */
  m_setHeader__java_lang_String(header) {
    this.f_mediaHeader__org_dominokit_domino_ui_media_MediaObject_.textContent = header;
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {MediaObject}
   * @public
   */
  m_setLeftMedia__elemental2_dom_Node(content) {
    if (Objects.m_isNull__java_lang_Object(this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_)) {
      this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["media-left"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
      this.m_asElement__().insertBefore(this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_, this.f_mediaBody__org_dominokit_domino_ui_media_MediaObject_);
    }
    ElementUtil.m_clear__elemental2_dom_Element(this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_);
    this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_.appendChild(content);
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {MediaObject}
   * @public
   */
  m_setRightMedia__elemental2_dom_Node(content) {
    if (Objects.m_isNull__java_lang_Object(this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_)) {
      this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["media-right"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
      this.m_asElement__().appendChild(this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_);
    }
    ElementUtil.m_clear__elemental2_dom_Element(this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_);
    this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_.appendChild(content);
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {MediaObject}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.f_mediaBody__org_dominokit_domino_ui_media_MediaObject_.appendChild(content);
    return this;
  }
  
  /**
   * @param {MediaAlign} align
   * @return {MediaObject}
   * @public
   */
  m_alignLeftMedia__org_dominokit_domino_ui_media_MediaObject_MediaAlign(align) {
    if (Objects.m_nonNull__java_lang_Object(this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_)) {
      this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_.classList.remove(this.f_leftAlign__org_dominokit_domino_ui_media_MediaObject_.f_style__org_dominokit_domino_ui_media_MediaObject_MediaAlign_);
      this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_.classList.add(align.f_style__org_dominokit_domino_ui_media_MediaObject_MediaAlign_);
      this.f_leftAlign__org_dominokit_domino_ui_media_MediaObject_ = align;
    }
    return this;
  }
  
  /**
   * @param {MediaAlign} align
   * @return {MediaObject}
   * @public
   */
  m_alignRightMedia__org_dominokit_domino_ui_media_MediaObject_MediaAlign(align) {
    if (Objects.m_nonNull__java_lang_Object(this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_)) {
      this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_.classList.remove(this.f_rightAlign__org_dominokit_domino_ui_media_MediaObject_.f_style__org_dominokit_domino_ui_media_MediaObject_MediaAlign_);
      this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_.classList.add(align.f_style__org_dominokit_domino_ui_media_MediaObject_MediaAlign_);
      this.f_rightAlign__org_dominokit_domino_ui_media_MediaObject_ = align;
    }
    return this;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getMediaBody__() {
    return this.f_mediaBody__org_dominokit_domino_ui_media_MediaObject_;
  }
  
  /**
   * @return {HTMLHeadingElement}
   * @public
   */
  m_getMediaHeader__() {
    return this.f_mediaHeader__org_dominokit_domino_ui_media_MediaObject_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getLeftMedia__() {
    return this.f_leftMedia__org_dominokit_domino_ui_media_MediaObject_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getRightMedia__() {
    return this.f_rightMedia__org_dominokit_domino_ui_media_MediaObject_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_media_MediaObject_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_media_MediaObject() {
    this.f_mediaHeader__org_dominokit_domino_ui_media_MediaObject_ = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["media-heading"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    this.f_mediaBody__org_dominokit_domino_ui_media_MediaObject_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["media-body"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_mediaHeader__org_dominokit_domino_ui_media_MediaObject_), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_element__org_dominokit_domino_ui_media_MediaObject_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["media"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_mediaBody__org_dominokit_domino_ui_media_MediaObject_), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_leftAlign__org_dominokit_domino_ui_media_MediaObject_ = MediaAlign.f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign;
    this.f_rightAlign__org_dominokit_domino_ui_media_MediaObject_ = MediaAlign.f_TOP__org_dominokit_domino_ui_media_MediaObject_MediaAlign;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaObject;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaObject);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaObject.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    MediaAlign = goog.module.get('org.dominokit.domino.ui.media.MediaObject.MediaAlign$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MediaObject, $Util.$makeClassName('org.dominokit.domino.ui.media.MediaObject'));


IsElement.$markImplementor(MediaObject);


exports = MediaObject; 
//# sourceMappingURL=MediaObject.js.map