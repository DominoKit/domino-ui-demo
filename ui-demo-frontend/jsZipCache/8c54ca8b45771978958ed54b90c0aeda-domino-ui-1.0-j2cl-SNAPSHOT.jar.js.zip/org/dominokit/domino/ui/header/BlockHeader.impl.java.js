/**
 * @fileoverview transpiled from org.dominokit.domino.ui.header.BlockHeader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.header.BlockHeader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class BlockHeader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_header_BlockHeader_;
    /** @public {HTMLHeadingElement} */
    this.f_headerElement__org_dominokit_domino_ui_header_BlockHeader_;
    /** @public {HTMLElement} */
    this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_;
  }
  
  /**
   * Factory method corresponding to constructor 'BlockHeader(HTMLDivElement, HTMLHeadingElement)'.
   * @param {HTMLDivElement} element
   * @param {HTMLHeadingElement} headerElement
   * @return {!BlockHeader}
   * @public
   */
  static $create__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement(element, headerElement) {
    BlockHeader.$clinit();
    let $instance = new BlockHeader();
    $instance.$ctor__org_dominokit_domino_ui_header_BlockHeader__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement(element, headerElement);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BlockHeader(HTMLDivElement, HTMLHeadingElement)'.
   * @param {HTMLDivElement} element
   * @param {HTMLHeadingElement} headerElement
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_header_BlockHeader__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement(element, headerElement) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_dominokit_domino_ui_header_BlockHeader_ = element;
    this.f_headerElement__org_dominokit_domino_ui_header_BlockHeader_ = headerElement;
  }
  
  /**
   * Factory method corresponding to constructor 'BlockHeader(HTMLDivElement, HTMLHeadingElement, String)'.
   * @param {HTMLDivElement} element
   * @param {HTMLHeadingElement} headerElement
   * @param {?string} description
   * @return {!BlockHeader}
   * @public
   */
  static $create__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement__java_lang_String(element, headerElement, description) {
    BlockHeader.$clinit();
    let $instance = new BlockHeader();
    $instance.$ctor__org_dominokit_domino_ui_header_BlockHeader__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement__java_lang_String(element, headerElement, description);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BlockHeader(HTMLDivElement, HTMLHeadingElement, String)'.
   * @param {HTMLDivElement} element
   * @param {HTMLHeadingElement} headerElement
   * @param {?string} description
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_header_BlockHeader__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement__java_lang_String(element, headerElement, description) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_dominokit_domino_ui_header_BlockHeader_ = element;
    this.f_headerElement__org_dominokit_domino_ui_header_BlockHeader_ = headerElement;
    this.m_createDescriptionElement__java_lang_String_$p_org_dominokit_domino_ui_header_BlockHeader(description);
  }
  
  /**
   * @param {?string} description
   * @return {void}
   * @public
   */
  m_createDescriptionElement__java_lang_String_$p_org_dominokit_domino_ui_header_BlockHeader(description) {
    this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_small__().m_textContent__java_lang_String(description), HtmlContentBuilder)).m_asElement__();
    this.f_headerElement__org_dominokit_domino_ui_header_BlockHeader_.appendChild(this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_);
  }
  
  /**
   * @param {?string} header
   * @param {?string} description
   * @return {BlockHeader}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(header, description) {
    BlockHeader.$clinit();
    let headerElement = /**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(2).m_textContent__java_lang_String(header), HtmlContentBuilder));
    let element = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["block-header"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(headerElement), HtmlContentBuilder)).m_asElement__(), $Overlay));
    return BlockHeader.$create__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement__java_lang_String(element, /**@type {HTMLHeadingElement} */ ($Casts.$to(headerElement.m_asElement__(), HTMLHeadingElement_$Overlay)), description);
  }
  
  /**
   * @param {?string} header
   * @return {BlockHeader}
   * @public
   */
  static m_create__java_lang_String(header) {
    BlockHeader.$clinit();
    let headerElement = /**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(2).m_textContent__java_lang_String(header), HtmlContentBuilder));
    let element = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["block-header"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(headerElement), HtmlContentBuilder)).m_asElement__(), $Overlay));
    return BlockHeader.$create__elemental2_dom_HTMLDivElement__elemental2_dom_HTMLHeadingElement(element, /**@type {HTMLHeadingElement} */ ($Casts.$to(headerElement.m_asElement__(), HTMLHeadingElement_$Overlay)));
  }
  
  /**
   * @param {Node} content
   * @return {BlockHeader}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    if (Objects.m_isNull__java_lang_Object(this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_)) {
      this.m_createDescriptionElement__java_lang_String_$p_org_dominokit_domino_ui_header_BlockHeader("");
    }
    this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_.appendChild(content);
    return this;
  }
  
  /**
   * @return {BlockHeader}
   * @public
   */
  m_invert__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_)) {
      this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_.remove();
      this.f_element__org_dominokit_domino_ui_header_BlockHeader_.insertBefore(this.f_descriptionElement__org_dominokit_domino_ui_header_BlockHeader_, this.f_headerElement__org_dominokit_domino_ui_header_BlockHeader_);
    }
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {BlockHeader}
   * @public
   */
  m_appendText__java_lang_String(text) {
    return this.m_appendContent__elemental2_dom_Node(new Text(text));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_header_BlockHeader_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BlockHeader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BlockHeader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BlockHeader.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BlockHeader, $Util.$makeClassName('org.dominokit.domino.ui.header.BlockHeader'));


IsElement.$markImplementor(BlockHeader);


exports = BlockHeader; 
//# sourceMappingURL=BlockHeader.js.map