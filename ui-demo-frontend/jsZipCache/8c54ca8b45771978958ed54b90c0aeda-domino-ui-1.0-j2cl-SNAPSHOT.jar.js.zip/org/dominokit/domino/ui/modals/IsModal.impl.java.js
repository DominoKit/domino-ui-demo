/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModal.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.IsModal$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class IsModal extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'IsModal()'.
   * @return {!IsModal}
   * @public
   */
  static $create__() {
    IsModal.$clinit();
    let $instance = new IsModal();
    $instance.$ctor__org_dominokit_domino_ui_modals_IsModal__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IsModal()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_IsModal__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IsModal;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IsModal);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IsModal.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IsModal, $Util.$makeClassName('org.dominokit.domino.ui.modals.IsModal'));




exports = IsModal; 
//# sourceMappingURL=IsModal.js.map