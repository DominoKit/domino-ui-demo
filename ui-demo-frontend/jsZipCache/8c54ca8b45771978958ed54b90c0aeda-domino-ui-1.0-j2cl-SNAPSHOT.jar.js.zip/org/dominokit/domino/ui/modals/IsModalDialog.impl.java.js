/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let CloseHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
let OpenHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');


/**
 * @interface
 * @template C_T
 */
class IsModalDialog {
  /**
   * @abstract
   * @param {Node} content
   * @return {C_T}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
  }
  
  /**
   * @abstract
   * @param {Node} content
   * @return {C_T}
   * @public
   */
  m_appendFooterContent__elemental2_dom_Node(content) {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_large__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_small__() {
  }
  
  /**
   * @abstract
   * @param {Color} color
   * @return {C_T}
   * @public
   */
  m_setModalColor__org_dominokit_domino_ui_style_Color(color) {
  }
  
  /**
   * @abstract
   * @param {boolean} autoClose
   * @return {C_T}
   * @public
   */
  m_setAutoClose__boolean(autoClose) {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_open__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_close__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_hideFooter__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_showFooter__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_hideHeader__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_showHeader__() {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @return {C_T}
   * @public
   */
  m_setTitle__java_lang_String(title) {
  }
  
  /**
   * @abstract
   * @return {HTMLDivElement}
   * @public
   */
  m_getDialogElement__() {
  }
  
  /**
   * @abstract
   * @return {HTMLDivElement}
   * @public
   */
  m_getContentElement__() {
  }
  
  /**
   * @abstract
   * @return {HTMLHeadingElement}
   * @public
   */
  m_getHeaderElement__() {
  }
  
  /**
   * @abstract
   * @return {HTMLDivElement}
   * @public
   */
  m_getHeaderContainerElement__() {
  }
  
  /**
   * @abstract
   * @return {HTMLDivElement}
   * @public
   */
  m_getBodyElement__() {
  }
  
  /**
   * @abstract
   * @return {HTMLDivElement}
   * @public
   */
  m_getFooterElement__() {
  }
  
  /**
   * @abstract
   * @param {OpenHandler} openHandler
   * @return {C_T}
   * @public
   */
  m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(openHandler) {
  }
  
  /**
   * @abstract
   * @param {CloseHandler} closeHandler
   * @return {C_T}
   * @public
   */
  m_onClose__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(closeHandler) {
  }
  
  /**
   * @abstract
   * @param {OpenHandler} openHandler
   * @return {C_T}
   * @public
   */
  m_removeOpenHandler__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(openHandler) {
  }
  
  /**
   * @abstract
   * @param {CloseHandler} closeHandler
   * @return {C_T}
   * @public
   */
  m_removeCloseHandler__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(closeHandler) {
  }
  
  /**
   * @abstract
   * @param {boolean} autoAppendAndRemove
   * @return {C_T}
   * @public
   */
  m_setAutoAppendAndRemove__boolean(autoAppendAndRemove) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_getAutoAppendAndRemove__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_modals_IsModalDialog = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_modals_IsModalDialog;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_modals_IsModalDialog;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IsModalDialog.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(IsModalDialog, $Util.$makeClassName('org.dominokit.domino.ui.modals.IsModalDialog'));


IsModalDialog.$markImplementor(/** @type {Function} */ (IsModalDialog));


exports = IsModalDialog; 
//# sourceMappingURL=IsModalDialog.js.map