/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.BaseModal$Modal.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.BaseModal.Modal$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class Modal extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLHeadingElement} */
    this.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    /** @public {HTMLDivElement} */
    this.f_modalHeader__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    /** @public {HTMLDivElement} */
    this.f_modalBody__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    /** @public {HTMLDivElement} */
    this.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    /** @public {HTMLDivElement} */
    this.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    /** @public {HTMLDivElement} */
    this.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * Factory method corresponding to constructor 'Modal()'.
   * @return {!Modal}
   * @public
   */
  static $create__() {
    Modal.$clinit();
    let $instance = new Modal();
    $instance.$ctor__org_dominokit_domino_ui_modals_BaseModal_Modal__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Modal()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_BaseModal_Modal__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_modals_BaseModal_Modal();
  }
  
  /**
   * @return {Modal}
   * @public
   */
  static m_create__() {
    Modal.$clinit();
    return Modal.$create__();
  }
  
  /**
   * @return {HTMLHeadingElement}
   * @public
   */
  m_getModalTitle__() {
    return this.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getModalBody__() {
    return this.f_modalBody__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getModalDialog__() {
    return this.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getModalContent__() {
    return this.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getModalFooter__() {
    return this.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getModalHeader__() {
    return this.f_modalHeader__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_modals_BaseModal_Modal() {
    this.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-title"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_modalHeader__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-header"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_modalBody__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-body"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-footer"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-content"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_modalHeader__org_dominokit_domino_ui_modals_BaseModal_Modal_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_modalBody__org_dominokit_domino_ui_modals_BaseModal_Modal_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-dialog"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("tabindex", "-1"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "document"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_element__org_dominokit_domino_ui_modals_BaseModal_Modal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal", "fade"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "-1"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("tabindex", "dialog"), HtmlContentBuilder)).m_style__java_lang_String("display: none;"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Modal;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Modal);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Modal.$clinit = function() {};
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Modal, $Util.$makeClassName('org.dominokit.domino.ui.modals.BaseModal$Modal'));


IsElement.$markImplementor(Modal);


exports = Modal; 
//# sourceMappingURL=BaseModal$Modal.js.map