/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog$OpenHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler.$LambdaAdaptor');


// Re-exports the implementation.
var OpenHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
exports = OpenHandler;
 