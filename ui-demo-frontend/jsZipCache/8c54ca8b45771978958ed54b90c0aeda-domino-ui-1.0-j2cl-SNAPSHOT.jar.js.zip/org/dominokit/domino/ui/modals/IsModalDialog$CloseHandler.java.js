/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog$CloseHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler.$LambdaAdaptor');


// Re-exports the implementation.
var CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
exports = CloseHandler;
 