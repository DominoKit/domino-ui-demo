/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');
const _OpenHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');


// Re-exports the implementation.
var IsModalDialog = goog.require('org.dominokit.domino.ui.modals.IsModalDialog$impl');
exports = IsModalDialog;
 