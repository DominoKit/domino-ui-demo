/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$CounterBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.CounterBuilder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CanCountTo = goog.require('org.dominokit.domino.ui.counter.Counter.CanCountTo$impl');
const HasCountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler$impl');
const HasIncrement = goog.require('org.dominokit.domino.ui.counter.Counter.HasIncrement$impl');
const HasInterval = goog.require('org.dominokit.domino.ui.counter.Counter.HasInterval$impl');

let Counter = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter$impl');
let CountHandler = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');


/**
 * @implements {CanCountTo}
 * @implements {HasInterval}
 * @implements {HasIncrement}
 * @implements {HasCountHandler}
  */
class CounterBuilder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_countFrom__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = 0;
    /** @public {number} */
    this.f_countTo__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = 0;
    /** @public {number} */
    this.f_interval__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = 0;
    /** @public {number} */
    this.f_increment__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = 0;
  }
  
  /**
   * Factory method corresponding to constructor 'CounterBuilder(int)'.
   * @param {number} countFrom
   * @return {!CounterBuilder}
   * @public
   */
  static $create__int(countFrom) {
    CounterBuilder.$clinit();
    let $instance = new CounterBuilder();
    $instance.$ctor__org_dominokit_domino_ui_counter_Counter_CounterBuilder__int(countFrom);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CounterBuilder(int)'.
   * @param {number} countFrom
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_counter_Counter_CounterBuilder__int(countFrom) {
    this.$ctor__java_lang_Object__();
    this.f_countFrom__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = countFrom;
  }
  
  /**
   * @override
   * @param {number} countTo
   * @return {HasInterval}
   * @public
   */
  m_countTo__int(countTo) {
    this.f_countTo__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = countTo;
    return this;
  }
  
  /**
   * @override
   * @param {number} interval
   * @return {HasIncrement}
   * @public
   */
  m_every__int(interval) {
    this.f_interval__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = interval;
    return this;
  }
  
  /**
   * @override
   * @param {number} increment
   * @return {HasCountHandler}
   * @public
   */
  m_incrementBy__int(increment) {
    this.f_increment__org_dominokit_domino_ui_counter_Counter_CounterBuilder_ = increment;
    return this;
  }
  
  /**
   * @override
   * @param {CountHandler} handler
   * @return {Counter}
   * @public
   */
  m_onCount__org_dominokit_domino_ui_counter_Counter_CountHandler(handler) {
    return Counter.$create__int__int__int__int__org_dominokit_domino_ui_counter_Counter_CountHandler(this.f_countFrom__org_dominokit_domino_ui_counter_Counter_CounterBuilder_, this.f_countTo__org_dominokit_domino_ui_counter_Counter_CounterBuilder_, this.f_interval__org_dominokit_domino_ui_counter_Counter_CounterBuilder_, this.f_increment__org_dominokit_domino_ui_counter_Counter_CounterBuilder_, handler);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CounterBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CounterBuilder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CounterBuilder.$clinit = function() {};
    Counter = goog.module.get('org.dominokit.domino.ui.counter.Counter$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CounterBuilder, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$CounterBuilder'));


CanCountTo.$markImplementor(CounterBuilder);
HasInterval.$markImplementor(CounterBuilder);
HasIncrement.$markImplementor(CounterBuilder);
HasCountHandler.$markImplementor(CounterBuilder);


exports = CounterBuilder; 
//# sourceMappingURL=Counter$CounterBuilder.js.map