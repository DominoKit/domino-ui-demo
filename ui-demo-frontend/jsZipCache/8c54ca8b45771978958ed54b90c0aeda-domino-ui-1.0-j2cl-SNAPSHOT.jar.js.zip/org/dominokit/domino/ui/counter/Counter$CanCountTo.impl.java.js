/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$CanCountTo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.CanCountTo$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CanCountTo.$LambdaAdaptor$impl');
let HasInterval = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasInterval$impl');


/**
 * @interface
 */
class CanCountTo {
  /**
   * @abstract
   * @param {number} countTo
   * @return {HasInterval}
   * @public
   */
  m_countTo__int(countTo) {
  }
  
  /**
   * @param {?function(number):HasInterval} fn
   * @return {CanCountTo}
   * @public
   */
  static $adapt(fn) {
    CanCountTo.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_CanCountTo = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_counter_Counter_CanCountTo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_CanCountTo;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanCountTo.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.counter.Counter.CanCountTo.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CanCountTo, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$CanCountTo'));


CanCountTo.$markImplementor(/** @type {Function} */ (CanCountTo));


exports = CanCountTo; 
//# sourceMappingURL=Counter$CanCountTo.js.map