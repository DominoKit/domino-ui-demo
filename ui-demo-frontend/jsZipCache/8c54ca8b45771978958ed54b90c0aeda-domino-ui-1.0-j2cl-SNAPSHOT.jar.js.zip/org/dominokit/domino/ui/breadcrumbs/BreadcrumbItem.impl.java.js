/**
 * @fileoverview transpiled from org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLLIElement>}
 * @implements {HasClickableElement}
  */
class BreadcrumbItem extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLLIElement} */
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {HTMLAnchorElement} */
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {Text} */
    this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {Icon} */
    this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {boolean} */
    this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbItem(String)'.
   * @param {?string} text
   * @return {!BreadcrumbItem}
   * @public
   */
  static $create__java_lang_String(text) {
    BreadcrumbItem.$clinit();
    let $instance = new BreadcrumbItem();
    $instance.$ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__java_lang_String(text);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbItem(String)'.
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__java_lang_String(text) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem();
    this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = new Text(text);
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbItem(Icon, String)'.
   * @param {Icon} icon
   * @param {?string} text
   * @return {!BreadcrumbItem}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_Icon__java_lang_String(icon, text) {
    BreadcrumbItem.$clinit();
    let $instance = new BreadcrumbItem();
    $instance.$ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__org_dominokit_domino_ui_icons_Icon__java_lang_String(icon, text);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbItem(Icon, String)'.
   * @param {Icon} icon
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__org_dominokit_domino_ui_icons_Icon__java_lang_String(icon, text) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem();
    this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = icon;
    this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = new Text(text);
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(icon.m_asElement__());
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
  }
  
  /**
   * @param {?string} text
   * @return {BreadcrumbItem}
   * @public
   */
  static m_create__java_lang_String(text) {
    BreadcrumbItem.$clinit();
    return BreadcrumbItem.$create__java_lang_String(text);
  }
  
  /**
   * @param {Icon} icon
   * @param {?string} text
   * @return {BreadcrumbItem}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String(icon, text) {
    BreadcrumbItem.$clinit();
    return BreadcrumbItem.$create__org_dominokit_domino_ui_icons_Icon__java_lang_String(icon, text);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_activate__() {
    if (!this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_) {
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.classList.add("active");
      this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.remove();
      this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.remove();
      if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_)) {
        this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__().remove();
        this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__());
      }
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = true;
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_deActivate__() {
    if (this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_) {
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.classList.remove("active");
      this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.remove();
      if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_)) {
        this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__().remove();
        this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__());
      }
      this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.appendChild(this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = false;
    }
  }
  
  /**
   * @param {EventListener} onClick
   * @return {BreadcrumbItem}
   * @public
   */
  m_onClick__elemental2_dom_EventListener(onClick) {
    this.m_getClickableElement__().addEventListener("click", onClick);
    return this;
  }
  
  /**
   * @override
   * @return {HTMLLIElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem() {
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = /**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), $Overlay));
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(Elements.m_a__().m_asElement__(), HTMLAnchorElement_$Overlay));
    this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BreadcrumbItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BreadcrumbItem);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BreadcrumbItem.$clinit = function() {};
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BreadcrumbItem, $Util.$makeClassName('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem'));


IsElement.$markImplementor(BreadcrumbItem);
HasClickableElement.$markImplementor(BreadcrumbItem);


exports = BreadcrumbItem; 
//# sourceMappingURL=BreadcrumbItem.js.map