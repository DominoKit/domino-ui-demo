/**
 * @fileoverview transpiled from org.dominokit.domino.ui.layout.Content.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.layout.Content$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class Content extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_contentContainer__org_dominokit_domino_ui_layout_Content_;
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_layout_Content_;
  }
  
  /**
   * Factory method corresponding to constructor 'Content()'.
   * @return {!Content}
   * @public
   */
  static $create__() {
    Content.$clinit();
    let $instance = new Content();
    $instance.$ctor__org_dominokit_domino_ui_layout_Content__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Content()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_layout_Content__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_layout_Content();
  }
  
  /**
   * @return {Content}
   * @public
   */
  static m_create__() {
    Content.$clinit();
    return Content.$create__();
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getContentContainer__() {
    return this.f_contentContainer__org_dominokit_domino_ui_layout_Content_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_layout_Content_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_layout_Content() {
    this.f_contentContainer__org_dominokit_domino_ui_layout_Content_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["content-panel"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_element__org_dominokit_domino_ui_layout_Content_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_section__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["content"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_contentContainer__org_dominokit_domino_ui_layout_Content_), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Content;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Content);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Content.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Content, $Util.$makeClassName('org.dominokit.domino.ui.layout.Content'));


IsElement.$markImplementor(Content);


exports = Content; 
//# sourceMappingURL=Content.js.map