/**
 * @fileoverview transpiled from org.dominokit.domino.ui.cards.Card.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.cards.Card$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card.$LambdaAdaptor$6$impl');
let Code = goog.forwardDeclare('org.dominokit.domino.ui.code.Code$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasBackground<Card>}
  */
class Card extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Text} */
    this.f_title__org_dominokit_domino_ui_cards_Card_;
    /** @public {Text} */
    this.f_description__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLElement} */
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLElement} */
    this.f_headerTitle__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLUListElement} */
    this.f_headerBar__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLDivElement} */
    this.f_header__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLDivElement} */
    this.f_body__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_cards_Card_;
    /** @public {boolean} */
    this.f_collapsible__org_dominokit_domino_ui_cards_Card_ = false;
    /** @public {HTMLLIElement} */
    this.f_collapseAction__org_dominokit_domino_ui_cards_Card_;
    /** @public {boolean} */
    this.f_collapsed__org_dominokit_domino_ui_cards_Card_ = false;
    /** @public {Icon} */
    this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * Factory method corresponding to constructor 'Card()'.
   * @return {!Card}
   * @public
   */
  static $create__() {
    Card.$clinit();
    let $instance = new Card();
    $instance.$ctor__org_dominokit_domino_ui_cards_Card__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Card()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_cards_Card__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_cards_Card();
    this.f_headerTitle__org_dominokit_domino_ui_cards_Card_.insertBefore(this.f_title__org_dominokit_domino_ui_cards_Card_, this.f_headerDescription__org_dominokit_domino_ui_cards_Card_);
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card_.appendChild(this.f_description__org_dominokit_domino_ui_cards_Card_);
  }
  
  /**
   * @return {Card}
   * @public
   */
  static m_create__() {
    Card.$clinit();
    let card = Card.$create__();
    card.m_asElement__().removeChild(card.f_header__org_dominokit_domino_ui_cards_Card_);
    return card;
  }
  
  /**
   * @param {?string} title
   * @return {Card}
   * @public
   */
  static m_create__java_lang_String(title) {
    Card.$clinit();
    let card = Card.$create__();
    card.m_setTitle__java_lang_String(title);
    card.f_headerTitle__org_dominokit_domino_ui_cards_Card_.removeChild(card.f_headerDescription__org_dominokit_domino_ui_cards_Card_);
    return card;
  }
  
  /**
   * @param {?string} title
   * @param {?string} description
   * @return {Card}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(title, description) {
    Card.$clinit();
    let card = Card.$create__();
    card.m_setTitle__java_lang_String(title);
    card.m_setDescription__java_lang_String(description);
    return card;
  }
  
  /**
   * @param {?string} name
   * @param {?string} info
   * @return {Card}
   * @public
   */
  static m_createProfile__java_lang_String__java_lang_String(name, info) {
    Card.$clinit();
    let profileCard = Card.m_create__java_lang_String__java_lang_String(name, info);
    profileCard.m_asElement__().style.marginBottom = $Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(0));
    profileCard.m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_THEME__org_dominokit_domino_ui_style_Color);
    return profileCard;
  }
  
  /**
   * @param {?string} codeBlock
   * @return {Card}
   * @public
   */
  static m_createCodeCard__java_lang_String(codeBlock) {
    Card.$clinit();
    return Card.m_create__java_lang_String("Source Code").m_setCollapsible__().m_collapse__().m_appendContent__elemental2_dom_Node(Code.m_block__java_lang_String(codeBlock).m_asElement__());
  }
  
  /**
   * @param {?string} titleText
   * @return {Card}
   * @public
   */
  m_setTitle__java_lang_String(titleText) {
    this.f_title__org_dominokit_domino_ui_cards_Card_.textContent = titleText;
    return this;
  }
  
  /**
   * @param {?string} descriptionText
   * @return {Card}
   * @public
   */
  m_setDescription__java_lang_String(descriptionText) {
    this.f_description__org_dominokit_domino_ui_cards_Card_.textContent = descriptionText;
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {Card}
   * @public
   */
  m_appendDescriptionContent__elemental2_dom_Node(content) {
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card_.appendChild(content);
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {Card}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.m_getBody__().appendChild(content);
    return this;
  }
  
  /**
   * @return {HTMLUListElement}
   * @public
   */
  m_getHeaderBar__() {
    return this.f_headerBar__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getBody__() {
    return this.f_body__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * @param {Color} background
   * @return {Card}
   * @public
   */
  m_setHeaderBackground__org_dominokit_domino_ui_style_Color(background) {
    this.f_header__org_dominokit_domino_ui_cards_Card_.classList.add(background.m_getBackground__());
    return this;
  }
  
  /**
   * @param {Color} background
   * @return {Card}
   * @public
   */
  m_setBodyBackground__org_dominokit_domino_ui_style_Color(background) {
    this.f_body__org_dominokit_domino_ui_cards_Card_.classList.add(background.m_getBackground__());
    return this;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Card}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    this.m_setHeaderBackground__org_dominokit_domino_ui_style_Color(background);
    this.m_setBodyBackground__org_dominokit_domino_ui_style_Color(background);
    return this;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getHeader__() {
    return this.f_header__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getHeaderTitle__() {
    return this.f_headerTitle__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getHeaderDescription__() {
    return this.f_headerDescription__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * @param {Icon} icon
   * @return {HTMLLIElement}
   * @public
   */
  static m_createIcon__org_dominokit_domino_ui_icons_Icon(icon) {
    Card.$clinit();
    return /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__elemental2_dom_Node(icon.m_asElement__()), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @param {Icon} icon
   * @param {EventListener} eventListener
   * @return {Card}
   * @public
   */
  m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(icon, eventListener) {
    let actionItem = this.m_createHeaderAction__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_ui_cards_Card(icon);
    actionItem.addEventListener("click", eventListener);
    this.m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(actionItem);
    return this;
  }
  
  /**
   * @param {HTMLLIElement} actionItem
   * @return {void}
   * @public
   */
  m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(actionItem) {
    if (Objects.m_nonNull__java_lang_Object(this.f_collapseAction__org_dominokit_domino_ui_cards_Card_) && this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
      this.f_headerBar__org_dominokit_domino_ui_cards_Card_.insertBefore(actionItem, this.f_collapseAction__org_dominokit_domino_ui_cards_Card_);
    } else {
      this.f_headerBar__org_dominokit_domino_ui_cards_Card_.appendChild(actionItem);
    }
  }
  
  /**
   * @param {Icon} icon
   * @return {HTMLLIElement}
   * @public
   */
  m_createHeaderAction__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_ui_cards_Card(icon) {
    return /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__elemental2_dom_Node(icon.m_asElement__()), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_setCollapsible__() {
    this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_ = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_up__();
    if (Objects.m_isNull__java_lang_Object(this.f_collapseAction__org_dominokit_domino_ui_cards_Card_)) {
      this.f_collapseAction__org_dominokit_domino_ui_cards_Card_ = this.m_createHeaderAction__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_ui_cards_Card(this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_);
    }
    this.f_collapseAction__org_dominokit_domino_ui_cards_Card_.addEventListener("click", new $LambdaAdaptor$6(((/** Event */ evt) =>{
      if (this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
        if (this.f_collapsed__org_dominokit_domino_ui_cards_Card_) {
          this.m_expand__();
        } else {
          this.m_collapse__();
        }
      }
    })));
    this.m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(this.f_collapseAction__org_dominokit_domino_ui_cards_Card_);
    this.f_collapsible__org_dominokit_domino_ui_cards_Card_ = true;
    return this;
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_collapse__() {
    if (this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
      this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_down__().m_getName__();
      this.m_getBody__().style.display = "none";
      this.f_collapsed__org_dominokit_domino_ui_cards_Card_ = true;
    }
    return this;
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_expand__() {
    if (this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
      this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_up__().m_getName__();
      this.m_getBody__().style.display = "block";
      this.f_collapsed__org_dominokit_domino_ui_cards_Card_ = false;
    }
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_cards_Card_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_cards_Card() {
    this.f_title__org_dominokit_domino_ui_cards_Card_ = new Text("");
    this.f_description__org_dominokit_domino_ui_cards_Card_ = new Text("");
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card_ = Elements.m_small__().m_asElement__();
    this.f_headerTitle__org_dominokit_domino_ui_cards_Card_ = /**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(2).m_add__elemental2_dom_Node(this.f_headerDescription__org_dominokit_domino_ui_cards_Card_), HtmlContentBuilder)).m_asElement__();
    this.f_headerBar__org_dominokit_domino_ui_cards_Card_ = /**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["header-dropdown", "m-r--5"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLUListElement_$Overlay));
    this.f_header__org_dominokit_domino_ui_cards_Card_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(this.f_headerTitle__org_dominokit_domino_ui_cards_Card_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_headerBar__org_dominokit_domino_ui_cards_Card_), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["header"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_body__org_dominokit_domino_ui_cards_Card_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["body"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_element__org_dominokit_domino_ui_cards_Card_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(this.f_header__org_dominokit_domino_ui_cards_Card_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_body__org_dominokit_domino_ui_cards_Card_), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["card"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_collapsible__org_dominokit_domino_ui_cards_Card_ = false;
    this.f_collapsed__org_dominokit_domino_ui_cards_Card_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Card;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Card);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Card.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.ui.cards.Card.$LambdaAdaptor$6$impl');
    Code = goog.module.get('org.dominokit.domino.ui.code.Code$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Card, $Util.$makeClassName('org.dominokit.domino.ui.cards.Card'));


IsElement.$markImplementor(Card);
HasBackground.$markImplementor(Card);


exports = Card; 
//# sourceMappingURL=Card.js.map