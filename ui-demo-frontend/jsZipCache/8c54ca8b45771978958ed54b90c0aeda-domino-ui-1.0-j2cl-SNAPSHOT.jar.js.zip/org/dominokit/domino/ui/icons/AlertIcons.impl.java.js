/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.AlertIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.AlertIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class AlertIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_alert__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_error__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_error_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_warning__() {
  }
  
  /**
   * @param {AlertIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_alert__$default__org_dominokit_domino_ui_icons_AlertIcons($thisArg) {
    AlertIcons.$clinit();
    return Icon.m_create__java_lang_String("add_alert");
  }
  
  /**
   * @param {AlertIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_error__$default__org_dominokit_domino_ui_icons_AlertIcons($thisArg) {
    AlertIcons.$clinit();
    return Icon.m_create__java_lang_String("error");
  }
  
  /**
   * @param {AlertIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_error_outline__$default__org_dominokit_domino_ui_icons_AlertIcons($thisArg) {
    AlertIcons.$clinit();
    return Icon.m_create__java_lang_String("error_outline");
  }
  
  /**
   * @param {AlertIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_warning__$default__org_dominokit_domino_ui_icons_AlertIcons($thisArg) {
    AlertIcons.$clinit();
    return Icon.m_create__java_lang_String("warning");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_AlertIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_AlertIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_AlertIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(AlertIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.AlertIcons'));


AlertIcons.$markImplementor(/** @type {Function} */ (AlertIcons));


exports = AlertIcons; 
//# sourceMappingURL=AlertIcons.js.map