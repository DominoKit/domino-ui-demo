/**
 * @fileoverview transpiled from org.dominokit.domino.ui.notifications.BottomLeftPosition.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.notifications.BottomLeftPosition');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _NotificationPosition = goog.require('org.dominokit.domino.ui.notifications.NotificationPosition');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');


// Re-exports the implementation.
var BottomLeftPosition = goog.require('org.dominokit.domino.ui.notifications.BottomLeftPosition$impl');
exports = BottomLeftPosition;
 