/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.SimpleListGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.SimpleListGroup$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let SimpleListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListItem$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLUListElement>}
  */
class SimpleListGroup extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLUListElement} */
    this.f_element__org_dominokit_domino_ui_lists_SimpleListGroup_;
  }
  
  /**
   * Factory method corresponding to constructor 'SimpleListGroup(HTMLUListElement)'.
   * @param {HTMLUListElement} element
   * @return {!SimpleListGroup}
   * @public
   */
  static $create__elemental2_dom_HTMLUListElement(element) {
    SimpleListGroup.$clinit();
    let $instance = new SimpleListGroup();
    $instance.$ctor__org_dominokit_domino_ui_lists_SimpleListGroup__elemental2_dom_HTMLUListElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SimpleListGroup(HTMLUListElement)'.
   * @param {HTMLUListElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_SimpleListGroup__elemental2_dom_HTMLUListElement(element) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_dominokit_domino_ui_lists_SimpleListGroup_ = element;
  }
  
  /**
   * @return {SimpleListGroup}
   * @public
   */
  static m_create__() {
    SimpleListGroup.$clinit();
    return SimpleListGroup.$create__elemental2_dom_HTMLUListElement(/**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay)));
  }
  
  /**
   * @param {?string} content
   * @return {SimpleListItem}
   * @public
   */
  m_addItem__java_lang_String(content) {
    let item = SimpleListItem.m_create__java_lang_String(content);
    this.f_element__org_dominokit_domino_ui_lists_SimpleListGroup_.appendChild(item.m_asElement__());
    return item;
  }
  
  /**
   * @param {?string} content
   * @return {SimpleListGroup}
   * @public
   */
  m_appendItem__java_lang_String(content) {
    this.f_element__org_dominokit_domino_ui_lists_SimpleListGroup_.appendChild(SimpleListItem.m_create__java_lang_String(content).m_asElement__());
    return this;
  }
  
  /**
   * @param {SimpleListItem} item
   * @return {SimpleListGroup}
   * @public
   */
  m_appendItem__org_dominokit_domino_ui_lists_SimpleListItem(item) {
    this.f_element__org_dominokit_domino_ui_lists_SimpleListGroup_.appendChild(item.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLUListElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_lists_SimpleListGroup_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SimpleListGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SimpleListGroup);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SimpleListGroup.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    SimpleListItem = goog.module.get('org.dominokit.domino.ui.lists.SimpleListItem$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SimpleListGroup, $Util.$makeClassName('org.dominokit.domino.ui.lists.SimpleListGroup'));


IsElement.$markImplementor(SimpleListGroup);


exports = SimpleListGroup; 
//# sourceMappingURL=SimpleListGroup.js.map