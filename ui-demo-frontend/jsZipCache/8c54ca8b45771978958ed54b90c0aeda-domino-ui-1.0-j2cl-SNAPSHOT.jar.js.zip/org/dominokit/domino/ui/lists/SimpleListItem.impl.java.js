/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.SimpleListItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.SimpleListItem$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseListItem = goog.require('org.dominokit.domino.ui.lists.BaseListItem$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const IsHtmlComponent = goog.require('org.dominokit.domino.ui.utils.IsHtmlComponent$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ListGroupStyle = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroupStyle$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let HtmlComponentBuilder = goog.forwardDeclare('org.dominokit.domino.ui.utils.HtmlComponentBuilder$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseListItem<HTMLLIElement>}
 * @implements {IsElement<HTMLLIElement>}
 * @implements {HasBackground<SimpleListItem>}
 * @implements {IsHtmlComponent<HTMLLIElement, SimpleListItem>}
  */
class SimpleListItem extends BaseListItem {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HtmlComponentBuilder<HTMLLIElement, SimpleListItem>} */
    this.f_htmlBuilder__org_dominokit_domino_ui_lists_SimpleListItem_;
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_lists_SimpleListItem_;
  }
  
  /**
   * Factory method corresponding to constructor 'SimpleListItem(String)'.
   * @param {?string} text
   * @return {!SimpleListItem}
   * @public
   */
  static $create__java_lang_String(text) {
    SimpleListItem.$clinit();
    let $instance = new SimpleListItem();
    $instance.$ctor__org_dominokit_domino_ui_lists_SimpleListItem__java_lang_String(text);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SimpleListItem(String)'.
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_SimpleListItem__java_lang_String(text) {
    this.$ctor__org_dominokit_domino_ui_lists_BaseListItem__elemental2_dom_Element(/**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list-group-item"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(text), HtmlContentBuilder)).m_asElement__(), $Overlay)));
    this.f_htmlBuilder__org_dominokit_domino_ui_lists_SimpleListItem_ = /**@type {!HtmlComponentBuilder<HTMLLIElement, SimpleListItem>} */ (HtmlComponentBuilder.$create__org_jboss_gwt_elemento_core_IsElement(this));
  }
  
  /**
   * @param {?string} text
   * @return {SimpleListItem}
   * @public
   */
  static m_create__java_lang_String(text) {
    SimpleListItem.$clinit();
    return SimpleListItem.$create__java_lang_String(text);
  }
  
  /**
   * @param {ListGroupStyle} itemStyle
   * @return {SimpleListItem}
   * @public
   */
  m_setStyle__org_dominokit_domino_ui_lists_ListGroupStyle(itemStyle) {
    return this.m_setStyle__java_lang_String_$p_org_dominokit_domino_ui_lists_SimpleListItem(itemStyle.m_getStyle__());
  }
  
  /**
   * @param {?string} itemStyle
   * @return {SimpleListItem}
   * @public
   */
  m_setStyle__java_lang_String_$p_org_dominokit_domino_ui_lists_SimpleListItem(itemStyle) {
    if (Objects.m_nonNull__java_lang_Object(this.f_style__org_dominokit_domino_ui_lists_SimpleListItem_)) {
      /**@type {HTMLLIElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).classList.remove(this.f_style__org_dominokit_domino_ui_lists_SimpleListItem_);
    }
    /**@type {HTMLLIElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).classList.add(itemStyle);
    this.f_style__org_dominokit_domino_ui_lists_SimpleListItem_ = itemStyle;
    return this;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {SimpleListItem}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    this.m_setStyle__java_lang_String_$p_org_dominokit_domino_ui_lists_SimpleListItem("list-group-" + j_l_String.m_valueOf__java_lang_Object(background.m_getBackground__()));
    return this;
  }
  
  /**
   * @param {?string} heading
   * @return {SimpleListItem}
   * @public
   */
  m_setHeading__java_lang_String(heading) {
    this.m_setHeaderText__java_lang_String_$pp_org_dominokit_domino_ui_lists(heading);
    return this;
  }
  
  /**
   * @param {?string} content
   * @return {SimpleListItem}
   * @public
   */
  m_setText__java_lang_String(content) {
    this.m_setBodyText__java_lang_String_$pp_org_dominokit_domino_ui_lists(content);
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {SimpleListItem}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.m_asElement__().appendChild(content);
    return this;
  }
  
  /**
   * @override
   * @return {HTMLLIElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLLIElement} */ ($Casts.$to(this.m_getElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {HtmlComponentBuilder<HTMLLIElement, SimpleListItem>}
   * @public
   */
  m_htmlBuilder__() {
    return this.f_htmlBuilder__org_dominokit_domino_ui_lists_SimpleListItem_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SimpleListItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SimpleListItem);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SimpleListItem.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    HtmlComponentBuilder = goog.module.get('org.dominokit.domino.ui.utils.HtmlComponentBuilder$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseListItem.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SimpleListItem, $Util.$makeClassName('org.dominokit.domino.ui.lists.SimpleListItem'));


IsElement.$markImplementor(SimpleListItem);
HasBackground.$markImplementor(SimpleListItem);
IsHtmlComponent.$markImplementor(SimpleListItem);


exports = SimpleListItem; 
//# sourceMappingURL=SimpleListItem.js.map