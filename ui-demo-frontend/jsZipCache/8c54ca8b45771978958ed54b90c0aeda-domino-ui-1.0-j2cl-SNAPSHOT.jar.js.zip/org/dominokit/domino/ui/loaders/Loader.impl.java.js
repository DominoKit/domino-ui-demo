/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.Loader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.Loader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let IsLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.IsLoader$impl');
let LoaderEffect = goog.forwardDeclare('org.dominokit.domino.ui.loaders.LoaderEffect$impl');
let LoaderFactory = goog.forwardDeclare('org.dominokit.domino.ui.loaders.LoaderFactory$impl');


class Loader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_started__org_dominokit_domino_ui_loaders_Loader_ = false;
    /** @public {HTMLElement} */
    this.f_target__org_dominokit_domino_ui_loaders_Loader_;
    /** @public {IsLoader} */
    this.f_loaderElement__org_dominokit_domino_ui_loaders_Loader_;
  }
  
  /**
   * @param {HTMLElement} target
   * @param {LoaderEffect} effect
   * @return {Loader}
   * @public
   */
  static m_create__elemental2_dom_HTMLElement__org_dominokit_domino_ui_loaders_LoaderEffect(target, effect) {
    Loader.$clinit();
    return Loader.$create__elemental2_dom_HTMLElement__org_dominokit_domino_ui_loaders_LoaderEffect(target, effect);
  }
  
  /**
   * Factory method corresponding to constructor 'Loader(HTMLElement, LoaderEffect)'.
   * @param {HTMLElement} target
   * @param {LoaderEffect} type
   * @return {!Loader}
   * @public
   */
  static $create__elemental2_dom_HTMLElement__org_dominokit_domino_ui_loaders_LoaderEffect(target, type) {
    Loader.$clinit();
    let $instance = new Loader();
    $instance.$ctor__org_dominokit_domino_ui_loaders_Loader__elemental2_dom_HTMLElement__org_dominokit_domino_ui_loaders_LoaderEffect(target, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Loader(HTMLElement, LoaderEffect)'.
   * @param {HTMLElement} target
   * @param {LoaderEffect} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_loaders_Loader__elemental2_dom_HTMLElement__org_dominokit_domino_ui_loaders_LoaderEffect(target, type) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_loaders_Loader();
    this.f_target__org_dominokit_domino_ui_loaders_Loader_ = target;
    this.f_loaderElement__org_dominokit_domino_ui_loaders_Loader_ = LoaderFactory.m_make__org_dominokit_domino_ui_loaders_LoaderEffect(type);
  }
  
  /**
   * @return {Loader}
   * @public
   */
  m_start__() {
    this.m_stop__();
    this.f_target__org_dominokit_domino_ui_loaders_Loader_.appendChild(this.f_loaderElement__org_dominokit_domino_ui_loaders_Loader_.m_asElement__());
    this.f_target__org_dominokit_domino_ui_loaders_Loader_.classList.add("waitMe_container");
    this.f_started__org_dominokit_domino_ui_loaders_Loader_ = true;
    return this;
  }
  
  /**
   * @return {Loader}
   * @public
   */
  m_stop__() {
    if (this.f_started__org_dominokit_domino_ui_loaders_Loader_) {
      this.f_target__org_dominokit_domino_ui_loaders_Loader_.removeChild(this.f_loaderElement__org_dominokit_domino_ui_loaders_Loader_.m_asElement__());
      this.f_target__org_dominokit_domino_ui_loaders_Loader_.classList.remove("waitMe_container");
      this.f_started__org_dominokit_domino_ui_loaders_Loader_ = false;
    }
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Loader}
   * @public
   */
  m_setLoadingText__java_lang_String(text) {
    this.f_loaderElement__org_dominokit_domino_ui_loaders_Loader_.m_setLoadingText__java_lang_String(text);
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_loaders_Loader() {
    this.f_started__org_dominokit_domino_ui_loaders_Loader_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Loader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Loader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Loader.$clinit = function() {};
    LoaderFactory = goog.module.get('org.dominokit.domino.ui.loaders.LoaderFactory$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Loader, $Util.$makeClassName('org.dominokit.domino.ui.loaders.Loader'));




exports = Loader; 
//# sourceMappingURL=Loader.js.map