/**
 * @fileoverview transpiled from org.dominokit.domino.ui.dialogs.MessageDialog.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.dialogs.MessageDialog');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseModal = goog.require('org.dominokit.domino.ui.modals.BaseModal');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Animation = goog.require('org.dominokit.domino.ui.animations.Animation');
const _CompleteCallback = goog.require('org.dominokit.domino.ui.animations.Animation.CompleteCallback');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _$LambdaAdaptor$17 = goog.require('org.dominokit.domino.ui.dialogs.MessageDialog.$LambdaAdaptor$17');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');
const _ModalSize = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize');
const _OpenHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MessageDialog = goog.require('org.dominokit.domino.ui.dialogs.MessageDialog$impl');
exports = MessageDialog;
 