/**
 * @fileoverview transpiled from org.dominokit.domino.ui.Typography.Blockquote.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.Typography.Blockquote$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLQuoteElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLQuoteElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class Blockquote extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_;
    /** @public {Paragraph} */
    this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_;
    /** @public {HTMLElement} */
    this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_;
  }
  
  /**
   * Factory method corresponding to constructor 'Blockquote()'.
   * @return {!Blockquote}
   * @public
   */
  static $create__() {
    Blockquote.$clinit();
    let $instance = new Blockquote();
    $instance.$ctor__org_dominokit_domino_ui_Typography_Blockquote__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Blockquote()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_Typography_Blockquote__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_Typography_Blockquote();
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_.appendChild(this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_.m_asElement__());
  }
  
  /**
   * Factory method corresponding to constructor 'Blockquote(String)'.
   * @param {?string} text
   * @return {!Blockquote}
   * @public
   */
  static $create__java_lang_String(text) {
    Blockquote.$clinit();
    let $instance = new Blockquote();
    $instance.$ctor__org_dominokit_domino_ui_Typography_Blockquote__java_lang_String(text);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Blockquote(String)'.
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_Typography_Blockquote__java_lang_String(text) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_Typography_Blockquote();
    this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_.m_setText__java_lang_String(text);
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_.appendChild(this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_.m_asElement__());
  }
  
  /**
   * Factory method corresponding to constructor 'Blockquote(Paragraph)'.
   * @param {Paragraph} paragraph
   * @return {!Blockquote}
   * @public
   */
  static $create__org_dominokit_domino_ui_Typography_Paragraph(paragraph) {
    Blockquote.$clinit();
    let $instance = new Blockquote();
    $instance.$ctor__org_dominokit_domino_ui_Typography_Blockquote__org_dominokit_domino_ui_Typography_Paragraph(paragraph);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Blockquote(Paragraph)'.
   * @param {Paragraph} paragraph
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_Typography_Blockquote__org_dominokit_domino_ui_Typography_Paragraph(paragraph) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_Typography_Blockquote();
    this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_ = paragraph;
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_.appendChild(paragraph.m_asElement__());
  }
  
  /**
   * @return {Blockquote}
   * @public
   */
  static m_create__() {
    Blockquote.$clinit();
    return Blockquote.$create__();
  }
  
  /**
   * @param {?string} text
   * @return {Blockquote}
   * @public
   */
  static m_create__java_lang_String(text) {
    Blockquote.$clinit();
    return Blockquote.$create__java_lang_String(text);
  }
  
  /**
   * @param {Paragraph} paragraph
   * @return {Blockquote}
   * @public
   */
  static m_create__org_dominokit_domino_ui_Typography_Paragraph(paragraph) {
    Blockquote.$clinit();
    return Blockquote.$create__org_dominokit_domino_ui_Typography_Paragraph(paragraph);
  }
  
  /**
   * @param {?string} text
   * @return {Blockquote}
   * @public
   */
  m_setText__java_lang_String(text) {
    this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_.m_setText__java_lang_String(text);
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {Blockquote}
   * @public
   */
  m_setFooterContent__elemental2_dom_Node(content) {
    if (Objects.m_nonNull__java_lang_Object(this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_)) {
      this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_.remove();
    }
    this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_footer__().m_add__elemental2_dom_Node(content), HtmlContentBuilder)).m_asElement__();
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_.appendChild(this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_);
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Blockquote}
   * @public
   */
  m_setFooterText__java_lang_String(text) {
    return this.m_setFooterContent__elemental2_dom_Node(new Text(text));
  }
  
  /**
   * @return {Blockquote}
   * @public
   */
  m_reverse__() {
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_.classList.remove(Styles.f_BLOCKQUOTE_REVERSE__org_dominokit_domino_ui_style_Styles);
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_.classList.add(Styles.f_BLOCKQUOTE_REVERSE__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {Blockquote}
   * @public
   */
  m_appendFooterContent__elemental2_dom_Node(content) {
    if (Objects.m_isNull__java_lang_Object(this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_)) {
      this.m_setFooterContent__elemental2_dom_Node(content);
    } else {
      this.f_footer__org_dominokit_domino_ui_Typography_Blockquote_.appendChild(content);
    }
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_Typography_Blockquote_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_Typography_Blockquote() {
    this.f_element__org_dominokit_domino_ui_Typography_Blockquote_ = /**@type {HtmlContentBuilder<HTMLQuoteElement>} */ ($Casts.$to(Elements.m_blockquote__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_m_b_25__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_paragraph__org_dominokit_domino_ui_Typography_Blockquote_ = Paragraph.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Blockquote;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Blockquote);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Blockquote.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Blockquote, $Util.$makeClassName('org.dominokit.domino.ui.Typography.Blockquote'));


IsElement.$markImplementor(Blockquote);


exports = Blockquote; 
//# sourceMappingURL=Blockquote.js.map