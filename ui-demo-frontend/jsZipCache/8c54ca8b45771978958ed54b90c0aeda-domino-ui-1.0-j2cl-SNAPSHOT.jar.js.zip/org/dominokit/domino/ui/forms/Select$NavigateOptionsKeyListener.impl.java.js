/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select$NavigateOptionsKeyListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Select.NavigateOptionsKeyListener$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {EventListener}
  */
class NavigateOptionsKeyListener extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select} */
    this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener;
  }
  
  /**
   * Factory method corresponding to constructor 'NavigateOptionsKeyListener(Select)'.
   * @param {Select} $outer_this
   * @return {!NavigateOptionsKeyListener}
   * @public
   */
  static $create__org_dominokit_domino_ui_forms_Select($outer_this) {
    NavigateOptionsKeyListener.$clinit();
    let $instance = new NavigateOptionsKeyListener();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener__org_dominokit_domino_ui_forms_Select($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NavigateOptionsKeyListener(Select)'.
   * @param {Select} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener__org_dominokit_domino_ui_forms_Select($outer_this) {
    this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener = $outer_this;
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {Event} evt
   * @return {void}
   * @public
   */
  handleEvent(evt) {
    let keyboardEvent = /**@type {KeyboardEvent} */ ($Casts.$to(evt, $Overlay));
    let element = /**@type {HTMLElement} */ (Js.m_uncheckedCast__java_lang_Object(keyboardEvent.target));
    for (let $iterator = this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let option = /**@type {SelectOption} */ ($Casts.$to($iterator.m_next__(), SelectOption));
      if (option.m_asElement__().contains(element)) {
        if (ElementUtil.m_isKeyOf__java_lang_String__elemental2_dom_KeyboardEvent("ArrowUp", keyboardEvent)) {
          this.m_focusPrev__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener(option);
          evt.preventDefault();
        } else if (ElementUtil.m_isKeyOf__java_lang_String__elemental2_dom_KeyboardEvent("ArrowDown", keyboardEvent)) {
          this.m_focusNext__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener(option);
          evt.preventDefault();
        }
        if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(keyboardEvent) || ElementUtil.m_isSpaceKey__elemental2_dom_KeyboardEvent(keyboardEvent) || ElementUtil.m_isKeyOf__java_lang_String__elemental2_dom_KeyboardEvent("tab", keyboardEvent)) {
          this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.m_doSelectOption__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option);
          evt.preventDefault();
        }
      }
    }
  }
  
  /**
   * @param {SelectOption} option
   * @return {void}
   * @public
   */
  m_focusNext__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener(option) {
    let i = this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.indexOf(option);
    if (i == this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.size() - 1) {
      /**@type {SelectOption} */ ($Casts.$to(this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(0), SelectOption)).m_focus__();
    } else {
      /**@type {SelectOption} */ ($Casts.$to(this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(i + 1), SelectOption)).m_focus__();
    }
  }
  
  /**
   * @param {SelectOption} option
   * @return {void}
   * @public
   */
  m_focusPrev__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener(option) {
    let i = this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.indexOf(option);
    if (i == 0) {
      /**@type {SelectOption} */ ($Casts.$to(this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.size() - 1), SelectOption)).m_focus__();
    } else {
      /**@type {SelectOption} */ ($Casts.$to(this.f_$outer_this__org_dominokit_domino_ui_forms_Select_NavigateOptionsKeyListener.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(i - 1), SelectOption)).m_focus__();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NavigateOptionsKeyListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NavigateOptionsKeyListener);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NavigateOptionsKeyListener.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.KeyboardEvent.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NavigateOptionsKeyListener, $Util.$makeClassName('org.dominokit.domino.ui.forms.Select$NavigateOptionsKeyListener'));




exports = NavigateOptionsKeyListener; 
//# sourceMappingURL=Select$NavigateOptionsKeyListener.js.map