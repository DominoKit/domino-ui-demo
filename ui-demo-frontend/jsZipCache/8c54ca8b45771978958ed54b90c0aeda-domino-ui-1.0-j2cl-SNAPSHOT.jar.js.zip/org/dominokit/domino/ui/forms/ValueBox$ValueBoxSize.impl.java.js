/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.ValueBox$ValueBoxSize.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.ValueBox.ValueBoxSize$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<ValueBoxSize>}
  */
class ValueBoxSize extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_sizeValue__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_;
  }
  
  /**
   * Factory method corresponding to constructor 'ValueBoxSize(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} sizeValue
   * @return {!ValueBoxSize}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, sizeValue) {
    let $instance = new ValueBoxSize();
    $instance.$ctor__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize__java_lang_String__int__java_lang_String($name, $ordinal, sizeValue);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ValueBoxSize(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} sizeValue
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize__java_lang_String__int__java_lang_String($name, $ordinal, sizeValue) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_sizeValue__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_ = sizeValue;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return "form-group" + j_l_String.m_valueOf__java_lang_Object((j_l_String.m_isEmpty__java_lang_String(this.f_sizeValue__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_) ? "" : "-" + j_l_String.m_valueOf__java_lang_Object(this.f_sizeValue__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_)));
  }
  
  /**
   * @param {string} name
   * @return {!ValueBoxSize}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    ValueBoxSize.$clinit();
    if ($Equality.$same(ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_, null)) {
      ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_ = $Enums.createMapFromValues(ValueBoxSize.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_);
  }
  
  /**
   * @return {!Array<!ValueBoxSize>}
   * @public
   */
  static m_values__() {
    ValueBoxSize.$clinit();
    return /**@type {!Array<ValueBoxSize>} */ ($Arrays.$init([ValueBoxSize.$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize, ValueBoxSize.$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize, ValueBoxSize.$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize], ValueBoxSize));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {ValueBoxSize} */ ($Casts.$to(arg0, ValueBoxSize)));
  }
  
  /**
   * @return {!ValueBoxSize}
   * @public
   */
  static get f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize() {
    return (ValueBoxSize.$clinit(), ValueBoxSize.$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize);
  }
  
  /**
   * @param {!ValueBoxSize} value
   * @return {void}
   * @public
   */
  static set f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize(value) {
    (ValueBoxSize.$clinit(), ValueBoxSize.$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = value);
  }
  
  /**
   * @return {!ValueBoxSize}
   * @public
   */
  static get f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize() {
    return (ValueBoxSize.$clinit(), ValueBoxSize.$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize);
  }
  
  /**
   * @param {!ValueBoxSize} value
   * @return {void}
   * @public
   */
  static set f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize(value) {
    (ValueBoxSize.$clinit(), ValueBoxSize.$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = value);
  }
  
  /**
   * @return {!ValueBoxSize}
   * @public
   */
  static get f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize() {
    return (ValueBoxSize.$clinit(), ValueBoxSize.$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize);
  }
  
  /**
   * @param {!ValueBoxSize} value
   * @return {void}
   * @public
   */
  static set f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize(value) {
    (ValueBoxSize.$clinit(), ValueBoxSize.$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = value);
  }
  
  /**
   * @return {Map<?string, !ValueBoxSize>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_() {
    return (ValueBoxSize.$clinit(), ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_);
  }
  
  /**
   * @param {Map<?string, !ValueBoxSize>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_(value) {
    (ValueBoxSize.$clinit(), ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ValueBoxSize;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ValueBoxSize);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ValueBoxSize.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    ValueBoxSize.$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = ValueBoxSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("LARGE"), ValueBoxSize.$ordinal$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize, "lg");
    ValueBoxSize.$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = ValueBoxSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("SMALL"), ValueBoxSize.$ordinal$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize, "sm");
    ValueBoxSize.$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = ValueBoxSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("DEFAULT"), ValueBoxSize.$ordinal$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize, "");
    ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(ValueBoxSize, $Util.$makeClassName('org.dominokit.domino.ui.forms.ValueBox$ValueBoxSize'));


/** @private {!ValueBoxSize} */
ValueBoxSize.$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize;


/** @private {!ValueBoxSize} */
ValueBoxSize.$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize;


/** @private {!ValueBoxSize} */
ValueBoxSize.$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize;


/** @private {Map<?string, !ValueBoxSize>} */
ValueBoxSize.$f_namesToValuesMap__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_;


/** @public {number} @const */
ValueBoxSize.$ordinal$f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = 0;


/** @public {number} @const */
ValueBoxSize.$ordinal$f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = 1;


/** @public {number} @const */
ValueBoxSize.$ordinal$f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize = 2;




exports = ValueBoxSize; 
//# sourceMappingURL=ValueBox$ValueBoxSize.js.map