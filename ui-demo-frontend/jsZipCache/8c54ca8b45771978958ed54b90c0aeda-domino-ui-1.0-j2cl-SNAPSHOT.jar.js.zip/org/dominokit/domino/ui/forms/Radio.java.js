/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Radio.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.Radio');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Checkable = goog.require('org.dominokit.domino.ui.utils.Checkable');
const _HasLabel = goog.require('org.dominokit.domino.ui.utils.HasLabel');
const _HasName = goog.require('org.dominokit.domino.ui.utils.HasName');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLInputElement_$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _HTMLLabelElement_$Overlay = goog.require('elemental2.dom.HTMLLabelElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$LambdaAdaptor$21 = goog.require('org.dominokit.domino.ui.forms.Radio.$LambdaAdaptor$21');
const _$LambdaAdaptor$22 = goog.require('org.dominokit.domino.ui.forms.Radio.$LambdaAdaptor$22');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _CheckHandler = goog.require('org.dominokit.domino.ui.utils.Checkable.CheckHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Radio = goog.require('org.dominokit.domino.ui.forms.Radio$impl');
exports = Radio;
 