/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select$SelectionHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.Select.SelectionHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler.$LambdaAdaptor');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');


// Re-exports the implementation.
var SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
exports = SelectionHandler;
 