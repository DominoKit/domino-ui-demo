/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerMonth.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerMonth$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler$impl');
const HasSelectSupport = goog.require('org.dominokit.domino.ui.utils.HasSelectSupport$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let JsDate_$Overlay = goog.forwardDeclare('elemental2.core.JsDate.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLTableElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableElement.$Overlay$impl');
let HTMLTableRowElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
let HTMLTableSectionElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let j_u_Date = goog.forwardDeclare('java.util.Date$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let DatePickerElement = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
let DaySelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler$impl');
let MonthContext = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.MonthContext$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let TextUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextUtil$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasSelectSupport<DatePickerElement>}
 * @implements {HasValue<j_u_Date>}
 * @implements {SelectionHandler}
  */
class DatePickerMonth extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DaySelectionHandler} */
    this.f_internalHandler__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {Date} */
    this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {DateTimeFormatInfo} */
    this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {Array<Array<DatePickerElement>>} */
    this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {List<DaySelectionHandler>} */
    this.f_daySelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {DatePickerElement} */
    this.f_selectedElement__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {Color} */
    this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerMonth(JsDate, DateTimeFormatInfo, DaySelectionHandler)'.
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {DaySelectionHandler} daySelectionHandler
   * @return {!DatePickerMonth}
   * @public
   */
  static $create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(date, dateTimeFormatInfo, daySelectionHandler) {
    DatePickerMonth.$clinit();
    let $instance = new DatePickerMonth();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePickerMonth__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(date, dateTimeFormatInfo, daySelectionHandler);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerMonth(JsDate, DateTimeFormatInfo, DaySelectionHandler)'.
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {DaySelectionHandler} daySelectionHandler
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePickerMonth__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(date, dateTimeFormatInfo, daySelectionHandler) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePickerMonth();
    this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = date;
    this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = dateTimeFormatInfo;
    this.f_internalHandler__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = daySelectionHandler;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_init__() {
    this.m_createMarkup___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth();
    this.m_update___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth();
  }
  
  /**
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {DaySelectionHandler} daySelectionHandler
   * @return {DatePickerMonth}
   * @public
   */
  static m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(date, dateTimeFormatInfo, daySelectionHandler) {
    DatePickerMonth.$clinit();
    return DatePickerMonth.$create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(date, dateTimeFormatInfo, daySelectionHandler);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_createMarkup___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth() {
    let table = /**@type {HtmlContentBuilder<HTMLTableElement>} */ ($Casts.$to(Elements.m_table__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["date-picker"], j_l_String))), HtmlContentBuilder));
    let thead = /**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ ($Casts.$to(Elements.m_thead__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(DatePickerElement.m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_).m_getElement__()), IsElement))), HtmlContentBuilder));
    /**@type {HtmlContentBuilder<HTMLTableElement>} */ ($Casts.$to(table.m_add__org_jboss_gwt_elemento_core_IsElement(thead), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ ($Casts.$to(Elements.m_tbody__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(1, 6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(2, 6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(3, 6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(4, 6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(5, 6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 0, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 1, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 2, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 3, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 4, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 5, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_td__().m_add__elemental2_dom_Node(DatePickerElement.m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(6, 6, this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_, this).m_getElement__()), IsElement))), IsElement))), IsElement)));
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerMonth_.appendChild(table.m_asElement__());
  }
  
  /**
   * @param {Date} jsDate
   * @return {void}
   * @public
   */
  m_update__elemental2_core_JsDate_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(jsDate) {
    this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = jsDate;
    this.m_update___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_update___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth() {
    let monthContext = MonthContext.$create__int__int(this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_.getFullYear(), this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_.getMonth());
    this.m_fillWeekHeader___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth();
    this.m_fillCurrentAndNextMonth__org_dominokit_domino_ui_datepicker_MonthContext_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext);
    this.m_fillPreviousMonth__org_dominokit_domino_ui_datepicker_MonthContext_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext);
  }
  
  /**
   * @param {MonthContext} monthContext
   * @return {void}
   * @public
   */
  m_fillPreviousMonth__org_dominokit_domino_ui_datepicker_MonthContext_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext) {
    let columnIndex = monthContext.m_getFirstDay__() - this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_firstDayOfTheWeek__();
    if (columnIndex < 0) {
      columnIndex = 7 + columnIndex;
    }
    let fillEnd = columnIndex == 0 ? 7 : columnIndex;
    let monthBefore = monthContext.m_getMonthBefore__();
    let monthBeforeDay = monthBefore.m_getDays__();
    for (let i = fillEnd - 1; i >= 0; i--) {
      let datePickerElement = this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_[1][i];
      this.m_fillPreviousMonthDay__org_dominokit_domino_ui_datepicker_MonthContext__int__int__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext, monthBeforeDay, i, datePickerElement);
      monthBeforeDay--;
    }
  }
  
  /**
   * @param {MonthContext} monthContext
   * @return {void}
   * @public
   */
  m_fillCurrentAndNextMonth__org_dominokit_domino_ui_datepicker_MonthContext_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext) {
    let columnIndex = monthContext.m_getFirstDay__() - this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_firstDayOfTheWeek__();
    if (columnIndex < 0) {
      columnIndex = 7 + columnIndex;
    }
    let startRow = 1;
    if (columnIndex == 0) {
      startRow = 2;
    }
    let dayNumber = 1;
    let row = startRow;
    let /** number */ column;
    let nextMonthDay = 1;
    for (; dayNumber <= monthContext.m_getDays__() || row < 7; row++) {
      for (column = columnIndex; column < 7; column++) {
        let datePickerElement = this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_[row][column];
        if (dayNumber <= monthContext.m_getDays__()) {
          this.m_fillMonthDay__org_dominokit_domino_ui_datepicker_MonthContext__int__int__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext, dayNumber, column, datePickerElement);
          dayNumber++;
        } else {
          this.m_fillNextMonthDay__org_dominokit_domino_ui_datepicker_MonthContext__int__int__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext, column, nextMonthDay, datePickerElement);
          nextMonthDay++;
        }
      }
      columnIndex = 0;
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_fillWeekHeader___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth() {
    let days = this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_weekdaysShort__();
    let daysFull = this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_weekdaysFull__();
    let startIndex = this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_firstDayOfTheWeek__();
    for (let y = 0; y < 7; y++) {
      this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_[0][y].m_setText__java_lang_String(days[startIndex]);
      $Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_[0][y].m_getElement__(), "title", TextUtil.m_firstLetterToUpper__java_lang_String(daysFull[startIndex]));
      startIndex++;
      if (startIndex >= 7) {
        startIndex = 0;
      }
    }
  }
  
  /**
   * @param {MonthContext} monthContext
   * @param {number} monthBeforeDay
   * @param {number} i
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_fillPreviousMonthDay__org_dominokit_domino_ui_datepicker_MonthContext__int__int__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext, monthBeforeDay, i, datePickerElement) {
    datePickerElement.m_setText__java_lang_String(monthBeforeDay + "");
    datePickerElement.m_setWeekDay__int(i);
    datePickerElement.m_setYear__int(monthContext.m_getMonth__() > 0 ? monthContext.m_getYear__() : monthContext.m_getYear__() - 1);
    datePickerElement.m_setMonth__int(monthContext.m_getMonth__() > 0 ? monthContext.m_getMonth__() - 1 : 11);
    datePickerElement.m_setDay__int(monthBeforeDay);
    this.m_styleOtherMonth__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement);
  }
  
  /**
   * @param {MonthContext} monthContext
   * @param {number} column
   * @param {number} nextMonthDay
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_fillNextMonthDay__org_dominokit_domino_ui_datepicker_MonthContext__int__int__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext, column, nextMonthDay, datePickerElement) {
    datePickerElement.m_setText__java_lang_String(nextMonthDay + "");
    datePickerElement.m_setWeekDay__int(column);
    datePickerElement.m_setYear__int(monthContext.m_getMonth__() < 11 ? monthContext.m_getYear__() : monthContext.m_getYear__() + 1);
    datePickerElement.m_setMonth__int(monthContext.m_getMonth__() < 11 ? monthContext.m_getMonth__() + 1 : 0);
    datePickerElement.m_setDay__int(nextMonthDay);
    this.m_styleOtherMonth__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement);
  }
  
  /**
   * @param {MonthContext} monthContext
   * @param {number} dayNumber
   * @param {number} column
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_fillMonthDay__org_dominokit_domino_ui_datepicker_MonthContext__int__int__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(monthContext, dayNumber, column, datePickerElement) {
    datePickerElement.m_setText__java_lang_String(dayNumber + "");
    this.m_styleCurrentMonth__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement);
    datePickerElement.m_setWeekDay__int(column);
    datePickerElement.m_setYear__int(monthContext.m_getYear__());
    datePickerElement.m_setMonth__int(monthContext.m_getMonth__());
    datePickerElement.m_setDay__int(dayNumber);
    if (dayNumber == this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_.getDate()) {
      this.m_selectElement__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement);
    }
  }
  
  /**
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_styleOtherMonth__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement) {
    datePickerElement.m_getElement__().classList.remove("other-month");
    datePickerElement.m_getElement__().classList.remove("current-month");
    datePickerElement.m_getElement__().classList.add("other-month");
  }
  
  /**
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_styleCurrentMonth__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement) {
    datePickerElement.m_getElement__().classList.remove("other-month");
    datePickerElement.m_getElement__().classList.remove("current-month");
    datePickerElement.m_getElement__().classList.add("current-month");
  }
  
  /**
   * @param {DaySelectionHandler} daySelectionHandler
   * @return {void}
   * @public
   */
  m_addDaySelectionHandler__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(daySelectionHandler) {
    this.f_daySelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerMonth_.add(daySelectionHandler);
  }
  
  /**
   * @param {DaySelectionHandler} daySelectionHandler
   * @return {void}
   * @public
   */
  m_removeDaySelectionHandler__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(daySelectionHandler) {
    this.f_daySelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerMonth_.remove(daySelectionHandler);
  }
  
  /**
   * @return {List<DaySelectionHandler>}
   * @public
   */
  m_getDaySelectionHandlers__() {
    return this.f_daySelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_clearDaySelectionHandlers__() {
    this.f_daySelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerMonth_.clear();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
  }
  
  /**
   * @override
   * @return {DatePickerElement}
   * @public
   */
  m_getSelectedItem__() {
    return this.f_selectedElement__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
  }
  
  /**
   * @param {j_u_Date} value
   * @return {void}
   * @public
   */
  m_setValue__java_util_Date(value) {
    this.m_update__elemental2_core_JsDate_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(new Date($Primitives.$widenLongToDouble(value.m_getTime__())));
  }
  
  /**
   * @override
   * @return {j_u_Date}
   * @public
   */
  m_getValue__() {
    return j_u_Date.$create__long(Double.m_longValue__java_lang_Double(Double.$create__double(this.m_getSelectedItem__().m_getDate__().getTime())));
  }
  
  /**
   * @override
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_selectElement__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement) {
    if (this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_.getFullYear() == datePickerElement.m_getDate__().getFullYear() && this.f_date__org_dominokit_domino_ui_datepicker_DatePickerMonth_.getMonth() == datePickerElement.m_getDate__().getMonth()) {
      this.m_deselect___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth();
      this.m_select__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement);
    } else {
      this.m_update__elemental2_core_JsDate_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement.m_getDate__());
    }
  }
  
  /**
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_select__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement) {
    datePickerElement.m_select__();
    datePickerElement.m_getElement__().classList.add(this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_getBackground__());
    this.f_selectedElement__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = datePickerElement;
    if (Objects.m_nonNull__java_lang_Object(this.f_internalHandler__org_dominokit_domino_ui_datepicker_DatePickerMonth_)) {
      this.f_internalHandler__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_onDaySelected__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement);
    }
    this.m_informSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_deselect___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth() {
    if (Objects.m_nonNull__java_lang_Object(this.f_selectedElement__org_dominokit_domino_ui_datepicker_DatePickerMonth_)) {
      this.f_selectedElement__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_deselect__();
      this.f_selectedElement__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_getElement__().classList.remove(this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_getBackground__());
    }
  }
  
  /**
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_informSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerElement_$p_org_dominokit_domino_ui_datepicker_DatePickerMonth(datePickerElement) {
    this.m_getDaySelectionHandlers__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DaySelectionHandler */ daySelectionHandler) =>{
      daySelectionHandler.m_onDaySelected__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement);
    })));
  }
  
  /**
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {void}
   * @public
   */
  m_setDateTimeFormatInfo__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo) {
    this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = dateTimeFormatInfo;
    this.m_update___$p_org_dominokit_domino_ui_datepicker_DatePickerMonth();
  }
  
  /**
   * @return {DateTimeFormatInfo}
   * @public
   */
  m_getDateTimeFormatInfo__() {
    return this.f_dateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_;
  }
  
  /**
   * @param {Color} background
   * @return {void}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    this.m_getSelectedItem__().m_getElement__().classList.remove(this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_getBackground__());
    this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = background;
    this.m_getSelectedItem__().m_getElement__().classList.add(this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_.m_getBackground__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_util_Date(/**@type {j_u_Date} */ ($Casts.$to(arg0, j_u_Date)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datepicker_DatePickerMonth() {
    this.f_monthData__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = /**@type {!Array<Array<DatePickerElement>>} */ ($Arrays.$create([7, 7], DatePickerElement));
    this.f_daySelectionHandlers__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = /**@type {!ArrayList<DaySelectionHandler>} */ (ArrayList.$create__());
    this.f_background__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color;
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerMonth_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["date-picker-container"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerMonth;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerMonth);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerMonth.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    j_u_Date = goog.module.get('java.util.Date$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    DatePickerElement = goog.module.get('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
    MonthContext = goog.module.get('org.dominokit.domino.ui.datepicker.MonthContext$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    TextUtil = goog.module.get('org.dominokit.domino.ui.utils.TextUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerMonth, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePickerMonth'));


IsElement.$markImplementor(DatePickerMonth);
HasSelectSupport.$markImplementor(DatePickerMonth);
HasValue.$markImplementor(DatePickerMonth);
SelectionHandler.$markImplementor(DatePickerMonth);


exports = DatePickerMonth; 
//# sourceMappingURL=DatePickerMonth.js.map