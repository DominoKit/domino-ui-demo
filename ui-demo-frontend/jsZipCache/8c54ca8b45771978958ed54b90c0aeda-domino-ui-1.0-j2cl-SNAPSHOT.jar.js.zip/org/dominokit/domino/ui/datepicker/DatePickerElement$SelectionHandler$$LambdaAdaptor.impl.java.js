/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerElement$SelectionHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler$impl');

let DatePickerElement = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');


/**
 * @implements {SelectionHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(DatePickerElement):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(DatePickerElement):void} */
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$LambdaAdaptor__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(DatePickerElement):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$LambdaAdaptor__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {DatePickerElement} arg0
   * @return {void}
   * @public
   */
  m_selectElement__org_dominokit_domino_ui_datepicker_DatePickerElement(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePickerElement$SelectionHandler$$LambdaAdaptor'));


SelectionHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DatePickerElement$SelectionHandler$$LambdaAdaptor.js.map