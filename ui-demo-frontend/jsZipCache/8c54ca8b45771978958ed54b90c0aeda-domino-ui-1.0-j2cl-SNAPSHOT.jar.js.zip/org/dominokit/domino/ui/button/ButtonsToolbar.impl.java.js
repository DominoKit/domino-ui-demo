/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.ButtonsToolbar.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.ButtonsToolbar$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class ButtonsToolbar extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_;
  }
  
  /**
   * Factory method corresponding to constructor 'ButtonsToolbar()'.
   * @return {!ButtonsToolbar}
   * @public
   */
  static $create__() {
    ButtonsToolbar.$clinit();
    let $instance = new ButtonsToolbar();
    $instance.$ctor__org_dominokit_domino_ui_button_ButtonsToolbar__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ButtonsToolbar()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_ButtonsToolbar__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_button_ButtonsToolbar();
  }
  
  /**
   * @return {ButtonsToolbar}
   * @public
   */
  static m_create__() {
    ButtonsToolbar.$clinit();
    return ButtonsToolbar.$create__();
  }
  
  /**
   * @param {ButtonsGroup} group
   * @return {ButtonsToolbar}
   * @public
   */
  m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(group) {
    this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_.appendChild(group.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_ButtonsToolbar() {
    this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_ = /**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["btn-toolbar"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "toolbar"), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsToolbar;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsToolbar);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ButtonsToolbar.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ButtonsToolbar, $Util.$makeClassName('org.dominokit.domino.ui.button.ButtonsToolbar'));


IsElement.$markImplementor(ButtonsToolbar);


exports = ButtonsToolbar; 
//# sourceMappingURL=ButtonsToolbar.js.map