/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.Button.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.Button$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const WavesElement = goog.require('org.dominokit.domino.ui.style.WavesElement$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');
const HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent$impl');
const HasStyleProperty = goog.require('org.dominokit.domino.ui.utils.HasStyleProperty$impl');
const IsHtmlComponent = goog.require('org.dominokit.domino.ui.utils.IsHtmlComponent$impl');
const Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable$impl');
const Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLButtonElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ButtonSize = goog.forwardDeclare('org.dominokit.domino.ui.button.ButtonSize$impl');
let CircleSize = goog.forwardDeclare('org.dominokit.domino.ui.button.CircleSize$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let WaveStyle = goog.forwardDeclare('org.dominokit.domino.ui.style.WaveStyle$impl');
let HtmlComponentBuilder = goog.forwardDeclare('org.dominokit.domino.ui.utils.HtmlComponentBuilder$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {WavesElement<Button, HTMLElement>}
 * @implements {Justifiable}
 * @implements {HasClickableElement}
 * @implements {Sizable<Button>}
 * @implements {HasBackground<Button>}
 * @implements {HasContent<Button>}
 * @implements {IsElement<HTMLElement>}
 * @implements {IsHtmlComponent<HTMLElement, Button>}
 * @implements {HasStyleProperty<Button>}
 * @implements {Switchable<Button>}
  */
class Button extends WavesElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_buttonElement__org_dominokit_domino_ui_button_Button;
    /** @public {StyleType} */
    this.f_type__org_dominokit_domino_ui_button_Button_;
    /** @public {Color} */
    this.f_background__org_dominokit_domino_ui_button_Button_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_button_Button_;
    /** @public {ButtonSize} */
    this.f_size__org_dominokit_domino_ui_button_Button_;
    /** @public {?string} */
    this.f_content__org_dominokit_domino_ui_button_Button;
    /** @public {HtmlComponentBuilder<HTMLElement, Button>} */
    this.f_buttonComponentBuilder__org_dominokit_domino_ui_button_Button_;
  }
  
  /**
   * @param {?string} content
   * @param {StyleType} type
   * @return {Button}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, type) {
    Button.$clinit();
    return Button.$create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
  }
  
  /**
   * @return {Button}
   * @public
   */
  static m_create__() {
    Button.$clinit();
    return Button.$create__();
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_create__java_lang_String(content) {
    Button.$clinit();
    return Button.$create__java_lang_String(content);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createDefault__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createPrimary__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createSuccess__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createInfo__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createWarning__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createDanger__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * Factory method corresponding to constructor 'Button()'.
   * @return {!Button}
   * @public
   */
  static $create__() {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__() {
    this.$ctor__org_dominokit_domino_ui_style_WavesElement__();
    this.$init__org_dominokit_domino_ui_button_Button();
    super.m_init__org_jboss_gwt_elemento_core_IsElement__elemental2_dom_HTMLElement(this, this.f_buttonElement__org_dominokit_domino_ui_button_Button);
  }
  
  /**
   * Factory method corresponding to constructor 'Button(String)'.
   * @param {?string} content
   * @return {!Button}
   * @public
   */
  static $create__java_lang_String(content) {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__java_lang_String(content) {
    this.$ctor__org_dominokit_domino_ui_button_Button__();
    this.m_setContent__java_lang_String(content);
  }
  
  /**
   * Factory method corresponding to constructor 'Button(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {!Button}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_button_Button__java_lang_String(content);
    this.m_setButtonType__org_dominokit_domino_ui_style_StyleType(type);
  }
  
  /**
   * @override
   * @param {?string} content
   * @return {Button}
   * @public
   */
  m_setContent__java_lang_String(content) {
    this.f_content__org_dominokit_domino_ui_button_Button = content;
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.textContent = this.f_content__org_dominokit_domino_ui_button_Button;
    return this;
  }
  
  /**
   * @param {ButtonSize} size
   * @return {Button}
   * @public
   */
  m_setSize__org_dominokit_domino_ui_button_ButtonSize(size) {
    if (Objects.m_nonNull__java_lang_Object(this.f_size__org_dominokit_domino_ui_button_Button_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.remove("btn-" + j_l_String.m_valueOf__java_lang_Object(this.f_size__org_dominokit_domino_ui_button_Button_.m_getStyle__()));
    }
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add("btn-" + j_l_String.m_valueOf__java_lang_Object(size.m_getStyle__()));
    this.f_size__org_dominokit_domino_ui_button_Button_ = size;
    return this;
  }
  
  /**
   * @param {boolean} block
   * @return {Button}
   * @public
   */
  m_setBlock__boolean(block) {
    if (block) {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add("btn-block");
    } else {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.remove("btn-block");
    }
    return this;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Button}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_Button_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.remove("btn-" + j_l_String.m_valueOf__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_Button_.m_getStyle__()));
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_background__org_dominokit_domino_ui_button_Button_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.remove(this.f_background__org_dominokit_domino_ui_button_Button_.m_getBackground__());
    }
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add(background.m_getBackground__());
    this.f_background__org_dominokit_domino_ui_button_Button_ = background;
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {Button}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_color__org_dominokit_domino_ui_button_Button_)) {
      this.m_asElement__().classList.remove(this.f_color__org_dominokit_domino_ui_button_Button_.m_getStyle__());
    }
    this.f_color__org_dominokit_domino_ui_button_Button_ = color;
    this.m_asElement__().classList.add(this.f_color__org_dominokit_domino_ui_button_Button_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {StyleType} type
   * @return {Button}
   * @public
   */
  m_setButtonType__org_dominokit_domino_ui_style_StyleType(type) {
    if (Objects.m_nonNull__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_Button_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.remove("btn-" + j_l_String.m_valueOf__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_Button_.m_getStyle__()));
    }
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add("btn-" + j_l_String.m_valueOf__java_lang_Object(type.m_getStyle__()));
    this.f_type__org_dominokit_domino_ui_button_Button_ = type;
    return this;
  }
  
  /**
   * @override
   * @return {Button}
   * @public
   */
  m_disable__() {
    $Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_buttonElement__org_dominokit_domino_ui_button_Button, Button.f_DISABLED__org_dominokit_domino_ui_button_Button_, Button.f_DISABLED__org_dominokit_domino_ui_button_Button_);
    return this;
  }
  
  /**
   * @override
   * @return {Button}
   * @public
   */
  m_enable__() {
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.removeAttribute(Button.f_DISABLED__org_dominokit_domino_ui_button_Button_);
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return !this.f_buttonElement__org_dominokit_domino_ui_button_Button.hasAttribute(Button.f_DISABLED__org_dominokit_domino_ui_button_Button_);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_buttonElement__org_dominokit_domino_ui_button_Button;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_justify__() {
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([this.m_asElement__().className], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "button"), HtmlContentBuilder)).m_textContent__java_lang_String(this.m_asElement__().textContent), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.m_asElement__();
  }
  
  /**
   * @param {Node} node
   * @return {Button}
   * @public
   */
  m_appendContent__elemental2_dom_Node(node) {
    this.m_asElement__().appendChild(node);
    return this;
  }
  
  /**
   * @override
   * @return {Button}
   * @public
   */
  m_large__() {
    this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
    return this;
  }
  
  /**
   * @override
   * @return {Button}
   * @public
   */
  m_small__() {
    this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
    return this;
  }
  
  /**
   * @override
   * @return {Button}
   * @public
   */
  m_xSmall__() {
    this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
    return this;
  }
  
  /**
   * @return {Button}
   * @public
   */
  m_block__() {
    this.m_setBlock__boolean(true);
    return this;
  }
  
  /**
   * @return {Button}
   * @public
   */
  m_linkify__() {
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add("btn-link");
    return this;
  }
  
  /**
   * @param {EventListener} listener
   * @return {Button}
   * @public
   */
  m_addClickListener__elemental2_dom_EventListener(listener) {
    this.m_getClickableElement__().addEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), listener);
    return this;
  }
  
  /**
   * @param {CircleSize} size
   * @return {Button}
   * @public
   */
  m_circle__org_dominokit_domino_ui_button_CircleSize(size) {
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add(size.m_getStyle__());
    this.m_applyCircleWaves___$p_org_dominokit_domino_ui_button_Button();
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_applyCircleWaves___$p_org_dominokit_domino_ui_button_Button() {
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_CIRCLE__org_dominokit_domino_ui_style_WaveStyle);
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_FLOAT__org_dominokit_domino_ui_style_WaveStyle);
  }
  
  /**
   * @override
   * @return {HtmlComponentBuilder<HTMLElement, Button>}
   * @public
   */
  m_htmlBuilder__() {
    return this.f_buttonComponentBuilder__org_dominokit_domino_ui_button_Button_;
  }
  
  /**
   * @override
   * @param {?string} name
   * @param {?string} value
   * @return {Button}
   * @public
   */
  m_setStyleProperty__java_lang_String__java_lang_String(name, value) {
    this.m_asElement__().style.setProperty(name, value);
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_Button() {
    this.f_buttonElement__org_dominokit_domino_ui_button_Button = /**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(Elements.m_button__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["btn"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_buttonComponentBuilder__org_dominokit_domino_ui_button_Button_ = /**@type {!HtmlComponentBuilder<HTMLElement, Button>} */ (HtmlComponentBuilder.$create__org_jboss_gwt_elemento_core_IsElement(this));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Button;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Button);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Button.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    ButtonSize = goog.module.get('org.dominokit.domino.ui.button.ButtonSize$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    WaveStyle = goog.module.get('org.dominokit.domino.ui.style.WaveStyle$impl');
    HtmlComponentBuilder = goog.module.get('org.dominokit.domino.ui.utils.HtmlComponentBuilder$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    WavesElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Button, $Util.$makeClassName('org.dominokit.domino.ui.button.Button'));


/** @public {?string} @const */
Button.f_DISABLED__org_dominokit_domino_ui_button_Button_ = "disabled";


Justifiable.$markImplementor(Button);
HasClickableElement.$markImplementor(Button);
Sizable.$markImplementor(Button);
HasBackground.$markImplementor(Button);
HasContent.$markImplementor(Button);
IsElement.$markImplementor(Button);
IsHtmlComponent.$markImplementor(Button);
HasStyleProperty.$markImplementor(Button);
Switchable.$markImplementor(Button);


exports = Button; 
//# sourceMappingURL=Button.js.map