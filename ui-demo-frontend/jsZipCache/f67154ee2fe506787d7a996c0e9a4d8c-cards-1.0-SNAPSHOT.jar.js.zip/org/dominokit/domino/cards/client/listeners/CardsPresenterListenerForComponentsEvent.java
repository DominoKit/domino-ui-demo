package org.dominokit.domino.cards.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.cards.client.presenters.CardsPresenterCommand;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class CardsPresenterListenerForComponentsEvent implements DominoEventListener<ComponentsEvent> {
  @Override
  public void listen(ComponentsEvent event) {
    new CardsPresenterCommand().onPresenterReady(presenter -> presenter.onComponentsEvent(event.context())).send();
  }
}
