/**
 * @fileoverview transpiled from org.dominokit.domino.cards.client.presenters.CardsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.cards.client.presenters.CardsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let CardsPresenter = goog.forwardDeclare('org.dominokit.domino.cards.client.presenters.CardsPresenter$impl');


/**
 * @extends {PresenterCommand<CardsPresenter>}
  */
class CardsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CardsPresenterCommand()'.
   * @return {!CardsPresenterCommand}
   * @public
   */
  static $create__() {
    CardsPresenterCommand.$clinit();
    let $instance = new CardsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_cards_client_presenters_CardsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CardsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_cards_client_presenters_CardsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CardsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CardsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CardsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CardsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.cards.client.presenters.CardsPresenterCommand'));




exports = CardsPresenterCommand; 
//# sourceMappingURL=CardsPresenterCommand.js.map