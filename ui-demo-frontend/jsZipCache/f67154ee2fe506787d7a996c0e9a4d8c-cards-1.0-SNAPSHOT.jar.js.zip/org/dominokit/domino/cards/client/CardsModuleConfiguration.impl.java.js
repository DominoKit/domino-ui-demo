/**
 * @fileoverview transpiled from org.dominokit.domino.cards.client.CardsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.cards.client.CardsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.cards.client.CardsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.cards.client.CardsModuleConfiguration.$2$impl');
let CardsPresenterListenerForComponentsEvent = goog.forwardDeclare('org.dominokit.domino.cards.client.listeners.CardsPresenterListenerForComponentsEvent$impl');
let CardsPresenter = goog.forwardDeclare('org.dominokit.domino.cards.client.presenters.CardsPresenter$impl');
let CardsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.cards.client.presenters.CardsPresenterCommand$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');


/**
 * @implements {ModuleConfiguration}
  */
class CardsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CardsModuleConfiguration()'.
   * @return {!CardsModuleConfiguration}
   * @public
   */
  static $create__() {
    CardsModuleConfiguration.$clinit();
    let $instance = new CardsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_cards_client_CardsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CardsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_cards_client_CardsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_cards_client_CardsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(CardsPresenter).m_getCanonicalName__(), Class.$get(CardsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_cards_client_CardsModuleConfiguration__java_lang_String(this, Class.$get(CardsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(CardsPresenterCommand).m_getCanonicalName__(), Class.$get(CardsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentsEvent), CardsPresenterListenerForComponentsEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CardsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CardsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CardsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.cards.client.CardsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.cards.client.CardsModuleConfiguration.$2$impl');
    CardsPresenterListenerForComponentsEvent = goog.module.get('org.dominokit.domino.cards.client.listeners.CardsPresenterListenerForComponentsEvent$impl');
    CardsPresenter = goog.module.get('org.dominokit.domino.cards.client.presenters.CardsPresenter$impl');
    CardsPresenterCommand = goog.module.get('org.dominokit.domino.cards.client.presenters.CardsPresenterCommand$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CardsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.cards.client.CardsModuleConfiguration'));


ModuleConfiguration.$markImplementor(CardsModuleConfiguration);


exports = CardsModuleConfiguration; 
//# sourceMappingURL=CardsModuleConfiguration.js.map