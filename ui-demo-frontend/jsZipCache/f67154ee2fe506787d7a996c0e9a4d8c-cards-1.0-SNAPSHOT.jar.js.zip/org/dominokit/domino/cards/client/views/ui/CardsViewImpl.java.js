/**
 * @fileoverview transpiled from org.dominokit.domino.cards.client.views.ui.CardsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.cards.client.views.ui.CardsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CardsView = goog.require('org.dominokit.domino.cards.client.views.CardsView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$10 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$10');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$11');
const _$LambdaAdaptor$12 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$12');
const _$LambdaAdaptor$13 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$13');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$15');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$16');
const _$LambdaAdaptor$17 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$17');
const _$LambdaAdaptor$18 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$18');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$19');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$20');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$3');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$4');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$5');
const _$LambdaAdaptor$6 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$6');
const _$LambdaAdaptor$7 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$7');
const _$LambdaAdaptor$8 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$8');
const _$LambdaAdaptor$9 = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$9');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CardsViewImpl = goog.require('org.dominokit.domino.cards.client.views.ui.CardsViewImpl$impl');
exports = CardsViewImpl;
 