/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _LoadersPresenter = goog.require('org.dominokit.domino.loaders.client.presenters.LoadersPresenter');


// Re-exports the implementation.
var LoadersPresenterCommand = goog.require('org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand$impl');
exports = LoadersPresenterCommand;
 