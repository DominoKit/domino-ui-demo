/**
 * @fileoverview transpiled from org.slf4j.ILoggerFactory$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.ILoggerFactory.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ILoggerFactory = goog.require('org.slf4j.ILoggerFactory');
const _Logger = goog.require('org.slf4j.Logger');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.slf4j.ILoggerFactory.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 