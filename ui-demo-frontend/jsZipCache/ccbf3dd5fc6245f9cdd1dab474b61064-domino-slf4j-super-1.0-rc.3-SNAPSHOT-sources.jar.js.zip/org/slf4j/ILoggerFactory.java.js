/**
 * @fileoverview transpiled from org.slf4j.ILoggerFactory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.ILoggerFactory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.slf4j.ILoggerFactory.$LambdaAdaptor');
const _Logger = goog.require('org.slf4j.Logger');


// Re-exports the implementation.
var ILoggerFactory = goog.require('org.slf4j.ILoggerFactory$impl');
exports = ILoggerFactory;
 