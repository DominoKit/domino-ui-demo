/**
 * @fileoverview transpiled from org.slf4j.helpers.NamedLoggerBase.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.helpers.NamedLoggerBase$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Logger = goog.require('org.slf4j.Logger$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let Marker = goog.forwardDeclare('org.slf4j.Marker$impl');


/**
 * @abstract
 * @implements {Logger}
  */
class NamedLoggerBase extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_slf4j_helpers_NamedLoggerBase;
  }
  
  /**
   * Initialization from constructor 'NamedLoggerBase()'.
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_helpers_NamedLoggerBase__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_slf4j_helpers_NamedLoggerBase;
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_debug__java_lang_String(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Array<*>} arg1
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__arrayOf_java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Throwable} arg1
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Throwable(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @param {*} arg3
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2, arg3) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Array<*>} arg2
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Throwable} arg2
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Throwable(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_error__java_lang_String(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Array<*>} arg1
   * @return {void}
   * @public
   */
  m_error__java_lang_String__arrayOf_java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Throwable} arg1
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Throwable(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @param {*} arg3
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2, arg3) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Array<*>} arg2
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Throwable} arg2
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Throwable(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_info__java_lang_String(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Array<*>} arg1
   * @return {void}
   * @public
   */
  m_info__java_lang_String__arrayOf_java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Throwable} arg1
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Throwable(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @param {*} arg3
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2, arg3) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Array<*>} arg2
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Throwable} arg2
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Throwable(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isDebugEnabled__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @return {boolean}
   * @public
   */
  m_isDebugEnabled__org_slf4j_Marker(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isErrorEnabled__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @return {boolean}
   * @public
   */
  m_isErrorEnabled__org_slf4j_Marker(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isInfoEnabled__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @return {boolean}
   * @public
   */
  m_isInfoEnabled__org_slf4j_Marker(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isTraceEnabled__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @return {boolean}
   * @public
   */
  m_isTraceEnabled__org_slf4j_Marker(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isWarnEnabled__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @return {boolean}
   * @public
   */
  m_isWarnEnabled__org_slf4j_Marker(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_trace__java_lang_String(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Array<*>} arg1
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__arrayOf_java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Throwable} arg1
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Throwable(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @param {*} arg3
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2, arg3) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Array<*>} arg2
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Throwable} arg2
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Throwable(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_warn__java_lang_String(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Array<*>} arg1
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__arrayOf_java_lang_Object(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {?string} arg0
   * @param {Throwable} arg1
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Throwable(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {*} arg2
   * @param {*} arg3
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(arg0, arg1, arg2, arg3) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Array<*>} arg2
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(arg0, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Marker} arg0
   * @param {?string} arg1
   * @param {Throwable} arg2
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Throwable(arg0, arg1, arg2) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NamedLoggerBase;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NamedLoggerBase);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NamedLoggerBase.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NamedLoggerBase, $Util.$makeClassName('org.slf4j.helpers.NamedLoggerBase'));


Logger.$markImplementor(NamedLoggerBase);


exports = NamedLoggerBase; 
//# sourceMappingURL=NamedLoggerBase.js.map