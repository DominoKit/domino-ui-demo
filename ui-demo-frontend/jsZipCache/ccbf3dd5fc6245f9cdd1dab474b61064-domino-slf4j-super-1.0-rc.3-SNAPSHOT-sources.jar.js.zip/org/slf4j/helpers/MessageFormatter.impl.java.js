/**
 * @fileoverview transpiled from org.slf4j.helpers.MessageFormatter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.helpers.MessageFormatter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let StringBuilder = goog.forwardDeclare('java.lang.StringBuilder$impl');
let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let FormattingTuple = goog.forwardDeclare('org.slf4j.helpers.FormattingTuple$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');
let $boolean = goog.forwardDeclare('vmbootstrap.primitives.$boolean$impl');
let $byte = goog.forwardDeclare('vmbootstrap.primitives.$byte$impl');
let $char = goog.forwardDeclare('vmbootstrap.primitives.$char$impl');
let $double = goog.forwardDeclare('vmbootstrap.primitives.$double$impl');
let $float = goog.forwardDeclare('vmbootstrap.primitives.$float$impl');
let $int = goog.forwardDeclare('vmbootstrap.primitives.$int$impl');
let $long = goog.forwardDeclare('vmbootstrap.primitives.$long$impl');
let $short = goog.forwardDeclare('vmbootstrap.primitives.$short$impl');


class MessageFormatter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MessageFormatter()'.
   * @return {!MessageFormatter}
   * @public
   */
  static $create__() {
    MessageFormatter.$clinit();
    let $instance = new MessageFormatter();
    $instance.$ctor__org_slf4j_helpers_MessageFormatter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MessageFormatter()'.
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_helpers_MessageFormatter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} messagePattern
   * @param {*} arg
   * @return {FormattingTuple}
   * @public
   */
  static m_format__java_lang_String__java_lang_Object(messagePattern, arg) {
    MessageFormatter.$clinit();
    return MessageFormatter.m_arrayFormat__java_lang_String__arrayOf_java_lang_Object(messagePattern, [arg]);
  }
  
  /**
   * @param {?string} messagePattern
   * @param {*} arg1
   * @param {*} arg2
   * @return {FormattingTuple}
   * @public
   */
  static m_format__java_lang_String__java_lang_Object__java_lang_Object(messagePattern, arg1, arg2) {
    MessageFormatter.$clinit();
    return MessageFormatter.m_arrayFormat__java_lang_String__arrayOf_java_lang_Object(messagePattern, [arg1, arg2]);
  }
  
  /**
   * @param {Array<*>} argArray
   * @return {Throwable}
   * @public
   */
  static m_getThrowableCandidate__arrayOf_java_lang_Object_$pp_org_slf4j_helpers(argArray) {
    MessageFormatter.$clinit();
    if ($Equality.$same(argArray, null) || argArray.length == 0) {
      return null;
    }
    let lastEntry = argArray[argArray.length - 1];
    if (Throwable.$isInstance(lastEntry)) {
      return /**@type {Throwable} */ ($Casts.$to(lastEntry, Throwable));
    }
    return null;
  }
  
  /**
   * @param {?string} messagePattern
   * @param {Array<*>} argArray
   * @return {FormattingTuple}
   * @public
   */
  static m_arrayFormat__java_lang_String__arrayOf_java_lang_Object(messagePattern, argArray) {
    MessageFormatter.$clinit();
    let throwableCandidate = MessageFormatter.m_getThrowableCandidate__arrayOf_java_lang_Object_$pp_org_slf4j_helpers(argArray);
    if ($Equality.$same(messagePattern, null)) {
      return FormattingTuple.$create__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(null, argArray, throwableCandidate);
    }
    if ($Equality.$same(argArray, null)) {
      return FormattingTuple.$create__java_lang_String(messagePattern);
    }
    let sbuf = StringBuilder.$create__int(j_l_String.m_length__java_lang_String(messagePattern) + MessageFormatter.f_OFFSET__org_slf4j_helpers_MessageFormatter);
    let seenSet = null;
    let /** number */ L;
    let i = 0;
    for (L = 0; L < argArray.length; L++) {
      let j = j_l_String.m_indexOf__java_lang_String__java_lang_String__int(messagePattern, MessageFormatter.f_DELIM_STR__org_slf4j_helpers_MessageFormatter_, i);
      if (j == -1) {
        if (i == 0) {
          return FormattingTuple.$create__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(messagePattern, argArray, throwableCandidate);
        } else {
          sbuf.m_append__java_lang_String(j_l_String.m_substring__java_lang_String__int__int(messagePattern, i, j_l_String.m_length__java_lang_String(messagePattern)));
          return FormattingTuple.$create__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(sbuf.toString(), argArray, throwableCandidate);
        }
      } else {
        if (MessageFormatter.m_isEscapedDelimeter__java_lang_String__int_$pp_org_slf4j_helpers(messagePattern, j)) {
          if (!MessageFormatter.m_isDoubleEscaped__java_lang_String__int_$pp_org_slf4j_helpers(messagePattern, j)) {
            L--;
            sbuf.m_append__java_lang_String(j_l_String.m_substring__java_lang_String__int__int(messagePattern, i, j - 1));
            sbuf.m_append__char(MessageFormatter.f_DELIM_START__org_slf4j_helpers_MessageFormatter_);
            i = j + 1;
          } else {
            sbuf.m_append__java_lang_String(j_l_String.m_substring__java_lang_String__int__int(messagePattern, i, j - 1));
            if ($Equality.$same(seenSet, null)) {
              seenSet = /**@type {!HashSet<*>} */ (HashSet.$create__());
            }
            MessageFormatter.m_deeplyAppendParameter__java_lang_StringBuilder__java_lang_Object__java_util_Set_$p_org_slf4j_helpers_MessageFormatter(sbuf, argArray[L], seenSet);
            i = j + 2;
          }
        } else {
          sbuf.m_append__java_lang_String(j_l_String.m_substring__java_lang_String__int__int(messagePattern, i, j));
          if ($Equality.$same(seenSet, null)) {
            seenSet = /**@type {!HashSet<*>} */ (HashSet.$create__());
          }
          MessageFormatter.m_deeplyAppendParameter__java_lang_StringBuilder__java_lang_Object__java_util_Set_$p_org_slf4j_helpers_MessageFormatter(sbuf, argArray[L], seenSet);
          i = j + 2;
        }
      }
    }
    sbuf.m_append__java_lang_String(j_l_String.m_substring__java_lang_String__int__int(messagePattern, i, j_l_String.m_length__java_lang_String(messagePattern)));
    if (L < argArray.length - 1) {
      return FormattingTuple.$create__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(sbuf.toString(), argArray, throwableCandidate);
    } else {
      return FormattingTuple.$create__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(sbuf.toString(), argArray, null);
    }
  }
  
  /**
   * @param {?string} messagePattern
   * @param {number} delimeterStartIndex
   * @return {boolean}
   * @public
   */
  static m_isEscapedDelimeter__java_lang_String__int_$pp_org_slf4j_helpers(messagePattern, delimeterStartIndex) {
    MessageFormatter.$clinit();
    if (delimeterStartIndex == 0) {
      return false;
    }
    let potentialEscape = j_l_String.m_charAt__java_lang_String__int(messagePattern, delimeterStartIndex - 1);
    return potentialEscape == MessageFormatter.f_ESCAPE_CHAR__org_slf4j_helpers_MessageFormatter_;
  }
  
  /**
   * @param {?string} messagePattern
   * @param {number} delimeterStartIndex
   * @return {boolean}
   * @public
   */
  static m_isDoubleEscaped__java_lang_String__int_$pp_org_slf4j_helpers(messagePattern, delimeterStartIndex) {
    MessageFormatter.$clinit();
    return (delimeterStartIndex >= 2 && j_l_String.m_charAt__java_lang_String__int(messagePattern, delimeterStartIndex - 2) == MessageFormatter.f_ESCAPE_CHAR__org_slf4j_helpers_MessageFormatter_);
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {*} o
   * @param {Set<*>} seenSet
   * @return {void}
   * @public
   */
  static m_deeplyAppendParameter__java_lang_StringBuilder__java_lang_Object__java_util_Set_$p_org_slf4j_helpers_MessageFormatter(sbuf, o, seenSet) {
    MessageFormatter.$clinit();
    if ($Equality.$same(o, null)) {
      sbuf.m_append__java_lang_String("null");
    } else if (!$Objects.m_getClass__java_lang_Object(o).m_isArray__()) {
      MessageFormatter.m_safeObjectAppend__java_lang_StringBuilder__java_lang_Object_$p_org_slf4j_helpers_MessageFormatter(sbuf, o);
    } else {
      sbuf.m_append__char(91 /* '[' */);
      if ($Arrays.$instanceIsOfType(o, $boolean, 1)) {
        MessageFormatter.m_booleanArrayAppend__java_lang_StringBuilder__arrayOf_boolean_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<boolean>} */ ($Arrays.$castTo(o, $boolean, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $byte, 1)) {
        MessageFormatter.m_byteArrayAppend__java_lang_StringBuilder__arrayOf_byte_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<number>} */ ($Arrays.$castTo(o, $byte, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $char, 1)) {
        MessageFormatter.m_charArrayAppend__java_lang_StringBuilder__arrayOf_char_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<number>} */ ($Arrays.$castTo(o, $char, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $short, 1)) {
        MessageFormatter.m_shortArrayAppend__java_lang_StringBuilder__arrayOf_short_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<number>} */ ($Arrays.$castTo(o, $short, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $int, 1)) {
        MessageFormatter.m_intArrayAppend__java_lang_StringBuilder__arrayOf_int_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<number>} */ ($Arrays.$castTo(o, $int, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $long, 1)) {
        MessageFormatter.m_longArrayAppend__java_lang_StringBuilder__arrayOf_long_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<!$Long>} */ ($Arrays.$castTo(o, $long, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $float, 1)) {
        MessageFormatter.m_floatArrayAppend__java_lang_StringBuilder__arrayOf_float_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<number>} */ ($Arrays.$castTo(o, $float, 1)));
      } else if ($Arrays.$instanceIsOfType(o, $double, 1)) {
        MessageFormatter.m_doubleArrayAppend__java_lang_StringBuilder__arrayOf_double_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<number>} */ ($Arrays.$castTo(o, $double, 1)));
      } else {
        MessageFormatter.m_objectArrayAppend__java_lang_StringBuilder__arrayOf_java_lang_Object__java_util_Set_$p_org_slf4j_helpers_MessageFormatter(sbuf, /**@type {Array<*>} */ ($Arrays.$castTo(o, j_l_Object, 1)), seenSet);
      }
      sbuf.m_append__char(93 /* ']' */);
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {*} o
   * @return {void}
   * @public
   */
  static m_safeObjectAppend__java_lang_StringBuilder__java_lang_Object_$p_org_slf4j_helpers_MessageFormatter(sbuf, o) {
    MessageFormatter.$clinit();
    try {
      sbuf.m_append__java_lang_String($Objects.m_toString__java_lang_Object(o));
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (Throwable.$isInstance(__$exc)) {
        let t = /**@type {Throwable} */ (__$exc);
        sbuf.m_append__java_lang_String("[FAILED toString()]");
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<*>} a
   * @param {Set<*>} seenSet
   * @return {void}
   * @public
   */
  static m_objectArrayAppend__java_lang_StringBuilder__arrayOf_java_lang_Object__java_util_Set_$p_org_slf4j_helpers_MessageFormatter(sbuf, a, seenSet) {
    MessageFormatter.$clinit();
    if (!seenSet.contains(a)) {
      seenSet.add(a);
      let len = a.length;
      for (let i = 0; i < len; i++) {
        MessageFormatter.m_deeplyAppendParameter__java_lang_StringBuilder__java_lang_Object__java_util_Set_$p_org_slf4j_helpers_MessageFormatter(sbuf, a[i], seenSet);
        if (i != len - 1) {
          sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
        }
      }
      seenSet.remove(a);
    } else {
      sbuf.m_append__java_lang_String("...");
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<boolean>} a
   * @return {void}
   * @public
   */
  static m_booleanArrayAppend__java_lang_StringBuilder__arrayOf_boolean_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__boolean(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<number>} a
   * @return {void}
   * @public
   */
  static m_byteArrayAppend__java_lang_StringBuilder__arrayOf_byte_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__int(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<number>} a
   * @return {void}
   * @public
   */
  static m_charArrayAppend__java_lang_StringBuilder__arrayOf_char_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__char(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<number>} a
   * @return {void}
   * @public
   */
  static m_shortArrayAppend__java_lang_StringBuilder__arrayOf_short_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__int(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<number>} a
   * @return {void}
   * @public
   */
  static m_intArrayAppend__java_lang_StringBuilder__arrayOf_int_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__int(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<!$Long>} a
   * @return {void}
   * @public
   */
  static m_longArrayAppend__java_lang_StringBuilder__arrayOf_long_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__long(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<number>} a
   * @return {void}
   * @public
   */
  static m_floatArrayAppend__java_lang_StringBuilder__arrayOf_float_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__float(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {StringBuilder} sbuf
   * @param {Array<number>} a
   * @return {void}
   * @public
   */
  static m_doubleArrayAppend__java_lang_StringBuilder__arrayOf_double_$p_org_slf4j_helpers_MessageFormatter(sbuf, a) {
    MessageFormatter.$clinit();
    let len = a.length;
    for (let i = 0; i < len; i++) {
      sbuf.m_append__double(a[i]);
      if (i != len - 1) {
        sbuf.m_append__java_lang_String(MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_);
      }
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MessageFormatter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MessageFormatter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MessageFormatter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    StringBuilder = goog.module.get('java.lang.StringBuilder$impl');
    Throwable = goog.module.get('java.lang.Throwable$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    FormattingTuple = goog.module.get('org.slf4j.helpers.FormattingTuple$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    $boolean = goog.module.get('vmbootstrap.primitives.$boolean$impl');
    $byte = goog.module.get('vmbootstrap.primitives.$byte$impl');
    $char = goog.module.get('vmbootstrap.primitives.$char$impl');
    $double = goog.module.get('vmbootstrap.primitives.$double$impl');
    $float = goog.module.get('vmbootstrap.primitives.$float$impl');
    $int = goog.module.get('vmbootstrap.primitives.$int$impl');
    $long = goog.module.get('vmbootstrap.primitives.$long$impl');
    $short = goog.module.get('vmbootstrap.primitives.$short$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MessageFormatter, $Util.$makeClassName('org.slf4j.helpers.MessageFormatter'));


/** @public {number} @const */
MessageFormatter.f_DELIM_START__org_slf4j_helpers_MessageFormatter_ = 123 /* '{' */;


/** @public {?string} @const */
MessageFormatter.f_DELIM_STR__org_slf4j_helpers_MessageFormatter_ = "{}";


/** @public {number} @const */
MessageFormatter.f_ESCAPE_CHAR__org_slf4j_helpers_MessageFormatter_ = 92 /* '\\' */;


/** @public {?string} @const */
MessageFormatter.f_ARRAY_JOIN_STR__org_slf4j_helpers_MessageFormatter_ = ", ";


/** @public {number} @const */
MessageFormatter.f_OFFSET__org_slf4j_helpers_MessageFormatter = 50;




exports = MessageFormatter; 
//# sourceMappingURL=MessageFormatter.js.map