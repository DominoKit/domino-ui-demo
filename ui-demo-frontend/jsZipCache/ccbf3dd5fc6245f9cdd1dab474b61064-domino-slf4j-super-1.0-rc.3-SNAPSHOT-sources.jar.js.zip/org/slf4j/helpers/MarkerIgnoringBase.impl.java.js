/**
 * @fileoverview transpiled from org.slf4j.helpers.MarkerIgnoringBase.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.helpers.MarkerIgnoringBase$impl');


const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Logger = goog.require('org.slf4j.Logger$impl');
const NamedLoggerBase = goog.require('org.slf4j.helpers.NamedLoggerBase$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let Marker = goog.forwardDeclare('org.slf4j.Marker$impl');


/**
 * @abstract
 * @implements {Logger}
  */
class MarkerIgnoringBase extends NamedLoggerBase {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'MarkerIgnoringBase()'.
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_helpers_MarkerIgnoringBase__() {
    this.$ctor__org_slf4j_helpers_NamedLoggerBase__();
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isTraceEnabled__org_slf4j_Marker(marker) {
    return this.m_isTraceEnabled__();
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String(marker, msg) {
    this.m_trace__java_lang_String(msg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
    this.m_trace__java_lang_String__java_lang_Object(format, arg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
    this.m_trace__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
    this.m_trace__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
    this.m_trace__java_lang_String__java_lang_Throwable(msg, t);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isDebugEnabled__org_slf4j_Marker(marker) {
    return this.m_isDebugEnabled__();
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String(marker, msg) {
    this.m_debug__java_lang_String(msg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
    this.m_debug__java_lang_String__java_lang_Object(format, arg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
    this.m_debug__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
    this.m_debug__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
    this.m_debug__java_lang_String__java_lang_Throwable(msg, t);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isInfoEnabled__org_slf4j_Marker(marker) {
    return this.m_isInfoEnabled__();
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String(marker, msg) {
    this.m_info__java_lang_String(msg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
    this.m_info__java_lang_String__java_lang_Object(format, arg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
    this.m_info__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
    this.m_info__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
    this.m_info__java_lang_String__java_lang_Throwable(msg, t);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isWarnEnabled__org_slf4j_Marker(marker) {
    return this.m_isWarnEnabled__();
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String(marker, msg) {
    this.m_warn__java_lang_String(msg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
    this.m_warn__java_lang_String__java_lang_Object(format, arg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
    this.m_warn__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
    this.m_warn__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
    this.m_warn__java_lang_String__java_lang_Throwable(msg, t);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isErrorEnabled__org_slf4j_Marker(marker) {
    return this.m_isErrorEnabled__();
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String(marker, msg) {
    this.m_error__java_lang_String(msg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
    this.m_error__java_lang_String__java_lang_Object(format, arg);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
    this.m_error__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
    this.m_error__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$);
  }
  
  /**
   * @override
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
    this.m_error__java_lang_String__java_lang_Throwable(msg, t);
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return j_l_String.m_valueOf__java_lang_Object(this.m_getClass__().m_getName__()) + "(" + j_l_String.m_valueOf__java_lang_Object(this.m_getName__()) + ")";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MarkerIgnoringBase;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MarkerIgnoringBase);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MarkerIgnoringBase.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    NamedLoggerBase.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MarkerIgnoringBase, $Util.$makeClassName('org.slf4j.helpers.MarkerIgnoringBase'));


/** @public {!$Long} @const */
MarkerIgnoringBase.f_serialVersionUID__org_slf4j_helpers_MarkerIgnoringBase_ = $Long.fromBits(1314727835, 2105782613) /* 9044267456635152283 */;


Logger.$markImplementor(MarkerIgnoringBase);


exports = MarkerIgnoringBase; 
//# sourceMappingURL=MarkerIgnoringBase.js.map