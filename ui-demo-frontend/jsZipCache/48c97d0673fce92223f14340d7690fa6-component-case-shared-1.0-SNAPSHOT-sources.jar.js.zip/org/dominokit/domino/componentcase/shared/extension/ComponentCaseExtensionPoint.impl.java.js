/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ExtensionPoint<ComponentCaseContext>}
 */
class ComponentCaseExtensionPoint {
  /**
   * @param {?function():ComponentCaseContext} fn
   * @return {ComponentCaseExtensionPoint}
   * @public
   */
  static $adapt(fn) {
    ComponentCaseExtensionPoint.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ExtensionPoint.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentCaseExtensionPoint, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint'));


ComponentCaseExtensionPoint.$markImplementor(/** @type {Function} */ (ComponentCaseExtensionPoint));


exports = ComponentCaseExtensionPoint; 
//# sourceMappingURL=ComponentCaseExtensionPoint.js.map