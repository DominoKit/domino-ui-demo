/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.DemoView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.DemoView.$LambdaAdaptor$impl');


/**
 * @interface
 */
class DemoView {
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getContent__() {
  }
  
  /**
   * @param {?function():Content} fn
   * @return {DemoView}
   * @public
   */
  static $adapt(fn) {
    DemoView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_DemoView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_DemoView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_DemoView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DemoView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.componentcase.shared.extension.DemoView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DemoView, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.DemoView'));


DemoView.$markImplementor(/** @type {Function} */ (DemoView));


exports = DemoView; 
//# sourceMappingURL=DemoView.js.map