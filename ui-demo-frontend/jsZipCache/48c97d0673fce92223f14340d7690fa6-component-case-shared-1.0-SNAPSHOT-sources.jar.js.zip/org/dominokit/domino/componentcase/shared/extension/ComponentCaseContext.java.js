/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Context = goog.require('org.dominokit.domino.api.shared.extension.Context');
const _ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext.$LambdaAdaptor');


// Re-exports the implementation.
var ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
exports = ComponentCaseContext;
 