/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCase$ComponentRemoveHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ComponentRemoveHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onBeforeRemove__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {ComponentRemoveHandler}
   * @public
   */
  static $adapt(fn) {
    ComponentRemoveHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase_ComponentRemoveHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase_ComponentRemoveHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase_ComponentRemoveHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentRemoveHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentRemoveHandler, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCase$ComponentRemoveHandler'));


ComponentRemoveHandler.$markImplementor(/** @type {Function} */ (ComponentRemoveHandler));


exports = ComponentRemoveHandler; 
//# sourceMappingURL=ComponentCase$ComponentRemoveHandler.js.map