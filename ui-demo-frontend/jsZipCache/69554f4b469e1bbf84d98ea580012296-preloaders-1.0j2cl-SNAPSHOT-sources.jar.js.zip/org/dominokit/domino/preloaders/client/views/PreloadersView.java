package org.dominokit.domino.preloaders.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.shared.extension.Content;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface PreloadersView extends View, DemoView{
}