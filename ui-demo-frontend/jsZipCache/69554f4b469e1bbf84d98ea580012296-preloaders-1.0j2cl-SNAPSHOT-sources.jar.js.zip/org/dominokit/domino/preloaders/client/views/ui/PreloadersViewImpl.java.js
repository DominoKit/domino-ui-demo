/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.views.ui.PreloadersViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.preloaders.client.views.ui.PreloadersViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _PreloadersView = goog.require('org.dominokit.domino.preloaders.client.views.PreloadersView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeResource = goog.require('org.dominokit.domino.preloaders.client.views.CodeResource');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Preloader = goog.require('org.dominokit.domino.ui.preloaders.Preloader');
const _Size = goog.require('org.dominokit.domino.ui.preloaders.Preloader.Size');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PreloadersViewImpl = goog.require('org.dominokit.domino.preloaders.client.views.ui.PreloadersViewImpl$impl');
exports = PreloadersViewImpl;
 