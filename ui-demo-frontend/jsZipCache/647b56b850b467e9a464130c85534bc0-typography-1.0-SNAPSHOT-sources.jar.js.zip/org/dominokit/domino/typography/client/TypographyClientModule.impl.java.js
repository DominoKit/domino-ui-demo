/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.TypographyClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.TypographyClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class TypographyClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyClientModule()'.
   * @return {!TypographyClientModule}
   * @public
   */
  static $create__() {
    TypographyClientModule.$clinit();
    let $instance = new TypographyClientModule();
    $instance.$ctor__org_dominokit_domino_typography_client_TypographyClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_TypographyClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    TypographyClientModule.$f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_.m_info__java_lang_String("Initializing Typography frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_() {
    return (TypographyClientModule.$clinit(), TypographyClientModule.$f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_(value) {
    (TypographyClientModule.$clinit(), TypographyClientModule.$f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    TypographyClientModule.$f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(TypographyClientModule));
  }
  
  
};

$Util.$setClassMetadata(TypographyClientModule, $Util.$makeClassName('org.dominokit.domino.typography.client.TypographyClientModule'));


/** @private {Logger} */
TypographyClientModule.$f_LOGGER__org_dominokit_domino_typography_client_TypographyClientModule_;




exports = TypographyClientModule; 
//# sourceMappingURL=TypographyClientModule.js.map