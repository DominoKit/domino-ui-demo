/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.presenters.TypographyPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.presenters.TypographyPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenter.$1$impl');
let TypographyView = goog.forwardDeclare('org.dominokit.domino.typography.client.views.TypographyView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<TypographyView>}
  */
class TypographyPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyPresenter()'.
   * @return {!TypographyPresenter}
   * @public
   */
  static $create__() {
    TypographyPresenter.$clinit();
    let $instance = new TypographyPresenter();
    $instance.$ctor__org_dominokit_domino_typography_client_presenters_TypographyPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_presenters_TypographyPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_typography_client_presenters_TypographyPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_typography_client_presenters_TypographyPresenter_() {
    return (TypographyPresenter.$clinit(), TypographyPresenter.$f_LOGGER__org_dominokit_domino_typography_client_presenters_TypographyPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_typography_client_presenters_TypographyPresenter_(value) {
    (TypographyPresenter.$clinit(), TypographyPresenter.$f_LOGGER__org_dominokit_domino_typography_client_presenters_TypographyPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.typography.client.presenters.TypographyPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    TypographyPresenter.$f_LOGGER__org_dominokit_domino_typography_client_presenters_TypographyPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(TypographyPresenter));
  }
  
  
};

$Util.$setClassMetadata(TypographyPresenter, $Util.$makeClassName('org.dominokit.domino.typography.client.presenters.TypographyPresenter'));


/** @private {Logger} */
TypographyPresenter.$f_LOGGER__org_dominokit_domino_typography_client_presenters_TypographyPresenter_;




exports = TypographyPresenter; 
//# sourceMappingURL=TypographyPresenter.js.map