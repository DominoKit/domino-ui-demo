/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _TypographyPresenter = goog.require('org.dominokit.domino.typography.client.presenters.TypographyPresenter');


// Re-exports the implementation.
var TypographyPresenterCommand = goog.require('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');
exports = TypographyPresenterCommand;
 