/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
let TypographyPresenter = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenter$impl');
let TypographyPresenterCommand = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentCaseExtensionPoint>}
  */
class TypographyPresenterContributionToComponentCaseExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {!TypographyPresenterContributionToComponentCaseExtensionPoint}
   * @public
   */
  static $create__() {
    TypographyPresenterContributionToComponentCaseExtensionPoint.$clinit();
    let $instance = new TypographyPresenterContributionToComponentCaseExtensionPoint();
    $instance.$ctor__org_dominokit_domino_typography_client_contributions_TypographyPresenterContributionToComponentCaseExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_contributions_TypographyPresenterContributionToComponentCaseExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(extensionPoint) {
    TypographyPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** TypographyPresenter */ presenter) =>{
      presenter.m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(/**@type {ComponentCaseExtensionPoint} */ ($Casts.$to(arg0, ComponentCaseExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyPresenterContributionToComponentCaseExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyPresenterContributionToComponentCaseExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyPresenterContributionToComponentCaseExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    TypographyPresenterCommand = goog.module.get('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TypographyPresenterContributionToComponentCaseExtensionPoint, $Util.$makeClassName('org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint'));


Contribution.$markImplementor(TypographyPresenterContributionToComponentCaseExtensionPoint);


exports = TypographyPresenterContributionToComponentCaseExtensionPoint; 
//# sourceMappingURL=TypographyPresenterContributionToComponentCaseExtensionPoint.js.map