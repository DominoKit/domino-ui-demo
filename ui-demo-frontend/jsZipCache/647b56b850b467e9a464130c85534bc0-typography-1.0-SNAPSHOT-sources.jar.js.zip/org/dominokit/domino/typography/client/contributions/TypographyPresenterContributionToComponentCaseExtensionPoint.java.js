/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');
const _TypographyPresenter = goog.require('org.dominokit.domino.typography.client.presenters.TypographyPresenter');
const _TypographyPresenterCommand = goog.require('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TypographyPresenterContributionToComponentCaseExtensionPoint = goog.require('org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint$impl');
exports = TypographyPresenterContributionToComponentCaseExtensionPoint;
 