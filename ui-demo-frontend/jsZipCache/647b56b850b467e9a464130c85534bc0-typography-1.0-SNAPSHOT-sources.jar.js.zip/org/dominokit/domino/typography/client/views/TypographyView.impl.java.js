/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.views.TypographyView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.views.TypographyView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.typography.client.views.TypographyView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class TypographyView {
  /**
   * @param {?function():Content} fn
   * @return {TypographyView}
   * @public
   */
  static $adapt(fn) {
    TypographyView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_typography_client_views_TypographyView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_typography_client_views_TypographyView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_typography_client_views_TypographyView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.typography.client.views.TypographyView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(TypographyView, $Util.$makeClassName('org.dominokit.domino.typography.client.views.TypographyView'));


TypographyView.$markImplementor(/** @type {Function} */ (TypographyView));


exports = TypographyView; 
//# sourceMappingURL=TypographyView.js.map