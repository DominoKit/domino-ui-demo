/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.listeners.LayoutPresenterListenerForMainDominoEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.listeners.LayoutPresenterListenerForMainDominoEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let MainDominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');
let MainEventContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainEventContext$impl');
let LayoutPresenter = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');
let LayoutPresenterCommand = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<MainDominoEvent>}
  */
class LayoutPresenterListenerForMainDominoEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutPresenterListenerForMainDominoEvent()'.
   * @return {!LayoutPresenterListenerForMainDominoEvent}
   * @public
   */
  static $create__() {
    LayoutPresenterListenerForMainDominoEvent.$clinit();
    let $instance = new LayoutPresenterListenerForMainDominoEvent();
    $instance.$ctor__org_dominokit_domino_layout_client_listeners_LayoutPresenterListenerForMainDominoEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutPresenterListenerForMainDominoEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_listeners_LayoutPresenterListenerForMainDominoEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {MainDominoEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_MainDominoEvent(event) {
    LayoutPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** LayoutPresenter */ presenter) =>{
      presenter.m_onMainModule__org_dominokit_domino_api_shared_extension_MainEventContext(/**@type {MainEventContext} */ ($Casts.$to(event.m_context__(), MainEventContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_api_shared_extension_MainDominoEvent(/**@type {MainDominoEvent} */ ($Casts.$to(arg0, MainDominoEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutPresenterListenerForMainDominoEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutPresenterListenerForMainDominoEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutPresenterListenerForMainDominoEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    MainDominoEvent = goog.module.get('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');
    MainEventContext = goog.module.get('org.dominokit.domino.api.shared.extension.MainEventContext$impl');
    LayoutPresenterCommand = goog.module.get('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutPresenterListenerForMainDominoEvent, $Util.$makeClassName('org.dominokit.domino.layout.client.listeners.LayoutPresenterListenerForMainDominoEvent'));


DominoEventListener.$markImplementor(LayoutPresenterListenerForMainDominoEvent);


exports = LayoutPresenterListenerForMainDominoEvent; 
//# sourceMappingURL=LayoutPresenterListenerForMainDominoEvent.js.map