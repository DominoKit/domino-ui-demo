/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.views.LayoutView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.views.LayoutView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _SelectionHandler = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler');


// Re-exports the implementation.
var LayoutView = goog.require('org.dominokit.domino.layout.client.views.LayoutView$impl');
exports = LayoutView;
 