/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _LayoutPresenter = goog.require('org.dominokit.domino.layout.client.presenters.LayoutPresenter');


// Re-exports the implementation.
var LayoutPresenterCommand = goog.require('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');
exports = LayoutPresenterCommand;
 