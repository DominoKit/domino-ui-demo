/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.LayoutModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.LayoutModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let MainDominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.layout.client.LayoutModuleConfiguration.$1$impl');
let LayoutPresenterListenerForMainDominoEvent = goog.forwardDeclare('org.dominokit.domino.layout.client.listeners.LayoutPresenterListenerForMainDominoEvent$impl');
let LayoutPresenter = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');
let LayoutPresenterCommand = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class LayoutModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutModuleConfiguration()'.
   * @return {!LayoutModuleConfiguration}
   * @public
   */
  static $create__() {
    LayoutModuleConfiguration.$clinit();
    let $instance = new LayoutModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_layout_client_LayoutModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_LayoutModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_layout_client_LayoutModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(LayoutPresenter).m_getCanonicalName__(), Class.$get(LayoutPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(LayoutPresenterCommand).m_getCanonicalName__(), Class.$get(LayoutPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(MainDominoEvent), LayoutPresenterListenerForMainDominoEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {ViewRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(arg0) {
    ModuleConfiguration.m_registerViews__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_ViewRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    MainDominoEvent = goog.module.get('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');
    $1 = goog.module.get('org.dominokit.domino.layout.client.LayoutModuleConfiguration.$1$impl');
    LayoutPresenterListenerForMainDominoEvent = goog.module.get('org.dominokit.domino.layout.client.listeners.LayoutPresenterListenerForMainDominoEvent$impl');
    LayoutPresenter = goog.module.get('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');
    LayoutPresenterCommand = goog.module.get('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.layout.client.LayoutModuleConfiguration'));


ModuleConfiguration.$markImplementor(LayoutModuleConfiguration);


exports = LayoutModuleConfiguration; 
//# sourceMappingURL=LayoutModuleConfiguration.js.map