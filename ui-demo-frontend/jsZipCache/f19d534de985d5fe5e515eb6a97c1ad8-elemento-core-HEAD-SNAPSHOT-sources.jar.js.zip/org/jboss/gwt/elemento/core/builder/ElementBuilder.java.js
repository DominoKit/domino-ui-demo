/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _TypedBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TypedBuilder');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventTarget_$Overlay = goog.require('elemental2.dom.EventTarget.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _Arrays = goog.require('java.util.Arrays');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _JsPropertyMap_$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ElementBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementBuilder$impl');
exports = ElementBuilder;
 