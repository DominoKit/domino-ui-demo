/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.BodyObserver$ElementObserver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.BodyObserver.ElementObserver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback');


// Re-exports the implementation.
var ElementObserver = goog.require('org.jboss.gwt.elemento.core.BodyObserver.ElementObserver$impl');
exports = ElementObserver;
 