/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementCreator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementCreator$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.ElementCreator.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ElementCreator {
  /**
   * @abstract
   * @template M_E
   * @param {?string} tag
   * @param {Class<M_E>} type
   * @return {M_E}
   * @public
   */
  m_create__java_lang_String__java_lang_Class(tag, type) {
  }
  
  /**
   * @template M_E
   * @param {?function(?string, Class<M_E>):M_E} fn
   * @return {ElementCreator}
   * @public
   */
  static $adapt(fn) {
    ElementCreator.$clinit();
    return /**@type {!$LambdaAdaptor<HTMLElement>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_ElementCreator = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_builder_ElementCreator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_ElementCreator;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ElementCreator.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.jboss.gwt.elemento.core.builder.ElementCreator.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ElementCreator, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.ElementCreator'));


ElementCreator.$markImplementor(/** @type {Function} */ (ElementCreator));


exports = ElementCreator; 
//# sourceMappingURL=ElementCreator.js.map