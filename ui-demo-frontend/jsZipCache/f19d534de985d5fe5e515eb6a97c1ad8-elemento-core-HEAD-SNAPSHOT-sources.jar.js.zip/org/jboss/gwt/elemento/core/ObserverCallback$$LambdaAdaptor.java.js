/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.ObserverCallback$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.ObserverCallback.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback');
const _$Overlay = goog.require('elemental2.dom.MutationRecord.$Overlay');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.jboss.gwt.elemento.core.ObserverCallback.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 