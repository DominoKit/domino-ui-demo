/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.EventType.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.EventType');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ClipboardEvent_$Overlay = goog.require('elemental2.dom.ClipboardEvent.$Overlay');
const _Document_$Overlay = goog.require('elemental2.dom.Document.$Overlay');
const _DragEvent_$Overlay = goog.require('elemental2.dom.DragEvent.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _EventTarget_$Overlay = goog.require('elemental2.dom.EventTarget.$Overlay');
const _FocusEvent_$Overlay = goog.require('elemental2.dom.FocusEvent.$Overlay');
const _HashChangeEvent_$Overlay = goog.require('elemental2.dom.HashChangeEvent.$Overlay');
const _InputEvent_$Overlay = goog.require('elemental2.dom.InputEvent.$Overlay');
const _KeyboardEvent_$Overlay = goog.require('elemental2.dom.KeyboardEvent.$Overlay');
const _MessageEvent_$Overlay = goog.require('elemental2.dom.MessageEvent.$Overlay');
const _MouseEvent_$Overlay = goog.require('elemental2.dom.MouseEvent.$Overlay');
const _PageTransitionEvent_$Overlay = goog.require('elemental2.dom.PageTransitionEvent.$Overlay');
const _PopStateEvent_$Overlay = goog.require('elemental2.dom.PopStateEvent.$Overlay');
const _TouchEvent_$Overlay = goog.require('elemental2.dom.TouchEvent.$Overlay');
const _UIEvent_$Overlay = goog.require('elemental2.dom.UIEvent.$Overlay');
const _WheelEvent_$Overlay = goog.require('elemental2.dom.WheelEvent.$Overlay');
const _Window_$Overlay = goog.require('elemental2.dom.Window.$Overlay');
const _StorageEvent_$Overlay = goog.require('elemental2.webstorage.StorageEvent.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');
const _$LambdaAdaptor$1 = goog.require('org.jboss.gwt.elemento.core.EventType.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.jboss.gwt.elemento.core.EventType.$LambdaAdaptor$2');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EventType = goog.require('org.jboss.gwt.elemento.core.EventType$impl');
exports = EventType;
 