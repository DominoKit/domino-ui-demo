/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.ObserverCallback$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.ObserverCallback.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.MutationRecord.$Overlay$impl');


/**
 * @implements {ObserverCallback}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(MutationRecord):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(MutationRecord):void} */
    this.f_$$fn__org_jboss_gwt_elemento_core_ObserverCallback_$LambdaAdaptor;
    this.$ctor__org_jboss_gwt_elemento_core_ObserverCallback_$LambdaAdaptor__org_jboss_gwt_elemento_core_ObserverCallback_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(MutationRecord):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_ObserverCallback_$LambdaAdaptor__org_jboss_gwt_elemento_core_ObserverCallback_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_jboss_gwt_elemento_core_ObserverCallback_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {MutationRecord} arg0
   * @return {void}
   * @public
   */
  m_onObserved__elemental2_dom_MutationRecord(arg0) {
    {
      let $function = this.f_$$fn__org_jboss_gwt_elemento_core_ObserverCallback_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.jboss.gwt.elemento.core.ObserverCallback$$LambdaAdaptor'));


ObserverCallback.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ObserverCallback$$LambdaAdaptor.js.map