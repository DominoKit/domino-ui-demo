/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.EventType.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.EventType$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ClipboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.ClipboardEvent.$Overlay$impl');
let Document_$Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let DragEvent_$Overlay = goog.forwardDeclare('elemental2.dom.DragEvent.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let EventTarget_$Overlay = goog.forwardDeclare('elemental2.dom.EventTarget.$Overlay$impl');
let FocusEvent_$Overlay = goog.forwardDeclare('elemental2.dom.FocusEvent.$Overlay$impl');
let HashChangeEvent_$Overlay = goog.forwardDeclare('elemental2.dom.HashChangeEvent.$Overlay$impl');
let InputEvent_$Overlay = goog.forwardDeclare('elemental2.dom.InputEvent.$Overlay$impl');
let KeyboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let MessageEvent_$Overlay = goog.forwardDeclare('elemental2.dom.MessageEvent.$Overlay$impl');
let MouseEvent_$Overlay = goog.forwardDeclare('elemental2.dom.MouseEvent.$Overlay$impl');
let PageTransitionEvent_$Overlay = goog.forwardDeclare('elemental2.dom.PageTransitionEvent.$Overlay$impl');
let PopStateEvent_$Overlay = goog.forwardDeclare('elemental2.dom.PopStateEvent.$Overlay$impl');
let TouchEvent_$Overlay = goog.forwardDeclare('elemental2.dom.TouchEvent.$Overlay$impl');
let UIEvent_$Overlay = goog.forwardDeclare('elemental2.dom.UIEvent.$Overlay$impl');
let WheelEvent_$Overlay = goog.forwardDeclare('elemental2.dom.WheelEvent.$Overlay$impl');
let Window_$Overlay = goog.forwardDeclare('elemental2.dom.Window.$Overlay$impl');
let StorageEvent_$Overlay = goog.forwardDeclare('elemental2.webstorage.StorageEvent.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let HandlerRegistration = goog.forwardDeclare('org.gwtproject.event.shared.HandlerRegistration$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType.$LambdaAdaptor$2$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T, C_V
  */
class EventType extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_jboss_gwt_elemento_core_EventType_;
  }
  
  /**
   * @template M_T, M_V
   * @param {?string} name
   * @return {EventType<M_T, M_V>}
   * @public
   */
  static m_of__java_lang_String(name) {
    EventType.$clinit();
    return /**@type {!EventType<Event, EventTarget>} */ (EventType.$create__java_lang_String(name));
  }
  
  /**
   * @template M_T
   * @param {EventTarget} target
   * @param {EventType<M_T, ?>} type
   * @param {?function(M_T):void} listener
   * @return {HandlerRegistration}
   * @public
   */
  static m_bind__elemental2_dom_EventTarget__org_jboss_gwt_elemento_core_EventType__org_jboss_gwt_elemento_core_EventCallbackFn(target, type, listener) {
    EventType.$clinit();
    return EventType.m_bind__elemental2_dom_EventTarget__java_lang_String__elemental2_dom_EventListener(target, type.f_name__org_jboss_gwt_elemento_core_EventType_, new $LambdaAdaptor$1(((/** Event */ e) =>{
      listener(/**@type {Event} */ ($Casts.$to(Js.m_cast__java_lang_Object(e), $Overlay)));
    })));
  }
  
  /**
   * @param {EventTarget} target
   * @param {?string} type
   * @param {EventListener} listener
   * @return {HandlerRegistration}
   * @public
   */
  static m_bind__elemental2_dom_EventTarget__java_lang_String__elemental2_dom_EventListener(target, type, listener) {
    EventType.$clinit();
    target.addEventListener(type, listener);
    return HandlerRegistration.$adapt((() =>{
      target.removeEventListener(type, listener);
    }));
  }
  
  /**
   * @template M_T
   * @param {EventTarget} target
   * @param {EventType<M_T, ?>} type
   * @param {boolean} useCapture
   * @param {?function(M_T):void} listener
   * @return {HandlerRegistration}
   * @public
   */
  static m_bind__elemental2_dom_EventTarget__org_jboss_gwt_elemento_core_EventType__boolean__org_jboss_gwt_elemento_core_EventCallbackFn(target, type, useCapture, listener) {
    EventType.$clinit();
    return EventType.m_bind__elemental2_dom_EventTarget__java_lang_String__boolean__elemental2_dom_EventListener(target, type.f_name__org_jboss_gwt_elemento_core_EventType_, useCapture, new $LambdaAdaptor$2(((/** Event */ e) =>{
      listener(/**@type {Event} */ ($Casts.$to(Js.m_cast__java_lang_Object(e), $Overlay)));
    })));
  }
  
  /**
   * @param {EventTarget} source
   * @param {?string} type
   * @param {boolean} useCapture
   * @param {EventListener} listener
   * @return {HandlerRegistration}
   * @public
   */
  static m_bind__elemental2_dom_EventTarget__java_lang_String__boolean__elemental2_dom_EventListener(source, type, useCapture, listener) {
    EventType.$clinit();
    EventTarget_$Overlay.m_addEventListener__elemental2_dom_EventTarget__java_lang_String__elemental2_dom_EventListener__boolean(source, type, listener, useCapture);
    return HandlerRegistration.$adapt((() =>{
      EventTarget_$Overlay.m_removeEventListener__elemental2_dom_EventTarget__java_lang_String__elemental2_dom_EventListener__boolean(source, type, listener, useCapture);
    }));
  }
  
  /**
   * Factory method corresponding to constructor 'EventType(String)'.
   * @template C_T, C_V
   * @param {?string} name
   * @return {!EventType<C_T, C_V>}
   * @public
   */
  static $create__java_lang_String(name) {
    EventType.$clinit();
    let $instance = new EventType();
    $instance.$ctor__org_jboss_gwt_elemento_core_EventType__java_lang_String(name);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EventType(String)'.
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_EventType__java_lang_String(name) {
    this.$ctor__java_lang_Object__();
    this.f_name__org_jboss_gwt_elemento_core_EventType_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_jboss_gwt_elemento_core_EventType_;
  }
  
  /**
   * @return {EventType<Event, Window>}
   * @public
   */
  static get f_online__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_online__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Window>} value
   * @return {void}
   * @public
   */
  static set f_online__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_online__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Window>}
   * @public
   */
  static get f_offline__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_offline__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Window>} value
   * @return {void}
   * @public
   */
  static set f_offline__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_offline__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<FocusEvent, Element>}
   * @public
   */
  static get f_focus__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_focus__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<FocusEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_focus__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_focus__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<FocusEvent, Element>}
   * @public
   */
  static get f_blur__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_blur__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<FocusEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_blur__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_blur__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<PageTransitionEvent, Document>}
   * @public
   */
  static get f_pagehide__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_pagehide__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<PageTransitionEvent, Document>} value
   * @return {void}
   * @public
   */
  static set f_pagehide__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_pagehide__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<PageTransitionEvent, Document>}
   * @public
   */
  static get f_pageshow__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_pageshow__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<PageTransitionEvent, Document>} value
   * @return {void}
   * @public
   */
  static set f_pageshow__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_pageshow__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<PopStateEvent, Window>}
   * @public
   */
  static get f_popstate__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_popstate__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<PopStateEvent, Window>} value
   * @return {void}
   * @public
   */
  static set f_popstate__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_popstate__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Element>}
   * @public
   */
  static get f_reset__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_reset__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Element>} value
   * @return {void}
   * @public
   */
  static set f_reset__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_reset__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Element>}
   * @public
   */
  static get f_submit__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_submit__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Element>} value
   * @return {void}
   * @public
   */
  static set f_submit__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_submit__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Window>}
   * @public
   */
  static get f_beforeprint__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_beforeprint__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Window>} value
   * @return {void}
   * @public
   */
  static set f_beforeprint__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_beforeprint__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Window>}
   * @public
   */
  static get f_afterprint__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_afterprint__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Window>} value
   * @return {void}
   * @public
   */
  static set f_afterprint__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_afterprint__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_compositionstart__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_compositionstart__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_compositionstart__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_compositionstart__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_compositionupdate__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_compositionupdate__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_compositionupdate__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_compositionupdate__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_compositionend__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_compositionend__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_compositionend__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_compositionend__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Document>}
   * @public
   */
  static get f_fullscreenchange__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_fullscreenchange__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Document>} value
   * @return {void}
   * @public
   */
  static set f_fullscreenchange__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_fullscreenchange__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Document>}
   * @public
   */
  static get f_fullscreenerror__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_fullscreenerror__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Document>} value
   * @return {void}
   * @public
   */
  static set f_fullscreenerror__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_fullscreenerror__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<UIEvent, Window>}
   * @public
   */
  static get f_resize__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_resize__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<UIEvent, Window>} value
   * @return {void}
   * @public
   */
  static set f_resize__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_resize__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<UIEvent, EventTarget>}
   * @public
   */
  static get f_scroll__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_scroll__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<UIEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_scroll__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_scroll__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<ClipboardEvent, EventTarget>}
   * @public
   */
  static get f_cut__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_cut__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<ClipboardEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_cut__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_cut__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<ClipboardEvent, EventTarget>}
   * @public
   */
  static get f_copy__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_copy__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<ClipboardEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_copy__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_copy__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<ClipboardEvent, EventTarget>}
   * @public
   */
  static get f_paste__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_paste__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<ClipboardEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_paste__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_paste__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<KeyboardEvent, EventTarget>}
   * @public
   */
  static get f_keydown__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_keydown__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<KeyboardEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_keydown__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_keydown__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<KeyboardEvent, EventTarget>}
   * @public
   */
  static get f_keypress__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_keypress__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<KeyboardEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_keypress__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_keypress__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<KeyboardEvent, EventTarget>}
   * @public
   */
  static get f_keyup__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_keyup__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<KeyboardEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_keyup__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_keyup__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, EventTarget>}
   * @public
   */
  static get f_mouseenter__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mouseenter__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_mouseenter__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mouseenter__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, EventTarget>}
   * @public
   */
  static get f_mouseover__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mouseover__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_mouseover__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mouseover__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, EventTarget>}
   * @public
   */
  static get f_mousemove__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mousemove__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_mousemove__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mousemove__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, EventTarget>}
   * @public
   */
  static get f_mousedown__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mousedown__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_mousedown__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mousedown__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, EventTarget>}
   * @public
   */
  static get f_mouseup__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mouseup__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_mouseup__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mouseup__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, Element>}
   * @public
   */
  static get f_auxclick__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_auxclick__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_auxclick__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_auxclick__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, Element>}
   * @public
   */
  static get f_click__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_click__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_click__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_click__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, Element>}
   * @public
   */
  static get f_dblclick__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_dblclick__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_dblclick__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_dblclick__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, Element>}
   * @public
   */
  static get f_contextmenu__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_contextmenu__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_contextmenu__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_contextmenu__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<WheelEvent, EventTarget>}
   * @public
   */
  static get f_wheel__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_wheel__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<WheelEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_wheel__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_wheel__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, Element>}
   * @public
   */
  static get f_mouseleave__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mouseleave__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_mouseleave__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mouseleave__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MouseEvent, Element>}
   * @public
   */
  static get f_mouseout__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_mouseout__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MouseEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_mouseout__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_mouseout__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Document>}
   * @public
   */
  static get f_pointerlockchange__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_pointerlockchange__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Document>} value
   * @return {void}
   * @public
   */
  static set f_pointerlockchange__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_pointerlockchange__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Document>}
   * @public
   */
  static get f_pointerlockerror__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_pointerlockerror__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Document>} value
   * @return {void}
   * @public
   */
  static set f_pointerlockerror__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_pointerlockerror__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_dragstart__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_dragstart__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_dragstart__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_dragstart__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_drag__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_drag__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_drag__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_drag__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_dragend__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_dragend__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_dragend__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_dragend__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_dragenter__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_dragenter__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_dragenter__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_dragenter__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_dragover__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_dragover__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_dragover__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_dragover__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_dragleave__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_dragleave__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_dragleave__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_dragleave__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<DragEvent, EventTarget>}
   * @public
   */
  static get f_drop__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_drop__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<DragEvent, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_drop__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_drop__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_touchcancel__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_touchcancel__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_touchcancel__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_touchcancel__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_touchend__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_touchend__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_touchend__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_touchend__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_touchmove__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_touchmove__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_touchmove__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_touchmove__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<TouchEvent, Element>}
   * @public
   */
  static get f_touchstart__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_touchstart__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<TouchEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_touchstart__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_touchstart__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<HashChangeEvent, Window>}
   * @public
   */
  static get f_hashchange__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_hashchange__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<HashChangeEvent, Window>} value
   * @return {void}
   * @public
   */
  static set f_hashchange__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_hashchange__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<InputEvent, Element>}
   * @public
   */
  static get f_input__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_input__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<InputEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_input__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_input__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Document>}
   * @public
   */
  static get f_readystatechange__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_readystatechange__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Document>} value
   * @return {void}
   * @public
   */
  static set f_readystatechange__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_readystatechange__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<InputEvent, Element>}
   * @public
   */
  static get f_change__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_change__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<InputEvent, Element>} value
   * @return {void}
   * @public
   */
  static set f_change__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_change__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Element>}
   * @public
   */
  static get f_invalid__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_invalid__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Element>} value
   * @return {void}
   * @public
   */
  static set f_invalid__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_invalid__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Element>}
   * @public
   */
  static get f_show__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_show__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Element>} value
   * @return {void}
   * @public
   */
  static set f_show__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_show__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<MessageEvent<?>, EventTarget>}
   * @public
   */
  static get f_message__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_message__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<MessageEvent<?>, EventTarget>} value
   * @return {void}
   * @public
   */
  static set f_message__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_message__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<StorageEvent, Window>}
   * @public
   */
  static get f_storage__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_storage__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<StorageEvent, Window>} value
   * @return {void}
   * @public
   */
  static set f_storage__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_storage__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Window>}
   * @public
   */
  static get f_load__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_load__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Window>} value
   * @return {void}
   * @public
   */
  static set f_load__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_load__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @return {EventType<Event, Document>}
   * @public
   */
  static get f_visibilitychange__org_jboss_gwt_elemento_core_EventType() {
    return (EventType.$clinit(), EventType.$f_visibilitychange__org_jboss_gwt_elemento_core_EventType);
  }
  
  /**
   * @param {EventType<Event, Document>} value
   * @return {void}
   * @public
   */
  static set f_visibilitychange__org_jboss_gwt_elemento_core_EventType(value) {
    (EventType.$clinit(), EventType.$f_visibilitychange__org_jboss_gwt_elemento_core_EventType = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EventType;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EventType);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EventType.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Event.$Overlay$impl');
    EventTarget_$Overlay = goog.module.get('elemental2.dom.EventTarget.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    HandlerRegistration = goog.module.get('org.gwtproject.event.shared.HandlerRegistration$impl');
    $LambdaAdaptor$1 = goog.module.get('org.jboss.gwt.elemento.core.EventType.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.jboss.gwt.elemento.core.EventType.$LambdaAdaptor$2$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    EventType.$f_online__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Window>} */ (EventType.m_of__java_lang_String("online"));
    EventType.$f_offline__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Window>} */ (EventType.m_of__java_lang_String("offline"));
    EventType.$f_focus__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<FocusEvent, Element>} */ (EventType.m_of__java_lang_String("focus"));
    EventType.$f_blur__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<FocusEvent, Element>} */ (EventType.m_of__java_lang_String("blur"));
    EventType.$f_pagehide__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<PageTransitionEvent, Document>} */ (EventType.m_of__java_lang_String("pagehide"));
    EventType.$f_pageshow__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<PageTransitionEvent, Document>} */ (EventType.m_of__java_lang_String("pageshow"));
    EventType.$f_popstate__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<PopStateEvent, Window>} */ (EventType.m_of__java_lang_String("popstate"));
    EventType.$f_reset__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Element>} */ (EventType.m_of__java_lang_String("reset"));
    EventType.$f_submit__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Element>} */ (EventType.m_of__java_lang_String("submit"));
    EventType.$f_beforeprint__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Window>} */ (EventType.m_of__java_lang_String("beforeprint"));
    EventType.$f_afterprint__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Window>} */ (EventType.m_of__java_lang_String("afterprint"));
    EventType.$f_compositionstart__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("compositionstart"));
    EventType.$f_compositionupdate__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("compositionupdate"));
    EventType.$f_compositionend__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("compositionend"));
    EventType.$f_fullscreenchange__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Document>} */ (EventType.m_of__java_lang_String("fullscreenchange"));
    EventType.$f_fullscreenerror__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Document>} */ (EventType.m_of__java_lang_String("fullscreenerror"));
    EventType.$f_resize__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<UIEvent, Window>} */ (EventType.m_of__java_lang_String("resize"));
    EventType.$f_scroll__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<UIEvent, EventTarget>} */ (EventType.m_of__java_lang_String("scroll"));
    EventType.$f_cut__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<ClipboardEvent, EventTarget>} */ (EventType.m_of__java_lang_String("cut"));
    EventType.$f_copy__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<ClipboardEvent, EventTarget>} */ (EventType.m_of__java_lang_String("copy"));
    EventType.$f_paste__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<ClipboardEvent, EventTarget>} */ (EventType.m_of__java_lang_String("paste"));
    EventType.$f_keydown__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<KeyboardEvent, EventTarget>} */ (EventType.m_of__java_lang_String("keydown"));
    EventType.$f_keypress__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<KeyboardEvent, EventTarget>} */ (EventType.m_of__java_lang_String("keypress"));
    EventType.$f_keyup__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<KeyboardEvent, EventTarget>} */ (EventType.m_of__java_lang_String("keyup"));
    EventType.$f_mouseenter__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, EventTarget>} */ (EventType.m_of__java_lang_String("mouseenter"));
    EventType.$f_mouseover__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, EventTarget>} */ (EventType.m_of__java_lang_String("mouseover"));
    EventType.$f_mousemove__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, EventTarget>} */ (EventType.m_of__java_lang_String("mousemove"));
    EventType.$f_mousedown__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, EventTarget>} */ (EventType.m_of__java_lang_String("mousedown"));
    EventType.$f_mouseup__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, EventTarget>} */ (EventType.m_of__java_lang_String("mouseup"));
    EventType.$f_auxclick__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, Element>} */ (EventType.m_of__java_lang_String("auxclick"));
    EventType.$f_click__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, Element>} */ (EventType.m_of__java_lang_String("click"));
    EventType.$f_dblclick__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, Element>} */ (EventType.m_of__java_lang_String("dblclick"));
    EventType.$f_contextmenu__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, Element>} */ (EventType.m_of__java_lang_String("contextmenu"));
    EventType.$f_wheel__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<WheelEvent, EventTarget>} */ (EventType.m_of__java_lang_String("wheel"));
    EventType.$f_mouseleave__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, Element>} */ (EventType.m_of__java_lang_String("mouseleave"));
    EventType.$f_mouseout__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MouseEvent, Element>} */ (EventType.m_of__java_lang_String("mouseout"));
    EventType.$f_pointerlockchange__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Document>} */ (EventType.m_of__java_lang_String("pointerlockchange"));
    EventType.$f_pointerlockerror__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Document>} */ (EventType.m_of__java_lang_String("pointerlockerror"));
    EventType.$f_dragstart__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("dragstart"));
    EventType.$f_drag__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("drag"));
    EventType.$f_dragend__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("dragend"));
    EventType.$f_dragenter__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("dragenter"));
    EventType.$f_dragover__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("dragover"));
    EventType.$f_dragleave__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("dragleave"));
    EventType.$f_drop__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<DragEvent, EventTarget>} */ (EventType.m_of__java_lang_String("drop"));
    EventType.$f_touchcancel__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("touchcancel"));
    EventType.$f_touchend__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("touchend"));
    EventType.$f_touchmove__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("touchmove"));
    EventType.$f_touchstart__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<TouchEvent, Element>} */ (EventType.m_of__java_lang_String("touchstart"));
    EventType.$f_hashchange__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<HashChangeEvent, Window>} */ (EventType.m_of__java_lang_String("hashchange"));
    EventType.$f_input__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<InputEvent, Element>} */ (EventType.m_of__java_lang_String("input"));
    EventType.$f_readystatechange__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Document>} */ (EventType.m_of__java_lang_String("readystatechange"));
    EventType.$f_change__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<InputEvent, Element>} */ (EventType.m_of__java_lang_String("change"));
    EventType.$f_invalid__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Element>} */ (EventType.m_of__java_lang_String("invalid"));
    EventType.$f_show__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Element>} */ (EventType.m_of__java_lang_String("show"));
    EventType.$f_message__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<MessageEvent<?>, EventTarget>} */ (EventType.m_of__java_lang_String("message"));
    EventType.$f_storage__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<StorageEvent, Window>} */ (EventType.m_of__java_lang_String("storage"));
    EventType.$f_load__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Window>} */ (EventType.m_of__java_lang_String("load"));
    EventType.$f_visibilitychange__org_jboss_gwt_elemento_core_EventType = /**@type {EventType<Event, Document>} */ (EventType.m_of__java_lang_String("visibilitychange"));
  }
  
  
};

$Util.$setClassMetadata(EventType, $Util.$makeClassName('org.jboss.gwt.elemento.core.EventType'));


/** @private {EventType<Event, Window>} */
EventType.$f_online__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Window>} */
EventType.$f_offline__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<FocusEvent, Element>} */
EventType.$f_focus__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<FocusEvent, Element>} */
EventType.$f_blur__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<PageTransitionEvent, Document>} */
EventType.$f_pagehide__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<PageTransitionEvent, Document>} */
EventType.$f_pageshow__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<PopStateEvent, Window>} */
EventType.$f_popstate__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Element>} */
EventType.$f_reset__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Element>} */
EventType.$f_submit__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Window>} */
EventType.$f_beforeprint__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Window>} */
EventType.$f_afterprint__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_compositionstart__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_compositionupdate__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_compositionend__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Document>} */
EventType.$f_fullscreenchange__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Document>} */
EventType.$f_fullscreenerror__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<UIEvent, Window>} */
EventType.$f_resize__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<UIEvent, EventTarget>} */
EventType.$f_scroll__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<ClipboardEvent, EventTarget>} */
EventType.$f_cut__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<ClipboardEvent, EventTarget>} */
EventType.$f_copy__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<ClipboardEvent, EventTarget>} */
EventType.$f_paste__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<KeyboardEvent, EventTarget>} */
EventType.$f_keydown__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<KeyboardEvent, EventTarget>} */
EventType.$f_keypress__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<KeyboardEvent, EventTarget>} */
EventType.$f_keyup__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, EventTarget>} */
EventType.$f_mouseenter__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, EventTarget>} */
EventType.$f_mouseover__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, EventTarget>} */
EventType.$f_mousemove__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, EventTarget>} */
EventType.$f_mousedown__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, EventTarget>} */
EventType.$f_mouseup__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, Element>} */
EventType.$f_auxclick__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, Element>} */
EventType.$f_click__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, Element>} */
EventType.$f_dblclick__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, Element>} */
EventType.$f_contextmenu__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<WheelEvent, EventTarget>} */
EventType.$f_wheel__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, Element>} */
EventType.$f_mouseleave__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MouseEvent, Element>} */
EventType.$f_mouseout__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Document>} */
EventType.$f_pointerlockchange__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Document>} */
EventType.$f_pointerlockerror__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_dragstart__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_drag__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_dragend__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_dragenter__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_dragover__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_dragleave__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<DragEvent, EventTarget>} */
EventType.$f_drop__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_touchcancel__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_touchend__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_touchmove__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<TouchEvent, Element>} */
EventType.$f_touchstart__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<HashChangeEvent, Window>} */
EventType.$f_hashchange__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<InputEvent, Element>} */
EventType.$f_input__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Document>} */
EventType.$f_readystatechange__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<InputEvent, Element>} */
EventType.$f_change__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Element>} */
EventType.$f_invalid__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Element>} */
EventType.$f_show__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<MessageEvent<?>, EventTarget>} */
EventType.$f_message__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<StorageEvent, Window>} */
EventType.$f_storage__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Window>} */
EventType.$f_load__org_jboss_gwt_elemento_core_EventType;


/** @private {EventType<Event, Document>} */
EventType.$f_visibilitychange__org_jboss_gwt_elemento_core_EventType;




exports = EventType; 
//# sourceMappingURL=EventType.js.map