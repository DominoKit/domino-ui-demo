/**
 * @fileoverview transpiled from elemental2.core.JSONType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.JSONType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.JSONType.StringifyReplacerUnionType.$Overlay');
const _StringifySpaceUnionType_$Overlay = goog.require('elemental2.core.JSONType.StringifySpaceUnionType.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var JSONType_$Overlay = goog.require('elemental2.core.JSONType.$Overlay$impl');
exports = JSONType_$Overlay;
 