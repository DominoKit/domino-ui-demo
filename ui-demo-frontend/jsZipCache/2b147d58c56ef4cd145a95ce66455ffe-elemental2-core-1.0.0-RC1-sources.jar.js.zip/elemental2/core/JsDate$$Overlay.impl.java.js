/**
 * @fileoverview transpiled from elemental2.core.JsDate$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsDate.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsDate.ToLocaleDateStringLocalesUnionType.$Overlay$impl');
let ToLocaleStringLocalesUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsDate.ToLocaleStringLocalesUnionType.$Overlay$impl');
let ToLocaleTimeStringLocalesUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsDate.ToLocaleTimeStringLocalesUnionType.$Overlay$impl');
let JsObject_$Overlay = goog.forwardDeclare('elemental2.core.JsObject.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class JsDate_$Overlay {
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleDateString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleDateString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return JsDate_$Overlay.m_toLocaleDateString__elemental2_core_JsDate__java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__arrayOf_java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return JsDate_$Overlay.m_toLocaleDateString__elemental2_core_JsDate__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__java_lang_String($thisArg, locales) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleDateString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__arrayOf_java_lang_String($thisArg, locales) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleDateString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleDateString__elemental2_core_JsDate__elemental2_core_JsDate_ToLocaleDateStringLocalesUnionType__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleDateString(locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return JsDate_$Overlay.m_toLocaleString__elemental2_core_JsDate__java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__arrayOf_java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return JsDate_$Overlay.m_toLocaleString__elemental2_core_JsDate__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__java_lang_String($thisArg, locales) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__arrayOf_java_lang_String($thisArg, locales) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsDate__elemental2_core_JsDate_ToLocaleStringLocalesUnionType__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleString(locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleTimeString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleTimeString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return JsDate_$Overlay.m_toLocaleTimeString__elemental2_core_JsDate__java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__arrayOf_java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return JsDate_$Overlay.m_toLocaleTimeString__elemental2_core_JsDate__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?string} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__java_lang_String($thisArg, locales) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleTimeString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {Array<?string>} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__arrayOf_java_lang_String($thisArg, locales) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleTimeString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Date} $thisArg
   * @param {?} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleTimeString__elemental2_core_JsDate__elemental2_core_JsDate_ToLocaleTimeStringLocalesUnionType__java_lang_Object($thisArg, locales, options) {
    JsDate_$Overlay.$clinit();
    return $thisArg.toLocaleTimeString(locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Date;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsDate_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JsDate_$Overlay, $Util.$makeClassName('Date'));


exports = JsDate_$Overlay; 
//# sourceMappingURL=JsDate$$Overlay.js.map