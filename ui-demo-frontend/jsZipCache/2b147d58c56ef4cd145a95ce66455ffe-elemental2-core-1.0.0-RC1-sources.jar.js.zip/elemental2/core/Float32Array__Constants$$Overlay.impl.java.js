/**
 * @fileoverview transpiled from elemental2.core.Float32Array__Constants$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Float32Array__Constants.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Float32Array;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('Float32Array'));


exports = $Overlay; 
//# sourceMappingURL=Float32Array__Constants$$Overlay.js.map