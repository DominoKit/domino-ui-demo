/**
 * @fileoverview transpiled from elemental2.core.TypedArray$SetArrayUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.TypedArray.SetArrayUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.ArrayBufferView.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $double = goog.forwardDeclare('vmbootstrap.primitives.$double$impl');


class SetArrayUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    SetArrayUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), SetArrayUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {ArrayBufferView}
   * @public
   */
  static m_asArrayBufferView__elemental2_core_TypedArray_SetArrayUnionType($thisArg) {
    SetArrayUnionType_$Overlay.$clinit();
    return /**@type {ArrayBufferView} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Array<number>}
   * @public
   */
  static m_asDoubleArray__elemental2_core_TypedArray_SetArrayUnionType($thisArg) {
    SetArrayUnionType_$Overlay.$clinit();
    return /**@type {Array<number>} */ ($Arrays.$castTo(Js.m_cast__java_lang_Object($thisArg), $double, 1));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isArrayBufferView__elemental2_core_TypedArray_SetArrayUnionType($thisArg) {
    SetArrayUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isDoubleArray__elemental2_core_TypedArray_SetArrayUnionType($thisArg) {
    SetArrayUnionType_$Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SetArrayUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.core.ArrayBufferView.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $double = goog.module.get('vmbootstrap.primitives.$double$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SetArrayUnionType_$Overlay, $Util.$makeClassName('?'));


exports = SetArrayUnionType_$Overlay; 
//# sourceMappingURL=TypedArray$SetArrayUnionType$$Overlay.js.map