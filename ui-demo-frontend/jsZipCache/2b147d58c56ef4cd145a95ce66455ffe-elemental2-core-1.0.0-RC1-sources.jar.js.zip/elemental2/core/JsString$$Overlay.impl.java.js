/**
 * @fileoverview transpiled from elemental2.core.JsString$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsString.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsObject.$Overlay$impl');
let JsRegExp_$Overlay = goog.forwardDeclare('elemental2.core.JsRegExp.$Overlay$impl');
let LocaleCompareLocalesUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsString.LocaleCompareLocalesUnionType.$Overlay$impl');
let ReplacePatternUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsString.ReplacePatternUnionType.$Overlay$impl');
let ReplaceReplacementUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsString.ReplaceReplacementUnionType.$Overlay$impl');
let SearchPatternUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsString.SearchPatternUnionType.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class JsString_$Overlay {
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {?} locales
   * @param {*} options
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__elemental2_core_JsString_LocaleCompareLocalesUnionType__java_lang_Object($thisArg, compareString, locales, options) {
    JsString_$Overlay.$clinit();
    return $thisArg.localeCompare(compareString, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {?string} locales
   * @param {Object} options
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__java_lang_String__elemental2_core_JsObject($thisArg, compareString, locales, options) {
    JsString_$Overlay.$clinit();
    return $thisArg.localeCompare(compareString, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {Array<?string>} locales
   * @param {Object} options
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, compareString, locales, options) {
    JsString_$Overlay.$clinit();
    return $thisArg.localeCompare(compareString, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {?string} locales
   * @param {*} options
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__java_lang_String__java_lang_Object($thisArg, compareString, locales, options) {
    JsString_$Overlay.$clinit();
    return JsString_$Overlay.m_localeCompare__elemental2_core_JsString__java_lang_String__java_lang_String__elemental2_core_JsObject($thisArg, compareString, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {Array<?string>} locales
   * @param {*} options
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__arrayOf_java_lang_String__java_lang_Object($thisArg, compareString, locales, options) {
    JsString_$Overlay.$clinit();
    return JsString_$Overlay.m_localeCompare__elemental2_core_JsString__java_lang_String__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, compareString, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {?string} locales
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__java_lang_String($thisArg, compareString, locales) {
    JsString_$Overlay.$clinit();
    return $thisArg.localeCompare(compareString, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} compareString
   * @param {Array<?string>} locales
   * @return {number}
   * @public
   */
  static m_localeCompare__elemental2_core_JsString__java_lang_String__arrayOf_java_lang_String($thisArg, compareString, locales) {
    JsString_$Overlay.$clinit();
    return $thisArg.localeCompare(compareString, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {RegExp} pattern
   * @param {?function(?string, ...*):*} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__elemental2_core_JsRegExp__elemental2_core_JsString_ReplaceReplacementFn($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacement)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {RegExp} pattern
   * @param {?} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__elemental2_core_JsRegExp__elemental2_core_JsString_ReplaceReplacementUnionType($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)), replacement);
  }
  
  /**
   * @param {String} $thisArg
   * @param {RegExp} pattern
   * @param {?string} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__elemental2_core_JsRegExp__java_lang_String($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacement)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?} pattern
   * @param {?function(?string, ...*):*} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__elemental2_core_JsString_ReplacePatternUnionType__elemental2_core_JsString_ReplaceReplacementFn($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(pattern, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacement)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?} pattern
   * @param {?string} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__elemental2_core_JsString_ReplacePatternUnionType__java_lang_String($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(pattern, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacement)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} pattern
   * @param {?function(?string, ...*):*} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__java_lang_String__elemental2_core_JsString_ReplaceReplacementFn($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacement)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} pattern
   * @param {?} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__java_lang_String__elemental2_core_JsString_ReplaceReplacementUnionType($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)), replacement);
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} pattern
   * @param {?string} replacement
   * @return {?string}
   * @public
   */
  static m_replace__elemental2_core_JsString__java_lang_String__java_lang_String($thisArg, pattern, replacement) {
    JsString_$Overlay.$clinit();
    return $thisArg.replace(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacement)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {RegExp} pattern
   * @return {number}
   * @public
   */
  static m_search__elemental2_core_JsString__elemental2_core_JsRegExp($thisArg, pattern) {
    JsString_$Overlay.$clinit();
    return $thisArg.search(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)));
  }
  
  /**
   * @param {String} $thisArg
   * @param {?string} pattern
   * @return {number}
   * @public
   */
  static m_search__elemental2_core_JsString__java_lang_String($thisArg, pattern) {
    JsString_$Overlay.$clinit();
    return $thisArg.search(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(pattern)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof String;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsString_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JsString_$Overlay, $Util.$makeClassName('String'));


exports = JsString_$Overlay; 
//# sourceMappingURL=JsString$$Overlay.js.map