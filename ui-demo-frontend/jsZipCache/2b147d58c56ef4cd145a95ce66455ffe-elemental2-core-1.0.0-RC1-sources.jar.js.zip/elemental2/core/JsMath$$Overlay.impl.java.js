/**
 * @fileoverview transpiled from elemental2.core.JsMath$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsMath.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_E__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_E__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_E__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_E__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_LN10__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_LN10__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_LN10__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_LN10__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_LN2__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_LN2__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_LN2__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_LN2__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_LOG10E__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_LOG10E__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_LOG10E__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_LOG10E__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_LOG2E__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_LOG2E__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_LOG2E__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_LOG2E__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PI__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PI__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PI__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PI__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SQRT1_2__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SQRT1_2__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SQRT1_2__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SQRT1_2__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SQRT2__elemental2_core_JsMath_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SQRT2__elemental2_core_JsMath_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SQRT2__elemental2_core_JsMath_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SQRT2__elemental2_core_JsMath_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Math;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
    $Overlay.$f_E__elemental2_core_JsMath_$Overlay = Math.E;
    $Overlay.$f_LN10__elemental2_core_JsMath_$Overlay = Math.LN10;
    $Overlay.$f_LN2__elemental2_core_JsMath_$Overlay = Math.LN2;
    $Overlay.$f_LOG10E__elemental2_core_JsMath_$Overlay = Math.LOG10E;
    $Overlay.$f_LOG2E__elemental2_core_JsMath_$Overlay = Math.LOG2E;
    $Overlay.$f_PI__elemental2_core_JsMath_$Overlay = Math.PI;
    $Overlay.$f_SQRT1_2__elemental2_core_JsMath_$Overlay = Math.SQRT1_2;
    $Overlay.$f_SQRT2__elemental2_core_JsMath_$Overlay = Math.SQRT2;
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('Math'));


/** @private {number} */
$Overlay.$f_E__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_LN10__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_LN2__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_LOG10E__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_LOG2E__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PI__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SQRT1_2__elemental2_core_JsMath_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SQRT2__elemental2_core_JsMath_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=JsMath$$Overlay.js.map