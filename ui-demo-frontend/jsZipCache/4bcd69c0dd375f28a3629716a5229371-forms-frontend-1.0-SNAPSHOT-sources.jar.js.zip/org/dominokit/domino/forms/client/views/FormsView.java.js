/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.views.FormsView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.forms.client.views.FormsView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView');
const _HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.forms.client.views.FormsView.$LambdaAdaptor');


// Re-exports the implementation.
var FormsView = goog.require('org.dominokit.domino.forms.client.views.FormsView$impl');
exports = FormsView;
 