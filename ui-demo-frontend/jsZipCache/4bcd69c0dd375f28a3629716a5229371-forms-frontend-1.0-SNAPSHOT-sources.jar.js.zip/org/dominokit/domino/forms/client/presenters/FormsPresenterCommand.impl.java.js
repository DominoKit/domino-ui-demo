/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.presenters.FormsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.presenters.FormsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let FormsPresenter = goog.forwardDeclare('org.dominokit.domino.forms.client.presenters.FormsPresenter$impl');


/**
 * @extends {PresenterCommand<FormsPresenter>}
  */
class FormsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsPresenterCommand()'.
   * @return {!FormsPresenterCommand}
   * @public
   */
  static $create__() {
    FormsPresenterCommand.$clinit();
    let $instance = new FormsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_forms_client_presenters_FormsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_presenters_FormsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.forms.client.presenters.FormsPresenterCommand'));




exports = FormsPresenterCommand; 
//# sourceMappingURL=FormsPresenterCommand.js.map