/**
 * @fileoverview transpiled from org.slf4j.helpers.MessageFormatter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.helpers.MessageFormatter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _Throwable = goog.require('java.lang.Throwable');
const _HashSet = goog.require('java.util.HashSet');
const _Set = goog.require('java.util.Set');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Long = goog.require('nativebootstrap.Long');
const _FormattingTuple = goog.require('org.slf4j.helpers.FormattingTuple');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');
const _$boolean = goog.require('vmbootstrap.primitives.$boolean');
const _$byte = goog.require('vmbootstrap.primitives.$byte');
const _$char = goog.require('vmbootstrap.primitives.$char');
const _$double = goog.require('vmbootstrap.primitives.$double');
const _$float = goog.require('vmbootstrap.primitives.$float');
const _$int = goog.require('vmbootstrap.primitives.$int');
const _$long = goog.require('vmbootstrap.primitives.$long');
const _$short = goog.require('vmbootstrap.primitives.$short');


// Re-exports the implementation.
var MessageFormatter = goog.require('org.slf4j.helpers.MessageFormatter$impl');
exports = MessageFormatter;
 