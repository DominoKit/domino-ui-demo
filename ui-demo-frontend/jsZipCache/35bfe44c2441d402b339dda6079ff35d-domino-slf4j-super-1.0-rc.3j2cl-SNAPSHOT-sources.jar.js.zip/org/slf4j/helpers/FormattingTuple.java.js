/**
 * @fileoverview transpiled from org.slf4j.helpers.FormattingTuple.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.helpers.FormattingTuple');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Throwable = goog.require('java.lang.Throwable');


// Re-exports the implementation.
var FormattingTuple = goog.require('org.slf4j.helpers.FormattingTuple$impl');
exports = FormattingTuple;
 