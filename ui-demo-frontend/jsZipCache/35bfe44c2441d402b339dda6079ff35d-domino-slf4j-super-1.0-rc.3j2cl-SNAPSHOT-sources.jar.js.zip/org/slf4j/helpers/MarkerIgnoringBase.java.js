/**
 * @fileoverview transpiled from org.slf4j.helpers.MarkerIgnoringBase.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.helpers.MarkerIgnoringBase');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');
const _Logger = goog.require('org.slf4j.Logger');
const _NamedLoggerBase = goog.require('org.slf4j.helpers.NamedLoggerBase');
const _j_l_String = goog.require('java.lang.String');
const _Throwable = goog.require('java.lang.Throwable');
const _Marker = goog.require('org.slf4j.Marker');


// Re-exports the implementation.
var MarkerIgnoringBase = goog.require('org.slf4j.helpers.MarkerIgnoringBase$impl');
exports = MarkerIgnoringBase;
 