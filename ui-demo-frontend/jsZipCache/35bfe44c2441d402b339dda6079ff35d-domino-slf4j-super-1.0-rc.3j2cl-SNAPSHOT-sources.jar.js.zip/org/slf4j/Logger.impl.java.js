/**
 * @fileoverview transpiled from org.slf4j.Logger.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.Logger$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let Marker = goog.forwardDeclare('org.slf4j.Marker$impl');


/**
 * @interface
 */
class Logger {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getName__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isTraceEnabled__() {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_trace__java_lang_String(msg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Object(format, arg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Throwable(msg, t) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isTraceEnabled__org_slf4j_Marker(marker) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String(marker, msg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, argArray) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_trace__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isDebugEnabled__() {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_debug__java_lang_String(msg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Object(format, arg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Throwable(msg, t) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isDebugEnabled__org_slf4j_Marker(marker) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String(marker, msg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_debug__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isInfoEnabled__() {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_info__java_lang_String(msg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Object(format, arg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_info__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Throwable(msg, t) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isInfoEnabled__org_slf4j_Marker(marker) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String(marker, msg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_info__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWarnEnabled__() {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_warn__java_lang_String(msg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Object(format, arg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Throwable(msg, t) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isWarnEnabled__org_slf4j_Marker(marker) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String(marker, msg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_warn__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isErrorEnabled__() {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_error__java_lang_String(msg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Object(format, arg) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_error__java_lang_String__arrayOf_java_lang_Object(format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Throwable(msg, t) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @return {boolean}
   * @public
   */
  m_isErrorEnabled__org_slf4j_Marker(marker) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String(marker, msg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Object(marker, format, arg) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Object__java_lang_Object(marker, format, arg1, arg2) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} format
   * @param {Array<*>} arguments$1$
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__arrayOf_java_lang_Object(marker, format, arguments$1$) {
  }
  
  /**
   * @abstract
   * @param {Marker} marker
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_error__org_slf4j_Marker__java_lang_String__java_lang_Throwable(marker, msg, t) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_slf4j_Logger = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_slf4j_Logger;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_slf4j_Logger;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Logger.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Logger, $Util.$makeClassName('org.slf4j.Logger'));


/** @public {?string} @const */
Logger.f_ROOT_LOGGER_NAME__org_slf4j_Logger = "ROOT";


Logger.$markImplementor(/** @type {Function} */ (Logger));


exports = Logger; 
//# sourceMappingURL=Logger.js.map