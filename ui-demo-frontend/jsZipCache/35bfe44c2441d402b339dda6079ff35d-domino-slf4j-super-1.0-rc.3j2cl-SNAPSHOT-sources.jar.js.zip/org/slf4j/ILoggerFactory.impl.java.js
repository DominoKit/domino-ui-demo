/**
 * @fileoverview transpiled from org.slf4j.ILoggerFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.ILoggerFactory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.slf4j.ILoggerFactory.$LambdaAdaptor$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');


/**
 * @interface
 */
class ILoggerFactory {
  /**
   * @abstract
   * @param {?string} name
   * @return {Logger}
   * @public
   */
  m_getLogger__java_lang_String(name) {
  }
  
  /**
   * @param {?function(?string):Logger} fn
   * @return {ILoggerFactory}
   * @public
   */
  static $adapt(fn) {
    ILoggerFactory.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_slf4j_ILoggerFactory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_slf4j_ILoggerFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_slf4j_ILoggerFactory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ILoggerFactory.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.slf4j.ILoggerFactory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ILoggerFactory, $Util.$makeClassName('org.slf4j.ILoggerFactory'));


ILoggerFactory.$markImplementor(/** @type {Function} */ (ILoggerFactory));


exports = ILoggerFactory; 
//# sourceMappingURL=ILoggerFactory.js.map