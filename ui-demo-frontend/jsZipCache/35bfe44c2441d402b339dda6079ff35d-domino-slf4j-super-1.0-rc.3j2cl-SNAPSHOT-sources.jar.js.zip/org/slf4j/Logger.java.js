/**
 * @fileoverview transpiled from org.slf4j.Logger.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.Logger');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Throwable = goog.require('java.lang.Throwable');
const _Marker = goog.require('org.slf4j.Marker');


// Re-exports the implementation.
var Logger = goog.require('org.slf4j.Logger$impl');
exports = Logger;
 