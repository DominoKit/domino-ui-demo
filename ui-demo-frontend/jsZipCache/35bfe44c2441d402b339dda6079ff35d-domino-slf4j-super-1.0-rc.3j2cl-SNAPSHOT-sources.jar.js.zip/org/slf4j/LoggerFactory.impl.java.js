/**
 * @fileoverview transpiled from org.slf4j.LoggerFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.LoggerFactory$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let GWTLoggerAdapter = goog.forwardDeclare('org.slf4j.GWTLoggerAdapter$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');


class LoggerFactory extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LoggerFactory()'.
   * @return {!LoggerFactory}
   * @public
   */
  static $create__() {
    LoggerFactory.$clinit();
    let $instance = new LoggerFactory();
    $instance.$ctor__org_slf4j_LoggerFactory__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoggerFactory()'.
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_LoggerFactory__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} name
   * @return {Logger}
   * @public
   */
  static m_getLogger__java_lang_String(name) {
    LoggerFactory.$clinit();
    return GWTLoggerAdapter.$create__java_lang_String(name);
  }
  
  /**
   * @param {Class} clazz
   * @return {Logger}
   * @public
   */
  static m_getLogger__java_lang_Class(clazz) {
    LoggerFactory.$clinit();
    return LoggerFactory.m_getLogger__java_lang_String(clazz.m_getName__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoggerFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoggerFactory);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoggerFactory.$clinit = function() {};
    GWTLoggerAdapter = goog.module.get('org.slf4j.GWTLoggerAdapter$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LoggerFactory, $Util.$makeClassName('org.slf4j.LoggerFactory'));




exports = LoggerFactory; 
//# sourceMappingURL=LoggerFactory.js.map