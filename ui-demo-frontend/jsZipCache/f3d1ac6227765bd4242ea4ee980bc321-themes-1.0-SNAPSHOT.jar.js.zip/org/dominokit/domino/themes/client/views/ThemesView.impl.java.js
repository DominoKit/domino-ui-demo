/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ThemesView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.views.ThemesView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let ThemeAppliedHandler = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler$impl');


/**
 * @interface
 * @extends {ContentView}
 */
class ThemesView {
  /**
   * @abstract
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
  }
  
  /**
   * @abstract
   * @param {?string} theme
   * @return {void}
   * @public
   */
  m_applyTheme__java_lang_String(theme) {
  }
  
  /**
   * @abstract
   * @param {?string} theme
   * @return {void}
   * @public
   */
  m_registerTheme__java_lang_String(theme) {
  }
  
  /**
   * @abstract
   * @param {?string} theme
   * @param {boolean} active
   * @return {void}
   * @public
   */
  m_registerTheme__java_lang_String__boolean(theme, active) {
  }
  
  /**
   * @abstract
   * @param {ThemeAppliedHandler} themeAppliedHandler
   * @return {void}
   * @public
   */
  m_onThemeApplied__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler(themeAppliedHandler) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ContentView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_themes_client_views_ThemesView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_themes_client_views_ThemesView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_themes_client_views_ThemesView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesView.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(ThemesView, $Util.$makeClassName('org.dominokit.domino.themes.client.views.ThemesView'));


ThemesView.$markImplementor(/** @type {Function} */ (ThemesView));


exports = ThemesView; 
//# sourceMappingURL=ThemesView.js.map