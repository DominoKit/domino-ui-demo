/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.listeners.ThemesPresenterListenerForLayoutEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.listeners.ThemesPresenterListenerForLayoutEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutEvent = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
let ThemesPresenter = goog.forwardDeclare('org.dominokit.domino.themes.client.presenters.ThemesPresenter$impl');
let ThemesPresenterCommand = goog.forwardDeclare('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<LayoutEvent>}
  */
class ThemesPresenterListenerForLayoutEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThemesPresenterListenerForLayoutEvent()'.
   * @return {!ThemesPresenterListenerForLayoutEvent}
   * @public
   */
  static $create__() {
    ThemesPresenterListenerForLayoutEvent.$clinit();
    let $instance = new ThemesPresenterListenerForLayoutEvent();
    $instance.$ctor__org_dominokit_domino_themes_client_listeners_ThemesPresenterListenerForLayoutEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThemesPresenterListenerForLayoutEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_listeners_ThemesPresenterListenerForLayoutEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(event) {
    ThemesPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ThemesPresenter */ presenter) =>{
      presenter.m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(event.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(/**@type {LayoutEvent} */ ($Casts.$to(arg0, LayoutEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesPresenterListenerForLayoutEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesPresenterListenerForLayoutEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesPresenterListenerForLayoutEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutEvent = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
    ThemesPresenterCommand = goog.module.get('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThemesPresenterListenerForLayoutEvent, $Util.$makeClassName('org.dominokit.domino.themes.client.listeners.ThemesPresenterListenerForLayoutEvent'));


DominoEventListener.$markImplementor(ThemesPresenterListenerForLayoutEvent);


exports = ThemesPresenterListenerForLayoutEvent; 
//# sourceMappingURL=ThemesPresenterListenerForLayoutEvent.js.map