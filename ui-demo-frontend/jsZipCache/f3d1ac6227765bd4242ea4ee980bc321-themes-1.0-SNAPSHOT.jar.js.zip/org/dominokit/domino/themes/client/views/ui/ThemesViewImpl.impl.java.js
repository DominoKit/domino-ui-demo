/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ThemesView = goog.require('org.dominokit.domino.themes.client.views.ThemesView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let ThemeAppliedHandler = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler$impl');
let ThemesPanel = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ui.ThemesPanel$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$3$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Theme = goog.forwardDeclare('org.dominokit.domino.ui.themes.Theme$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ThemesView}
  */
class ThemesViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ThemesPanel} */
    this.f_themesPanel__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_;
    /** @public {HTMLLIElement} */
    this.f_activeTheme__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_;
    /** @public {Map<?string, HTMLLIElement>} */
    this.f_themesElements__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_;
    /** @public {ThemeAppliedHandler} */
    this.f_themeAppliedHandler__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ThemesViewImpl()'.
   * @return {!ThemesViewImpl}
   * @public
   */
  static $create__() {
    ThemesViewImpl.$clinit();
    let $instance = new ThemesViewImpl();
    $instance.$ctor__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThemesViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl();
  }
  
  /**
   * @override
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
    let hideElement = this.m_makeIcon__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(Icons.f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons.m_keyboard_tab__());
    hideElement.addEventListener("click", new $LambdaAdaptor$1(((/** Event */ e) =>{
      if (Objects.m_nonNull__java_lang_Object(Elements.m_label__())) {
        layout.m_hideRightPanel__();
      }
    })));
    this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.m_getHeaderBar__().m_appendChild__elemental2_dom_Node(hideElement);
    this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.m_style__().m_setMarginBottom__java_lang_String("0px");
    this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.m_bodyStyle__().m_setPadding__java_lang_String("0px");
    this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.m_appendChild__elemental2_dom_Node(this.f_themesPanel__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.m_asElement__());
    let actionItem = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(layout.m_addActionItem__java_lang_String("style").m_get__()), $Overlay));
    actionItem.addEventListener("click", new $LambdaAdaptor$2(((/** Event */ e$1$) =>{
      layout.m_setRightPanelContent__org_dominokit_domino_api_shared_extension_Content(this.m_getContent__());
      layout.m_showRightPanel__();
    })));
  }
  
  /**
   * @param {Icon} icon
   * @return {HTMLLIElement}
   * @public
   */
  m_makeIcon__org_dominokit_domino_ui_icons_Icon_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(icon) {
    return /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__elemental2_dom_Node(icon.m_asElement__()), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    let /** Card */ $$qualifier0;
    return /**@type {Content<HTMLDivElement>} */ ($Casts.$to(($$qualifier0 = this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_, Content.$adapt((() =>{
      return /**@type {HTMLDivElement} */ ($Casts.$to($$qualifier0.m_asElement__(), HTMLDivElement_$Overlay));
    }))), Content));
  }
  
  /**
   * @override
   * @param {?string} theme
   * @return {void}
   * @public
   */
  m_registerTheme__java_lang_String(theme) {
    this.m_registerTheme__java_lang_String__boolean(theme, false);
  }
  
  /**
   * @override
   * @param {?string} theme
   * @param {boolean} active
   * @return {void}
   * @public
   */
  m_registerTheme__java_lang_String__boolean(theme, active) {
    this.m_addTheme__org_dominokit_domino_ui_themes_Theme__boolean_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(ThemesViewImpl.m_of__java_lang_String_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme), active);
  }
  
  /**
   * @param {Theme} theme
   * @param {boolean} active
   * @return {HTMLLIElement}
   * @public
   */
  m_addTheme__org_dominokit_domino_ui_themes_Theme__boolean_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme, active) {
    let themeElement = /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(theme.m_getThemeStyle__(), "theme-", "")], j_l_String)))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String(theme.m_getName__()), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
    this.f_themesElements__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.put(theme.m_getName__(), themeElement);
    if (active) {
      themeElement.classList.add("active");
      this.f_activeTheme__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = themeElement;
      this.m_applyTheme__org_dominokit_domino_ui_themes_Theme_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme);
    }
    this.f_themesPanel__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.f_themesContainer__org_dominokit_domino_themes_client_views_ui_ThemesPanel.appendChild(themeElement);
    themeElement.addEventListener("click", new $LambdaAdaptor$3(((/** Event */ evt) =>{
      this.m_applyTheme__org_dominokit_domino_ui_themes_Theme_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme);
    })));
    return themeElement;
  }
  
  /**
   * @param {Theme} theme
   * @return {void}
   * @public
   */
  m_applyTheme__org_dominokit_domino_ui_themes_Theme_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme) {
    if (Objects.m_nonNull__java_lang_Object(this.f_activeTheme__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_)) {
      this.f_activeTheme__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.classList.remove("active");
    }
    let themeElement = /**@type {HTMLLIElement} */ ($Casts.$to(this.f_themesElements__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.get(theme.m_getName__()), HTMLLIElement_$Overlay));
    this.f_activeTheme__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = themeElement;
    themeElement.classList.add("active");
    theme.m_apply__();
    if (Objects.m_nonNull__java_lang_Object(this.f_themeAppliedHandler__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_)) {
      this.f_themeAppliedHandler__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_.m_onThemeApplied__java_lang_String(theme.m_getName__());
    }
  }
  
  /**
   * @override
   * @param {?string} theme
   * @return {void}
   * @public
   */
  m_applyTheme__java_lang_String(theme) {
    if (Objects.m_nonNull__java_lang_Object(ThemesViewImpl.m_of__java_lang_String_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme))) {
      this.m_applyTheme__org_dominokit_domino_ui_themes_Theme_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(ThemesViewImpl.m_of__java_lang_String_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(theme));
    }
  }
  
  /**
   * @override
   * @param {ThemeAppliedHandler} themeAppliedHandler
   * @return {void}
   * @public
   */
  m_onThemeApplied__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler(themeAppliedHandler) {
    this.f_themeAppliedHandler__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = themeAppliedHandler;
  }
  
  /**
   * @param {?string} themeKey
   * @return {Theme}
   * @public
   */
  static m_of__java_lang_String_$p_org_dominokit_domino_themes_client_views_ui_ThemesViewImpl(themeKey) {
    ThemesViewImpl.$clinit();
    switch ($InternalPreconditions.m_checkNotNull__java_lang_Object(themeKey)) {
      case "red": 
        return ColorScheme.f_RED__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "pink": 
        return ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "purple": 
        return ColorScheme.f_PURPLE__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "deep_purple": 
        return ColorScheme.f_DEEP_PURPLE__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "indigo": 
        return ColorScheme.f_INDIGO__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "blue": 
        return ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "light_blue": 
        return ColorScheme.f_LIGHT_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "cyan": 
        return ColorScheme.f_CYAN__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "teal": 
        return ColorScheme.f_TEAL__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "green": 
        return ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "light_green": 
        return ColorScheme.f_LIGHT_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "lime": 
        return ColorScheme.f_LIME__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "yellow": 
        return ColorScheme.f_YELLOW__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "amber": 
        return ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "orange": 
        return ColorScheme.f_ORANGE__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "deep_orange": 
        return ColorScheme.f_DEEP_ORANGE__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "brown": 
        return ColorScheme.f_BROWN__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "grey": 
        return ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "blue_grey": 
        return ColorScheme.f_BLUE_GREY__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      case "black": 
        return ColorScheme.f_BLACK__org_dominokit_domino_ui_style_ColorScheme.m_theme__();
      default: 
        return Theme.f_currentTheme__org_dominokit_domino_ui_themes_Theme;
    }
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl() {
    this.f_themesPanel__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = ThemesPanel.m_create___$pp_org_dominokit_domino_themes_client_views_ui();
    this.f_themesElements__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = /**@type {!HashMap<?string, HTMLLIElement>} */ (HashMap.$create__());
    this.f_card__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = Card.m_create__java_lang_String__java_lang_String("Themes", "Select theme to apply.");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_() {
    return (ThemesViewImpl.$clinit(), ThemesViewImpl.$f_LOGGER__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_(value) {
    (ThemesViewImpl.$clinit(), ThemesViewImpl.$f_LOGGER__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesViewImpl.$clinit = function() {};
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Class = goog.module.get('java.lang.Class$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    Content = goog.module.get('org.dominokit.domino.api.shared.extension.Content$impl');
    ThemesPanel = goog.module.get('org.dominokit.domino.themes.client.views.ui.ThemesPanel$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$3$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Theme = goog.module.get('org.dominokit.domino.ui.themes.Theme$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    HasContent.$clinit();
    ThemesViewImpl.$f_LOGGER__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ThemesViewImpl));
  }
  
  
};

$Util.$setClassMetadata(ThemesViewImpl, $Util.$makeClassName('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl'));


/** @private {Logger} */
ThemesViewImpl.$f_LOGGER__org_dominokit_domino_themes_client_views_ui_ThemesViewImpl_;


ThemesView.$markImplementor(ThemesViewImpl);


exports = ThemesViewImpl; 
//# sourceMappingURL=ThemesViewImpl.js.map