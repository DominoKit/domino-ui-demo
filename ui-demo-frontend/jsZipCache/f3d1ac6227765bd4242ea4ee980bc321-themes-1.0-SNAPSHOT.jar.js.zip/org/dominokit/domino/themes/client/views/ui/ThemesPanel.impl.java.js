/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ui.ThemesPanel.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.views.ui.ThemesPanel$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let Templated__ThemesPanel = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel$impl');


/**
 * @abstract
 * @implements {IsElement<HTMLDivElement>}
  */
class ThemesPanel extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLUListElement} */
    this.f_themesContainer__org_dominokit_domino_themes_client_views_ui_ThemesPanel;
  }
  
  /**
   * Initialization from constructor 'ThemesPanel()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_views_ui_ThemesPanel__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {ThemesPanel}
   * @public
   */
  static m_create___$pp_org_dominokit_domino_themes_client_views_ui() {
    ThemesPanel.$clinit();
    return Templated__ThemesPanel.$create__();
  }
  
  /**
   * @abstract
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesPanel;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesPanel);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesPanel.$clinit = function() {};
    Templated__ThemesPanel = goog.module.get('org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThemesPanel, $Util.$makeClassName('org.dominokit.domino.themes.client.views.ui.ThemesPanel'));


IsElement.$markImplementor(ThemesPanel);


exports = ThemesPanel; 
//# sourceMappingURL=ThemesPanel.js.map