/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.listeners.ThemesPresenterListenerForLayoutEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.themes.client.listeners.ThemesPresenterListenerForLayoutEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _LayoutEvent = goog.require('org.dominokit.domino.layout.shared.extension.LayoutEvent');
const _ThemesPresenter = goog.require('org.dominokit.domino.themes.client.presenters.ThemesPresenter');
const _ThemesPresenterCommand = goog.require('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ThemesPresenterListenerForLayoutEvent = goog.require('org.dominokit.domino.themes.client.listeners.ThemesPresenterListenerForLayoutEvent$impl');
exports = ThemesPresenterListenerForLayoutEvent;
 