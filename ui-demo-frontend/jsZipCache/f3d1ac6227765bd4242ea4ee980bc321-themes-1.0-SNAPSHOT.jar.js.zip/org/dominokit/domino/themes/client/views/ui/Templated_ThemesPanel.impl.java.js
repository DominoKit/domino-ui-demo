/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ThemesPanel = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesPanel$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let TemplateUtil = goog.forwardDeclare('org.jboss.gwt.elemento.template.TemplateUtil$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Templated__ThemesPanel extends ThemesPanel {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_;
  }
  
  /**
   * Factory method corresponding to constructor 'Templated_ThemesPanel()'.
   * @return {!Templated__ThemesPanel}
   * @public
   */
  static $create__() {
    Templated__ThemesPanel.$clinit();
    let $instance = new Templated__ThemesPanel();
    $instance.$ctor__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Templated_ThemesPanel()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel__() {
    this.$ctor__org_dominokit_domino_themes_client_views_ui_ThemesPanel__();
    this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_ = /**@type {HTMLDivElement} */ ($Casts.$to($Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.createElement("div"), HTMLDivElement_$Overlay));
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_, "class", "slimScrollDiv");
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_, "style", "position: relative; width: auto;");
    this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_.innerHTML = "<ul data-element=\"themesContainer\" class=\"demo-choose-skin\" style=\"width: auto;\"> </ul>";
    if ($Equality.$same(this.f_themesContainer__org_dominokit_domino_themes_client_views_ui_ThemesPanel, null)) {
      this.f_themesContainer__org_dominokit_domino_themes_client_views_ui_ThemesPanel = /**@type {HTMLUListElement} */ ($Casts.$to(TemplateUtil.m_resolveElementAs__elemental2_dom_HTMLElement__java_lang_String(this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_, "themesContainer"), HTMLUListElement_$Overlay));
    } else {
      TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_, "themesContainer", this.f_themesContainer__org_dominokit_domino_themes_client_views_ui_ThemesPanel);
    }
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_templated_themespanel_root_element__org_dominokit_domino_themes_client_views_ui_Templated_ThemesPanel_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Templated__ThemesPanel;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Templated__ThemesPanel);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Templated__ThemesPanel.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    TemplateUtil = goog.module.get('org.jboss.gwt.elemento.template.TemplateUtil$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ThemesPanel.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Templated__ThemesPanel, $Util.$makeClassName('org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel'));




exports = Templated__ThemesPanel; 
//# sourceMappingURL=Templated_ThemesPanel.js.map