/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ThemesView$ThemeAppliedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ThemeAppliedHandler {
  /**
   * @abstract
   * @param {?string} theme
   * @return {void}
   * @public
   */
  m_onThemeApplied__java_lang_String(theme) {
  }
  
  /**
   * @param {?function(?string):void} fn
   * @return {ThemeAppliedHandler}
   * @public
   */
  static $adapt(fn) {
    ThemeAppliedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemeAppliedHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ThemeAppliedHandler, $Util.$makeClassName('org.dominokit.domino.themes.client.views.ThemesView$ThemeAppliedHandler'));


ThemeAppliedHandler.$markImplementor(/** @type {Function} */ (ThemeAppliedHandler));


exports = ThemeAppliedHandler; 
//# sourceMappingURL=ThemesView$ThemeAppliedHandler.js.map