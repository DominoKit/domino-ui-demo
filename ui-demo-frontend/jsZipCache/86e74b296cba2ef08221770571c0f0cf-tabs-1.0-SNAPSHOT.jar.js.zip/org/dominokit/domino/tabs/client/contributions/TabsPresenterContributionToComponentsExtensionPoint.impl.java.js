/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.contributions.TabsPresenterContributionToComponentsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tabs.client.contributions.TabsPresenterContributionToComponentsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let TabsPresenter = goog.forwardDeclare('org.dominokit.domino.tabs.client.presenters.TabsPresenter$impl');
let TabsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentsExtensionPoint>}
  */
class TabsPresenterContributionToComponentsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TabsPresenterContributionToComponentsExtensionPoint()'.
   * @return {!TabsPresenterContributionToComponentsExtensionPoint}
   * @public
   */
  static $create__() {
    TabsPresenterContributionToComponentsExtensionPoint.$clinit();
    let $instance = new TabsPresenterContributionToComponentsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_tabs_client_contributions_TabsPresenterContributionToComponentsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TabsPresenterContributionToComponentsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tabs_client_contributions_TabsPresenterContributionToComponentsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(extensionPoint) {
    TabsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** TabsPresenter */ presenter) =>{
      presenter.m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(/**@type {ComponentsExtensionPoint} */ ($Casts.$to(arg0, ComponentsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TabsPresenterContributionToComponentsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TabsPresenterContributionToComponentsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TabsPresenterContributionToComponentsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    TabsPresenterCommand = goog.module.get('org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TabsPresenterContributionToComponentsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.tabs.client.contributions.TabsPresenterContributionToComponentsExtensionPoint'));


Contribution.$markImplementor(TabsPresenterContributionToComponentsExtensionPoint);


exports = TabsPresenterContributionToComponentsExtensionPoint; 
//# sourceMappingURL=TabsPresenterContributionToComponentsExtensionPoint.js.map