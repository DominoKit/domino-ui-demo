package org.dominokit.domino.tabs.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class TabsPresenterContributionToComponentsExtensionPoint implements Contribution<ComponentsExtensionPoint> {
  @Override
  public void contribute(ComponentsExtensionPoint extensionPoint) {
    new TabsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentsModule(extensionPoint.context())).send();
  }
}
