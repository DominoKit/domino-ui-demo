/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let TabsPresenter = goog.forwardDeclare('org.dominokit.domino.tabs.client.presenters.TabsPresenter$impl');


/**
 * @extends {PresenterCommand<TabsPresenter>}
  */
class TabsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TabsPresenterCommand()'.
   * @return {!TabsPresenterCommand}
   * @public
   */
  static $create__() {
    TabsPresenterCommand.$clinit();
    let $instance = new TabsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_tabs_client_presenters_TabsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TabsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tabs_client_presenters_TabsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TabsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TabsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TabsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TabsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.tabs.client.presenters.TabsPresenterCommand'));




exports = TabsPresenterCommand; 
//# sourceMappingURL=TabsPresenterCommand.js.map