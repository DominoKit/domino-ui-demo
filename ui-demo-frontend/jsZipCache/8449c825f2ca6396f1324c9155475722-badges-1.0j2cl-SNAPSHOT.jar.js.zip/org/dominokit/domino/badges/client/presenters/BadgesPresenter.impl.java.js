/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.presenters.BadgesPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.badges.client.presenters.BadgesPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.badges.client.presenters.BadgesPresenter.$1$impl');
let BadgesView = goog.forwardDeclare('org.dominokit.domino.badges.client.views.BadgesView$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<BadgesView>}
  */
class BadgesPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BadgesPresenter()'.
   * @return {!BadgesPresenter}
   * @public
   */
  static $create__() {
    BadgesPresenter.$clinit();
    let $instance = new BadgesPresenter();
    $instance.$ctor__org_dominokit_domino_badges_client_presenters_BadgesPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BadgesPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_badges_client_presenters_BadgesPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_badges_client_presenters_BadgesPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_badges_client_presenters_BadgesPresenter_() {
    return (BadgesPresenter.$clinit(), BadgesPresenter.$f_LOGGER__org_dominokit_domino_badges_client_presenters_BadgesPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_badges_client_presenters_BadgesPresenter_(value) {
    (BadgesPresenter.$clinit(), BadgesPresenter.$f_LOGGER__org_dominokit_domino_badges_client_presenters_BadgesPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BadgesPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BadgesPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BadgesPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.badges.client.presenters.BadgesPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    BadgesPresenter.$f_LOGGER__org_dominokit_domino_badges_client_presenters_BadgesPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(BadgesPresenter));
  }
  
  
};

$Util.$setClassMetadata(BadgesPresenter, $Util.$makeClassName('org.dominokit.domino.badges.client.presenters.BadgesPresenter'));


/** @private {Logger} */
BadgesPresenter.$f_LOGGER__org_dominokit_domino_badges_client_presenters_BadgesPresenter_;




exports = BadgesPresenter; 
//# sourceMappingURL=BadgesPresenter.js.map