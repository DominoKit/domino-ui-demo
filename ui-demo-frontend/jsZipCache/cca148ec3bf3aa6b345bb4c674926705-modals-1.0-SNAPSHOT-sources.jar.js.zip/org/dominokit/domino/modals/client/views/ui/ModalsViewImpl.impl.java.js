/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const ModalsView = goog.require('org.dominokit.domino.modals.client.views.ModalsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let ComponentRemoveHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$17$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$18$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$20$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$9$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ModalSize = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
let ModalType = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.ModalType$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ModalsView}
  */
class ModalsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
    /** @public {ModalDialog} */
    this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
    /** @public {ComponentRemoveHandler} */
    this.f_closeHandler__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ModalsViewImpl()'.
   * @return {!ModalsViewImpl}
   * @public
   */
  static $create__() {
    ModalsViewImpl.$clinit();
    let $instance = new ModalsViewImpl();
    $instance.$ctor__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(ModalsViewImpl.f_MODULE_NAME__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("MODALS").m_asElement__());
    this.m_initModalsSize___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
    this.m_initSheets___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
    this.m_initModalColor___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSheets___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("SHEETS MODALS", "Sheets are modal that stick to screen edges.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_style__().m_setMargin__java_lang_String("10px").m_get__(), Row__12)).m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column) =>{
      column.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span__int__int__int__int(3, 3, 6, 12).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("LEFT - LARGE").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
        let modal = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("LEFT SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_LEFT_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("LEFT - DEFAULT").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
        let modal$1$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("LEFT SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_LEFT_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$1$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("LEFT - SMALL").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
        let modal$2$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("LEFT SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_LEFT_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$2$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span__int__int__int__int(3, 3, 6, 12).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("TOP").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt$3$) =>{
        let modal$3$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("TOP SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_TOP_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$3$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span__int__int__int__int(3, 3, 6, 12).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("BOTTOM - LARGE").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$5(((/** Event */ evt$4$) =>{
        let modal$4$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("TOP SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_BOTTOM_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$4$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span__int__int__int__int(3, 3, 6, 12).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("RIGHT - LARGE").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$6(((/** Event */ evt$5$) =>{
        let modal$5$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("TOP SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_RIGHT_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$5$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("RIGHT - DEFAULT").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$7(((/** Event */ evt$6$) =>{
        let modal$6$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("TOP SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_RIGHT_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$6$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__java_lang_String("RIGHT - SMALL").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$8(((/** Event */ evt$7$) =>{
        let modal$7$ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("TOP SHEET").m_setType__org_dominokit_domino_ui_modals_IsModalDialog_ModalType(ModalType.f_RIGHT_SHEET__org_dominokit_domino_ui_modals_IsModalDialog_ModalType), ModalDialog)).m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize), ModalDialog)).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)), ModalDialog));
        this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modal$7$);
      }))), Button)).m_style__().m_setMargin__java_lang_String("5px").m_setMinWidth__java_lang_String("200px"))), Column))));
    })))).m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ModalsViewImpl.f_MODULE_NAME__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl, "sheetModals").m_asElement__());
  }
  
  /**
   * @param {ModalDialog} dialog
   * @return {void}
   * @public
   */
  m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(dialog) {
    dialog.m_open__();
    this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = dialog;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initModalsSize___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    let defaultSizeModal = this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
    let defaultSizeButton = Button.m_createDefault__java_lang_String("MODAL - DEFAULT SIZE");
    defaultSizeButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$9(((/** Event */ e) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(defaultSizeModal);
    })));
    let largeSizeModal = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_large__(), ModalDialog));
    let largeSizeButton = Button.m_createDefault__java_lang_String("MODAL - LARGE SIZE");
    largeSizeButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$10(((/** Event */ e$1$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(largeSizeModal);
    })));
    let smallSizeModal = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_small__(), ModalDialog));
    let smallSizeButton = Button.m_createDefault__java_lang_String("MODAL - SMALL SIZE");
    smallSizeButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$11(((/** Event */ e$2$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(smallSizeModal);
    })));
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("MODAL SIZE EXAMPLE", "Modals are streamlined, but flexible, dialog prompts with the minimum required functionality and smart defaults.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_span4__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column) =>{
      column.m_appendChild__org_jboss_gwt_elemento_core_IsElement(defaultSizeButton);
    }))).m_span4__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$1$) =>{
      column$1$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(largeSizeButton);
    }))).m_span4__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$2$) =>{
      column$2$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(smallSizeButton);
    })))).m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ModalsViewImpl.f_MODULE_NAME__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl, "initModalsSize").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initModalColor___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    let modalDialogRed = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), ModalDialog));
    let redButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("RED").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), Button));
    redButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$12(((/** Event */ e) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogRed);
    })));
    let modalDialogPink = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color), ModalDialog));
    let pinkButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("PINK").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color), Button));
    pinkButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$13(((/** Event */ e$1$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogPink);
    })));
    let modalDialogPurple = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let purpleButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color), Button));
    purpleButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$14(((/** Event */ e$2$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogPurple);
    })));
    let modalDialogDeepPurple = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let deepPurpleButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("DEEP PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color), Button));
    deepPurpleButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$15(((/** Event */ e$3$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogDeepPurple);
    })));
    let modalDialogIndigo = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color), ModalDialog));
    let indigoButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("INDIGO").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color), Button));
    indigoButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$16(((/** Event */ e$4$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogIndigo);
    })));
    let modalDialogBlue = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let blueButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("BLUE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color), Button));
    blueButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$17(((/** Event */ e$5$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogBlue);
    })));
    let modalDialogOrange = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let orangeButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("ORANGE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color), Button));
    orangeButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$18(((/** Event */ e$6$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogOrange);
    })));
    let modalDialogGreen = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color), ModalDialog));
    let greenButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color), Button));
    greenButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$19(((/** Event */ e$7$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogGreen);
    })));
    let modalDialogTeal = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color), ModalDialog));
    let tealButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("TEAL").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color), Button));
    tealButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$20(((/** Event */ e$8$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogTeal);
    })));
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("WITH MATERIAL DESIGN COLORS", "You can use material design colors.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["button-demo"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(redButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(pinkButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(purpleButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(deepPurpleButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(indigoButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(blueButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(orangeButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(greenButton), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(tealButton), IsElement))).m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ModalsViewImpl.f_MODULE_NAME__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl, "initModalColor").m_asElement__());
  }
  
  /**
   * @return {ModalDialog}
   * @public
   */
  m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    let modal = /**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String("Modal title").m_setAutoClose__boolean(true), ModalDialog));
    modal.m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_));
    let closeButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("CLOSE").m_linkify__(), Button));
    let saveButton = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("SAVE CHANGES").m_linkify__(), Button));
    let closeModalListener = new $LambdaAdaptor$21(((/** Event */ evt) =>{
      modal.m_close__();
    }));
    closeButton.m_addClickListener__elemental2_dom_EventListener(closeModalListener);
    saveButton.m_addClickListener__elemental2_dom_EventListener(closeModalListener);
    modal.m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(saveButton);
    modal.m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(closeButton);
    return modal;
  }
  
  /**
   * @override
   * @return {ComponentRemoveHandler}
   * @public
   */
  m_cleanup__() {
    return this.f_closeHandler__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_closeHandler__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = ComponentRemoveHandler.$adapt((() =>{
      if (Objects.m_nonNull__java_lang_Object(this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)) {
        this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.m_close__();
      }
    }));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    ComponentRemoveHandler = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$17$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$18$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$20$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$9$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ModalSize = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
    ModalType = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.ModalType$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ModalsViewImpl, $Util.$makeClassName('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl'));


/** @public {?string} @const */
ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales orci ante, sed ornare eros vestibulum ut. Ut accumsan vitae eros sit amet tristique. Nullam scelerisque nunc enim, non dignissim nibh faucibus ullamcorper. Fusce pulvinar libero vel ligula iaculis ullamcorper. Integer dapibus, mi ac tempor varius, purus nibh mattis erat, vitae porta nunc nisi non tellus. Vivamus mollis ante non massa egestas fringilla. Vestibulum egestas consectetur nunc at ultricies. Morbi quis consectetur nunc.";


/** @public {?string} @const */
ModalsViewImpl.f_MODULE_NAME__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl = "modals";


ModalsView.$markImplementor(ModalsViewImpl);


exports = ModalsViewImpl; 
//# sourceMappingURL=ModalsViewImpl.js.map