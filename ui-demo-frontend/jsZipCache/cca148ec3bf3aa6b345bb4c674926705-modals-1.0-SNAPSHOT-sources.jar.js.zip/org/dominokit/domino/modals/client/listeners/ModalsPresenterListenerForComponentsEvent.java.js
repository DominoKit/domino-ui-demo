/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.listeners.ModalsPresenterListenerForComponentsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.modals.client.listeners.ModalsPresenterListenerForComponentsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');
const _ModalsPresenter = goog.require('org.dominokit.domino.modals.client.presenters.ModalsPresenter');
const _ModalsPresenterCommand = goog.require('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ModalsPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.modals.client.listeners.ModalsPresenterListenerForComponentsEvent$impl');
exports = ModalsPresenterListenerForComponentsEvent;
 