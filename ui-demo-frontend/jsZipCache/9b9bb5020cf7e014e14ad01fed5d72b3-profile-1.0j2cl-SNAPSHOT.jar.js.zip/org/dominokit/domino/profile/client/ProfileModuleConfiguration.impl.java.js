/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.ProfileModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.ProfileModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let LayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.profile.client.ProfileModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.profile.client.ProfileModuleConfiguration.$2$impl');
let ProfilePresenterContributionToLayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.profile.client.contributions.ProfilePresenterContributionToLayoutExtensionPoint$impl');
let ProfilePresenter = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');
let ProfilePresenterCommand = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class ProfileModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProfileModuleConfiguration()'.
   * @return {!ProfileModuleConfiguration}
   * @public
   */
  static $create__() {
    ProfileModuleConfiguration.$clinit();
    let $instance = new ProfileModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_profile_client_ProfileModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfileModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_ProfileModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_profile_client_ProfileModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(ProfilePresenter).m_getCanonicalName__(), Class.$get(ProfilePresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_profile_client_ProfileModuleConfiguration__java_lang_String(this, Class.$get(ProfilePresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(ProfilePresenterCommand).m_getCanonicalName__(), Class.$get(ProfilePresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(LayoutExtensionPoint), ProfilePresenterContributionToLayoutExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfileModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfileModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfileModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LayoutExtensionPoint = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
    $1 = goog.module.get('org.dominokit.domino.profile.client.ProfileModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.profile.client.ProfileModuleConfiguration.$2$impl');
    ProfilePresenterContributionToLayoutExtensionPoint = goog.module.get('org.dominokit.domino.profile.client.contributions.ProfilePresenterContributionToLayoutExtensionPoint$impl');
    ProfilePresenter = goog.module.get('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');
    ProfilePresenterCommand = goog.module.get('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProfileModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.profile.client.ProfileModuleConfiguration'));


ModuleConfiguration.$markImplementor(ProfileModuleConfiguration);


exports = ProfileModuleConfiguration; 
//# sourceMappingURL=ProfileModuleConfiguration.js.map