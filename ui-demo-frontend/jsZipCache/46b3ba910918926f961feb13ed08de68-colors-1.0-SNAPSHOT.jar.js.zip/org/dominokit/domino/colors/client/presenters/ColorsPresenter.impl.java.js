/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.presenters.ColorsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.colors.client.presenters.ColorsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.colors.client.presenters.ColorsPresenter.$1$impl');
let ColorsView = goog.forwardDeclare('org.dominokit.domino.colors.client.views.ColorsView$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<ColorsView>}
  */
class ColorsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ColorsPresenter()'.
   * @return {!ColorsPresenter}
   * @public
   */
  static $create__() {
    ColorsPresenter.$clinit();
    let $instance = new ColorsPresenter();
    $instance.$ctor__org_dominokit_domino_colors_client_presenters_ColorsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColorsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_colors_client_presenters_ColorsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_colors_client_presenters_ColorsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_colors_client_presenters_ColorsPresenter_() {
    return (ColorsPresenter.$clinit(), ColorsPresenter.$f_LOGGER__org_dominokit_domino_colors_client_presenters_ColorsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_colors_client_presenters_ColorsPresenter_(value) {
    (ColorsPresenter.$clinit(), ColorsPresenter.$f_LOGGER__org_dominokit_domino_colors_client_presenters_ColorsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColorsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColorsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ColorsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.colors.client.presenters.ColorsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    ColorsPresenter.$f_LOGGER__org_dominokit_domino_colors_client_presenters_ColorsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ColorsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ColorsPresenter, $Util.$makeClassName('org.dominokit.domino.colors.client.presenters.ColorsPresenter'));


/** @private {Logger} */
ColorsPresenter.$f_LOGGER__org_dominokit_domino_colors_client_presenters_ColorsPresenter_;




exports = ColorsPresenter; 
//# sourceMappingURL=ColorsPresenter.js.map