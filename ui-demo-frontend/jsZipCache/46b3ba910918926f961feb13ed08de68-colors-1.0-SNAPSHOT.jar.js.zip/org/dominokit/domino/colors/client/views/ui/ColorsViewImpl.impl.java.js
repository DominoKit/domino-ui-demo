/**
 * @fileoverview transpiled from org.dominokit.domino.colors.client.views.ui.ColorsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.colors.client.views.ui.ColorsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ColorsView = goog.require('org.dominokit.domino.colors.client.views.ColorsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ColorsView}
  */
class ColorsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ColorsViewImpl()'.
   * @return {!ColorsViewImpl}
   * @public
   */
  static $create__() {
    ColorsViewImpl.$clinit();
    let $instance = new ColorsViewImpl();
    $instance.$ctor__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColorsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("COLORS").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("MATERIAL DESIGN COLORS", "Taken by Google's Material Design Color page which link is ").m_appendDescriptionContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://material.google.com/style/color.html#color-color-palette"), HtmlContentBuilder)).m_textContent__java_lang_String("material.google.com/style/color.html#color-color-palette"), HtmlContentBuilder)).m_title__java_lang_String("Google's Material Design Color"), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_RED__org_dominokit_domino_ui_style_Color, Color.f_RED__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_PINK__org_dominokit_domino_ui_style_Color, Color.f_PINK__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_PURPLE__org_dominokit_domino_ui_style_Color, Color.f_PURPLE__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color, Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_INDIGO__org_dominokit_domino_ui_style_Color, Color.f_INDIGO__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_BLUE__org_dominokit_domino_ui_style_Color, Color.f_BLUE__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color, Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_CYAN__org_dominokit_domino_ui_style_Color, Color.f_CYAN__org_dominokit_domino_ui_style_Color))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_TEAL__org_dominokit_domino_ui_style_Color, Color.f_TEAL__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_GREEN__org_dominokit_domino_ui_style_Color, Color.f_GREEN__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color, Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_LIME__org_dominokit_domino_ui_style_Color, Color.f_LIME__org_dominokit_domino_ui_style_Color))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_YELLOW__org_dominokit_domino_ui_style_Color, Color.f_YELLOW__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_AMBER__org_dominokit_domino_ui_style_Color, Color.f_AMBER__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_ORANGE__org_dominokit_domino_ui_style_Color, Color.f_ORANGE__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_DEEP_ORANGE__org_dominokit_domino_ui_style_Color, Color.f_DEEP_ORANGE__org_dominokit_domino_ui_style_Color))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_BROWN__org_dominokit_domino_ui_style_Color, Color.f_BROWN__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_GREY__org_dominokit_domino_ui_style_Color, Color.f_GREY__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color, Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(Color.f_BLACK__org_dominokit_domino_ui_style_Color, Color.f_BLACK__org_dominokit_domino_ui_style_Color))).m_asElement__()).m_asElement__());
  }
  
  /**
   * @param {Color} color
   * @param {Color} background
   * @return {HTMLElement}
   * @public
   */
  m_makeColorBox__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_colors_client_views_ui_ColorsViewImpl(color, background) {
    return /**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-color-box", background.m_getBackground__()], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["color-name"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(color.m_getName__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["color-code"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(color.m_getHex__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["color-class-name"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(background.m_getBackground__()), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["color-class-name"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(color.m_getStyle__()), IsElement))), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl() {
    this.f_element__org_dominokit_domino_colors_client_views_ui_ColorsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColorsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColorsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ColorsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ColorsViewImpl, $Util.$makeClassName('org.dominokit.domino.colors.client.views.ui.ColorsViewImpl'));


ColorsView.$markImplementor(ColorsViewImpl);


exports = ColorsViewImpl; 
//# sourceMappingURL=ColorsViewImpl.js.map