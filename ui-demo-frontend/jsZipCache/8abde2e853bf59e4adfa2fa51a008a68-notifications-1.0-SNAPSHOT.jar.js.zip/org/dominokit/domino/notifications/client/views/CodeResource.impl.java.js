/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.notifications.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_notifications_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_notifications_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_notificationsPosition__() {
    CodeResource.$clinit();
    return "//Show notifications on pre-defined positions\n" + "//Notification.TOP_LEFT\n" + "//Notification.TOP_CENTER\n" + "//Notification.TOP_RIGHT\n" + "//Notification.BOTTOM_LEFT\n" + "//Notification.BOTTOM_CENTER\n" + "//Notification.BOTTOM_RIGHT\n" + "\n" + "Notification.create(\"You received a message\")\n" + "        .setPosition(Notification.BOTTOM_RIGHT)\n" + "        .show());\"";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_notificationsTypes__() {
    CodeResource.$clinit();
    return "Button danger = Button.createDanger(\"DANGER\").large();\n" + "danger.getClickableElement().addEventListener(\"click\", e ->\n" + "        Notification.createDanger(\"You received a message\")\n" + "                .setPosition(Notification.TOP_LEFT)\n" + "                .show());\n" + "\n" + "Button success = Button.createSuccess(\"SUCCESS\").large();\n" + "success.getClickableElement().addEventListener(\"click\", e ->\n" + "        Notification.createSuccess(\"You received a message\")\n" + "                .setPosition(Notification.TOP_LEFT)\n" + "                .show());\n" + "\n" + "Button warning = Button.createWarning(\"WARNING\").large();\n" + "warning.getClickableElement().addEventListener(\"click\", e ->\n" + "        Notification.createWarning(\"You received a message\")\n" + "                .setPosition(Notification.TOP_LEFT)\n" + "                .show());\n" + "\n" + "\n" + "Button info = Button.createInfo(\"INFO\").large();\n" + "info.getClickableElement().addEventListener(\"click\", e ->\n" + "        Notification.createInfo(\"You received a message\")\n" + "                .setPosition(Notification.TOP_LEFT)\n" + "                .show());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_withMaterialColors__() {
    CodeResource.$clinit();
    return "//Change the color of the notification by setting the background\n" + "Notification.create(\"You received a message\")\n" + "        .setBackground(Background.TEAL)\n" + "        .setPosition(Notification.TOP_LEFT)\n" + "        .show();";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_withAnimation__() {
    CodeResource.$clinit();
    return "//Use the IN transition, OUT transition for transaction appear/disappear animation\n" + "//use duration to set the wait time before the notification automatically disappear\n" + "\n" + "Notification.create(\"You received a message\")\n" + "        .duration(5000)\n" + "        .inTransition(Transition.LIGHT_SPEED_IN)\n" + "        .outTransition(Transition.LIGHT_SPEED_OUT)\n" + "        .setPosition(Notification.TOP_CENTER)\n" + "        .show();";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.notifications.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map