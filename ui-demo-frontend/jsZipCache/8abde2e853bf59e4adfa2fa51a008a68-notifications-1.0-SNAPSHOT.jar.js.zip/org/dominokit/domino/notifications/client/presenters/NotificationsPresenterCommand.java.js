/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _NotificationsPresenter = goog.require('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter');


// Re-exports the implementation.
var NotificationsPresenterCommand = goog.require('org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand$impl');
exports = NotificationsPresenterCommand;
 