/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.presenters.NotificationsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter.$1$impl');
let NotificationsView = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.NotificationsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<NotificationsView>}
  */
class NotificationsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'NotificationsPresenter()'.
   * @return {!NotificationsPresenter}
   * @public
   */
  static $create__() {
    NotificationsPresenter.$clinit();
    let $instance = new NotificationsPresenter();
    $instance.$ctor__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NotificationsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentCaseModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter_() {
    return (NotificationsPresenter.$clinit(), NotificationsPresenter.$f_LOGGER__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter_(value) {
    (NotificationsPresenter.$clinit(), NotificationsPresenter.$f_LOGGER__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NotificationsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NotificationsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NotificationsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    NotificationsPresenter.$f_LOGGER__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(NotificationsPresenter));
  }
  
  
};

$Util.$setClassMetadata(NotificationsPresenter, $Util.$makeClassName('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter'));


/** @private {Logger} */
NotificationsPresenter.$f_LOGGER__org_dominokit_domino_notifications_client_presenters_NotificationsPresenter_;




exports = NotificationsPresenter; 
//# sourceMappingURL=NotificationsPresenter.js.map