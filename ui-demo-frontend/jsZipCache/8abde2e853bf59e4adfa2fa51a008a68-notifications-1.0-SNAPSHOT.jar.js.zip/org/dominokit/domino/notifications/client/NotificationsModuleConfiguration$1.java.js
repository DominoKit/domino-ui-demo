/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.NotificationsModuleConfiguration$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.notifications.client.NotificationsModuleConfiguration.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _NotificationsModuleConfiguration = goog.require('org.dominokit.domino.notifications.client.NotificationsModuleConfiguration');
const _NotificationsPresenter = goog.require('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.notifications.client.NotificationsModuleConfiguration.$1$impl');
exports = $1;
 