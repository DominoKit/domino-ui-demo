package org.dominokit.domino.notifications.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.notifications.client.contributions.NotificationsPresenterContributionToComponentsExtensionPoint;
import org.dominokit.domino.notifications.client.presenters.NotificationsPresenter;
import org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand;
import org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class NotificationsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(NotificationsPresenter.class.getCanonicalName(), NotificationsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new NotificationsPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(NotificationsPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new NotificationsViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(NotificationsPresenterCommand.class.getCanonicalName(), NotificationsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentsExtensionPoint.class, new NotificationsPresenterContributionToComponentsExtensionPoint());
  }
}
