/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _Shape = goog.require('com.fasterxml.jackson.annotation.JsonFormat.Shape');
const _HashSet = goog.require('java.util.HashSet');
const _Set = goog.require('java.util.Set');
const _$Equality = goog.require('nativebootstrap.Equality');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _TypeDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo');


// Re-exports the implementation.
var GwtJacksonJsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters$impl');
exports = GwtJacksonJsonDeserializerParameters;
 