/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DateFormat = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.DateFormat$impl');
let DoubleArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader$impl');
let IntegerArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader$impl');
let IntegerStackFactory = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory$impl');
let MapLikeFactory = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory$impl');
let ShortArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader$impl');
let StringArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.StringArrayReader$impl');
let ValueStringifier = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.ValueStringifier$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializerParameters$impl');


/**
 * @interface
 */
class JacksonContext {
  /**
   * @abstract
   * @return {DateFormat}
   * @public
   */
  m_dateFormat__() {
  }
  
  /**
   * @abstract
   * @return {IntegerStackFactory}
   * @public
   */
  m_integerStackFactory__() {
  }
  
  /**
   * @abstract
   * @return {MapLikeFactory}
   * @public
   */
  m_mapLikeFactory__() {
  }
  
  /**
   * @abstract
   * @return {ValueStringifier}
   * @public
   */
  m_stringifier__() {
  }
  
  /**
   * @abstract
   * @return {StringArrayReader}
   * @public
   */
  m_stringArrayReader__() {
  }
  
  /**
   * @abstract
   * @return {ShortArrayReader}
   * @public
   */
  m_shortArrayReader__() {
  }
  
  /**
   * @abstract
   * @return {IntegerArrayReader}
   * @public
   */
  m_integerArrayReader__() {
  }
  
  /**
   * @abstract
   * @return {DoubleArrayReader}
   * @public
   */
  m_doubleArrayReader__() {
  }
  
  /**
   * @abstract
   * @return {JsonSerializerParameters}
   * @public
   */
  m_defaultSerializerParameters__() {
  }
  
  /**
   * @abstract
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_defaultDeserializerParameters__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JacksonContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JacksonContext, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext'));


JacksonContext.$markImplementor(/** @type {Function} */ (JacksonContext));


exports = JacksonContext; 
//# sourceMappingURL=JacksonContext.js.map