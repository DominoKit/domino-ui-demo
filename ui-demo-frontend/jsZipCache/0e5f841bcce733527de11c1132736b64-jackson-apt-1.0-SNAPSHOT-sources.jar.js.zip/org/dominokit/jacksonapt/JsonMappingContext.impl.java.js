/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonMappingContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonMappingContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Logger = goog.forwardDeclare('java.util.logging.Logger$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JsonMappingContext.$LambdaAdaptor$impl');


/**
 * @interface
 */
class JsonMappingContext {
  /**
   * @abstract
   * @return {Logger}
   * @public
   */
  m_getLogger__() {
  }
  
  /**
   * @param {?function():Logger} fn
   * @return {JsonMappingContext}
   * @public
   */
  static $adapt(fn) {
    JsonMappingContext.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonMappingContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JsonMappingContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonMappingContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonMappingContext.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JsonMappingContext.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonMappingContext, $Util.$makeClassName('org.dominokit.jacksonapt.JsonMappingContext'));


JsonMappingContext.$markImplementor(/** @type {Function} */ (JsonMappingContext));


exports = JsonMappingContext; 
//# sourceMappingURL=JsonMappingContext.js.map