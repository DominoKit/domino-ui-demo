/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.AbstractObjectWriter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.AbstractObjectWriter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper$impl');
const ObjectWriter = goog.require('org.dominokit.jacksonapt.ObjectWriter$impl');

let UnsupportedOperationException = goog.forwardDeclare('java.lang.UnsupportedOperationException$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_T
 * @extends {AbstractObjectMapper<C_T>}
 * @implements {ObjectWriter<C_T>}
  */
class AbstractObjectWriter extends AbstractObjectMapper {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'AbstractObjectWriter(String)'.
   * @param {?string} rootName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_AbstractObjectWriter__java_lang_String(rootName) {
    this.$ctor__org_dominokit_jacksonapt_AbstractObjectMapper__java_lang_String(rootName);
  }
  
  /**
   * @override
   * @return {JsonDeserializer<C_T>}
   * @public
   */
  m_newDeserializer__() {
    throw $Exceptions.toJs(UnsupportedOperationException.$create__java_lang_String("ObjectWriter doesn't support deserialization"));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractObjectWriter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractObjectWriter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractObjectWriter.$clinit = function() {};
    UnsupportedOperationException = goog.module.get('java.lang.UnsupportedOperationException$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    AbstractObjectMapper.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractObjectWriter, $Util.$makeClassName('org.dominokit.jacksonapt.AbstractObjectWriter'));


ObjectWriter.$markImplementor(AbstractObjectWriter);


exports = AbstractObjectWriter; 
//# sourceMappingURL=AbstractObjectWriter.js.map