/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContextProvider.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContextProvider');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Objects = goog.require('java.util.Objects');
const _JacksonContext = goog.require('org.dominokit.jacksonapt.JacksonContext');
const _ServerJacksonContext = goog.require('org.dominokit.jacksonapt.ServerJacksonContext');


// Re-exports the implementation.
var JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider$impl');
exports = JacksonContextProvider;
 