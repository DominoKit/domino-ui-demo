/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.ObjectWriter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.ObjectWriter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');


// Re-exports the implementation.
var ObjectWriter = goog.require('org.dominokit.jacksonapt.ObjectWriter$impl');
exports = ObjectWriter;
 