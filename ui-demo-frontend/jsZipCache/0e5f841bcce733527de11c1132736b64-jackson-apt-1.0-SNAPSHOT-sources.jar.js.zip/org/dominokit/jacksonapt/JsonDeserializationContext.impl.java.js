/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonDeserializationContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonMappingContext = goog.require('org.dominokit.jacksonapt.JsonMappingContext$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let RuntimeException = goog.forwardDeclare('java.lang.RuntimeException$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonDeserializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 * @extends {JsonMappingContext}
 */
class JsonDeserializationContext {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isFailOnUnknownProperties__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isUnwrapRootValue__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isAcceptSingleValueAsArray__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isUseSafeEval__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isReadUnknownEnumValuesAsNull__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isUseBrowserTimezone__() {
  }
  
  /**
   * @abstract
   * @param {?string} input
   * @return {JsonReader}
   * @public
   */
  m_newJsonReader__java_lang_String(input) {
  }
  
  /**
   * @abstract
   * @param {?string} message
   * @return {JsonDeserializationException}
   * @public
   */
  m_traceError__java_lang_String(message) {
  }
  
  /**
   * @abstract
   * @param {?string} message
   * @param {JsonReader} reader
   * @return {JsonDeserializationException}
   * @public
   */
  m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader(message, reader) {
  }
  
  /**
   * @abstract
   * @param {RuntimeException} cause
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_RuntimeException(cause) {
  }
  
  /**
   * @abstract
   * @param {RuntimeException} cause
   * @param {JsonReader} reader
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_RuntimeException__org_dominokit_jacksonapt_stream_JsonReader(cause, reader) {
  }
  
  /**
   * @abstract
   * @param {IdKey} id
   * @param {*} instance
   * @return {void}
   * @public
   */
  m_addObjectId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Object(id, instance) {
  }
  
  /**
   * @abstract
   * @param {IdKey} id
   * @return {*}
   * @public
   */
  m_getObjectWithId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey(id) {
  }
  
  /**
   * @abstract
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_defaultParameters__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    JsonMappingContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonDeserializationContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JsonDeserializationContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonDeserializationContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonDeserializationContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonDeserializationContext, $Util.$makeClassName('org.dominokit.jacksonapt.JsonDeserializationContext'));


JsonDeserializationContext.$markImplementor(/** @type {Function} */ (JsonDeserializationContext));


exports = JsonDeserializationContext; 
//# sourceMappingURL=JsonDeserializationContext.js.map