/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');

let Shape = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');


/**
 * @implements {JsonDeserializerParameters}
  */
class GwtJacksonJsonDeserializerParameters extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_pattern__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
    /** @public {Shape} */
    this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
    /** @public {?string} */
    this.f_locale__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
    /** @public {Set<?string>} */
    this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
    /** @public {boolean} */
    this.f_ignoreUnknown__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = false;
    /** @public {IdentityDeserializationInfo} */
    this.f_identityInfo__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
    /** @public {TypeDeserializationInfo} */
    this.f_typeInfo__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * Factory method corresponding to constructor 'GwtJacksonJsonDeserializerParameters()'.
   * @return {!GwtJacksonJsonDeserializerParameters}
   * @public
   */
  static $create__() {
    GwtJacksonJsonDeserializerParameters.$clinit();
    let $instance = new GwtJacksonJsonDeserializerParameters();
    $instance.$ctor__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GwtJacksonJsonDeserializerParameters()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getPattern__() {
    return this.f_pattern__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {?string} pattern
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setPattern__java_lang_String(pattern) {
    this.f_pattern__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = pattern;
    return this;
  }
  
  /**
   * @override
   * @return {Shape}
   * @public
   */
  m_getShape__() {
    return this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {Shape} shape
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setShape__com_fasterxml_jackson_annotation_JsonFormat_Shape(shape) {
    this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = shape;
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getLocale__() {
    return this.f_locale__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {?string} locale
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setLocale__java_lang_String(locale) {
    this.f_locale__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = locale;
    return this;
  }
  
  /**
   * @override
   * @return {Set<?string>}
   * @public
   */
  m_getIgnoredProperties__() {
    return this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {?string} ignoredProperty
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_addIgnoredProperty__java_lang_String(ignoredProperty) {
    if ($Equality.$same(null, this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_)) {
      this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = /**@type {!HashSet<?string>} */ (HashSet.$create__());
    }
    this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_.add(ignoredProperty);
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isIgnoreUnknown__() {
    return this.f_ignoreUnknown__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {boolean} ignoreUnknown
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setIgnoreUnknown__boolean(ignoreUnknown) {
    this.f_ignoreUnknown__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = ignoreUnknown;
    return this;
  }
  
  /**
   * @override
   * @return {IdentityDeserializationInfo}
   * @public
   */
  m_getIdentityInfo__() {
    return this.f_identityInfo__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {IdentityDeserializationInfo} identityInfo
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setIdentityInfo__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo(identityInfo) {
    this.f_identityInfo__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = identityInfo;
    return this;
  }
  
  /**
   * @override
   * @return {TypeDeserializationInfo}
   * @public
   */
  m_getTypeInfo__() {
    return this.f_typeInfo__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_;
  }
  
  /**
   * @override
   * @param {TypeDeserializationInfo} typeInfo
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setTypeInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo(typeInfo) {
    this.f_typeInfo__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = typeInfo;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters() {
    this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = Shape.f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape;
    this.f_ignoreUnknown__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters_ = false;
  }
  
  /**
   * @return {JsonDeserializerParameters}
   * @public
   */
  static get f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters() {
    return (GwtJacksonJsonDeserializerParameters.$clinit(), GwtJacksonJsonDeserializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters);
  }
  
  /**
   * @param {JsonDeserializerParameters} value
   * @return {void}
   * @public
   */
  static set f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters(value) {
    (GwtJacksonJsonDeserializerParameters.$clinit(), GwtJacksonJsonDeserializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GwtJacksonJsonDeserializerParameters;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GwtJacksonJsonDeserializerParameters);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GwtJacksonJsonDeserializerParameters.$clinit = function() {};
    Shape = goog.module.get('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    j_l_Object.$clinit();
    GwtJacksonJsonDeserializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters = GwtJacksonJsonDeserializerParameters.$create__();
  }
  
  
};

$Util.$setClassMetadata(GwtJacksonJsonDeserializerParameters, $Util.$makeClassName('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters'));


/** @private {JsonDeserializerParameters} */
GwtJacksonJsonDeserializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters;


JsonDeserializerParameters.$markImplementor(GwtJacksonJsonDeserializerParameters);


exports = GwtJacksonJsonDeserializerParameters; 
//# sourceMappingURL=GwtJacksonJsonDeserializerParameters.js.map