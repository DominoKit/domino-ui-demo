/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.Deserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.Deserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer');


// Re-exports the implementation.
var Deserializer = goog.require('org.dominokit.jacksonapt.Deserializer$impl');
exports = Deserializer;
 