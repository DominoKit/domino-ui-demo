/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonSerializationContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonSerializationContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonMappingContext = goog.require('org.dominokit.jacksonapt.JsonMappingContext$impl');

let ObjectIdGenerator = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator$impl');
let RuntimeException = goog.forwardDeclare('java.lang.RuntimeException$impl');
let JsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializerParameters$impl');
let JsonSerializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonSerializationException$impl');
let ObjectIdSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.ObjectIdSerializer$impl');
let JsonWriter = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonWriter$impl');


/**
 * @interface
 * @extends {JsonMappingContext}
 */
class JsonSerializationContext {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isSerializeNulls__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWriteDatesAsTimestamps__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWriteDateKeysAsTimestamps__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWrapRootValue__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWriteCharArraysAsJsonArrays__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWriteNullMapValues__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWriteEmptyJsonArrays__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isOrderMapEntriesByKeys__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isWriteSingleElemArraysUnwrapped__() {
  }
  
  /**
   * @abstract
   * @return {JsonWriter}
   * @public
   */
  m_newJsonWriter__() {
  }
  
  /**
   * @abstract
   * @param {*} value
   * @param {?string} message
   * @return {JsonSerializationException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_String(value, message) {
  }
  
  /**
   * @abstract
   * @param {*} value
   * @param {?string} message
   * @param {JsonWriter} writer
   * @return {JsonSerializationException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_String__org_dominokit_jacksonapt_stream_JsonWriter(value, message, writer) {
  }
  
  /**
   * @abstract
   * @param {*} value
   * @param {RuntimeException} cause
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_RuntimeException(value, cause) {
  }
  
  /**
   * @abstract
   * @param {*} value
   * @param {RuntimeException} cause
   * @param {JsonWriter} writer
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_RuntimeException__org_dominokit_jacksonapt_stream_JsonWriter(value, cause, writer) {
  }
  
  /**
   * @abstract
   * @param {*} object
   * @param {ObjectIdSerializer<?>} id
   * @return {void}
   * @public
   */
  m_addObjectId__java_lang_Object__org_dominokit_jacksonapt_ser_bean_ObjectIdSerializer(object, id) {
  }
  
  /**
   * @abstract
   * @param {*} object
   * @return {ObjectIdSerializer<?>}
   * @public
   */
  m_getObjectId__java_lang_Object(object) {
  }
  
  /**
   * @abstract
   * @param {ObjectIdGenerator<?>} generator
   * @return {void}
   * @public
   */
  m_addGenerator__com_fasterxml_jackson_annotation_ObjectIdGenerator(generator) {
  }
  
  /**
   * @abstract
   * @template M_T
   * @param {ObjectIdGenerator<M_T>} gen
   * @return {ObjectIdGenerator<M_T>}
   * @public
   */
  m_findObjectIdGenerator__com_fasterxml_jackson_annotation_ObjectIdGenerator(gen) {
  }
  
  /**
   * @abstract
   * @return {JsonSerializerParameters}
   * @public
   */
  m_defaultParameters__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    JsonMappingContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonSerializationContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JsonSerializationContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonSerializationContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonSerializationContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonSerializationContext, $Util.$makeClassName('org.dominokit.jacksonapt.JsonSerializationContext'));


JsonSerializationContext.$markImplementor(/** @type {Function} */ (JsonSerializationContext));


exports = JsonSerializationContext; 
//# sourceMappingURL=JsonSerializationContext.js.map