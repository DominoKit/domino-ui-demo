/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.Deserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.Deserializer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let KeyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');


/**
 * @abstract
 * @template C_T
  */
class Deserializer extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {KeyDeserializer<C_T>} */
    this.f_key__org_dominokit_jacksonapt_Deserializer_;
    /** @public {JsonDeserializer<C_T>} */
    this.f_json__org_dominokit_jacksonapt_Deserializer_;
  }
  
  /**
   * Initialization from constructor 'Deserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_Deserializer__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {KeyDeserializer<C_T>}
   * @public
   */
  m_key__() {
    if ($Equality.$same(null, this.f_key__org_dominokit_jacksonapt_Deserializer_)) {
      this.f_key__org_dominokit_jacksonapt_Deserializer_ = this.m_createKeyDeserializer__();
    }
    return this.f_key__org_dominokit_jacksonapt_Deserializer_;
  }
  
  /**
   * @abstract
   * @return {KeyDeserializer<C_T>}
   * @public
   */
  m_createKeyDeserializer__() {
  }
  
  /**
   * @return {JsonDeserializer<C_T>}
   * @public
   */
  m_json__() {
    if ($Equality.$same(null, this.f_json__org_dominokit_jacksonapt_Deserializer_)) {
      this.f_json__org_dominokit_jacksonapt_Deserializer_ = this.m_createJsonDeserializer__();
    }
    return this.f_json__org_dominokit_jacksonapt_Deserializer_;
  }
  
  /**
   * @abstract
   * @return {JsonDeserializer<C_T>}
   * @public
   */
  m_createJsonDeserializer__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Deserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Deserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Deserializer.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Deserializer, $Util.$makeClassName('org.dominokit.jacksonapt.Deserializer'));




exports = Deserializer; 
//# sourceMappingURL=Deserializer.js.map