/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.AbstractObjectReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.AbstractObjectReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper');
const _ObjectReader = goog.require('org.dominokit.jacksonapt.ObjectReader');
const _UnsupportedOperationException = goog.require('java.lang.UnsupportedOperationException');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var AbstractObjectReader = goog.require('org.dominokit.jacksonapt.AbstractObjectReader$impl');
exports = AbstractObjectReader;
 