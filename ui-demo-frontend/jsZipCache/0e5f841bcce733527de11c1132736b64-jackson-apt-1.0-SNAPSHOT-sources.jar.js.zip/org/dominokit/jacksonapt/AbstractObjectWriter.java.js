/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.AbstractObjectWriter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.AbstractObjectWriter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper');
const _ObjectWriter = goog.require('org.dominokit.jacksonapt.ObjectWriter');
const _UnsupportedOperationException = goog.require('java.lang.UnsupportedOperationException');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var AbstractObjectWriter = goog.require('org.dominokit.jacksonapt.AbstractObjectWriter$impl');
exports = AbstractObjectWriter;
 