/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$ShortJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ShortJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let Short = goog.forwardDeclare('java.lang.Short$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


/**
 * @extends {BaseNumberJsonDeserializer<Short>}
  */
class ShortJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {ShortJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    ShortJsonDeserializer.$clinit();
    return ShortJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'ShortJsonDeserializer()'.
   * @return {!ShortJsonDeserializer}
   * @public
   */
  static $create__() {
    ShortJsonDeserializer.$clinit();
    let $instance = new ShortJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ShortJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Short}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NUMBER__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return Short.m_valueOf__short($Primitives.$narrowIntToShort(reader.m_nextInt__()));
    } else {
      return Short.m_valueOf__short(Short.m_parseShort__java_lang_String(reader.m_nextString__()));
    }
  }
  
  /**
   * @return {ShortJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_() {
    return (ShortJsonDeserializer.$clinit(), ShortJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_);
  }
  
  /**
   * @param {ShortJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_(value) {
    (ShortJsonDeserializer.$clinit(), ShortJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ShortJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ShortJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ShortJsonDeserializer.$clinit = function() {};
    Short = goog.module.get('java.lang.Short$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    BaseNumberJsonDeserializer.$clinit();
    ShortJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_ = ShortJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(ShortJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$ShortJsonDeserializer'));


/** @private {ShortJsonDeserializer} */
ShortJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ShortJsonDeserializer_;




exports = ShortJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$ShortJsonDeserializer.js.map