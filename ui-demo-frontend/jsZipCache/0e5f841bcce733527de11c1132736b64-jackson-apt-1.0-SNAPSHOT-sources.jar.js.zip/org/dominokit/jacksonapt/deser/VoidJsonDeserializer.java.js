/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.VoidJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.VoidJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var VoidJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.VoidJsonDeserializer$impl');
exports = VoidJsonDeserializer;
 