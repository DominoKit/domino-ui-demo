/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlTimestampJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.SqlTimestampJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$impl');

let Timestamp = goog.forwardDeclare('java.sql.Timestamp$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');


/**
 * @extends {BaseDateJsonDeserializer<Timestamp>}
  */
class SqlTimestampJsonDeserializer extends BaseDateJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {SqlTimestampJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    SqlTimestampJsonDeserializer.$clinit();
    return SqlTimestampJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'SqlTimestampJsonDeserializer()'.
   * @return {!SqlTimestampJsonDeserializer}
   * @public
   */
  static $create__() {
    SqlTimestampJsonDeserializer.$clinit();
    let $instance = new SqlTimestampJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SqlTimestampJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @param {JsonDeserializerParameters} params
   * @return {Timestamp}
   * @public
   */
  m_deserializeNumber__long__org_dominokit_jacksonapt_JsonDeserializerParameters(millis, params) {
    return Timestamp.$create__long(millis);
  }
  
  /**
   * @override
   * @param {?string} date
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Timestamp}
   * @public
   */
  m_deserializeString__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(date, ctx, params) {
    return Timestamp.$create__long(JacksonContextProvider.m_get__().m_dateFormat__().m_parse__boolean__java_lang_String__java_lang_Boolean__java_lang_String(ctx.m_isUseBrowserTimezone__(), params.m_getPattern__(), null, date).m_getTime__());
  }
  
  /**
   * @return {SqlTimestampJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_() {
    return (SqlTimestampJsonDeserializer.$clinit(), SqlTimestampJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_);
  }
  
  /**
   * @param {SqlTimestampJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_(value) {
    (SqlTimestampJsonDeserializer.$clinit(), SqlTimestampJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SqlTimestampJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SqlTimestampJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SqlTimestampJsonDeserializer.$clinit = function() {};
    Timestamp = goog.module.get('java.sql.Timestamp$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    BaseDateJsonDeserializer.$clinit();
    SqlTimestampJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_ = SqlTimestampJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(SqlTimestampJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlTimestampJsonDeserializer'));


/** @private {SqlTimestampJsonDeserializer} */
SqlTimestampJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimestampJsonDeserializer_;




exports = SqlTimestampJsonDeserializer; 
//# sourceMappingURL=BaseDateJsonDeserializer$SqlTimestampJsonDeserializer.js.map