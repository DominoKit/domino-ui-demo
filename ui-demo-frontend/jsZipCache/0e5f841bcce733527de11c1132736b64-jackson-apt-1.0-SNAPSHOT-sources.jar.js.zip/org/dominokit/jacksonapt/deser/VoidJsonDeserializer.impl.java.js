/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.VoidJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.VoidJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {JsonDeserializer<?void>}
  */
class VoidJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {VoidJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    VoidJsonDeserializer.$clinit();
    return VoidJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'VoidJsonDeserializer()'.
   * @return {!VoidJsonDeserializer}
   * @public
   */
  static $create__() {
    VoidJsonDeserializer.$clinit();
    let $instance = new VoidJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_VoidJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'VoidJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_VoidJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {?void}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    reader.m_skipValue__();
    return null;
  }
  
  /**
   * @return {VoidJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_() {
    return (VoidJsonDeserializer.$clinit(), VoidJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_);
  }
  
  /**
   * @param {VoidJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_(value) {
    (VoidJsonDeserializer.$clinit(), VoidJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof VoidJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, VoidJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    VoidJsonDeserializer.$clinit = function() {};
    JsonDeserializer.$clinit();
    VoidJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_ = VoidJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(VoidJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.VoidJsonDeserializer'));


/** @private {VoidJsonDeserializer} */
VoidJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_VoidJsonDeserializer_;




exports = VoidJsonDeserializer; 
//# sourceMappingURL=VoidJsonDeserializer.js.map