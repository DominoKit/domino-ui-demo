/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlDateJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.SqlDateJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$impl');

let Date = goog.forwardDeclare('java.sql.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');


/**
 * @extends {BaseDateJsonDeserializer<Date>}
  */
class SqlDateJsonDeserializer extends BaseDateJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {SqlDateJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    SqlDateJsonDeserializer.$clinit();
    return SqlDateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'SqlDateJsonDeserializer()'.
   * @return {!SqlDateJsonDeserializer}
   * @public
   */
  static $create__() {
    SqlDateJsonDeserializer.$clinit();
    let $instance = new SqlDateJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SqlDateJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @param {JsonDeserializerParameters} params
   * @return {Date}
   * @public
   */
  m_deserializeNumber__long__org_dominokit_jacksonapt_JsonDeserializerParameters(millis, params) {
    return Date.$create__long(millis);
  }
  
  /**
   * @override
   * @param {?string} date
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Date}
   * @public
   */
  m_deserializeString__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(date, ctx, params) {
    return Date.$create__long(JacksonContextProvider.m_get__().m_dateFormat__().m_parse__boolean__java_lang_String__java_lang_Boolean__java_lang_String(ctx.m_isUseBrowserTimezone__(), SqlDateJsonDeserializer.f_SQL_DATE_FORMAT__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_, false, date).m_getTime__());
  }
  
  /**
   * @return {SqlDateJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_() {
    return (SqlDateJsonDeserializer.$clinit(), SqlDateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_);
  }
  
  /**
   * @param {SqlDateJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_(value) {
    (SqlDateJsonDeserializer.$clinit(), SqlDateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SqlDateJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SqlDateJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SqlDateJsonDeserializer.$clinit = function() {};
    Date = goog.module.get('java.sql.Date$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    BaseDateJsonDeserializer.$clinit();
    SqlDateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_ = SqlDateJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(SqlDateJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlDateJsonDeserializer'));


/** @private {SqlDateJsonDeserializer} */
SqlDateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_;


/** @public {?string} @const */
SqlDateJsonDeserializer.f_SQL_DATE_FORMAT__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlDateJsonDeserializer_ = "yyyy-MM-dd";




exports = SqlDateJsonDeserializer; 
//# sourceMappingURL=BaseDateJsonDeserializer$SqlDateJsonDeserializer.js.map