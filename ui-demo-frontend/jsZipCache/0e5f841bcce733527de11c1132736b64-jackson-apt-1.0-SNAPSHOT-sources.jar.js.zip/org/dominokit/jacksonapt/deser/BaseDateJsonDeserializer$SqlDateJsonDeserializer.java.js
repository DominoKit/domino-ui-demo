/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlDateJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.SqlDateJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer');
const _Date = goog.require('java.sql.Date');
const _$Long = goog.require('nativebootstrap.Long');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');


// Re-exports the implementation.
var SqlDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.SqlDateJsonDeserializer$impl');
exports = SqlDateJsonDeserializer;
 