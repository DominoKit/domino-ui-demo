/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BooleanJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @extends {JsonDeserializer<?boolean>}
  */
class BooleanJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {BooleanJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    BooleanJsonDeserializer.$clinit();
    return BooleanJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'BooleanJsonDeserializer()'.
   * @return {!BooleanJsonDeserializer}
   * @public
   */
  static $create__() {
    BooleanJsonDeserializer.$clinit();
    let $instance = new BooleanJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BooleanJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {?boolean}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let token = reader.m_peek__();
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_BOOLEAN__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      return reader.m_nextBoolean__();
    } else if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_STRING__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      return Boolean.m_valueOf__java_lang_String(reader.m_nextString__());
    } else if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NUMBER__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      return reader.m_nextInt__() == 1;
    } else {
      return null;
    }
  }
  
  /**
   * @return {BooleanJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_() {
    return (BooleanJsonDeserializer.$clinit(), BooleanJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_);
  }
  
  /**
   * @param {BooleanJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_(value) {
    (BooleanJsonDeserializer.$clinit(), BooleanJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BooleanJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BooleanJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BooleanJsonDeserializer.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    JsonDeserializer.$clinit();
    BooleanJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_ = BooleanJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(BooleanJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer'));


/** @private {BooleanJsonDeserializer} */
BooleanJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BooleanJsonDeserializer_;




exports = BooleanJsonDeserializer; 
//# sourceMappingURL=BooleanJsonDeserializer.js.map