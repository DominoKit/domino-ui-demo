/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$FloatJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.FloatJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let Float = goog.forwardDeclare('java.lang.Float$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {BaseNumberJsonDeserializer<Float>}
  */
class FloatJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {FloatJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    FloatJsonDeserializer.$clinit();
    return FloatJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'FloatJsonDeserializer()'.
   * @return {!FloatJsonDeserializer}
   * @public
   */
  static $create__() {
    FloatJsonDeserializer.$clinit();
    let $instance = new FloatJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FloatJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Float}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return Float.m_valueOf__float(Float.m_parseFloat__java_lang_String(reader.m_nextString__()));
  }
  
  /**
   * @return {FloatJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_() {
    return (FloatJsonDeserializer.$clinit(), FloatJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_);
  }
  
  /**
   * @param {FloatJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_(value) {
    (FloatJsonDeserializer.$clinit(), FloatJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FloatJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FloatJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FloatJsonDeserializer.$clinit = function() {};
    Float = goog.module.get('java.lang.Float$impl');
    BaseNumberJsonDeserializer.$clinit();
    FloatJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_ = FloatJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(FloatJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$FloatJsonDeserializer'));


/** @private {FloatJsonDeserializer} */
FloatJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_FloatJsonDeserializer_;




exports = FloatJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$FloatJsonDeserializer.js.map