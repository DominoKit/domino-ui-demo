/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.EnumJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Enum = goog.forwardDeclare('java.lang.Enum$impl');
let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_E
 * @extends {JsonDeserializer<C_E>}
  */
class EnumJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Class<C_E>} */
    this.f_enumClass__org_dominokit_jacksonapt_deser_EnumJsonDeserializer_;
  }
  
  /**
   * @template M_E
   * @param {Class<M_E>} enumClass
   * @return {EnumJsonDeserializer<M_E>}
   * @public
   */
  static m_newInstance__java_lang_Class(enumClass) {
    EnumJsonDeserializer.$clinit();
    return /**@type {!EnumJsonDeserializer<Enum>} */ (EnumJsonDeserializer.$create__java_lang_Class(enumClass));
  }
  
  /**
   * Factory method corresponding to constructor 'EnumJsonDeserializer(Class)'.
   * @template C_E
   * @param {Class<C_E>} enumClass
   * @return {!EnumJsonDeserializer<C_E>}
   * @public
   */
  static $create__java_lang_Class(enumClass) {
    EnumJsonDeserializer.$clinit();
    let $instance = new EnumJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_EnumJsonDeserializer__java_lang_Class(enumClass);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EnumJsonDeserializer(Class)'.
   * @param {Class<C_E>} enumClass
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_EnumJsonDeserializer__java_lang_Class(enumClass) {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
    if ($Equality.$same(null, enumClass)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("enumClass cannot be null"));
    }
    this.f_enumClass__org_dominokit_jacksonapt_deser_EnumJsonDeserializer_ = enumClass;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_E}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    try {
      return Enum.m_valueOf__java_lang_Class__java_lang_String(this.f_enumClass__org_dominokit_jacksonapt_deser_EnumJsonDeserializer_, reader.m_nextString__());
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (IllegalArgumentException.$isInstance(__$exc)) {
        let ex = /**@type {IllegalArgumentException} */ (__$exc);
        if (ctx.m_isReadUnknownEnumValuesAsNull__()) {
          return null;
        }
        throw $Exceptions.toJs(ex);
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @return {Class<C_E>}
   * @public
   */
  m_getEnumClass__() {
    return this.f_enumClass__org_dominokit_jacksonapt_deser_EnumJsonDeserializer_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EnumJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EnumJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EnumJsonDeserializer.$clinit = function() {};
    Enum = goog.module.get('java.lang.Enum$impl');
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    JsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EnumJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.EnumJsonDeserializer'));




exports = EnumJsonDeserializer; 
//# sourceMappingURL=EnumJsonDeserializer.js.map