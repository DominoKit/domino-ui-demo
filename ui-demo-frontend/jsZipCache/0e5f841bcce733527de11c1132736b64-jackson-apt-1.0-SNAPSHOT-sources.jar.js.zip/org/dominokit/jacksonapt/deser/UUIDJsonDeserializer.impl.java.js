/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.UUIDJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.UUIDJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let UUID = goog.forwardDeclare('java.util.UUID$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {JsonDeserializer<UUID>}
  */
class UUIDJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {UUIDJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    UUIDJsonDeserializer.$clinit();
    return UUIDJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'UUIDJsonDeserializer()'.
   * @return {!UUIDJsonDeserializer}
   * @public
   */
  static $create__() {
    UUIDJsonDeserializer.$clinit();
    let $instance = new UUIDJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'UUIDJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {UUID}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return UUID.m_fromString__java_lang_String(reader.m_nextString__());
  }
  
  /**
   * @return {UUIDJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_() {
    return (UUIDJsonDeserializer.$clinit(), UUIDJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_);
  }
  
  /**
   * @param {UUIDJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_(value) {
    (UUIDJsonDeserializer.$clinit(), UUIDJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof UUIDJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, UUIDJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    UUIDJsonDeserializer.$clinit = function() {};
    UUID = goog.module.get('java.util.UUID$impl');
    JsonDeserializer.$clinit();
    UUIDJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_ = UUIDJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(UUIDJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.UUIDJsonDeserializer'));


/** @private {UUIDJsonDeserializer} */
UUIDJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_UUIDJsonDeserializer_;




exports = UUIDJsonDeserializer; 
//# sourceMappingURL=UUIDJsonDeserializer.js.map