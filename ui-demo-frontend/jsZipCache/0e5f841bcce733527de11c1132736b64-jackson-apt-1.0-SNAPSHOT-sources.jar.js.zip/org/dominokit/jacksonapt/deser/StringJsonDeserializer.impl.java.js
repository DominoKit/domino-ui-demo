/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.StringJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {JsonDeserializer<?string>}
  */
class StringJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {StringJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    StringJsonDeserializer.$clinit();
    return StringJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'StringJsonDeserializer()'.
   * @return {!StringJsonDeserializer}
   * @public
   */
  static $create__() {
    StringJsonDeserializer.$clinit();
    let $instance = new StringJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_StringJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StringJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_StringJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {?string}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return reader.m_nextString__();
  }
  
  /**
   * @return {StringJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_() {
    return (StringJsonDeserializer.$clinit(), StringJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_);
  }
  
  /**
   * @param {StringJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_(value) {
    (StringJsonDeserializer.$clinit(), StringJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StringJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StringJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StringJsonDeserializer.$clinit = function() {};
    JsonDeserializer.$clinit();
    StringJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_ = StringJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(StringJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.StringJsonDeserializer'));


/** @private {StringJsonDeserializer} */
StringJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_StringJsonDeserializer_;




exports = StringJsonDeserializer; 
//# sourceMappingURL=StringJsonDeserializer.js.map