/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer');
const _SortedSet = goog.require('java.util.SortedSet');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');


// Re-exports the implementation.
var BaseSortedSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer$impl');
exports = BaseSortedSetJsonDeserializer;
 