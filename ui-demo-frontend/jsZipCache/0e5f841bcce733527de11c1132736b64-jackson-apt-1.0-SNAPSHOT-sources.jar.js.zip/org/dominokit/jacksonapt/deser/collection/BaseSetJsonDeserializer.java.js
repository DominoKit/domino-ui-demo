/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseCollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer');
const _Set = goog.require('java.util.Set');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');


// Re-exports the implementation.
var BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer$impl');
exports = BaseSetJsonDeserializer;
 