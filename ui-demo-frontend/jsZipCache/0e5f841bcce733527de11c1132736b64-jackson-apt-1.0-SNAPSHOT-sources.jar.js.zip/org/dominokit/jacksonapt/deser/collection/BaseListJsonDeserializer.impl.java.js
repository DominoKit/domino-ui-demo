/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseListJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseListJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseCollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');


/**
 * @abstract
 * @template C_L, C_T
 * @extends {BaseCollectionJsonDeserializer<C_L, C_T>}
  */
class BaseListJsonDeserializer extends BaseCollectionJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseListJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_BaseListJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseListJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseListJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseListJsonDeserializer.$clinit = function() {};
    BaseCollectionJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseListJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.BaseListJsonDeserializer'));




exports = BaseListJsonDeserializer; 
//# sourceMappingURL=BaseListJsonDeserializer.js.map