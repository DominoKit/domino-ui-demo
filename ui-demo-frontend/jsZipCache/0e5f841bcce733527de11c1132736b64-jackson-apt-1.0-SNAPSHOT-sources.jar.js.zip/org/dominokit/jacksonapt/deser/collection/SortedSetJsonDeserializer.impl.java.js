/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.SortedSetJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.SortedSetJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseSortedSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let SortedSet = goog.forwardDeclare('java.util.SortedSet$impl');
let TreeSet = goog.forwardDeclare('java.util.TreeSet$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseSortedSetJsonDeserializer<SortedSet<C_T>, C_T>}
  */
class SortedSetJsonDeserializer extends BaseSortedSetJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {SortedSetJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    SortedSetJsonDeserializer.$clinit();
    return /**@type {!SortedSetJsonDeserializer<*>} */ (SortedSetJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'SortedSetJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!SortedSetJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    SortedSetJsonDeserializer.$clinit();
    let $instance = new SortedSetJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_SortedSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SortedSetJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_SortedSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseSortedSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {SortedSet<C_T>}
   * @public
   */
  m_newCollection__() {
    return /**@type {!TreeSet<C_T>} */ (TreeSet.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {SortedSet<C_T>} */ ($Casts.$to(arg2, SortedSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {SortedSet<C_T>} */ ($Casts.$to(arg2, SortedSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {SortedSet<C_T>} */ ($Casts.$to(arg2, SortedSet)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SortedSetJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SortedSetJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SortedSetJsonDeserializer.$clinit = function() {};
    SortedSet = goog.module.get('java.util.SortedSet$impl');
    TreeSet = goog.module.get('java.util.TreeSet$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseSortedSetJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SortedSetJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.SortedSetJsonDeserializer'));




exports = SortedSetJsonDeserializer; 
//# sourceMappingURL=SortedSetJsonDeserializer.js.map