/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.IterableJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.IterableJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseIterableJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_T
 * @extends {BaseIterableJsonDeserializer<Iterable<C_T>, C_T>}
  */
class IterableJsonDeserializer extends BaseIterableJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {IterableJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    IterableJsonDeserializer.$clinit();
    return /**@type {!IterableJsonDeserializer<*>} */ (IterableJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'IterableJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!IterableJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    IterableJsonDeserializer.$clinit();
    let $instance = new IterableJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_IterableJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IterableJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_IterableJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Iterable<C_T>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Equality.$same(JsonToken.f_BEGIN_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      let result = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
      reader.m_beginArray__();
      while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
        result.add(this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params));
      }
      reader.m_endArray__();
      return result;
    } else if (ctx.m_isAcceptSingleValueAsArray__()) {
      let result$1$ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
      result$1$.add(this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params));
      return result$1$;
    } else {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot deserialize a java.lang.Iterable out of " + j_l_String.m_valueOf__java_lang_Object(reader.m_peek__()) + " token", reader));
    }
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {Iterable<C_T>} */ ($Casts.$to(arg2, Iterable)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IterableJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IterableJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IterableJsonDeserializer.$clinit = function() {};
    Iterable = goog.module.get('java.lang.Iterable$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    BaseIterableJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IterableJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.IterableJsonDeserializer'));




exports = IterableJsonDeserializer; 
//# sourceMappingURL=IterableJsonDeserializer.js.map