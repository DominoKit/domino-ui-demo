/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.EnumSetJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.EnumSetJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Enum = goog.forwardDeclare('java.lang.Enum$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let EnumSet = goog.forwardDeclare('java.util.EnumSet$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let EnumJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_E
 * @extends {BaseSetJsonDeserializer<EnumSet<C_E>, C_E>}
  */
class EnumSetJsonDeserializer extends BaseSetJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Class<C_E>} */
    this.f_enumClass__org_dominokit_jacksonapt_deser_collection_EnumSetJsonDeserializer_;
  }
  
  /**
   * @template M_E
   * @param {EnumJsonDeserializer<M_E>} deserializer
   * @return {EnumSetJsonDeserializer<M_E>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_deser_EnumJsonDeserializer(deserializer) {
    EnumSetJsonDeserializer.$clinit();
    return /**@type {!EnumSetJsonDeserializer<Enum>} */ (EnumSetJsonDeserializer.$create__org_dominokit_jacksonapt_deser_EnumJsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'EnumSetJsonDeserializer(EnumJsonDeserializer)'.
   * @template C_E
   * @param {EnumJsonDeserializer<C_E>} deserializer
   * @return {!EnumSetJsonDeserializer<C_E>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_deser_EnumJsonDeserializer(deserializer) {
    EnumSetJsonDeserializer.$clinit();
    let $instance = new EnumSetJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_EnumSetJsonDeserializer__org_dominokit_jacksonapt_deser_EnumJsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EnumSetJsonDeserializer(EnumJsonDeserializer)'.
   * @param {EnumJsonDeserializer<C_E>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_EnumSetJsonDeserializer__org_dominokit_jacksonapt_deser_EnumJsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    this.f_enumClass__org_dominokit_jacksonapt_deser_collection_EnumSetJsonDeserializer_ = deserializer.m_getEnumClass__();
  }
  
  /**
   * @override
   * @return {EnumSet<C_E>}
   * @public
   */
  m_newCollection__() {
    return /**@type {EnumSet<C_E>} */ (EnumSet.m_noneOf__java_lang_Class(this.f_enumClass__org_dominokit_jacksonapt_deser_collection_EnumSetJsonDeserializer_));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isNullValueAllowed__() {
    return false;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {EnumSet<C_E>} */ ($Casts.$to(arg2, EnumSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {EnumSet<C_E>} */ ($Casts.$to(arg2, EnumSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {EnumSet<C_E>} */ ($Casts.$to(arg2, EnumSet)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EnumSetJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EnumSetJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EnumSetJsonDeserializer.$clinit = function() {};
    EnumSet = goog.module.get('java.util.EnumSet$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseSetJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EnumSetJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.EnumSetJsonDeserializer'));




exports = EnumSetJsonDeserializer; 
//# sourceMappingURL=EnumSetJsonDeserializer.js.map