/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.AbstractQueueJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.AbstractQueueJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseQueueJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseQueueJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let AbstractQueue = goog.forwardDeclare('java.util.AbstractQueue$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let PriorityQueue = goog.forwardDeclare('java.util.PriorityQueue$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseQueueJsonDeserializer<AbstractQueue<C_T>, C_T>}
  */
class AbstractQueueJsonDeserializer extends BaseQueueJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {AbstractQueueJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    AbstractQueueJsonDeserializer.$clinit();
    return /**@type {!AbstractQueueJsonDeserializer<*>} */ (AbstractQueueJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'AbstractQueueJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!AbstractQueueJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    AbstractQueueJsonDeserializer.$clinit();
    let $instance = new AbstractQueueJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_AbstractQueueJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AbstractQueueJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_AbstractQueueJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseQueueJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {AbstractQueue<C_T>}
   * @public
   */
  m_newCollection__() {
    return /**@type {!PriorityQueue<C_T>} */ (PriorityQueue.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractQueue<C_T>} */ ($Casts.$to(arg2, AbstractQueue)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractQueue<C_T>} */ ($Casts.$to(arg2, AbstractQueue)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractQueue<C_T>} */ ($Casts.$to(arg2, AbstractQueue)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractQueueJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractQueueJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractQueueJsonDeserializer.$clinit = function() {};
    AbstractQueue = goog.module.get('java.util.AbstractQueue$impl');
    PriorityQueue = goog.module.get('java.util.PriorityQueue$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseQueueJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractQueueJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.AbstractQueueJsonDeserializer'));




exports = AbstractQueueJsonDeserializer; 
//# sourceMappingURL=AbstractQueueJsonDeserializer.js.map