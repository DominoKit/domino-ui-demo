/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_I, C_T
 * @extends {JsonDeserializer<C_I>}
  */
class BaseIterableJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {JsonDeserializer<C_T>} */
    this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer;
  }
  
  /**
   * Initialization from constructor 'BaseIterableJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
    if ($Equality.$same(null, deserializer)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("deserializer can't be null"));
    }
    this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer = deserializer;
  }
  
  /**
   * @param {?string} referenceName
   * @param {*} reference
   * @param {C_I} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    if (!$Equality.$same(null, value)) {
      for (let $iterator = /**@type {Iterable} */ (value).m_iterator__(); $iterator.m_hasNext__(); ) {
        let val = $iterator.m_next__();
        this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, val, ctx);
      }
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseIterableJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseIterableJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseIterableJsonDeserializer.$clinit = function() {};
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    JsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseIterableJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer'));




exports = BaseIterableJsonDeserializer; 
//# sourceMappingURL=BaseIterableJsonDeserializer.js.map