/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.AbstractSetJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.AbstractSetJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _AbstractSet = goog.require('java.util.AbstractSet');
const _Collection = goog.require('java.util.Collection');
const _LinkedHashSet = goog.require('java.util.LinkedHashSet');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AbstractSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.AbstractSetJsonDeserializer$impl');
exports = AbstractSetJsonDeserializer;
 