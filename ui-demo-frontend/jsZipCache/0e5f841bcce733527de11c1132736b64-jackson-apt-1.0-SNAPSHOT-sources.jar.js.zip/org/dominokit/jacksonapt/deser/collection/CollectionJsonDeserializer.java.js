/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.CollectionJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.CollectionJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseCollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.CollectionJsonDeserializer$impl');
exports = CollectionJsonDeserializer;
 