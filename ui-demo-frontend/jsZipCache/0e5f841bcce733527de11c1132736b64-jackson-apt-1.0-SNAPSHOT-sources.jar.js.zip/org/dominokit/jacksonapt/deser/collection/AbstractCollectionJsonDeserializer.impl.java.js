/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.AbstractCollectionJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.AbstractCollectionJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseCollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let AbstractCollection = goog.forwardDeclare('java.util.AbstractCollection$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseCollectionJsonDeserializer<AbstractCollection<C_T>, C_T>}
  */
class AbstractCollectionJsonDeserializer extends BaseCollectionJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {AbstractCollectionJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    AbstractCollectionJsonDeserializer.$clinit();
    return /**@type {!AbstractCollectionJsonDeserializer<*>} */ (AbstractCollectionJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'AbstractCollectionJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!AbstractCollectionJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    AbstractCollectionJsonDeserializer.$clinit();
    let $instance = new AbstractCollectionJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_AbstractCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AbstractCollectionJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_AbstractCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {AbstractCollection<C_T>}
   * @public
   */
  m_newCollection__() {
    return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractCollection<C_T>} */ ($Casts.$to(arg2, AbstractCollection)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractCollection<C_T>} */ ($Casts.$to(arg2, AbstractCollection)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractCollection<C_T>} */ ($Casts.$to(arg2, AbstractCollection)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractCollectionJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractCollectionJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractCollectionJsonDeserializer.$clinit = function() {};
    AbstractCollection = goog.module.get('java.util.AbstractCollection$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseCollectionJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractCollectionJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.AbstractCollectionJsonDeserializer'));




exports = AbstractCollectionJsonDeserializer; 
//# sourceMappingURL=AbstractCollectionJsonDeserializer.js.map