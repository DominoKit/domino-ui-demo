/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _Iterable = goog.require('java.lang.Iterable');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var BaseIterableJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer$impl');
exports = BaseIterableJsonDeserializer;
 