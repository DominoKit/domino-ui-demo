/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.AbstractSetJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.AbstractSetJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let AbstractSet = goog.forwardDeclare('java.util.AbstractSet$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let LinkedHashSet = goog.forwardDeclare('java.util.LinkedHashSet$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseSetJsonDeserializer<AbstractSet<C_T>, C_T>}
  */
class AbstractSetJsonDeserializer extends BaseSetJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {AbstractSetJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    AbstractSetJsonDeserializer.$clinit();
    return /**@type {!AbstractSetJsonDeserializer<*>} */ (AbstractSetJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'AbstractSetJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!AbstractSetJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    AbstractSetJsonDeserializer.$clinit();
    let $instance = new AbstractSetJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_AbstractSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AbstractSetJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_AbstractSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {AbstractSet<C_T>}
   * @public
   */
  m_newCollection__() {
    return /**@type {!LinkedHashSet<C_T>} */ (LinkedHashSet.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractSet<C_T>} */ ($Casts.$to(arg2, AbstractSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractSet<C_T>} */ ($Casts.$to(arg2, AbstractSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractSet<C_T>} */ ($Casts.$to(arg2, AbstractSet)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractSetJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractSetJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractSetJsonDeserializer.$clinit = function() {};
    AbstractSet = goog.module.get('java.util.AbstractSet$impl');
    LinkedHashSet = goog.module.get('java.util.LinkedHashSet$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseSetJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractSetJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.AbstractSetJsonDeserializer'));




exports = AbstractSetJsonDeserializer; 
//# sourceMappingURL=AbstractSetJsonDeserializer.js.map