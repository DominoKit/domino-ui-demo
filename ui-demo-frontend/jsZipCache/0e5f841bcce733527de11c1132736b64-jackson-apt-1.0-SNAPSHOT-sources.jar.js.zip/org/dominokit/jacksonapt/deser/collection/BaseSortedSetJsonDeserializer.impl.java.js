/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer$impl');

let SortedSet = goog.forwardDeclare('java.util.SortedSet$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');


/**
 * @abstract
 * @template C_S, C_T
 * @extends {BaseSetJsonDeserializer<C_S, C_T>}
  */
class BaseSortedSetJsonDeserializer extends BaseSetJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseSortedSetJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_BaseSortedSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isNullValueAllowed__() {
    return false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseSortedSetJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseSortedSetJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseSortedSetJsonDeserializer.$clinit = function() {};
    BaseSetJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseSortedSetJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer'));




exports = BaseSortedSetJsonDeserializer; 
//# sourceMappingURL=BaseSortedSetJsonDeserializer.js.map