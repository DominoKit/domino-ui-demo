/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.HasDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.HasDeserializer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_V, C_S
  */
class HasDeserializer extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {C_S} */
    this.f_deserializer__org_dominokit_jacksonapt_deser_bean_HasDeserializer_;
  }
  
  /**
   * Initialization from constructor 'HasDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializer__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {C_S}
   * @public
   */
  m_getDeserializer__() {
    if ($Equality.$same(null, this.f_deserializer__org_dominokit_jacksonapt_deser_bean_HasDeserializer_)) {
      this.f_deserializer__org_dominokit_jacksonapt_deser_bean_HasDeserializer_ = /**@type {C_S} */ ($Casts.$to(this.m_newDeserializer__(), JsonDeserializer));
    }
    return this.f_deserializer__org_dominokit_jacksonapt_deser_bean_HasDeserializer_;
  }
  
  /**
   * @abstract
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HasDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HasDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasDeserializer.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonDeserializer = goog.module.get('org.dominokit.jacksonapt.JsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HasDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.HasDeserializer'));




exports = HasDeserializer; 
//# sourceMappingURL=HasDeserializer.js.map