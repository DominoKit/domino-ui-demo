/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$BeanSubtypeDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer.BeanSubtypeDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SubtypeDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let AbstractBeanJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_BeanSubtypeDeserializer_T
 * @extends {SubtypeDeserializer<C_BeanSubtypeDeserializer_T, AbstractBeanJsonDeserializer<C_BeanSubtypeDeserializer_T>>}
  */
class BeanSubtypeDeserializer extends SubtypeDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BeanSubtypeDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_SubtypeDeserializer_BeanSubtypeDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_SubtypeDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @param {Map<?string, ?string>} bufferedProperties
   * @return {C_BeanSubtypeDeserializer_T}
   * @public
   */
  m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, typeInformation, bufferedProperties) {
    return /**@type {AbstractBeanJsonDeserializer<C_BeanSubtypeDeserializer_T>} */ ($Casts.$to(this.m_getDeserializer__(), AbstractBeanJsonDeserializer)).m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, typeInformation, bufferedProperties);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {C_BeanSubtypeDeserializer_T}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation) {
    return /**@type {AbstractBeanJsonDeserializer<C_BeanSubtypeDeserializer_T>} */ ($Casts.$to(this.m_getDeserializer__(), AbstractBeanJsonDeserializer)).m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BeanSubtypeDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BeanSubtypeDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BeanSubtypeDeserializer.$clinit = function() {};
    AbstractBeanJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    SubtypeDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BeanSubtypeDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$BeanSubtypeDeserializer'));




exports = BeanSubtypeDeserializer; 
//# sourceMappingURL=SubtypeDeserializer$BeanSubtypeDeserializer.js.map