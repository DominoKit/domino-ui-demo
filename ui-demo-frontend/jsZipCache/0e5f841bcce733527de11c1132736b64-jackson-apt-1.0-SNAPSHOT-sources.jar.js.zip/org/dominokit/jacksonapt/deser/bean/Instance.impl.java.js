/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.Instance.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.Instance$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');


/**
 * @template C_T
  */
class Instance extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {C_T} */
    this.f_instance__org_dominokit_jacksonapt_deser_bean_Instance_;
    /** @public {Map<?string, ?string>} */
    this.f_bufferedProperties__org_dominokit_jacksonapt_deser_bean_Instance_;
  }
  
  /**
   * Factory method corresponding to constructor 'Instance(Object, Map)'.
   * @template C_T
   * @param {C_T} instance
   * @param {Map<?string, ?string>} bufferedProperties
   * @return {!Instance<C_T>}
   * @public
   */
  static $create__java_lang_Object__java_util_Map(instance, bufferedProperties) {
    Instance.$clinit();
    let $instance = new Instance();
    $instance.$ctor__org_dominokit_jacksonapt_deser_bean_Instance__java_lang_Object__java_util_Map(instance, bufferedProperties);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Instance(Object, Map)'.
   * @param {C_T} instance
   * @param {Map<?string, ?string>} bufferedProperties
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_Instance__java_lang_Object__java_util_Map(instance, bufferedProperties) {
    this.$ctor__java_lang_Object__();
    this.f_instance__org_dominokit_jacksonapt_deser_bean_Instance_ = instance;
    this.f_bufferedProperties__org_dominokit_jacksonapt_deser_bean_Instance_ = bufferedProperties;
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_getInstance__() {
    return this.f_instance__org_dominokit_jacksonapt_deser_bean_Instance_;
  }
  
  /**
   * @return {Map<?string, ?string>}
   * @public
   */
  m_getBufferedProperties__() {
    return this.f_bufferedProperties__org_dominokit_jacksonapt_deser_bean_Instance_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Instance;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Instance);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Instance.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Instance, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.Instance'));




exports = Instance; 
//# sourceMappingURL=Instance.js.map