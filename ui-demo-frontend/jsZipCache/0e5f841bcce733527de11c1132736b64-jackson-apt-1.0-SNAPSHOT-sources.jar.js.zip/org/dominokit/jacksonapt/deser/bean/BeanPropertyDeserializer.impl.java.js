/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasDeserializerAndParameters = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @abstract
 * @template C_T, C_V
 * @extends {HasDeserializerAndParameters<C_V, JsonDeserializer<C_V>>}
  */
class BeanPropertyDeserializer extends HasDeserializerAndParameters {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BeanPropertyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters__();
  }
  
  /**
   * @param {JsonReader} reader
   * @param {C_T} bean
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(reader, bean, ctx) {
    this.m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(bean, this.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx), ctx);
  }
  
  /**
   * @abstract
   * @param {C_T} bean
   * @param {C_V} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BeanPropertyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BeanPropertyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BeanPropertyDeserializer.$clinit = function() {};
    HasDeserializerAndParameters.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BeanPropertyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer'));




exports = BeanPropertyDeserializer; 
//# sourceMappingURL=BeanPropertyDeserializer.js.map