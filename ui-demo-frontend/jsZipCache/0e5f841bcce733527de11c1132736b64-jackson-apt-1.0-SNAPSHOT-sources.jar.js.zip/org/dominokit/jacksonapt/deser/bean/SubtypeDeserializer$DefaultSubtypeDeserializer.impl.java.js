/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$DefaultSubtypeDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer.DefaultSubtypeDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SubtypeDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_DefaultSubtypeDeserializer_T
 * @extends {SubtypeDeserializer<C_DefaultSubtypeDeserializer_T, JsonDeserializer<C_DefaultSubtypeDeserializer_T>>}
  */
class DefaultSubtypeDeserializer extends SubtypeDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'DefaultSubtypeDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_SubtypeDeserializer_DefaultSubtypeDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_SubtypeDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @param {Map<?string, ?string>} bufferedProperties
   * @return {C_DefaultSubtypeDeserializer_T}
   * @public
   */
  m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, typeInformation, bufferedProperties) {
    throw $Exceptions.toJs(ctx.m_traceError__java_lang_String("Cannot deserialize into a bean when not using an AbstractBeanJsonDeserializer"));
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {C_DefaultSubtypeDeserializer_T}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation) {
    return this.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultSubtypeDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultSubtypeDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultSubtypeDeserializer.$clinit = function() {};
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    SubtypeDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DefaultSubtypeDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$DefaultSubtypeDeserializer'));




exports = DefaultSubtypeDeserializer; 
//# sourceMappingURL=SubtypeDeserializer$DefaultSubtypeDeserializer.js.map