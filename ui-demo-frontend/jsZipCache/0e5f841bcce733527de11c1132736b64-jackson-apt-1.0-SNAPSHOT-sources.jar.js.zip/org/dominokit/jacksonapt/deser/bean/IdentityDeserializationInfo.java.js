/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
exports = IdentityDeserializationInfo;
 