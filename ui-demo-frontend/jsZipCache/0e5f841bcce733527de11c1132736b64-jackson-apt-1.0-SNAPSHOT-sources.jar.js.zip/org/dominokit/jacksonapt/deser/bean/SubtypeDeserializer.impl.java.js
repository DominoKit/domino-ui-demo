/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializer$impl');
const InternalDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.InternalDeserializer$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @abstract
 * @template C_T, C_D
 * @extends {HasDeserializer<C_T, C_D>}
 * @implements {InternalDeserializer<C_T, C_D>}
  */
class SubtypeDeserializer extends HasDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'SubtypeDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_SubtypeDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializer__();
  }
  
  /**
   * @abstract
   * @override
   * @param {JsonReader} arg0
   * @param {JsonDeserializationContext} arg1
   * @param {JsonDeserializerParameters} arg2
   * @param {IdentityDeserializationInfo} arg3
   * @param {TypeDeserializationInfo} arg4
   * @param {?string} arg5
   * @param {Map<?string, ?string>} arg6
   * @return {C_T}
   * @public
   */
  m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
  }
  
  /**
   * @abstract
   * @override
   * @param {JsonReader} arg0
   * @param {JsonDeserializationContext} arg1
   * @param {JsonDeserializerParameters} arg2
   * @param {IdentityDeserializationInfo} arg3
   * @param {TypeDeserializationInfo} arg4
   * @param {?string} arg5
   * @return {C_T}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(arg0, arg1, arg2, arg3, arg4, arg5) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SubtypeDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SubtypeDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SubtypeDeserializer.$clinit = function() {};
    HasDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SubtypeDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer'));


InternalDeserializer.$markImplementor(SubtypeDeserializer);


exports = SubtypeDeserializer; 
//# sourceMappingURL=SubtypeDeserializer.js.map