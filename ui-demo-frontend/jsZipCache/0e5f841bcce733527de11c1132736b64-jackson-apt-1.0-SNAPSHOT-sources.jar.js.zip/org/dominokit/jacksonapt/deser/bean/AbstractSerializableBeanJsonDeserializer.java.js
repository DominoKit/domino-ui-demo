/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractSerializableBeanJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractSerializableBeanJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Serializable = goog.require('java.io.Serializable');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _NumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.NumberJsonDeserializer');
const _BooleanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer');
const _StringJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.StringJsonDeserializer');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _TypeDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo');
const _ArrayListJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.ArrayListJsonDeserializer');
const _LinkedHashMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.LinkedHashMapJsonDeserializer');
const _StringKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.StringKeyDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var AbstractSerializableBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractSerializableBeanJsonDeserializer$impl');
exports = AbstractSerializableBeanJsonDeserializer;
 