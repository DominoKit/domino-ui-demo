/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _InternalDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.InternalDeserializer');
const _As = goog.require('com.fasterxml.jackson.annotation.JsonTypeInfo.As');
const _Class = goog.require('java.lang.Class');
const _j_l_Object = goog.require('java.lang.Object');
const _j_l_String = goog.require('java.lang.String');
const _Collections = goog.require('java.util.Collections');
const _HashMap = goog.require('java.util.HashMap');
const _HashSet = goog.require('java.util.HashSet');
const _Map = goog.require('java.util.Map');
const _Entry = goog.require('java.util.Map.Entry');
const _Set = goog.require('java.util.Set');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _AnySetterDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AnySetterDeserializer');
const _BackReferenceProperty = goog.require('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _HasDeserializerAndParameters = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');
const _SubtypeDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer');
const _TypeDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');
exports = AbstractBeanJsonDeserializer;
 