/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractDelegationBeanJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractDelegationBeanJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _TypeDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var AbstractDelegationBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractDelegationBeanJsonDeserializer$impl');
exports = AbstractDelegationBeanJsonDeserializer;
 