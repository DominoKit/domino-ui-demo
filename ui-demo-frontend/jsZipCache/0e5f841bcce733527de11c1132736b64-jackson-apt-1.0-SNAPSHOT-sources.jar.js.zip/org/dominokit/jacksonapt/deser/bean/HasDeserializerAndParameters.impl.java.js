/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializer$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @abstract
 * @template C_V, C_S
 * @extends {HasDeserializer<C_V, C_S>}
  */
class HasDeserializerAndParameters extends HasDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {JsonDeserializerParameters} */
    this.f_parameters__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters_;
  }
  
  /**
   * Initialization from constructor 'HasDeserializerAndParameters()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializer__();
  }
  
  /**
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_getParameters__() {
    if ($Equality.$same(null, this.f_parameters__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters_)) {
      this.f_parameters__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters_ = this.m_newParameters__();
    }
    return this.f_parameters__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters_;
  }
  
  /**
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_newParameters__() {
    return JacksonContextProvider.m_get__().m_defaultDeserializerParameters__();
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @return {C_V}
   * @public
   */
  m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx) {
    return /**@type {JsonDeserializer} */ (this.m_getDeserializer__()).m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, this.m_getParameters__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HasDeserializerAndParameters;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HasDeserializerAndParameters);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasDeserializerAndParameters.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    HasDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HasDeserializerAndParameters, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters'));




exports = HasDeserializerAndParameters; 
//# sourceMappingURL=HasDeserializerAndParameters.js.map