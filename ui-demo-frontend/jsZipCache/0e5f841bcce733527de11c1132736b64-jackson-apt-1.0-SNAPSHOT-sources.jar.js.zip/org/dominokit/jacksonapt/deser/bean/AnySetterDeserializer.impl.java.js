/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AnySetterDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AnySetterDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasDeserializerAndParameters = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @abstract
 * @template C_T, C_V
 * @extends {HasDeserializerAndParameters<C_V, JsonDeserializer<C_V>>}
  */
class AnySetterDeserializer extends HasDeserializerAndParameters {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'AnySetterDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_AnySetterDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializerAndParameters__();
  }
  
  /**
   * @param {JsonReader} reader
   * @param {C_T} bean
   * @param {?string} propertyName
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__java_lang_Object__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(reader, bean, propertyName, ctx) {
    this.m_setValue__java_lang_Object__java_lang_String__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(bean, propertyName, this.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx), ctx);
  }
  
  /**
   * @abstract
   * @param {C_T} bean
   * @param {?string} propertyName
   * @param {C_V} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_String__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(bean, propertyName, value, ctx) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnySetterDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnySetterDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnySetterDeserializer.$clinit = function() {};
    HasDeserializerAndParameters.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnySetterDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.AnySetterDeserializer'));




exports = AnySetterDeserializer; 
//# sourceMappingURL=AnySetterDeserializer.js.map