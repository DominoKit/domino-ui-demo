/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.InternalDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.InternalDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 * @template C_T, C_S
 */
class InternalDeserializer {
  /**
   * @abstract
   * @return {C_S}
   * @public
   */
  m_getDeserializer__() {
  }
  
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @param {Map<?string, ?string>} bufferedProperties
   * @return {C_T}
   * @public
   */
  m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, typeInformation, bufferedProperties) {
  }
  
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {C_T}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_InternalDeserializer = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_bean_InternalDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_InternalDeserializer;
  }
  
  /**
   * @public
   */
  static $clinit() {
    InternalDeserializer.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(InternalDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.InternalDeserializer'));


InternalDeserializer.$markImplementor(/** @type {Function} */ (InternalDeserializer));


exports = InternalDeserializer; 
//# sourceMappingURL=InternalDeserializer.js.map