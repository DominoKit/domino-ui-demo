/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.PropertyIdentityDeserializationInfo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.PropertyIdentityDeserializationInfo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');
const _Class = goog.require('java.lang.Class');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var PropertyIdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.PropertyIdentityDeserializationInfo$impl');
exports = PropertyIdentityDeserializationInfo;
 