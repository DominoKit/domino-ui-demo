/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.JsMapLike.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.JsMapLike');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');
const _Any_$Overlay = goog.require('jsinterop.base.Any.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var JsMapLike = goog.require('org.dominokit.jacksonapt.deser.bean.JsMapLike$impl');
exports = JsMapLike;
 