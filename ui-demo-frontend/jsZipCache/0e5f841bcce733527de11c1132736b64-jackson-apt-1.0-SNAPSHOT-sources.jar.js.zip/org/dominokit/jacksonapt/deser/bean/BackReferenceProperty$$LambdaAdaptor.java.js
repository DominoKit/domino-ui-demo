/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _BackReferenceProperty = goog.require('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 