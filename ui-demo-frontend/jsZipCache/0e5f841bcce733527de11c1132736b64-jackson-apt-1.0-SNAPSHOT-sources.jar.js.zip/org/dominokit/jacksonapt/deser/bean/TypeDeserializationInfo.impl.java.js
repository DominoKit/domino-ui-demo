/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let As = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonTypeInfo.As$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
  */
class TypeDeserializationInfo extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {As} */
    this.f_include__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_;
    /** @public {?string} */
    this.f_propertyName__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_;
    /** @public {Map<?string, Class<?>>} */
    this.f_typeInfoToClass__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_;
  }
  
  /**
   * Factory method corresponding to constructor 'TypeDeserializationInfo(As, String)'.
   * @template C_T
   * @param {As} include
   * @param {?string} propertyName
   * @return {!TypeDeserializationInfo<C_T>}
   * @public
   */
  static $create__com_fasterxml_jackson_annotation_JsonTypeInfo_As__java_lang_String(include, propertyName) {
    TypeDeserializationInfo.$clinit();
    let $instance = new TypeDeserializationInfo();
    $instance.$ctor__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__com_fasterxml_jackson_annotation_JsonTypeInfo_As__java_lang_String(include, propertyName);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypeDeserializationInfo(As, String)'.
   * @param {As} include
   * @param {?string} propertyName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__com_fasterxml_jackson_annotation_JsonTypeInfo_As__java_lang_String(include, propertyName) {
    this.$ctor__java_lang_Object__();
    this.f_include__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_ = include;
    this.f_propertyName__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_ = propertyName;
    this.f_typeInfoToClass__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_ = /**@type {!HashMap<?string, Class<?>>} */ (HashMap.$create__());
  }
  
  /**
   * @template M_S
   * @param {Class<M_S>} clazz
   * @param {?string} typeInfo
   * @return {TypeDeserializationInfo<C_T>}
   * @public
   */
  m_addTypeInfo__java_lang_Class__java_lang_String(clazz, typeInfo) {
    this.f_typeInfoToClass__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_.put(typeInfo, clazz);
    return this;
  }
  
  /**
   * @return {As}
   * @public
   */
  m_getInclude__() {
    return this.f_include__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPropertyName__() {
    return this.f_propertyName__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_;
  }
  
  /**
   * @param {?string} typeInfo
   * @return {Class<?>}
   * @public
   */
  m_getTypeClass__java_lang_String(typeInfo) {
    return /**@type {Class<*>} */ ($Casts.$to(this.f_typeInfoToClass__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo_.get(typeInfo), Class));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypeDeserializationInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypeDeserializationInfo);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypeDeserializationInfo.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TypeDeserializationInfo, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo'));




exports = TypeDeserializationInfo; 
//# sourceMappingURL=TypeDeserializationInfo.js.map