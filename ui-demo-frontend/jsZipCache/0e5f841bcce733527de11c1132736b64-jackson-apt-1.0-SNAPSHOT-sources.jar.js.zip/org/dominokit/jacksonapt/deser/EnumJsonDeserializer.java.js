/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.EnumJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.EnumJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Enum = goog.require('java.lang.Enum');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var EnumJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.EnumJsonDeserializer$impl');
exports = EnumJsonDeserializer;
 