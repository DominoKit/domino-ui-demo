/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$ByteJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ByteJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let Byte = goog.forwardDeclare('java.lang.Byte$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


/**
 * @extends {BaseNumberJsonDeserializer<Byte>}
  */
class ByteJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {ByteJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    ByteJsonDeserializer.$clinit();
    return ByteJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'ByteJsonDeserializer()'.
   * @return {!ByteJsonDeserializer}
   * @public
   */
  static $create__() {
    ByteJsonDeserializer.$clinit();
    let $instance = new ByteJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ByteJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Byte}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return Byte.m_valueOf__byte($Primitives.$narrowIntToByte(reader.m_nextInt__()));
  }
  
  /**
   * @return {ByteJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_() {
    return (ByteJsonDeserializer.$clinit(), ByteJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_);
  }
  
  /**
   * @param {ByteJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_(value) {
    (ByteJsonDeserializer.$clinit(), ByteJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ByteJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ByteJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ByteJsonDeserializer.$clinit = function() {};
    Byte = goog.module.get('java.lang.Byte$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    BaseNumberJsonDeserializer.$clinit();
    ByteJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_ = ByteJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(ByteJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$ByteJsonDeserializer'));


/** @private {ByteJsonDeserializer} */
ByteJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_ByteJsonDeserializer_;




exports = ByteJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$ByteJsonDeserializer.js.map