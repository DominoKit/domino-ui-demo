/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _Number = goog.require('java.lang.Number');


// Re-exports the implementation.
var BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');
exports = BaseNumberJsonDeserializer;
 