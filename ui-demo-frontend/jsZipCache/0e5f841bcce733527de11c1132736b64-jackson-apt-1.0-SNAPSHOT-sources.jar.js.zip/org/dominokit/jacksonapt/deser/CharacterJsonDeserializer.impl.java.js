/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.CharacterJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let Character = goog.forwardDeclare('java.lang.Character$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


/**
 * @extends {JsonDeserializer<Character>}
  */
class CharacterJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {CharacterJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    CharacterJsonDeserializer.$clinit();
    return CharacterJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'CharacterJsonDeserializer()'.
   * @return {!CharacterJsonDeserializer}
   * @public
   */
  static $create__() {
    CharacterJsonDeserializer.$clinit();
    let $instance = new CharacterJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CharacterJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Character}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NUMBER__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return Character.m_valueOf__char($Primitives.$narrowIntToChar(reader.m_nextInt__()));
    } else {
      let value = reader.m_nextString__();
      if (j_l_String.m_isEmpty__java_lang_String(value)) {
        return null;
      }
      return Character.m_valueOf__char(j_l_String.m_charAt__java_lang_String__int(value, 0));
    }
  }
  
  /**
   * @return {CharacterJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_() {
    return (CharacterJsonDeserializer.$clinit(), CharacterJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_);
  }
  
  /**
   * @param {CharacterJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_(value) {
    (CharacterJsonDeserializer.$clinit(), CharacterJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CharacterJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CharacterJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CharacterJsonDeserializer.$clinit = function() {};
    Character = goog.module.get('java.lang.Character$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    JsonDeserializer.$clinit();
    CharacterJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_ = CharacterJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(CharacterJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer'));


/** @private {CharacterJsonDeserializer} */
CharacterJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_CharacterJsonDeserializer_;




exports = CharacterJsonDeserializer; 
//# sourceMappingURL=CharacterJsonDeserializer.js.map