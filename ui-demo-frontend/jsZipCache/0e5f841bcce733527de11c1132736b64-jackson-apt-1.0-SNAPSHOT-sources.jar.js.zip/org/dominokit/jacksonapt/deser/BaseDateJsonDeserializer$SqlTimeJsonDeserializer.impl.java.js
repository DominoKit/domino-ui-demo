/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlTimeJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.SqlTimeJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$impl');

let Time = goog.forwardDeclare('java.sql.Time$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');


/**
 * @extends {BaseDateJsonDeserializer<Time>}
  */
class SqlTimeJsonDeserializer extends BaseDateJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {SqlTimeJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    SqlTimeJsonDeserializer.$clinit();
    return SqlTimeJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'SqlTimeJsonDeserializer()'.
   * @return {!SqlTimeJsonDeserializer}
   * @public
   */
  static $create__() {
    SqlTimeJsonDeserializer.$clinit();
    let $instance = new SqlTimeJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SqlTimeJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @param {JsonDeserializerParameters} params
   * @return {Time}
   * @public
   */
  m_deserializeNumber__long__org_dominokit_jacksonapt_JsonDeserializerParameters(millis, params) {
    return Time.$create__long(millis);
  }
  
  /**
   * @override
   * @param {?string} date
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Time}
   * @public
   */
  m_deserializeString__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(date, ctx, params) {
    return Time.m_valueOf__java_lang_String(date);
  }
  
  /**
   * @return {SqlTimeJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_() {
    return (SqlTimeJsonDeserializer.$clinit(), SqlTimeJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_);
  }
  
  /**
   * @param {SqlTimeJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_(value) {
    (SqlTimeJsonDeserializer.$clinit(), SqlTimeJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SqlTimeJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SqlTimeJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SqlTimeJsonDeserializer.$clinit = function() {};
    Time = goog.module.get('java.sql.Time$impl');
    BaseDateJsonDeserializer.$clinit();
    SqlTimeJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_ = SqlTimeJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(SqlTimeJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$SqlTimeJsonDeserializer'));


/** @private {SqlTimeJsonDeserializer} */
SqlTimeJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_SqlTimeJsonDeserializer_;




exports = SqlTimeJsonDeserializer; 
//# sourceMappingURL=BaseDateJsonDeserializer$SqlTimeJsonDeserializer.js.map