/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveFloatArrayJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveFloatArrayJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer');
const _Float = goog.require('java.lang.Float');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _FloatJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.FloatJsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$float = goog.require('vmbootstrap.primitives.$float');


// Re-exports the implementation.
var PrimitiveFloatArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.PrimitiveFloatArrayJsonDeserializer$impl');
exports = PrimitiveFloatArrayJsonDeserializer;
 