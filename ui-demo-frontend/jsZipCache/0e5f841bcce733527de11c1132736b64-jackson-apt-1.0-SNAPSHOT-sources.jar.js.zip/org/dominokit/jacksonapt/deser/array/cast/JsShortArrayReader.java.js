/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ShortArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader');
const _BaseJsNumberArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _$Overlay = goog.require('elemental2.core.JsNumber.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var JsShortArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader$impl');
exports = JsShortArrayReader;
 