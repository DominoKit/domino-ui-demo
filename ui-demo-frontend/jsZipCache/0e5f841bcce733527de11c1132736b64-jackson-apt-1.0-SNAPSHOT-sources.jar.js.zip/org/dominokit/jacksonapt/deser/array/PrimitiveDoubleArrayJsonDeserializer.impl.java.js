/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveDoubleArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveDoubleArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Double = goog.forwardDeclare('java.lang.Double$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let DoubleJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.DoubleJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $double = goog.forwardDeclare('vmbootstrap.primitives.$double$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<number>>}
  */
class PrimitiveDoubleArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveDoubleArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveDoubleArrayJsonDeserializer.$clinit();
    return PrimitiveDoubleArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveDoubleArrayJsonDeserializer()'.
   * @return {!PrimitiveDoubleArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveDoubleArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveDoubleArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveDoubleArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<?number>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, DoubleJsonDeserializer.m_getInstance__(), params));
    let result = /**@type {!Array<number>} */ ($Arrays.$create([list.size()], $double));
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let value = /**@type {?number} */ ($Casts.$to($iterator.m_next__(), Double));
      if (!$Equality.$same(null, value)) {
        $Arrays.$set(result, i, Double.m_doubleValue__java_lang_Double(value));
      }
      i++;
    }
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<number>} */ ($Arrays.$init([Double.m_doubleValue__java_lang_Double(/**@type {?number} */ ($Casts.$to(DoubleJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Double)))], $double));
  }
  
  /**
   * @return {PrimitiveDoubleArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_() {
    return (PrimitiveDoubleArrayJsonDeserializer.$clinit(), PrimitiveDoubleArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveDoubleArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_(value) {
    (PrimitiveDoubleArrayJsonDeserializer.$clinit(), PrimitiveDoubleArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveDoubleArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveDoubleArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveDoubleArrayJsonDeserializer.$clinit = function() {};
    Double = goog.module.get('java.lang.Double$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    DoubleJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.DoubleJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $double = goog.module.get('vmbootstrap.primitives.$double$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveDoubleArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_ = PrimitiveDoubleArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveDoubleArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.PrimitiveDoubleArrayJsonDeserializer'));


/** @private {PrimitiveDoubleArrayJsonDeserializer} */
PrimitiveDoubleArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveDoubleArrayJsonDeserializer_;




exports = PrimitiveDoubleArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveDoubleArrayJsonDeserializer.js.map