/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveLongArrayJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveLongArrayJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer');
const _Long = goog.require('java.lang.Long');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Long = goog.require('nativebootstrap.Long');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _LongJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.LongJsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$long = goog.require('vmbootstrap.primitives.$long');


// Re-exports the implementation.
var PrimitiveLongArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.PrimitiveLongArrayJsonDeserializer$impl');
exports = PrimitiveLongArrayJsonDeserializer;
 