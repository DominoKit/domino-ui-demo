/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collections = goog.forwardDeclare('java.util.Collections$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_T
 * @extends {JsonDeserializer<C_T>}
  */
class AbstractArrayJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'AbstractArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Equality.$same(JsonToken.f_BEGIN_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return this.m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
    } else {
      return this.m_doDeserializeNonArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
    }
  }
  
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_doDeserializeNonArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if (ctx.m_isAcceptSingleValueAsArray__()) {
      return this.m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
    } else {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot deserialize an array out of " + j_l_String.m_valueOf__java_lang_Object(reader.m_peek__()) + " token", reader));
    }
  }
  
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
  }
  
  /**
   * @template M_C
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializer<M_C>} deserializer
   * @param {JsonDeserializerParameters} params
   * @return {List<M_C>}
   * @public
   */
  m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, deserializer, params) {
    let /** List<*> */ list;
    reader.m_beginArray__();
    let token = reader.m_peek__();
    if ($Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      list = /**@type {List<*>} */ (Collections.m_emptyList__());
    } else {
      list = /**@type {!ArrayList<*>} */ (ArrayList.$create__());
      while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
        list.add(deserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params));
        token = reader.m_peek__();
      }
    }
    reader.m_endArray__();
    return list;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractArrayJsonDeserializer.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Collections = goog.module.get('java.util.Collections$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    JsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer'));




exports = AbstractArrayJsonDeserializer; 
//# sourceMappingURL=AbstractArrayJsonDeserializer.js.map