/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveCharacterArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveCharacterArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Character = goog.forwardDeclare('java.lang.Character$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let CharacterJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $char = goog.forwardDeclare('vmbootstrap.primitives.$char$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<number>>}
  */
class PrimitiveCharacterArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveCharacterArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveCharacterArrayJsonDeserializer.$clinit();
    return PrimitiveCharacterArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveCharacterArrayJsonDeserializer()'.
   * @return {!PrimitiveCharacterArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveCharacterArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveCharacterArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveCharacterArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<Character>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, CharacterJsonDeserializer.m_getInstance__(), params));
    let result = /**@type {!Array<number>} */ ($Arrays.$create([list.size()], $char));
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let value = /**@type {Character} */ ($Casts.$to($iterator.m_next__(), Character));
      if (!$Equality.$same(null, value)) {
        $Arrays.$set(result, i, value.m_charValue__());
      }
      i++;
    }
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeNonArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Equality.$same(JsonToken.f_STRING__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return j_l_String.m_toCharArray__java_lang_String(reader.m_nextString__());
    } else if (ctx.m_isAcceptSingleValueAsArray__()) {
      return this.m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
    } else {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot deserialize a char[] out of " + j_l_String.m_valueOf__java_lang_Object(reader.m_peek__()) + " token", reader));
    }
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<number>} */ ($Arrays.$init([/**@type {Character} */ ($Casts.$to(CharacterJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Character)).m_charValue__()], $char));
  }
  
  /**
   * @return {PrimitiveCharacterArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_() {
    return (PrimitiveCharacterArrayJsonDeserializer.$clinit(), PrimitiveCharacterArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveCharacterArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_(value) {
    (PrimitiveCharacterArrayJsonDeserializer.$clinit(), PrimitiveCharacterArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveCharacterArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveCharacterArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveCharacterArrayJsonDeserializer.$clinit = function() {};
    Character = goog.module.get('java.lang.Character$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    CharacterJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $char = goog.module.get('vmbootstrap.primitives.$char$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveCharacterArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_ = PrimitiveCharacterArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveCharacterArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.PrimitiveCharacterArrayJsonDeserializer'));


/** @private {PrimitiveCharacterArrayJsonDeserializer} */
PrimitiveCharacterArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveCharacterArrayJsonDeserializer_;




exports = PrimitiveCharacterArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveCharacterArrayJsonDeserializer.js.map