/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveIntegerArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveIntegerArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let IntegerJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $int = goog.forwardDeclare('vmbootstrap.primitives.$int$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<number>>>}
  */
class PrimitiveIntegerArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveIntegerArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveIntegerArray2dJsonDeserializer.$clinit();
    return PrimitiveIntegerArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveIntegerArray2dJsonDeserializer()'.
   * @return {!PrimitiveIntegerArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveIntegerArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveIntegerArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveIntegerArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<number>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<List<Integer>>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, IntegerJsonDeserializer.m_getInstance__(), params));
    if (list.isEmpty()) {
      return /**@type {!Array<Array<number>>} */ ($Arrays.$create([0, 0], $int));
    }
    let firstList = /**@type {List<Integer>} */ ($Casts.$to(list.getAtIndex(0), List));
    if (firstList.isEmpty()) {
      return /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), 0], $int));
    }
    let array = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), firstList.size()], $int));
    let i = 0;
    let /** number */ j;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let innerList = /**@type {List<Integer>} */ ($Casts.$to($iterator.m_next__(), List));
      j = 0;
      for (let $iterator$1$ = innerList.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
        let value = /**@type {Integer} */ ($Casts.$to($iterator$1$.m_next__(), Integer));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(array[i], j, value.m_intValue__());
        }
        j++;
      }
      i++;
    }
    return array;
  }
  
  /**
   * @return {PrimitiveIntegerArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_() {
    return (PrimitiveIntegerArray2dJsonDeserializer.$clinit(), PrimitiveIntegerArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveIntegerArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_(value) {
    (PrimitiveIntegerArray2dJsonDeserializer.$clinit(), PrimitiveIntegerArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveIntegerArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveIntegerArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveIntegerArray2dJsonDeserializer.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    IntegerJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $int = goog.module.get('vmbootstrap.primitives.$int$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveIntegerArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_ = PrimitiveIntegerArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveIntegerArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveIntegerArray2dJsonDeserializer'));


/** @private {PrimitiveIntegerArray2dJsonDeserializer} */
PrimitiveIntegerArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveIntegerArray2dJsonDeserializer_;




exports = PrimitiveIntegerArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveIntegerArray2dJsonDeserializer.js.map