/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveCharacterArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveCharacterArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Character = goog.forwardDeclare('java.lang.Character$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let CharacterJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $char = goog.forwardDeclare('vmbootstrap.primitives.$char$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<number>>>}
  */
class PrimitiveCharacterArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveCharacterArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveCharacterArray2dJsonDeserializer.$clinit();
    return PrimitiveCharacterArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveCharacterArray2dJsonDeserializer()'.
   * @return {!PrimitiveCharacterArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveCharacterArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveCharacterArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveCharacterArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<number>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let /** Array<Array<number>> */ result;
    reader.m_beginArray__();
    let token = reader.m_peek__();
    if ($Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([0, 0], $char));
    } else if ($Equality.$same(JsonToken.f_STRING__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      let list = /**@type {!ArrayList<Array<number>>} */ (ArrayList.$create__());
      let size = 0;
      while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
        let decoded = j_l_String.m_toCharArray__java_lang_String(reader.m_nextString__());
        size = Math.max(size, decoded.length);
        list.add(decoded);
        token = reader.m_peek__();
      }
      result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), size], $char));
      let i = 0;
      for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
        let value = /**@type {Array<number>} */ ($Arrays.$castTo($iterator.m_next__(), $char, 1));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(result, i, value);
        }
        i++;
      }
    } else {
      let list$1$ = /**@type {List<List<Character>>} */ (this.m_doDeserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_stream_JsonToken(reader, ctx, CharacterJsonDeserializer.m_getInstance__(), params, token));
      let firstList = /**@type {List<Character>} */ ($Casts.$to(list$1$.getAtIndex(0), List));
      if (firstList.isEmpty()) {
        result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list$1$.size(), 0], $char));
      } else {
        result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list$1$.size(), firstList.size()], $char));
        let i$1$ = 0;
        let /** number */ j;
        for (let $iterator$1$ = list$1$.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
          let innerList = /**@type {List<Character>} */ ($Casts.$to($iterator$1$.m_next__(), List));
          j = 0;
          for (let $iterator$2$ = innerList.m_iterator__(); $iterator$2$.m_hasNext__(); ) {
            let value$1$ = /**@type {Character} */ ($Casts.$to($iterator$2$.m_next__(), Character));
            if (!$Equality.$same(null, value$1$)) {
              $Arrays.$set(result[i$1$], j, value$1$.m_charValue__());
            }
            j++;
          }
          i$1$++;
        }
      }
    }
    reader.m_endArray__();
    return result;
  }
  
  /**
   * @return {PrimitiveCharacterArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_() {
    return (PrimitiveCharacterArray2dJsonDeserializer.$clinit(), PrimitiveCharacterArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveCharacterArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_(value) {
    (PrimitiveCharacterArray2dJsonDeserializer.$clinit(), PrimitiveCharacterArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveCharacterArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveCharacterArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveCharacterArray2dJsonDeserializer.$clinit = function() {};
    Character = goog.module.get('java.lang.Character$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    CharacterJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $char = goog.module.get('vmbootstrap.primitives.$char$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveCharacterArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_ = PrimitiveCharacterArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveCharacterArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveCharacterArray2dJsonDeserializer'));


/** @private {PrimitiveCharacterArray2dJsonDeserializer} */
PrimitiveCharacterArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveCharacterArray2dJsonDeserializer_;




exports = PrimitiveCharacterArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveCharacterArray2dJsonDeserializer.js.map