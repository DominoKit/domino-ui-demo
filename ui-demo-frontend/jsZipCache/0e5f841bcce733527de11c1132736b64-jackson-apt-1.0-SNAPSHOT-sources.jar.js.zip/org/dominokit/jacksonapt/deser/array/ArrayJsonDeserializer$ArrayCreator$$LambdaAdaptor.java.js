/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$ArrayCreator$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ArrayCreator = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 