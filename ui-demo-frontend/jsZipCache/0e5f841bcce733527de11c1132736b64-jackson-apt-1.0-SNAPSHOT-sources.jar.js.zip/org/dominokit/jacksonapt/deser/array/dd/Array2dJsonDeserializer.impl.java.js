/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let Array2dCreator = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.Array2dCreator$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_T
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<C_T>>>}
  */
class Array2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {JsonDeserializer<C_T>} */
    this.f_deserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_;
    /** @public {Array2dCreator<C_T>} */
    this.f_array2dCreator__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_;
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @param {Array2dCreator<M_T>} arrayCreator
   * @return {Array2dJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator(deserializer, arrayCreator) {
    Array2dJsonDeserializer.$clinit();
    return /**@type {!Array2dJsonDeserializer<*>} */ (Array2dJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator(deserializer, arrayCreator));
  }
  
  /**
   * Factory method corresponding to constructor 'Array2dJsonDeserializer(JsonDeserializer, Array2dCreator)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @param {Array2dCreator<C_T>} array2dCreator
   * @return {!Array2dJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator(deserializer, array2dCreator) {
    Array2dJsonDeserializer.$clinit();
    let $instance = new Array2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator(deserializer, array2dCreator);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Array2dJsonDeserializer(JsonDeserializer, Array2dCreator)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @param {Array2dCreator<C_T>} array2dCreator
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator(deserializer, array2dCreator) {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
    if ($Equality.$same(null, deserializer)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("deserializer cannot be null"));
    }
    if ($Equality.$same(null, array2dCreator)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("Cannot deserialize an array without an array2dCreator"));
    }
    this.f_deserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_ = deserializer;
    this.f_array2dCreator__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_ = array2dCreator;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<C_T>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<List<C_T>>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, this.f_deserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_, params));
    if (list.isEmpty()) {
      return this.f_array2dCreator__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_.m_create__int__int(0, 0);
    }
    let firstList = /**@type {List<C_T>} */ ($Casts.$to(list.getAtIndex(0), List));
    if (firstList.isEmpty()) {
      return this.f_array2dCreator__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_.m_create__int__int(list.size(), 0);
    }
    let array = this.f_array2dCreator__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_.m_create__int__int(list.size(), firstList.size());
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let innerList = /**@type {List<C_T>} */ ($Casts.$to($iterator.m_next__(), List));
      $Arrays.$set(array, i, innerList.m_toArray__arrayOf_java_lang_Object(array[i]));
      i++;
    }
    return array;
  }
  
  /**
   * @param {?string} referenceName
   * @param {*} reference
   * @param {Array<Array<C_T>>} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__arrayOf_arrayOf_java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    if (!$Equality.$same(null, value) && value.length > 0) {
      for (let $array = value, $index = 0; $index < $array.length; $index++) {
        let array = $array[$index];
        for (let $array$1$ = array, $index$1$ = 0; $index$1$ < $array$1$.length; $index$1$++) {
          let val = $array$1$[$index$1$];
          this.f_deserializer__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, val, ctx);
        }
      }
    }
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    this.m_setBackReference__java_lang_String__java_lang_Object__arrayOf_arrayOf_java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {Array<Array<C_T>>} */ ($Arrays.$castTo(arg2, j_l_Object, 2)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Array2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Array2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Array2dJsonDeserializer.$clinit = function() {};
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    AbstractArray2dJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Array2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer'));




exports = Array2dJsonDeserializer; 
//# sourceMappingURL=Array2dJsonDeserializer.js.map