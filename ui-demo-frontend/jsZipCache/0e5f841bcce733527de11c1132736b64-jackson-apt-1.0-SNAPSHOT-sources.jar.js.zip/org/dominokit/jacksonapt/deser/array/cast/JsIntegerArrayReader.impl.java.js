/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const IntegerArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader$impl');
const BaseJsNumberArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.core.JsNumber.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @implements {IntegerArrayReader}
  */
class JsIntegerArrayReader extends BaseJsNumberArrayReader {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'JsIntegerArrayReader()'.
   * @return {!JsIntegerArrayReader}
   * @public
   */
  static $create__() {
    JsIntegerArrayReader.$clinit();
    let $instance = new JsIntegerArrayReader();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_cast_JsIntegerArrayReader__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JsIntegerArrayReader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_cast_JsIntegerArrayReader__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_cast_BaseJsNumberArrayReader__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @return {Array<number>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
    return JsIntegerArrayReader.m_reinterpretCast__elemental2_core_JsArray_$p_org_dominokit_jacksonapt_deser_array_cast_JsIntegerArrayReader(super.m_readNumberArray__org_dominokit_jacksonapt_stream_JsonReader_$pp_org_dominokit_jacksonapt_deser_array_cast(reader));
  }
  
  /**
   * @param {Array<Number>} value
   * @return {Array<number>}
   * @public
   */
  static m_reinterpretCast__elemental2_core_JsArray_$p_org_dominokit_jacksonapt_deser_array_cast_JsIntegerArrayReader(value) {
    JsIntegerArrayReader.$clinit();
    let sliced = /**@type {Array<Number>} */ ($Arrays.$castToNative(value.slice()));
    return /**@type {Array<number>} */ (Js.m_uncheckedCast__java_lang_Object(sliced));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsIntegerArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsIntegerArrayReader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsIntegerArrayReader.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    BaseJsNumberArrayReader.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsIntegerArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader'));


IntegerArrayReader.$markImplementor(JsIntegerArrayReader);


exports = JsIntegerArrayReader; 
//# sourceMappingURL=JsIntegerArrayReader.js.map