/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$ArrayCreator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_ArrayCreator_T
 */
class ArrayCreator {
  /**
   * @abstract
   * @param {number} length
   * @return {Array<C_ArrayCreator_T>}
   * @public
   */
  m_create__int(length) {
  }
  
  /**
   * @template C_ArrayCreator_T
   * @param {?function(number):Array<C_ArrayCreator_T>} fn
   * @return {ArrayCreator<C_ArrayCreator_T>}
   * @public
   */
  static $adapt(fn) {
    ArrayCreator.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ArrayCreator.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ArrayCreator, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$ArrayCreator'));


ArrayCreator.$markImplementor(/** @type {Function} */ (ArrayCreator));


exports = ArrayCreator; 
//# sourceMappingURL=ArrayJsonDeserializer$ArrayCreator.js.map