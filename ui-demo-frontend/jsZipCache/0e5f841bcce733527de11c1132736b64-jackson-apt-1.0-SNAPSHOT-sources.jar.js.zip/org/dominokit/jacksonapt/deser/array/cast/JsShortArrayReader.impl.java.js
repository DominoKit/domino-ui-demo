/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ShortArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader$impl');
const BaseJsNumberArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.core.JsNumber.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @implements {ShortArrayReader}
  */
class JsShortArrayReader extends BaseJsNumberArrayReader {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'JsShortArrayReader()'.
   * @return {!JsShortArrayReader}
   * @public
   */
  static $create__() {
    JsShortArrayReader.$clinit();
    let $instance = new JsShortArrayReader();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_cast_JsShortArrayReader__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JsShortArrayReader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_cast_JsShortArrayReader__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_cast_BaseJsNumberArrayReader__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @return {Array<number>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
    return JsShortArrayReader.m_reinterpretCast__elemental2_core_JsArray_$p_org_dominokit_jacksonapt_deser_array_cast_JsShortArrayReader(super.m_readNumberArray__org_dominokit_jacksonapt_stream_JsonReader_$pp_org_dominokit_jacksonapt_deser_array_cast(reader));
  }
  
  /**
   * @param {Array<Number>} value
   * @return {Array<number>}
   * @public
   */
  static m_reinterpretCast__elemental2_core_JsArray_$p_org_dominokit_jacksonapt_deser_array_cast_JsShortArrayReader(value) {
    JsShortArrayReader.$clinit();
    let sliced = /**@type {Array<Number>} */ ($Arrays.$castToNative(value.slice()));
    return /**@type {Array<number>} */ (Js.m_uncheckedCast__java_lang_Object(sliced));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsShortArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsShortArrayReader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsShortArrayReader.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    BaseJsNumberArrayReader.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsShortArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader'));


ShortArrayReader.$markImplementor(JsShortArrayReader);


exports = JsShortArrayReader; 
//# sourceMappingURL=JsShortArrayReader.js.map