/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveCharacterArrayJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveCharacterArrayJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer');
const _Character = goog.require('java.lang.Character');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _CharacterJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$char = goog.require('vmbootstrap.primitives.$char');


// Re-exports the implementation.
var PrimitiveCharacterArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.PrimitiveCharacterArrayJsonDeserializer$impl');
exports = PrimitiveCharacterArrayJsonDeserializer;
 