/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveLongArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveLongArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Long = goog.forwardDeclare('java.lang.Long$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let LongJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.LongJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $long = goog.forwardDeclare('vmbootstrap.primitives.$long$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<!$Long>>>}
  */
class PrimitiveLongArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveLongArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveLongArray2dJsonDeserializer.$clinit();
    return PrimitiveLongArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveLongArray2dJsonDeserializer()'.
   * @return {!PrimitiveLongArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveLongArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveLongArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveLongArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<!$Long>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<List<Long>>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, LongJsonDeserializer.m_getInstance__(), params));
    if (list.isEmpty()) {
      return /**@type {!Array<Array<!$Long>>} */ ($Arrays.$create([0, 0], $long));
    }
    let firstList = /**@type {List<Long>} */ ($Casts.$to(list.getAtIndex(0), List));
    if (firstList.isEmpty()) {
      return /**@type {!Array<Array<!$Long>>} */ ($Arrays.$create([list.size(), 0], $long));
    }
    let array = /**@type {!Array<Array<!$Long>>} */ ($Arrays.$create([list.size(), firstList.size()], $long));
    let i = 0;
    let /** number */ j;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let innerList = /**@type {List<Long>} */ ($Casts.$to($iterator.m_next__(), List));
      j = 0;
      for (let $iterator$1$ = innerList.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
        let value = /**@type {Long} */ ($Casts.$to($iterator$1$.m_next__(), Long));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(array[i], j, value.m_longValue__());
        }
        j++;
      }
      i++;
    }
    return array;
  }
  
  /**
   * @return {PrimitiveLongArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_() {
    return (PrimitiveLongArray2dJsonDeserializer.$clinit(), PrimitiveLongArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveLongArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_(value) {
    (PrimitiveLongArray2dJsonDeserializer.$clinit(), PrimitiveLongArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveLongArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveLongArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveLongArray2dJsonDeserializer.$clinit = function() {};
    Long = goog.module.get('java.lang.Long$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    LongJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.LongJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $long = goog.module.get('vmbootstrap.primitives.$long$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveLongArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_ = PrimitiveLongArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveLongArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveLongArray2dJsonDeserializer'));


/** @private {PrimitiveLongArray2dJsonDeserializer} */
PrimitiveLongArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveLongArray2dJsonDeserializer_;




exports = PrimitiveLongArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveLongArray2dJsonDeserializer.js.map