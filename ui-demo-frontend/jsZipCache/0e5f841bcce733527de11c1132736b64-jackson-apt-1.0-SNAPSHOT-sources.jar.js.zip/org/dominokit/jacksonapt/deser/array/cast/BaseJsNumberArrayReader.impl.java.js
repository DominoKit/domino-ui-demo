/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.core.JsNumber.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
  */
class BaseJsNumberArrayReader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseJsNumberArrayReader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_cast_BaseJsNumberArrayReader__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {JsonReader} reader
   * @return {Array<Number>}
   * @public
   */
  m_readNumberArray__org_dominokit_jacksonapt_stream_JsonReader_$pp_org_dominokit_jacksonapt_deser_array_cast(reader) {
    let jsArray = /**@type {!Array<Number>} */ (new Array());
    reader.m_beginArray__();
    while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      if ($Equality.$same(JsonToken.f_NULL__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
        reader.m_skipValue__();
        jsArray.push(...$InternalPreconditions.m_checkNotNull__java_lang_Object(null));
      } else {
        jsArray.push(/**@type {Number} */ ($Casts.$to(Js.m_cast__java_lang_Object(Integer.m_valueOf__int(reader.m_nextInt__())), $Overlay)));
      }
    }
    reader.m_endArray__();
    return jsArray;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseJsNumberArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseJsNumberArrayReader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseJsNumberArrayReader.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.core.JsNumber.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseJsNumberArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader'));




exports = BaseJsNumberArrayReader; 
//# sourceMappingURL=BaseJsNumberArrayReader.js.map