/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveFloatArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveFloatArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Float = goog.forwardDeclare('java.lang.Float$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let FloatJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.FloatJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $float = goog.forwardDeclare('vmbootstrap.primitives.$float$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<number>>>}
  */
class PrimitiveFloatArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveFloatArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveFloatArray2dJsonDeserializer.$clinit();
    return PrimitiveFloatArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveFloatArray2dJsonDeserializer()'.
   * @return {!PrimitiveFloatArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveFloatArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveFloatArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveFloatArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<number>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<List<Float>>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, FloatJsonDeserializer.m_getInstance__(), params));
    if (list.isEmpty()) {
      return /**@type {!Array<Array<number>>} */ ($Arrays.$create([0, 0], $float));
    }
    let firstList = /**@type {List<Float>} */ ($Casts.$to(list.getAtIndex(0), List));
    if (firstList.isEmpty()) {
      return /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), 0], $float));
    }
    let array = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), firstList.size()], $float));
    let i = 0;
    let /** number */ j;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let innerList = /**@type {List<Float>} */ ($Casts.$to($iterator.m_next__(), List));
      j = 0;
      for (let $iterator$1$ = innerList.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
        let value = /**@type {Float} */ ($Casts.$to($iterator$1$.m_next__(), Float));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(array[i], j, value.m_floatValue__());
        }
        j++;
      }
      i++;
    }
    return array;
  }
  
  /**
   * @return {PrimitiveFloatArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_() {
    return (PrimitiveFloatArray2dJsonDeserializer.$clinit(), PrimitiveFloatArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveFloatArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_(value) {
    (PrimitiveFloatArray2dJsonDeserializer.$clinit(), PrimitiveFloatArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveFloatArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveFloatArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveFloatArray2dJsonDeserializer.$clinit = function() {};
    Float = goog.module.get('java.lang.Float$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    FloatJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.FloatJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $float = goog.module.get('vmbootstrap.primitives.$float$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveFloatArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_ = PrimitiveFloatArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveFloatArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveFloatArray2dJsonDeserializer'));


/** @private {PrimitiveFloatArray2dJsonDeserializer} */
PrimitiveFloatArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveFloatArray2dJsonDeserializer_;




exports = PrimitiveFloatArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveFloatArray2dJsonDeserializer.js.map