/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveFloatArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveFloatArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Float = goog.forwardDeclare('java.lang.Float$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let FloatJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.FloatJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $float = goog.forwardDeclare('vmbootstrap.primitives.$float$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<number>>}
  */
class PrimitiveFloatArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveFloatArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveFloatArrayJsonDeserializer.$clinit();
    return PrimitiveFloatArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveFloatArrayJsonDeserializer()'.
   * @return {!PrimitiveFloatArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveFloatArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveFloatArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveFloatArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<Float>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, FloatJsonDeserializer.m_getInstance__(), params));
    let result = /**@type {!Array<number>} */ ($Arrays.$create([list.size()], $float));
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let value = /**@type {Float} */ ($Casts.$to($iterator.m_next__(), Float));
      if (!$Equality.$same(null, value)) {
        $Arrays.$set(result, i, value.m_floatValue__());
      }
      i++;
    }
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<number>} */ ($Arrays.$init([/**@type {Float} */ ($Casts.$to(FloatJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Float)).m_floatValue__()], $float));
  }
  
  /**
   * @return {PrimitiveFloatArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_() {
    return (PrimitiveFloatArrayJsonDeserializer.$clinit(), PrimitiveFloatArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveFloatArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_(value) {
    (PrimitiveFloatArrayJsonDeserializer.$clinit(), PrimitiveFloatArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveFloatArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveFloatArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveFloatArrayJsonDeserializer.$clinit = function() {};
    Float = goog.module.get('java.lang.Float$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    FloatJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.FloatJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $float = goog.module.get('vmbootstrap.primitives.$float$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveFloatArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_ = PrimitiveFloatArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveFloatArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.PrimitiveFloatArrayJsonDeserializer'));


/** @private {PrimitiveFloatArrayJsonDeserializer} */
PrimitiveFloatArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveFloatArrayJsonDeserializer_;




exports = PrimitiveFloatArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveFloatArrayJsonDeserializer.js.map