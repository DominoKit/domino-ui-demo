/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$ArrayCreator$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ArrayCreator = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator$impl');


/**
 * @template C_ArrayCreator_T
 * @implements {ArrayCreator<C_ArrayCreator_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(number):Array<C_ArrayCreator_T>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(number):Array<C_ArrayCreator_T>} */
    this.f_$$fn__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$LambdaAdaptor__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(number):Array<C_ArrayCreator_T>} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$LambdaAdaptor__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {number} arg0
   * @return {Array<C_ArrayCreator_T>}
   * @public
   */
  m_create__int(arg0) {
    let /** ?function(number):Array<C_ArrayCreator_T> */ $function;
    return ($function = this.f_$$fn__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$ArrayCreator$$LambdaAdaptor'));


ArrayCreator.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ArrayJsonDeserializer$ArrayCreator$$LambdaAdaptor.js.map