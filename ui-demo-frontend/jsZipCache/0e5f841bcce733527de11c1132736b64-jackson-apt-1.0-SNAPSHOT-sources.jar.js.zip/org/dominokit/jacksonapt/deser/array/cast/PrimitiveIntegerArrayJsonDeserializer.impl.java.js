/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.PrimitiveIntegerArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.PrimitiveIntegerArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let IntegerJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $int = goog.forwardDeclare('vmbootstrap.primitives.$int$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<number>>}
  */
class PrimitiveIntegerArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveIntegerArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveIntegerArrayJsonDeserializer.$clinit();
    return PrimitiveIntegerArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveIntegerArrayJsonDeserializer()'.
   * @return {!PrimitiveIntegerArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveIntegerArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveIntegerArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveIntegerArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return JacksonContextProvider.m_get__().m_integerArrayReader__().m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<number>} */ ($Arrays.$init([/**@type {Integer} */ ($Casts.$to(IntegerJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Integer)).m_intValue__()], $int));
  }
  
  /**
   * @return {PrimitiveIntegerArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_() {
    return (PrimitiveIntegerArrayJsonDeserializer.$clinit(), PrimitiveIntegerArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveIntegerArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_(value) {
    (PrimitiveIntegerArrayJsonDeserializer.$clinit(), PrimitiveIntegerArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveIntegerArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveIntegerArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveIntegerArrayJsonDeserializer.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    IntegerJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $int = goog.module.get('vmbootstrap.primitives.$int$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveIntegerArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_ = PrimitiveIntegerArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveIntegerArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.cast.PrimitiveIntegerArrayJsonDeserializer'));


/** @private {PrimitiveIntegerArrayJsonDeserializer} */
PrimitiveIntegerArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_PrimitiveIntegerArrayJsonDeserializer_;




exports = PrimitiveIntegerArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveIntegerArrayJsonDeserializer.js.map