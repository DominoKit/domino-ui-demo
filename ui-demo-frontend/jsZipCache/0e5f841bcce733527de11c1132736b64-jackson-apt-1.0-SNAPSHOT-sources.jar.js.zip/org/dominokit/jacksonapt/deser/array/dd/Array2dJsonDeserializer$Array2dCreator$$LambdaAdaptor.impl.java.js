/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer$Array2dCreator$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.Array2dCreator.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Array2dCreator = goog.require('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.Array2dCreator$impl');


/**
 * @template C_Array2dCreator_T
 * @implements {Array2dCreator<C_Array2dCreator_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(number, number):Array<Array<C_Array2dCreator_T>>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(number, number):Array<Array<C_Array2dCreator_T>>} */
    this.f_$$fn__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$LambdaAdaptor__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(number, number):Array<Array<C_Array2dCreator_T>>} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$LambdaAdaptor__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {number} arg0
   * @param {number} arg1
   * @return {Array<Array<C_Array2dCreator_T>>}
   * @public
   */
  m_create__int__int(arg0, arg1) {
    let /** ?function(number, number):Array<Array<C_Array2dCreator_T>> */ $function;
    return ($function = this.f_$$fn__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator_$LambdaAdaptor, $function(arg0, arg1));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer$Array2dCreator$$LambdaAdaptor'));


Array2dCreator.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Array2dJsonDeserializer$Array2dCreator$$LambdaAdaptor.js.map