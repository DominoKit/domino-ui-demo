/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _$Overlay = goog.require('elemental2.core.JsNumber.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Js = goog.require('jsinterop.base.Js');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BaseJsNumberArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader$impl');
exports = BaseJsNumberArrayReader;
 