/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$LongKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.LongKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let Long = goog.forwardDeclare('java.lang.Long$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<Long>}
  */
class LongKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {LongKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    LongKeyDeserializer.$clinit();
    return LongKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'LongKeyDeserializer()'.
   * @return {!LongKeyDeserializer}
   * @public
   */
  static $create__() {
    LongKeyDeserializer.$clinit();
    let $instance = new LongKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LongKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {Long}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Long.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {LongKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_() {
    return (LongKeyDeserializer.$clinit(), LongKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_);
  }
  
  /**
   * @param {LongKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_(value) {
    (LongKeyDeserializer.$clinit(), LongKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LongKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LongKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LongKeyDeserializer.$clinit = function() {};
    Long = goog.module.get('java.lang.Long$impl');
    BaseNumberKeyDeserializer.$clinit();
    LongKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_ = LongKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(LongKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$LongKeyDeserializer'));


/** @private {LongKeyDeserializer} */
LongKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_LongKeyDeserializer_;




exports = LongKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$LongKeyDeserializer.js.map