/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.DateKeyParser$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.DateKeyParser.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser');
const _Date = goog.require('java.util.Date');
const _DateDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.DateDeserializer');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 