/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BooleanKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BooleanKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {KeyDeserializer<?boolean>}
  */
class BooleanKeyDeserializer extends KeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {BooleanKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    BooleanKeyDeserializer.$clinit();
    return BooleanKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'BooleanKeyDeserializer()'.
   * @return {!BooleanKeyDeserializer}
   * @public
   */
  static $create__() {
    BooleanKeyDeserializer.$clinit();
    let $instance = new BooleanKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BooleanKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {?boolean}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Boolean.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {BooleanKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_() {
    return (BooleanKeyDeserializer.$clinit(), BooleanKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_);
  }
  
  /**
   * @param {BooleanKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_(value) {
    (BooleanKeyDeserializer.$clinit(), BooleanKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BooleanKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BooleanKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BooleanKeyDeserializer.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    KeyDeserializer.$clinit();
    BooleanKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_ = BooleanKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(BooleanKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BooleanKeyDeserializer'));


/** @private {BooleanKeyDeserializer} */
BooleanKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BooleanKeyDeserializer_;




exports = BooleanKeyDeserializer; 
//# sourceMappingURL=BooleanKeyDeserializer.js.map