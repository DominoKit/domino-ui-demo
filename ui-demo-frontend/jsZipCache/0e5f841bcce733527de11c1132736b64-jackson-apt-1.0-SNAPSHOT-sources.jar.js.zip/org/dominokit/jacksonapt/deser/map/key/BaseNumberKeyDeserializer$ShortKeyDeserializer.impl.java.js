/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$ShortKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.ShortKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let Short = goog.forwardDeclare('java.lang.Short$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<Short>}
  */
class ShortKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {ShortKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    ShortKeyDeserializer.$clinit();
    return ShortKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'ShortKeyDeserializer()'.
   * @return {!ShortKeyDeserializer}
   * @public
   */
  static $create__() {
    ShortKeyDeserializer.$clinit();
    let $instance = new ShortKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ShortKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {Short}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Short.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {ShortKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_() {
    return (ShortKeyDeserializer.$clinit(), ShortKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_);
  }
  
  /**
   * @param {ShortKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_(value) {
    (ShortKeyDeserializer.$clinit(), ShortKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ShortKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ShortKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ShortKeyDeserializer.$clinit = function() {};
    Short = goog.module.get('java.lang.Short$impl');
    BaseNumberKeyDeserializer.$clinit();
    ShortKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_ = ShortKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(ShortKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$ShortKeyDeserializer'));


/** @private {ShortKeyDeserializer} */
ShortKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ShortKeyDeserializer_;




exports = ShortKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$ShortKeyDeserializer.js.map