/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.AbstractMapJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.AbstractMapJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer');
const _AbstractMap = goog.require('java.util.AbstractMap');
const _LinkedHashMap = goog.require('java.util.LinkedHashMap');
const _Map = goog.require('java.util.Map');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AbstractMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.AbstractMapJsonDeserializer$impl');
exports = AbstractMapJsonDeserializer;
 