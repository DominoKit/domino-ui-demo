/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$BigDecimalKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.BigDecimalKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let BigDecimal = goog.forwardDeclare('java.math.BigDecimal$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<BigDecimal>}
  */
class BigDecimalKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {BigDecimalKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    BigDecimalKeyDeserializer.$clinit();
    return BigDecimalKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'BigDecimalKeyDeserializer()'.
   * @return {!BigDecimalKeyDeserializer}
   * @public
   */
  static $create__() {
    BigDecimalKeyDeserializer.$clinit();
    let $instance = new BigDecimalKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BigDecimalKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {BigDecimal}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return BigDecimal.$create__java_lang_String(key);
  }
  
  /**
   * @return {BigDecimalKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_() {
    return (BigDecimalKeyDeserializer.$clinit(), BigDecimalKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_);
  }
  
  /**
   * @param {BigDecimalKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_(value) {
    (BigDecimalKeyDeserializer.$clinit(), BigDecimalKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BigDecimalKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BigDecimalKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BigDecimalKeyDeserializer.$clinit = function() {};
    BigDecimal = goog.module.get('java.math.BigDecimal$impl');
    BaseNumberKeyDeserializer.$clinit();
    BigDecimalKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_ = BigDecimalKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(BigDecimalKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$BigDecimalKeyDeserializer'));


/** @private {BigDecimalKeyDeserializer} */
BigDecimalKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigDecimalKeyDeserializer_;




exports = BigDecimalKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$BigDecimalKeyDeserializer.js.map