/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlDateKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlDateKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$impl');

let Date = goog.forwardDeclare('java.sql.Date$impl');
let j_u_Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');


/**
 * @extends {BaseDateKeyDeserializer<Date>}
  */
class SqlDateKeyDeserializer extends BaseDateKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {SqlDateKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    SqlDateKeyDeserializer.$clinit();
    return SqlDateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'SqlDateKeyDeserializer()'.
   * @return {!SqlDateKeyDeserializer}
   * @public
   */
  static $create__() {
    SqlDateKeyDeserializer.$clinit();
    let $instance = new SqlDateKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SqlDateKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @return {Date}
   * @public
   */
  m_deserializeMillis__long(millis) {
    return Date.$create__long(millis);
  }
  
  /**
   * @override
   * @param {j_u_Date} date
   * @return {Date}
   * @public
   */
  m_deserializeDate__java_util_Date(date) {
    return this.m_deserializeMillis__long(date.m_getTime__());
  }
  
  /**
   * @return {SqlDateKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_() {
    return (SqlDateKeyDeserializer.$clinit(), SqlDateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_);
  }
  
  /**
   * @param {SqlDateKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_(value) {
    (SqlDateKeyDeserializer.$clinit(), SqlDateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SqlDateKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SqlDateKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SqlDateKeyDeserializer.$clinit = function() {};
    Date = goog.module.get('java.sql.Date$impl');
    BaseDateKeyDeserializer.$clinit();
    SqlDateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_ = SqlDateKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(SqlDateKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlDateKeyDeserializer'));


/** @private {SqlDateKeyDeserializer} */
SqlDateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlDateKeyDeserializer_;




exports = SqlDateKeyDeserializer; 
//# sourceMappingURL=BaseDateKeyDeserializer$SqlDateKeyDeserializer.js.map