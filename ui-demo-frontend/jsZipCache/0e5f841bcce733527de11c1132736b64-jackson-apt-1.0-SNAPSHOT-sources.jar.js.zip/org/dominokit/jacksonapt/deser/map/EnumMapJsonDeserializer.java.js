/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.EnumMapJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.EnumMapJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Enum = goog.require('java.lang.Enum');
const _EnumMap = goog.require('java.util.EnumMap');
const _Map = goog.require('java.util.Map');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _EnumKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.EnumKeyDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EnumMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.EnumMapJsonDeserializer$impl');
exports = EnumMapJsonDeserializer;
 