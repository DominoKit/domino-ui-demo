/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$BigIntegerKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.BigIntegerKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let BigInteger = goog.forwardDeclare('java.math.BigInteger$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<BigInteger>}
  */
class BigIntegerKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {BigIntegerKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    BigIntegerKeyDeserializer.$clinit();
    return BigIntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'BigIntegerKeyDeserializer()'.
   * @return {!BigIntegerKeyDeserializer}
   * @public
   */
  static $create__() {
    BigIntegerKeyDeserializer.$clinit();
    let $instance = new BigIntegerKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BigIntegerKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {BigInteger}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return BigInteger.$create__java_lang_String(key);
  }
  
  /**
   * @return {BigIntegerKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_() {
    return (BigIntegerKeyDeserializer.$clinit(), BigIntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_);
  }
  
  /**
   * @param {BigIntegerKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_(value) {
    (BigIntegerKeyDeserializer.$clinit(), BigIntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BigIntegerKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BigIntegerKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BigIntegerKeyDeserializer.$clinit = function() {};
    BigInteger = goog.module.get('java.math.BigInteger$impl');
    BaseNumberKeyDeserializer.$clinit();
    BigIntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_ = BigIntegerKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(BigIntegerKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$BigIntegerKeyDeserializer'));


/** @private {BigIntegerKeyDeserializer} */
BigIntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_BigIntegerKeyDeserializer_;




exports = BigIntegerKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$BigIntegerKeyDeserializer.js.map