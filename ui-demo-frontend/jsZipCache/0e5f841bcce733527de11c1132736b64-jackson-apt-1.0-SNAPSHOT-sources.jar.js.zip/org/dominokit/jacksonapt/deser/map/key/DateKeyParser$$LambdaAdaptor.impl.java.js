/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.DateKeyParser$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.DateKeyParser.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let DateDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.DateDeserializer$impl');


/**
 * @template C_D
 * @implements {DateKeyParser<C_D>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string, DateDeserializer<C_D>):C_D} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string, DateDeserializer<C_D>):C_D} */
    this.f_$$fn__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$LambdaAdaptor__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string, DateDeserializer<C_D>):C_D} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$LambdaAdaptor__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @param {DateDeserializer<C_D>} arg1
   * @return {C_D}
   * @public
   */
  m_parse__java_lang_String__org_dominokit_jacksonapt_deser_map_key_DateDeserializer(arg0, arg1) {
    let /** ?function(?string, DateDeserializer<C_D>):C_D */ $function;
    return ($function = this.f_$$fn__org_dominokit_jacksonapt_deser_map_key_DateKeyParser_$LambdaAdaptor, $function(arg0, arg1));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$$LambdaAdaptor'));


DateKeyParser.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DateKeyParser$$LambdaAdaptor.js.map