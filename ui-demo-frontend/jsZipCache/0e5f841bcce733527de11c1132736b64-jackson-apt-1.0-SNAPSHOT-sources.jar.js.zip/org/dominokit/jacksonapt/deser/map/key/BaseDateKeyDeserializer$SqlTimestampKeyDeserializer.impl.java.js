/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlTimestampKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlTimestampKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$impl');

let Timestamp = goog.forwardDeclare('java.sql.Timestamp$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');


/**
 * @extends {BaseDateKeyDeserializer<Timestamp>}
  */
class SqlTimestampKeyDeserializer extends BaseDateKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {SqlTimestampKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    SqlTimestampKeyDeserializer.$clinit();
    return SqlTimestampKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'SqlTimestampKeyDeserializer()'.
   * @return {!SqlTimestampKeyDeserializer}
   * @public
   */
  static $create__() {
    SqlTimestampKeyDeserializer.$clinit();
    let $instance = new SqlTimestampKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SqlTimestampKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @return {Timestamp}
   * @public
   */
  m_deserializeMillis__long(millis) {
    return Timestamp.$create__long(millis);
  }
  
  /**
   * @override
   * @param {Date} date
   * @return {Timestamp}
   * @public
   */
  m_deserializeDate__java_util_Date(date) {
    return this.m_deserializeMillis__long(date.m_getTime__());
  }
  
  /**
   * @return {SqlTimestampKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_() {
    return (SqlTimestampKeyDeserializer.$clinit(), SqlTimestampKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_);
  }
  
  /**
   * @param {SqlTimestampKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_(value) {
    (SqlTimestampKeyDeserializer.$clinit(), SqlTimestampKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SqlTimestampKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SqlTimestampKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SqlTimestampKeyDeserializer.$clinit = function() {};
    Timestamp = goog.module.get('java.sql.Timestamp$impl');
    BaseDateKeyDeserializer.$clinit();
    SqlTimestampKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_ = SqlTimestampKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(SqlTimestampKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlTimestampKeyDeserializer'));


/** @private {SqlTimestampKeyDeserializer} */
SqlTimestampKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimestampKeyDeserializer_;




exports = SqlTimestampKeyDeserializer; 
//# sourceMappingURL=BaseDateKeyDeserializer$SqlTimestampKeyDeserializer.js.map