/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.DateDeserializer$impl');
const KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let DateKeyParser = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_D
 * @extends {KeyDeserializer<C_D>}
 * @implements {DateDeserializer<C_D>}
  */
class BaseDateKeyDeserializer extends KeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseDateKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {C_D}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return (/**@type {DateKeyParser<C_D>} */ ($Casts.$to(JacksonContextProvider.m_get__().m_dateFormat__().m_makeDateKeyParser__(), DateKeyParser))).m_parse__java_lang_String__org_dominokit_jacksonapt_deser_map_key_DateDeserializer(key, this);
  }
  
  /**
   * @abstract
   * @override
   * @param {Date} arg0
   * @return {C_D}
   * @public
   */
  m_deserializeDate__java_util_Date(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {!$Long} arg0
   * @return {C_D}
   * @public
   */
  m_deserializeMillis__long(arg0) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseDateKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseDateKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseDateKeyDeserializer.$clinit = function() {};
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    DateKeyParser = goog.module.get('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    KeyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseDateKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer'));


DateDeserializer.$markImplementor(BaseDateKeyDeserializer);


exports = BaseDateKeyDeserializer; 
//# sourceMappingURL=BaseDateKeyDeserializer.js.map