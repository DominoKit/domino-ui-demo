/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.DateKeyParser.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let DateDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.DateDeserializer$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.DateKeyParser.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_D
 */
class DateKeyParser {
  /**
   * @abstract
   * @param {?string} keyValue
   * @param {DateDeserializer<C_D>} deserializer
   * @return {C_D}
   * @public
   */
  m_parse__java_lang_String__org_dominokit_jacksonapt_deser_map_key_DateDeserializer(keyValue, deserializer) {
  }
  
  /**
   * @template C_D
   * @param {?function(?string, DateDeserializer<C_D>):C_D} fn
   * @return {DateKeyParser<C_D>}
   * @public
   */
  static $adapt(fn) {
    DateKeyParser.$clinit();
    return /**@type {!$LambdaAdaptor<Date>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_map_key_DateKeyParser = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_map_key_DateKeyParser;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_map_key_DateKeyParser;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateKeyParser.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.deser.map.key.DateKeyParser.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DateKeyParser, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.DateKeyParser'));


DateKeyParser.$markImplementor(/** @type {Function} */ (DateKeyParser));


exports = DateKeyParser; 
//# sourceMappingURL=DateKeyParser.js.map