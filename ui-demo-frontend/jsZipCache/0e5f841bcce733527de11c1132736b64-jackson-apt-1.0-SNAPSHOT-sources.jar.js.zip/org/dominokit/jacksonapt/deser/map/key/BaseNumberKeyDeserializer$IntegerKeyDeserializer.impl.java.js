/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$IntegerKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.IntegerKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<Integer>}
  */
class IntegerKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {IntegerKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    IntegerKeyDeserializer.$clinit();
    return IntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'IntegerKeyDeserializer()'.
   * @return {!IntegerKeyDeserializer}
   * @public
   */
  static $create__() {
    IntegerKeyDeserializer.$clinit();
    let $instance = new IntegerKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IntegerKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {Integer}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Integer.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {IntegerKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_() {
    return (IntegerKeyDeserializer.$clinit(), IntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_);
  }
  
  /**
   * @param {IntegerKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_(value) {
    (IntegerKeyDeserializer.$clinit(), IntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IntegerKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IntegerKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IntegerKeyDeserializer.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    BaseNumberKeyDeserializer.$clinit();
    IntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_ = IntegerKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(IntegerKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$IntegerKeyDeserializer'));


/** @private {IntegerKeyDeserializer} */
IntegerKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_IntegerKeyDeserializer_;




exports = IntegerKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$IntegerKeyDeserializer.js.map