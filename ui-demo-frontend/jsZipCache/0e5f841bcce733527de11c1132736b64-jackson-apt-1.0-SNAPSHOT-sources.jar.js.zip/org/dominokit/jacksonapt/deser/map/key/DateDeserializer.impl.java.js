/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.DateDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.DateDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');


/**
 * @interface
 * @template C_D
 */
class DateDeserializer {
  /**
   * @abstract
   * @param {!$Long} millis
   * @return {C_D}
   * @public
   */
  m_deserializeMillis__long(millis) {
  }
  
  /**
   * @abstract
   * @param {Date} date
   * @return {C_D}
   * @public
   */
  m_deserializeDate__java_util_Date(date) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_map_key_DateDeserializer = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_map_key_DateDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_map_key_DateDeserializer;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateDeserializer.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(DateDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.DateDeserializer'));


DateDeserializer.$markImplementor(/** @type {Function} */ (DateDeserializer));


exports = DateDeserializer; 
//# sourceMappingURL=DateDeserializer.js.map