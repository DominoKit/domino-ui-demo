/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.TreeMapJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.TreeMapJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let TreeMap = goog.forwardDeclare('java.util.TreeMap$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let KeyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_K, C_V
 * @extends {BaseMapJsonDeserializer<TreeMap<C_K, C_V>, C_K, C_V>}
  */
class TreeMapJsonDeserializer extends BaseMapJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_K, M_V
   * @param {KeyDeserializer<M_K>} keyDeserializer
   * @param {JsonDeserializer<M_V>} valueDeserializer
   * @return {TreeMapJsonDeserializer<M_K, M_V>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    TreeMapJsonDeserializer.$clinit();
    return /**@type {!TreeMapJsonDeserializer<*, *>} */ (TreeMapJsonDeserializer.$create__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'TreeMapJsonDeserializer(KeyDeserializer, JsonDeserializer)'.
   * @template C_K, C_V
   * @param {KeyDeserializer<C_K>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {!TreeMapJsonDeserializer<C_K, C_V>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    TreeMapJsonDeserializer.$clinit();
    let $instance = new TreeMapJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_TreeMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TreeMapJsonDeserializer(KeyDeserializer, JsonDeserializer)'.
   * @param {KeyDeserializer<C_K>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_TreeMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer);
  }
  
  /**
   * @override
   * @return {TreeMap<C_K, C_V>}
   * @public
   */
  m_newMap__() {
    return /**@type {!TreeMap<C_K, C_V>} */ (TreeMap.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Map} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {TreeMap<C_K, C_V>} */ ($Casts.$to(arg2, TreeMap)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {TreeMap<C_K, C_V>} */ ($Casts.$to(arg2, TreeMap)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TreeMapJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TreeMapJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TreeMapJsonDeserializer.$clinit = function() {};
    TreeMap = goog.module.get('java.util.TreeMap$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseMapJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TreeMapJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.TreeMapJsonDeserializer'));




exports = TreeMapJsonDeserializer; 
//# sourceMappingURL=TreeMapJsonDeserializer.js.map