/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonSerializationContext$Builder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let DefaultJsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonSerializationContext$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');


class Builder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    /** @public {boolean} */
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Builder()'.
   * @return {!Builder}
   * @public
   */
  static $create__() {
    Builder.$clinit();
    let $instance = new Builder();
    $instance.$ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Builder()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder();
  }
  
  /**
   * @param {boolean} useEqualityForObjectId
   * @return {Builder}
   * @public
   */
  m_useEqualityForObjectId__boolean(useEqualityForObjectId) {
    this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = useEqualityForObjectId;
    return this;
  }
  
  /**
   * @param {boolean} serializeNulls
   * @return {Builder}
   * @public
   */
  m_serializeNulls__boolean(serializeNulls) {
    this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = serializeNulls;
    return this;
  }
  
  /**
   * @param {boolean} writeDatesAsTimestamps
   * @return {Builder}
   * @public
   */
  m_writeDatesAsTimestamps__boolean(writeDatesAsTimestamps) {
    this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = writeDatesAsTimestamps;
    return this;
  }
  
  /**
   * @param {boolean} writeDateKeysAsTimestamps
   * @return {Builder}
   * @public
   */
  m_writeDateKeysAsTimestamps__boolean(writeDateKeysAsTimestamps) {
    this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = writeDateKeysAsTimestamps;
    return this;
  }
  
  /**
   * @param {boolean} indent
   * @return {Builder}
   * @public
   */
  m_indent__boolean(indent) {
    this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = indent;
    return this;
  }
  
  /**
   * @param {boolean} wrapRootValue
   * @return {Builder}
   * @public
   */
  m_wrapRootValue__boolean(wrapRootValue) {
    this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = wrapRootValue;
    return this;
  }
  
  /**
   * @param {boolean} writeCharArraysAsJsonArrays
   * @return {Builder}
   * @public
   */
  m_writeCharArraysAsJsonArrays__boolean(writeCharArraysAsJsonArrays) {
    this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = writeCharArraysAsJsonArrays;
    return this;
  }
  
  /**
   * @param {boolean} writeNullMapValues
   * @return {Builder}
   * @public
   */
  m_writeNullMapValues__boolean(writeNullMapValues) {
    this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = writeNullMapValues;
    return this;
  }
  
  /**
   * @param {boolean} writeEmptyJsonArrays
   * @return {Builder}
   * @public
   */
  m_writeEmptyJsonArrays__boolean(writeEmptyJsonArrays) {
    this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = writeEmptyJsonArrays;
    return this;
  }
  
  /**
   * @param {boolean} orderMapEntriesByKeys
   * @return {Builder}
   * @public
   */
  m_orderMapEntriesByKeys__boolean(orderMapEntriesByKeys) {
    this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = orderMapEntriesByKeys;
    return this;
  }
  
  /**
   * @param {boolean} writeSingleElemArraysUnwrapped
   * @return {Builder}
   * @public
   */
  m_writeSingleElemArraysUnwrapped__boolean(writeSingleElemArraysUnwrapped) {
    this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = writeSingleElemArraysUnwrapped;
    return this;
  }
  
  /**
   * @param {boolean} wrapExceptions
   * @return {Builder}
   * @public
   */
  m_wrapExceptions__boolean(wrapExceptions) {
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = wrapExceptions;
    return this;
  }
  
  /**
   * @return {JsonSerializationContext}
   * @public
   */
  m_build__() {
    return DefaultJsonSerializationContext.$create__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean(this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder, this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder() {
    this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = true;
    this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = true;
    this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = true;
    this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = true;
    this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = false;
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Builder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Builder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Builder.$clinit = function() {};
    DefaultJsonSerializationContext = goog.module.get('org.dominokit.jacksonapt.DefaultJsonSerializationContext$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Builder, $Util.$makeClassName('org.dominokit.jacksonapt.DefaultJsonSerializationContext$Builder'));




exports = Builder; 
//# sourceMappingURL=DefaultJsonSerializationContext$Builder.js.map