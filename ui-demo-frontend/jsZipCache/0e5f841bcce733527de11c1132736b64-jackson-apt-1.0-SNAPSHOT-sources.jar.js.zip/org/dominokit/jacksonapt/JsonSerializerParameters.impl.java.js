/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonSerializerParameters.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonSerializerParameters$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Shape = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');
let Include = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let IdentitySerializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.IdentitySerializationInfo$impl');
let TypeSerializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.TypeSerializationInfo$impl');


/**
 * @interface
 */
class JsonSerializerParameters {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getPattern__() {
  }
  
  /**
   * @abstract
   * @param {?string} pattern
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setPattern__java_lang_String(pattern) {
  }
  
  /**
   * @abstract
   * @return {Shape}
   * @public
   */
  m_getShape__() {
  }
  
  /**
   * @abstract
   * @param {Shape} shape
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setShape__com_fasterxml_jackson_annotation_JsonFormat_Shape(shape) {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getLocale__() {
  }
  
  /**
   * @abstract
   * @param {?string} locale
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setLocale__java_lang_String(locale) {
  }
  
  /**
   * @abstract
   * @return {*}
   * @public
   */
  m_getTimezone__() {
  }
  
  /**
   * @abstract
   * @param {*} timezone
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setTimezone__java_lang_Object(timezone) {
  }
  
  /**
   * @abstract
   * @return {Set<?string>}
   * @public
   */
  m_getIgnoredProperties__() {
  }
  
  /**
   * @abstract
   * @param {?string} ignoredProperty
   * @return {JsonSerializerParameters}
   * @public
   */
  m_addIgnoredProperty__java_lang_String(ignoredProperty) {
  }
  
  /**
   * @abstract
   * @return {Include}
   * @public
   */
  m_getInclude__() {
  }
  
  /**
   * @abstract
   * @param {Include} include
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setInclude__com_fasterxml_jackson_annotation_JsonInclude_Include(include) {
  }
  
  /**
   * @abstract
   * @return {IdentitySerializationInfo}
   * @public
   */
  m_getIdentityInfo__() {
  }
  
  /**
   * @abstract
   * @param {IdentitySerializationInfo} identityInfo
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setIdentityInfo__org_dominokit_jacksonapt_ser_bean_IdentitySerializationInfo(identityInfo) {
  }
  
  /**
   * @abstract
   * @return {TypeSerializationInfo}
   * @public
   */
  m_getTypeInfo__() {
  }
  
  /**
   * @abstract
   * @param {TypeSerializationInfo} typeInfo
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setTypeInfo__org_dominokit_jacksonapt_ser_bean_TypeSerializationInfo(typeInfo) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isUnwrapped__() {
  }
  
  /**
   * @abstract
   * @param {boolean} unwrapped
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setUnwrapped__boolean(unwrapped) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonSerializerParameters = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JsonSerializerParameters;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonSerializerParameters;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonSerializerParameters.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonSerializerParameters, $Util.$makeClassName('org.dominokit.jacksonapt.JsonSerializerParameters'));


JsonSerializerParameters.$markImplementor(/** @type {Function} */ (JsonSerializerParameters));


exports = JsonSerializerParameters; 
//# sourceMappingURL=JsonSerializerParameters.js.map