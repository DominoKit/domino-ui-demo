/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.annotation.JSONReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.annotation.JSONReader$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.annotation.JSONReader.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JSONReader {
  /**
   * @param {?function():Class<?>} fn
   * @return {JSONReader}
   * @public
   */
  static $adapt(fn) {
    JSONReader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONReader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_annotation_JSONReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONReader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JSONReader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.annotation.JSONReader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JSONReader, $Util.$makeClassName('org.dominokit.jacksonapt.annotation.JSONReader'));


JSONReader.$markImplementor(/** @type {Function} */ (JSONReader));


exports = JSONReader; 
//# sourceMappingURL=JSONReader.js.map