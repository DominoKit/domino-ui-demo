/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.annotation.JSONMapper$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.annotation.JSONMapper.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const JSONMapper = goog.require('org.dominokit.jacksonapt.annotation.JSONMapper$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Annotation = goog.forwardDeclare('java.lang.annotation.Annotation$impl');


/**
 * @implements {JSONMapper}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Class<?>} */
    this.f_$$fn__org_dominokit_jacksonapt_annotation_JSONMapper_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_annotation_JSONMapper_$LambdaAdaptor__org_dominokit_jacksonapt_annotation_JSONMapper_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_annotation_JSONMapper_$LambdaAdaptor__org_dominokit_jacksonapt_annotation_JSONMapper_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_annotation_JSONMapper_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Class<?>}
   * @public
   */
  m_annotationType__() {
    let /** ?function():Class<?> */ $function;
    return ($function = this.f_$$fn__org_dominokit_jacksonapt_annotation_JSONMapper_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.annotation.JSONMapper$$LambdaAdaptor'));


JSONMapper.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=JSONMapper$$LambdaAdaptor.js.map