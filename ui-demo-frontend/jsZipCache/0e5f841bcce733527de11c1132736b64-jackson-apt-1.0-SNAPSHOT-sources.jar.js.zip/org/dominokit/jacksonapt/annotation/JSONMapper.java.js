/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.annotation.JSONMapper.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.annotation.JSONMapper');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.annotation.JSONMapper.$LambdaAdaptor');


// Re-exports the implementation.
var JSONMapper = goog.require('org.dominokit.jacksonapt.annotation.JSONMapper$impl');
exports = JSONMapper;
 