/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonDeserializerParameters.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JsonDeserializerParameters');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Shape = goog.require('com.fasterxml.jackson.annotation.JsonFormat.Shape');
const _Set = goog.require('java.util.Set');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _TypeDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo');


// Re-exports the implementation.
var JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
exports = JsonDeserializerParameters;
 