/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$MapLikeFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory.$LambdaAdaptor$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @interface
 */
class MapLikeFactory {
  /**
   * @abstract
   * @template M_MapLikeFactory_make_T
   * @return {MapLike<M_MapLikeFactory_make_T>}
   * @public
   */
  m_make__() {
  }
  
  /**
   * @template M_MapLikeFactory_make_T
   * @param {?function():MapLike<M_MapLikeFactory_make_T>} fn
   * @return {MapLikeFactory}
   * @public
   */
  static $adapt(fn) {
    MapLikeFactory.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_MapLikeFactory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_MapLikeFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_MapLikeFactory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MapLikeFactory.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MapLikeFactory, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$MapLikeFactory'));


MapLikeFactory.$markImplementor(/** @type {Function} */ (MapLikeFactory));


exports = MapLikeFactory; 
//# sourceMappingURL=JacksonContext$MapLikeFactory.js.map