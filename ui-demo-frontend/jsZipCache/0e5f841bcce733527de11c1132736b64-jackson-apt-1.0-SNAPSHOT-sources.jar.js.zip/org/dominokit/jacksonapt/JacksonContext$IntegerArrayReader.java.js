/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$IntegerArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader.$LambdaAdaptor');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var IntegerArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader$impl');
exports = IntegerArrayReader;
 