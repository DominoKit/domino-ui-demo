/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$ValueStringifier$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.ValueStringifier.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ValueStringifier = goog.require('org.dominokit.jacksonapt.JacksonContext.ValueStringifier');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JacksonContext.ValueStringifier.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 