/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$ShortArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader.$LambdaAdaptor');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var ShortArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader$impl');
exports = ShortArrayReader;
 