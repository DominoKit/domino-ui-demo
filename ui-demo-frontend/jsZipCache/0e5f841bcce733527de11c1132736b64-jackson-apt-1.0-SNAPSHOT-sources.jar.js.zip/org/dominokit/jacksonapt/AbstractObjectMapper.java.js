/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.AbstractObjectMapper.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.AbstractObjectMapper');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ObjectMapper = goog.require('org.dominokit.jacksonapt.ObjectMapper');
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _DefaultJsonDeserializationContext = goog.require('org.dominokit.jacksonapt.DefaultJsonDeserializationContext');
const _DefaultJsonSerializationContext = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _ArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer');
const _ArrayCreator = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator');
const _JsonDeserializationException = goog.require('org.dominokit.jacksonapt.exception.JsonDeserializationException');
const _JsonSerializationException = goog.require('org.dominokit.jacksonapt.exception.JsonSerializationException');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper$impl');
exports = AbstractObjectMapper;
 