/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonDeserializationContext$Builder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.Builder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let DefaultJsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


class Builder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    /** @public {boolean} */
    this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    /** @public {boolean} */
    this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    /** @public {boolean} */
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    /** @public {boolean} */
    this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    /** @public {boolean} */
    this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    /** @public {boolean} */
    this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Builder()'.
   * @return {!Builder}
   * @public
   */
  static $create__() {
    Builder.$clinit();
    let $instance = new Builder();
    $instance.$ctor__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Builder()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder();
  }
  
  /**
   * @param {boolean} failOnUnknownProperties
   * @return {Builder}
   * @public
   */
  m_failOnUnknownProperties__boolean(failOnUnknownProperties) {
    this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = failOnUnknownProperties;
    return this;
  }
  
  /**
   * @param {boolean} unwrapRootValue
   * @return {Builder}
   * @public
   */
  m_unwrapRootValue__boolean(unwrapRootValue) {
    this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = unwrapRootValue;
    return this;
  }
  
  /**
   * @param {boolean} acceptSingleValueAsArray
   * @return {Builder}
   * @public
   */
  m_acceptSingleValueAsArray__boolean(acceptSingleValueAsArray) {
    this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = acceptSingleValueAsArray;
    return this;
  }
  
  /**
   * @param {boolean} wrapExceptions
   * @return {Builder}
   * @public
   */
  m_wrapExceptions__boolean(wrapExceptions) {
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = wrapExceptions;
    return this;
  }
  
  /**
   * @param {boolean} useSafeEval
   * @return {Builder}
   * @public
   */
  m_useSafeEval__boolean(useSafeEval) {
    this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = useSafeEval;
    return this;
  }
  
  /**
   * @param {boolean} readUnknownEnumValuesAsNull
   * @return {Builder}
   * @public
   */
  m_readUnknownEnumValuesAsNull__boolean(readUnknownEnumValuesAsNull) {
    this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = readUnknownEnumValuesAsNull;
    return this;
  }
  
  /**
   * @param {boolean} useBrowserTimezone
   * @return {Builder}
   * @public
   */
  m_useBrowserTimezone__boolean(useBrowserTimezone) {
    this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = useBrowserTimezone;
    return this;
  }
  
  /**
   * @return {JsonDeserializationContext}
   * @public
   */
  m_build__() {
    return DefaultJsonDeserializationContext.$create__boolean__boolean__boolean__boolean__boolean__boolean__boolean(this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder, this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder, this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder, this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder, this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder, this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder, this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder() {
    this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = true;
    this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = true;
    this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = true;
    this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
    this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_Builder = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Builder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Builder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Builder.$clinit = function() {};
    DefaultJsonDeserializationContext = goog.module.get('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Builder, $Util.$makeClassName('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$Builder'));




exports = Builder; 
//# sourceMappingURL=DefaultJsonDeserializationContext$Builder.js.map