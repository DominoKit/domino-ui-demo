package org.dominokit.jacksonapt;

                                                                          
                                                                           
                                                                         
                                                                          
                                                          
                                                                
                                                        


/**
 * <p>ServerJacksonContext class.</p>
 *
 * @author vegegoku
 * @version $Id: $Id
 */
public class ServerJacksonContext extends JsJacksonContext{

                    
                                                                                           

                        
                    
             
                                    
                                       
     

                        
                    
             
                                                      
                                        
     

                        
                    
             
                                            
                                   
     

                        
                    
             
                                           
                                 
     

                        
                    
             
                                                  
                                              
     

                        
                    
             
                                                
                                             
     

                        
                    
             
                                                    
                                               
     

                        
                    
             
                                                  
                                              
     

                        
                    
             
                                                                   
                                                             
     

                        
                    
             
                                                                       
                                                               
     

}
