/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.AbstractObjectMapper.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.AbstractObjectMapper$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ObjectMapper = goog.require('org.dominokit.jacksonapt.ObjectMapper$impl');

let RuntimeException = goog.forwardDeclare('java.lang.RuntimeException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let DefaultJsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$impl');
let DefaultJsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonSerializationContext$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let ArrayJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$impl');
let ArrayCreator = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator$impl');
let JsonDeserializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
let JsonSerializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonSerializationException$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_T
 * @implements {ObjectMapper<C_T>}
  */
class AbstractObjectMapper extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_rootName__org_dominokit_jacksonapt_AbstractObjectMapper_;
    /** @public {JsonDeserializer<C_T>} */
    this.f_deserializer__org_dominokit_jacksonapt_AbstractObjectMapper_;
    /** @public {JsonSerializer<C_T>} */
    this.f_serializer__org_dominokit_jacksonapt_AbstractObjectMapper_;
  }
  
  /**
   * Initialization from constructor 'AbstractObjectMapper(String)'.
   * @param {?string} rootName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_AbstractObjectMapper__java_lang_String(rootName) {
    this.$ctor__java_lang_Object__();
    this.f_rootName__org_dominokit_jacksonapt_AbstractObjectMapper_ = rootName;
  }
  
  /**
   * @override
   * @param {?string} in$1$
   * @return {C_T}
   * @public
   */
  m_read__java_lang_String(in$1$) {
    return this.m_read__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(in$1$, DefaultJsonDeserializationContext.m_builder__().m_build__());
  }
  
  /**
   * @override
   * @param {?string} in$1$
   * @param {JsonDeserializationContext} ctx
   * @return {C_T}
   * @public
   */
  m_read__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(in$1$, ctx) {
    let reader = ctx.m_newJsonReader__java_lang_String(in$1$);
    try {
      if (ctx.m_isUnwrapRootValue__()) {
        if (!$Equality.$same(JsonToken.f_BEGIN_OBJECT__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
          throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Unwrap root value is enabled but the input is not a JSON Object", reader));
        }
        reader.m_beginObject__();
        if ($Equality.$same(JsonToken.f_END_OBJECT__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
          throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Unwrap root value is enabled but the JSON Object is empty", reader));
        }
        let name = reader.m_nextName__();
        if (!j_l_String.m_equals__java_lang_String__java_lang_Object(name, this.f_rootName__org_dominokit_jacksonapt_AbstractObjectMapper_)) {
          throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Unwrap root value is enabled but the name '" + j_l_String.m_valueOf__java_lang_Object(name) + "' don't match the expected rootName " + "'" + j_l_String.m_valueOf__java_lang_Object(this.f_rootName__org_dominokit_jacksonapt_AbstractObjectMapper_) + "'", reader));
        }
        let result = this.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx);
        reader.m_endObject__();
        return result;
      } else {
        return this.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx);
      }
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (JsonDeserializationException.$isInstance(__$exc)) {
        let e = /**@type {JsonDeserializationException} */ (__$exc);
        throw $Exceptions.toJs(e);
      } else if (RuntimeException.$isInstance(__$exc)) {
        let e$1$ = /**@type {RuntimeException} */ (__$exc);
        throw $Exceptions.toJs(ctx.m_traceError__java_lang_RuntimeException__org_dominokit_jacksonapt_stream_JsonReader(e$1$, reader));
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @override
   * @param {?string} input
   * @param {ArrayCreator<C_T>} arrayCreator
   * @return {Array<C_T>}
   * @public
   */
  m_readArray__java_lang_String__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(input, arrayCreator) {
    return this.m_readArray__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(input, DefaultJsonDeserializationContext.m_builder__().m_build__(), arrayCreator);
  }
  
  /**
   * @override
   * @param {?string} input
   * @param {JsonDeserializationContext} ctx
   * @param {ArrayCreator<C_T>} arrayCreator
   * @return {Array<C_T>}
   * @public
   */
  m_readArray__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(input, ctx, arrayCreator) {
    let jsonDeserializer = /**@type {ArrayJsonDeserializer<C_T>} */ (ArrayJsonDeserializer.m_newInstance__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(this.m_getDeserializer__(), arrayCreator));
    return /**@type {Array<C_T>} */ ($Arrays.$castTo(jsonDeserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(ctx.m_newJsonReader__java_lang_String(input), ctx), j_l_Object, 1));
  }
  
  /**
   * @override
   * @return {JsonDeserializer<C_T>}
   * @public
   */
  m_getDeserializer__() {
    if ($Equality.$same(null, this.f_deserializer__org_dominokit_jacksonapt_AbstractObjectMapper_)) {
      this.f_deserializer__org_dominokit_jacksonapt_AbstractObjectMapper_ = this.m_newDeserializer__();
    }
    return this.f_deserializer__org_dominokit_jacksonapt_AbstractObjectMapper_;
  }
  
  /**
   * @abstract
   * @return {JsonDeserializer<C_T>}
   * @public
   */
  m_newDeserializer__() {
  }
  
  /**
   * @override
   * @param {C_T} value
   * @return {?string}
   * @public
   */
  m_write__java_lang_Object(value) {
    return this.m_write__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(value, DefaultJsonSerializationContext.m_builder__().m_build__());
  }
  
  /**
   * @override
   * @param {C_T} value
   * @param {JsonSerializationContext} ctx
   * @return {?string}
   * @public
   */
  m_write__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(value, ctx) {
    let writer = ctx.m_newJsonWriter__();
    try {
      if (ctx.m_isWrapRootValue__()) {
        writer.m_beginObject__();
        writer.m_name__java_lang_String(this.f_rootName__org_dominokit_jacksonapt_AbstractObjectMapper_);
        this.m_getSerializer__().m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(writer, value, ctx);
        writer.m_endObject__();
      } else {
        this.m_getSerializer__().m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(writer, value, ctx);
      }
      return writer.m_getOutput__();
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (JsonSerializationException.$isInstance(__$exc)) {
        let e = /**@type {JsonSerializationException} */ (__$exc);
        throw $Exceptions.toJs(e);
      } else if (RuntimeException.$isInstance(__$exc)) {
        let e$1$ = /**@type {RuntimeException} */ (__$exc);
        throw $Exceptions.toJs(ctx.m_traceError__java_lang_Object__java_lang_RuntimeException__org_dominokit_jacksonapt_stream_JsonWriter(value, e$1$, writer));
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @override
   * @return {JsonSerializer<C_T>}
   * @public
   */
  m_getSerializer__() {
    if ($Equality.$same(null, this.f_serializer__org_dominokit_jacksonapt_AbstractObjectMapper_)) {
      this.f_serializer__org_dominokit_jacksonapt_AbstractObjectMapper_ = /**@type {JsonSerializer<C_T>} */ ($Casts.$to(this.m_newSerializer__(), JsonSerializer));
    }
    return this.f_serializer__org_dominokit_jacksonapt_AbstractObjectMapper_;
  }
  
  /**
   * @abstract
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractObjectMapper;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractObjectMapper);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractObjectMapper.$clinit = function() {};
    RuntimeException = goog.module.get('java.lang.RuntimeException$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    DefaultJsonDeserializationContext = goog.module.get('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$impl');
    DefaultJsonSerializationContext = goog.module.get('org.dominokit.jacksonapt.DefaultJsonSerializationContext$impl');
    JsonSerializer = goog.module.get('org.dominokit.jacksonapt.JsonSerializer$impl');
    ArrayJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$impl');
    JsonDeserializationException = goog.module.get('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
    JsonSerializationException = goog.module.get('org.dominokit.jacksonapt.exception.JsonSerializationException$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractObjectMapper, $Util.$makeClassName('org.dominokit.jacksonapt.AbstractObjectMapper'));


ObjectMapper.$markImplementor(AbstractObjectMapper);


exports = AbstractObjectMapper; 
//# sourceMappingURL=AbstractObjectMapper.js.map