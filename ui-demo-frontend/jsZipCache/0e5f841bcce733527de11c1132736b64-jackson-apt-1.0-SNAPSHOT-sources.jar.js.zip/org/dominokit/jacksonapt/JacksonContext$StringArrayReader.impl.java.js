/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$StringArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.StringArrayReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.StringArrayReader.$LambdaAdaptor$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 */
class StringArrayReader {
  /**
   * @abstract
   * @param {JsonReader} reader
   * @return {Array<?string>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
  }
  
  /**
   * @param {?function(JsonReader):Array<?string>} fn
   * @return {StringArrayReader}
   * @public
   */
  static $adapt(fn) {
    StringArrayReader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_StringArrayReader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_StringArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_StringArrayReader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    StringArrayReader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.StringArrayReader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(StringArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$StringArrayReader'));


StringArrayReader.$markImplementor(/** @type {Function} */ (StringArrayReader));


exports = StringArrayReader; 
//# sourceMappingURL=JacksonContext$StringArrayReader.js.map