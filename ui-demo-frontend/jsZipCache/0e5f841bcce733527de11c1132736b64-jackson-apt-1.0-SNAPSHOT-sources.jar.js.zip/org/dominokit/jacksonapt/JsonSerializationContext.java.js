/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonSerializationContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JsonSerializationContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonMappingContext = goog.require('org.dominokit.jacksonapt.JsonMappingContext');
const _ObjectIdGenerator = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator');
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters');
const _JsonSerializationException = goog.require('org.dominokit.jacksonapt.exception.JsonSerializationException');
const _ObjectIdSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.ObjectIdSerializer');
const _JsonWriter = goog.require('org.dominokit.jacksonapt.stream.JsonWriter');


// Re-exports the implementation.
var JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext$impl');
exports = JsonSerializationContext;
 