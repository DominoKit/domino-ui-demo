/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$IntegerStackFactory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Integer = goog.require('java.lang.Integer');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory.$LambdaAdaptor');
const _Stack = goog.require('org.dominokit.jacksonapt.stream.Stack');


// Re-exports the implementation.
var IntegerStackFactory = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory$impl');
exports = IntegerStackFactory;
 