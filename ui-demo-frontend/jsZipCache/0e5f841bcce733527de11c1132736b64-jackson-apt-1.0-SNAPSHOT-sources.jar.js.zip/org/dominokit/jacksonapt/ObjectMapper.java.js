/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.ObjectMapper.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.ObjectMapper');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ObjectReader = goog.require('org.dominokit.jacksonapt.ObjectReader');
const _ObjectWriter = goog.require('org.dominokit.jacksonapt.ObjectWriter');


// Re-exports the implementation.
var ObjectMapper = goog.require('org.dominokit.jacksonapt.ObjectMapper$impl');
exports = ObjectMapper;
 