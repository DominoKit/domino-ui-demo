/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.contributions.ThumbnailsPresenterContributionToComponentsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.thumbnails.client.contributions.ThumbnailsPresenterContributionToComponentsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let ThumbnailsPresenter = goog.forwardDeclare('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter$impl');
let ThumbnailsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentsExtensionPoint>}
  */
class ThumbnailsPresenterContributionToComponentsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThumbnailsPresenterContributionToComponentsExtensionPoint()'.
   * @return {!ThumbnailsPresenterContributionToComponentsExtensionPoint}
   * @public
   */
  static $create__() {
    ThumbnailsPresenterContributionToComponentsExtensionPoint.$clinit();
    let $instance = new ThumbnailsPresenterContributionToComponentsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_thumbnails_client_contributions_ThumbnailsPresenterContributionToComponentsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThumbnailsPresenterContributionToComponentsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_thumbnails_client_contributions_ThumbnailsPresenterContributionToComponentsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(extensionPoint) {
    ThumbnailsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ThumbnailsPresenter */ presenter) =>{
      presenter.m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(/**@type {ComponentsExtensionPoint} */ ($Casts.$to(arg0, ComponentsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThumbnailsPresenterContributionToComponentsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThumbnailsPresenterContributionToComponentsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThumbnailsPresenterContributionToComponentsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    ThumbnailsPresenterCommand = goog.module.get('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThumbnailsPresenterContributionToComponentsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.thumbnails.client.contributions.ThumbnailsPresenterContributionToComponentsExtensionPoint'));


Contribution.$markImplementor(ThumbnailsPresenterContributionToComponentsExtensionPoint);


exports = ThumbnailsPresenterContributionToComponentsExtensionPoint; 
//# sourceMappingURL=ThumbnailsPresenterContributionToComponentsExtensionPoint.js.map