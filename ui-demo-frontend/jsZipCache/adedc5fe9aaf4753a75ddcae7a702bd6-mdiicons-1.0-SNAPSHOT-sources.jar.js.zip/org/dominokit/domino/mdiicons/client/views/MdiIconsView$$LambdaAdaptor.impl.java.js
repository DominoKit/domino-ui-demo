/**
 * @fileoverview transpiled from org.dominokit.domino.mdiicons.client.views.MdiIconsView$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.mdiicons.client.views.MdiIconsView.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MdiIconsView = goog.require('org.dominokit.domino.mdiicons.client.views.MdiIconsView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @implements {MdiIconsView}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Content} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Content} */
    this.f_$$fn__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$LambdaAdaptor__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Content} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$LambdaAdaptor__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Content}
   * @public
   */
  m_getContent__() {
    let /** ?function():Content */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_mdiicons_client_views_MdiIconsView_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.mdiicons.client.views.MdiIconsView$$LambdaAdaptor'));


MdiIconsView.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=MdiIconsView$$LambdaAdaptor.js.map