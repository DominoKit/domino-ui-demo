/**
 * @fileoverview transpiled from org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration.$2$impl');
let MdiIconsPresenterListenerForComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.listeners.MdiIconsPresenterListenerForComponentCaseEvent$impl');
let MdiIconsPresenter = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter$impl');
let MdiIconsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class MdiIconsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MdiIconsModuleConfiguration()'.
   * @return {!MdiIconsModuleConfiguration}
   * @public
   */
  static $create__() {
    MdiIconsModuleConfiguration.$clinit();
    let $instance = new MdiIconsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_mdiicons_client_MdiIconsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MdiIconsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_mdiicons_client_MdiIconsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_mdiicons_client_MdiIconsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(MdiIconsPresenter).m_getCanonicalName__(), Class.$get(MdiIconsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_mdiicons_client_MdiIconsModuleConfiguration__java_lang_String(this, Class.$get(MdiIconsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(MdiIconsPresenterCommand).m_getCanonicalName__(), Class.$get(MdiIconsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentCaseEvent), MdiIconsPresenterListenerForComponentCaseEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MdiIconsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MdiIconsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MdiIconsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    $1 = goog.module.get('org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration.$2$impl');
    MdiIconsPresenterListenerForComponentCaseEvent = goog.module.get('org.dominokit.domino.mdiicons.client.listeners.MdiIconsPresenterListenerForComponentCaseEvent$impl');
    MdiIconsPresenter = goog.module.get('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter$impl');
    MdiIconsPresenterCommand = goog.module.get('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MdiIconsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.mdiicons.client.MdiIconsModuleConfiguration'));


ModuleConfiguration.$markImplementor(MdiIconsModuleConfiguration);


exports = MdiIconsModuleConfiguration; 
//# sourceMappingURL=MdiIconsModuleConfiguration.js.map