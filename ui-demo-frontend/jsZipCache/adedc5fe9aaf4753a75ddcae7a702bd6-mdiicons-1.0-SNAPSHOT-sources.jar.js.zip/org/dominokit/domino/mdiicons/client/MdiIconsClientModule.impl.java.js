/**
 * @fileoverview transpiled from org.dominokit.domino.mdiicons.client.MdiIconsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.mdiicons.client.MdiIconsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class MdiIconsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MdiIconsClientModule()'.
   * @return {!MdiIconsClientModule}
   * @public
   */
  static $create__() {
    MdiIconsClientModule.$clinit();
    let $instance = new MdiIconsClientModule();
    $instance.$ctor__org_dominokit_domino_mdiicons_client_MdiIconsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MdiIconsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_mdiicons_client_MdiIconsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    MdiIconsClientModule.$f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_.m_info__java_lang_String("Initializing MdiIcons frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_() {
    return (MdiIconsClientModule.$clinit(), MdiIconsClientModule.$f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_(value) {
    (MdiIconsClientModule.$clinit(), MdiIconsClientModule.$f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MdiIconsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MdiIconsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MdiIconsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    MdiIconsClientModule.$f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(MdiIconsClientModule));
  }
  
  
};

$Util.$setClassMetadata(MdiIconsClientModule, $Util.$makeClassName('org.dominokit.domino.mdiicons.client.MdiIconsClientModule'));


/** @private {Logger} */
MdiIconsClientModule.$f_LOGGER__org_dominokit_domino_mdiicons_client_MdiIconsClientModule_;




exports = MdiIconsClientModule; 
//# sourceMappingURL=MdiIconsClientModule.js.map