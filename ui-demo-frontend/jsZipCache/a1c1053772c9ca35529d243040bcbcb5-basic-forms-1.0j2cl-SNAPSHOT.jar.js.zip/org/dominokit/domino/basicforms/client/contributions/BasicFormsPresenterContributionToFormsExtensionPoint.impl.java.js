/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.contributions.BasicFormsPresenterContributionToFormsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.basicforms.client.contributions.BasicFormsPresenterContributionToFormsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let BasicFormsPresenter = goog.forwardDeclare('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter$impl');
let BasicFormsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<FormsExtensionPoint>}
  */
class BasicFormsPresenterContributionToFormsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BasicFormsPresenterContributionToFormsExtensionPoint()'.
   * @return {!BasicFormsPresenterContributionToFormsExtensionPoint}
   * @public
   */
  static $create__() {
    BasicFormsPresenterContributionToFormsExtensionPoint.$clinit();
    let $instance = new BasicFormsPresenterContributionToFormsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_basicforms_client_contributions_BasicFormsPresenterContributionToFormsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BasicFormsPresenterContributionToFormsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_basicforms_client_contributions_BasicFormsPresenterContributionToFormsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {FormsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint(extensionPoint) {
    BasicFormsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** BasicFormsPresenter */ presenter) =>{
      presenter.m_contributeToMainModule__org_dominokit_domino_forms_shared_extension_FormsContext(/**@type {FormsContext} */ ($Casts.$to(extensionPoint.m_context__(), FormsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint(/**@type {FormsExtensionPoint} */ ($Casts.$to(arg0, FormsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BasicFormsPresenterContributionToFormsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BasicFormsPresenterContributionToFormsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BasicFormsPresenterContributionToFormsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    BasicFormsPresenterCommand = goog.module.get('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsExtensionPoint = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BasicFormsPresenterContributionToFormsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.basicforms.client.contributions.BasicFormsPresenterContributionToFormsExtensionPoint'));


Contribution.$markImplementor(BasicFormsPresenterContributionToFormsExtensionPoint);


exports = BasicFormsPresenterContributionToFormsExtensionPoint; 
//# sourceMappingURL=BasicFormsPresenterContributionToFormsExtensionPoint.js.map