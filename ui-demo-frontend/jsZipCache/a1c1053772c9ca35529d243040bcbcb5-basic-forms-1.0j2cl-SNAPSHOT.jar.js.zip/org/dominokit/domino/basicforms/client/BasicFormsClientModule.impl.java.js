/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.BasicFormsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.basicforms.client.BasicFormsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class BasicFormsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BasicFormsClientModule()'.
   * @return {!BasicFormsClientModule}
   * @public
   */
  static $create__() {
    BasicFormsClientModule.$clinit();
    let $instance = new BasicFormsClientModule();
    $instance.$ctor__org_dominokit_domino_basicforms_client_BasicFormsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BasicFormsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_basicforms_client_BasicFormsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    BasicFormsClientModule.$f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_.m_info__java_lang_String("Initializing BasicForms frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_() {
    return (BasicFormsClientModule.$clinit(), BasicFormsClientModule.$f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_(value) {
    (BasicFormsClientModule.$clinit(), BasicFormsClientModule.$f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BasicFormsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BasicFormsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BasicFormsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    BasicFormsClientModule.$f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(BasicFormsClientModule));
  }
  
  
};

$Util.$setClassMetadata(BasicFormsClientModule, $Util.$makeClassName('org.dominokit.domino.basicforms.client.BasicFormsClientModule'));


/** @private {Logger} */
BasicFormsClientModule.$f_LOGGER__org_dominokit_domino_basicforms_client_BasicFormsClientModule_;




exports = BasicFormsClientModule; 
//# sourceMappingURL=BasicFormsClientModule.js.map