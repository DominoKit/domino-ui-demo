/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.contributions.BasicFormsPresenterContributionToFormsExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.basicforms.client.contributions.BasicFormsPresenterContributionToFormsExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _BasicFormsPresenter = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter');
const _BasicFormsPresenterCommand = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand');
const _FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext');
const _FormsExtensionPoint = goog.require('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BasicFormsPresenterContributionToFormsExtensionPoint = goog.require('org.dominokit.domino.basicforms.client.contributions.BasicFormsPresenterContributionToFormsExtensionPoint$impl');
exports = BasicFormsPresenterContributionToFormsExtensionPoint;
 