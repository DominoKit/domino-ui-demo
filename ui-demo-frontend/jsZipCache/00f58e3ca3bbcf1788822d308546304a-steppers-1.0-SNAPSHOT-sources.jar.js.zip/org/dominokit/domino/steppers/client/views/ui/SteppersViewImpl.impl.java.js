/**
 * @fileoverview transpiled from org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const SteppersView = goog.require('org.dominokit.domino.steppers.client.views.SteppersView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let KeyboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$9$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Step = goog.forwardDeclare('org.dominokit.domino.ui.steppers.Step$impl');
let ActivationHandler = goog.forwardDeclare('org.dominokit.domino.ui.steppers.Step.ActivationHandler$impl');
let StepCompletedValidator = goog.forwardDeclare('org.dominokit.domino.ui.steppers.Step.StepCompletedValidator$impl');
let Stepper = goog.forwardDeclare('org.dominokit.domino.ui.steppers.Stepper$impl');
let StepperCompletionHandler = goog.forwardDeclare('org.dominokit.domino.ui.steppers.Stepper.StepperCompletionHandler$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {SteppersView}
  */
class SteppersViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'SteppersViewImpl()'.
   * @return {!SteppersViewImpl}
   * @public
   */
  static $create__() {
    SteppersViewImpl.$clinit();
    let $instance = new SteppersViewImpl();
    $instance.$ctor__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SteppersViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(SteppersViewImpl.f_MODULE_NAME__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("STEPPERS").m_asElement__());
    this.m_verticalStepper___$p_org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl();
    this.m_horizontalStepper___$p_org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_verticalStepper___$p_org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl() {
    let stepper = Stepper.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color);
    let nameTextBox = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Name").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_label__()), TextBox));
    nameTextBox.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("keypress", new $LambdaAdaptor$1(((/** Event */ evt) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt)))) {
        stepper.m_next__();
      }
    })));
    let email = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Email").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__()), TextBox));
    email.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("keypress", new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt$1$)))) {
        stepper.m_next__();
      }
    })));
    let phone = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String("Phone")), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_phone__()), TextBox));
    phone.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("keypress", new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt$2$)))) {
        stepper.m_finish__();
      }
    })));
    let stepOne = Step.m_create__java_lang_String__java_lang_String("Contact name", "Contact name step").m_setValidator__org_dominokit_domino_ui_steppers_Step_StepCompletedValidator(StepCompletedValidator.$adapt((() =>{
      return nameTextBox.m_validate__().m_isValid__();
    }))).m_onActivated__org_dominokit_domino_ui_steppers_Step_ActivationHandler(ActivationHandler.$adapt(((/** Step */ step) =>{
      nameTextBox.m_focus__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(nameTextBox), Column)))).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Next"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt$3$) =>{
      stepper.m_next__();
    })))), Column))));
    let stepTow = Step.m_create__java_lang_String__java_lang_String("Contact email", "Contact email step").m_setValidator__org_dominokit_domino_ui_steppers_Step_StepCompletedValidator(StepCompletedValidator.$adapt((() =>{
      return email.m_validate__().m_isValid__();
    }))).m_onActivated__org_dominokit_domino_ui_steppers_Step_ActivationHandler(ActivationHandler.$adapt(((/** Step */ step$1$) =>{
      email.m_focus__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(email), Column)))).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Back"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$5(((/** Event */ evt$4$) =>{
      stepper.m_back__();
    })))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Next"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$6(((/** Event */ evt$5$) =>{
      stepper.m_next__();
    })))), Column))));
    let stepThree = Step.m_create__java_lang_String__java_lang_String("Contact phone", "Contact phone step").m_setValidator__org_dominokit_domino_ui_steppers_Step_StepCompletedValidator(StepCompletedValidator.$adapt((() =>{
      return phone.m_validate__().m_isValid__();
    }))).m_onActivated__org_dominokit_domino_ui_steppers_Step_ActivationHandler(ActivationHandler.$adapt(((/** Step */ step$2$) =>{
      phone.m_focus__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(phone), Column)))).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Back"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$7(((/** Event */ evt$6$) =>{
      stepper.m_back__();
    })))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Finish"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$8(((/** Event */ evt$7$) =>{
      stepper.m_finish__();
    })))), Column))));
    stepper.m_appendChild__org_dominokit_domino_ui_steppers_Step(stepOne).m_appendChild__org_dominokit_domino_ui_steppers_Step(stepTow).m_appendChild__org_dominokit_domino_ui_steppers_Step(stepThree).m_setCompletionHandler__org_dominokit_domino_ui_steppers_Stepper_StepperCompletionHandler(StepperCompletionHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("All step completed").m_show__();
    })));
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_.appendChild(Card.m_create__java_lang_String("VERTICAL STEPPER").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(stepper), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SteppersViewImpl.f_MODULE_NAME__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl, "verticalStepper").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_horizontalStepper___$p_org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl() {
    let stepper = Stepper.m_create__().m_setMinHeight__java_lang_String("300px").m_setHorizontal__boolean(true);
    let nameTextBox = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Name").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_label__()), TextBox));
    nameTextBox.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("keypress", new $LambdaAdaptor$9(((/** Event */ evt) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt)))) {
        stepper.m_next__();
      }
    })));
    let email = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Email").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_email__()), TextBox));
    email.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("keypress", new $LambdaAdaptor$10(((/** Event */ evt$1$) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt$1$)))) {
        stepper.m_next__();
      }
    })));
    let phone = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String("Phone")), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_phone__()), TextBox));
    phone.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("keypress", new $LambdaAdaptor$11(((/** Event */ evt$2$) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt$2$)))) {
        stepper.m_finish__();
      }
    })));
    let stepOne = Step.m_create__java_lang_String__java_lang_String("Contact name", "Contact name step").m_setValidator__org_dominokit_domino_ui_steppers_Step_StepCompletedValidator(StepCompletedValidator.$adapt((() =>{
      return nameTextBox.m_validate__().m_isValid__();
    }))).m_onActivated__org_dominokit_domino_ui_steppers_Step_ActivationHandler(ActivationHandler.$adapt(((/** Step */ step) =>{
      nameTextBox.m_focus__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(nameTextBox), Column)))).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Next"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$12(((/** Event */ evt$3$) =>{
      stepper.m_next__();
    })))), Column))));
    let stepTow = Step.m_create__java_lang_String__java_lang_String("Contact email", "Contact email step").m_setValidator__org_dominokit_domino_ui_steppers_Step_StepCompletedValidator(StepCompletedValidator.$adapt((() =>{
      return email.m_validate__().m_isValid__();
    }))).m_onActivated__org_dominokit_domino_ui_steppers_Step_ActivationHandler(ActivationHandler.$adapt(((/** Step */ step$1$) =>{
      email.m_focus__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(email), Column)))).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Back"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$13(((/** Event */ evt$4$) =>{
      stepper.m_back__();
    })))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Next"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$14(((/** Event */ evt$5$) =>{
      stepper.m_next__();
    })))), Column))));
    let stepThree = Step.m_create__java_lang_String__java_lang_String("Contact phone", "Contact phone step").m_setValidator__org_dominokit_domino_ui_steppers_Step_StepCompletedValidator(StepCompletedValidator.$adapt((() =>{
      return phone.m_validate__().m_isValid__();
    }))).m_onActivated__org_dominokit_domino_ui_steppers_Step_ActivationHandler(ActivationHandler.$adapt(((/** Step */ step$2$) =>{
      phone.m_focus__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(phone), Column)))).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Back"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$15(((/** Event */ evt$6$) =>{
      stepper.m_back__();
    })))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Style<HTMLElement, Button>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("Finish"))).m_setMinWidth__java_lang_String("120px").m_setMarginRight__java_lang_String("5px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$16(((/** Event */ evt$7$) =>{
      stepper.m_finish__();
    })))), Column))));
    stepper.m_appendChild__org_dominokit_domino_ui_steppers_Step(stepOne).m_appendChild__org_dominokit_domino_ui_steppers_Step(stepTow).m_appendChild__org_dominokit_domino_ui_steppers_Step(stepThree).m_setCompletionHandler__org_dominokit_domino_ui_steppers_Stepper_StepperCompletionHandler(StepperCompletionHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("All step completed").m_show__();
    })));
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_.appendChild(Card.m_create__java_lang_String("HORIZONTAL STEPPER").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(stepper), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SteppersViewImpl.f_MODULE_NAME__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl, "horizontalStepper").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl() {
    this.f_element__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SteppersViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SteppersViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SteppersViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl.$LambdaAdaptor$9$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Step = goog.module.get('org.dominokit.domino.ui.steppers.Step$impl');
    ActivationHandler = goog.module.get('org.dominokit.domino.ui.steppers.Step.ActivationHandler$impl');
    StepCompletedValidator = goog.module.get('org.dominokit.domino.ui.steppers.Step.StepCompletedValidator$impl');
    Stepper = goog.module.get('org.dominokit.domino.ui.steppers.Stepper$impl');
    StepperCompletionHandler = goog.module.get('org.dominokit.domino.ui.steppers.Stepper.StepperCompletionHandler$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SteppersViewImpl, $Util.$makeClassName('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl'));


/** @public {?string} @const */
SteppersViewImpl.f_MODULE_NAME__org_dominokit_domino_steppers_client_views_ui_SteppersViewImpl = "steppers";


SteppersView.$markImplementor(SteppersViewImpl);


exports = SteppersViewImpl; 
//# sourceMappingURL=SteppersViewImpl.js.map