/**
 * @fileoverview transpiled from org.dominokit.domino.steppers.client.SteppersModuleConfiguration$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.steppers.client.SteppersModuleConfiguration.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _SteppersModuleConfiguration = goog.require('org.dominokit.domino.steppers.client.SteppersModuleConfiguration');
const _SteppersViewImpl = goog.require('org.dominokit.domino.steppers.client.views.ui.SteppersViewImpl');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.steppers.client.SteppersModuleConfiguration.$2$impl');
exports = $2;
 