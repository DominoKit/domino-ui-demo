/**
 * @fileoverview transpiled from org.dominokit.domino.steppers.client.presenters.SteppersPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.steppers.client.presenters.SteppersPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.steppers.client.presenters.SteppersPresenter.$1$impl');
let SteppersView = goog.forwardDeclare('org.dominokit.domino.steppers.client.views.SteppersView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<SteppersView>}
  */
class SteppersPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SteppersPresenter()'.
   * @return {!SteppersPresenter}
   * @public
   */
  static $create__() {
    SteppersPresenter.$clinit();
    let $instance = new SteppersPresenter();
    $instance.$ctor__org_dominokit_domino_steppers_client_presenters_SteppersPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SteppersPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_steppers_client_presenters_SteppersPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {FormsContext} formsContext
   * @return {void}
   * @public
   */
  m_onFormsReadyEvent__org_dominokit_domino_forms_shared_extension_FormsContext(formsContext) {
    formsContext.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_steppers_client_presenters_SteppersPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_steppers_client_presenters_SteppersPresenter_() {
    return (SteppersPresenter.$clinit(), SteppersPresenter.$f_LOGGER__org_dominokit_domino_steppers_client_presenters_SteppersPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_steppers_client_presenters_SteppersPresenter_(value) {
    (SteppersPresenter.$clinit(), SteppersPresenter.$f_LOGGER__org_dominokit_domino_steppers_client_presenters_SteppersPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SteppersPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SteppersPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SteppersPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.steppers.client.presenters.SteppersPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    SteppersPresenter.$f_LOGGER__org_dominokit_domino_steppers_client_presenters_SteppersPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SteppersPresenter));
  }
  
  
};

$Util.$setClassMetadata(SteppersPresenter, $Util.$makeClassName('org.dominokit.domino.steppers.client.presenters.SteppersPresenter'));


/** @private {Logger} */
SteppersPresenter.$f_LOGGER__org_dominokit_domino_steppers_client_presenters_SteppersPresenter_;




exports = SteppersPresenter; 
//# sourceMappingURL=SteppersPresenter.js.map