/**
 * @fileoverview transpiled from org.dominokit.domino.steppers.client.listeners.SteppersPresenterListenerForFormsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.steppers.client.listeners.SteppersPresenterListenerForFormsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsEvent = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
let SteppersPresenter = goog.forwardDeclare('org.dominokit.domino.steppers.client.presenters.SteppersPresenter$impl');
let SteppersPresenterCommand = goog.forwardDeclare('org.dominokit.domino.steppers.client.presenters.SteppersPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<FormsEvent>}
  */
class SteppersPresenterListenerForFormsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SteppersPresenterListenerForFormsEvent()'.
   * @return {!SteppersPresenterListenerForFormsEvent}
   * @public
   */
  static $create__() {
    SteppersPresenterListenerForFormsEvent.$clinit();
    let $instance = new SteppersPresenterListenerForFormsEvent();
    $instance.$ctor__org_dominokit_domino_steppers_client_listeners_SteppersPresenterListenerForFormsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SteppersPresenterListenerForFormsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_steppers_client_listeners_SteppersPresenterListenerForFormsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {FormsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_forms_shared_extension_FormsEvent(event) {
    SteppersPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** SteppersPresenter */ presenter) =>{
      presenter.m_onFormsReadyEvent__org_dominokit_domino_forms_shared_extension_FormsContext(/**@type {FormsContext} */ ($Casts.$to(event.m_context__(), FormsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_forms_shared_extension_FormsEvent(/**@type {FormsEvent} */ ($Casts.$to(arg0, FormsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SteppersPresenterListenerForFormsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SteppersPresenterListenerForFormsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SteppersPresenterListenerForFormsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsEvent = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
    SteppersPresenterCommand = goog.module.get('org.dominokit.domino.steppers.client.presenters.SteppersPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SteppersPresenterListenerForFormsEvent, $Util.$makeClassName('org.dominokit.domino.steppers.client.listeners.SteppersPresenterListenerForFormsEvent'));


DominoEventListener.$markImplementor(SteppersPresenterListenerForFormsEvent);


exports = SteppersPresenterListenerForFormsEvent; 
//# sourceMappingURL=SteppersPresenterListenerForFormsEvent.js.map