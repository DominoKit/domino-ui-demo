/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.views.PopoverView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.popover.client.views.PopoverView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.popover.client.views.PopoverView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class PopoverView {
  /**
   * @param {?function():Content} fn
   * @return {PopoverView}
   * @public
   */
  static $adapt(fn) {
    PopoverView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_popover_client_views_PopoverView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_popover_client_views_PopoverView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_popover_client_views_PopoverView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PopoverView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.popover.client.views.PopoverView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(PopoverView, $Util.$makeClassName('org.dominokit.domino.popover.client.views.PopoverView'));


PopoverView.$markImplementor(/** @type {Function} */ (PopoverView));


exports = PopoverView; 
//# sourceMappingURL=PopoverView.js.map