/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.presenters.PopoverPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.popover.client.presenters.PopoverPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.popover.client.presenters.PopoverPresenter.$1$impl');
let PopoverView = goog.forwardDeclare('org.dominokit.domino.popover.client.views.PopoverView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<PopoverView>}
  */
class PopoverPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PopoverPresenter()'.
   * @return {!PopoverPresenter}
   * @public
   */
  static $create__() {
    PopoverPresenter.$clinit();
    let $instance = new PopoverPresenter();
    $instance.$ctor__org_dominokit_domino_popover_client_presenters_PopoverPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PopoverPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_popover_client_presenters_PopoverPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_popover_client_presenters_PopoverPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_popover_client_presenters_PopoverPresenter_() {
    return (PopoverPresenter.$clinit(), PopoverPresenter.$f_LOGGER__org_dominokit_domino_popover_client_presenters_PopoverPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_popover_client_presenters_PopoverPresenter_(value) {
    (PopoverPresenter.$clinit(), PopoverPresenter.$f_LOGGER__org_dominokit_domino_popover_client_presenters_PopoverPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PopoverPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PopoverPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PopoverPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.popover.client.presenters.PopoverPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    PopoverPresenter.$f_LOGGER__org_dominokit_domino_popover_client_presenters_PopoverPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(PopoverPresenter));
  }
  
  
};

$Util.$setClassMetadata(PopoverPresenter, $Util.$makeClassName('org.dominokit.domino.popover.client.presenters.PopoverPresenter'));


/** @private {Logger} */
PopoverPresenter.$f_LOGGER__org_dominokit_domino_popover_client_presenters_PopoverPresenter_;




exports = PopoverPresenter; 
//# sourceMappingURL=PopoverPresenter.js.map