/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.presenters.PopoverPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.popover.client.presenters.PopoverPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _PopoverPresenter = goog.require('org.dominokit.domino.popover.client.presenters.PopoverPresenter');


// Re-exports the implementation.
var PopoverPresenterCommand = goog.require('org.dominokit.domino.popover.client.presenters.PopoverPresenterCommand$impl');
exports = PopoverPresenterCommand;
 