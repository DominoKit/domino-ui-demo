package org.dominokit.domino.datepicker.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.datepicker.client.contributions.DatePickerPresenterContributionToFormsExtensionPoint;
import org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter;
import org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand;
import org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl;
import org.dominokit.domino.forms.shared.extension.FormsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class DatePickerModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(DatePickerPresenter.class.getCanonicalName(), DatePickerPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new DatePickerPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(DatePickerPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new DatePickerViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(DatePickerPresenterCommand.class.getCanonicalName(), DatePickerPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(FormsExtensionPoint.class, new DatePickerPresenterContributionToFormsExtensionPoint());
  }
}
