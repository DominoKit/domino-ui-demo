/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let DatePickerPresenter = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$impl');


/**
 * @extends {PresenterCommand<DatePickerPresenter>}
  */
class DatePickerPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerPresenterCommand()'.
   * @return {!DatePickerPresenterCommand}
   * @public
   */
  static $create__() {
    DatePickerPresenterCommand.$clinit();
    let $instance = new DatePickerPresenterCommand();
    $instance.$ctor__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_presenters_DatePickerPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerPresenterCommand, $Util.$makeClassName('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand'));




exports = DatePickerPresenterCommand; 
//# sourceMappingURL=DatePickerPresenterCommand.js.map