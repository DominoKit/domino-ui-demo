/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.contributions.DatePickerPresenterContributionToFormsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datepicker.client.contributions.DatePickerPresenterContributionToFormsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let DatePickerPresenter = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenter$impl');
let DatePickerPresenterCommand = goog.forwardDeclare('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<FormsExtensionPoint>}
  */
class DatePickerPresenterContributionToFormsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerPresenterContributionToFormsExtensionPoint()'.
   * @return {!DatePickerPresenterContributionToFormsExtensionPoint}
   * @public
   */
  static $create__() {
    DatePickerPresenterContributionToFormsExtensionPoint.$clinit();
    let $instance = new DatePickerPresenterContributionToFormsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_datepicker_client_contributions_DatePickerPresenterContributionToFormsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerPresenterContributionToFormsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datepicker_client_contributions_DatePickerPresenterContributionToFormsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {FormsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint(extensionPoint) {
    DatePickerPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** DatePickerPresenter */ presenter) =>{
      presenter.m_contributeToFormsModule__org_dominokit_domino_forms_shared_extension_FormsContext(/**@type {FormsContext} */ ($Casts.$to(extensionPoint.m_context__(), FormsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint(/**@type {FormsExtensionPoint} */ ($Casts.$to(arg0, FormsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerPresenterContributionToFormsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerPresenterContributionToFormsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerPresenterContributionToFormsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    DatePickerPresenterCommand = goog.module.get('org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsExtensionPoint = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerPresenterContributionToFormsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.datepicker.client.contributions.DatePickerPresenterContributionToFormsExtensionPoint'));


Contribution.$markImplementor(DatePickerPresenterContributionToFormsExtensionPoint);


exports = DatePickerPresenterContributionToFormsExtensionPoint; 
//# sourceMappingURL=DatePickerPresenterContributionToFormsExtensionPoint.js.map