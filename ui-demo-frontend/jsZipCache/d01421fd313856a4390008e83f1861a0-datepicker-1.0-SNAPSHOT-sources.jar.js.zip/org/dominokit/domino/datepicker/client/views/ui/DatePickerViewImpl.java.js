/**
 * @fileoverview transpiled from org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _DatePickerView = goog.require('org.dominokit.domino.datepicker.client.views.DatePickerView');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Date = goog.require('java.util.Date');
const _CodeResource = goog.require('org.dominokit.domino.datepicker.client.views.CodeResource');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.$LambdaAdaptor$3');
const _Formatter = goog.require('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl.Formatter');
const _IconButton = goog.require('org.dominokit.domino.ui.button.IconButton');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _DateBox = goog.require('org.dominokit.domino.ui.datepicker.DateBox');
const _PickerStyle = goog.require('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle');
const _DatePicker = goog.require('org.dominokit.domino.ui.datepicker.DatePicker');
const _DateSelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _PickerHandler = goog.require('org.dominokit.domino.ui.pickers.PickerHandler');
const _Popover = goog.require('org.dominokit.domino.ui.popover.Popover');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _DateTimeFormatInfoImpl__fr = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_fr');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DatePickerViewImpl = goog.require('org.dominokit.domino.datepicker.client.views.ui.DatePickerViewImpl$impl');
exports = DatePickerViewImpl;
 