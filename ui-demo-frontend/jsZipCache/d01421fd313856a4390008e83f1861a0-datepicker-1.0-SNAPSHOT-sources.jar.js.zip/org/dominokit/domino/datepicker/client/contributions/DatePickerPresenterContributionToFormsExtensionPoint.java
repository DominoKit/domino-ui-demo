package org.dominokit.domino.datepicker.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.datepicker.client.presenters.DatePickerPresenterCommand;
import org.dominokit.domino.forms.shared.extension.FormsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class DatePickerPresenterContributionToFormsExtensionPoint implements Contribution<FormsExtensionPoint> {
  @Override
  public void contribute(FormsExtensionPoint extensionPoint) {
    new DatePickerPresenterCommand().onPresenterReady(presenter -> presenter.contributeToFormsModule(extensionPoint.context())).send();
  }
}
