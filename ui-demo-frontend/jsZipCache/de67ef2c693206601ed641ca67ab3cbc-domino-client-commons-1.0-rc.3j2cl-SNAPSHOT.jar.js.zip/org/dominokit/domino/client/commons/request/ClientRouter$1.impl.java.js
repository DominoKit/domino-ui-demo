/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.ClientRouter$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.ClientRouter.$1$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');
let ClientRouter = goog.forwardDeclare('org.dominokit.domino.client.commons.request.ClientRouter$impl');


/**
 * @implements {AsyncTask}
  */
class $1 extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ClientRouter} */
    this.f_$outer_this__org_dominokit_domino_client_commons_request_ClientRouter_1;
    /** @public {PresenterCommand} */
    this.$c_presenterCommand;
  }
  
  /**
   * Factory method corresponding to constructor 'new AsyncTask(ClientRouter, PresenterCommand)'.
   * @param {ClientRouter} $outer_this
   * @param {PresenterCommand} $c_presenterCommand
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_client_commons_request_ClientRouter__org_dominokit_domino_api_client_request_PresenterCommand($outer_this, $c_presenterCommand) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_client_commons_request_ClientRouter_1__org_dominokit_domino_client_commons_request_ClientRouter__org_dominokit_domino_api_client_request_PresenterCommand($outer_this, $c_presenterCommand);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new AsyncTask(ClientRouter, PresenterCommand)'.
   * @param {ClientRouter} $outer_this
   * @param {PresenterCommand} $c_presenterCommand
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_ClientRouter_1__org_dominokit_domino_client_commons_request_ClientRouter__org_dominokit_domino_api_client_request_PresenterCommand($outer_this, $c_presenterCommand) {
    this.f_$outer_this__org_dominokit_domino_client_commons_request_ClientRouter_1 = $outer_this;
    this.$c_presenterCommand = $c_presenterCommand;
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_onSuccess__() {
    this.f_$outer_this__org_dominokit_domino_client_commons_request_ClientRouter_1.f_requestEventFactory__org_dominokit_domino_client_commons_request_ClientRouter_.m_make__org_dominokit_domino_api_client_request_PresenterCommand(this.$c_presenterCommand).m_fire__();
  }
  
  /**
   * @override
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  m_onFailed__java_lang_Throwable(error) {
    ClientRouter.f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_.m_error__java_lang_String__java_lang_Throwable("Could not RunAsync request [" + j_l_String.m_valueOf__java_lang_Object(this.$c_presenterCommand) + "]", error);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    ClientRouter = goog.module.get('org.dominokit.domino.client.commons.request.ClientRouter$impl');
    j_l_Object.$clinit();
    AsyncTask.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.client.commons.request.ClientRouter$1'));


AsyncTask.$markImplementor($1);


exports = $1; 
//# sourceMappingURL=ClientRouter$1.js.map