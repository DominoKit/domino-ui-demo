/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.ClientRouter$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.ClientRouter.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');
const _j_l_String = goog.require('java.lang.String');
const _Throwable = goog.require('java.lang.Throwable');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ClientRouter = goog.require('org.dominokit.domino.client.commons.request.ClientRouter');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.client.commons.request.ClientRouter.$1$impl');
exports = $1;
 