/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.RequestAsyncSender');
const _Class = goog.require('java.lang.Class');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _ServerRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ServerRequestEventFactory');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _RequestAsyncTask = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.RequestAsyncTask');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var AbstractRequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$impl');
exports = AbstractRequestAsyncSender;
 