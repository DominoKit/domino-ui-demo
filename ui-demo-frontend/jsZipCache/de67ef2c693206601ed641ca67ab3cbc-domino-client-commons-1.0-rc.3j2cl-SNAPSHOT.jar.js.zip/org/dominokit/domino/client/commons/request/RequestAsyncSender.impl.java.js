/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.RequestAsyncSender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.RequestAsyncSender$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.client.commons.request.RequestAsyncSender.$LambdaAdaptor$impl');


/**
 * @interface
 */
class RequestAsyncSender {
  /**
   * @abstract
   * @param {ServerRequest} request
   * @return {void}
   * @public
   */
  m_send__org_dominokit_domino_api_client_request_ServerRequest(request) {
  }
  
  /**
   * @param {?function(ServerRequest):void} fn
   * @return {RequestAsyncSender}
   * @public
   */
  static $adapt(fn) {
    RequestAsyncSender.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_client_commons_request_RequestAsyncSender = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_client_commons_request_RequestAsyncSender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_client_commons_request_RequestAsyncSender;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestAsyncSender.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.client.commons.request.RequestAsyncSender.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestAsyncSender, $Util.$makeClassName('org.dominokit.domino.client.commons.request.RequestAsyncSender'));


RequestAsyncSender.$markImplementor(/** @type {Function} */ (RequestAsyncSender));


exports = RequestAsyncSender; 
//# sourceMappingURL=RequestAsyncSender.js.map