/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.history.DominoDirectState.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.history.DominoDirectState$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DirectState = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectState$impl');

let DirectUrlHandler = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler$impl');
let State = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');
let TokenFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter$impl');


/**
 * @implements {DirectState}
  */
class DominoDirectState extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TokenFilter} */
    this.f_tokenFilter__org_dominokit_domino_client_commons_history_DominoDirectState_;
    /** @public {State} */
    this.f_state__org_dominokit_domino_client_commons_history_DominoDirectState_;
  }
  
  /**
   * Factory method corresponding to constructor 'DominoDirectState(TokenFilter, State)'.
   * @param {TokenFilter} tokenFilter
   * @param {State} state
   * @return {!DominoDirectState}
   * @public
   */
  static $create__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_State(tokenFilter, state) {
    DominoDirectState.$clinit();
    let $instance = new DominoDirectState();
    $instance.$ctor__org_dominokit_domino_client_commons_history_DominoDirectState__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_State(tokenFilter, state);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DominoDirectState(TokenFilter, State)'.
   * @param {TokenFilter} tokenFilter
   * @param {State} state
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_history_DominoDirectState__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_State(tokenFilter, state) {
    this.$ctor__java_lang_Object__();
    this.f_tokenFilter__org_dominokit_domino_client_commons_history_DominoDirectState_ = tokenFilter;
    this.f_state__org_dominokit_domino_client_commons_history_DominoDirectState_ = state;
  }
  
  /**
   * @override
   * @param {DirectUrlHandler} handler
   * @return {void}
   * @public
   */
  m_onDirectUrl__org_dominokit_domino_api_shared_history_DominoHistory_DirectUrlHandler(handler) {
    if (this.f_tokenFilter__org_dominokit_domino_client_commons_history_DominoDirectState_.m_filter__org_dominokit_domino_api_shared_history_HistoryToken(this.f_state__org_dominokit_domino_client_commons_history_DominoDirectState_.m_token__())) {
      handler.m_handle__org_dominokit_domino_api_shared_history_DominoHistory_State(this.f_state__org_dominokit_domino_client_commons_history_DominoDirectState_);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DominoDirectState;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DominoDirectState);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoDirectState.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DominoDirectState, $Util.$makeClassName('org.dominokit.domino.client.commons.history.DominoDirectState'));


DirectState.$markImplementor(DominoDirectState);


exports = DominoDirectState; 
//# sourceMappingURL=DominoDirectState.js.map