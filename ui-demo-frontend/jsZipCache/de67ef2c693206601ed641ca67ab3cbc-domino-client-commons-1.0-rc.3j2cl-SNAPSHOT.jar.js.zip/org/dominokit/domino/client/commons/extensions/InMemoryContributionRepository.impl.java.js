/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ContributionsRepository = goog.require('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let Contribution = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ContributionWrapper = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository.ContributionWrapper$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ContributionsRepository}
  */
class InMemoryContributionRepository extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<?string, Set<ContributionWrapper>>} */
    this.f_contributions__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_;
  }
  
  /**
   * Factory method corresponding to constructor 'InMemoryContributionRepository()'.
   * @return {!InMemoryContributionRepository}
   * @public
   */
  static $create__() {
    InMemoryContributionRepository.$clinit();
    let $instance = new InMemoryContributionRepository();
    $instance.$ctor__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InMemoryContributionRepository()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository();
  }
  
  /**
   * @override
   * @param {Class<?>} extensionPoint
   * @param {Contribution} contribution
   * @return {void}
   * @public
   */
  m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(extensionPoint, contribution) {
    this.m_initializeExtensionPointContributions__java_lang_Class_$p_org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository(extensionPoint);
    /**@type {Set<ContributionWrapper>} */ ($Casts.$to(this.f_contributions__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_.get(extensionPoint.m_getCanonicalName__()), Set)).add(ContributionWrapper.$create__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository__org_dominokit_domino_api_shared_extension_Contribution(this, contribution));
  }
  
  /**
   * @override
   * @param {Class<?>} extensionPoint
   * @return {Set<Contribution>}
   * @public
   */
  m_findExtensionPointContributions__java_lang_Class(extensionPoint) {
    this.m_initializeExtensionPointContributions__java_lang_Class_$p_org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository(extensionPoint);
    return /**@type {Set<Contribution>} */ ($Casts.$to(/**@type {Stream<Contribution>} */ (/**@type {Set<ContributionWrapper>} */ ($Casts.$to(this.f_contributions__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_.get(extensionPoint.m_getCanonicalName__()), Set)).m_stream__().m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** ContributionWrapper */ cw) =>{
      return cw.f_contribution__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper_;
    })))).m_collect__java_util_stream_Collector(/**@type {Collector<Contribution, ?, Set<Contribution>>} */ (Collectors.m_toSet__())), Set));
  }
  
  /**
   * @param {Class<?>} extensionPoint
   * @return {void}
   * @public
   */
  m_initializeExtensionPointContributions__java_lang_Class_$p_org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository(extensionPoint) {
    if (Objects.m_isNull__java_lang_Object(this.f_contributions__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_.get(extensionPoint.m_getCanonicalName__()))) {
      this.f_contributions__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_.put(extensionPoint.m_getCanonicalName__(), /**@type {!HashSet<ContributionWrapper>} */ (HashSet.$create__()));
    }
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository() {
    this.f_contributions__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ = /**@type {!HashMap<?string, Set<ContributionWrapper>>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InMemoryContributionRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InMemoryContributionRepository);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InMemoryContributionRepository.$clinit = function() {};
    HashMap = goog.module.get('java.util.HashMap$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Set = goog.module.get('java.util.Set$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    ContributionWrapper = goog.module.get('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository.ContributionWrapper$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InMemoryContributionRepository, $Util.$makeClassName('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository'));


ContributionsRepository.$markImplementor(InMemoryContributionRepository);


exports = InMemoryContributionRepository; 
//# sourceMappingURL=InMemoryContributionRepository.js.map