/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ViewsRepository = goog.require('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');

let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let LazyViewLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let ViewCannotBeRegisteredMoreThanOnce = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewCannotBeRegisteredMoreThanOnce$impl');
let ViewNotFoundException = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewNotFoundException$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {ViewsRepository}
  */
class InMemoryViewRepository extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HashMap<?string, LazyViewLoader>} */
    this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_;
  }
  
  /**
   * Factory method corresponding to constructor 'InMemoryViewRepository()'.
   * @return {!InMemoryViewRepository}
   * @public
   */
  static $create__() {
    InMemoryViewRepository.$clinit();
    let $instance = new InMemoryViewRepository();
    $instance.$ctor__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InMemoryViewRepository()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository();
  }
  
  /**
   * @override
   * @param {LazyViewLoader} lazyViewLoader
   * @return {void}
   * @public
   */
  m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader(lazyViewLoader) {
    if (this.m_isRegisteredPresenterView__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository(lazyViewLoader.m_getPresenterName__())) {
      throw $Exceptions.toJs(ViewCannotBeRegisteredMoreThanOnce.$create__java_lang_String(lazyViewLoader.m_getPresenterName__()));
    }
    this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_.put(lazyViewLoader.m_getPresenterName__(), lazyViewLoader);
  }
  
  /**
   * @override
   * @param {?string} presenterName
   * @return {View}
   * @public
   */
  m_getView__java_lang_String(presenterName) {
    if (this.m_isRegisteredPresenterView__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository(presenterName)) {
      return /**@type {LazyViewLoader} */ ($Casts.$to(this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_.get(presenterName), LazyViewLoader)).m_getView__();
    }
    throw $Exceptions.toJs(ViewNotFoundException.$create__java_lang_String(presenterName));
  }
  
  /**
   * @param {?string} presenterName
   * @return {LazyViewLoader}
   * @public
   */
  m_getViewLoader__java_lang_String(presenterName) {
    if (this.m_isRegisteredPresenterView__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository(presenterName)) {
      return /**@type {LazyViewLoader} */ ($Casts.$to(this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_.get(presenterName), LazyViewLoader));
    }
    throw $Exceptions.toJs(ViewNotFoundException.$create__java_lang_String(presenterName));
  }
  
  /**
   * @param {?string} presenterName
   * @return {boolean}
   * @public
   */
  m_isRegisteredPresenterView__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository(presenterName) {
    return this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_.containsKey(presenterName);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_.clear();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository() {
    this.f_views__org_dominokit_domino_client_commons_mvp_view_InMemoryViewRepository_ = /**@type {!HashMap<?string, LazyViewLoader>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InMemoryViewRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InMemoryViewRepository);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InMemoryViewRepository.$clinit = function() {};
    HashMap = goog.module.get('java.util.HashMap$impl');
    LazyViewLoader = goog.module.get('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');
    ViewCannotBeRegisteredMoreThanOnce = goog.module.get('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewCannotBeRegisteredMoreThanOnce$impl');
    ViewNotFoundException = goog.module.get('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewNotFoundException$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InMemoryViewRepository, $Util.$makeClassName('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository'));


ViewsRepository.$markImplementor(InMemoryViewRepository);


exports = InMemoryViewRepository; 
//# sourceMappingURL=InMemoryViewRepository.js.map