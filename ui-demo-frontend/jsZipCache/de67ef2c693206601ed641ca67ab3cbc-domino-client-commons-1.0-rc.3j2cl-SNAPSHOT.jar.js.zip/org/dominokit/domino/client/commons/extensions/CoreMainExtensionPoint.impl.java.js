/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MainExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');

let MainContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint.$1$impl');


/**
 * @implements {MainExtensionPoint}
  */
class CoreMainExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CoreMainExtensionPoint()'.
   * @return {!CoreMainExtensionPoint}
   * @public
   */
  static $create__() {
    CoreMainExtensionPoint.$clinit();
    let $instance = new CoreMainExtensionPoint();
    $instance.$ctor__org_dominokit_domino_client_commons_extensions_CoreMainExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CoreMainExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_extensions_CoreMainExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {MainContext}
   * @public
   */
  m_context__() {
    return $1.$create__org_dominokit_domino_client_commons_extensions_CoreMainExtensionPoint(this);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CoreMainExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CoreMainExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CoreMainExtensionPoint.$clinit = function() {};
    $1 = goog.module.get('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint.$1$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CoreMainExtensionPoint, $Util.$makeClassName('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint'));


MainExtensionPoint.$markImplementor(CoreMainExtensionPoint);


exports = CoreMainExtensionPoint; 
//# sourceMappingURL=CoreMainExtensionPoint.js.map