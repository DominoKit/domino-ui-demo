/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ContributionsRepository = goog.require('org.dominokit.domino.api.client.extension.ContributionsRepository');
const _Class = goog.require('java.lang.Class');
const _HashMap = goog.require('java.util.HashMap');
const _HashSet = goog.require('java.util.HashSet');
const _Map = goog.require('java.util.Map');
const _Objects = goog.require('java.util.Objects');
const _Set = goog.require('java.util.Set');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Stream = goog.require('java.util.stream.Stream');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ContributionWrapper = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository.ContributionWrapper');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var InMemoryContributionRepository = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository$impl');
exports = InMemoryContributionRepository;
 