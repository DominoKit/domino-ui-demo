/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _LazyRequestRestSenderLoader = goog.require('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader');
const _RequestRestSender = goog.require('org.dominokit.domino.api.client.request.RequestRestSender');
const _SenderCannotBeRegisteredMoreThanOnce = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderCannotBeRegisteredMoreThanOnce');
const _SenderNotFoundException = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderNotFoundException');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var InMemoryRequestRestSendersRepository = goog.require('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository$impl');
exports = InMemoryRequestRestSendersRepository;
 