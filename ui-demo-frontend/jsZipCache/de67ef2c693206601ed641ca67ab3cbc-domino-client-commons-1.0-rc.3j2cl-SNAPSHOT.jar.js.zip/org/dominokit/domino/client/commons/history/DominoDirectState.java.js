/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.history.DominoDirectState.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.history.DominoDirectState');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DirectState = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectState');
const _DirectUrlHandler = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');


// Re-exports the implementation.
var DominoDirectState = goog.require('org.dominokit.domino.client.commons.history.DominoDirectState$impl');
exports = DominoDirectState;
 