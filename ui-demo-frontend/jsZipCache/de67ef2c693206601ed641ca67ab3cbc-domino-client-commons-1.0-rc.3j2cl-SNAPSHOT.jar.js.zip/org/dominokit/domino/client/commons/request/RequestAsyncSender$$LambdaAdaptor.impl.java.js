/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.RequestAsyncSender$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.RequestAsyncSender.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.RequestAsyncSender$impl');

let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');


/**
 * @implements {RequestAsyncSender}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ServerRequest):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(ServerRequest):void} */
    this.f_$$fn__org_dominokit_domino_client_commons_request_RequestAsyncSender_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_client_commons_request_RequestAsyncSender_$LambdaAdaptor__org_dominokit_domino_client_commons_request_RequestAsyncSender_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ServerRequest):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_RequestAsyncSender_$LambdaAdaptor__org_dominokit_domino_client_commons_request_RequestAsyncSender_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_client_commons_request_RequestAsyncSender_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {ServerRequest} arg0
   * @return {void}
   * @public
   */
  m_send__org_dominokit_domino_api_client_request_ServerRequest(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_client_commons_request_RequestAsyncSender_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.client.commons.request.RequestAsyncSender$$LambdaAdaptor'));


RequestAsyncSender.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=RequestAsyncSender$$LambdaAdaptor.js.map