package org.dominokit.domino.advancedforms.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.forms.shared.extension.FormsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class AdvancedFormsPresenterContributionToFormsExtensionPoint implements Contribution<FormsExtensionPoint> {
  @Override
  public void contribute(FormsExtensionPoint extensionPoint) {
    new AdvancedFormsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToMainModule(extensionPoint.context())).send();
  }
}
