/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AdvancedFormsView = goog.require('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _File_$Overlay = goog.require('elemental2.dom.File.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _XMLHttpRequest_$Overlay = goog.require('elemental2.dom.XMLHttpRequest.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeResource = goog.require('org.dominokit.domino.advancedforms.client.views.CodeResource');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _FileItem = goog.require('org.dominokit.domino.ui.upload.FileItem');
const _ErrorHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.ErrorHandler');
const _RemoveFileHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler');
const _SuccessUploadHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.SuccessUploadHandler');
const _FileUpload = goog.require('org.dominokit.domino.ui.upload.FileUpload');
const _OnAddFileHandler = goog.require('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AdvancedFormsViewImpl = goog.require('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl$impl');
exports = AdvancedFormsViewImpl;
 