/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.views.ui.IconsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.icons.client.views.ui.IconsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _IconsView = goog.require('org.dominokit.domino.icons.client.views.IconsView');
const _ClipboardEvent_$Overlay = goog.require('elemental2.dom.ClipboardEvent.$Overlay');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLInputElement_$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _HTMLParagraphElement_$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.icons.client.views.ui.IconsViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.icons.client.views.ui.IconsViewImpl.$LambdaAdaptor$2');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _InputType = goog.require('org.jboss.gwt.elemento.core.InputType');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _InputBuilder = goog.require('org.jboss.gwt.elemento.core.builder.InputBuilder');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var IconsViewImpl = goog.require('org.dominokit.domino.icons.client.views.ui.IconsViewImpl$impl');
exports = IconsViewImpl;
 