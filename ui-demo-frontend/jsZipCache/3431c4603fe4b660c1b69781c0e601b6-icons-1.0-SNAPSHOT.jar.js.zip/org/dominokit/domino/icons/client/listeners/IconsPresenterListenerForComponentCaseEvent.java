package org.dominokit.domino.icons.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;
import org.dominokit.domino.icons.client.presenters.IconsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class IconsPresenterListenerForComponentCaseEvent implements DominoEventListener<ComponentCaseEvent> {
  @Override
  public void listen(ComponentCaseEvent event) {
    new IconsPresenterCommand().onPresenterReady(presenter -> presenter.onComponentsEvent(event.context())).send();
  }
}
