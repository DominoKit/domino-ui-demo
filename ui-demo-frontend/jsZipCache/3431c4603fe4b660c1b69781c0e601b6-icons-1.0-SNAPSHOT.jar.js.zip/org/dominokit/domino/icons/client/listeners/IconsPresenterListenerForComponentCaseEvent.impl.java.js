/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.listeners.IconsPresenterListenerForComponentCaseEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.icons.client.listeners.IconsPresenterListenerForComponentCaseEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let IconsPresenter = goog.forwardDeclare('org.dominokit.domino.icons.client.presenters.IconsPresenter$impl');
let IconsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.icons.client.presenters.IconsPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentCaseEvent>}
  */
class IconsPresenterListenerForComponentCaseEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'IconsPresenterListenerForComponentCaseEvent()'.
   * @return {!IconsPresenterListenerForComponentCaseEvent}
   * @public
   */
  static $create__() {
    IconsPresenterListenerForComponentCaseEvent.$clinit();
    let $instance = new IconsPresenterListenerForComponentCaseEvent();
    $instance.$ctor__org_dominokit_domino_icons_client_listeners_IconsPresenterListenerForComponentCaseEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconsPresenterListenerForComponentCaseEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_icons_client_listeners_IconsPresenterListenerForComponentCaseEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(event) {
    IconsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** IconsPresenter */ presenter) =>{
      presenter.m_onComponentsEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(event.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(/**@type {ComponentCaseEvent} */ ($Casts.$to(arg0, ComponentCaseEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IconsPresenterListenerForComponentCaseEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IconsPresenterListenerForComponentCaseEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IconsPresenterListenerForComponentCaseEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    IconsPresenterCommand = goog.module.get('org.dominokit.domino.icons.client.presenters.IconsPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IconsPresenterListenerForComponentCaseEvent, $Util.$makeClassName('org.dominokit.domino.icons.client.listeners.IconsPresenterListenerForComponentCaseEvent'));


DominoEventListener.$markImplementor(IconsPresenterListenerForComponentCaseEvent);


exports = IconsPresenterListenerForComponentCaseEvent; 
//# sourceMappingURL=IconsPresenterListenerForComponentCaseEvent.js.map