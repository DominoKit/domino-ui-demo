/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.views.ui.BadgesViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.badges.client.views.ui.BadgesViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BadgesView = goog.require('org.dominokit.domino.badges.client.views.BadgesView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeResource = goog.require('org.dominokit.domino.badges.client.views.CodeResource');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _ListGroup = goog.require('org.dominokit.domino.ui.lists.ListGroup');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BadgesViewImpl = goog.require('org.dominokit.domino.badges.client.views.ui.BadgesViewImpl$impl');
exports = BadgesViewImpl;
 