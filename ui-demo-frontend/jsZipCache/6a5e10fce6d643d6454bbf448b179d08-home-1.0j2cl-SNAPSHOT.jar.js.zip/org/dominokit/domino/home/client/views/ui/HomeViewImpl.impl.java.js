/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.views.ui.HomeViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.home.client.views.ui.HomeViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const HomeView = goog.require('org.dominokit.domino.home.client.views.HomeView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {HomeView}
  */
class HomeViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'HomeViewImpl()'.
   * @return {!HomeViewImpl}
   * @public
   */
  static $create__() {
    HomeViewImpl.$clinit();
    let $instance = new HomeViewImpl();
    $instance.$ctor__org_dominokit_domino_home_client_views_ui_HomeViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HomeViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_home_client_views_ui_HomeViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_home_client_views_ui_HomeViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    window.console.info("hhhhhhhhhhhhhhhhhhhhhoooooommmmmmmmmeeeeee");
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("SETUP", "Steps required to start working with domino ui components").m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(Card.m_createCodeCard__java_lang_String("<dependency>\n" + "  <groupId>org.dominokit</groupId>\n" + "  <artifactId>domino-ui</artifactId>\n" + "  <version>1.0-SNAPSHOT</version>\n" + "</dependency>\n" + "<dependency>\n" + "  <groupId>org.dominokit</groupId>\n" + "  <artifactId>domino-ui</artifactId>\n" + "  <version>1.0-SNAPSHOT</version>\n" + "  <classifier>sources</classifier>\n" + "</dependency>").m_setTitle__java_lang_String("Maven dependencies").m_expand__().m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(Card.m_createCodeCard__java_lang_String("<inherits name=\"org.dominokit.domino.ui.DominoUI\"/>").m_setTitle__java_lang_String("GWT module inheritance").m_expand__().m_asElement__());
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_.appendChild(Card.m_createCodeCard__java_lang_String("<meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">\n" + "\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/font/material-icons.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/plugins/bootstrap/css/bootstrap.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/plugins/node-waves/waves.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/plugins/animate-css/animate.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/plugins/waitme/waitMe.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/css/style.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"/{module-short-name}/css/themes/all-themes.css\">").m_setTitle__java_lang_String("Html page required imports").m_setDescription__java_lang_String("The path depends on your module and index page setup.").m_expand__().m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_home_client_views_ui_HomeViewImpl() {
    this.f_element__org_dominokit_domino_home_client_views_ui_HomeViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HomeViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HomeViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HomeViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HomeViewImpl, $Util.$makeClassName('org.dominokit.domino.home.client.views.ui.HomeViewImpl'));


HomeView.$markImplementor(HomeViewImpl);


exports = HomeViewImpl; 
//# sourceMappingURL=HomeViewImpl.js.map