/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.thumbnails.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_thumbnails_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_thumbnails_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_basicSample__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"DEFAULT EXAMPLE\", \"By default, thumbnails are designed to showcase linked images with minimal required markup\")\n" + "    .appendContent(Row.create()\n" + "            .addColumn(column.copy().addElement(Thumbnail.create()\n" + "                    .setContent(a()\n" + "                            .add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/5.jpg\")\n" + "                                    .css(Styles.img_responsive).asElement())\n" + "                            .asElement())\n" + "                    .asElement()))\n" + "            .addColumn(column.copy().addElement(Thumbnail.create()\n" + "                    .setContent(a()\n" + "                            .add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/6.jpg\")\n" + "                                    .css(Styles.img_responsive).asElement())\n" + "                            .asElement())\n" + "                    .asElement()))\n" + "            .addColumn(column.copy().addElement(Thumbnail.create()\n" + "                    .setContent(a()\n" + "                            .add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/7.jpg\")\n" + "                                    .css(Styles.img_responsive).asElement())\n" + "                            .asElement())\n" + "                    .asElement()))\n" + "            .addColumn(column.copy().addElement(Thumbnail.create()\n" + "                    .setContent(a()\n" + "                            .add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/8.jpg\")\n" + "                                    .css(Styles.img_responsive).asElement())\n" + "                            .asElement())\n" + "                    .asElement()))\n" + "            .asElement())\n" + "    .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_withExtraContentSample__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"CUSTOM CONTENT\", \"With a bit of extra markup, it's possible to add any kind of HTML content like headings, paragraphs, or buttons into thumbnails.\")\n" + "    .appendContent(Row.create()\n" + "            .addColumn(column.copy()\n" + "                    .addElement(Thumbnail.create()\n" + "                            .setContent(a().add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/1.jpg\")\n" + "                                    .css(Styles.img_responsive)\n" + "                                    .asElement())\n" + "                                    .asElement())\n" + "                            .appendCaptionContent(h(3).textContent(\"Thumbnail label\").asElement())\n" + "                            .appendCaptionContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                            .appendCaptionContent(Button.createPrimary(\"BUTTON\").asElement())\n" + "                            .asElement()))\n" + "            .addColumn(column.copy()\n" + "                    .addElement(Thumbnail.create()\n" + "                            .setContent(a().add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/2.jpg\")\n" + "                                    .css(Styles.img_responsive)\n" + "                                    .asElement())\n" + "                                    .asElement())\n" + "                            .appendCaptionContent(h(3).textContent(\"Thumbnail label\").asElement())\n" + "                            .appendCaptionContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                            .appendCaptionContent(Button.createPrimary(\"BUTTON\").asElement())\n" + "                            .asElement()))\n" + "            .addColumn(column.copy()\n" + "                    .addElement(Thumbnail.create()\n" + "                            .setContent(a().add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/3.jpg\")\n" + "                                    .css(Styles.img_responsive)\n" + "                                    .asElement())\n" + "                                    .asElement())\n" + "                            .appendCaptionContent(h(3).textContent(\"Thumbnail label\").asElement())\n" + "                            .appendCaptionContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                            .appendCaptionContent(Button.createPrimary(\"BUTTON\").asElement())\n" + "                            .asElement()))\n" + "            .addColumn(column.copy()\n" + "                    .addElement(Thumbnail.create()\n" + "                            .setContent(a().add(img(GWT.getModuleBaseURL() + \"/images/image-gallery/4.jpg\")\n" + "                                    .css(Styles.img_responsive)\n" + "                                    .asElement())\n" + "                                    .asElement())\n" + "                            .appendCaptionContent(h(3).textContent(\"Thumbnail label\").asElement())\n" + "                            .appendCaptionContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                            .appendCaptionContent(Button.createPrimary(\"BUTTON\").asElement())\n" + "                            .asElement()))\n" + "            .asElement())\n" + "    .asElement());";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.thumbnails.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map