/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.popover.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_popover_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_popover_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_tooltips__() {
    CodeResource.$clinit();
    return "HTMLElement tooltip_on_right = Button.createPrimary(\"TOOLTIP ON RIGHT\").block().asElement();\n" + "\n" + "Tooltip.create(tooltip_on_right, \"Tooltip on right\")\n" + "        .position(PopupPosition.RIGHT);\n" + "\n" + "HTMLElement tooltip_on_top = Button.createPrimary(\"TOOLTIP ON TOP\").block().asElement();\n" + "\n" + "Tooltip.create(tooltip_on_top, \"Tooltip on top\")\n" + "        .position(PopupPosition.TOP);\n" + "\n" + "HTMLElement tooltip_on_bottom = Button.createPrimary(\"TOOLTIP ON BOTTOM\").block().asElement();\n" + "\n" + "Tooltip.create(tooltip_on_bottom, \"Tooltip on bottom\")\n" + "        .position(PopupPosition.BOTTOM);\n" + "\n" + "HTMLElement tooltip_on_left = Button.createPrimary(\"TOOLTIP ON LEFT\").block().asElement();\n" + "\n" + "Tooltip.create(tooltip_on_left, \"Tooltip on left\")\n" + "        .position(PopupPosition.LEFT);\n" + "\n" + "element.appendChild(Card.create(\"TOOLTIPS\")\n" + "        .appendContent(Row.create()\n" + "                .addColumn(column.copy()\n" + "                        .addElement(tooltip_on_right))\n" + "                .addColumn(column.copy()\n" + "                        .addElement(tooltip_on_top))\n" + "                .addColumn(column.copy()\n" + "                        .addElement(tooltip_on_bottom))\n" + "                .addColumn(column.copy()\n" + "                        .addElement(tooltip_on_left))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_popover__() {
    CodeResource.$clinit();
    return "HTMLElement popover_on_right = Button.createPrimary(\"POPOVER ON RIGHT\").block().asElement();\n" + "\n" + "Popover.create(popover_on_right, \"Popover on right\", Paragraph.create(\"Vivamus sagittis lacus vel augue laoreet rutrum faucibus.\").asElement())\n" + "        .position(PopupPosition.RIGHT);\n" + "\n" + "HTMLElement popover_on_top = Button.createPrimary(\"POPOVER ON TOP\").block().asElement();\n" + "\n" + "Popover.create(popover_on_top, \"Popover on right\", Paragraph.create(\"Vivamus sagittis lacus vel augue laoreet rutrum faucibus.\").asElement())\n" + "        .position(PopupPosition.TOP);\n" + "\n" + "HTMLElement popover_on_bottom = Button.createPrimary(\"POPOVER ON BOTTOM\").block().asElement();\n" + "\n" + "Popover.create(popover_on_bottom, \"Popover on right\", Paragraph.create(\"Vivamus sagittis lacus vel augue laoreet rutrum faucibus.\").asElement())\n" + "        .position(PopupPosition.BOTTOM);\n" + "\n" + "HTMLElement popover_on_left = Button.createPrimary(\"POPOVER ON LEFT\").block().asElement();\n" + "\n" + "Popover.create(popover_on_left, \"Popover on right\", Paragraph.create(\"Vivamus sagittis lacus vel augue laoreet rutrum faucibus.\").asElement())\n" + "        .position(PopupPosition.LEFT);\n" + "\n" + "element.appendChild(Card.create(\"POPOVER\")\n" + "        .appendContent(Row.create()\n" + "                .addColumn(column.copy()\n" + "                        .addElement(popover_on_right))\n" + "                .addColumn(column.copy()\n" + "                        .addElement(popover_on_top))\n" + "                .addColumn(column.copy()\n" + "                        .addElement(popover_on_bottom))\n" + "                .addColumn(column.copy()\n" + "                        .addElement(popover_on_left))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.popover.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map