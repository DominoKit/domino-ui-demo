/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ButtonsView = goog.require('org.dominokit.domino.buttons.client.views.ButtonsView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _Integer = goog.require('java.lang.Integer');
const _Consumer = goog.require('java.util.function.Consumer');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _ButtonSize = goog.require('org.dominokit.domino.ui.button.ButtonSize');
const _ButtonsToolbar = goog.require('org.dominokit.domino.ui.button.ButtonsToolbar');
const _CircleSize = goog.require('org.dominokit.domino.ui.button.CircleSize');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');
const _SplitButton = goog.require('org.dominokit.domino.ui.button.SplitButton');
const _ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _DropDownPosition = goog.require('org.dominokit.domino.ui.dropdown.DropDownPosition');
const _DropdownAction = goog.require('org.dominokit.domino.ui.dropdown.DropdownAction');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Unit = goog.require('org.dominokit.domino.ui.style.Unit');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ButtonsViewImpl = goog.require('org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl$impl');
exports = ButtonsViewImpl;
 