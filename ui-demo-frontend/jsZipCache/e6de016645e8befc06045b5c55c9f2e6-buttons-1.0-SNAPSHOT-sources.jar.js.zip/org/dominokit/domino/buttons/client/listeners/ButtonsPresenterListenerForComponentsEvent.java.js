/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.listeners.ButtonsPresenterListenerForComponentsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.buttons.client.listeners.ButtonsPresenterListenerForComponentsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ButtonsPresenter = goog.require('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter');
const _ButtonsPresenterCommand = goog.require('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ButtonsPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.buttons.client.listeners.ButtonsPresenterListenerForComponentsEvent$impl');
exports = ButtonsPresenterListenerForComponentsEvent;
 