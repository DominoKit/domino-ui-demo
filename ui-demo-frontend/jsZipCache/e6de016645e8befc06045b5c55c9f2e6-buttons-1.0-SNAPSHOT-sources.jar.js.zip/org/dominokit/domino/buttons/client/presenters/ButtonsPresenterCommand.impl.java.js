/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ButtonsPresenter = goog.forwardDeclare('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter$impl');


/**
 * @extends {PresenterCommand<ButtonsPresenter>}
  */
class ButtonsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ButtonsPresenterCommand()'.
   * @return {!ButtonsPresenterCommand}
   * @public
   */
  static $create__() {
    ButtonsPresenterCommand.$clinit();
    let $instance = new ButtonsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_buttons_client_presenters_ButtonsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ButtonsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_buttons_client_presenters_ButtonsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ButtonsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ButtonsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand'));




exports = ButtonsPresenterCommand; 
//# sourceMappingURL=ButtonsPresenterCommand.js.map