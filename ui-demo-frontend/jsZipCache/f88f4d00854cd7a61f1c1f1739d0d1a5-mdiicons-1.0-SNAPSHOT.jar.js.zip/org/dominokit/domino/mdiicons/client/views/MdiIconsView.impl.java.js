/**
 * @fileoverview transpiled from org.dominokit.domino.mdiicons.client.views.MdiIconsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.mdiicons.client.views.MdiIconsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.views.MdiIconsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class MdiIconsView {
  /**
   * @abstract
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
  }
  
  /**
   * @param {?function():Content} fn
   * @return {MdiIconsView}
   * @public
   */
  static $adapt(fn) {
    MdiIconsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_mdiicons_client_views_MdiIconsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_mdiicons_client_views_MdiIconsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_mdiicons_client_views_MdiIconsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MdiIconsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.mdiicons.client.views.MdiIconsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MdiIconsView, $Util.$makeClassName('org.dominokit.domino.mdiicons.client.views.MdiIconsView'));


MdiIconsView.$markImplementor(/** @type {Function} */ (MdiIconsView));


exports = MdiIconsView; 
//# sourceMappingURL=MdiIconsView.js.map