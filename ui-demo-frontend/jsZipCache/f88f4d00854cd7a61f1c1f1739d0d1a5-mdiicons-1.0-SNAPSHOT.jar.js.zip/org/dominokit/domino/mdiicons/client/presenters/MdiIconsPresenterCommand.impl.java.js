/**
 * @fileoverview transpiled from org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let MdiIconsPresenter = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter$impl');


/**
 * @extends {PresenterCommand<MdiIconsPresenter>}
  */
class MdiIconsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MdiIconsPresenterCommand()'.
   * @return {!MdiIconsPresenterCommand}
   * @public
   */
  static $create__() {
    MdiIconsPresenterCommand.$clinit();
    let $instance = new MdiIconsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MdiIconsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MdiIconsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MdiIconsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MdiIconsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MdiIconsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenterCommand'));




exports = MdiIconsPresenterCommand; 
//# sourceMappingURL=MdiIconsPresenterCommand.js.map