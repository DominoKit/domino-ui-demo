/**
 * @fileoverview transpiled from org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter.$1$impl');
let MdiIconsView = goog.forwardDeclare('org.dominokit.domino.mdiicons.client.views.MdiIconsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<MdiIconsView>}
  */
class MdiIconsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MdiIconsPresenter()'.
   * @return {!MdiIconsPresenter}
   * @public
   */
  static $create__() {
    MdiIconsPresenter.$clinit();
    let $instance = new MdiIconsPresenter();
    $instance.$ctor__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MdiIconsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_listenToComponentsCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter_() {
    return (MdiIconsPresenter.$clinit(), MdiIconsPresenter.$f_LOGGER__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter_(value) {
    (MdiIconsPresenter.$clinit(), MdiIconsPresenter.$f_LOGGER__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MdiIconsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MdiIconsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MdiIconsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    MdiIconsPresenter.$f_LOGGER__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(MdiIconsPresenter));
  }
  
  
};

$Util.$setClassMetadata(MdiIconsPresenter, $Util.$makeClassName('org.dominokit.domino.mdiicons.client.presenters.MdiIconsPresenter'));


/** @private {Logger} */
MdiIconsPresenter.$f_LOGGER__org_dominokit_domino_mdiicons_client_presenters_MdiIconsPresenter_;




exports = MdiIconsPresenter; 
//# sourceMappingURL=MdiIconsPresenter.js.map