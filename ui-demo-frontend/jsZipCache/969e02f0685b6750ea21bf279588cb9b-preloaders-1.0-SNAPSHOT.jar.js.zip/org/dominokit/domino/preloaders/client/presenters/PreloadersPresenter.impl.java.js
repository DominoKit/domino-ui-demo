/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter.$1$impl');
let PreloadersView = goog.forwardDeclare('org.dominokit.domino.preloaders.client.views.PreloadersView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<PreloadersView>}
  */
class PreloadersPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PreloadersPresenter()'.
   * @return {!PreloadersPresenter}
   * @public
   */
  static $create__() {
    PreloadersPresenter.$clinit();
    let $instance = new PreloadersPresenter();
    $instance.$ctor__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PreloadersPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_onComponentsEvent__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter_() {
    return (PreloadersPresenter.$clinit(), PreloadersPresenter.$f_LOGGER__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter_(value) {
    (PreloadersPresenter.$clinit(), PreloadersPresenter.$f_LOGGER__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PreloadersPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PreloadersPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PreloadersPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    PreloadersPresenter.$f_LOGGER__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(PreloadersPresenter));
  }
  
  
};

$Util.$setClassMetadata(PreloadersPresenter, $Util.$makeClassName('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter'));


/** @private {Logger} */
PreloadersPresenter.$f_LOGGER__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenter_;




exports = PreloadersPresenter; 
//# sourceMappingURL=PreloadersPresenter.js.map