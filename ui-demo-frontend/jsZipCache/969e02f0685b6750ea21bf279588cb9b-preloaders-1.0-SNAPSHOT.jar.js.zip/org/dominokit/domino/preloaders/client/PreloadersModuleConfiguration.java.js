/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.PreloadersModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.preloaders.client.PreloadersModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');
const _$1 = goog.require('org.dominokit.domino.preloaders.client.PreloadersModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.preloaders.client.PreloadersModuleConfiguration.$2');
const _PreloadersPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.preloaders.client.listeners.PreloadersPresenterListenerForComponentsEvent');
const _PreloadersPresenter = goog.require('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter');
const _PreloadersPresenterCommand = goog.require('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand');


// Re-exports the implementation.
var PreloadersModuleConfiguration = goog.require('org.dominokit.domino.preloaders.client.PreloadersModuleConfiguration$impl');
exports = PreloadersModuleConfiguration;
 