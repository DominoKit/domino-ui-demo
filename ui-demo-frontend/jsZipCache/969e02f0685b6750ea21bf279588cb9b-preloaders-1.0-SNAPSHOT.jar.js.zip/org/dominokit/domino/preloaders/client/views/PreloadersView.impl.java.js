/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.views.PreloadersView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.preloaders.client.views.PreloadersView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.preloaders.client.views.PreloadersView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class PreloadersView {
  /**
   * @param {?function():Content} fn
   * @return {PreloadersView}
   * @public
   */
  static $adapt(fn) {
    PreloadersView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_preloaders_client_views_PreloadersView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_preloaders_client_views_PreloadersView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_preloaders_client_views_PreloadersView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PreloadersView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.preloaders.client.views.PreloadersView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(PreloadersView, $Util.$makeClassName('org.dominokit.domino.preloaders.client.views.PreloadersView'));


PreloadersView.$markImplementor(/** @type {Function} */ (PreloadersView));


exports = PreloadersView; 
//# sourceMappingURL=PreloadersView.js.map