/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _$1 = goog.require('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter.$1');
const _PreloadersView = goog.require('org.dominokit.domino.preloaders.client.views.PreloadersView');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var PreloadersPresenter = goog.require('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter$impl');
exports = PreloadersPresenter;
 