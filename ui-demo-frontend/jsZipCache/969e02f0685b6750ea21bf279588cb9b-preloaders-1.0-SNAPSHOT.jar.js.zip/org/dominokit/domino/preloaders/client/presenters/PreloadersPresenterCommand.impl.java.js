/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let PreloadersPresenter = goog.forwardDeclare('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter$impl');


/**
 * @extends {PresenterCommand<PreloadersPresenter>}
  */
class PreloadersPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PreloadersPresenterCommand()'.
   * @return {!PreloadersPresenterCommand}
   * @public
   */
  static $create__() {
    PreloadersPresenterCommand.$clinit();
    let $instance = new PreloadersPresenterCommand();
    $instance.$ctor__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PreloadersPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_preloaders_client_presenters_PreloadersPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PreloadersPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PreloadersPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PreloadersPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PreloadersPresenterCommand, $Util.$makeClassName('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand'));




exports = PreloadersPresenterCommand; 
//# sourceMappingURL=PreloadersPresenterCommand.js.map