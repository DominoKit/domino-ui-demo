/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.PreloadersClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.preloaders.client.PreloadersClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class PreloadersClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PreloadersClientModule()'.
   * @return {!PreloadersClientModule}
   * @public
   */
  static $create__() {
    PreloadersClientModule.$clinit();
    let $instance = new PreloadersClientModule();
    $instance.$ctor__org_dominokit_domino_preloaders_client_PreloadersClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PreloadersClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_preloaders_client_PreloadersClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    PreloadersClientModule.$f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_.m_info__java_lang_String("Initializing Preloaders frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_() {
    return (PreloadersClientModule.$clinit(), PreloadersClientModule.$f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_(value) {
    (PreloadersClientModule.$clinit(), PreloadersClientModule.$f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PreloadersClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PreloadersClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PreloadersClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    PreloadersClientModule.$f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(PreloadersClientModule));
  }
  
  
};

$Util.$setClassMetadata(PreloadersClientModule, $Util.$makeClassName('org.dominokit.domino.preloaders.client.PreloadersClientModule'));


/** @private {Logger} */
PreloadersClientModule.$f_LOGGER__org_dominokit_domino_preloaders_client_PreloadersClientModule_;




exports = PreloadersClientModule; 
//# sourceMappingURL=PreloadersClientModule.js.map