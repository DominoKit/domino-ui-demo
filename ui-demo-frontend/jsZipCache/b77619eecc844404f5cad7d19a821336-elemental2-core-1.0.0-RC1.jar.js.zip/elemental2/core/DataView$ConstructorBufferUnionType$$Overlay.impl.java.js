/**
 * @fileoverview transpiled from elemental2.core.DataView$ConstructorBufferUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.DataView.ConstructorBufferUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.ArrayBuffer.$Overlay$impl');
let SharedArrayBuffer_$Overlay = goog.forwardDeclare('elemental2.core.SharedArrayBuffer.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ConstructorBufferUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ConstructorBufferUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ConstructorBufferUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {ArrayBuffer}
   * @public
   */
  static m_asArrayBuffer__elemental2_core_DataView_ConstructorBufferUnionType($thisArg) {
    ConstructorBufferUnionType_$Overlay.$clinit();
    return /**@type {ArrayBuffer} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {SharedArrayBuffer}
   * @public
   */
  static m_asSharedArrayBuffer__elemental2_core_DataView_ConstructorBufferUnionType($thisArg) {
    ConstructorBufferUnionType_$Overlay.$clinit();
    return /**@type {SharedArrayBuffer} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), SharedArrayBuffer_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isArrayBuffer__elemental2_core_DataView_ConstructorBufferUnionType($thisArg) {
    ConstructorBufferUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isSharedArrayBuffer__elemental2_core_DataView_ConstructorBufferUnionType($thisArg) {
    ConstructorBufferUnionType_$Overlay.$clinit();
    return SharedArrayBuffer_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ConstructorBufferUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.core.ArrayBuffer.$Overlay$impl');
    SharedArrayBuffer_$Overlay = goog.module.get('elemental2.core.SharedArrayBuffer.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ConstructorBufferUnionType_$Overlay, $Util.$makeClassName('?'));


exports = ConstructorBufferUnionType_$Overlay; 
//# sourceMappingURL=DataView$ConstructorBufferUnionType$$Overlay.js.map