/**
 * @fileoverview transpiled from elemental2.core.JsSet$ConstructorIterableUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsSet.ConstructorIterableUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsIterable.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ConstructorIterableUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ConstructorIterableUnionType_$Overlay));
  }
  
  /**
   * @template C_ConstructorIterableUnionType_VALUE
   * @param {?} $thisArg
   * @return {Iterable<C_ConstructorIterableUnionType_VALUE>}
   * @public
   */
  static m_asJsIterable__elemental2_core_JsSet_ConstructorIterableUnionType($thisArg) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return /**@type {Iterable<*>} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @template C_ConstructorIterableUnionType_VALUE
   * @param {?} $thisArg
   * @return {Array<C_ConstructorIterableUnionType_VALUE>}
   * @public
   */
  static m_asVALUEArray__elemental2_core_JsSet_ConstructorIterableUnionType($thisArg) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return /**@type {Array<*>} */ ($Arrays.$castTo(Js.m_cast__java_lang_Object($thisArg), j_l_Object, 1));
  }
  
  /**
   * @template C_ConstructorIterableUnionType_VALUE
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isVALUEArray__elemental2_core_JsSet_ConstructorIterableUnionType($thisArg) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ConstructorIterableUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.core.JsIterable.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ConstructorIterableUnionType_$Overlay, $Util.$makeClassName('?'));


exports = ConstructorIterableUnionType_$Overlay; 
//# sourceMappingURL=JsSet$ConstructorIterableUnionType$$Overlay.js.map