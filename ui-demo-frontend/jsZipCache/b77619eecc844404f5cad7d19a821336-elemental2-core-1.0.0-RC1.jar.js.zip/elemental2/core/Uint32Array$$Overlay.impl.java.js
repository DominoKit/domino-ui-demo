/**
 * @fileoverview transpiled from elemental2.core.Uint32Array$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Uint32Array.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_BYTES_PER_ELEMENT__elemental2_core_Uint32Array_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Uint32Array_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_BYTES_PER_ELEMENT__elemental2_core_Uint32Array_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Uint32Array_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Uint32Array;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
    $Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Uint32Array_$Overlay = Uint32Array.BYTES_PER_ELEMENT;
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('Uint32Array'));


/** @private {number} */
$Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Uint32Array_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=Uint32Array$$Overlay.js.map