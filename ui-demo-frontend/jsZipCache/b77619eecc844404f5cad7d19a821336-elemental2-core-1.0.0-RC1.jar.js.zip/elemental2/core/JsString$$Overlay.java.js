/**
 * @fileoverview transpiled from elemental2.core.JsString$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.JsString.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.JsObject.$Overlay');
const _JsRegExp_$Overlay = goog.require('elemental2.core.JsRegExp.$Overlay');
const _LocaleCompareLocalesUnionType_$Overlay = goog.require('elemental2.core.JsString.LocaleCompareLocalesUnionType.$Overlay');
const _ReplacePatternUnionType_$Overlay = goog.require('elemental2.core.JsString.ReplacePatternUnionType.$Overlay');
const _ReplaceReplacementUnionType_$Overlay = goog.require('elemental2.core.JsString.ReplaceReplacementUnionType.$Overlay');
const _SearchPatternUnionType_$Overlay = goog.require('elemental2.core.JsString.SearchPatternUnionType.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var JsString_$Overlay = goog.require('elemental2.core.JsString.$Overlay$impl');
exports = JsString_$Overlay;
 