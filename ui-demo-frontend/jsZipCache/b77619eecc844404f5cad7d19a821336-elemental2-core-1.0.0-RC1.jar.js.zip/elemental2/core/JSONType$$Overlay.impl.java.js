/**
 * @fileoverview transpiled from elemental2.core.JSONType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JSONType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JSONType.StringifyReplacerUnionType.$Overlay$impl');
let StringifySpaceUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JSONType.StringifySpaceUnionType.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class JSONType_$Overlay {
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {Array<?string>} replacer
   * @param {?string} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__arrayOf_java_lang_String__java_lang_String($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(space)));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {Array<?string>} replacer
   * @param {?} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__arrayOf_java_lang_String__elemental2_core_JSONType_StringifySpaceUnionType($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)), space);
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {Array<?string>} replacer
   * @param {number} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__arrayOf_java_lang_String__int($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(Integer.m_valueOf__int(space))));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {Array<?string>} replacer
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__arrayOf_java_lang_String($thisArg, jsonObj, replacer) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {?function(?string, *):*} replacer
   * @param {?string} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__elemental2_core_JSONType_StringifyReplacerFn__java_lang_String($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(space)));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {?function(?string, *):*} replacer
   * @param {?} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__elemental2_core_JSONType_StringifyReplacerFn__elemental2_core_JSONType_StringifySpaceUnionType($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)), space);
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {?function(?string, *):*} replacer
   * @param {number} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__elemental2_core_JSONType_StringifyReplacerFn__int($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(Integer.m_valueOf__int(space))));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {?function(?string, *):*} replacer
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__elemental2_core_JSONType_StringifyReplacerFn($thisArg, jsonObj, replacer) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(replacer)));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {?} replacer
   * @param {?string} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__elemental2_core_JSONType_StringifyReplacerUnionType__java_lang_String($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, replacer, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(space)));
  }
  
  /**
   * @param {JSONType} $thisArg
   * @param {*} jsonObj
   * @param {?} replacer
   * @param {number} space
   * @return {?string}
   * @public
   */
  static m_stringify__elemental2_core_JSONType__java_lang_Object__elemental2_core_JSONType_StringifyReplacerUnionType__int($thisArg, jsonObj, replacer, space) {
    JSONType_$Overlay.$clinit();
    return $thisArg.stringify(jsonObj, replacer, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(Integer.m_valueOf__int(space))));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JSONType;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JSONType_$Overlay.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JSONType_$Overlay, $Util.$makeClassName('JSONType'));


exports = JSONType_$Overlay; 
//# sourceMappingURL=JSONType$$Overlay.js.map