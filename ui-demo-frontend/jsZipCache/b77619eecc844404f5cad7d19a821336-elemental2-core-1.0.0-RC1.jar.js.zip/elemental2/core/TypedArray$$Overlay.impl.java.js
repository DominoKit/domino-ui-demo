/**
 * @fileoverview transpiled from elemental2.core.TypedArray$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.TypedArray.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ArrayBufferView_$Overlay = goog.forwardDeclare('elemental2.core.ArrayBufferView.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.core.TypedArray.SetArrayUnionType.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class TypedArray_$Overlay {
  /**
   * @param {TypedArray} $thisArg
   * @param {ArrayBufferView} array
   * @param {number} offset
   * @return {void}
   * @public
   */
  static m_set__elemental2_core_TypedArray__elemental2_core_ArrayBufferView__int($thisArg, array, offset) {
    TypedArray_$Overlay.$clinit();
    $thisArg.set(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(array)), offset);
  }
  
  /**
   * @param {TypedArray} $thisArg
   * @param {ArrayBufferView} array
   * @return {void}
   * @public
   */
  static m_set__elemental2_core_TypedArray__elemental2_core_ArrayBufferView($thisArg, array) {
    TypedArray_$Overlay.$clinit();
    $thisArg.set(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(array)));
  }
  
  /**
   * @param {TypedArray} $thisArg
   * @param {Array<number>} array
   * @param {number} offset
   * @return {void}
   * @public
   */
  static m_set__elemental2_core_TypedArray__arrayOf_double__int($thisArg, array, offset) {
    TypedArray_$Overlay.$clinit();
    $thisArg.set(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(array)), offset);
  }
  
  /**
   * @param {TypedArray} $thisArg
   * @param {Array<number>} array
   * @return {void}
   * @public
   */
  static m_set__elemental2_core_TypedArray__arrayOf_double($thisArg, array) {
    TypedArray_$Overlay.$clinit();
    $thisArg.set(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(array)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypedArray;
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypedArray_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(TypedArray_$Overlay, $Util.$makeClassName('TypedArray'));


exports = TypedArray_$Overlay; 
//# sourceMappingURL=TypedArray$$Overlay.js.map