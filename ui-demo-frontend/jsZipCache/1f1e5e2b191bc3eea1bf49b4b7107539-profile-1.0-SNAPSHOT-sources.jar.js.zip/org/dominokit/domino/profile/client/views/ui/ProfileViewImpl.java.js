/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ui.ProfileViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent');
const _CreateHandler = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _DropdownAction = goog.require('org.dominokit.domino.ui.dropdown.DropdownAction');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ProfileViewImpl = goog.require('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl$impl');
exports = ProfileViewImpl;
 