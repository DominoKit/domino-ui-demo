/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.listeners.ProfilePresenterListenerForLayoutEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.listeners.ProfilePresenterListenerForLayoutEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutEvent = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
let ProfilePresenter = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');
let ProfilePresenterCommand = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<LayoutEvent>}
  */
class ProfilePresenterListenerForLayoutEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProfilePresenterListenerForLayoutEvent()'.
   * @return {!ProfilePresenterListenerForLayoutEvent}
   * @public
   */
  static $create__() {
    ProfilePresenterListenerForLayoutEvent.$clinit();
    let $instance = new ProfilePresenterListenerForLayoutEvent();
    $instance.$ctor__org_dominokit_domino_profile_client_listeners_ProfilePresenterListenerForLayoutEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfilePresenterListenerForLayoutEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_listeners_ProfilePresenterListenerForLayoutEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(event) {
    ProfilePresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ProfilePresenter */ presenter) =>{
      presenter.m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(event.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_layout_shared_extension_LayoutEvent(/**@type {LayoutEvent} */ ($Casts.$to(arg0, LayoutEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfilePresenterListenerForLayoutEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfilePresenterListenerForLayoutEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfilePresenterListenerForLayoutEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutEvent = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');
    ProfilePresenterCommand = goog.module.get('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProfilePresenterListenerForLayoutEvent, $Util.$makeClassName('org.dominokit.domino.profile.client.listeners.ProfilePresenterListenerForLayoutEvent'));


DominoEventListener.$markImplementor(ProfilePresenterListenerForLayoutEvent);


exports = ProfilePresenterListenerForLayoutEvent; 
//# sourceMappingURL=ProfilePresenterListenerForLayoutEvent.js.map