/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ui.ProfileViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let DropdownAction = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropdownAction$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ProfileView}
  */
class ProfileViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Card} */
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_;
    /** @public {IsLayout} */
    this.f_layout__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ProfileViewImpl()'.
   * @return {!ProfileViewImpl}
   * @public
   */
  static $create__() {
    ProfileViewImpl.$clinit();
    let $instance = new ProfileViewImpl();
    $instance.$ctor__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfileViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl();
  }
  
  /**
   * @override
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
    this.f_layout__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_ = layout;
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_style__().m_add__java_lang_String("profile-card").m_add__java_lang_String("classy-card").m_add__java_lang_String("bg-theme");
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_TRANSPARENT__org_dominokit_domino_ui_style_Color);
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_setBodyBackground__org_dominokit_domino_ui_style_Color(Color.f_TRANSPARENT__org_dominokit_domino_ui_style_Color);
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getHeader__().m_style__().m_remove__java_lang_String("bg-theme");
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_setBodyPadding__java_lang_String("10px");
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getBody__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, DominoElement<HTMLDivElement>> */ style) =>{
      style.m_remove__java_lang_String("bg-theme");
    })));
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getHeaderTitle__().m_setAttribute__java_lang_String__java_lang_String("id", "demo-profile");
    let leftPanel = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(layout.m_getLeftPanel__().m_get__()), $Overlay));
    if (leftPanel.childElementCount > 0) {
      leftPanel.insertBefore(this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_asElement__(), leftPanel.firstChild);
    } else {
      leftPanel.appendChild(this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_asElement__());
    }
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/user.png").m_style__java_lang_String("border-radius:50%;"));
    let dropdownButton = /**@type {DropdownButton} */ ($Casts.$to(DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__()).m_linkify__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TRANSPARENT__org_dominokit_domino_ui_style_Color), DropdownButton)).m_hideCaret__().m_appendChild__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Action 1").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value) =>{
      Notification.m_createInfo__java_lang_String(value).m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Action 2").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$1$) =>{
      Notification.m_createInfo__java_lang_String(value$1$).m_show__();
    }))));
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getHeaderBar__().m_appendChild__elemental2_dom_Node(dropdownButton.m_asElement__());
    /**@type {Style<HTMLDivElement, Card>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_)).m_setHeight__java_lang_String("186px");
    /**@type {HTMLDivElement} */ ($Casts.$to(this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_asElement__(), HTMLDivElement_$Overlay)).appendChild(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String))), HtmlContentBuilder)).m_asElement__());
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    return this.f_layout__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_.m_getContentPanel__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl() {
    this.f_profile__org_dominokit_domino_profile_client_views_ui_ProfileViewImpl_ = Card.m_createProfile__java_lang_String__java_lang_String("Vegegoku", "vegegoku@bo3.com");
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfileViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfileViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfileViewImpl.$clinit = function() {};
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    DropdownButton = goog.module.get('org.dominokit.domino.ui.button.DropdownButton$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    DropdownAction = goog.module.get('org.dominokit.domino.ui.dropdown.DropdownAction$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProfileViewImpl, $Util.$makeClassName('org.dominokit.domino.profile.client.views.ui.ProfileViewImpl'));


ProfileView.$markImplementor(ProfileViewImpl);


exports = ProfileViewImpl; 
//# sourceMappingURL=ProfileViewImpl.js.map