/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.GwtEventProcessor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.GwtEventProcessor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor$impl');

let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.GwtEventProcessor.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {EventProcessor}
 */
class GwtEventProcessor {
  /**
   * @param {?function(Event):void} fn
   * @return {GwtEventProcessor}
   * @public
   */
  static $adapt(fn) {
    GwtEventProcessor.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventProcessor.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_gwt_client_events_GwtEventProcessor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_gwt_client_events_GwtEventProcessor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_gwt_client_events_GwtEventProcessor;
  }
  
  /**
   * @public
   */
  static $clinit() {
    GwtEventProcessor.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.gwt.client.events.GwtEventProcessor.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(GwtEventProcessor, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.GwtEventProcessor'));


GwtEventProcessor.$markImplementor(/** @type {Function} */ (GwtEventProcessor));


exports = GwtEventProcessor; 
//# sourceMappingURL=GwtEventProcessor.js.map