/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory.$1$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');

let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');
let StateHistoryToken = goog.forwardDeclare('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
let StateHistory = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory$impl');


/**
 * @implements {State}
  */
class $1 extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {StateHistory} */
    this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new State(StateHistory)'.
   * @param {StateHistory} $outer_this
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_history_StateHistory($outer_this) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_gwt_client_history_StateHistory_1__org_dominokit_domino_gwt_client_history_StateHistory($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new State(StateHistory)'.
   * @param {StateHistory} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_history_StateHistory_1__org_dominokit_domino_gwt_client_history_StateHistory($outer_this) {
    this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_1 = $outer_this;
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {HistoryToken}
   * @public
   */
  m_token__() {
    return StateHistoryToken.$create__java_lang_String(this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_1.m_windowToken___$p_org_dominokit_domino_gwt_client_history_StateHistory());
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_data__() {
    return "";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_title__() {
    return this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_1.m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    StateHistoryToken = goog.module.get('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.gwt.client.history.StateHistory$1'));


State.$markImplementor($1);


exports = $1; 
//# sourceMappingURL=StateHistory$1.js.map