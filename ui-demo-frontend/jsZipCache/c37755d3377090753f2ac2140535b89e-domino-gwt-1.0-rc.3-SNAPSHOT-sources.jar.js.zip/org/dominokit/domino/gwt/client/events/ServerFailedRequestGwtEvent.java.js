/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event = goog.require('org.gwtproject.event.shared.Event');
const _EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor');
const _Type = goog.require('org.gwtproject.event.shared.Event.Type');


// Re-exports the implementation.
var ServerFailedRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent$impl');
exports = ServerFailedRequestGwtEvent;
 