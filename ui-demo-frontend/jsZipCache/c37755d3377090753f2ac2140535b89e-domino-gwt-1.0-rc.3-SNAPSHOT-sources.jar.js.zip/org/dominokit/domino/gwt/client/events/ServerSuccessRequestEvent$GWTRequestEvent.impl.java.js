/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$GWTRequestEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.GWTRequestEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestEvent = goog.require('org.dominokit.domino.api.client.events.EventsBus.RequestEvent$impl');

let ServerSuccessRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$impl');
let ServerSuccessRequestGwtEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent$impl');


/**
 * @implements {RequestEvent<ServerSuccessRequestGwtEvent>}
  */
class GWTRequestEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ServerSuccessRequestEvent} */
    this.f_$outer_this__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent;
    /** @public {ServerSuccessRequestGwtEvent} */
    this.f_event__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent_;
  }
  
  /**
   * Factory method corresponding to constructor 'GWTRequestEvent(ServerSuccessRequestEvent, ServerSuccessRequestGwtEvent)'.
   * @param {ServerSuccessRequestEvent} $outer_this
   * @param {ServerSuccessRequestGwtEvent} event
   * @return {!GWTRequestEvent}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent__org_dominokit_domino_gwt_client_events_ServerSuccessRequestGwtEvent($outer_this, event) {
    GWTRequestEvent.$clinit();
    let $instance = new GWTRequestEvent();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent__org_dominokit_domino_gwt_client_events_ServerSuccessRequestGwtEvent($outer_this, event);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GWTRequestEvent(ServerSuccessRequestEvent, ServerSuccessRequestGwtEvent)'.
   * @param {ServerSuccessRequestEvent} $outer_this
   * @param {ServerSuccessRequestGwtEvent} event
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent__org_dominokit_domino_gwt_client_events_ServerSuccessRequestGwtEvent($outer_this, event) {
    this.f_$outer_this__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_event__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent_ = event;
  }
  
  /**
   * @override
   * @return {ServerSuccessRequestGwtEvent}
   * @public
   */
  m_asEvent__() {
    return this.f_event__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_GWTRequestEvent_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GWTRequestEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GWTRequestEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GWTRequestEvent.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GWTRequestEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$GWTRequestEvent'));


RequestEvent.$markImplementor(GWTRequestEvent);


exports = GWTRequestEvent; 
//# sourceMappingURL=ServerSuccessRequestEvent$GWTRequestEvent.js.map