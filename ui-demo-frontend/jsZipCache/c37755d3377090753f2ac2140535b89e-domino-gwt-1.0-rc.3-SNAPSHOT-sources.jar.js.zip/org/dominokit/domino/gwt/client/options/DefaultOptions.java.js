/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.options.DefaultOptions.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.options.DefaultOptions');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions');
const _List = goog.require('java.util.List');
const _CanSetDominoOptions = goog.require('org.dominokit.domino.api.client.CanSetDominoOptions');
const _DynamicServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot');
const _NotImplementedException = goog.require('org.dominokit.domino.gwt.client.options.DefaultOptions.NotImplementedException');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var DefaultOptions = goog.require('org.dominokit.domino.gwt.client.options.DefaultOptions$impl');
exports = DefaultOptions;
 