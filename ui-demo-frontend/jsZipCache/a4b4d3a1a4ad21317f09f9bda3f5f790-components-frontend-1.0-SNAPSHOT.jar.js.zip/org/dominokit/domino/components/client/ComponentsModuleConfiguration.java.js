/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.ComponentsModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.components.client.ComponentsModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');
const _$1 = goog.require('org.dominokit.domino.components.client.ComponentsModuleConfiguration.$1');
const _ComponentsPresenterContributionToComponentCaseExtensionPoint = goog.require('org.dominokit.domino.components.client.contributions.ComponentsPresenterContributionToComponentCaseExtensionPoint');
const _ComponentsPresenter = goog.require('org.dominokit.domino.components.client.presenters.ComponentsPresenter');
const _ComponentsPresenterCommand = goog.require('org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand');


// Re-exports the implementation.
var ComponentsModuleConfiguration = goog.require('org.dominokit.domino.components.client.ComponentsModuleConfiguration$impl');
exports = ComponentsModuleConfiguration;
 