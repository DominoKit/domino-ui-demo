/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.presenters.ComponentsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.presenters.ComponentsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.components.client.presenters.ComponentsPresenter.$1$impl');
let ComponentsView = goog.forwardDeclare('org.dominokit.domino.components.client.views.ComponentsView$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<ComponentsView>}
  */
class ComponentsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentsPresenter()'.
   * @return {!ComponentsPresenter}
   * @public
   */
  static $create__() {
    ComponentsPresenter.$clinit();
    let $instance = new ComponentsPresenter();
    $instance.$ctor__org_dominokit_domino_components_client_presenters_ComponentsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_client_presenters_ComponentsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_contributeToDemoPageModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_components_client_presenters_ComponentsPresenter(this));
    this.m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(Class.$get(ComponentsExtensionPoint), ComponentsExtensionPoint.$adapt((() =>{
      return ComponentsContext.$adapt((() =>{
        return context;
      }));
    })));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_components_client_presenters_ComponentsPresenter_() {
    return (ComponentsPresenter.$clinit(), ComponentsPresenter.$f_LOGGER__org_dominokit_domino_components_client_presenters_ComponentsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_components_client_presenters_ComponentsPresenter_(value) {
    (ComponentsPresenter.$clinit(), ComponentsPresenter.$f_LOGGER__org_dominokit_domino_components_client_presenters_ComponentsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.components.client.presenters.ComponentsPresenter.$1$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    ComponentsPresenter.$f_LOGGER__org_dominokit_domino_components_client_presenters_ComponentsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ComponentsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ComponentsPresenter, $Util.$makeClassName('org.dominokit.domino.components.client.presenters.ComponentsPresenter'));


/** @private {Logger} */
ComponentsPresenter.$f_LOGGER__org_dominokit_domino_components_client_presenters_ComponentsPresenter_;




exports = ComponentsPresenter; 
//# sourceMappingURL=ComponentsPresenter.js.map