package org.dominokit.domino.components.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint;
import org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class ComponentsPresenterContributionToComponentCaseExtensionPoint implements Contribution<ComponentCaseExtensionPoint> {
  @Override
  public void contribute(ComponentCaseExtensionPoint extensionPoint) {
    new ComponentsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToDemoPageModule(extensionPoint.context())).send();
  }
}
