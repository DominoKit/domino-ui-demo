/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ComponentsPresenter = goog.require('org.dominokit.domino.components.client.presenters.ComponentsPresenter');


// Re-exports the implementation.
var ComponentsPresenterCommand = goog.require('org.dominokit.domino.components.client.presenters.ComponentsPresenterCommand$impl');
exports = ComponentsPresenterCommand;
 