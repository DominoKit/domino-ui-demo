/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.views.ComponentsView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.components.client.views.ComponentsView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');


// Re-exports the implementation.
var ComponentsView = goog.require('org.dominokit.domino.components.client.views.ComponentsView$impl');
exports = ComponentsView;
 