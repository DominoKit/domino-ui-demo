/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.forms.shared.extension.FormsEvent.$LambdaAdaptor');


// Re-exports the implementation.
var FormsEvent = goog.require('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
exports = FormsEvent;
 