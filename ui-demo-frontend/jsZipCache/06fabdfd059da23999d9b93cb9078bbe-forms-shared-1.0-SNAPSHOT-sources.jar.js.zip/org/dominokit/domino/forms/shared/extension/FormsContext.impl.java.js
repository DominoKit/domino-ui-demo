/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {EventContext}
 */
class FormsContext {
  /**
   * @abstract
   * @return {ComponentCaseContext}
   * @public
   */
  m_getComponentCaseContext__() {
  }
  
  /**
   * @param {?function():ComponentCaseContext} fn
   * @return {FormsContext}
   * @public
   */
  static $adapt(fn) {
    FormsContext.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_forms_shared_extension_FormsContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_forms_shared_extension_FormsContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_forms_shared_extension_FormsContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsContext.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(FormsContext, $Util.$makeClassName('org.dominokit.domino.forms.shared.extension.FormsContext'));


FormsContext.$markImplementor(/** @type {Function} */ (FormsContext));


exports = FormsContext; 
//# sourceMappingURL=FormsContext.js.map