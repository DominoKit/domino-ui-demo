/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext.$LambdaAdaptor');


// Re-exports the implementation.
var FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
exports = FormsContext;
 