/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsContext$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsContext.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');


/**
 * @implements {FormsContext}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentCaseContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():ComponentCaseContext} */
    this.f_$$fn__org_dominokit_domino_forms_shared_extension_FormsContext_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_forms_shared_extension_FormsContext_$LambdaAdaptor__org_dominokit_domino_forms_shared_extension_FormsContext_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentCaseContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_shared_extension_FormsContext_$LambdaAdaptor__org_dominokit_domino_forms_shared_extension_FormsContext_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_forms_shared_extension_FormsContext_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {ComponentCaseContext}
   * @public
   */
  m_getComponentCaseContext__() {
    let /** ?function():ComponentCaseContext */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_forms_shared_extension_FormsContext_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.forms.shared.extension.FormsContext$$LambdaAdaptor'));


FormsContext.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=FormsContext$$LambdaAdaptor.js.map