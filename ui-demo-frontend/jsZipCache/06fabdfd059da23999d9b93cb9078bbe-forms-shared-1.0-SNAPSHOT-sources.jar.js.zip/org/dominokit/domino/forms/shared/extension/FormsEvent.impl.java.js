/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsEvent.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {DominoEvent<FormsContext>}
 */
class FormsEvent {
  /**
   * @param {?function():FormsContext} fn
   * @return {FormsEvent}
   * @public
   */
  static $adapt(fn) {
    FormsEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_forms_shared_extension_FormsEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_forms_shared_extension_FormsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_forms_shared_extension_FormsEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(FormsEvent, $Util.$makeClassName('org.dominokit.domino.forms.shared.extension.FormsEvent'));


FormsEvent.$markImplementor(/** @type {Function} */ (FormsEvent));


exports = FormsEvent; 
//# sourceMappingURL=FormsEvent.js.map