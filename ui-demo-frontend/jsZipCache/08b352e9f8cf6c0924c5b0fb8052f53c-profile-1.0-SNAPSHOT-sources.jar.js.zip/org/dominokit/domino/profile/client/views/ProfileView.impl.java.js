/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ProfileView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.views.ProfileView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');

let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.profile.client.views.ProfileView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 */
class ProfileView {
  /**
   * @abstract
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
  }
  
  /**
   * @param {?function(IsLayout):void} fn
   * @return {ProfileView}
   * @public
   */
  static $adapt(fn) {
    ProfileView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_profile_client_views_ProfileView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_profile_client_views_ProfileView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_profile_client_views_ProfileView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfileView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.profile.client.views.ProfileView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ProfileView, $Util.$makeClassName('org.dominokit.domino.profile.client.views.ProfileView'));


ProfileView.$markImplementor(/** @type {Function} */ (ProfileView));


exports = ProfileView; 
//# sourceMappingURL=ProfileView.js.map