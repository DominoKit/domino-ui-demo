/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ProfileView$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.views.ProfileView.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView$impl');

let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');


/**
 * @implements {ProfileView}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(IsLayout):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(IsLayout):void} */
    this.f_$$fn__org_dominokit_domino_profile_client_views_ProfileView_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_profile_client_views_ProfileView_$LambdaAdaptor__org_dominokit_domino_profile_client_views_ProfileView_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(IsLayout):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_views_ProfileView_$LambdaAdaptor__org_dominokit_domino_profile_client_views_ProfileView_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_profile_client_views_ProfileView_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {IsLayout} arg0
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_profile_client_views_ProfileView_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.profile.client.views.ProfileView$$LambdaAdaptor'));


ProfileView.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ProfileView$$LambdaAdaptor.js.map