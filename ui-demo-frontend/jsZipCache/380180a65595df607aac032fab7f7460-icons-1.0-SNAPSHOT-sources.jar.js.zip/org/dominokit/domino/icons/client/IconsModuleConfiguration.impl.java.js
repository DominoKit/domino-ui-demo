/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.IconsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.icons.client.IconsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.icons.client.IconsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.icons.client.IconsModuleConfiguration.$2$impl');
let IconsPresenterContributionToComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.icons.client.contributions.IconsPresenterContributionToComponentsExtensionPoint$impl');
let IconsPresenter = goog.forwardDeclare('org.dominokit.domino.icons.client.presenters.IconsPresenter$impl');
let IconsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.icons.client.presenters.IconsPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class IconsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'IconsModuleConfiguration()'.
   * @return {!IconsModuleConfiguration}
   * @public
   */
  static $create__() {
    IconsModuleConfiguration.$clinit();
    let $instance = new IconsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_icons_client_IconsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_icons_client_IconsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_icons_client_IconsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(IconsPresenter).m_getCanonicalName__(), Class.$get(IconsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_icons_client_IconsModuleConfiguration__java_lang_String(this, Class.$get(IconsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(IconsPresenterCommand).m_getCanonicalName__(), Class.$get(IconsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(ComponentsExtensionPoint), IconsPresenterContributionToComponentsExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IconsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IconsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IconsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    $1 = goog.module.get('org.dominokit.domino.icons.client.IconsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.icons.client.IconsModuleConfiguration.$2$impl');
    IconsPresenterContributionToComponentsExtensionPoint = goog.module.get('org.dominokit.domino.icons.client.contributions.IconsPresenterContributionToComponentsExtensionPoint$impl');
    IconsPresenter = goog.module.get('org.dominokit.domino.icons.client.presenters.IconsPresenter$impl');
    IconsPresenterCommand = goog.module.get('org.dominokit.domino.icons.client.presenters.IconsPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IconsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.icons.client.IconsModuleConfiguration'));


ModuleConfiguration.$markImplementor(IconsModuleConfiguration);


exports = IconsModuleConfiguration; 
//# sourceMappingURL=IconsModuleConfiguration.js.map