/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCase.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCase$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let ComponentRemoveHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
let ComponentRevealedHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler$impl');


/**
 * @interface
 */
class ComponentCase {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getHistoryToken__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getMenuPath__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_hasContent__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getIconName__() {
  }
  
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getContent__() {
  }
  
  /**
   * @abstract
   * @return {ComponentRevealedHandler}
   * @public
   */
  m_onComponentRevealed__() {
  }
  
  /**
   * @abstract
   * @return {ComponentRemoveHandler}
   * @public
   */
  m_onComponentRemoved__() {
  }
  
  /**
   * @param {ComponentCase} $thisArg
   * @return {boolean}
   * @public
   */
  static m_hasContent__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase($thisArg) {
    ComponentCase.$clinit();
    return true;
  }
  
  /**
   * @param {ComponentCase} $thisArg
   * @return {?string}
   * @public
   */
  static m_getIconName__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase($thisArg) {
    ComponentCase.$clinit();
    return "";
  }
  
  /**
   * @param {ComponentCase} $thisArg
   * @return {Content}
   * @public
   */
  static m_getContent__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase($thisArg) {
    ComponentCase.$clinit();
    return null;
  }
  
  /**
   * @param {ComponentCase} $thisArg
   * @return {ComponentRevealedHandler}
   * @public
   */
  static m_onComponentRevealed__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase($thisArg) {
    ComponentCase.$clinit();
    return ComponentRevealedHandler.$adapt((() =>{
    }));
  }
  
  /**
   * @param {ComponentCase} $thisArg
   * @return {ComponentRemoveHandler}
   * @public
   */
  static m_onComponentRemoved__$default__org_dominokit_domino_componentcase_shared_extension_ComponentCase($thisArg) {
    ComponentCase.$clinit();
    return ComponentRemoveHandler.$adapt((() =>{
    }));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCase.$clinit = function() {};
    ComponentRemoveHandler = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
    ComponentRevealedHandler = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentCase, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCase'));


ComponentCase.$markImplementor(/** @type {Function} */ (ComponentCase));


exports = ComponentCase; 
//# sourceMappingURL=ComponentCase.js.map