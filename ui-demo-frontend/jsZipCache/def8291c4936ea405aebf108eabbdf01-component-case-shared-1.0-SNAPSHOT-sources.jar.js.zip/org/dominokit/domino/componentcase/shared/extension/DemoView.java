package org.dominokit.domino.componentcase.shared.extension;

import org.dominokit.domino.api.shared.extension.Content;

public interface DemoView {
    Content getContent();
}
