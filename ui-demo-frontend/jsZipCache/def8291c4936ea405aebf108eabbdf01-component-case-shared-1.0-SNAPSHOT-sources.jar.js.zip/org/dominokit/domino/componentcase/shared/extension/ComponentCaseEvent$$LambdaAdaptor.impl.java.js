/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ComponentCaseEvent}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentCaseContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():ComponentCaseContext} */
    this.f_$$fn__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$LambdaAdaptor__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentCaseContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$LambdaAdaptor__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {ComponentCaseContext}
   * @public
   */
  m_context__() {
    let /** ?function():ComponentCaseContext */ $function;
    return /**@type {ComponentCaseContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent_$LambdaAdaptor, $function()), ComponentCaseContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$$LambdaAdaptor'));


ComponentCaseEvent.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ComponentCaseEvent$$LambdaAdaptor.js.map