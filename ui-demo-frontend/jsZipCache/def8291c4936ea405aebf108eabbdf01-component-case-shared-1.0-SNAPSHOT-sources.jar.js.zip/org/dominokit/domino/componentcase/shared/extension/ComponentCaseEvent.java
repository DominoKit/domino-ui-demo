package org.dominokit.domino.componentcase.shared.extension;

import org.dominokit.domino.api.shared.extension.DominoEvent;

public interface ComponentCaseEvent extends DominoEvent<ComponentCaseContext> {
}
