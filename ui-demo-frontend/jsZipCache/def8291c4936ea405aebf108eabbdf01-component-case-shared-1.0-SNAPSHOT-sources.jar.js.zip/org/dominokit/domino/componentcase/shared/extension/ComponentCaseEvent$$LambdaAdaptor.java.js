/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 