/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {DominoEvent<ComponentCaseContext>}
 */
class ComponentCaseEvent {
  /**
   * @param {?function():ComponentCaseContext} fn
   * @return {ComponentCaseEvent}
   * @public
   */
  static $adapt(fn) {
    ComponentCaseEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentCaseEvent, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent'));


ComponentCaseEvent.$markImplementor(/** @type {Function} */ (ComponentCaseEvent));


exports = ComponentCaseEvent; 
//# sourceMappingURL=ComponentCaseEvent.js.map