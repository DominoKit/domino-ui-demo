/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext$impl');

let ComponentCase = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {EventContext}
 */
class ComponentCaseContext {
  /**
   * @abstract
   * @param {ComponentCase} componentCase
   * @return {void}
   * @public
   */
  m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase(componentCase) {
  }
  
  /**
   * @param {?function(ComponentCase):void} fn
   * @return {ComponentCaseContext}
   * @public
   */
  static $adapt(fn) {
    ComponentCaseContext.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseContext.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentCaseContext, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext'));


ComponentCaseContext.$markImplementor(/** @type {Function} */ (ComponentCaseContext));


exports = ComponentCaseContext; 
//# sourceMappingURL=ComponentCaseContext.js.map