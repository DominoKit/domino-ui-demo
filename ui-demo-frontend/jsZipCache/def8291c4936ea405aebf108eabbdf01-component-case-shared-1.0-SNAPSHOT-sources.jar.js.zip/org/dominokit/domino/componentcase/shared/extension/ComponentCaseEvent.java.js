/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent.$LambdaAdaptor');


// Re-exports the implementation.
var ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
exports = ComponentCaseEvent;
 