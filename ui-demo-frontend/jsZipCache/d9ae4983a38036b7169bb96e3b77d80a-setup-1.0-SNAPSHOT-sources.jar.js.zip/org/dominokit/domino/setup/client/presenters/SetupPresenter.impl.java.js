/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.presenters.SetupPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.setup.client.presenters.SetupPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.setup.client.presenters.SetupPresenter.$1$impl');
let SetupView = goog.forwardDeclare('org.dominokit.domino.setup.client.views.SetupView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<SetupView>}
  */
class SetupPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SetupPresenter()'.
   * @return {!SetupPresenter}
   * @public
   */
  static $create__() {
    SetupPresenter.$clinit();
    let $instance = new SetupPresenter();
    $instance.$ctor__org_dominokit_domino_setup_client_presenters_SetupPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SetupPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_setup_client_presenters_SetupPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_listenToComponentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_setup_client_presenters_SetupPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_setup_client_presenters_SetupPresenter_() {
    return (SetupPresenter.$clinit(), SetupPresenter.$f_LOGGER__org_dominokit_domino_setup_client_presenters_SetupPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_setup_client_presenters_SetupPresenter_(value) {
    (SetupPresenter.$clinit(), SetupPresenter.$f_LOGGER__org_dominokit_domino_setup_client_presenters_SetupPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SetupPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SetupPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SetupPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.setup.client.presenters.SetupPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    SetupPresenter.$f_LOGGER__org_dominokit_domino_setup_client_presenters_SetupPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SetupPresenter));
  }
  
  
};

$Util.$setClassMetadata(SetupPresenter, $Util.$makeClassName('org.dominokit.domino.setup.client.presenters.SetupPresenter'));


/** @private {Logger} */
SetupPresenter.$f_LOGGER__org_dominokit_domino_setup_client_presenters_SetupPresenter_;




exports = SetupPresenter; 
//# sourceMappingURL=SetupPresenter.js.map