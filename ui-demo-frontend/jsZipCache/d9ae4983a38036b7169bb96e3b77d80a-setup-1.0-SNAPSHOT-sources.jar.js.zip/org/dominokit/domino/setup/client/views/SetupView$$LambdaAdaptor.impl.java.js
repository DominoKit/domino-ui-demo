/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.views.SetupView$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.setup.client.views.SetupView.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SetupView = goog.require('org.dominokit.domino.setup.client.views.SetupView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @implements {SetupView}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Content} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Content} */
    this.f_$$fn__org_dominokit_domino_setup_client_views_SetupView_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_setup_client_views_SetupView_$LambdaAdaptor__org_dominokit_domino_setup_client_views_SetupView_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Content} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_setup_client_views_SetupView_$LambdaAdaptor__org_dominokit_domino_setup_client_views_SetupView_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_setup_client_views_SetupView_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Content}
   * @public
   */
  m_getContent__() {
    let /** ?function():Content */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_setup_client_views_SetupView_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.setup.client.views.SetupView$$LambdaAdaptor'));


SetupView.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=SetupView$$LambdaAdaptor.js.map