/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.views.ui.SetupViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.setup.client.views.ui.SetupViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const SetupView = goog.require('org.dominokit.domino.setup.client.views.SetupView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {SetupView}
  */
class SetupViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'SetupViewImpl()'.
   * @return {!SetupViewImpl}
   * @public
   */
  static $create__() {
    SetupViewImpl.$clinit();
    let $instance = new SetupViewImpl();
    $instance.$ctor__org_dominokit_domino_setup_client_views_ui_SetupViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SetupViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_setup_client_views_ui_SetupViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_setup_client_views_ui_SetupViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("SETUP", "Steps required to start working with domino ui components").m_asElement__());
    this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String("<dependency>\n" + "  <groupId>org.dominokit</groupId>\n" + "  <artifactId>domino-ui</artifactId>\n" + "  <version>1.0-SNAPSHOT</version>\n" + "</dependency>\n" + "<dependency>\n" + "  <groupId>org.dominokit</groupId>\n" + "  <artifactId>domino-ui</artifactId>\n" + "  <version>1.0-SNAPSHOT</version>\n" + "  <classifier>sources</classifier>\n" + "</dependency>").m_setTitle__java_lang_String("Maven dependencies").m_expand__().m_asElement__());
    this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String("<inherits name=\"org.dominokit.domino.ui.DominoUI\"/>").m_setTitle__java_lang_String("gwt module inheritance").m_expand__().m_asElement__());
    this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String("<meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">\n" + "\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"{module-short-name}/css/domino-ui.css\">\n" + "<link type=\"text/css\" rel=\"stylesheet\" href=\"{module-short-name}/css/themes/all-themes.css\">").m_setTitle__java_lang_String("Html page required imports").m_setDescription__java_lang_String("The path depends on your module and index page setup.").m_expand__().m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_setup_client_views_ui_SetupViewImpl() {
    this.f_element__org_dominokit_domino_setup_client_views_ui_SetupViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SetupViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SetupViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SetupViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SetupViewImpl, $Util.$makeClassName('org.dominokit.domino.setup.client.views.ui.SetupViewImpl'));


SetupView.$markImplementor(SetupViewImpl);


exports = SetupViewImpl; 
//# sourceMappingURL=SetupViewImpl.js.map