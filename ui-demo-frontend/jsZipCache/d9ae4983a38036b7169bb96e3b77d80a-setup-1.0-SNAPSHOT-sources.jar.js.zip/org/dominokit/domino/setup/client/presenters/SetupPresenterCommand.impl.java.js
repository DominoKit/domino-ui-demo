/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.presenters.SetupPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.setup.client.presenters.SetupPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let SetupPresenter = goog.forwardDeclare('org.dominokit.domino.setup.client.presenters.SetupPresenter$impl');


/**
 * @extends {PresenterCommand<SetupPresenter>}
  */
class SetupPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SetupPresenterCommand()'.
   * @return {!SetupPresenterCommand}
   * @public
   */
  static $create__() {
    SetupPresenterCommand.$clinit();
    let $instance = new SetupPresenterCommand();
    $instance.$ctor__org_dominokit_domino_setup_client_presenters_SetupPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SetupPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_setup_client_presenters_SetupPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SetupPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SetupPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SetupPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SetupPresenterCommand, $Util.$makeClassName('org.dominokit.domino.setup.client.presenters.SetupPresenterCommand'));




exports = SetupPresenterCommand; 
//# sourceMappingURL=SetupPresenterCommand.js.map