/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.views.ui.SetupViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.setup.client.views.ui.SetupViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _SetupView = goog.require('org.dominokit.domino.setup.client.views.SetupView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SetupViewImpl = goog.require('org.dominokit.domino.setup.client.views.ui.SetupViewImpl$impl');
exports = SetupViewImpl;
 