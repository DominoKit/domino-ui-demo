/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');

let MenuContext = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ExtensionPoint<MenuContext>}
 */
class MenuExtensionPoint {
  /**
   * @param {?function():MenuContext} fn
   * @return {MenuExtensionPoint}
   * @public
   */
  static $adapt(fn) {
    MenuExtensionPoint.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ExtensionPoint.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MenuExtensionPoint, $Util.$makeClassName('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint'));


MenuExtensionPoint.$markImplementor(/** @type {Function} */ (MenuExtensionPoint));


exports = MenuExtensionPoint; 
//# sourceMappingURL=MenuExtensionPoint.js.map