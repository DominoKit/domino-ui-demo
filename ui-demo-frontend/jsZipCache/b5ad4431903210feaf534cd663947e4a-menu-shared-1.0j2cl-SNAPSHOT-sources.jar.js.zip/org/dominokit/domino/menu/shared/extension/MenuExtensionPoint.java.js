/**
 * @fileoverview transpiled from org.dominokit.domino.menu.shared.extension.MenuExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint.$LambdaAdaptor');


// Re-exports the implementation.
var MenuExtensionPoint = goog.require('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$impl');
exports = MenuExtensionPoint;
 