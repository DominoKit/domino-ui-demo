/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ThumbnailsPresenter = goog.require('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter');


// Re-exports the implementation.
var ThumbnailsPresenterCommand = goog.require('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenterCommand$impl');
exports = ThumbnailsPresenterCommand;
 