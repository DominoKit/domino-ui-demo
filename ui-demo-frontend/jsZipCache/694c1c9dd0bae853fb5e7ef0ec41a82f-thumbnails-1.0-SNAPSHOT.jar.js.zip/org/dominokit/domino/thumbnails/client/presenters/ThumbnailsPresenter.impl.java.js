/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter.$1$impl');
let ThumbnailsView = goog.forwardDeclare('org.dominokit.domino.thumbnails.client.views.ThumbnailsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<ThumbnailsView>}
  */
class ThumbnailsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThumbnailsPresenter()'.
   * @return {!ThumbnailsPresenter}
   * @public
   */
  static $create__() {
    ThumbnailsPresenter.$clinit();
    let $instance = new ThumbnailsPresenter();
    $instance.$ctor__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThumbnailsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter_() {
    return (ThumbnailsPresenter.$clinit(), ThumbnailsPresenter.$f_LOGGER__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter_(value) {
    (ThumbnailsPresenter.$clinit(), ThumbnailsPresenter.$f_LOGGER__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThumbnailsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThumbnailsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThumbnailsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    ThumbnailsPresenter.$f_LOGGER__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ThumbnailsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ThumbnailsPresenter, $Util.$makeClassName('org.dominokit.domino.thumbnails.client.presenters.ThumbnailsPresenter'));


/** @private {Logger} */
ThumbnailsPresenter.$f_LOGGER__org_dominokit_domino_thumbnails_client_presenters_ThumbnailsPresenter_;




exports = ThumbnailsPresenter; 
//# sourceMappingURL=ThumbnailsPresenter.js.map