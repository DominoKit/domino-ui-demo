/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.ComponentsUIModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.ComponentsUIModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.components.client.ComponentsUIModuleConfiguration.$1$impl');
let ComponentsPresenter = goog.forwardDeclare('org.dominokit.domino.components.client.presenters.ComponentsPresenter$impl');


/**
 * @implements {ModuleConfiguration}
  */
class ComponentsUIModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentsUIModuleConfiguration()'.
   * @return {!ComponentsUIModuleConfiguration}
   * @public
   */
  static $create__() {
    ComponentsUIModuleConfiguration.$clinit();
    let $instance = new ComponentsUIModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_components_client_ComponentsUIModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentsUIModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_client_ComponentsUIModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($1.$create__org_dominokit_domino_components_client_ComponentsUIModuleConfiguration__java_lang_String(this, Class.$get(ComponentsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {ContributionsRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(arg0) {
    ModuleConfiguration.m_registerContributions__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_extension_ContributionsRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {PresenterRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(arg0) {
    ModuleConfiguration.m_registerPresenters__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_PresenterRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CommandRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(arg0) {
    ModuleConfiguration.m_registerRequests__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_CommandRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentsUIModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentsUIModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsUIModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.components.client.ComponentsUIModuleConfiguration.$1$impl');
    ComponentsPresenter = goog.module.get('org.dominokit.domino.components.client.presenters.ComponentsPresenter$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentsUIModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.components.client.ComponentsUIModuleConfiguration'));


ModuleConfiguration.$markImplementor(ComponentsUIModuleConfiguration);


exports = ComponentsUIModuleConfiguration; 
//# sourceMappingURL=ComponentsUIModuleConfiguration.js.map