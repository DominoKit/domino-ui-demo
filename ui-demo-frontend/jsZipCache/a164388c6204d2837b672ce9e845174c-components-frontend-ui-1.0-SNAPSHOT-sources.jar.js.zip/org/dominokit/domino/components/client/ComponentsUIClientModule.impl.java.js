/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.ComponentsUIClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.ComponentsUIClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ComponentsUIClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentsUIClientModule()'.
   * @return {!ComponentsUIClientModule}
   * @public
   */
  static $create__() {
    ComponentsUIClientModule.$clinit();
    let $instance = new ComponentsUIClientModule();
    $instance.$ctor__org_dominokit_domino_components_client_ComponentsUIClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentsUIClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_client_ComponentsUIClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ComponentsUIClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_.m_info__java_lang_String("Initializing Components frontend UI module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_() {
    return (ComponentsUIClientModule.$clinit(), ComponentsUIClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_(value) {
    (ComponentsUIClientModule.$clinit(), ComponentsUIClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentsUIClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentsUIClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsUIClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ComponentsUIClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ComponentsUIClientModule));
  }
  
  
};

$Util.$setClassMetadata(ComponentsUIClientModule, $Util.$makeClassName('org.dominokit.domino.components.client.ComponentsUIClientModule'));


/** @private {Logger} */
ComponentsUIClientModule.$f_LOGGER__org_dominokit_domino_components_client_ComponentsUIClientModule_;




exports = ComponentsUIClientModule; 
//# sourceMappingURL=ComponentsUIClientModule.js.map