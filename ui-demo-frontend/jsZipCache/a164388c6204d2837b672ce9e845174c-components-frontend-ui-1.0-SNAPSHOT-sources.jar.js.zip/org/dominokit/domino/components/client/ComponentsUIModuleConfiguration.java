package org.dominokit.domino.components.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.components.client.presenters.ComponentsPresenter;
import org.dominokit.domino.components.client.ui.views.ComponentsViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ComponentsUIModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(ComponentsPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new ComponentsViewImpl();
      }
    });
  }
}
