/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.ui.views.ComponentsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.ui.views.ComponentsViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentsView = goog.require('org.dominokit.domino.components.client.views.ComponentsView$impl');


/**
 * @implements {ComponentsView}
  */
class ComponentsViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentsViewImpl()'.
   * @return {!ComponentsViewImpl}
   * @public
   */
  static $create__() {
    ComponentsViewImpl.$clinit();
    let $instance = new ComponentsViewImpl();
    $instance.$ctor__org_dominokit_domino_components_client_ui_views_ComponentsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_client_ui_views_ComponentsViewImpl__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsViewImpl.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentsViewImpl, $Util.$makeClassName('org.dominokit.domino.components.client.ui.views.ComponentsViewImpl'));


ComponentsView.$markImplementor(ComponentsViewImpl);


exports = ComponentsViewImpl; 
//# sourceMappingURL=ComponentsViewImpl.js.map