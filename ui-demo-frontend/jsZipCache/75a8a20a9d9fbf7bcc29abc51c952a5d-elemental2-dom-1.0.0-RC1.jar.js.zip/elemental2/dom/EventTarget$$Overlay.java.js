/**
 * @fileoverview transpiled from elemental2.dom.EventTarget$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.EventTarget.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AddEventListenerOptions_$Overlay = goog.require('elemental2.dom.AddEventListenerOptions.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _EventListenerOptions_$Overlay = goog.require('elemental2.dom.EventListenerOptions.$Overlay');
const _$Overlay = goog.require('elemental2.dom.EventTarget.AddEventListenerOptionsUnionType.$Overlay');
const _RemoveEventListenerOptionsUnionType_$Overlay = goog.require('elemental2.dom.EventTarget.RemoveEventListenerOptionsUnionType.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var EventTarget_$Overlay = goog.require('elemental2.dom.EventTarget.$Overlay$impl');
exports = EventTarget_$Overlay;
 