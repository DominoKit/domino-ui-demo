/**
 * @fileoverview transpiled from elemental2.dom.CSSProperties$MarginLeftUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CSSProperties.MarginLeftUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Double = goog.require('java.lang.Double');
const _j_l_Object = goog.require('java.lang.Object');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $Overlay = goog.require('elemental2.dom.CSSProperties.MarginLeftUnionType.$Overlay$impl');
exports = $Overlay;
 