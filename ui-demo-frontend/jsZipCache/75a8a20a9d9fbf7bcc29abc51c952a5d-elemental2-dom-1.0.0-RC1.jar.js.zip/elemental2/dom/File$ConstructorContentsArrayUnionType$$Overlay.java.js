/**
 * @fileoverview transpiled from elemental2.dom.File$ConstructorContentsArrayUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.File.ConstructorContentsArrayUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.ArrayBuffer.$Overlay');
const _Blob_$Overlay = goog.require('elemental2.dom.Blob.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ConstructorContentsArrayUnionType_$Overlay = goog.require('elemental2.dom.File.ConstructorContentsArrayUnionType.$Overlay$impl');
exports = ConstructorContentsArrayUnionType_$Overlay;
 