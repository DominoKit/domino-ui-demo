/**
 * @fileoverview transpiled from elemental2.dom.Element$ScrollIntoViewTopUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Element.ScrollIntoViewTopUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.ScrollIntoViewTopType.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ScrollIntoViewTopUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ScrollIntoViewTopUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ScrollIntoViewTopUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_asBoolean__elemental2_dom_Element_ScrollIntoViewTopUnionType($thisArg) {
    ScrollIntoViewTopUnionType_$Overlay.$clinit();
    return Js.m_asBoolean__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {?}
   * @public
   */
  static m_asScrollIntoViewTopType__elemental2_dom_Element_ScrollIntoViewTopUnionType($thisArg) {
    ScrollIntoViewTopUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isBoolean__elemental2_dom_Element_ScrollIntoViewTopUnionType($thisArg) {
    ScrollIntoViewTopUnionType_$Overlay.$clinit();
    return Boolean.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ScrollIntoViewTopUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Element.ScrollIntoViewTopType.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ScrollIntoViewTopUnionType_$Overlay, $Util.$makeClassName('?'));


exports = ScrollIntoViewTopUnionType_$Overlay; 
//# sourceMappingURL=Element$ScrollIntoViewTopUnionType$$Overlay.js.map