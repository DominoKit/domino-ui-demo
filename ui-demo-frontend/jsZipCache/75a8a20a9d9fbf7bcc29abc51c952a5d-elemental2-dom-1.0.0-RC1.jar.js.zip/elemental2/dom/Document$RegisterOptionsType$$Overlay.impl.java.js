/**
 * @fileoverview transpiled from elemental2.dom.Document$RegisterOptionsType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Document.RegisterOptionsType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class RegisterOptionsType_$Overlay {
  /**
   * @return {?}
   * @public
   */
  static m_create__() {
    RegisterOptionsType_$Overlay.$clinit();
    return /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RegisterOptionsType_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RegisterOptionsType_$Overlay, $Util.$makeClassName('?'));


exports = RegisterOptionsType_$Overlay; 
//# sourceMappingURL=Document$RegisterOptionsType$$Overlay.js.map