/**
 * @fileoverview transpiled from elemental2.dom.CharacterData$ReplaceWithNodesUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CharacterData.ReplaceWithNodesUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ReplaceWithNodesUnionType_$Overlay = goog.require('elemental2.dom.CharacterData.ReplaceWithNodesUnionType.$Overlay$impl');
exports = ReplaceWithNodesUnionType_$Overlay;
 