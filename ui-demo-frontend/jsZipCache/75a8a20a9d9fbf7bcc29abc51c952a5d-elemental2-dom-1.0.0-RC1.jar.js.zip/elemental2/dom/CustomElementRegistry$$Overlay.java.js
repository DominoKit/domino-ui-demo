/**
 * @fileoverview transpiled from elemental2.dom.CustomElementRegistry$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CustomElementRegistry.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DefineOptionsType_$Overlay = goog.require('elemental2.dom.CustomElementRegistry.DefineOptionsType.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsConstructorFn.$Overlay');


// Re-exports the implementation.
var CustomElementRegistry_$Overlay = goog.require('elemental2.dom.CustomElementRegistry.$Overlay$impl');
exports = CustomElementRegistry_$Overlay;
 