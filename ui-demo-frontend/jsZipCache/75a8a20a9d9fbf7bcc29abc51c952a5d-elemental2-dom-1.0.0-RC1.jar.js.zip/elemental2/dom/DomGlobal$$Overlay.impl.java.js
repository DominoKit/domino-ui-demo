/**
 * @fileoverview transpiled from elemental2.dom.DomGlobal$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.DomGlobal.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let Transferable_$Overlay = goog.forwardDeclare('elemental2.core.Transferable.$Overlay$impl');
let Database_$Overlay = goog.forwardDeclare('elemental2.dom.Database.$Overlay$impl');
let DatabaseCallback_$Overlay = goog.forwardDeclare('elemental2.dom.DatabaseCallback.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.FetchInputUnionType.$Overlay$impl');
let OpenDatabaseCallbackUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.OpenDatabaseCallbackUnionType.$Overlay$impl');
let PostMessageTargetOriginOrPortsOrTransferUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.PostMessageTargetOriginOrPortsOrTransferUnionType.$Overlay$impl');
let PostMessageTargetOriginOrTransferUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.PostMessageTargetOriginOrTransferUnionType.$Overlay$impl');
let SetIntervalCallbackUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.SetIntervalCallbackUnionType.$Overlay$impl');
let SetTimeoutCallbackUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.SetTimeoutCallbackUnionType.$Overlay$impl');
let HTMLDocument_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDocument.$Overlay$impl');
let Location_$Overlay = goog.forwardDeclare('elemental2.dom.Location.$Overlay$impl');
let Navigator_$Overlay = goog.forwardDeclare('elemental2.dom.Navigator.$Overlay$impl');
let Request_$Overlay = goog.forwardDeclare('elemental2.dom.Request.$Overlay$impl');
let RequestInit_$Overlay = goog.forwardDeclare('elemental2.dom.RequestInit.$Overlay$impl');
let Response_$Overlay = goog.forwardDeclare('elemental2.dom.Response.$Overlay$impl');
let Screen_$Overlay = goog.forwardDeclare('elemental2.dom.Screen.$Overlay$impl');
let Window_$Overlay = goog.forwardDeclare('elemental2.dom.Window.$Overlay$impl');
let Promise_$Overlay = goog.forwardDeclare('elemental2.promise.Promise.$Overlay$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class DomGlobal_$Overlay {
  /**
   * @param {Request} input
   * @param {RequestInit} init
   * @return {Promise<Response>}
   * @public
   */
  static m_fetch__elemental2_dom_Request__elemental2_dom_RequestInit(input, init) {
    DomGlobal_$Overlay.$clinit();
    return window.fetch(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(input)), init);
  }
  
  /**
   * @param {Request} input
   * @return {Promise<Response>}
   * @public
   */
  static m_fetch__elemental2_dom_Request(input) {
    DomGlobal_$Overlay.$clinit();
    return window.fetch(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(input)));
  }
  
  /**
   * @param {?string} input
   * @param {RequestInit} init
   * @return {Promise<Response>}
   * @public
   */
  static m_fetch__java_lang_String__elemental2_dom_RequestInit(input, init) {
    DomGlobal_$Overlay.$clinit();
    return window.fetch(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(input)), init);
  }
  
  /**
   * @param {?string} input
   * @return {Promise<Response>}
   * @public
   */
  static m_fetch__java_lang_String(input) {
    DomGlobal_$Overlay.$clinit();
    return window.fetch(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(input)));
  }
  
  /**
   * @param {?string} name
   * @param {?string} version
   * @param {?string} description
   * @param {number} size
   * @param {DatabaseCallback} callback
   * @return {Database}
   * @public
   */
  static m_openDatabase__java_lang_String__java_lang_String__java_lang_String__int__elemental2_dom_DatabaseCallback(name, version, description, size, callback) {
    DomGlobal_$Overlay.$clinit();
    return window.openDatabase(name, version, description, size, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(callback)));
  }
  
  /**
   * @param {?string} name
   * @param {?string} version
   * @param {?string} description
   * @param {number} size
   * @param {?function(Database):*} callback
   * @return {Database}
   * @public
   */
  static m_openDatabase__java_lang_String__java_lang_String__java_lang_String__int__elemental2_dom_DomGlobal_OpenDatabaseCallbackFn(name, version, description, size, callback) {
    DomGlobal_$Overlay.$clinit();
    return window.openDatabase(name, version, description, size, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(callback)));
  }
  
  /**
   * @param {*} message
   * @param {?} targetOriginOrTransfer
   * @param {Array} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__elemental2_dom_DomGlobal_PostMessageTargetOriginOrTransferUnionType__elemental2_core_JsArray(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, targetOriginOrTransfer, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrPortsOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {?} targetOriginOrTransfer
   * @param {?string} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__elemental2_dom_DomGlobal_PostMessageTargetOriginOrTransferUnionType__java_lang_String(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, targetOriginOrTransfer, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrPortsOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {?string} targetOriginOrTransfer
   * @param {Array} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__java_lang_String__elemental2_core_JsArray(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrPortsOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {?string} targetOriginOrTransfer
   * @param {?} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__java_lang_String__elemental2_dom_DomGlobal_PostMessageTargetOriginOrPortsOrTransferUnionType(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)), targetOriginOrPortsOrTransfer);
  }
  
  /**
   * @param {*} message
   * @param {?string} targetOriginOrTransfer
   * @param {?string} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__java_lang_String__java_lang_String(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrPortsOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {?string} targetOriginOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__java_lang_String(message, targetOriginOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {Array<Transferable>} targetOriginOrTransfer
   * @param {Array} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__arrayOf_elemental2_core_Transferable__elemental2_core_JsArray(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrPortsOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {Array<Transferable>} targetOriginOrTransfer
   * @param {?} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__arrayOf_elemental2_core_Transferable__elemental2_dom_DomGlobal_PostMessageTargetOriginOrPortsOrTransferUnionType(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)), targetOriginOrPortsOrTransfer);
  }
  
  /**
   * @param {*} message
   * @param {Array<Transferable>} targetOriginOrTransfer
   * @param {?string} targetOriginOrPortsOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__arrayOf_elemental2_core_Transferable__java_lang_String(message, targetOriginOrTransfer, targetOriginOrPortsOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)), /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrPortsOrTransfer)));
  }
  
  /**
   * @param {*} message
   * @param {Array<Transferable>} targetOriginOrTransfer
   * @return {void}
   * @public
   */
  static m_postMessage__java_lang_Object__arrayOf_elemental2_core_Transferable(message, targetOriginOrTransfer) {
    DomGlobal_$Overlay.$clinit();
    window.postMessage(message, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(targetOriginOrTransfer)));
  }
  
  /**
   * @param {?function(...*):void} callback
   * @param {number} delay
   * @param {Array<*>} var_args
   * @return {number}
   * @public
   */
  static m_setInterval__elemental2_dom_DomGlobal_SetIntervalCallbackFn__double__arrayOf_java_lang_Object(callback, delay, var_args) {
    DomGlobal_$Overlay.$clinit();
    return window.setInterval(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(callback)), delay, ...$InternalPreconditions.m_checkNotNull__java_lang_Object(var_args));
  }
  
  /**
   * @param {?string} callback
   * @param {number} delay
   * @param {Array<*>} var_args
   * @return {number}
   * @public
   */
  static m_setInterval__java_lang_String__double__arrayOf_java_lang_Object(callback, delay, var_args) {
    DomGlobal_$Overlay.$clinit();
    return window.setInterval(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(callback)), delay, ...$InternalPreconditions.m_checkNotNull__java_lang_Object(var_args));
  }
  
  /**
   * @param {?function(...*):void} callback
   * @param {number} delay
   * @param {Array<*>} var_args
   * @return {number}
   * @public
   */
  static m_setTimeout__elemental2_dom_DomGlobal_SetTimeoutCallbackFn__double__arrayOf_java_lang_Object(callback, delay, var_args) {
    DomGlobal_$Overlay.$clinit();
    return window.setTimeout(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(callback)), delay, ...$InternalPreconditions.m_checkNotNull__java_lang_Object(var_args));
  }
  
  /**
   * @param {?string} callback
   * @param {number} delay
   * @param {Array<*>} var_args
   * @return {number}
   * @public
   */
  static m_setTimeout__java_lang_String__double__arrayOf_java_lang_Object(callback, delay, var_args) {
    DomGlobal_$Overlay.$clinit();
    return window.setTimeout(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(callback)), delay, ...$InternalPreconditions.m_checkNotNull__java_lang_Object(var_args));
  }
  
  /**
   * @return {HTMLDocument}
   * @public
   */
  static get f_document__elemental2_dom_DomGlobal_$Overlay() {
    return (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_document__elemental2_dom_DomGlobal_$Overlay);
  }
  
  /**
   * @param {HTMLDocument} value
   * @return {void}
   * @public
   */
  static set f_document__elemental2_dom_DomGlobal_$Overlay(value) {
    (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_document__elemental2_dom_DomGlobal_$Overlay = value);
  }
  
  /**
   * @return {Location}
   * @public
   */
  static get f_location__elemental2_dom_DomGlobal_$Overlay() {
    return (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_location__elemental2_dom_DomGlobal_$Overlay);
  }
  
  /**
   * @param {Location} value
   * @return {void}
   * @public
   */
  static set f_location__elemental2_dom_DomGlobal_$Overlay(value) {
    (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_location__elemental2_dom_DomGlobal_$Overlay = value);
  }
  
  /**
   * @return {Navigator}
   * @public
   */
  static get f_navigator__elemental2_dom_DomGlobal_$Overlay() {
    return (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_navigator__elemental2_dom_DomGlobal_$Overlay);
  }
  
  /**
   * @param {Navigator} value
   * @return {void}
   * @public
   */
  static set f_navigator__elemental2_dom_DomGlobal_$Overlay(value) {
    (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_navigator__elemental2_dom_DomGlobal_$Overlay = value);
  }
  
  /**
   * @return {Screen}
   * @public
   */
  static get f_screen__elemental2_dom_DomGlobal_$Overlay() {
    return (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_screen__elemental2_dom_DomGlobal_$Overlay);
  }
  
  /**
   * @param {Screen} value
   * @return {void}
   * @public
   */
  static set f_screen__elemental2_dom_DomGlobal_$Overlay(value) {
    (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_screen__elemental2_dom_DomGlobal_$Overlay = value);
  }
  
  /**
   * @return {Window}
   * @public
   */
  static get f_self__elemental2_dom_DomGlobal_$Overlay() {
    return (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_self__elemental2_dom_DomGlobal_$Overlay);
  }
  
  /**
   * @param {Window} value
   * @return {void}
   * @public
   */
  static set f_self__elemental2_dom_DomGlobal_$Overlay(value) {
    (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_self__elemental2_dom_DomGlobal_$Overlay = value);
  }
  
  /**
   * @return {Window}
   * @public
   */
  static get f_top__elemental2_dom_DomGlobal_$Overlay() {
    return (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_top__elemental2_dom_DomGlobal_$Overlay);
  }
  
  /**
   * @param {Window} value
   * @return {void}
   * @public
   */
  static set f_top__elemental2_dom_DomGlobal_$Overlay(value) {
    (DomGlobal_$Overlay.$clinit(), DomGlobal_$Overlay.$f_top__elemental2_dom_DomGlobal_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof window;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DomGlobal_$Overlay.$clinit = function() {};
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    DomGlobal_$Overlay.$f_document__elemental2_dom_DomGlobal_$Overlay = window.document;
    DomGlobal_$Overlay.$f_location__elemental2_dom_DomGlobal_$Overlay = window.location;
    DomGlobal_$Overlay.$f_navigator__elemental2_dom_DomGlobal_$Overlay = window.navigator;
    DomGlobal_$Overlay.$f_screen__elemental2_dom_DomGlobal_$Overlay = window.screen;
    DomGlobal_$Overlay.$f_self__elemental2_dom_DomGlobal_$Overlay = window.self;
    DomGlobal_$Overlay.$f_top__elemental2_dom_DomGlobal_$Overlay = window.top;
  }
  
  
};

$Util.$setClassMetadata(DomGlobal_$Overlay, $Util.$makeClassName('window'));


/** @private {HTMLDocument} */
DomGlobal_$Overlay.$f_document__elemental2_dom_DomGlobal_$Overlay;


/** @private {Location} */
DomGlobal_$Overlay.$f_location__elemental2_dom_DomGlobal_$Overlay;


/** @private {Navigator} */
DomGlobal_$Overlay.$f_navigator__elemental2_dom_DomGlobal_$Overlay;


/** @private {Screen} */
DomGlobal_$Overlay.$f_screen__elemental2_dom_DomGlobal_$Overlay;


/** @private {Window} */
DomGlobal_$Overlay.$f_self__elemental2_dom_DomGlobal_$Overlay;


/** @private {Window} */
DomGlobal_$Overlay.$f_top__elemental2_dom_DomGlobal_$Overlay;


exports = DomGlobal_$Overlay; 
//# sourceMappingURL=DomGlobal$$Overlay.js.map