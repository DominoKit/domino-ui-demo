/**
 * @fileoverview transpiled from elemental2.dom.ByteLengthQueuingStrategy$ByteLengthQueuingStrategyConfigType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.ByteLengthQueuingStrategy.ByteLengthQueuingStrategyConfigType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');


// Re-exports the implementation.
var ByteLengthQueuingStrategyConfigType_$Overlay = goog.require('elemental2.dom.ByteLengthQueuingStrategy.ByteLengthQueuingStrategyConfigType.$Overlay$impl');
exports = ByteLengthQueuingStrategyConfigType_$Overlay;
 