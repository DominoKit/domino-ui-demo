/**
 * @fileoverview transpiled from elemental2.dom.AddEventListenerOptions$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.AddEventListenerOptions.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class AddEventListenerOptions_$Overlay {
  /**
   * @return {AddEventListenerOptions}
   * @public
   */
  static m_create__() {
    AddEventListenerOptions_$Overlay.$clinit();
    return /**@type {AddEventListenerOptions} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AddEventListenerOptions_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(AddEventListenerOptions_$Overlay, $Util.$makeClassName('AddEventListenerOptions'));


exports = AddEventListenerOptions_$Overlay; 
//# sourceMappingURL=AddEventListenerOptions$$Overlay.js.map