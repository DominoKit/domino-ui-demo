/**
 * @fileoverview transpiled from elemental2.dom.ByteLengthQueuingStrategy$SizeChunkType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.ByteLengthQueuingStrategy.SizeChunkType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class SizeChunkType_$Overlay {
  /**
   * @return {?}
   * @public
   */
  static m_create__() {
    SizeChunkType_$Overlay.$clinit();
    return /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SizeChunkType_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SizeChunkType_$Overlay, $Util.$makeClassName('?'));


exports = SizeChunkType_$Overlay; 
//# sourceMappingURL=ByteLengthQueuingStrategy$SizeChunkType$$Overlay.js.map