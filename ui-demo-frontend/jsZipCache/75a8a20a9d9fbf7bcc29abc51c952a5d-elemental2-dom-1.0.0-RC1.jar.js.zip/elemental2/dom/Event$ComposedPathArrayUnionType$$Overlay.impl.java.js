/**
 * @fileoverview transpiled from elemental2.dom.Event$ComposedPathArrayUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Event.ComposedPathArrayUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let ShadowRoot_$Overlay = goog.forwardDeclare('elemental2.dom.ShadowRoot.$Overlay$impl');
let Window_$Overlay = goog.forwardDeclare('elemental2.dom.Window.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ComposedPathArrayUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ComposedPathArrayUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Document}
   * @public
   */
  static m_asDocument__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return /**@type {Document} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Element}
   * @public
   */
  static m_asElement__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return /**@type {Element} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), Element_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {ShadowRoot}
   * @public
   */
  static m_asShadowRoot__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return /**@type {ShadowRoot} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), ShadowRoot_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Window}
   * @public
   */
  static m_asWindow__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return /**@type {Window} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), Window_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isDocument__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isElement__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return Element_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isShadowRoot__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return ShadowRoot_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isWindow__elemental2_dom_Event_ComposedPathArrayUnionType($thisArg) {
    ComposedPathArrayUnionType_$Overlay.$clinit();
    return Window_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComposedPathArrayUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Document.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    ShadowRoot_$Overlay = goog.module.get('elemental2.dom.ShadowRoot.$Overlay$impl');
    Window_$Overlay = goog.module.get('elemental2.dom.Window.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComposedPathArrayUnionType_$Overlay, $Util.$makeClassName('?'));


exports = ComposedPathArrayUnionType_$Overlay; 
//# sourceMappingURL=Event$ComposedPathArrayUnionType$$Overlay.js.map