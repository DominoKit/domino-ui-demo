/**
 * @fileoverview transpiled from elemental2.dom.DoubleRange$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.DoubleRange.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class DoubleRange_$Overlay {
  /**
   * @return {DoubleRange}
   * @public
   */
  static m_create__() {
    DoubleRange_$Overlay.$clinit();
    return /**@type {DoubleRange} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DoubleRange_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DoubleRange_$Overlay, $Util.$makeClassName('DoubleRange'));


exports = DoubleRange_$Overlay; 
//# sourceMappingURL=DoubleRange$$Overlay.js.map