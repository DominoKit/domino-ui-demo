/**
 * @fileoverview transpiled from elemental2.dom.FetchEvent$RespondWithRUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.FetchEvent.RespondWithRUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Response_$Overlay = goog.require('elemental2.dom.Response.$Overlay');
const _$Overlay = goog.require('elemental2.promise.IThenable.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var RespondWithRUnionType_$Overlay = goog.require('elemental2.dom.FetchEvent.RespondWithRUnionType.$Overlay$impl');
exports = RespondWithRUnionType_$Overlay;
 