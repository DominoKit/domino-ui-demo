/**
 * @fileoverview transpiled from elemental2.dom.Document$RegisterElementOptionsType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Document.RegisterElementOptionsType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class RegisterElementOptionsType_$Overlay {
  /**
   * @return {?}
   * @public
   */
  static m_create__() {
    RegisterElementOptionsType_$Overlay.$clinit();
    return /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RegisterElementOptionsType_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RegisterElementOptionsType_$Overlay, $Util.$makeClassName('?'));


exports = RegisterElementOptionsType_$Overlay; 
//# sourceMappingURL=Document$RegisterElementOptionsType$$Overlay.js.map