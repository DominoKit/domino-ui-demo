/**
 * @fileoverview transpiled from elemental2.dom.FetchEvent$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.FetchEvent.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.FetchEvent.RespondWithRUnionType.$Overlay$impl');
let Response_$Overlay = goog.forwardDeclare('elemental2.dom.Response.$Overlay$impl');
let IThenable_$Overlay = goog.forwardDeclare('elemental2.promise.IThenable.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class FetchEvent_$Overlay {
  /**
   * @param {FetchEvent} $thisArg
   * @param {IThenable<Response>} r
   * @return {void}
   * @public
   */
  static m_respondWith__elemental2_dom_FetchEvent__elemental2_promise_IThenable($thisArg, r) {
    FetchEvent_$Overlay.$clinit();
    $thisArg.respondWith(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(r)));
  }
  
  /**
   * @param {FetchEvent} $thisArg
   * @param {Response} r
   * @return {void}
   * @public
   */
  static m_respondWith__elemental2_dom_FetchEvent__elemental2_dom_Response($thisArg, r) {
    FetchEvent_$Overlay.$clinit();
    $thisArg.respondWith(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(r)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FetchEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FetchEvent_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(FetchEvent_$Overlay, $Util.$makeClassName('FetchEvent'));


exports = FetchEvent_$Overlay; 
//# sourceMappingURL=FetchEvent$$Overlay.js.map