/**
 * @fileoverview transpiled from elemental2.dom.CharacterData$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.CharacterData.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.CharacterData.ReplaceWithNodesUnionType.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class CharacterData_$Overlay {
  /**
   * @param {CharacterData} $thisArg
   * @param {Array<Node>} nodes
   * @return {void}
   * @public
   */
  static m_replaceWith__elemental2_dom_CharacterData__arrayOf_elemental2_dom_Node($thisArg, nodes) {
    CharacterData_$Overlay.$clinit();
    $thisArg.replaceWith(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(nodes)));
  }
  
  /**
   * @param {CharacterData} $thisArg
   * @param {Array<?string>} nodes
   * @return {void}
   * @public
   */
  static m_replaceWith__elemental2_dom_CharacterData__arrayOf_java_lang_String($thisArg, nodes) {
    CharacterData_$Overlay.$clinit();
    $thisArg.replaceWith(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(nodes)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CharacterData;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CharacterData_$Overlay.$clinit = function() {};
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(CharacterData_$Overlay, $Util.$makeClassName('CharacterData'));


exports = CharacterData_$Overlay; 
//# sourceMappingURL=CharacterData$$Overlay.js.map