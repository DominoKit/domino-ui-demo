/**
 * @fileoverview transpiled from elemental2.dom.DedicatedWorkerGlobalScope$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.DedicatedWorkerGlobalScope.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface($Overlay, $Util.$makeClassName('DedicatedWorkerGlobalScope'));


exports = $Overlay; 
//# sourceMappingURL=DedicatedWorkerGlobalScope$$Overlay.js.map