/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let AdvancedFormsPresenter = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenter$impl');


/**
 * @extends {PresenterCommand<AdvancedFormsPresenter>}
  */
class AdvancedFormsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedFormsPresenterCommand()'.
   * @return {!AdvancedFormsPresenterCommand}
   * @public
   */
  static $create__() {
    AdvancedFormsPresenterCommand.$clinit();
    let $instance = new AdvancedFormsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_presenters_AdvancedFormsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedFormsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_presenters_AdvancedFormsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedFormsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedFormsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AdvancedFormsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand'));




exports = AdvancedFormsPresenterCommand; 
//# sourceMappingURL=AdvancedFormsPresenterCommand.js.map