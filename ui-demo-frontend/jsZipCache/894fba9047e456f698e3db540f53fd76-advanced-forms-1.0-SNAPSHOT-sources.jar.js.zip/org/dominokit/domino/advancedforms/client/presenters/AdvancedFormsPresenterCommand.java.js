/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _AdvancedFormsPresenter = goog.require('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenter');


// Re-exports the implementation.
var AdvancedFormsPresenterCommand = goog.require('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand$impl');
exports = AdvancedFormsPresenterCommand;
 