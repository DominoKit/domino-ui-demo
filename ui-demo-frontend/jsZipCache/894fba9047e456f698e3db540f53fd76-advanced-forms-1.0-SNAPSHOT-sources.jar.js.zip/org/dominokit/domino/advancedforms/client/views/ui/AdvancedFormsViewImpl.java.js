/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AdvancedFormsView = goog.require('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _File_$Overlay = goog.require('elemental2.dom.File.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Response_$Overlay = goog.require('elemental2.dom.Response.$Overlay');
const _XMLHttpRequest_$Overlay = goog.require('elemental2.dom.XMLHttpRequest.$Overlay');
const _Promise_$Overlay = goog.require('elemental2.promise.Promise.$Overlay');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _Arrays = goog.require('java.util.Arrays');
const _Collections = goog.require('java.util.Collections');
const _List = goog.require('java.util.List');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _JsPropertyMap_$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.$LambdaAdaptor$2');
const _Person = goog.require('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.Person');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _LocalSuggestBoxStore = goog.require('org.dominokit.domino.ui.forms.LocalSuggestBoxStore');
const _SuggestBox = goog.require('org.dominokit.domino.ui.forms.SuggestBox');
const _SuggestBoxStore = goog.require('org.dominokit.domino.ui.forms.SuggestBoxStore');
const _SuggestionsHandler = goog.require('org.dominokit.domino.ui.forms.SuggestBoxStore.SuggestionsHandler');
const _SuggestItem = goog.require('org.dominokit.domino.ui.forms.SuggestItem');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _ValidationResult = goog.require('org.dominokit.domino.ui.forms.validations.ValidationResult');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _KeyboardEvents = goog.require('org.dominokit.domino.ui.keyboard.KeyboardEvents');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _TagsInput = goog.require('org.dominokit.domino.ui.tag.TagsInput');
const _LocalTagsStore = goog.require('org.dominokit.domino.ui.tag.store.LocalTagsStore');
const _FileItem = goog.require('org.dominokit.domino.ui.upload.FileItem');
const _ErrorHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.ErrorHandler');
const _RemoveFileHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler');
const _SuccessUploadHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.SuccessUploadHandler');
const _FileUpload = goog.require('org.dominokit.domino.ui.upload.FileUpload');
const _OnAddFileHandler = goog.require('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler');
const _Validator = goog.require('org.dominokit.domino.ui.utils.HasValidation.Validator');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AdvancedFormsViewImpl = goog.require('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl$impl');
exports = AdvancedFormsViewImpl;
 