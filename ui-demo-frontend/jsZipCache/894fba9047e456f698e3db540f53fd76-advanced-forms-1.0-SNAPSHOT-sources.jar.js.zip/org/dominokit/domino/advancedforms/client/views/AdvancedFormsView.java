package org.dominokit.domino.advancedforms.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface AdvancedFormsView extends View, DemoView {
}