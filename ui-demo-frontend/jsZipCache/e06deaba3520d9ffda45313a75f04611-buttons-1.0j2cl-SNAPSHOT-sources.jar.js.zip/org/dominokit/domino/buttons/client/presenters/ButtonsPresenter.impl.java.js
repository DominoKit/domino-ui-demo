/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.presenters.ButtonsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter.$1$impl');
let ButtonsView = goog.forwardDeclare('org.dominokit.domino.buttons.client.views.ButtonsView$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<ButtonsView>}
  */
class ButtonsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ButtonsPresenter()'.
   * @return {!ButtonsPresenter}
   * @public
   */
  static $create__() {
    ButtonsPresenter.$clinit();
    let $instance = new ButtonsPresenter();
    $instance.$ctor__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ButtonsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter_() {
    return (ButtonsPresenter.$clinit(), ButtonsPresenter.$f_LOGGER__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter_(value) {
    (ButtonsPresenter.$clinit(), ButtonsPresenter.$f_LOGGER__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ButtonsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    ButtonsPresenter.$f_LOGGER__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ButtonsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ButtonsPresenter, $Util.$makeClassName('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter'));


/** @private {Logger} */
ButtonsPresenter.$f_LOGGER__org_dominokit_domino_buttons_client_presenters_ButtonsPresenter_;




exports = ButtonsPresenter; 
//# sourceMappingURL=ButtonsPresenter.js.map