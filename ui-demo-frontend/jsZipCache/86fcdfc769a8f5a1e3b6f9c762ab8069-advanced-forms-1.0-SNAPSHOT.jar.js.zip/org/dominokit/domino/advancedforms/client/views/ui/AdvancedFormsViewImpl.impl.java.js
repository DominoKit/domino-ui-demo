/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AdvancedFormsView = goog.require('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let File_$Overlay = goog.forwardDeclare('elemental2.dom.File.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Response_$Overlay = goog.forwardDeclare('elemental2.dom.Response.$Overlay$impl');
let XMLHttpRequest_$Overlay = goog.forwardDeclare('elemental2.dom.XMLHttpRequest.$Overlay$impl');
let Promise_$Overlay = goog.forwardDeclare('elemental2.promise.Promise.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let Collections = goog.forwardDeclare('java.util.Collections$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let JsPropertyMap_$Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.$LambdaAdaptor$2$impl');
let Person = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.Person$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let LocalSuggestBoxStore = goog.forwardDeclare('org.dominokit.domino.ui.forms.LocalSuggestBoxStore$impl');
let SuggestBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.SuggestBox$impl');
let SuggestBoxStore = goog.forwardDeclare('org.dominokit.domino.ui.forms.SuggestBoxStore$impl');
let SuggestionsHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.SuggestBoxStore.SuggestionsHandler$impl');
let SuggestItem = goog.forwardDeclare('org.dominokit.domino.ui.forms.SuggestItem$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let ValidationResult = goog.forwardDeclare('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let KeyboardEvents = goog.forwardDeclare('org.dominokit.domino.ui.keyboard.KeyboardEvents$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let TagsInput = goog.forwardDeclare('org.dominokit.domino.ui.tag.TagsInput$impl');
let LocalTagsStore = goog.forwardDeclare('org.dominokit.domino.ui.tag.store.LocalTagsStore$impl');
let FileItem = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem$impl');
let ErrorHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.ErrorHandler$impl');
let RemoveFileHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler$impl');
let SuccessUploadHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.SuccessUploadHandler$impl');
let FileUpload = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileUpload$impl');
let OnAddFileHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {AdvancedFormsView}
  */
class AdvancedFormsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
    /** @public {Card} */
    this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
    /** @public {Card} */
    this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
    /** @public {Card} */
    this.f_suggestBoxCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedFormsViewImpl()'.
   * @return {!AdvancedFormsViewImpl}
   * @public
   */
  static $create__() {
    AdvancedFormsViewImpl.$clinit();
    let $instance = new AdvancedFormsViewImpl();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedFormsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(AdvancedFormsViewImpl.f_MODULE_NAME__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl, Class.$get(AdvancedFormsViewImpl)).m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("ADVANCED FORM ELEMENTS").m_asElement__());
    this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = Card.m_create__java_lang_String("FILE UPLOAD - DRAG & DROP OR WITH CLICK & CHOOSE");
    this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = Card.m_create__java_lang_String("TAGS INPUT");
    this.f_suggestBoxCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = Card.m_create__java_lang_String("SUGGEST BOX");
    this.m_initFileUploadExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl();
    this.m_initTagsInputExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl();
    this.m_initSuggestBoxExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl();
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AdvancedFormsViewImpl.f_MODULE_NAME__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl, "upload-example").m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AdvancedFormsViewImpl.f_MODULE_NAME__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl, "tags-example").m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(this.f_suggestBoxCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(AdvancedFormsViewImpl.f_MODULE_NAME__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl, "suggest-box-example").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFileUploadExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl() {
    let fileUpload = FileUpload.m_create__().m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_touch_app__()).m_setUrl__java_lang_String("http://localhost:8080/form").m_multipleFiles__().m_accept__java_lang_String("image/*").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Drop files here or click to upload."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_em__().m_textContent__java_lang_String("(This is just a demo upload. Selected files are not actually uploaded)"), IsElement))).m_onAddFile__org_dominokit_domino_ui_upload_FileUpload_OnAddFileHandler(OnAddFileHandler.$adapt(((/** FileItem */ fileItem) =>{
      fileItem.m_addErrorHandler__org_dominokit_domino_ui_upload_FileItem_ErrorHandler(ErrorHandler.$adapt(((/** XMLHttpRequest */ request) =>{
        Notification.m_createDanger__java_lang_String("Error while uploading " + j_l_String.m_valueOf__java_lang_Object(request.responseText)).m_show__();
      })));
      fileItem.m_addSuccessUploadHandler__org_dominokit_domino_ui_upload_FileItem_SuccessUploadHandler(SuccessUploadHandler.$adapt(((/** XMLHttpRequest */ request$1$) =>{
        Notification.m_createSuccess__java_lang_String("File uploaded successfully").m_show__();
      })));
      fileItem.m_addRemoveHandler__org_dominokit_domino_ui_upload_FileItem_RemoveFileHandler(RemoveFileHandler.$adapt(((/** File */ file) =>{
        Notification.m_createInfo__java_lang_String("File has been removed " + j_l_String.m_valueOf__java_lang_Object(file.name)).m_show__();
      })));
    })));
    this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(fileUpload);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initTagsInputExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl() {
    this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("FREE TEXT TAGS", "Free text tags accept any text value")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(TagsInput.m_create__java_lang_String("Free tag").m_setPlaceholder__java_lang_String("Type anything...").m_value__java_lang_Object(/**@type {List<?string>} */ (Collections.m_singletonList__java_lang_Object("Hey! how are you?")))), Column))));
    let schroeder_coleman = Person.$create__int__java_lang_String(1, "Schroeder Coleman");
    let personsStore = /**@type {LocalTagsStore<Person>} */ (LocalTagsStore.m_create__()).m_addItem__java_lang_String__java_lang_Object("Schroeder Coleman", schroeder_coleman).m_addItem__java_lang_String__java_lang_Object("Renee Mcintyre", Person.$create__int__java_lang_String(2, "Renee Mcintyre")).m_addItem__java_lang_String__java_lang_Object("Casey Garza", Person.$create__int__java_lang_String(3, "Casey Garza"));
    let objectTags = /**@type {TagsInput<Person>} */ (TagsInput.m_create__java_lang_String__org_dominokit_domino_ui_tag_store_TagsStore("Friends", personsStore));
    objectTags.m_setValue__java_lang_Object(/**@type {List<Person>} */ (Collections.m_singletonList__java_lang_Object(schroeder_coleman)));
    this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("SELECT TAGS", "Select tags have store of objects to be selected")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(objectTags.m_setPlaceholder__java_lang_String("Friend's name...")), Column))));
    let ipAddresses = TagsInput.m_create__java_lang_String("IP addresses");
    this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("TAGS DECORATIONS", "Tags input has its own decorations")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(/**@type {TagsInput<?string>} */ ($Casts.$to(/**@type {TagsInput<?string>} */ ($Casts.$to(ipAddresses.m_setHelperText__java_lang_String("Pattern: 000.000.000.000"), TagsInput)).m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(Validator.$adapt((() =>{
      let ipAddressesValue = ipAddresses.m_getValue__();
      for (let $iterator = ipAddressesValue.m_iterator__(); $iterator.m_hasNext__(); ) {
        let v = /**@type {?string} */ ($Casts.$to($iterator.m_next__(), j_l_String));
        if (!new RegExp(AdvancedFormsViewImpl.f_IP_ADDRESS_REGEX__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_).test(v)) {
          return ValidationResult.m_invalid__java_lang_String("Invalid IP address [ " + j_l_String.m_valueOf__java_lang_Object(v) + " ]");
        }
      }
      return ValidationResult.m_valid__();
    }))), TagsInput)).m_value__java_lang_Object(/**@type {List<?string>} */ (Collections.m_singletonList__java_lang_Object("127.0.0.1"))), TagsInput)).m_setPlaceholder__java_lang_String("Type invalid address...").m_setAutoValidation__boolean(true)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("READONLY")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__java_lang_String("Hardware").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setReadOnly__boolean(true)), Column))));
    this.f_tagsInputCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String("TAGS WITH COLORS", "Tags can have colors!")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__().m_setPlaceholder__java_lang_String("Type hardware name...").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setTagsColor__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_RED__org_dominokit_domino_ui_style_ColorScheme)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__().m_setPlaceholder__java_lang_String("Type hardware name...").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setTagsColor__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TEAL__org_dominokit_domino_ui_style_ColorScheme)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__().m_setPlaceholder__java_lang_String("Type hardware name...").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setTagsColor__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_CYAN__org_dominokit_domino_ui_style_ColorScheme)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__().m_setPlaceholder__java_lang_String("Type hardware name...").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setTagsColor__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BROWN__org_dominokit_domino_ui_style_ColorScheme)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__().m_setPlaceholder__java_lang_String("Type hardware name...").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setTagsColor__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__().m_setPlaceholder__java_lang_String("Type hardware name...").m_value__java_lang_Object(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Keyboard", "Screen", "USB Driver", "Mouse"], j_l_String))))), TagsInput)).m_setTagsColor__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme)), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSuggestBoxExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl() {
    let localStore = LocalSuggestBoxStore.m_create__().m_addSuggestion__org_dominokit_domino_ui_forms_SuggestItem(SuggestItem.m_create__java_lang_String("Schroeder Coleman")).m_addSuggestion__org_dominokit_domino_ui_forms_SuggestItem(SuggestItem.m_create__java_lang_String("Renee Mcintyre")).m_addSuggestion__org_dominokit_domino_ui_forms_SuggestItem(SuggestItem.m_create__java_lang_String("Casey Garza"));
    let friendNameBox = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Your friend name").m_setHelperText__java_lang_String("Add friend name as suggestion"), TextBox));
    KeyboardEvents.m_listenOn__org_jboss_gwt_elemento_core_IsElement(friendNameBox).m_onEnter__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      localStore.m_addSuggestion__org_dominokit_domino_ui_forms_SuggestItem(SuggestItem.m_create__java_lang_String(friendNameBox.m_getValue__()));
      friendNameBox.m_clear__();
    })));
    this.f_suggestBoxCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_setBodyPaddingTop__java_lang_String("40px").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Local suggest store")), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(friendNameBox), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createPrimary__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_add__()).m_setContent__java_lang_String("ADD FRIEND"), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      localStore.m_addSuggestion__org_dominokit_domino_ui_forms_SuggestItem(SuggestItem.m_create__java_lang_String(friendNameBox.m_getValue__()));
      friendNameBox.m_clear__();
    })))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(SuggestBox.m_create__java_lang_String__org_dominokit_domino_ui_forms_SuggestBoxStore("Your friends", localStore).m_setHelperText__java_lang_String("Type any letter and see suggestions")), Column))));
    let dynamicStore = SuggestBoxStore.$adapt(((/** ?string */ searchValue, /** SuggestionsHandler */ suggestionsHandler) =>{
      /**@type {Promise<*>} */ (/**@type {Promise<?string>} */ ($Overlay.m_fetch__java_lang_String("https://restcountries.eu/rest/v2/all").then(((/** Response */ arg0) =>{
        return arg0.text();
      }))).then(((/** ?string */ json) =>{
        let suggestItems = /**@type {!ArrayList<SuggestItem>} */ (ArrayList.$create__());
        let randomNames = /**@type {Array<Object<string, ?string>>} */ ($Casts.$to(Js.m_cast__java_lang_Object(window.JSON.parse(json)), JsArray_$Overlay));
        for (let i = 0; i < randomNames.length; i++) {
          let nameProperties = /**@type {Object<string, ?string>} */ ($Casts.$to(JsArrayLike_$Overlay.m_getAt__jsinterop_base_JsArrayLike__int(randomNames, i), JsPropertyMap_$Overlay));
          if (j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(/**@type {?string} */ ($Casts.$to(JsPropertyMap_$Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(nameProperties, "name"), j_l_String))), j_l_String.m_toLowerCase__java_lang_String(searchValue))) {
            let suggestItem = SuggestItem.m_create__java_lang_String(/**@type {?string} */ ($Casts.$to(JsPropertyMap_$Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(nameProperties, "name"), j_l_String)));
            suggestItems.add(suggestItem);
          }
        }
        suggestionsHandler.m_onSuggestionsReady__java_util_List(suggestItems);
        return null;
      })));
    }));
    this.f_suggestBoxCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Dynamic suggest store")), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(SuggestBox.m_create__java_lang_String__org_dominokit_domino_ui_forms_SuggestBoxStore("Country", dynamicStore)), Column))));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl() {
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedFormsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedFormsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsViewImpl.$clinit = function() {};
    JsArray_$Overlay = goog.module.get('elemental2.core.JsArray.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Class = goog.module.get('java.lang.Class$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    Collections = goog.module.get('java.util.Collections$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    JsArrayLike_$Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    JsPropertyMap_$Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.$LambdaAdaptor$2$impl');
    Person = goog.module.get('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.Person$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    LocalSuggestBoxStore = goog.module.get('org.dominokit.domino.ui.forms.LocalSuggestBoxStore$impl');
    SuggestBox = goog.module.get('org.dominokit.domino.ui.forms.SuggestBox$impl');
    SuggestBoxStore = goog.module.get('org.dominokit.domino.ui.forms.SuggestBoxStore$impl');
    SuggestItem = goog.module.get('org.dominokit.domino.ui.forms.SuggestItem$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    ValidationResult = goog.module.get('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    KeyboardEvents = goog.module.get('org.dominokit.domino.ui.keyboard.KeyboardEvents$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    TagsInput = goog.module.get('org.dominokit.domino.ui.tag.TagsInput$impl');
    LocalTagsStore = goog.module.get('org.dominokit.domino.ui.tag.store.LocalTagsStore$impl');
    ErrorHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.ErrorHandler$impl');
    RemoveFileHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler$impl');
    SuccessUploadHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.SuccessUploadHandler$impl');
    FileUpload = goog.module.get('org.dominokit.domino.ui.upload.FileUpload$impl');
    OnAddFileHandler = goog.module.get('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler$impl');
    Validator = goog.module.get('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AdvancedFormsViewImpl, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl'));


/** @public {?string} @const */
AdvancedFormsViewImpl.f_IP_ADDRESS_REGEX__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";


/** @public {?string} @const */
AdvancedFormsViewImpl.f_MODULE_NAME__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl = "advanced-forms";


AdvancedFormsView.$markImplementor(AdvancedFormsViewImpl);


exports = AdvancedFormsViewImpl; 
//# sourceMappingURL=AdvancedFormsViewImpl.js.map