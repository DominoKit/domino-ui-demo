/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.listeners.AdvancedFormsPresenterListenerForFormsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.listeners.AdvancedFormsPresenterListenerForFormsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let AdvancedFormsPresenter = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenter$impl');
let AdvancedFormsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand$impl');
let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsEvent = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<FormsEvent>}
  */
class AdvancedFormsPresenterListenerForFormsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedFormsPresenterListenerForFormsEvent()'.
   * @return {!AdvancedFormsPresenterListenerForFormsEvent}
   * @public
   */
  static $create__() {
    AdvancedFormsPresenterListenerForFormsEvent.$clinit();
    let $instance = new AdvancedFormsPresenterListenerForFormsEvent();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_listeners_AdvancedFormsPresenterListenerForFormsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedFormsPresenterListenerForFormsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_listeners_AdvancedFormsPresenterListenerForFormsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {FormsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_forms_shared_extension_FormsEvent(event) {
    AdvancedFormsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** AdvancedFormsPresenter */ presenter) =>{
      presenter.m_onMainEvent__org_dominokit_domino_forms_shared_extension_FormsContext(/**@type {FormsContext} */ ($Casts.$to(event.m_context__(), FormsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_forms_shared_extension_FormsEvent(/**@type {FormsEvent} */ ($Casts.$to(arg0, FormsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedFormsPresenterListenerForFormsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedFormsPresenterListenerForFormsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsPresenterListenerForFormsEvent.$clinit = function() {};
    AdvancedFormsPresenterCommand = goog.module.get('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand$impl');
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsEvent = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AdvancedFormsPresenterListenerForFormsEvent, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.listeners.AdvancedFormsPresenterListenerForFormsEvent'));


DominoEventListener.$markImplementor(AdvancedFormsPresenterListenerForFormsEvent);


exports = AdvancedFormsPresenterListenerForFormsEvent; 
//# sourceMappingURL=AdvancedFormsPresenterListenerForFormsEvent.js.map