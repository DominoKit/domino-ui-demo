/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.views.ui.Person.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.views.ui.Person$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Person extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_id__org_dominokit_domino_advancedforms_client_views_ui_Person_ = 0;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_advancedforms_client_views_ui_Person_;
  }
  
  /**
   * Factory method corresponding to constructor 'Person(int, String)'.
   * @param {number} id
   * @param {?string} name
   * @return {!Person}
   * @public
   */
  static $create__int__java_lang_String(id, name) {
    Person.$clinit();
    let $instance = new Person();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_views_ui_Person__int__java_lang_String(id, name);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Person(int, String)'.
   * @param {number} id
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_views_ui_Person__int__java_lang_String(id, name) {
    this.$ctor__java_lang_Object__();
    this.f_id__org_dominokit_domino_advancedforms_client_views_ui_Person_ = id;
    this.f_name__org_dominokit_domino_advancedforms_client_views_ui_Person_ = name;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getId__() {
    return this.f_id__org_dominokit_domino_advancedforms_client_views_ui_Person_;
  }
  
  /**
   * @param {number} id
   * @return {void}
   * @public
   */
  m_setId__int(id) {
    this.f_id__org_dominokit_domino_advancedforms_client_views_ui_Person_ = id;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_advancedforms_client_views_ui_Person_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_domino_advancedforms_client_views_ui_Person_ = name;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Person;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Person);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Person.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Person, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.views.ui.Person'));




exports = Person; 
//# sourceMappingURL=Person.js.map