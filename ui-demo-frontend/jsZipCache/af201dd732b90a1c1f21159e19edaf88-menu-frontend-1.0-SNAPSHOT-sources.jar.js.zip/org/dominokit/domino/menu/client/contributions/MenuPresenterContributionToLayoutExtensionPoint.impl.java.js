/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.contributions.MenuPresenterContributionToLayoutExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.contributions.MenuPresenterContributionToLayoutExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
let MenuPresenter = goog.forwardDeclare('org.dominokit.domino.menu.client.presenters.MenuPresenter$impl');
let MenuPresenterCommand = goog.forwardDeclare('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<LayoutExtensionPoint>}
  */
class MenuPresenterContributionToLayoutExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MenuPresenterContributionToLayoutExtensionPoint()'.
   * @return {!MenuPresenterContributionToLayoutExtensionPoint}
   * @public
   */
  static $create__() {
    MenuPresenterContributionToLayoutExtensionPoint.$clinit();
    let $instance = new MenuPresenterContributionToLayoutExtensionPoint();
    $instance.$ctor__org_dominokit_domino_menu_client_contributions_MenuPresenterContributionToLayoutExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuPresenterContributionToLayoutExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_contributions_MenuPresenterContributionToLayoutExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(extensionPoint) {
    MenuPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** MenuPresenter */ presenter) =>{
      presenter.m_contributeToLayoutModule__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(extensionPoint.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(/**@type {LayoutExtensionPoint} */ ($Casts.$to(arg0, LayoutExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuPresenterContributionToLayoutExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuPresenterContributionToLayoutExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuPresenterContributionToLayoutExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutExtensionPoint = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
    MenuPresenterCommand = goog.module.get('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuPresenterContributionToLayoutExtensionPoint, $Util.$makeClassName('org.dominokit.domino.menu.client.contributions.MenuPresenterContributionToLayoutExtensionPoint'));


Contribution.$markImplementor(MenuPresenterContributionToLayoutExtensionPoint);


exports = MenuPresenterContributionToLayoutExtensionPoint; 
//# sourceMappingURL=MenuPresenterContributionToLayoutExtensionPoint.js.map