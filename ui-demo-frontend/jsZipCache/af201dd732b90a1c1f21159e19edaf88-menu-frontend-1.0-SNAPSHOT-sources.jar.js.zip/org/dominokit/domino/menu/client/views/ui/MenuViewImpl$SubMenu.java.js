/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.ui.MenuViewImpl$SubMenu.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _MenuViewImpl = goog.require('org.dominokit.domino.menu.client.views.ui.MenuViewImpl');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu.$LambdaAdaptor$3');
const _OnMenuSelectedHandler = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler');
const _MenuItem = goog.require('org.dominokit.domino.ui.menu.MenuItem');


// Re-exports the implementation.
var SubMenu = goog.require('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');
exports = SubMenu;
 