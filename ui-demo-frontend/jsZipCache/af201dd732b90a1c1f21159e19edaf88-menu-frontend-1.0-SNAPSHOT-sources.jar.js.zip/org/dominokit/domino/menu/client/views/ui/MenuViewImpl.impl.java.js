/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.ui.MenuViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.menu.client.views.ui.MenuViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MenuView = goog.require('org.dominokit.domino.menu.client.views.MenuView$impl');

let HeightUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
let MarginTopUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginTopUnionType.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$2$impl');
let SubMenu = goog.forwardDeclare('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');
let CanAddMenuItem = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem$impl');
let OnMenuSelectedHandler = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Menu = goog.forwardDeclare('org.dominokit.domino.ui.menu.Menu$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {MenuView}
  */
class MenuViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Menu} */
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_;
    /** @public {Icon} */
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_;
    /** @public {boolean} */
    this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'MenuViewImpl()'.
   * @return {!MenuViewImpl}
   * @public
   */
  static $create__() {
    MenuViewImpl.$clinit();
    let $instance = new MenuViewImpl();
    $instance.$ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_menu_client_views_ui_MenuViewImpl();
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().style.marginBottom = $Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(0));
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().style.marginTop = MarginTopUnionType_$Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(0));
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().classList.add("pull-right");
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().style.cursor = "pointer";
  }
  
  /**
   * @override
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = Menu.m_create__java_lang_String("Demo menu");
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_getRoot__().style.height = HeightUnionType_$Overlay.m_of__java_lang_Object("calc(100vh - 250px)");
    let leftPanel = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(layout.m_getLeftPanel__().m_get__()), HTMLElement_$Overlay));
    leftPanel.appendChild(this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__());
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_getHeader__().appendChild(this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__());
    this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().style.height = HeightUnionType_$Overlay.m_of__java_lang_Object("calc(100vh - 237px)");
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().addEventListener("click", new $LambdaAdaptor$1(((/** Event */ evt) =>{
      if (this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_) {
        layout.m_unfixLeftPanelPosition__();
        this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock__().m_getName__();
        layout.m_hideLeftPanel__();
        this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
      } else {
        layout.m_fixLeftPanelPosition__();
        this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock_open__().m_getName__();
        this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = true;
      }
    })));
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @param {OnMenuSelectedHandler} selectionHandler
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String__org_dominokit_domino_menu_shared_extension_MenuContext_OnMenuSelectedHandler(title, iconName, selectionHandler) {
    let menuItem = this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_addMenuItem__java_lang_String__org_dominokit_domino_ui_icons_Icon(title, Icon.m_create__java_lang_String(iconName));
    menuItem.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$2(((/** Event */ e) =>{
      selectionHandler.m_onMenuSelected__();
    })));
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem(this, menuItem);
  }
  
  /**
   * @override
   * @param {?string} title
   * @param {?string} iconName
   * @return {CanAddMenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__java_lang_String(title, iconName) {
    let menuItem = this.f_menu__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_.m_addMenuItem__java_lang_String__org_dominokit_domino_ui_icons_Icon(title, Icon.m_create__java_lang_String(iconName));
    return SubMenu.$create__org_dominokit_domino_menu_client_views_ui_MenuViewImpl__org_dominokit_domino_ui_menu_MenuItem(this, menuItem);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_menu_client_views_ui_MenuViewImpl() {
    this.f_lockIcon__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock_open__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color);
    this.f_locked__org_dominokit_domino_menu_client_views_ui_MenuViewImpl_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuViewImpl.$clinit = function() {};
    HeightUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
    MarginTopUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginTopUnionType.$Overlay$impl');
    HTMLElement_$Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.$LambdaAdaptor$2$impl');
    SubMenu = goog.module.get('org.dominokit.domino.menu.client.views.ui.MenuViewImpl.SubMenu$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Menu = goog.module.get('org.dominokit.domino.ui.menu.Menu$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuViewImpl, $Util.$makeClassName('org.dominokit.domino.menu.client.views.ui.MenuViewImpl'));


MenuView.$markImplementor(MenuViewImpl);


exports = MenuViewImpl; 
//# sourceMappingURL=MenuViewImpl.js.map