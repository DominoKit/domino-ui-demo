/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.contributions.MenuPresenterContributionToLayoutExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.client.contributions.MenuPresenterContributionToLayoutExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _LayoutExtensionPoint = goog.require('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint');
const _MenuPresenter = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenter');
const _MenuPresenterCommand = goog.require('org.dominokit.domino.menu.client.presenters.MenuPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MenuPresenterContributionToLayoutExtensionPoint = goog.require('org.dominokit.domino.menu.client.contributions.MenuPresenterContributionToLayoutExtensionPoint$impl');
exports = MenuPresenterContributionToLayoutExtensionPoint;
 