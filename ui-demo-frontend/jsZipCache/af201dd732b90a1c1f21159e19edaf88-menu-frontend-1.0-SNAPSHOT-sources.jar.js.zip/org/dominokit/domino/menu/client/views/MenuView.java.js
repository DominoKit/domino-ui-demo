/**
 * @fileoverview transpiled from org.dominokit.domino.menu.client.views.MenuView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.menu.client.views.MenuView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem');
const _OnMenuSelectedHandler = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler');


// Re-exports the implementation.
var MenuView = goog.require('org.dominokit.domino.menu.client.views.MenuView$impl');
exports = MenuView;
 