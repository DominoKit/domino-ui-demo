/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.LocalizedNames.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.LocalizedNames$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class LocalizedNames {
  /**
   * @abstract
   * @return {Array<?string>}
   * @public
   */
  m_getLikelyRegionCodes__() {
  }
  
  /**
   * @abstract
   * @param {?string} regionCode
   * @return {?string}
   * @public
   */
  m_getRegionName__java_lang_String(regionCode) {
  }
  
  /**
   * @abstract
   * @return {Array<?string>}
   * @public
   */
  m_getSortedRegionCodes__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_i18n_client_LocalizedNames = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_i18n_client_LocalizedNames;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_i18n_client_LocalizedNames;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LocalizedNames.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(LocalizedNames, $Util.$makeClassName('org.gwtproject.i18n.client.LocalizedNames'));


LocalizedNames.$markImplementor(/** @type {Function} */ (LocalizedNames));


exports = LocalizedNames; 
//# sourceMappingURL=LocalizedNames.js.map