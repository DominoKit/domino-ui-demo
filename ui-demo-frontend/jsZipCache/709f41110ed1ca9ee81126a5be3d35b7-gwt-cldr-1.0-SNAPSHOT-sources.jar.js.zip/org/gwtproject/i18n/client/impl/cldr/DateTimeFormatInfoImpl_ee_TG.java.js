/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ee_TG.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ee_TG');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__ee = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ee');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__ee__TG = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ee_TG$impl');
exports = DateTimeFormatInfoImpl__ee__TG;
 