/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_WS.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_WS$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__en__001 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_001$impl');


class DateTimeFormatInfoImpl__en__WS extends DateTimeFormatInfoImpl__en__001 {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_en_WS()'.
   * @return {!DateTimeFormatInfoImpl__en__WS}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__en__WS.$clinit();
    let $instance = new DateTimeFormatInfoImpl__en__WS();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_WS__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_en_WS()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_WS__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_001__();
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__en__WS;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__en__WS);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__en__WS.$clinit = function() {};
    DateTimeFormatInfoImpl__en__001.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__en__WS, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_WS'));




exports = DateTimeFormatInfoImpl__en__WS; 
//# sourceMappingURL=DateTimeFormatInfoImpl_en_WS.js.map