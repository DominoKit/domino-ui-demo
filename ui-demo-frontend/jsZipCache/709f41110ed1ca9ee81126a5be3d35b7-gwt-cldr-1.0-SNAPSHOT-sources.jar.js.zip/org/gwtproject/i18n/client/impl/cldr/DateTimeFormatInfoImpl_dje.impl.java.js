/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_dje.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_dje$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


class DateTimeFormatInfoImpl__dje extends DateTimeFormatInfoImpl {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_dje()'.
   * @return {!DateTimeFormatInfoImpl__dje}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__dje.$clinit();
    let $instance = new DateTimeFormatInfoImpl__dje();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_dje__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_dje()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_dje__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_ampms__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Subbaahi", "Zaarikay b"], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatFull__() {
    return "EEEE d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatLong__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatMedium__() {
    return "d MMM, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatShort__() {
    return "d/M/y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Isaa jine", "Isaa zamanoo"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["IJ", "IZ"], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMinuteSecond__() {
    return "m:ss";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthAbbrevDay__() {
    return "d MMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullWeekdayDay__() {
    return "EEEE d MMMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthNumDay__() {
    return "d/M";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrev__() {
    return "MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrevDay__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFullDay__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNum__() {
    return "M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNumDay__() {
    return "d/M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthWeekdayDay__() {
    return "EEE d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterFull__() {
    return "QQQQ y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterShort__() {
    return "Q y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["\u017Danwiye", "Feewiriye", "Marsi", "Awiril", "Me", "\u017Duwe\u014B", "\u017Duyye", "Ut", "Sektanbur", "Oktoobur", "Noowanbur", "Deesanbur"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["\u017D", "F", "M", "A", "M", "\u017D", "\u017D", "U", "S", "O", "N", "D"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["\u017Dan", "Fee", "Mar", "Awi", "Me", "\u017Duw", "\u017Duy", "Ut", "Sek", "Okt", "Noo", "Dee"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Arrubu 1", "Arrubu 2", "Arrubu 3", "Arrubu 4"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["A1", "A2", "A3", "A4"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Alhadi", "Atinni", "Atalaata", "Alarba", "Alhamisi", "Alzuma", "Asibti"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["H", "T", "T", "L", "M", "Z", "S"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Alh", "Ati", "Ata", "Ala", "Alm", "Alz", "Asi"], j_l_String));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__dje;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__dje);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__dje.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    DateTimeFormatInfoImpl.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__dje, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_dje'));




exports = DateTimeFormatInfoImpl__dje; 
//# sourceMappingURL=DateTimeFormatInfoImpl_dje.js.map