/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ar_BH.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ar_BH$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__ar__001 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ar_001$impl');


class DateTimeFormatInfoImpl__ar__BH extends DateTimeFormatInfoImpl__ar__001 {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_ar_BH()'.
   * @return {!DateTimeFormatInfoImpl__ar__BH}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__ar__BH.$clinit();
    let $instance = new DateTimeFormatInfoImpl__ar__BH();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ar_BH__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_ar_BH()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ar_BH__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ar_001__();
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 6;
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_weekendEnd__() {
    return 6;
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_weekendStart__() {
    return 5;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__ar__BH;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__ar__BH);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__ar__BH.$clinit = function() {};
    DateTimeFormatInfoImpl__ar__001.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__ar__BH, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ar_BH'));




exports = DateTimeFormatInfoImpl__ar__BH; 
//# sourceMappingURL=DateTimeFormatInfoImpl_ar_BH.js.map