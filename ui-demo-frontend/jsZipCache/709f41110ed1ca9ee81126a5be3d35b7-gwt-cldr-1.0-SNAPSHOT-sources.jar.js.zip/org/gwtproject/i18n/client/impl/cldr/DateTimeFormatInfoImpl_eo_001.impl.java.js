/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_eo_001.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_eo_001$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__eo = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_eo$impl');


class DateTimeFormatInfoImpl__eo__001 extends DateTimeFormatInfoImpl__eo {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_eo_001()'.
   * @return {!DateTimeFormatInfoImpl__eo__001}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__eo__001.$clinit();
    let $instance = new DateTimeFormatInfoImpl__eo__001();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_eo_001__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_eo_001()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_eo_001__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_eo__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__eo__001;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__eo__001);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__eo__001.$clinit = function() {};
    DateTimeFormatInfoImpl__eo.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__eo__001, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_eo_001'));




exports = DateTimeFormatInfoImpl__eo__001; 
//# sourceMappingURL=DateTimeFormatInfoImpl_eo_001.js.map