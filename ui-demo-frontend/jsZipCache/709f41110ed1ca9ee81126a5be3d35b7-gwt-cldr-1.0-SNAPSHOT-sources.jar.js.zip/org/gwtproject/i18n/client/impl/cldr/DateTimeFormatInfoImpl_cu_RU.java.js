/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu_RU.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu_RU');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__cu = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__cu__RU = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu_RU$impl');
exports = DateTimeFormatInfoImpl__cu__RU;
 