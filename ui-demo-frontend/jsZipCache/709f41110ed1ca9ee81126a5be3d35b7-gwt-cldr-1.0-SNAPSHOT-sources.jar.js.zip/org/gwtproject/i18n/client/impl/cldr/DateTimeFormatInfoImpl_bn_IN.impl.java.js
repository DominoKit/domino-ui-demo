/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_bn_IN.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_bn_IN$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__bn = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_bn$impl');


class DateTimeFormatInfoImpl__bn__IN extends DateTimeFormatInfoImpl__bn {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_bn_IN()'.
   * @return {!DateTimeFormatInfoImpl__bn__IN}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__bn__IN.$clinit();
    let $instance = new DateTimeFormatInfoImpl__bn__IN();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_bn_IN__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_bn_IN()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_bn_IN__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_bn__();
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_weekendStart__() {
    return 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__bn__IN;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__bn__IN);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__bn__IN.$clinit = function() {};
    DateTimeFormatInfoImpl__bn.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__bn__IN, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_bn_IN'));




exports = DateTimeFormatInfoImpl__bn__IN; 
//# sourceMappingURL=DateTimeFormatInfoImpl_bn_IN.js.map