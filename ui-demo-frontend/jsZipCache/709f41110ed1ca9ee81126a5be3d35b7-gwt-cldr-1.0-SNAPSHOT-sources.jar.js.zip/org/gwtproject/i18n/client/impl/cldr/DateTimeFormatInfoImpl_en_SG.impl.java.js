/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_SG.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_SG$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__en__001 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_001$impl');


class DateTimeFormatInfoImpl__en__SG extends DateTimeFormatInfoImpl__en__001 {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DateTimeFormatInfoImpl_en_SG()'.
   * @return {!DateTimeFormatInfoImpl__en__SG}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__en__SG.$clinit();
    let $instance = new DateTimeFormatInfoImpl__en__SG();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_SG__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateTimeFormatInfoImpl_en_SG()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_SG__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en_001__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatShort__() {
    return "d/M/yy";
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__en__SG;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__en__SG);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__en__SG.$clinit = function() {};
    DateTimeFormatInfoImpl__en__001.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__en__SG, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_SG'));




exports = DateTimeFormatInfoImpl__en__SG; 
//# sourceMappingURL=DateTimeFormatInfoImpl_en_SG.js.map