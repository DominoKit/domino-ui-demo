/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_T
 * @implements {DemoView}
  */
class ComponentView extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_initialized__org_dominokit_domino_componentcase_shared_extension_ComponentView_ = false;
  }
  
  /**
   * Initialization from constructor 'ComponentView()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_componentcase_shared_extension_ComponentView();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_doInit___$p_org_dominokit_domino_componentcase_shared_extension_ComponentView() {
    this.f_initialized__org_dominokit_domino_componentcase_shared_extension_ComponentView_ = true;
    this.m_init__();
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_init__() {
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    if (!this.f_initialized__org_dominokit_domino_componentcase_shared_extension_ComponentView_) {
      this.m_doInit___$p_org_dominokit_domino_componentcase_shared_extension_ComponentView();
    }
    return /**@type {Content<C_T>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.m_getElement__();
    })), Content));
  }
  
  /**
   * @param {?string} codeResource
   * @return {Card}
   * @public
   */
  m_createCodeCard__java_lang_String(codeResource) {
    return Card.m_createCodeCard__java_lang_String(codeResource);
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_getElement__() {
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_componentcase_shared_extension_ComponentView() {
    this.f_initialized__org_dominokit_domino_componentcase_shared_extension_ComponentView_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentView);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentView.$clinit = function() {};
    Content = goog.module.get('org.dominokit.domino.api.shared.extension.Content$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentView, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentView'));


DemoView.$markImplementor(ComponentView);


exports = ComponentView; 
//# sourceMappingURL=ComponentView.js.map