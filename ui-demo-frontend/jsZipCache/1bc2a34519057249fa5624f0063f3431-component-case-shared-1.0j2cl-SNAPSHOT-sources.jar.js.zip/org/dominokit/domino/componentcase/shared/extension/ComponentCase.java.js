/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCase.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCase');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _ComponentRemoveHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler');
const _ComponentRevealedHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler');


// Re-exports the implementation.
var ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase$impl');
exports = ComponentCase;
 