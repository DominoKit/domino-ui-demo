/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint.$LambdaAdaptor');


// Re-exports the implementation.
var ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
exports = ComponentCaseExtensionPoint;
 