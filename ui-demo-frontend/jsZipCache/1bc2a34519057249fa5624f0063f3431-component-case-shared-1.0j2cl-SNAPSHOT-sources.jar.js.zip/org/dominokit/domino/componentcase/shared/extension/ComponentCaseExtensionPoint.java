package org.dominokit.domino.componentcase.shared.extension;

import org.dominokit.domino.api.shared.extension.ExtensionPoint;

public interface ComponentCaseExtensionPoint extends ExtensionPoint<ComponentCaseContext>{
}
