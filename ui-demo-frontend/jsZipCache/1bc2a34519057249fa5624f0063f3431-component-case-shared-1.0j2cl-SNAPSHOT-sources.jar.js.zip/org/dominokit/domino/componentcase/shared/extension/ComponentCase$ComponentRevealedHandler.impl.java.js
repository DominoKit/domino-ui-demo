/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.shared.extension.ComponentCase$ComponentRevealedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ComponentRevealedHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onRevealed__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {ComponentRevealedHandler}
   * @public
   */
  static $adapt(fn) {
    ComponentRevealedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase_ComponentRevealedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase_ComponentRevealedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_componentcase_shared_extension_ComponentCase_ComponentRevealedHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentRevealedHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentRevealedHandler, $Util.$makeClassName('org.dominokit.domino.componentcase.shared.extension.ComponentCase$ComponentRevealedHandler'));


ComponentRevealedHandler.$markImplementor(/** @type {Function} */ (ComponentRevealedHandler));


exports = ComponentRevealedHandler; 
//# sourceMappingURL=ComponentCase$ComponentRevealedHandler.js.map