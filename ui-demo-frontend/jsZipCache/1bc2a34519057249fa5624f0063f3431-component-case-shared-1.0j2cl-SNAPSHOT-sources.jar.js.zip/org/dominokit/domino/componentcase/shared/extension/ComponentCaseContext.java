package org.dominokit.domino.componentcase.shared.extension;


import org.dominokit.domino.api.shared.extension.Context;

public interface ComponentCaseContext extends Context {
    void addComponentCase(ComponentCase componentCase);
}
