/**
 * @fileoverview transpiled from elemental2.svg.SVGFESpecularLightingElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFESpecularLightingElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFESpecularLightingElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFESpecularLightingElement'));


exports = $Overlay; 
//# sourceMappingURL=SVGFESpecularLightingElement$$Overlay.js.map