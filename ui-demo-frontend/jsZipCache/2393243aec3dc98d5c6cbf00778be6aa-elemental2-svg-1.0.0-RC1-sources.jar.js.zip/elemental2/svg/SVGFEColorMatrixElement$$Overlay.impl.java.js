/**
 * @fileoverview transpiled from elemental2.svg.SVGFEColorMatrixElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFEColorMatrixElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOLORMATRIX_TYPE_HUEROTATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_HUEROTATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOLORMATRIX_TYPE_HUEROTATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_HUEROTATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA__elemental2_svg_SVGFEColorMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA__elemental2_svg_SVGFEColorMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA__elemental2_svg_SVGFEColorMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA__elemental2_svg_SVGFEColorMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOLORMATRIX_TYPE_MATRIX__elemental2_svg_SVGFEColorMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_MATRIX__elemental2_svg_SVGFEColorMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOLORMATRIX_TYPE_MATRIX__elemental2_svg_SVGFEColorMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_MATRIX__elemental2_svg_SVGFEColorMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOLORMATRIX_TYPE_SATURATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_SATURATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOLORMATRIX_TYPE_SATURATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_SATURATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOLORMATRIX_TYPE_UNKNOWN__elemental2_svg_SVGFEColorMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_UNKNOWN__elemental2_svg_SVGFEColorMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOLORMATRIX_TYPE_UNKNOWN__elemental2_svg_SVGFEColorMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOLORMATRIX_TYPE_UNKNOWN__elemental2_svg_SVGFEColorMatrixElement_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFEColorMatrixElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
    $Overlay.$f_SVG_FECOLORMATRIX_TYPE_HUEROTATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay = SVGFEColorMatrixElement.SVG_FECOLORMATRIX_TYPE_HUEROTATE;
    $Overlay.$f_SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA__elemental2_svg_SVGFEColorMatrixElement_$Overlay = SVGFEColorMatrixElement.SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA;
    $Overlay.$f_SVG_FECOLORMATRIX_TYPE_MATRIX__elemental2_svg_SVGFEColorMatrixElement_$Overlay = SVGFEColorMatrixElement.SVG_FECOLORMATRIX_TYPE_MATRIX;
    $Overlay.$f_SVG_FECOLORMATRIX_TYPE_SATURATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay = SVGFEColorMatrixElement.SVG_FECOLORMATRIX_TYPE_SATURATE;
    $Overlay.$f_SVG_FECOLORMATRIX_TYPE_UNKNOWN__elemental2_svg_SVGFEColorMatrixElement_$Overlay = SVGFEColorMatrixElement.SVG_FECOLORMATRIX_TYPE_UNKNOWN;
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFEColorMatrixElement'));


/** @private {number} */
$Overlay.$f_SVG_FECOLORMATRIX_TYPE_HUEROTATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA__elemental2_svg_SVGFEColorMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOLORMATRIX_TYPE_MATRIX__elemental2_svg_SVGFEColorMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOLORMATRIX_TYPE_SATURATE__elemental2_svg_SVGFEColorMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOLORMATRIX_TYPE_UNKNOWN__elemental2_svg_SVGFEColorMatrixElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFEColorMatrixElement$$Overlay.js.map