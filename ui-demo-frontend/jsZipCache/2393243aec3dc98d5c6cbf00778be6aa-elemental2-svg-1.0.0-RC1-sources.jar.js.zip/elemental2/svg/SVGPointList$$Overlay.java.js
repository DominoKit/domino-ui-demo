/**
 * @fileoverview transpiled from elemental2.svg.SVGPointList$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.svg.SVGPointList.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var $Overlay = goog.require('elemental2.svg.SVGPointList.$Overlay$impl');
exports = $Overlay;
 