package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGComponentTransferFunctionElement", namespace = JsPackage.GLOBAL)
class SVGComponentTransferFunctionElement__Constants {
  static double SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE;
  static double SVG_FECOMPONENTTRANSFER_TYPE_GAMMA;
  static double SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY;
  static double SVG_FECOMPONENTTRANSFER_TYPE_LINEAR;
  static double SVG_FECOMPONENTTRANSFER_TYPE_TABLE;
  static double SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN;
}
