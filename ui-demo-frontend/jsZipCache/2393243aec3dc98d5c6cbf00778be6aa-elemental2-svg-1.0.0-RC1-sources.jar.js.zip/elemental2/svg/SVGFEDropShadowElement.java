package elemental2.svg;

import elemental2.dom.CSSValue;
import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsProperty;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGFEDropShadowElement extends SVGElement
    implements SVGFilterPrimitiveStandardAttributes {
  public SVGAnimatedString className;
  public SVGAnimatedNumber dx;
  public SVGAnimatedNumber dy;
  public SVGAnimatedLength height;
  public SVGAnimatedString in1;
  public SVGAnimatedString result;
  public SVGAnimatedNumber stdDeviationX;
  public SVGAnimatedNumber stdDeviationY;
  public SVGAnimatedLength width;
  public SVGAnimatedLength x;
  public SVGAnimatedLength y;

  @JsProperty
  public native SVGAnimatedString getClassName();

  @JsProperty
  public native SVGAnimatedLength getHeight();

  public native CSSValue getPresentationAttribute();

  public native CSSValue getPresentationAttribute(String name);

  @JsProperty
  public native SVGAnimatedString getResult();

  @JsProperty
  public native SVGAnimatedLength getWidth();

  @JsProperty
  public native SVGAnimatedLength getX();

  @JsProperty
  public native SVGAnimatedLength getY();

  @JsProperty
  public native void setClassName(SVGAnimatedString className);

  @JsProperty
  public native void setHeight(SVGAnimatedLength height);

  @JsProperty
  public native void setResult(SVGAnimatedString result);

  public native void setStdDeviation();

  public native void setStdDeviation(double stdDeviationX, double stdDeviationY);

  public native void setStdDeviation(double stdDeviationX);

  @JsProperty
  public native void setWidth(SVGAnimatedLength width);

  @JsProperty
  public native void setX(SVGAnimatedLength x);

  @JsProperty
  public native void setY(SVGAnimatedLength y);
}
