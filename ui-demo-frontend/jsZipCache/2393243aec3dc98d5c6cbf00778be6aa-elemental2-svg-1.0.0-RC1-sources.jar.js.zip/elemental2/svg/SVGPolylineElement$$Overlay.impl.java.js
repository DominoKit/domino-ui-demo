/**
 * @fileoverview transpiled from elemental2.svg.SVGPolylineElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGPolylineElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGPolylineElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGPolylineElement'));


exports = $Overlay; 
//# sourceMappingURL=SVGPolylineElement$$Overlay.js.map