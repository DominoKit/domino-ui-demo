package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public interface ElementTimeControl {
  void beginElement();

  void beginElementAt();

  void beginElementAt(double offset);

  void endElement();

  void endElementAt();

  void endElementAt(double offset);
}
