/**
 * @fileoverview transpiled from elemental2.svg.SVGFEMorphologyElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFEMorphologyElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MORPHOLOGY_OPERATOR_DILATE__elemental2_svg_SVGFEMorphologyElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_DILATE__elemental2_svg_SVGFEMorphologyElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MORPHOLOGY_OPERATOR_DILATE__elemental2_svg_SVGFEMorphologyElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_DILATE__elemental2_svg_SVGFEMorphologyElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MORPHOLOGY_OPERATOR_ERODE__elemental2_svg_SVGFEMorphologyElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_ERODE__elemental2_svg_SVGFEMorphologyElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MORPHOLOGY_OPERATOR_ERODE__elemental2_svg_SVGFEMorphologyElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_ERODE__elemental2_svg_SVGFEMorphologyElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MORPHOLOGY_OPERATOR_UNKNOWN__elemental2_svg_SVGFEMorphologyElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_UNKNOWN__elemental2_svg_SVGFEMorphologyElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MORPHOLOGY_OPERATOR_UNKNOWN__elemental2_svg_SVGFEMorphologyElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_UNKNOWN__elemental2_svg_SVGFEMorphologyElement_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFEMorphologyElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
    $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_DILATE__elemental2_svg_SVGFEMorphologyElement_$Overlay = SVGFEMorphologyElement.SVG_MORPHOLOGY_OPERATOR_DILATE;
    $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_ERODE__elemental2_svg_SVGFEMorphologyElement_$Overlay = SVGFEMorphologyElement.SVG_MORPHOLOGY_OPERATOR_ERODE;
    $Overlay.$f_SVG_MORPHOLOGY_OPERATOR_UNKNOWN__elemental2_svg_SVGFEMorphologyElement_$Overlay = SVGFEMorphologyElement.SVG_MORPHOLOGY_OPERATOR_UNKNOWN;
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFEMorphologyElement'));


/** @private {number} */
$Overlay.$f_SVG_MORPHOLOGY_OPERATOR_DILATE__elemental2_svg_SVGFEMorphologyElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MORPHOLOGY_OPERATOR_ERODE__elemental2_svg_SVGFEMorphologyElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MORPHOLOGY_OPERATOR_UNKNOWN__elemental2_svg_SVGFEMorphologyElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFEMorphologyElement$$Overlay.js.map