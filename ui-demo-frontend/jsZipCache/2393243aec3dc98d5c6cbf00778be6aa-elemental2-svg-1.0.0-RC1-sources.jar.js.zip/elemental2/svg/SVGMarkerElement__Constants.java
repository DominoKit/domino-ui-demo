package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGMarkerElement", namespace = JsPackage.GLOBAL)
class SVGMarkerElement__Constants {
  static double SVG_MARKERUNITS_STROKEWIDTH;
  static double SVG_MARKERUNITS_UNKNOWN;
  static double SVG_MARKERUNITS_USERSPACEONUSE;
  static double SVG_MARKER_ORIENT_ANGLE;
  static double SVG_MARKER_ORIENT_AUTO;
  static double SVG_MARKER_ORIENT_UNKNOWN;
}
