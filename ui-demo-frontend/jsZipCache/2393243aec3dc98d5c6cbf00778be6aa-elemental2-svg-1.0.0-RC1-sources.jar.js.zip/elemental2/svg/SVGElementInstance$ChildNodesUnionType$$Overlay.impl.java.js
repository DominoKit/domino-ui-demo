/**
 * @fileoverview transpiled from elemental2.svg.SVGElementInstance$ChildNodesUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGElementInstance.ChildNodesUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let SVGElementInstance_$Overlay = goog.forwardDeclare('elemental2.svg.SVGElementInstance.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.svg.SVGElementInstanceList.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ChildNodesUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ChildNodesUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ChildNodesUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Array<SVGElementInstance>}
   * @public
   */
  static m_asSVGElementInstanceArray__elemental2_svg_SVGElementInstance_ChildNodesUnionType($thisArg) {
    ChildNodesUnionType_$Overlay.$clinit();
    return /**@type {Array<SVGElementInstance>} */ ($Arrays.$castToNative(Js.m_cast__java_lang_Object($thisArg)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {SVGElementInstanceList}
   * @public
   */
  static m_asSVGElementInstanceList__elemental2_svg_SVGElementInstance_ChildNodesUnionType($thisArg) {
    ChildNodesUnionType_$Overlay.$clinit();
    return /**@type {SVGElementInstanceList} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isSVGElementInstanceArray__elemental2_svg_SVGElementInstance_ChildNodesUnionType($thisArg) {
    ChildNodesUnionType_$Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isSVGElementInstanceList__elemental2_svg_SVGElementInstance_ChildNodesUnionType($thisArg) {
    ChildNodesUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ChildNodesUnionType_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.svg.SVGElementInstanceList.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ChildNodesUnionType_$Overlay, $Util.$makeClassName('?'));


exports = ChildNodesUnionType_$Overlay; 
//# sourceMappingURL=SVGElementInstance$ChildNodesUnionType$$Overlay.js.map