/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$ListenerWrapper.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.ListenerWrapper$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let DominoEventListener = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');
let InMemoryDominoEventsListenerRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


class ListenerWrapper extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {InMemoryDominoEventsListenerRepository} */
    this.f_$outer_this__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper;
    /** @public {DominoEventListener} */
    this.f_dominoEventListener__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper_;
  }
  
  /**
   * Factory method corresponding to constructor 'ListenerWrapper(InMemoryDominoEventsListenerRepository, DominoEventListener)'.
   * @param {InMemoryDominoEventsListenerRepository} $outer_this
   * @param {DominoEventListener} dominoEventListener
   * @return {!ListenerWrapper}
   * @public
   */
  static $create__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository__org_dominokit_domino_api_shared_extension_DominoEventListener($outer_this, dominoEventListener) {
    ListenerWrapper.$clinit();
    let $instance = new ListenerWrapper();
    $instance.$ctor__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository__org_dominokit_domino_api_shared_extension_DominoEventListener($outer_this, dominoEventListener);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListenerWrapper(InMemoryDominoEventsListenerRepository, DominoEventListener)'.
   * @param {InMemoryDominoEventsListenerRepository} $outer_this
   * @param {DominoEventListener} dominoEventListener
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository__org_dominokit_domino_api_shared_extension_DominoEventListener($outer_this, dominoEventListener) {
    this.f_$outer_this__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_dominoEventListener__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper_ = dominoEventListener;
  }
  
  /**
   * @override
   * @param {*} other
   * @return {boolean}
   * @public
   */
  equals(other) {
    if (Objects.m_isNull__java_lang_Object(other)) {
      return false;
    }
    return j_l_String.m_equals__java_lang_String__java_lang_Object($Objects.m_getClass__java_lang_Object(this.f_dominoEventListener__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper_).m_getCanonicalName__(), $Objects.m_getClass__java_lang_Object((/**@type {ListenerWrapper} */ ($Casts.$to(other, ListenerWrapper))).f_dominoEventListener__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper_).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return j_l_String.m_hashCode__java_lang_String($Objects.m_getClass__java_lang_Object(this.f_dominoEventListener__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper_).m_getCanonicalName__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListenerWrapper;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListenerWrapper);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListenerWrapper.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ListenerWrapper, $Util.$makeClassName('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$ListenerWrapper'));




exports = ListenerWrapper; 
//# sourceMappingURL=InMemoryDominoEventsListenerRepository$ListenerWrapper.js.map