/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventsListenersRepository = goog.require('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository');
const _Class = goog.require('java.lang.Class');
const _HashMap = goog.require('java.util.HashMap');
const _HashSet = goog.require('java.util.HashSet');
const _Map = goog.require('java.util.Map');
const _Objects = goog.require('java.util.Objects');
const _Set = goog.require('java.util.Set');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Stream = goog.require('java.util.stream.Stream');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _ListenerWrapper = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.ListenerWrapper');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var InMemoryDominoEventsListenerRepository = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$impl');
exports = InMemoryDominoEventsListenerRepository;
 