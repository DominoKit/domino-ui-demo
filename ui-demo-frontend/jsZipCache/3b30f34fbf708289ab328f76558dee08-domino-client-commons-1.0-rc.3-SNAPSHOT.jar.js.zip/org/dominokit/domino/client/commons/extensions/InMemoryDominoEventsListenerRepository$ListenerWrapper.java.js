/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$ListenerWrapper.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.ListenerWrapper');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _InMemoryDominoEventsListenerRepository = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var ListenerWrapper = goog.require('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.ListenerWrapper$impl');
exports = ListenerWrapper;
 