/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _MainDominoEvent = goog.require('org.dominokit.domino.api.shared.extension.MainDominoEvent');
const _MainEventContext = goog.require('org.dominokit.domino.api.shared.extension.MainEventContext');
const _$1 = goog.require('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint.$1');


// Re-exports the implementation.
var CoreMainExtensionPoint = goog.require('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint$impl');
exports = CoreMainExtensionPoint;
 