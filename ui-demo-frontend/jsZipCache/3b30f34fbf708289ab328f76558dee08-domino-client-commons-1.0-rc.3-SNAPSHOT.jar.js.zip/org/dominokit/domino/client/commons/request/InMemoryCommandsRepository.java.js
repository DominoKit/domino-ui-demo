/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.InMemoryCommandsRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _CommandsRepository = goog.require('org.dominokit.domino.api.client.request.CommandsRepository');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _CommandCannotBeRegisteredMoreThanOnce = goog.require('org.dominokit.domino.api.client.request.CommandsRepository.CommandCannotBeRegisteredMoreThanOnce');
const _CommandKeyNotFoundException = goog.require('org.dominokit.domino.api.client.request.CommandsRepository.CommandKeyNotFoundException');
const _RequestHolder = goog.require('org.dominokit.domino.api.client.request.RequestHolder');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var InMemoryCommandsRepository = goog.require('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository$impl');
exports = InMemoryCommandsRepository;
 