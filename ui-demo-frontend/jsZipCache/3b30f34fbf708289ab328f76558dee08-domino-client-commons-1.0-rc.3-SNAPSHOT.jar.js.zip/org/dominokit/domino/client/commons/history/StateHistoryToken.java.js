/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.history.StateHistoryToken.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.history.StateHistoryToken');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken');
const _j_l_String = goog.require('java.lang.String');
const _Arrays = goog.require('java.util.Arrays');
const _HashMap = goog.require('java.util.HashMap');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _Entry = goog.require('java.util.Map.Entry');
const _Objects = goog.require('java.util.Objects');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _IntPredicate = goog.require('java.util.function.IntPredicate');
const _Predicate = goog.require('java.util.function.Predicate');
const _Supplier = goog.require('java.util.function.Supplier');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _IntStream = goog.require('java.util.stream.IntStream');
const _Stream = goog.require('java.util.stream.Stream');
const _TokenCannotBeNullException = goog.require('org.dominokit.domino.api.shared.history.HistoryToken.TokenCannotBeNullException');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$int = goog.require('vmbootstrap.primitives.$int');


// Re-exports the implementation.
var StateHistoryToken = goog.require('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
exports = StateHistoryToken;
 