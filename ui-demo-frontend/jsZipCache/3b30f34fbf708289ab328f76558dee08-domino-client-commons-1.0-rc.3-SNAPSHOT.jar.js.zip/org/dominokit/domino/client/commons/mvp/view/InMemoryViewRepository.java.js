/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ViewsRepository = goog.require('org.dominokit.domino.api.client.mvp.view.ViewsRepository');
const _HashMap = goog.require('java.util.HashMap');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _ViewCannotBeRegisteredMoreThanOnce = goog.require('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewCannotBeRegisteredMoreThanOnce');
const _ViewNotFoundException = goog.require('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewNotFoundException');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var InMemoryViewRepository = goog.require('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository$impl');
exports = InMemoryViewRepository;
 