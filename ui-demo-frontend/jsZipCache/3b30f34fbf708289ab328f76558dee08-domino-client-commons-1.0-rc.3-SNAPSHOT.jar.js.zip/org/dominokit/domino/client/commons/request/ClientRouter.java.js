/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.ClientRouter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.ClientRouter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter');
const _Class = goog.require('java.lang.Class');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _ClientRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _Request = goog.require('org.dominokit.domino.api.client.request.Request');
const _$1 = goog.require('org.dominokit.domino.client.commons.request.ClientRouter.$1');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ClientRouter = goog.require('org.dominokit.domino.client.commons.request.ClientRouter$impl');
exports = ClientRouter;
 