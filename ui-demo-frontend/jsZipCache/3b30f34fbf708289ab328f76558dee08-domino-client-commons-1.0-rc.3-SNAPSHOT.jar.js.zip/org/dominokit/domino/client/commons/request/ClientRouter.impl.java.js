/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.ClientRouter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.ClientRouter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let ClientRequestEventFactory = goog.forwardDeclare('org.dominokit.domino.api.client.events.ClientRequestEventFactory$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');
let Request = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.client.commons.request.ClientRouter.$1$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {RequestRouter<PresenterCommand>}
  */
class ClientRouter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ClientRequestEventFactory} */
    this.f_requestEventFactory__org_dominokit_domino_client_commons_request_ClientRouter_;
  }
  
  /**
   * Factory method corresponding to constructor 'ClientRouter(ClientRequestEventFactory)'.
   * @param {ClientRequestEventFactory} requestEventFactory
   * @return {!ClientRouter}
   * @public
   */
  static $create__org_dominokit_domino_api_client_events_ClientRequestEventFactory(requestEventFactory) {
    ClientRouter.$clinit();
    let $instance = new ClientRouter();
    $instance.$ctor__org_dominokit_domino_client_commons_request_ClientRouter__org_dominokit_domino_api_client_events_ClientRequestEventFactory(requestEventFactory);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ClientRouter(ClientRequestEventFactory)'.
   * @param {ClientRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_ClientRouter__org_dominokit_domino_api_client_events_ClientRequestEventFactory(requestEventFactory) {
    this.$ctor__java_lang_Object__();
    this.f_requestEventFactory__org_dominokit_domino_client_commons_request_ClientRouter_ = requestEventFactory;
  }
  
  /**
   * @param {PresenterCommand} presenterCommand
   * @return {void}
   * @public
   */
  m_routeRequest__org_dominokit_domino_api_client_request_PresenterCommand(presenterCommand) {
    ClientApp.m_make__().m_getAsyncRunner__().m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask($1.$create__org_dominokit_domino_client_commons_request_ClientRouter__org_dominokit_domino_api_client_request_PresenterCommand(this, presenterCommand));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {Request} arg0
   * @return {void}
   * @public
   */
  m_routeRequest__org_dominokit_domino_api_client_request_Request(arg0) {
    this.m_routeRequest__org_dominokit_domino_api_client_request_PresenterCommand(/**@type {PresenterCommand} */ ($Casts.$to(arg0, PresenterCommand)));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_() {
    return (ClientRouter.$clinit(), ClientRouter.$f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_(value) {
    (ClientRouter.$clinit(), ClientRouter.$f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientRouter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientRouter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientRouter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    PresenterCommand = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand$impl');
    $1 = goog.module.get('org.dominokit.domino.client.commons.request.ClientRouter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    ClientRouter.$f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ClientRouter));
  }
  
  
};

$Util.$setClassMetadata(ClientRouter, $Util.$makeClassName('org.dominokit.domino.client.commons.request.ClientRouter'));


/** @private {Logger} */
ClientRouter.$f_LOGGER__org_dominokit_domino_client_commons_request_ClientRouter_;


RequestRouter.$markImplementor(ClientRouter);


exports = ClientRouter; 
//# sourceMappingURL=ClientRouter.js.map