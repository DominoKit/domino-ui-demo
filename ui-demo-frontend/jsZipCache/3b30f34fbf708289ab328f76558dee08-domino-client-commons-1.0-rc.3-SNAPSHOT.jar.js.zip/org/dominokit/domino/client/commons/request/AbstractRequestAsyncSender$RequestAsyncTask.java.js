/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$RequestAsyncTask.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.RequestAsyncTask');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');
const _j_l_String = goog.require('java.lang.String');
const _Throwable = goog.require('java.lang.Throwable');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _AbstractRequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender');


// Re-exports the implementation.
var RequestAsyncTask = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.RequestAsyncTask$impl');
exports = RequestAsyncTask;
 