/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventsListenersRepository = goog.require('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let DominoEventListener = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');
let ListenerWrapper = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.ListenerWrapper$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventsListenersRepository}
  */
class InMemoryDominoEventsListenerRepository extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<?string, Set<ListenerWrapper>>} */
    this.f_listeners__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_;
  }
  
  /**
   * Factory method corresponding to constructor 'InMemoryDominoEventsListenerRepository()'.
   * @return {!InMemoryDominoEventsListenerRepository}
   * @public
   */
  static $create__() {
    InMemoryDominoEventsListenerRepository.$clinit();
    let $instance = new InMemoryDominoEventsListenerRepository();
    $instance.$ctor__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InMemoryDominoEventsListenerRepository()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository();
  }
  
  /**
   * @override
   * @param {Class<?>} dominoEvent
   * @param {DominoEventListener} dominoEventListener
   * @return {void}
   * @public
   */
  m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(dominoEvent, dominoEventListener) {
    this.m_initializeEventListeners__java_lang_Class_$p_org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository(dominoEvent);
    /**@type {Set<ListenerWrapper>} */ ($Casts.$to(this.f_listeners__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_.get(dominoEvent.m_getCanonicalName__()), Set)).add(ListenerWrapper.$create__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository__org_dominokit_domino_api_shared_extension_DominoEventListener(this, dominoEventListener));
  }
  
  /**
   * @override
   * @param {Class<?>} dominoEvent
   * @return {Set<DominoEventListener>}
   * @public
   */
  m_getEventListeners__java_lang_Class(dominoEvent) {
    this.m_initializeEventListeners__java_lang_Class_$p_org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository(dominoEvent);
    return /**@type {Set<DominoEventListener>} */ ($Casts.$to(/**@type {Stream<DominoEventListener>} */ (/**@type {Set<ListenerWrapper>} */ ($Casts.$to(this.f_listeners__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_.get(dominoEvent.m_getCanonicalName__()), Set)).m_stream__().m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** ListenerWrapper */ cw) =>{
      return cw.f_dominoEventListener__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ListenerWrapper_;
    })))).m_collect__java_util_stream_Collector(/**@type {Collector<DominoEventListener, ?, Set<DominoEventListener>>} */ (Collectors.m_toSet__())), Set));
  }
  
  /**
   * @param {Class<?>} extensionPoint
   * @return {void}
   * @public
   */
  m_initializeEventListeners__java_lang_Class_$p_org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository(extensionPoint) {
    if (Objects.m_isNull__java_lang_Object(this.f_listeners__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_.get(extensionPoint.m_getCanonicalName__()))) {
      this.f_listeners__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_.put(extensionPoint.m_getCanonicalName__(), /**@type {!HashSet<ListenerWrapper>} */ (HashSet.$create__()));
    }
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository() {
    this.f_listeners__org_dominokit_domino_client_commons_extensions_InMemoryDominoEventsListenerRepository_ = /**@type {!HashMap<?string, Set<ListenerWrapper>>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InMemoryDominoEventsListenerRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InMemoryDominoEventsListenerRepository);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InMemoryDominoEventsListenerRepository.$clinit = function() {};
    HashMap = goog.module.get('java.util.HashMap$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Set = goog.module.get('java.util.Set$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    ListenerWrapper = goog.module.get('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository.ListenerWrapper$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InMemoryDominoEventsListenerRepository, $Util.$makeClassName('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository'));


DominoEventsListenersRepository.$markImplementor(InMemoryDominoEventsListenerRepository);


exports = InMemoryDominoEventsListenerRepository; 
//# sourceMappingURL=InMemoryDominoEventsListenerRepository.js.map