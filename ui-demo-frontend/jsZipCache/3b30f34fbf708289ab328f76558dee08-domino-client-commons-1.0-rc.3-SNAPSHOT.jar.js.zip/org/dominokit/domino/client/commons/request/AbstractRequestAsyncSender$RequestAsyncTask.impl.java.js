/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$RequestAsyncTask.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.RequestAsyncTask$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let AbstractRequestAsyncSender = goog.forwardDeclare('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$impl');


/**
 * @implements {AsyncTask}
  */
class RequestAsyncTask extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AbstractRequestAsyncSender} */
    this.f_$outer_this__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask;
    /** @public {ServerRequest} */
    this.f_request__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask_;
  }
  
  /**
   * Factory method corresponding to constructor 'RequestAsyncTask(AbstractRequestAsyncSender, ServerRequest)'.
   * @param {AbstractRequestAsyncSender} $outer_this
   * @param {ServerRequest} request
   * @return {!RequestAsyncTask}
   * @public
   */
  static $create__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_request_ServerRequest($outer_this, request) {
    RequestAsyncTask.$clinit();
    let $instance = new RequestAsyncTask();
    $instance.$ctor__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_request_ServerRequest($outer_this, request);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RequestAsyncTask(AbstractRequestAsyncSender, ServerRequest)'.
   * @param {AbstractRequestAsyncSender} $outer_this
   * @param {ServerRequest} request
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_request_ServerRequest($outer_this, request) {
    this.f_$outer_this__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_request__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask_ = request;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_onSuccess__() {
    this.f_$outer_this__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask.m_sendRequest__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_client_events_ServerRequestEventFactory(this.f_request__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask_, this.f_$outer_this__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask.f_requestEventFactory__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_);
  }
  
  /**
   * @override
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  m_onFailed__java_lang_Throwable(error) {
    AbstractRequestAsyncSender.f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_.m_debug__java_lang_String__java_lang_Throwable("Could not RunAsync request [" + j_l_String.m_valueOf__java_lang_Object(this.f_request__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_RequestAsyncTask_) + "]", error);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RequestAsyncTask;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RequestAsyncTask);
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestAsyncTask.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    AbstractRequestAsyncSender = goog.module.get('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$impl');
    j_l_Object.$clinit();
    AsyncTask.$clinit();
  }
  
  
};

$Util.$setClassMetadata(RequestAsyncTask, $Util.$makeClassName('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$RequestAsyncTask'));


AsyncTask.$markImplementor(RequestAsyncTask);


exports = RequestAsyncTask; 
//# sourceMappingURL=AbstractRequestAsyncSender$RequestAsyncTask.js.map