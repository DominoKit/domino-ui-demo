package org.dominokit.domino.helpers.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface HelpersView extends View, DemoView{
}