/**
 * @fileoverview transpiled from org.dominokit.domino.helpers.client.HelpersClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.helpers.client.HelpersClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class HelpersClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'HelpersClientModule()'.
   * @return {!HelpersClientModule}
   * @public
   */
  static $create__() {
    HelpersClientModule.$clinit();
    let $instance = new HelpersClientModule();
    $instance.$ctor__org_dominokit_domino_helpers_client_HelpersClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HelpersClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_helpers_client_HelpersClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    HelpersClientModule.$f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_.m_info__java_lang_String("Initializing Helpers frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_() {
    return (HelpersClientModule.$clinit(), HelpersClientModule.$f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_(value) {
    (HelpersClientModule.$clinit(), HelpersClientModule.$f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HelpersClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HelpersClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HelpersClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    HelpersClientModule.$f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(HelpersClientModule));
  }
  
  
};

$Util.$setClassMetadata(HelpersClientModule, $Util.$makeClassName('org.dominokit.domino.helpers.client.HelpersClientModule'));


/** @private {Logger} */
HelpersClientModule.$f_LOGGER__org_dominokit_domino_helpers_client_HelpersClientModule_;




exports = HelpersClientModule; 
//# sourceMappingURL=HelpersClientModule.js.map