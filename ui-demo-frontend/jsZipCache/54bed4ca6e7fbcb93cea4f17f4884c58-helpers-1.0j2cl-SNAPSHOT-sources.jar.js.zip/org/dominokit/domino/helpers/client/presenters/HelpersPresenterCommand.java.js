/**
 * @fileoverview transpiled from org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _HelpersPresenter = goog.require('org.dominokit.domino.helpers.client.presenters.HelpersPresenter');


// Re-exports the implementation.
var HelpersPresenterCommand = goog.require('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand$impl');
exports = HelpersPresenterCommand;
 