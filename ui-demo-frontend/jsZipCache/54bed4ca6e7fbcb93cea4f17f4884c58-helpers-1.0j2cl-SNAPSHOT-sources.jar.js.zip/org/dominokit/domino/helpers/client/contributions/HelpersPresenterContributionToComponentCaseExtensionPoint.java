package org.dominokit.domino.helpers.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint;
import org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class HelpersPresenterContributionToComponentCaseExtensionPoint implements Contribution<ComponentCaseExtensionPoint> {
  @Override
  public void contribute(ComponentCaseExtensionPoint extensionPoint) {
    new HelpersPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentCaseModule(extensionPoint.context())).send();
  }
}
