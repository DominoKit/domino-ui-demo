/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.contributions.AdvancedFormsPresenterContributionToFormsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.contributions.AdvancedFormsPresenterContributionToFormsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let AdvancedFormsPresenter = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenter$impl');
let AdvancedFormsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand$impl');
let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<FormsExtensionPoint>}
  */
class AdvancedFormsPresenterContributionToFormsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedFormsPresenterContributionToFormsExtensionPoint()'.
   * @return {!AdvancedFormsPresenterContributionToFormsExtensionPoint}
   * @public
   */
  static $create__() {
    AdvancedFormsPresenterContributionToFormsExtensionPoint.$clinit();
    let $instance = new AdvancedFormsPresenterContributionToFormsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_contributions_AdvancedFormsPresenterContributionToFormsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedFormsPresenterContributionToFormsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_contributions_AdvancedFormsPresenterContributionToFormsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {FormsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint(extensionPoint) {
    AdvancedFormsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** AdvancedFormsPresenter */ presenter) =>{
      presenter.m_contributeToMainModule__org_dominokit_domino_forms_shared_extension_FormsContext(/**@type {FormsContext} */ ($Casts.$to(extensionPoint.m_context__(), FormsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint(/**@type {FormsExtensionPoint} */ ($Casts.$to(arg0, FormsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedFormsPresenterContributionToFormsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedFormsPresenterContributionToFormsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsPresenterContributionToFormsExtensionPoint.$clinit = function() {};
    AdvancedFormsPresenterCommand = goog.module.get('org.dominokit.domino.advancedforms.client.presenters.AdvancedFormsPresenterCommand$impl');
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsExtensionPoint = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AdvancedFormsPresenterContributionToFormsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.contributions.AdvancedFormsPresenterContributionToFormsExtensionPoint'));


Contribution.$markImplementor(AdvancedFormsPresenterContributionToFormsExtensionPoint);


exports = AdvancedFormsPresenterContributionToFormsExtensionPoint; 
//# sourceMappingURL=AdvancedFormsPresenterContributionToFormsExtensionPoint.js.map