package org.dominokit.domino.collapse.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface CollapseView extends View, DemoView{
}