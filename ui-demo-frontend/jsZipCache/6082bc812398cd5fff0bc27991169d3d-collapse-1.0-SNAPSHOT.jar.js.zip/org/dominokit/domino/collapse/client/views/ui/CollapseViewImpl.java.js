/**
 * @fileoverview transpiled from org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CollapseView = goog.require('org.dominokit.domino.collapse.client.views.CollapseView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeResource = goog.require('org.dominokit.domino.collapse.client.views.CodeResource');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl.$LambdaAdaptor$1');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Accordion = goog.require('org.dominokit.domino.ui.collapsible.Accordion');
const _AccordionPanel = goog.require('org.dominokit.domino.ui.collapsible.AccordionPanel');
const _Collapsible = goog.require('org.dominokit.domino.ui.collapsible.Collapsible');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _CssStyles = goog.require('org.dominokit.domino.ui.style.CssStyles');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CollapseViewImpl = goog.require('org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl$impl');
exports = CollapseViewImpl;
 