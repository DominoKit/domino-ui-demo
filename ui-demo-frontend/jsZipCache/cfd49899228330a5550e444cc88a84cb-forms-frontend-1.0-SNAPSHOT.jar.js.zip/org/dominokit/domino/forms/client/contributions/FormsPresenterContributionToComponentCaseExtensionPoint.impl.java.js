/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
let FormsPresenter = goog.forwardDeclare('org.dominokit.domino.forms.client.presenters.FormsPresenter$impl');
let FormsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.forms.client.presenters.FormsPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentCaseExtensionPoint>}
  */
class FormsPresenterContributionToComponentCaseExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {!FormsPresenterContributionToComponentCaseExtensionPoint}
   * @public
   */
  static $create__() {
    FormsPresenterContributionToComponentCaseExtensionPoint.$clinit();
    let $instance = new FormsPresenterContributionToComponentCaseExtensionPoint();
    $instance.$ctor__org_dominokit_domino_forms_client_contributions_FormsPresenterContributionToComponentCaseExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_contributions_FormsPresenterContributionToComponentCaseExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(extensionPoint) {
    FormsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** FormsPresenter */ presenter) =>{
      presenter.m_contributeToMainModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(/**@type {ComponentCaseExtensionPoint} */ ($Casts.$to(arg0, ComponentCaseExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsPresenterContributionToComponentCaseExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsPresenterContributionToComponentCaseExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsPresenterContributionToComponentCaseExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    FormsPresenterCommand = goog.module.get('org.dominokit.domino.forms.client.presenters.FormsPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsPresenterContributionToComponentCaseExtensionPoint, $Util.$makeClassName('org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint'));


Contribution.$markImplementor(FormsPresenterContributionToComponentCaseExtensionPoint);


exports = FormsPresenterContributionToComponentCaseExtensionPoint; 
//# sourceMappingURL=FormsPresenterContributionToComponentCaseExtensionPoint.js.map