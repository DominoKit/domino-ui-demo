/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');
const _FormsPresenter = goog.require('org.dominokit.domino.forms.client.presenters.FormsPresenter');
const _FormsPresenterCommand = goog.require('org.dominokit.domino.forms.client.presenters.FormsPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var FormsPresenterContributionToComponentCaseExtensionPoint = goog.require('org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint$impl');
exports = FormsPresenterContributionToComponentCaseExtensionPoint;
 