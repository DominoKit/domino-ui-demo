/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter.$1$impl');
let TimePickerView = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.TimePickerView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<TimePickerView>}
  */
class TimePickerPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TimePickerPresenter()'.
   * @return {!TimePickerPresenter}
   * @public
   */
  static $create__() {
    TimePickerPresenter.$clinit();
    let $instance = new TimePickerPresenter();
    $instance.$ctor__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TimePickerPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {FormsContext} context
   * @return {void}
   * @public
   */
  m_contributeToFormsModule__org_dominokit_domino_forms_shared_extension_FormsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter_() {
    return (TimePickerPresenter.$clinit(), TimePickerPresenter.$f_LOGGER__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter_(value) {
    (TimePickerPresenter.$clinit(), TimePickerPresenter.$f_LOGGER__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TimePickerPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TimePickerPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TimePickerPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    TimePickerPresenter.$f_LOGGER__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(TimePickerPresenter));
  }
  
  
};

$Util.$setClassMetadata(TimePickerPresenter, $Util.$makeClassName('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter'));


/** @private {Logger} */
TimePickerPresenter.$f_LOGGER__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenter_;




exports = TimePickerPresenter; 
//# sourceMappingURL=TimePickerPresenter.js.map