/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _FormsExtensionPoint = goog.require('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint');
const _$1 = goog.require('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration.$2');
const _TimePickerPresenterContributionToFormsExtensionPoint = goog.require('org.dominokit.domino.timepicker.client.contributions.TimePickerPresenterContributionToFormsExtensionPoint');
const _TimePickerPresenter = goog.require('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter');
const _TimePickerPresenterCommand = goog.require('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenterCommand');


// Re-exports the implementation.
var TimePickerModuleConfiguration = goog.require('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration$impl');
exports = TimePickerModuleConfiguration;
 