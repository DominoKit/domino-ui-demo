/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const TimePickerView = goog.require('org.dominokit.domino.timepicker.client.views.TimePickerView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$3$impl');
let IconButton = goog.forwardDeclare('org.dominokit.domino.ui.button.IconButton$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ClockStyle = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.ClockStyle$impl');
let Time = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.Time$impl');
let TimeBox = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimeBox$impl');
let PickerStyle = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimeBox.PickerStyle$impl');
let TimePicker = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimePicker$impl');
let TimeSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.TimePicker.TimeSelectionHandler$impl');
let DateTimeFormatInfoImpl__de = goog.forwardDeclare('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_de$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {TimePickerView}
  */
class TimePickerViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'TimePickerViewImpl()'.
   * @return {!TimePickerViewImpl}
   * @public
   */
  static $create__() {
    TimePickerViewImpl.$clinit();
    let $instance = new TimePickerViewImpl();
    $instance.$ctor__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TimePickerViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("TIME PICKERS").m_asElement__());
    this.m_inlined___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
    this.m_popups___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
    this.m_timeBox___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_inlined___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(Card.m_create__java_lang_String("INLINED").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(TimePicker.m_create__().m_fixedWidth__java_lang_String("270px").m_showBorder__().m_hideClearButton__().m_hideCloseButton__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time, /** DateTimeFormatInfo */ dateTimeFormatInfo, /** TimePicker */ timePicker) =>{
      window.console.info(timePicker.m_getFormattedTime__());
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(TimePicker.m_create__org_gwtproject_i18n_shared_DateTimeFormatInfo(DateTimeFormatInfoImpl__de.$create__()).m_fixedWidth__java_lang_String("270px").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_showBorder__().m_hideClearButton__().m_setShowSwitchers__boolean(true).m_hideCloseButton__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$, /** TimePicker */ timePicker$1$) =>{
      window.console.info(timePicker$1$.m_getFormattedTime__());
    }))).m_todayButtonText__java_lang_String("nu").m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(TimePicker.m_create__().m_fixedWidth__java_lang_String("270px").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_setClockStyle__org_dominokit_domino_ui_timepicker_ClockStyle(ClockStyle.f__24__org_dominokit_domino_ui_timepicker_ClockStyle).m_showBorder__().m_hideClearButton__().m_hideCloseButton__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$, /** TimePicker */ timePicker$2$) =>{
      window.console.info(timePicker$2$.m_getFormattedTime__());
    }))).m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_inlined__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_popups___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    let bluePopupButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let bluePopTimePicker = TimePicker.m_create__().m_showBorder__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time, /** DateTimeFormatInfo */ dateTimeFormatInfo, /** TimePicker */ picker) =>{
      window.console.info(picker.m_getFormattedTime__());
    })));
    let bluePopover = Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(bluePopupButton.m_asElement__(), "Wakeup", bluePopTimePicker.m_asElement__());
    bluePopTimePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      bluePopover.m_close__();
    })));
    bluePopTimePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let pinkPopupButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let pinkPopDatePicker = TimePicker.m_create__org_gwtproject_i18n_shared_DateTimeFormatInfo(DateTimeFormatInfoImpl__de.$create__()).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo$1$, /** TimePicker */ picker$1$) =>{
      window.console.info(picker$1$.m_getFormattedTime__());
    })));
    let pinkPopover = Popover.m_createPicker__elemental2_dom_HTMLElement__elemental2_dom_Node(pinkPopupButton.m_asElement__(), pinkPopDatePicker.m_asElement__());
    pinkPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      pinkPopover.m_close__();
    })));
    pinkPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let greenPopupButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let greenPopDatePicker = TimePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$2$, /** DateTimeFormatInfo */ dateTimeFormatInfo$2$, /** TimePicker */ picker$2$) =>{
      window.console.info(picker$2$.m_getFormattedTime__());
    })));
    let greenPopover = Popover.m_createPicker__elemental2_dom_HTMLElement__elemental2_dom_Node(greenPopupButton.m_asElement__(), greenPopDatePicker.m_asElement__());
    greenPopDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenPopover.m_close__();
    })));
    greenPopDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    let blueModalButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let blueDatePicker = TimePicker.m_create__().m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$3$, /** DateTimeFormatInfo */ dateTimeFormatInfo$3$, /** TimePicker */ picker$3$) =>{
      window.console.info(picker$3$.m_getFormattedTime__());
    })));
    let blueModal = blueDatePicker.m_createModal__java_lang_String("Wakeup");
    blueDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      blueModal.m_close__();
    })));
    blueDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    blueModal.m_appendContent__elemental2_dom_Node(blueDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(blueModal.m_asElement__());
    blueModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      blueModal.m_open__();
    })));
    let pinkModalButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let pinkDatePicker = TimePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$4$, /** DateTimeFormatInfo */ dateTimeFormatInfo$4$, /** TimePicker */ picker$4$) =>{
      window.console.info(picker$4$.m_getFormattedTime__());
    })));
    let pinkModal = pinkDatePicker.m_createModal__java_lang_String("Wakeup");
    pinkDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      pinkModal.m_close__();
    })));
    pinkDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    pinkModal.m_appendContent__elemental2_dom_Node(pinkDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(pinkModal.m_asElement__());
    pinkModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      pinkModal.m_open__();
    })));
    let greenModalButton = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__());
    let greenDatePicker = TimePicker.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme).m_addTimeSelectionHandler__org_dominokit_domino_ui_timepicker_TimePicker_TimeSelectionHandler(TimeSelectionHandler.$adapt(((/** Time */ time$5$, /** DateTimeFormatInfo */ dateTimeFormatInfo$5$, /** TimePicker */ picker$5$) =>{
      window.console.info(picker$5$.m_getFormattedTime__());
    })));
    let greenModal = greenDatePicker.m_createModal__java_lang_String("Wakeup");
    greenDatePicker.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      greenModal.m_close__();
    })));
    greenDatePicker.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("a Click on clear button").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_setBackground__org_dominokit_domino_ui_style_Color(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme.m_color__()).m_show__();
    })));
    greenModal.m_appendContent__elemental2_dom_Node(greenDatePicker.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(greenModal.m_asElement__());
    greenModalButton.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      greenModal.m_open__();
    })));
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(Card.m_create__java_lang_String("POPUP").m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("POP OVER").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bluePopupButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(pinkPopupButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(greenPopupButton.m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("MODAL").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(blueModalButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(pinkModalButton.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(greenModalButton.m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_popups__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_timeBox___$p_org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    let column = this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.m_copy__().m_removeCssClass__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles);
    let timeBox1 = /**@type {TimeBox} */ ($Casts.$to(TimeBox.m_create__().m_floating__(), TimeBox)).m_setPlaceholder__java_lang_String("Wakeup");
    let timeBox2 = TimeBox.m_create__java_lang_String__org_dominokit_domino_ui_timepicker_Time__org_gwtproject_i18n_shared_DateTimeFormatInfo("Wakeup", Time.$create__(), DateTimeFormatInfoImpl__de.$create__());
    timeBox2.m_getTimePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme);
    let timeBox3 = /**@type {TimeBox} */ ($Casts.$to(TimeBox.m_create__().m_floating__(), TimeBox)).m_setPopoverPosition__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition).m_setPickerStyle__org_dominokit_domino_ui_timepicker_TimeBox_PickerStyle(PickerStyle.f_POPOVER__org_dominokit_domino_ui_timepicker_TimeBox_PickerStyle).m_setPlaceholder__java_lang_String("Wakeup");
    timeBox3.m_getTimePicker__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme);
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(Card.m_create__java_lang_String("TIME BOX").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(timeBox1.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(timeBox2.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(timeBox3.m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_timebox__()).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl() {
    this.f_element__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
    this.f_column__org_dominokit_domino_timepicker_client_views_ui_TimePickerViewImpl_ = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall).m_addCssClass__java_lang_String(Styles.f_padding_0__org_dominokit_domino_ui_style_Styles).m_centerContent__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TimePickerViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TimePickerViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TimePickerViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.timepicker.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl.$LambdaAdaptor$3$impl');
    IconButton = goog.module.get('org.dominokit.domino.ui.button.IconButton$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    PickerHandler = goog.module.get('org.dominokit.domino.ui.pickers.PickerHandler$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ClockStyle = goog.module.get('org.dominokit.domino.ui.timepicker.ClockStyle$impl');
    Time = goog.module.get('org.dominokit.domino.ui.timepicker.Time$impl');
    TimeBox = goog.module.get('org.dominokit.domino.ui.timepicker.TimeBox$impl');
    PickerStyle = goog.module.get('org.dominokit.domino.ui.timepicker.TimeBox.PickerStyle$impl');
    TimePicker = goog.module.get('org.dominokit.domino.ui.timepicker.TimePicker$impl');
    TimeSelectionHandler = goog.module.get('org.dominokit.domino.ui.timepicker.TimePicker.TimeSelectionHandler$impl');
    DateTimeFormatInfoImpl__de = goog.module.get('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_de$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TimePickerViewImpl, $Util.$makeClassName('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl'));


TimePickerView.$markImplementor(TimePickerViewImpl);


exports = TimePickerViewImpl; 
//# sourceMappingURL=TimePickerViewImpl.js.map