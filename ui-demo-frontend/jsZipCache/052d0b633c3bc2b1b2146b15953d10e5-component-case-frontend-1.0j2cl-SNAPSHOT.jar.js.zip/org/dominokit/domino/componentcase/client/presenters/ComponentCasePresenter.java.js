/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _Objects = goog.require('java.util.Objects');
const _ContextAggregator = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator');
const _ContextWait = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait');
const _ReadyHandler = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DirectUrlHandler = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectUrlHandler');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');
const _StateListener = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');
const _MenuBranch = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.MenuBranch');
const _NoRootMenuException = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.NoRootMenuException');
const _ComponentCaseView = goog.require('org.dominokit.domino.componentcase.client.views.ComponentCaseView');
const _ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase');
const _ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem');
const _OnMenuSelectedHandler = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.OnMenuSelectedHandler');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var ComponentCasePresenter = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
exports = ComponentCasePresenter;
 