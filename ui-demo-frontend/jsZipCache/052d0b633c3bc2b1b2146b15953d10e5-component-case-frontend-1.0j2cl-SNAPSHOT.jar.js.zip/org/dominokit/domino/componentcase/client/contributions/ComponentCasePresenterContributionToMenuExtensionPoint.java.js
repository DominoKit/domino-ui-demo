/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ComponentCasePresenter = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter');
const _ComponentCasePresenterCommand = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand');
const _MenuContext = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext');
const _MenuExtensionPoint = goog.require('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ComponentCasePresenterContributionToMenuExtensionPoint = goog.require('org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint$impl');
exports = ComponentCasePresenterContributionToMenuExtensionPoint;
 