/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');


/**
 * @extends {PresenterCommand<ComponentCasePresenter>}
  */
class ComponentCasePresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCasePresenterCommand()'.
   * @return {!ComponentCasePresenterCommand}
   * @public
   */
  static $create__() {
    ComponentCasePresenterCommand.$clinit();
    let $instance = new ComponentCasePresenterCommand();
    $instance.$ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCasePresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCasePresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCasePresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCasePresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCasePresenterCommand, $Util.$makeClassName('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand'));




exports = ComponentCasePresenterCommand; 
//# sourceMappingURL=ComponentCasePresenterCommand.js.map