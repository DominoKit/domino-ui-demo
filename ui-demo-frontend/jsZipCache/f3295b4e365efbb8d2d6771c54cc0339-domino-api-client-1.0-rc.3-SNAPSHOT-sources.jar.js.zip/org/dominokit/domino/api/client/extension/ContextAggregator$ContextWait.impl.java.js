/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$ContextWait.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let LinkedHashSet = goog.forwardDeclare('java.util.LinkedHashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let ReadyHandler = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');


/**
 * @template C_ContextWait_T
  */
class ContextWait extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Set<ReadyHandler>} */
    this.f_readyHandlers__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_;
    /** @public {C_ContextWait_T} */
    this.f_context__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContextWait()'.
   * @template C_ContextWait_T
   * @return {!ContextWait<C_ContextWait_T>}
   * @public
   */
  static $create__() {
    ContextWait.$clinit();
    let $instance = new ContextWait();
    $instance.$ctor__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContextWait()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait();
  }
  
  /**
   * @template M_ContextWait_create_T
   * @return {ContextWait<M_ContextWait_create_T>}
   * @public
   */
  static m_create__() {
    ContextWait.$clinit();
    return /**@type {!ContextWait<*>} */ (ContextWait.$create__());
  }
  
  /**
   * @param {ReadyHandler} handler
   * @return {void}
   * @public
   */
  m_onReady__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$pp_org_dominokit_domino_api_client_extension(handler) {
    this.f_readyHandlers__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_.add(handler);
  }
  
  /**
   * @param {C_ContextWait_T} context
   * @return {void}
   * @public
   */
  m_receiveContext__java_lang_Object(context) {
    this.f_context__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_ = context;
    this.f_readyHandlers__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ReadyHandler */ arg0) =>{
      arg0.m_onReady__();
    })));
  }
  
  /**
   * @return {C_ContextWait_T}
   * @public
   */
  m_get__() {
    return this.f_context__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait() {
    this.f_readyHandlers__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait_ = /**@type {!LinkedHashSet<ReadyHandler>} */ (LinkedHashSet.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContextWait;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContextWait);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContextWait.$clinit = function() {};
    LinkedHashSet = goog.module.get('java.util.LinkedHashSet$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContextWait, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContextAggregator$ContextWait'));




exports = ContextWait; 
//# sourceMappingURL=ContextAggregator$ContextWait.js.map