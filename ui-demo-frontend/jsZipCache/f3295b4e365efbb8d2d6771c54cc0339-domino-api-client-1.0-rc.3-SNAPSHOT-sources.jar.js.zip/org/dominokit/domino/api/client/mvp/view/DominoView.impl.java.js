/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.DominoView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.DominoView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');

let RemovedHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler$impl');
let RevealedHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler$impl');
let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');


/**
 * @interface
 * @template C_T
 * @extends {ContentView}
 */
class DominoView {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isInitialized__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isSingleton__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_createRoot__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @abstract
   * @param {RevealedHandler} revealHandler
   * @return {void}
   * @public
   */
  m_setRevealHandler__org_dominokit_domino_api_client_mvp_view_DominoView_RevealedHandler(revealHandler) {
  }
  
  /**
   * @abstract
   * @param {RemovedHandler} removeHandler
   * @return {void}
   * @public
   */
  m_setRemoveHandler__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler(removeHandler) {
  }
  
  /**
   * @template C_T
   * @param {DominoView<C_T>} $thisArg
   * @param {RevealedHandler} revealHandler
   * @return {void}
   * @public
   */
  static m_setRevealHandler__$default__org_dominokit_domino_api_client_mvp_view_DominoView__org_dominokit_domino_api_client_mvp_view_DominoView_RevealedHandler($thisArg, revealHandler) {
    DominoView.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DominoView<C_T>} $thisArg
   * @param {RemovedHandler} removeHandler
   * @return {void}
   * @public
   */
  static m_setRemoveHandler__$default__org_dominokit_domino_api_client_mvp_view_DominoView__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler($thisArg, removeHandler) {
    DominoView.$clinit();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ContentView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_DominoView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_DominoView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_DominoView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoView.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(DominoView, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.DominoView'));


DominoView.$markImplementor(/** @type {Function} */ (DominoView));


exports = DominoView; 
//# sourceMappingURL=DominoView.js.map