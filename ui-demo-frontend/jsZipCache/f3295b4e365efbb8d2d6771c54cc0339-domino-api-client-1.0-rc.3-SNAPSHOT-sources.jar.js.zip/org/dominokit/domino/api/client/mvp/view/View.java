package org.dominokit.domino.api.client.mvp.view;

public interface View {

}
