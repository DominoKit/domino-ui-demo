/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Fail$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Fail.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Fail = goog.require('org.dominokit.domino.api.client.request.Fail$impl');

let FailedResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');


/**
 * @implements {Fail}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(FailedResponseBean):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(FailedResponseBean):void} */
    this.f_$$fn__org_dominokit_domino_api_client_request_Fail_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_Fail_$LambdaAdaptor__org_dominokit_domino_api_client_request_Fail_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(FailedResponseBean):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Fail_$LambdaAdaptor__org_dominokit_domino_api_client_request_Fail_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_Fail_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {FailedResponseBean} arg0
   * @return {void}
   * @public
   */
  m_onFail__org_dominokit_domino_api_shared_request_FailedResponseBean(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_request_Fail_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.Fail$$LambdaAdaptor'));


Fail.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Fail$$LambdaAdaptor.js.map