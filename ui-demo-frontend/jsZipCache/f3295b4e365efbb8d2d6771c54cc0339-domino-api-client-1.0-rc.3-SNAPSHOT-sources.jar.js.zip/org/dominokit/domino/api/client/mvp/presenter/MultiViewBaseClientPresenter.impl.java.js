/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.MultiViewBaseClientPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.MultiViewBaseClientPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let CompositeView = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.CompositeView$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');


/**
 * @template C_V
 * @extends {ViewBaseClientPresenter<C_V>}
  */
class MultiViewBaseClientPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MultiViewBaseClientPresenter()'.
   * @template C_V
   * @return {!MultiViewBaseClientPresenter<C_V>}
   * @public
   */
  static $create__() {
    MultiViewBaseClientPresenter.$clinit();
    let $instance = new MultiViewBaseClientPresenter();
    $instance.$ctor__org_dominokit_domino_api_client_mvp_presenter_MultiViewBaseClientPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MultiViewBaseClientPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_MultiViewBaseClientPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MultiViewBaseClientPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MultiViewBaseClientPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MultiViewBaseClientPresenter.$clinit = function() {};
    ViewBaseClientPresenter.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MultiViewBaseClientPresenter, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.MultiViewBaseClientPresenter'));




exports = MultiViewBaseClientPresenter; 
//# sourceMappingURL=MultiViewBaseClientPresenter.js.map