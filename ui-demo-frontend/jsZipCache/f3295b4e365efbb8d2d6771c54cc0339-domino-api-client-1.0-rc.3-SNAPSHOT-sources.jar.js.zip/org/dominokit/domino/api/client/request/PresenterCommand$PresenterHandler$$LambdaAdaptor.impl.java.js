/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.PresenterCommand$PresenterHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');


/**
 * @template C_PresenterHandler_P
 * @implements {PresenterHandler<C_PresenterHandler_P>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_PresenterHandler_P):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(C_PresenterHandler_P):void} */
    this.f_$$fn__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$LambdaAdaptor__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_PresenterHandler_P):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$LambdaAdaptor__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {C_PresenterHandler_P} arg0
   * @return {void}
   * @public
   */
  m_onReady__java_lang_Object(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.PresenterCommand$PresenterHandler$$LambdaAdaptor'));


PresenterHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=PresenterCommand$PresenterHandler$$LambdaAdaptor.js.map