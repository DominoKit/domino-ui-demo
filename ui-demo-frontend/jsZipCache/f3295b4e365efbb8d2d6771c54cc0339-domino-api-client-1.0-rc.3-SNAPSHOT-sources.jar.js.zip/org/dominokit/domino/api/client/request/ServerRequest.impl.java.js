/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.ServerRequest.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.ServerRequest$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseRequest = goog.require('org.dominokit.domino.api.client.request.BaseRequest$impl');
const CanFailOrSend = goog.require('org.dominokit.domino.api.client.request.CanFailOrSend$impl');
const Response = goog.require('org.dominokit.domino.api.client.request.Response$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let CanSend = goog.forwardDeclare('org.dominokit.domino.api.client.request.CanSend$impl');
let Fail = goog.forwardDeclare('org.dominokit.domino.api.client.request.Fail$impl');
let InvalidRequestState = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.InvalidRequestState$impl');
let ServerFailedRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext$impl');
let ServerResponseReceivedStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext$impl');
let ServerSuccessRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext$impl');
let RequestState = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestState$impl');
let Success = goog.forwardDeclare('org.dominokit.domino.api.client.request.Success$impl');
let FailedResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');
let RequestBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.RequestBean$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_R, C_S
 * @implements {Response<C_S>}
 * @implements {CanFailOrSend}
  */
class ServerRequest extends BaseRequest {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<?string, ?string>} */
    this.f_headers__org_dominokit_domino_api_client_request_ServerRequest_;
    /** @public {C_R} */
    this.f_requestBean__org_dominokit_domino_api_client_request_ServerRequest_;
    /** @public {Success<C_S>} */
    this.f_success__org_dominokit_domino_api_client_request_ServerRequest_;
    /** @public {Fail} */
    this.f_fail__org_dominokit_domino_api_client_request_ServerRequest_;
    /** @public {RequestState<ServerSuccessRequestStateContext>} */
    this.f_executedOnServer__org_dominokit_domino_api_client_request_ServerRequest_;
    /** @public {RequestState<ServerFailedRequestStateContext>} */
    this.f_failedOnServer__org_dominokit_domino_api_client_request_ServerRequest_;
    /** @public {RequestState<ServerResponseReceivedStateContext>} */
    this.f_sent__org_dominokit_domino_api_client_request_ServerRequest_;
  }
  
  /**
   * Initialization from constructor 'ServerRequest()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_ServerRequest__() {
    this.$ctor__org_dominokit_domino_api_client_request_BaseRequest__();
    this.$init__org_dominokit_domino_api_client_request_ServerRequest();
  }
  
  /**
   * Initialization from constructor 'ServerRequest(RequestBean)'.
   * @param {C_R} requestBean
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_RequestBean(requestBean) {
    this.$ctor__org_dominokit_domino_api_client_request_BaseRequest__();
    this.$init__org_dominokit_domino_api_client_request_ServerRequest();
    this.f_requestBean__org_dominokit_domino_api_client_request_ServerRequest_ = requestBean;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_send__() {
    this.m_execute__();
  }
  
  /**
   * @param {C_R} requestBean
   * @return {ServerRequest<C_R, C_S>}
   * @public
   */
  m_setBean__org_dominokit_domino_api_shared_request_RequestBean(requestBean) {
    this.f_requestBean__org_dominokit_domino_api_client_request_ServerRequest_ = requestBean;
    return this;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_startRouting__() {
    this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_sent__org_dominokit_domino_api_client_request_ServerRequest_;
    this.f_clientApp__org_dominokit_domino_api_client_request_BaseRequest.m_getServerRouter__().m_routeRequest__org_dominokit_domino_api_client_request_Request(this);
  }
  
  /**
   * @return {C_R}
   * @public
   */
  m_requestBean__() {
    return this.f_requestBean__org_dominokit_domino_api_client_request_ServerRequest_;
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @return {ServerRequest<C_R, C_S>}
   * @public
   */
  m_setHeader__java_lang_String__java_lang_String(name, value) {
    this.f_headers__org_dominokit_domino_api_client_request_ServerRequest_.put(name, value);
    return this;
  }
  
  /**
   * @return {Map<?string, ?string>}
   * @public
   */
  m_headers__() {
    return /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__java_util_Map(this.f_headers__org_dominokit_domino_api_client_request_ServerRequest_));
  }
  
  /**
   * @override
   * @param {Success<C_S>} success
   * @return {CanFailOrSend}
   * @public
   */
  m_onSuccess__org_dominokit_domino_api_client_request_Success(success) {
    this.f_success__org_dominokit_domino_api_client_request_ServerRequest_ = success;
    return this;
  }
  
  /**
   * @override
   * @param {Fail} fail
   * @return {CanSend}
   * @public
   */
  m_onFailed__org_dominokit_domino_api_client_request_Fail(fail) {
    this.f_fail__org_dominokit_domino_api_client_request_ServerRequest_ = fail;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_request_ServerRequest() {
    this.f_headers__org_dominokit_domino_api_client_request_ServerRequest_ = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
    this.f_success__org_dominokit_domino_api_client_request_ServerRequest_ = /**@type {Success<C_S>} */ (Success.$adapt(((/** ResponseBean */ response) =>{
    })));
    this.f_fail__org_dominokit_domino_api_client_request_ServerRequest_ = Fail.$adapt(((/** FailedResponseBean */ failedResponse) =>{
      ServerRequest.$f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_.m_debug__java_lang_String__java_lang_Throwable("could not execute request on server: ", failedResponse.m_getError__());
    }));
    this.f_executedOnServer__org_dominokit_domino_api_client_request_ServerRequest_ = RequestState.$adapt(((/** ServerSuccessRequestStateContext */ context) =>{
      this.f_success__org_dominokit_domino_api_client_request_ServerRequest_.m_onSuccess__org_dominokit_domino_api_shared_request_ResponseBean(/**@type {ResponseBean} */ ($Casts.$to(context.f_responseBean__org_dominokit_domino_api_client_request_Request_ServerSuccessRequestStateContext, ResponseBean)));
      this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_completed__org_dominokit_domino_api_client_request_BaseRequest;
    }));
    this.f_failedOnServer__org_dominokit_domino_api_client_request_ServerRequest_ = RequestState.$adapt(((/** ServerFailedRequestStateContext */ context$1$) =>{
      this.f_fail__org_dominokit_domino_api_client_request_ServerRequest_.m_onFail__org_dominokit_domino_api_shared_request_FailedResponseBean(context$1$.f_response__org_dominokit_domino_api_client_request_Request_ServerFailedRequestStateContext);
      this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_completed__org_dominokit_domino_api_client_request_BaseRequest;
    }));
    this.f_sent__org_dominokit_domino_api_client_request_ServerRequest_ = RequestState.$adapt(((/** ServerResponseReceivedStateContext */ context$2$) =>{
      if (ServerSuccessRequestStateContext.$isInstance(context$2$.f_nextContext__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext)) {
        this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_executedOnServer__org_dominokit_domino_api_client_request_ServerRequest_;
        this.m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(context$2$.f_nextContext__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext);
      } else if (ServerFailedRequestStateContext.$isInstance(context$2$.f_nextContext__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext)) {
        this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_failedOnServer__org_dominokit_domino_api_client_request_ServerRequest_;
        this.m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(context$2$.f_nextContext__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext);
      } else {
        throw $Exceptions.toJs(InvalidRequestState.$create__java_lang_String("Request cannot be processed until a responseBean is recieved from the server"));
      }
    }));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_() {
    return (ServerRequest.$clinit(), ServerRequest.$f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_(value) {
    (ServerRequest.$clinit(), ServerRequest.$f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerRequest;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerRequest);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerRequest.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Fail = goog.module.get('org.dominokit.domino.api.client.request.Fail$impl');
    InvalidRequestState = goog.module.get('org.dominokit.domino.api.client.request.Request.InvalidRequestState$impl');
    ServerFailedRequestStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext$impl');
    ServerSuccessRequestStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext$impl');
    RequestState = goog.module.get('org.dominokit.domino.api.client.request.RequestState$impl');
    Success = goog.module.get('org.dominokit.domino.api.client.request.Success$impl');
    ResponseBean = goog.module.get('org.dominokit.domino.api.shared.request.ResponseBean$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    BaseRequest.$clinit();
    ServerRequest.$f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ServerRequest));
  }
  
  
};

$Util.$setClassMetadata(ServerRequest, $Util.$makeClassName('org.dominokit.domino.api.client.request.ServerRequest'));


/** @private {Logger} */
ServerRequest.$f_LOGGER__org_dominokit_domino_api_client_request_ServerRequest_;


Response.$markImplementor(ServerRequest);
CanFailOrSend.$markImplementor(ServerRequest);


exports = ServerRequest; 
//# sourceMappingURL=ServerRequest.js.map