/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CommandsRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.CommandsRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let RequestHolder = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestHolder$impl');


/**
 * @interface
 */
class CommandsRepository {
  /**
   * @abstract
   * @param {RequestHolder} requestHolder
   * @return {void}
   * @public
   */
  m_registerCommand__org_dominokit_domino_api_client_request_RequestHolder(requestHolder) {
  }
  
  /**
   * @abstract
   * @param {?string} requestKey
   * @return {RequestHolder}
   * @public
   */
  m_findRequestPresenterWrapper__java_lang_String(requestKey) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CommandsRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_CommandsRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CommandsRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CommandsRepository.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(CommandsRepository, $Util.$makeClassName('org.dominokit.domino.api.client.request.CommandsRepository'));


CommandsRepository.$markImplementor(/** @type {Function} */ (CommandsRepository));


exports = CommandsRepository; 
//# sourceMappingURL=CommandsRepository.js.map