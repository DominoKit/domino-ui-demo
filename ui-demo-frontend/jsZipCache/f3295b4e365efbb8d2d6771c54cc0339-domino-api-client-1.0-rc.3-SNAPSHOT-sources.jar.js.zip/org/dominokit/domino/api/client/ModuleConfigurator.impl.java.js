/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ModuleConfigurator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ModuleConfigurator$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let ModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.api.client.ModuleConfiguration$impl');


class ModuleConfigurator extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ModuleConfigurator()'.
   * @return {!ModuleConfigurator}
   * @public
   */
  static $create__() {
    ModuleConfigurator.$clinit();
    let $instance = new ModuleConfigurator();
    $instance.$ctor__org_dominokit_domino_api_client_ModuleConfigurator__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModuleConfigurator()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ModuleConfigurator__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ModuleConfiguration} moduleConfiguration
   * @return {void}
   * @public
   */
  m_configureModule__org_dominokit_domino_api_client_ModuleConfiguration(moduleConfiguration) {
    ClientApp.m_make__().m_configureModule__org_dominokit_domino_api_client_ModuleConfiguration(moduleConfiguration);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModuleConfigurator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModuleConfigurator);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModuleConfigurator.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ModuleConfigurator, $Util.$makeClassName('org.dominokit.domino.api.client.ModuleConfigurator'));




exports = ModuleConfigurator; 
//# sourceMappingURL=ModuleConfigurator.js.map