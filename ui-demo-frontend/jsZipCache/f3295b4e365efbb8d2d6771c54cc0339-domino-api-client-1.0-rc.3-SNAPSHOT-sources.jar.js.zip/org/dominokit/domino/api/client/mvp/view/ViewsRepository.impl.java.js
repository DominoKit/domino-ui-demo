/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.ViewsRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let LazyViewLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');


/**
 * @interface
 */
class ViewsRepository {
  /**
   * @abstract
   * @param {LazyViewLoader} lazyViewLoader
   * @return {void}
   * @public
   */
  m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader(lazyViewLoader) {
  }
  
  /**
   * @abstract
   * @param {?string} presenterName
   * @return {View}
   * @public
   */
  m_getView__java_lang_String(presenterName) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_ViewsRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_ViewsRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_ViewsRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ViewsRepository.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ViewsRepository, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.ViewsRepository'));


ViewsRepository.$markImplementor(/** @type {Function} */ (ViewsRepository));


exports = ViewsRepository; 
//# sourceMappingURL=ViewsRepository.js.map