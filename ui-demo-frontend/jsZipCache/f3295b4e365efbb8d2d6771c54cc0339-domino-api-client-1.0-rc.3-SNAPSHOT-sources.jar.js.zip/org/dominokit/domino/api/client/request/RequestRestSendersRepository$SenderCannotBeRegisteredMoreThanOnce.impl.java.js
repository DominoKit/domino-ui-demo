/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSendersRepository$SenderCannotBeRegisteredMoreThanOnce.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderCannotBeRegisteredMoreThanOnce$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class SenderCannotBeRegisteredMoreThanOnce extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SenderCannotBeRegisteredMoreThanOnce(String)'.
   * @param {?string} requestName
   * @return {!SenderCannotBeRegisteredMoreThanOnce}
   * @public
   */
  static $create__java_lang_String(requestName) {
    SenderCannotBeRegisteredMoreThanOnce.$clinit();
    let $instance = new SenderCannotBeRegisteredMoreThanOnce();
    $instance.$ctor__org_dominokit_domino_api_client_request_RequestRestSendersRepository_SenderCannotBeRegisteredMoreThanOnce__java_lang_String(requestName);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SenderCannotBeRegisteredMoreThanOnce(String)'.
   * @param {?string} requestName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_RequestRestSendersRepository_SenderCannotBeRegisteredMoreThanOnce__java_lang_String(requestName) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(requestName);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SenderCannotBeRegisteredMoreThanOnce;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SenderCannotBeRegisteredMoreThanOnce);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SenderCannotBeRegisteredMoreThanOnce.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SenderCannotBeRegisteredMoreThanOnce, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestRestSendersRepository$SenderCannotBeRegisteredMoreThanOnce'));




exports = SenderCannotBeRegisteredMoreThanOnce; 
//# sourceMappingURL=RequestRestSendersRepository$SenderCannotBeRegisteredMoreThanOnce.js.map