/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.DominoEvents.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.extension.DominoEvents');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');


// Re-exports the implementation.
var DominoEvents = goog.require('org.dominokit.domino.api.client.extension.DominoEvents$impl');
exports = DominoEvents;
 