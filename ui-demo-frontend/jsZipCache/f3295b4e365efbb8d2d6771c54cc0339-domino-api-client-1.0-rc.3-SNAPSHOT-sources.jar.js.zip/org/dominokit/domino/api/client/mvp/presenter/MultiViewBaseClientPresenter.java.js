/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.MultiViewBaseClientPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.MultiViewBaseClientPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _CompositeView = goog.require('org.dominokit.domino.api.client.mvp.view.CompositeView');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');


// Re-exports the implementation.
var MultiViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.MultiViewBaseClientPresenter$impl');
exports = MultiViewBaseClientPresenter;
 