/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.HasPathMatcher.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.HasPathMatcher$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');
let HasServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.HasPathMatcher.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasPathMatcher {
  /**
   * @abstract
   * @param {HasServiceRoot} serviceRoot
   * @return {DynamicServiceRoot}
   * @public
   */
  m_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot(serviceRoot) {
  }
  
  /**
   * @param {?function(HasServiceRoot):DynamicServiceRoot} fn
   * @return {HasPathMatcher}
   * @public
   */
  static $adapt(fn) {
    HasPathMatcher.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_HasPathMatcher = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_HasPathMatcher;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_HasPathMatcher;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasPathMatcher.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.HasPathMatcher.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasPathMatcher, $Util.$makeClassName('org.dominokit.domino.api.client.HasPathMatcher'));


HasPathMatcher.$markImplementor(/** @type {Function} */ (HasPathMatcher));


exports = HasPathMatcher; 
//# sourceMappingURL=HasPathMatcher.js.map