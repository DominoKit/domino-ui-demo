/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.Presentable.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class Presentable {
  /**
   * @abstract
   * @return {Presentable}
   * @public
   */
  m_init__() {
  }
  
  /**
   * @param {Presentable} $thisArg
   * @return {Presentable}
   * @public
   */
  static m_init__$default__org_dominokit_domino_api_client_mvp_presenter_Presentable($thisArg) {
    Presentable.$clinit();
    return $thisArg;
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_presenter_Presentable = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_presenter_Presentable;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_presenter_Presentable;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Presentable.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Presentable, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.Presentable'));


Presentable.$markImplementor(/** @type {Function} */ (Presentable));


exports = Presentable; 
//# sourceMappingURL=Presentable.js.map