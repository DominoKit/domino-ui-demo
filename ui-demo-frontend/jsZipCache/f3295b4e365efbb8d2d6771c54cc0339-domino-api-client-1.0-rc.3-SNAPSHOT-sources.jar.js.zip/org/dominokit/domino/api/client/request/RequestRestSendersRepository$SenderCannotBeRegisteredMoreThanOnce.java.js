/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSendersRepository$SenderCannotBeRegisteredMoreThanOnce.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderCannotBeRegisteredMoreThanOnce');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var SenderCannotBeRegisteredMoreThanOnce = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderCannotBeRegisteredMoreThanOnce$impl');
exports = SenderCannotBeRegisteredMoreThanOnce;
 