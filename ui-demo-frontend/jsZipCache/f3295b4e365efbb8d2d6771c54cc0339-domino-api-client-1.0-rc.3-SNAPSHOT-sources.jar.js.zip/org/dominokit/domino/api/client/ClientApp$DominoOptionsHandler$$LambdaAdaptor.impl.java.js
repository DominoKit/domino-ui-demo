/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$DominoOptionsHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoOptionsHandler = goog.require('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler$impl');

let CanSetDominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.CanSetDominoOptions$impl');


/**
 * @implements {DominoOptionsHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(CanSetDominoOptions):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(CanSetDominoOptions):void} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(CanSetDominoOptions):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {CanSetDominoOptions} arg0
   * @return {void}
   * @public
   */
  m_onBeforeRun__org_dominokit_domino_api_client_CanSetDominoOptions(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$DominoOptionsHandler$$LambdaAdaptor'));


DominoOptionsHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$DominoOptionsHandler$$LambdaAdaptor.js.map