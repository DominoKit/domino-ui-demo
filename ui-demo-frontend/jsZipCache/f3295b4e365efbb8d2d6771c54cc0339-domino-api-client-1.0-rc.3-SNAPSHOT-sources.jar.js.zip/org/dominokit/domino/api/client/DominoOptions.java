package org.dominokit.domino.api.client;

public interface DominoOptions extends HasDominoOptions, CanSetDominoOptions {
    void applyOptions();
}
