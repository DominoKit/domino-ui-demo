/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.HasUiHandlers.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.HasUiHandlers$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasUiHandlers.$LambdaAdaptor$impl');
let UiHandlers = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.UiHandlers$impl');


/**
 * @interface
 * @template C_T
 */
class HasUiHandlers {
  /**
   * @abstract
   * @param {C_T} uiHandlers
   * @return {void}
   * @public
   */
  m_setUiHandlers__org_dominokit_domino_api_client_mvp_view_UiHandlers(uiHandlers) {
  }
  
  /**
   * @template C_T
   * @param {?function(C_T):void} fn
   * @return {HasUiHandlers<C_T>}
   * @public
   */
  static $adapt(fn) {
    HasUiHandlers.$clinit();
    return /**@type {!$LambdaAdaptor<UiHandlers>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_HasUiHandlers = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_HasUiHandlers;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_HasUiHandlers;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasUiHandlers.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasUiHandlers.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasUiHandlers, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.HasUiHandlers'));


HasUiHandlers.$markImplementor(/** @type {Function} */ (HasUiHandlers));


exports = HasUiHandlers; 
//# sourceMappingURL=HasUiHandlers.js.map