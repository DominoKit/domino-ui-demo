/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.DominoEvents.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.DominoEvents$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');


class DominoEvents extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DominoEvents()'.
   * @return {!DominoEvents}
   * @public
   */
  static $create__() {
    DominoEvents.$clinit();
    let $instance = new DominoEvents();
    $instance.$ctor__org_dominokit_domino_api_client_extension_DominoEvents__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DominoEvents()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_DominoEvents__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @template M_E
   * @param {Class<M_E>} eventType
   * @param {M_E} dominoEvent
   * @return {void}
   * @public
   */
  static m_fire__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEvent(eventType, dominoEvent) {
    DominoEvents.$clinit();
    ClientApp.m_make__().m_fireEvent__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEvent(eventType, dominoEvent);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DominoEvents;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DominoEvents);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoEvents.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DominoEvents, $Util.$makeClassName('org.dominokit.domino.api.client.extension.DominoEvents'));




exports = DominoEvents; 
//# sourceMappingURL=DominoEvents.js.map