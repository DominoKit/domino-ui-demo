/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.Request.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.Request$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.annotations.Request.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class Request {
  /**
   * @param {?function():Class<?>} fn
   * @return {Request}
   * @public
   */
  static $adapt(fn) {
    Request.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_Request = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_Request;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_Request;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Request.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.annotations.Request.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Request, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.Request'));


Request.$markImplementor(/** @type {Function} */ (Request));


exports = Request; 
//# sourceMappingURL=Request.js.map