/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSender$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSender.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestRestSender = goog.require('org.dominokit.domino.api.client.request.RequestRestSender$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let ServerRequestCallBack = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequestCallBack$impl');
let RequestBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.RequestBean$impl');


/**
 * @template C_T
 * @implements {RequestRestSender<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_T, Map<?string, ?string>, ServerRequestCallBack):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(C_T, Map<?string, ?string>, ServerRequestCallBack):void} */
    this.f_$$fn__org_dominokit_domino_api_client_request_RequestRestSender_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_RequestRestSender_$LambdaAdaptor__org_dominokit_domino_api_client_request_RequestRestSender_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_T, Map<?string, ?string>, ServerRequestCallBack):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_RequestRestSender_$LambdaAdaptor__org_dominokit_domino_api_client_request_RequestRestSender_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_RequestRestSender_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {C_T} arg0
   * @param {Map<?string, ?string>} arg1
   * @param {ServerRequestCallBack} arg2
   * @return {void}
   * @public
   */
  m_send__org_dominokit_domino_api_shared_request_RequestBean__java_util_Map__org_dominokit_domino_api_client_request_ServerRequestCallBack(arg0, arg1, arg2) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_request_RequestRestSender_$LambdaAdaptor;
      $function(arg0, arg1, arg2);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestRestSender$$LambdaAdaptor'));


RequestRestSender.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=RequestRestSender$$LambdaAdaptor.js.map