/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.EventsBus$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.EventsBus.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const EventsBus = goog.require('org.dominokit.domino.api.client.events.EventsBus$impl');

let RequestEvent = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus.RequestEvent$impl');


/**
 * @template C_T
 * @implements {EventsBus<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(RequestEvent<C_T>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(RequestEvent<C_T>):void} */
    this.f_$$fn__org_dominokit_domino_api_client_events_EventsBus_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_events_EventsBus_$LambdaAdaptor__org_dominokit_domino_api_client_events_EventsBus_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(RequestEvent<C_T>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_events_EventsBus_$LambdaAdaptor__org_dominokit_domino_api_client_events_EventsBus_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_events_EventsBus_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {RequestEvent<C_T>} arg0
   * @return {void}
   * @public
   */
  m_publishEvent__org_dominokit_domino_api_client_events_EventsBus_RequestEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_events_EventsBus_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.events.EventsBus$$LambdaAdaptor'));


EventsBus.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=EventsBus$$LambdaAdaptor.js.map