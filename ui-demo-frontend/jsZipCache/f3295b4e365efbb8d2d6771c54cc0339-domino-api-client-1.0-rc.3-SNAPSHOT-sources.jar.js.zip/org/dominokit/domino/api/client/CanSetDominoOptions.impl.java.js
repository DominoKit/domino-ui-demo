/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.CanSetDominoOptions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.CanSetDominoOptions$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');


/**
 * @interface
 */
class CanSetDominoOptions {
  /**
   * @abstract
   * @param {?string} defaultServiceRoot
   * @return {CanSetDominoOptions}
   * @public
   */
  m_setDefaultServiceRoot__java_lang_String(defaultServiceRoot) {
  }
  
  /**
   * @abstract
   * @param {?string} defaultJsonDateFormat
   * @return {CanSetDominoOptions}
   * @public
   */
  m_setDefaultJsonDateFormat__java_lang_String(defaultJsonDateFormat) {
  }
  
  /**
   * @abstract
   * @param {DynamicServiceRoot} dynamicServiceRoot
   * @return {CanSetDominoOptions}
   * @public
   */
  m_addDynamicServiceRoot__org_dominokit_domino_api_client_DynamicServiceRoot(dynamicServiceRoot) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_CanSetDominoOptions = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_CanSetDominoOptions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_CanSetDominoOptions;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanSetDominoOptions.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(CanSetDominoOptions, $Util.$makeClassName('org.dominokit.domino.api.client.CanSetDominoOptions'));


CanSetDominoOptions.$markImplementor(/** @type {Function} */ (CanSetDominoOptions));


exports = CanSetDominoOptions; 
//# sourceMappingURL=CanSetDominoOptions.js.map