/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ModuleConfigurationProvider.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ModuleConfigurationProvider$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.api.client.ModuleConfiguration$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ModuleConfigurationProvider.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ModuleConfigurationProvider {
  /**
   * @abstract
   * @return {ModuleConfiguration}
   * @public
   */
  m_get__() {
  }
  
  /**
   * @param {?function():ModuleConfiguration} fn
   * @return {ModuleConfigurationProvider}
   * @public
   */
  static $adapt(fn) {
    ModuleConfigurationProvider.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ModuleConfigurationProvider = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ModuleConfigurationProvider;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ModuleConfigurationProvider;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModuleConfigurationProvider.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ModuleConfigurationProvider.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ModuleConfigurationProvider, $Util.$makeClassName('org.dominokit.domino.api.client.ModuleConfigurationProvider'));


ModuleConfigurationProvider.$markImplementor(/** @type {Function} */ (ModuleConfigurationProvider));


exports = ModuleConfigurationProvider; 
//# sourceMappingURL=ModuleConfigurationProvider.js.map