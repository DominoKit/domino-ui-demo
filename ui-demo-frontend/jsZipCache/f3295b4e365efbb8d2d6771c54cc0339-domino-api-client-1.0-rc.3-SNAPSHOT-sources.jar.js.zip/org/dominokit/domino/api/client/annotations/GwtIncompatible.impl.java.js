/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.GwtIncompatible.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.GwtIncompatible$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class GwtIncompatible {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_GwtIncompatible = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_GwtIncompatible;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_GwtIncompatible;
  }
  
  /**
   * @public
   */
  static $clinit() {
    GwtIncompatible.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(GwtIncompatible, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.GwtIncompatible'));


GwtIncompatible.$markImplementor(/** @type {Function} */ (GwtIncompatible));


exports = GwtIncompatible; 
//# sourceMappingURL=GwtIncompatible.js.map