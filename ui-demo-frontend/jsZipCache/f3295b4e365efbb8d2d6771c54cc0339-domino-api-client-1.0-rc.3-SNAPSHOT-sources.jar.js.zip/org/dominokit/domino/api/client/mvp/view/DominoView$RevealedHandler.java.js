/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.DominoView$RevealedHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler.$LambdaAdaptor');


// Re-exports the implementation.
var RevealedHandler = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler$impl');
exports = RevealedHandler;
 