/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.ServerRequest.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.ServerRequest');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseRequest = goog.require('org.dominokit.domino.api.client.request.BaseRequest');
const _CanFailOrSend = goog.require('org.dominokit.domino.api.client.request.CanFailOrSend');
const _Response = goog.require('org.dominokit.domino.api.client.request.Response');
const _Class = goog.require('java.lang.Class');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _CanSend = goog.require('org.dominokit.domino.api.client.request.CanSend');
const _Fail = goog.require('org.dominokit.domino.api.client.request.Fail');
const _InvalidRequestState = goog.require('org.dominokit.domino.api.client.request.Request.InvalidRequestState');
const _ServerFailedRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext');
const _ServerResponseReceivedStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext');
const _ServerSuccessRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext');
const _RequestState = goog.require('org.dominokit.domino.api.client.request.RequestState');
const _Success = goog.require('org.dominokit.domino.api.client.request.Success');
const _FailedResponseBean = goog.require('org.dominokit.domino.api.shared.request.FailedResponseBean');
const _RequestBean = goog.require('org.dominokit.domino.api.shared.request.RequestBean');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest$impl');
exports = ServerRequest;
 