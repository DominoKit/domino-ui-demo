/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CommandsRepository$CommandKeyNotFoundException.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.CommandsRepository.CommandKeyNotFoundException');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var CommandKeyNotFoundException = goog.require('org.dominokit.domino.api.client.request.CommandsRepository.CommandKeyNotFoundException$impl');
exports = CommandKeyNotFoundException;
 