/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRouter$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRouter.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter');
const _Request = goog.require('org.dominokit.domino.api.client.request.Request');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.request.RequestRouter.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 