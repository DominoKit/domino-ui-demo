/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestHolder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestHolder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


class RequestHolder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_requestName__org_dominokit_domino_api_client_request_RequestHolder_;
    /** @public {?string} */
    this.f_presenterName__org_dominokit_domino_api_client_request_RequestHolder_;
  }
  
  /**
   * Factory method corresponding to constructor 'RequestHolder(String, String)'.
   * @param {?string} requestName
   * @param {?string} presenterName
   * @return {!RequestHolder}
   * @public
   */
  static $create__java_lang_String__java_lang_String(requestName, presenterName) {
    RequestHolder.$clinit();
    let $instance = new RequestHolder();
    $instance.$ctor__org_dominokit_domino_api_client_request_RequestHolder__java_lang_String__java_lang_String(requestName, presenterName);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RequestHolder(String, String)'.
   * @param {?string} requestName
   * @param {?string} presenterName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_RequestHolder__java_lang_String__java_lang_String(requestName, presenterName) {
    this.$ctor__java_lang_Object__();
    this.f_requestName__org_dominokit_domino_api_client_request_RequestHolder_ = requestName;
    this.f_presenterName__org_dominokit_domino_api_client_request_RequestHolder_ = presenterName;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getRequestName__() {
    return this.f_requestName__org_dominokit_domino_api_client_request_RequestHolder_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPresenterName__() {
    return this.f_presenterName__org_dominokit_domino_api_client_request_RequestHolder_;
  }
  
  /**
   * @override
   * @param {*} other
   * @return {boolean}
   * @public
   */
  equals(other) {
    if ($Equality.$same(this, other)) {
      return true;
    }
    if ($Equality.$same(other, null) || !$Equality.$same(this.m_getClass__(), $Objects.m_getClass__java_lang_Object(other))) {
      return false;
    }
    if (!j_l_String.m_equals__java_lang_String__java_lang_Object(this.m_getRequestName__(), (/**@type {RequestHolder} */ ($Casts.$to(other, RequestHolder))).m_getRequestName__())) {
      return false;
    }
    return j_l_String.m_equals__java_lang_String__java_lang_Object(this.m_getPresenterName__(), (/**@type {RequestHolder} */ ($Casts.$to(other, RequestHolder))).m_getPresenterName__());
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    let result = j_l_String.m_hashCode__java_lang_String(this.m_getRequestName__());
    result = 31 * result + j_l_String.m_hashCode__java_lang_String(this.m_getPresenterName__());
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RequestHolder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RequestHolder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestHolder.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(RequestHolder, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestHolder'));




exports = RequestHolder; 
//# sourceMappingURL=RequestHolder.js.map