/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasRequestRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasRequestRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasPresentersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasRequestRepository.$LambdaAdaptor$impl');
let PresentersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');


/**
 * @interface
 */
class HasRequestRepository {
  /**
   * @abstract
   * @param {PresentersRepository} presentersRepository
   * @return {HasPresentersRepository}
   * @public
   */
  m_presentersRepository__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository(presentersRepository) {
  }
  
  /**
   * @param {?function(PresentersRepository):HasPresentersRepository} fn
   * @return {HasRequestRepository}
   * @public
   */
  static $adapt(fn) {
    HasRequestRepository.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasRequestRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasRequestRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasRequestRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasRequestRepository.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasRequestRepository.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasRequestRepository, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasRequestRepository'));


HasRequestRepository.$markImplementor(/** @type {Function} */ (HasRequestRepository));


exports = HasRequestRepository; 
//# sourceMappingURL=ClientApp$HasRequestRepository.js.map