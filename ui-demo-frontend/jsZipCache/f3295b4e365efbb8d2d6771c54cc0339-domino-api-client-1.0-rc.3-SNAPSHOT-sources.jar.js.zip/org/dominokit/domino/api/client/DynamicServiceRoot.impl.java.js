/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.DynamicServiceRoot.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.DynamicServiceRoot$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasPathMatcher = goog.require('org.dominokit.domino.api.client.HasPathMatcher$impl');

let HasServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot$impl');
let PathMatcher = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher$impl');


/**
 * @implements {HasPathMatcher}
  */
class DynamicServiceRoot extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {PathMatcher} */
    this.f_pathMatcher__org_dominokit_domino_api_client_DynamicServiceRoot_;
    /** @public {HasServiceRoot} */
    this.f_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_;
  }
  
  /**
   * Factory method corresponding to constructor 'DynamicServiceRoot(PathMatcher)'.
   * @param {PathMatcher} pathMatcher
   * @return {!DynamicServiceRoot}
   * @public
   */
  static $create__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher(pathMatcher) {
    DynamicServiceRoot.$clinit();
    let $instance = new DynamicServiceRoot();
    $instance.$ctor__org_dominokit_domino_api_client_DynamicServiceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher(pathMatcher);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DynamicServiceRoot(PathMatcher)'.
   * @param {PathMatcher} pathMatcher
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_DynamicServiceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher(pathMatcher) {
    this.$ctor__java_lang_Object__();
    this.f_pathMatcher__org_dominokit_domino_api_client_DynamicServiceRoot_ = pathMatcher;
  }
  
  /**
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_isMatchingPath__java_lang_String(path) {
    return this.f_pathMatcher__org_dominokit_domino_api_client_DynamicServiceRoot_.m_isMatch__java_lang_String(path);
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_onMatchingPath__() {
    return this.f_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_.m_onMatch__();
  }
  
  /**
   * @param {PathMatcher} pathMatcher
   * @return {HasPathMatcher}
   * @public
   */
  static m_pathMatcher__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher(pathMatcher) {
    DynamicServiceRoot.$clinit();
    return DynamicServiceRoot.$create__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher(pathMatcher);
  }
  
  /**
   * @override
   * @param {HasServiceRoot} serviceRoot
   * @return {DynamicServiceRoot}
   * @public
   */
  m_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot(serviceRoot) {
    this.f_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_ = serviceRoot;
    return this;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DynamicServiceRoot;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DynamicServiceRoot);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DynamicServiceRoot.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DynamicServiceRoot, $Util.$makeClassName('org.dominokit.domino.api.client.DynamicServiceRoot'));


HasPathMatcher.$markImplementor(DynamicServiceRoot);


exports = DynamicServiceRoot; 
//# sourceMappingURL=DynamicServiceRoot.js.map