/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.HasDominoOptions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.HasDominoOptions$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');


/**
 * @interface
 */
class HasDominoOptions {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getDefaultServiceRoot__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getDefaultJsonDateFormat__() {
  }
  
  /**
   * @abstract
   * @return {List<DynamicServiceRoot>}
   * @public
   */
  m_getServiceRoots__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_HasDominoOptions = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_HasDominoOptions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_HasDominoOptions;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasDominoOptions.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(HasDominoOptions, $Util.$makeClassName('org.dominokit.domino.api.client.HasDominoOptions'));


HasDominoOptions.$markImplementor(/** @type {Function} */ (HasDominoOptions));


exports = HasDominoOptions; 
//# sourceMappingURL=HasDominoOptions.js.map