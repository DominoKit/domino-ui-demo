/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.HasContent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.HasContent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent.$LambdaAdaptor');
const _CreateHandler = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');


// Re-exports the implementation.
var HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
exports = HasContent;
 