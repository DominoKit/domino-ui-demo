/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.CompositeView$ViewNotFoundInCompositeView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.CompositeView.ViewNotFoundInCompositeView$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class ViewNotFoundInCompositeView extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ViewNotFoundInCompositeView(String)'.
   * @param {?string} message
   * @return {!ViewNotFoundInCompositeView}
   * @public
   */
  static $create__java_lang_String(message) {
    ViewNotFoundInCompositeView.$clinit();
    let $instance = new ViewNotFoundInCompositeView();
    $instance.$ctor__org_dominokit_domino_api_client_mvp_view_CompositeView_ViewNotFoundInCompositeView__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ViewNotFoundInCompositeView(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_view_CompositeView_ViewNotFoundInCompositeView__java_lang_String(message) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ViewNotFoundInCompositeView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ViewNotFoundInCompositeView);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ViewNotFoundInCompositeView.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ViewNotFoundInCompositeView, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.CompositeView$ViewNotFoundInCompositeView'));




exports = ViewNotFoundInCompositeView; 
//# sourceMappingURL=CompositeView$ViewNotFoundInCompositeView.js.map