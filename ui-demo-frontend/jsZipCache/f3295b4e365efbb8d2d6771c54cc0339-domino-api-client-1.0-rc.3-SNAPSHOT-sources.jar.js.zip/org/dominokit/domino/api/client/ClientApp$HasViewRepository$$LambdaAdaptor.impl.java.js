/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasViewRepository$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasViewRepository.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasViewRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');

let HasDominoEventListenersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasDominoEventListenersRepository$impl');
let DominoEventsListenersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository$impl');


/**
 * @implements {HasViewRepository}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(DominoEventsListenersRepository):HasDominoEventListenersRepository} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(DominoEventsListenersRepository):HasDominoEventListenersRepository} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(DominoEventsListenersRepository):HasDominoEventListenersRepository} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {DominoEventsListenersRepository} arg0
   * @return {HasDominoEventListenersRepository}
   * @public
   */
  m_eventsListenersRepository__org_dominokit_domino_api_client_extension_DominoEventsListenersRepository(arg0) {
    let /** ?function(DominoEventsListenersRepository):HasDominoEventListenersRepository */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasViewRepository$$LambdaAdaptor'));


HasViewRepository.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasViewRepository$$LambdaAdaptor.js.map