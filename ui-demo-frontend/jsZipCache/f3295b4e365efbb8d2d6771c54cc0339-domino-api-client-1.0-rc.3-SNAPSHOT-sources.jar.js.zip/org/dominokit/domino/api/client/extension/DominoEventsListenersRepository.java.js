/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.DominoEventsListenersRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Set = goog.require('java.util.Set');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');


// Re-exports the implementation.
var DominoEventsListenersRepository = goog.require('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository$impl');
exports = DominoEventsListenersRepository;
 