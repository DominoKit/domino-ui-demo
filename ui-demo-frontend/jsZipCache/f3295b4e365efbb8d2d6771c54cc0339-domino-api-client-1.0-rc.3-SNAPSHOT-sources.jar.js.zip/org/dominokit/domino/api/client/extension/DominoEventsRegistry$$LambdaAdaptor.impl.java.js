/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.DominoEventsRegistry$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.DominoEventsRegistry.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let DominoEventListener = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');


/**
 * @implements {DominoEventsRegistry}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(Class<?>, DominoEventListener):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(Class<?>, DominoEventListener):void} */
    this.f_$$fn__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(Class<?>, DominoEventListener):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {Class<?>} arg0
   * @param {DominoEventListener} arg1
   * @return {void}
   * @public
   */
  m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_extension_DominoEventsRegistry_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.extension.DominoEventsRegistry$$LambdaAdaptor'));


DominoEventsRegistry.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DominoEventsRegistry$$LambdaAdaptor.js.map