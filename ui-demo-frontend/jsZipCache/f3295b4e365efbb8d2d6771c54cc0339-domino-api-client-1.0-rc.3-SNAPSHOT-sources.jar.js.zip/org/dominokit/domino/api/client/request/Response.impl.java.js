/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Response.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Response$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let CanFailOrSend = goog.forwardDeclare('org.dominokit.domino.api.client.request.CanFailOrSend$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.Response.$LambdaAdaptor$impl');
let Success = goog.forwardDeclare('org.dominokit.domino.api.client.request.Success$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @interface
 * @template C_S
 */
class Response {
  /**
   * @abstract
   * @param {Success<C_S>} success
   * @return {CanFailOrSend}
   * @public
   */
  m_onSuccess__org_dominokit_domino_api_client_request_Success(success) {
  }
  
  /**
   * @template C_S
   * @param {?function(Success<C_S>):CanFailOrSend} fn
   * @return {Response<C_S>}
   * @public
   */
  static $adapt(fn) {
    Response.$clinit();
    return /**@type {!$LambdaAdaptor<ResponseBean>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Response = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_Response;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Response;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Response.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.Response.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Response, $Util.$makeClassName('org.dominokit.domino.api.client.request.Response'));


Response.$markImplementor(/** @type {Function} */ (Response));


exports = Response; 
//# sourceMappingURL=Response.js.map