/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$ContextAggregatorBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.ContextAggregatorBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _CanWaitForContext = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.CanWaitForContext');
const _LinkedHashSet = goog.require('java.util.LinkedHashSet');
const _Set = goog.require('java.util.Set');
const _ContextAggregator = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator');
const _ContextWait = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait');
const _ReadyHandler = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler');


// Re-exports the implementation.
var ContextAggregatorBuilder = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ContextAggregatorBuilder$impl');
exports = ContextAggregatorBuilder;
 