/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.CompositeView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.CompositeView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');


/**
 * @interface
 * @template C_V
 * @extends {View}
 */
class CompositeView {
  /**
   * @abstract
   * @param {?string} classifier
   * @return {C_V}
   * @public
   */
  m_getView__java_lang_String(classifier) {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_defaultViewClassifier__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_CompositeView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_CompositeView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_CompositeView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CompositeView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(CompositeView, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.CompositeView'));


CompositeView.$markImplementor(/** @type {Function} */ (CompositeView));


exports = CompositeView; 
//# sourceMappingURL=CompositeView.js.map