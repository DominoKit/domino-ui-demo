/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ServiceRootMatcher.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ServiceRootMatcher');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Predicate = goog.require('java.util.function.Predicate');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _DynamicServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot');
const _HasServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot');
const _PathMatcher = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ServiceRootMatcher = goog.require('org.dominokit.domino.api.client.ServiceRootMatcher$impl');
exports = ServiceRootMatcher;
 