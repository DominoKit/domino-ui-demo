/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestState.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.RequestState');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.request.RequestState.$LambdaAdaptor');
const _RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext');


// Re-exports the implementation.
var RequestState = goog.require('org.dominokit.domino.api.client.request.RequestState$impl');
exports = RequestState;
 