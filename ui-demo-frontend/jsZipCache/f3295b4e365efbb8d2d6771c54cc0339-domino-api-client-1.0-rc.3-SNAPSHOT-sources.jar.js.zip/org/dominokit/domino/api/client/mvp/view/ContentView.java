package org.dominokit.domino.api.client.mvp.view;

public interface ContentView extends View, HasContent {
}
