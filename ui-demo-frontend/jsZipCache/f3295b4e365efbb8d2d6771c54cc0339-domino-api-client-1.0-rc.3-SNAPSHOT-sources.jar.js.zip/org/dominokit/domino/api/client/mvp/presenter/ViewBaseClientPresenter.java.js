/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _DominoView = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView');
const _RemovedHandler = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler');
const _RevealedHandler = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');
exports = ViewBaseClientPresenter;
 