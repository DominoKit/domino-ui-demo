/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.ListenTo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.ListenTo$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class ListenTo {
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_event__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_ListenTo = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_ListenTo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_ListenTo;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListenTo.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ListenTo, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.ListenTo'));


ListenTo.$markImplementor(/** @type {Function} */ (ListenTo));


exports = ListenTo; 
//# sourceMappingURL=ListenTo.js.map