/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasAsyncRunner$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasAsyncRunner = goog.require('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner$impl');

let HasOptions = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasOptions$impl');
let MainDominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');


/**
 * @implements {HasAsyncRunner}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(MainDominoEvent):HasOptions} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(MainDominoEvent):HasOptions} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(MainDominoEvent):HasOptions} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {MainDominoEvent} arg0
   * @return {HasOptions}
   * @public
   */
  m_mainExtensionPoint__org_dominokit_domino_api_shared_extension_MainDominoEvent(arg0) {
    let /** ?function(MainDominoEvent):HasOptions */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasAsyncRunner_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasAsyncRunner$$LambdaAdaptor'));


HasAsyncRunner.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasAsyncRunner$$LambdaAdaptor.js.map