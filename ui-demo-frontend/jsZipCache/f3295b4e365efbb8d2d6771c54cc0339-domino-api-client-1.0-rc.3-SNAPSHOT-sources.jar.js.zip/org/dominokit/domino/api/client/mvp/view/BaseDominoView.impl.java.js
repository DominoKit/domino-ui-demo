/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.BaseDominoView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.BaseDominoView$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoView = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView$impl');
const HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent$impl');

let Objects = goog.forwardDeclare('java.util.Objects$impl');
let RemovedHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler$impl');
let RevealedHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_T
 * @implements {DominoView<C_T>}
 * @implements {HasContent}
  */
class BaseDominoView extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_initialized__org_dominokit_domino_api_client_mvp_view_BaseDominoView_ = false;
    /** @public {RevealedHandler} */
    this.f_revealHandler__org_dominokit_domino_api_client_mvp_view_BaseDominoView;
    /** @public {RemovedHandler} */
    this.f_removeHandler__org_dominokit_domino_api_client_mvp_view_BaseDominoView;
    /** @public {C_T} */
    this.f_root__org_dominokit_domino_api_client_mvp_view_BaseDominoView;
  }
  
  /**
   * Initialization from constructor 'BaseDominoView()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_view_BaseDominoView__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_api_client_mvp_view_BaseDominoView();
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isInitialized__() {
    return this.f_initialized__org_dominokit_domino_api_client_mvp_view_BaseDominoView_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSingleton__() {
    return false;
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    return this.m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(null);
  }
  
  /**
   * @override
   * @param {CreateHandler} createHandler
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(createHandler) {
    if (!this.f_initialized__org_dominokit_domino_api_client_mvp_view_BaseDominoView_ || !this.m_isSingleton__()) {
      this.f_root__org_dominokit_domino_api_client_mvp_view_BaseDominoView = this.m_createRoot__();
      this.m_initRoot__java_lang_Object(this.f_root__org_dominokit_domino_api_client_mvp_view_BaseDominoView);
      this.m_init__java_lang_Object(this.f_root__org_dominokit_domino_api_client_mvp_view_BaseDominoView);
      if (Objects.m_nonNull__java_lang_Object(createHandler)) {
        createHandler.m_onCreated__();
      }
      this.f_initialized__org_dominokit_domino_api_client_mvp_view_BaseDominoView_ = true;
    }
    return /**@type {Content<C_T>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_root__org_dominokit_domino_api_client_mvp_view_BaseDominoView;
    })), Content));
  }
  
  /**
   * @abstract
   * @param {C_T} root
   * @return {void}
   * @public
   */
  m_initRoot__java_lang_Object(root) {
  }
  
  /**
   * @abstract
   * @param {C_T} root
   * @return {void}
   * @public
   */
  m_init__java_lang_Object(root) {
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @override
   * @param {RevealedHandler} revealHandler
   * @return {void}
   * @public
   */
  m_setRevealHandler__org_dominokit_domino_api_client_mvp_view_DominoView_RevealedHandler(revealHandler) {
    this.f_revealHandler__org_dominokit_domino_api_client_mvp_view_BaseDominoView = revealHandler;
  }
  
  /**
   * @override
   * @param {RemovedHandler} removeHandler
   * @return {void}
   * @public
   */
  m_setRemoveHandler__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler(removeHandler) {
    this.f_removeHandler__org_dominokit_domino_api_client_mvp_view_BaseDominoView = removeHandler;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_mvp_view_BaseDominoView() {
    this.f_initialized__org_dominokit_domino_api_client_mvp_view_BaseDominoView_ = false;
  }
  
  /**
   * @abstract
   * @override
   * @return {C_T}
   * @public
   */
  m_createRoot__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseDominoView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseDominoView);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseDominoView.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    Content = goog.module.get('org.dominokit.domino.api.shared.extension.Content$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    DominoView.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseDominoView, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.BaseDominoView'));


DominoView.$markImplementor(BaseDominoView);
HasContent.$markImplementor(BaseDominoView);


exports = BaseDominoView; 
//# sourceMappingURL=BaseDominoView.js.map