/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _Class = goog.require('java.lang.Class');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _CanSetDominoOptions = goog.require('org.dominokit.domino.api.client.CanSetDominoOptions');
const _AttributeHolder = goog.require('org.dominokit.domino.api.client.ClientApp.AttributeHolder');
const _DominoOptionsHandler = goog.require('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler');
const _ClientStartupTask = goog.require('org.dominokit.domino.api.client.ClientStartupTask');
const _DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _AsyncRunner = goog.require('org.dominokit.domino.api.client.async.AsyncRunner');
const _AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');
const _EventsBus = goog.require('org.dominokit.domino.api.client.events.EventsBus');
const _DominoEventsListenersRepository = goog.require('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _PresentersRepository = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _ViewsRepository = goog.require('org.dominokit.domino.api.client.mvp.view.ViewsRepository');
const _CommandsRepository = goog.require('org.dominokit.domino.api.client.request.CommandsRepository');
const _LazyRequestRestSenderLoader = goog.require('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _RequestHolder = goog.require('org.dominokit.domino.api.client.request.RequestHolder');
const _RequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository');
const _RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _MainDominoEvent = goog.require('org.dominokit.domino.api.shared.extension.MainDominoEvent');
const _AppHistory = goog.require('org.dominokit.domino.api.shared.history.AppHistory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp$impl');
exports = ClientApp;
 