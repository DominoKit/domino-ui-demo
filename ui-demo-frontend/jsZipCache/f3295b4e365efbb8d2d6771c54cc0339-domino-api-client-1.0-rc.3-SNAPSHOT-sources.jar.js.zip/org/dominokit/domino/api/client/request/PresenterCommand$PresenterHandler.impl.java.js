/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.PresenterCommand$PresenterHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_PresenterHandler_P
 */
class PresenterHandler {
  /**
   * @abstract
   * @param {C_PresenterHandler_P} presenter
   * @return {void}
   * @public
   */
  m_onReady__java_lang_Object(presenter) {
  }
  
  /**
   * @template C_PresenterHandler_P
   * @param {?function(C_PresenterHandler_P):void} fn
   * @return {PresenterHandler<C_PresenterHandler_P>}
   * @public
   */
  static $adapt(fn) {
    PresenterHandler.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PresenterHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(PresenterHandler, $Util.$makeClassName('org.dominokit.domino.api.client.request.PresenterCommand$PresenterHandler'));


PresenterHandler.$markImplementor(/** @type {Function} */ (PresenterHandler));


exports = PresenterHandler; 
//# sourceMappingURL=PresenterCommand$PresenterHandler.js.map