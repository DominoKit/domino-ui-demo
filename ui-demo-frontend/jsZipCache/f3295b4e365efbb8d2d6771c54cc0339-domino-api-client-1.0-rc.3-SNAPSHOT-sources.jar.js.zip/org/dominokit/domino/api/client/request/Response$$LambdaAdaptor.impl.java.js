/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Response$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Response.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Response = goog.require('org.dominokit.domino.api.client.request.Response$impl');

let CanFailOrSend = goog.forwardDeclare('org.dominokit.domino.api.client.request.CanFailOrSend$impl');
let Success = goog.forwardDeclare('org.dominokit.domino.api.client.request.Success$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @template C_S
 * @implements {Response<C_S>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(Success<C_S>):CanFailOrSend} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(Success<C_S>):CanFailOrSend} */
    this.f_$$fn__org_dominokit_domino_api_client_request_Response_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_Response_$LambdaAdaptor__org_dominokit_domino_api_client_request_Response_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(Success<C_S>):CanFailOrSend} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Response_$LambdaAdaptor__org_dominokit_domino_api_client_request_Response_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_Response_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {Success<C_S>} arg0
   * @return {CanFailOrSend}
   * @public
   */
  m_onSuccess__org_dominokit_domino_api_client_request_Success(arg0) {
    let /** ?function(Success<C_S>):CanFailOrSend */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_request_Response_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.Response$$LambdaAdaptor'));


Response.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Response$$LambdaAdaptor.js.map