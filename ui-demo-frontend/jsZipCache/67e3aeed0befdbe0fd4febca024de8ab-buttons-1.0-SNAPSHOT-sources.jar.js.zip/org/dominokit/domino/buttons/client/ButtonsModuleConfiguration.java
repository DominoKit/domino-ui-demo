package org.dominokit.domino.buttons.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.buttons.client.contributions.ButtonsPresenterContributionToComponentsExtensionPoint;
import org.dominokit.domino.buttons.client.presenters.ButtonsPresenter;
import org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand;
import org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ButtonsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(ButtonsPresenter.class.getCanonicalName(), ButtonsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new ButtonsPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(ButtonsPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new ButtonsViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(ButtonsPresenterCommand.class.getCanonicalName(), ButtonsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentsExtensionPoint.class, new ButtonsPresenterContributionToComponentsExtensionPoint());
  }
}
