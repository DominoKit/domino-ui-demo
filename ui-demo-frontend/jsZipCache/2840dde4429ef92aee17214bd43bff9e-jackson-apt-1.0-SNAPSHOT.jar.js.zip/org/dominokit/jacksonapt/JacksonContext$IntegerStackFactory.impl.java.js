/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$IntegerStackFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory.$LambdaAdaptor$impl');
let Stack = goog.forwardDeclare('org.dominokit.jacksonapt.stream.Stack$impl');


/**
 * @interface
 */
class IntegerStackFactory {
  /**
   * @abstract
   * @return {Stack<Integer>}
   * @public
   */
  m_make__() {
  }
  
  /**
   * @param {?function():Stack<Integer>} fn
   * @return {IntegerStackFactory}
   * @public
   */
  static $adapt(fn) {
    IntegerStackFactory.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_IntegerStackFactory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_IntegerStackFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_IntegerStackFactory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IntegerStackFactory.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(IntegerStackFactory, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$IntegerStackFactory'));


IntegerStackFactory.$markImplementor(/** @type {Function} */ (IntegerStackFactory));


exports = IntegerStackFactory; 
//# sourceMappingURL=JacksonContext$IntegerStackFactory.js.map