/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContextProvider.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContextProvider$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Objects = goog.forwardDeclare('java.util.Objects$impl');
let JacksonContext = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext$impl');
let ServerJacksonContext = goog.forwardDeclare('org.dominokit.jacksonapt.ServerJacksonContext$impl');


class JacksonContextProvider extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'JacksonContextProvider()'.
   * @return {!JacksonContextProvider}
   * @public
   */
  static $create__() {
    JacksonContextProvider.$clinit();
    let $instance = new JacksonContextProvider();
    $instance.$ctor__org_dominokit_jacksonapt_JacksonContextProvider__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JacksonContextProvider()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_JacksonContextProvider__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {JacksonContext}
   * @public
   */
  static m_get__() {
    JacksonContextProvider.$clinit();
    if (Objects.m_isNull__java_lang_Object(JacksonContextProvider.$f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider)) {
      JacksonContextProvider.m_initContext___$p_org_dominokit_jacksonapt_JacksonContextProvider();
    }
    return JacksonContextProvider.$f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider;
  }
  
  /**
   * @return {void}
   * @public
   */
  static m_initContext___$p_org_dominokit_jacksonapt_JacksonContextProvider() {
    JacksonContextProvider.$clinit();
    JacksonContextProvider.$f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider = ServerJacksonContext.$create__();
  }
  
  /**
   * @return {JacksonContext}
   * @public
   */
  static get f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider() {
    return (JacksonContextProvider.$clinit(), JacksonContextProvider.$f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider);
  }
  
  /**
   * @param {JacksonContext} value
   * @return {void}
   * @public
   */
  static set f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider(value) {
    (JacksonContextProvider.$clinit(), JacksonContextProvider.$f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JacksonContextProvider;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JacksonContextProvider);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JacksonContextProvider.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    ServerJacksonContext = goog.module.get('org.dominokit.jacksonapt.ServerJacksonContext$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JacksonContextProvider, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContextProvider'));


/** @private {JacksonContext} */
JacksonContextProvider.$f_jacksonContext__org_dominokit_jacksonapt_JacksonContextProvider;




exports = JacksonContextProvider; 
//# sourceMappingURL=JacksonContextProvider.js.map