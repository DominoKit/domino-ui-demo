/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$DoubleArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader.$LambdaAdaptor$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 */
class DoubleArrayReader {
  /**
   * @abstract
   * @param {JsonReader} reader
   * @return {Array<number>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
  }
  
  /**
   * @param {?function(JsonReader):Array<number>} fn
   * @return {DoubleArrayReader}
   * @public
   */
  static $adapt(fn) {
    DoubleArrayReader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_DoubleArrayReader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_DoubleArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_DoubleArrayReader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DoubleArrayReader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DoubleArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$DoubleArrayReader'));


DoubleArrayReader.$markImplementor(/** @type {Function} */ (DoubleArrayReader));


exports = DoubleArrayReader; 
//# sourceMappingURL=JacksonContext$DoubleArrayReader.js.map