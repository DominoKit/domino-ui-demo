/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$DoubleArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader.$LambdaAdaptor');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var DoubleArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader$impl');
exports = DoubleArrayReader;
 