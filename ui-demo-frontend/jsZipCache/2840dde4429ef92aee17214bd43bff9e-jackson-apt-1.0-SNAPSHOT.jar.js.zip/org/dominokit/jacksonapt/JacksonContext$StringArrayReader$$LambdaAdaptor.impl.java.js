/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$StringArrayReader$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.StringArrayReader.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const StringArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.StringArrayReader$impl');

let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @implements {StringArrayReader}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(JsonReader):Array<?string>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(JsonReader):Array<?string>} */
    this.f_$$fn__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$LambdaAdaptor__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(JsonReader):Array<?string>} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$LambdaAdaptor__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {JsonReader} arg0
   * @return {Array<?string>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(arg0) {
    let /** ?function(JsonReader):Array<?string> */ $function;
    return ($function = this.f_$$fn__org_dominokit_jacksonapt_JacksonContext_StringArrayReader_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$StringArrayReader$$LambdaAdaptor'));


StringArrayReader.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=JacksonContext$StringArrayReader$$LambdaAdaptor.js.map