/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonSerializationContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonSerializationContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext$impl');

let ObjectIdGenerator = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator$impl');
let RuntimeException = goog.forwardDeclare('java.lang.RuntimeException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let StringBuilder = goog.forwardDeclare('java.lang.StringBuilder$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let IdentityHashMap = goog.forwardDeclare('java.util.IdentityHashMap$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Level = goog.forwardDeclare('java.util.logging.Level$impl');
let Logger = goog.forwardDeclare('java.util.logging.Logger$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Builder = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder$impl');
let DefaultBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonSerializationContext.DefaultBuilder$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializerParameters$impl');
let JsonSerializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonSerializationException$impl');
let ObjectIdSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.ObjectIdSerializer$impl');
let JsonWriter = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonWriter$impl');
let FastJsonWriter = goog.forwardDeclare('org.dominokit.jacksonapt.stream.impl.FastJsonWriter$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {JsonSerializationContext}
  */
class DefaultJsonSerializationContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<*, ObjectIdSerializer<?>>} */
    this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
    /** @public {List<ObjectIdGenerator<?>>} */
    this.f_generators__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
    /** @public {boolean} */
    this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
    /** @public {boolean} */
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = false;
  }
  
  /**
   * @return {Builder}
   * @public
   */
  static m_builder__() {
    DefaultJsonSerializationContext.$clinit();
    return DefaultBuilder.$create__();
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultJsonSerializationContext(boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean)'.
   * @param {boolean} useEqualityForObjectId
   * @param {boolean} serializeNulls
   * @param {boolean} writeDatesAsTimestamps
   * @param {boolean} writeDateKeysAsTimestamps
   * @param {boolean} indent
   * @param {boolean} wrapRootValue
   * @param {boolean} writeCharArraysAsJsonArrays
   * @param {boolean} writeNullMapValues
   * @param {boolean} writeEmptyJsonArrays
   * @param {boolean} orderMapEntriesByKeys
   * @param {boolean} writeSingleElemArraysUnwrapped
   * @param {boolean} wrapExceptions
   * @return {!DefaultJsonSerializationContext}
   * @public
   */
  static $create__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean(useEqualityForObjectId, serializeNulls, writeDatesAsTimestamps, writeDateKeysAsTimestamps, indent, wrapRootValue, writeCharArraysAsJsonArrays, writeNullMapValues, writeEmptyJsonArrays, orderMapEntriesByKeys, writeSingleElemArraysUnwrapped, wrapExceptions) {
    DefaultJsonSerializationContext.$clinit();
    let $instance = new DefaultJsonSerializationContext();
    $instance.$ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean(useEqualityForObjectId, serializeNulls, writeDatesAsTimestamps, writeDateKeysAsTimestamps, indent, wrapRootValue, writeCharArraysAsJsonArrays, writeNullMapValues, writeEmptyJsonArrays, orderMapEntriesByKeys, writeSingleElemArraysUnwrapped, wrapExceptions);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultJsonSerializationContext(boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean)'.
   * @param {boolean} useEqualityForObjectId
   * @param {boolean} serializeNulls
   * @param {boolean} writeDatesAsTimestamps
   * @param {boolean} writeDateKeysAsTimestamps
   * @param {boolean} indent
   * @param {boolean} wrapRootValue
   * @param {boolean} writeCharArraysAsJsonArrays
   * @param {boolean} writeNullMapValues
   * @param {boolean} writeEmptyJsonArrays
   * @param {boolean} orderMapEntriesByKeys
   * @param {boolean} writeSingleElemArraysUnwrapped
   * @param {boolean} wrapExceptions
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean__boolean(useEqualityForObjectId, serializeNulls, writeDatesAsTimestamps, writeDateKeysAsTimestamps, indent, wrapRootValue, writeCharArraysAsJsonArrays, writeNullMapValues, writeEmptyJsonArrays, orderMapEntriesByKeys, writeSingleElemArraysUnwrapped, wrapExceptions) {
    this.$ctor__java_lang_Object__();
    this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = useEqualityForObjectId;
    this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = serializeNulls;
    this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = writeDatesAsTimestamps;
    this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = writeDateKeysAsTimestamps;
    this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = indent;
    this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = wrapRootValue;
    this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = writeCharArraysAsJsonArrays;
    this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = writeNullMapValues;
    this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = writeEmptyJsonArrays;
    this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = orderMapEntriesByKeys;
    this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = writeSingleElemArraysUnwrapped;
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = wrapExceptions;
  }
  
  /**
   * @override
   * @return {Logger}
   * @public
   */
  m_getLogger__() {
    return DefaultJsonSerializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSerializeNulls__() {
    return this.f_serializeNulls__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWriteDatesAsTimestamps__() {
    return this.f_writeDatesAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWriteDateKeysAsTimestamps__() {
    return this.f_writeDateKeysAsTimestamps__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWrapRootValue__() {
    return this.f_wrapRootValue__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWriteCharArraysAsJsonArrays__() {
    return this.f_writeCharArraysAsJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWriteNullMapValues__() {
    return this.f_writeNullMapValues__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWriteEmptyJsonArrays__() {
    return this.f_writeEmptyJsonArrays__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isOrderMapEntriesByKeys__() {
    return this.f_orderMapEntriesByKeys__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWriteSingleElemArraysUnwrapped__() {
    return this.f_writeSingleElemArraysUnwrapped__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;
  }
  
  /**
   * @override
   * @return {JsonWriter}
   * @public
   */
  m_newJsonWriter__() {
    let writer = FastJsonWriter.$create__java_lang_StringBuilder(StringBuilder.$create__());
    writer.m_setLenient__boolean(true);
    if (this.f_indent__org_dominokit_jacksonapt_DefaultJsonSerializationContext_) {
      writer.m_setIndent__java_lang_String("  ");
    }
    return writer;
  }
  
  /**
   * @override
   * @param {*} value
   * @param {?string} message
   * @return {JsonSerializationException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_String(value, message) {
    this.m_getLogger__().m_log__java_util_logging_Level__java_lang_String(Level.f_SEVERE__java_util_logging_Level, message);
    return JsonSerializationException.$create__java_lang_String(message);
  }
  
  /**
   * @override
   * @param {*} value
   * @param {?string} message
   * @param {JsonWriter} writer
   * @return {JsonSerializationException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_String__org_dominokit_jacksonapt_stream_JsonWriter(value, message, writer) {
    let exception = this.m_traceError__java_lang_Object__java_lang_String(value, message);
    this.m_traceWriterInfo__java_lang_Object__org_dominokit_jacksonapt_stream_JsonWriter_$p_org_dominokit_jacksonapt_DefaultJsonSerializationContext(value, writer);
    return exception;
  }
  
  /**
   * @override
   * @param {*} value
   * @param {RuntimeException} cause
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_RuntimeException(value, cause) {
    this.m_getLogger__().m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable(Level.f_SEVERE__java_util_logging_Level, "Error during serialization", cause);
    if (this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonSerializationContext_) {
      return JsonSerializationException.$create__java_lang_Throwable(cause);
    } else {
      return cause;
    }
  }
  
  /**
   * @override
   * @param {*} value
   * @param {RuntimeException} cause
   * @param {JsonWriter} writer
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_Object__java_lang_RuntimeException__org_dominokit_jacksonapt_stream_JsonWriter(value, cause, writer) {
    let exception = this.m_traceError__java_lang_Object__java_lang_RuntimeException(value, cause);
    this.m_traceWriterInfo__java_lang_Object__org_dominokit_jacksonapt_stream_JsonWriter_$p_org_dominokit_jacksonapt_DefaultJsonSerializationContext(value, writer);
    return exception;
  }
  
  /**
   * @param {*} value
   * @param {JsonWriter} writer
   * @return {void}
   * @public
   */
  m_traceWriterInfo__java_lang_Object__org_dominokit_jacksonapt_stream_JsonWriter_$p_org_dominokit_jacksonapt_DefaultJsonSerializationContext(value, writer) {
    if (this.m_getLogger__().m_isLoggable__java_util_logging_Level(Level.f_INFO__java_util_logging_Level)) {
      this.m_getLogger__().m_log__java_util_logging_Level__java_lang_String(Level.f_INFO__java_util_logging_Level, "Error on value <" + j_l_String.m_valueOf__java_lang_Object(value) + ">. Current output : <" + j_l_String.m_valueOf__java_lang_Object(writer.m_getOutput__()) + ">");
    }
  }
  
  /**
   * @override
   * @param {*} object
   * @param {ObjectIdSerializer<?>} id
   * @return {void}
   * @public
   */
  m_addObjectId__java_lang_Object__org_dominokit_jacksonapt_ser_bean_ObjectIdSerializer(object, id) {
    if ($Equality.$same(null, this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_)) {
      if (this.f_useEqualityForObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_) {
        this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = /**@type {!HashMap<*, ObjectIdSerializer<?>>} */ (HashMap.$create__());
      } else {
        this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = /**@type {!IdentityHashMap<*, ObjectIdSerializer<?>>} */ (IdentityHashMap.$create__());
      }
    }
    this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_.put(object, id);
  }
  
  /**
   * @override
   * @param {*} object
   * @return {ObjectIdSerializer<?>}
   * @public
   */
  m_getObjectId__java_lang_Object(object) {
    if (!$Equality.$same(null, this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_)) {
      return /**@type {ObjectIdSerializer<*>} */ ($Casts.$to(this.f_mapObjectId__org_dominokit_jacksonapt_DefaultJsonSerializationContext_.get(object), ObjectIdSerializer));
    }
    return null;
  }
  
  /**
   * @override
   * @param {ObjectIdGenerator<?>} generator
   * @return {void}
   * @public
   */
  m_addGenerator__com_fasterxml_jackson_annotation_ObjectIdGenerator(generator) {
    if ($Equality.$same(null, this.f_generators__org_dominokit_jacksonapt_DefaultJsonSerializationContext_)) {
      this.f_generators__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = /**@type {!ArrayList<ObjectIdGenerator<?>>} */ (ArrayList.$create__());
    }
    this.f_generators__org_dominokit_jacksonapt_DefaultJsonSerializationContext_.add(generator);
  }
  
  /**
   * @override
   * @template M_T
   * @param {ObjectIdGenerator<M_T>} gen
   * @return {ObjectIdGenerator<M_T>}
   * @public
   */
  m_findObjectIdGenerator__com_fasterxml_jackson_annotation_ObjectIdGenerator(gen) {
    if (!$Equality.$same(null, this.f_generators__org_dominokit_jacksonapt_DefaultJsonSerializationContext_)) {
      for (let $iterator = this.f_generators__org_dominokit_jacksonapt_DefaultJsonSerializationContext_.m_iterator__(); $iterator.m_hasNext__(); ) {
        let generator = /**@type {ObjectIdGenerator<*>} */ ($Casts.$to($iterator.m_next__(), ObjectIdGenerator));
        if (generator.m_canUseFor__com_fasterxml_jackson_annotation_ObjectIdGenerator(gen)) {
          return /**@type {ObjectIdGenerator<*>} */ ($Casts.$to(generator, ObjectIdGenerator));
        }
      }
    }
    return null;
  }
  
  /**
   * @override
   * @return {JsonSerializerParameters}
   * @public
   */
  m_defaultParameters__() {
    return JacksonContextProvider.m_get__().m_defaultSerializerParameters__();
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_() {
    return (DefaultJsonSerializationContext.$clinit(), DefaultJsonSerializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_(value) {
    (DefaultJsonSerializationContext.$clinit(), DefaultJsonSerializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultJsonSerializationContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultJsonSerializationContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultJsonSerializationContext.$clinit = function() {};
    ObjectIdGenerator = goog.module.get('com.fasterxml.jackson.annotation.ObjectIdGenerator$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    StringBuilder = goog.module.get('java.lang.StringBuilder$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    IdentityHashMap = goog.module.get('java.util.IdentityHashMap$impl');
    Level = goog.module.get('java.util.logging.Level$impl');
    Logger = goog.module.get('java.util.logging.Logger$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    DefaultBuilder = goog.module.get('org.dominokit.jacksonapt.DefaultJsonSerializationContext.DefaultBuilder$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    JsonSerializationException = goog.module.get('org.dominokit.jacksonapt.exception.JsonSerializationException$impl');
    ObjectIdSerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.ObjectIdSerializer$impl');
    FastJsonWriter = goog.module.get('org.dominokit.jacksonapt.stream.impl.FastJsonWriter$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    DefaultJsonSerializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_ = Logger.m_getLogger__java_lang_String("JsonSerialization");
  }
  
  
};

$Util.$setClassMetadata(DefaultJsonSerializationContext, $Util.$makeClassName('org.dominokit.jacksonapt.DefaultJsonSerializationContext'));


/** @private {Logger} */
DefaultJsonSerializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonSerializationContext_;


JsonSerializationContext.$markImplementor(DefaultJsonSerializationContext);


exports = DefaultJsonSerializationContext; 
//# sourceMappingURL=DefaultJsonSerializationContext.js.map