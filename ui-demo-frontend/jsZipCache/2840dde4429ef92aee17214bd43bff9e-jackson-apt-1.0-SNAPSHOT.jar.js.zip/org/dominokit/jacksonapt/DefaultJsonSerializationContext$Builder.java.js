/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonSerializationContext$Builder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DefaultJsonSerializationContext = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');


// Re-exports the implementation.
var Builder = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder$impl');
exports = Builder;
 