/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonDeserializationContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonDeserializationContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _Level = goog.require('java.util.logging.Level');
const _Logger = goog.require('java.util.logging.Logger');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Builder = goog.require('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.Builder');
const _DefaultBuilder = goog.require('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.DefaultBuilder');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonDeserializationException = goog.require('org.dominokit.jacksonapt.exception.JsonDeserializationException');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _NonBufferedJsonReader = goog.require('org.dominokit.jacksonapt.stream.impl.NonBufferedJsonReader');


// Re-exports the implementation.
var DefaultJsonDeserializationContext = goog.require('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$impl');
exports = DefaultJsonDeserializationContext;
 