/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.ObjectReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.ObjectReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let ArrayCreator = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator$impl');


/**
 * @interface
 * @template C_T
 */
class ObjectReader {
  /**
   * @abstract
   * @param {?string} input
   * @return {C_T}
   * @public
   */
  m_read__java_lang_String(input) {
  }
  
  /**
   * @abstract
   * @param {?string} input
   * @param {JsonDeserializationContext} ctx
   * @return {C_T}
   * @public
   */
  m_read__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(input, ctx) {
  }
  
  /**
   * @abstract
   * @param {?string} input
   * @param {ArrayCreator<C_T>} arrayCreator
   * @return {Array<C_T>}
   * @public
   */
  m_readArray__java_lang_String__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(input, arrayCreator) {
  }
  
  /**
   * @abstract
   * @param {?string} input
   * @param {JsonDeserializationContext} ctx
   * @param {ArrayCreator<C_T>} arrayCreator
   * @return {Array<C_T>}
   * @public
   */
  m_readArray__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(input, ctx, arrayCreator) {
  }
  
  /**
   * @abstract
   * @return {JsonDeserializer<C_T>}
   * @public
   */
  m_getDeserializer__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_ObjectReader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_ObjectReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_ObjectReader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ObjectReader.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ObjectReader, $Util.$makeClassName('org.dominokit.jacksonapt.ObjectReader'));


ObjectReader.$markImplementor(/** @type {Function} */ (ObjectReader));


exports = ObjectReader; 
//# sourceMappingURL=ObjectReader.js.map