/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonSerializationContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonSerializationContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _ObjectIdGenerator = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator');
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _ArrayList = goog.require('java.util.ArrayList');
const _HashMap = goog.require('java.util.HashMap');
const _IdentityHashMap = goog.require('java.util.IdentityHashMap');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _Level = goog.require('java.util.logging.Level');
const _Logger = goog.require('java.util.logging.Logger');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Builder = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder');
const _DefaultBuilder = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext.DefaultBuilder');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters');
const _JsonSerializationException = goog.require('org.dominokit.jacksonapt.exception.JsonSerializationException');
const _ObjectIdSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.ObjectIdSerializer');
const _JsonWriter = goog.require('org.dominokit.jacksonapt.stream.JsonWriter');
const _FastJsonWriter = goog.require('org.dominokit.jacksonapt.stream.impl.FastJsonWriter');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DefaultJsonSerializationContext = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext$impl');
exports = DefaultJsonSerializationContext;
 