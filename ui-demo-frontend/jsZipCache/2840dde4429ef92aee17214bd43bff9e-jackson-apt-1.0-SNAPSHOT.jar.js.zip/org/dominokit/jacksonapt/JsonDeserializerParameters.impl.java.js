/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonDeserializerParameters.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Shape = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');


/**
 * @interface
 */
class JsonDeserializerParameters {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getPattern__() {
  }
  
  /**
   * @abstract
   * @param {?string} pattern
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setPattern__java_lang_String(pattern) {
  }
  
  /**
   * @abstract
   * @return {Shape}
   * @public
   */
  m_getShape__() {
  }
  
  /**
   * @abstract
   * @param {Shape} shape
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setShape__com_fasterxml_jackson_annotation_JsonFormat_Shape(shape) {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getLocale__() {
  }
  
  /**
   * @abstract
   * @param {?string} locale
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setLocale__java_lang_String(locale) {
  }
  
  /**
   * @abstract
   * @return {Set<?string>}
   * @public
   */
  m_getIgnoredProperties__() {
  }
  
  /**
   * @abstract
   * @param {?string} ignoredProperty
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_addIgnoredProperty__java_lang_String(ignoredProperty) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isIgnoreUnknown__() {
  }
  
  /**
   * @abstract
   * @param {boolean} ignoreUnknown
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setIgnoreUnknown__boolean(ignoreUnknown) {
  }
  
  /**
   * @abstract
   * @return {IdentityDeserializationInfo}
   * @public
   */
  m_getIdentityInfo__() {
  }
  
  /**
   * @abstract
   * @param {IdentityDeserializationInfo} identityInfo
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setIdentityInfo__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo(identityInfo) {
  }
  
  /**
   * @abstract
   * @return {TypeDeserializationInfo}
   * @public
   */
  m_getTypeInfo__() {
  }
  
  /**
   * @abstract
   * @param {TypeDeserializationInfo} typeInfo
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_setTypeInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo(typeInfo) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonDeserializerParameters = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JsonDeserializerParameters;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JsonDeserializerParameters;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonDeserializerParameters.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonDeserializerParameters, $Util.$makeClassName('org.dominokit.jacksonapt.JsonDeserializerParameters'));


JsonDeserializerParameters.$markImplementor(/** @type {Function} */ (JsonDeserializerParameters));


exports = JsonDeserializerParameters; 
//# sourceMappingURL=JsonDeserializerParameters.js.map