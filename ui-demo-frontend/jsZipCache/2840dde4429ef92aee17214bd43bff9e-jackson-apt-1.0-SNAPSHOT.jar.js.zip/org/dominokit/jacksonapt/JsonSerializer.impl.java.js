/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonSerializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonSerializer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Include = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializerParameters$impl');
let JsonWriter = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonWriter$impl');


/**
 * @abstract
 * @template C_T
  */
class JsonSerializer extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'JsonSerializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_JsonSerializer__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {JsonWriter} writer
   * @param {C_T} value
   * @param {JsonSerializationContext} ctx
   * @return {void}
   * @public
   */
  m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(writer, value, ctx) {
    this.m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, ctx.m_defaultParameters__());
  }
  
  /**
   * @param {JsonWriter} writer
   * @param {C_T} value
   * @param {JsonSerializationContext} ctx
   * @param {JsonSerializerParameters} params
   * @return {void}
   * @public
   */
  m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params) {
    this.m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters__boolean(writer, value, ctx, params, false);
  }
  
  /**
   * @param {JsonWriter} writer
   * @param {C_T} value
   * @param {JsonSerializationContext} ctx
   * @param {JsonSerializerParameters} params
   * @param {boolean} isMapValue
   * @return {void}
   * @public
   */
  m_serialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters__boolean(writer, value, ctx, params, isMapValue) {
    if (!$Equality.$same(null, params.m_getInclude__()) && !isMapValue) {
      switch (params.m_getInclude__().ordinal()) {
        case Include.$ordinal$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include: 
          if ($Equality.$same(null, value)) {
            this.m_serializeNullValue__org_dominokit_jacksonapt_stream_JsonWriter__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, ctx, params);
          } else {
            this.m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params);
          }
          return;
        case Include.$ordinal$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include: 
          if (this.m_isDefault__java_lang_Object(value)) {
            writer.m_cancelName__();
          } else {
            this.m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params);
          }
          return;
        case Include.$ordinal$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include: 
          if (this.m_isEmpty__java_lang_Object(value)) {
            writer.m_cancelName__();
          } else {
            this.m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params);
          }
          return;
        case Include.$ordinal$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include: 
          if ($Equality.$same(null, value)) {
            writer.m_cancelName__();
          } else {
            this.m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params);
          }
          return;
        case Include.$ordinal$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include: 
          if (this.m_isAbsent__java_lang_Object(value)) {
            writer.m_cancelName__();
          } else {
            this.m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params);
          }
          return;
      }
    }
    if ($Equality.$same(null, value)) {
      if (ctx.m_isSerializeNulls__() || (isMapValue && ctx.m_isWriteNullMapValues__())) {
        this.m_serializeNullValue__org_dominokit_jacksonapt_stream_JsonWriter__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, ctx, params);
      } else {
        writer.m_cancelName__();
      }
    } else {
      this.m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params);
    }
  }
  
  /**
   * @param {JsonWriter} writer
   * @param {JsonSerializationContext} ctx
   * @param {JsonSerializerParameters} params
   * @return {void}
   * @public
   */
  m_serializeNullValue__org_dominokit_jacksonapt_stream_JsonWriter__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, ctx, params) {
    writer.m_nullValue__();
  }
  
  /**
   * @param {C_T} value
   * @return {boolean}
   * @public
   */
  m_isDefault__java_lang_Object(value) {
    return this.m_isEmpty__java_lang_Object(value);
  }
  
  /**
   * @param {C_T} value
   * @return {boolean}
   * @public
   */
  m_isEmpty__java_lang_Object(value) {
    return $Equality.$same(null, value);
  }
  
  /**
   * @param {C_T} value
   * @return {boolean}
   * @public
   */
  m_isAbsent__java_lang_Object(value) {
    return $Equality.$same(null, value);
  }
  
  /**
   * @abstract
   * @param {JsonWriter} writer
   * @param {C_T} value
   * @param {JsonSerializationContext} ctx
   * @param {JsonSerializerParameters} params
   * @return {void}
   * @public
   */
  m_doSerialize__org_dominokit_jacksonapt_stream_JsonWriter__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext__org_dominokit_jacksonapt_JsonSerializerParameters(writer, value, ctx, params) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsonSerializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsonSerializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonSerializer.$clinit = function() {};
    Include = goog.module.get('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsonSerializer, $Util.$makeClassName('org.dominokit.jacksonapt.JsonSerializer'));




exports = JsonSerializer; 
//# sourceMappingURL=JsonSerializer.js.map