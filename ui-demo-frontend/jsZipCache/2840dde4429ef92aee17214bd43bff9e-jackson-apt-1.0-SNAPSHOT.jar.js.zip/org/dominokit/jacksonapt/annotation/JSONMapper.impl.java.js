/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.annotation.JSONMapper.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.annotation.JSONMapper$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.annotation.JSONMapper.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JSONMapper {
  /**
   * @param {?function():Class<?>} fn
   * @return {JSONMapper}
   * @public
   */
  static $adapt(fn) {
    JSONMapper.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONMapper = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_annotation_JSONMapper;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONMapper;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JSONMapper.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.annotation.JSONMapper.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JSONMapper, $Util.$makeClassName('org.dominokit.jacksonapt.annotation.JSONMapper'));


JSONMapper.$markImplementor(/** @type {Function} */ (JSONMapper));


exports = JSONMapper; 
//# sourceMappingURL=JSONMapper.js.map