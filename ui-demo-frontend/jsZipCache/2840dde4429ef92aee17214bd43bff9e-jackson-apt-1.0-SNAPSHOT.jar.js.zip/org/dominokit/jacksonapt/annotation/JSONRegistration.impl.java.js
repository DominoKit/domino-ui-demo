/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.annotation.JSONRegistration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.annotation.JSONRegistration$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JSONRegistration {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONRegistration = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_annotation_JSONRegistration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONRegistration;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JSONRegistration.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JSONRegistration, $Util.$makeClassName('org.dominokit.jacksonapt.annotation.JSONRegistration'));


JSONRegistration.$markImplementor(/** @type {Function} */ (JSONRegistration));


exports = JSONRegistration; 
//# sourceMappingURL=JSONRegistration.js.map