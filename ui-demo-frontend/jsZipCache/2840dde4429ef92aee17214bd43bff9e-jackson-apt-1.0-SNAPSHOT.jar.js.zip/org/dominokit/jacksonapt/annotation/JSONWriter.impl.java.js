/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.annotation.JSONWriter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.annotation.JSONWriter$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.annotation.JSONWriter.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JSONWriter {
  /**
   * @param {?function():Class<?>} fn
   * @return {JSONWriter}
   * @public
   */
  static $adapt(fn) {
    JSONWriter.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONWriter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_annotation_JSONWriter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_annotation_JSONWriter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JSONWriter.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.annotation.JSONWriter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JSONWriter, $Util.$makeClassName('org.dominokit.jacksonapt.annotation.JSONWriter'));


JSONWriter.$markImplementor(/** @type {Function} */ (JSONWriter));


exports = JSONWriter; 
//# sourceMappingURL=JSONWriter.js.map