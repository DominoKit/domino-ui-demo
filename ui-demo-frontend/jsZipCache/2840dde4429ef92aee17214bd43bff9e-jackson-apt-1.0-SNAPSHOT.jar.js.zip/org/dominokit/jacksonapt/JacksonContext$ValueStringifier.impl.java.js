/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$ValueStringifier.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.ValueStringifier$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.ValueStringifier.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ValueStringifier {
  /**
   * @abstract
   * @param {?string} value
   * @return {?string}
   * @public
   */
  m_stringify__java_lang_String(value) {
  }
  
  /**
   * @param {?function(?string):?string} fn
   * @return {ValueStringifier}
   * @public
   */
  static $adapt(fn) {
    ValueStringifier.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_ValueStringifier = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_ValueStringifier;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_ValueStringifier;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ValueStringifier.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.ValueStringifier.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ValueStringifier, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$ValueStringifier'));


ValueStringifier.$markImplementor(/** @type {Function} */ (ValueStringifier));


exports = ValueStringifier; 
//# sourceMappingURL=JacksonContext$ValueStringifier.js.map