/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonSerializerParameters.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JsonSerializerParameters');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Shape = goog.require('com.fasterxml.jackson.annotation.JsonFormat.Shape');
const _Include = goog.require('com.fasterxml.jackson.annotation.JsonInclude.Include');
const _Set = goog.require('java.util.Set');
const _IdentitySerializationInfo = goog.require('org.dominokit.jacksonapt.ser.bean.IdentitySerializationInfo');
const _TypeSerializationInfo = goog.require('org.dominokit.jacksonapt.ser.bean.TypeSerializationInfo');


// Re-exports the implementation.
var JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters$impl');
exports = JsonSerializerParameters;
 