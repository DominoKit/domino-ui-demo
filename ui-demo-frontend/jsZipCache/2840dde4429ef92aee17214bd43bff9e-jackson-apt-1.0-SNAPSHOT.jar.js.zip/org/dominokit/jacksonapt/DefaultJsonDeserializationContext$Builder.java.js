/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonDeserializationContext$Builder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.Builder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DefaultJsonDeserializationContext = goog.require('org.dominokit.jacksonapt.DefaultJsonDeserializationContext');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');


// Re-exports the implementation.
var Builder = goog.require('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.Builder$impl');
exports = Builder;
 