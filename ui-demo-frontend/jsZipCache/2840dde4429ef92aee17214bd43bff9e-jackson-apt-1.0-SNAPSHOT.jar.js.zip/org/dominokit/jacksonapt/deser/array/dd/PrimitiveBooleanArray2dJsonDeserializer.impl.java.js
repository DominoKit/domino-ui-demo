/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveBooleanArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveBooleanArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let BooleanJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $boolean = goog.forwardDeclare('vmbootstrap.primitives.$boolean$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<boolean>>>}
  */
class PrimitiveBooleanArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveBooleanArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveBooleanArray2dJsonDeserializer.$clinit();
    return PrimitiveBooleanArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveBooleanArray2dJsonDeserializer()'.
   * @return {!PrimitiveBooleanArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveBooleanArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveBooleanArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveBooleanArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<boolean>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<List<?boolean>>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, BooleanJsonDeserializer.m_getInstance__(), params));
    if (list.isEmpty()) {
      return /**@type {!Array<Array<boolean>>} */ ($Arrays.$create([0, 0], $boolean));
    }
    let firstList = /**@type {List<?boolean>} */ ($Casts.$to(list.getAtIndex(0), List));
    if (firstList.isEmpty()) {
      return /**@type {!Array<Array<boolean>>} */ ($Arrays.$create([list.size(), 0], $boolean));
    }
    let array = /**@type {!Array<Array<boolean>>} */ ($Arrays.$create([list.size(), firstList.size()], $boolean));
    let i = 0;
    let /** number */ j;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let innerList = /**@type {List<?boolean>} */ ($Casts.$to($iterator.m_next__(), List));
      j = 0;
      for (let $iterator$1$ = innerList.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
        let value = /**@type {?boolean} */ ($Casts.$to($iterator$1$.m_next__(), Boolean));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(array[i], j, Boolean.m_booleanValue__java_lang_Boolean(value));
        }
        j++;
      }
      i++;
    }
    return array;
  }
  
  /**
   * @return {PrimitiveBooleanArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_() {
    return (PrimitiveBooleanArray2dJsonDeserializer.$clinit(), PrimitiveBooleanArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveBooleanArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_(value) {
    (PrimitiveBooleanArray2dJsonDeserializer.$clinit(), PrimitiveBooleanArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveBooleanArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveBooleanArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveBooleanArray2dJsonDeserializer.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    BooleanJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $boolean = goog.module.get('vmbootstrap.primitives.$boolean$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveBooleanArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_ = PrimitiveBooleanArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveBooleanArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveBooleanArray2dJsonDeserializer'));


/** @private {PrimitiveBooleanArray2dJsonDeserializer} */
PrimitiveBooleanArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveBooleanArray2dJsonDeserializer_;




exports = PrimitiveBooleanArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveBooleanArray2dJsonDeserializer.js.map