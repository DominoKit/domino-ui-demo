/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveDoubleArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveDoubleArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Double = goog.forwardDeclare('java.lang.Double$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let DoubleJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.DoubleJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $double = goog.forwardDeclare('vmbootstrap.primitives.$double$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<number>>>}
  */
class PrimitiveDoubleArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveDoubleArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveDoubleArray2dJsonDeserializer.$clinit();
    return PrimitiveDoubleArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveDoubleArray2dJsonDeserializer()'.
   * @return {!PrimitiveDoubleArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveDoubleArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveDoubleArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveDoubleArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<number>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<List<?number>>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, DoubleJsonDeserializer.m_getInstance__(), params));
    if (list.isEmpty()) {
      return /**@type {!Array<Array<number>>} */ ($Arrays.$create([0, 0], $double));
    }
    let firstList = /**@type {List<?number>} */ ($Casts.$to(list.getAtIndex(0), List));
    if (firstList.isEmpty()) {
      return /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), 0], $double));
    }
    let array = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), firstList.size()], $double));
    let i = 0;
    let /** number */ j;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let innerList = /**@type {List<?number>} */ ($Casts.$to($iterator.m_next__(), List));
      j = 0;
      for (let $iterator$1$ = innerList.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
        let value = /**@type {?number} */ ($Casts.$to($iterator$1$.m_next__(), Double));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(array[i], j, Double.m_doubleValue__java_lang_Double(value));
        }
        j++;
      }
      i++;
    }
    return array;
  }
  
  /**
   * @return {PrimitiveDoubleArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_() {
    return (PrimitiveDoubleArray2dJsonDeserializer.$clinit(), PrimitiveDoubleArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveDoubleArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_(value) {
    (PrimitiveDoubleArray2dJsonDeserializer.$clinit(), PrimitiveDoubleArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveDoubleArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveDoubleArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveDoubleArray2dJsonDeserializer.$clinit = function() {};
    Double = goog.module.get('java.lang.Double$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    DoubleJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.DoubleJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $double = goog.module.get('vmbootstrap.primitives.$double$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveDoubleArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_ = PrimitiveDoubleArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveDoubleArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveDoubleArray2dJsonDeserializer'));


/** @private {PrimitiveDoubleArray2dJsonDeserializer} */
PrimitiveDoubleArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveDoubleArray2dJsonDeserializer_;




exports = PrimitiveDoubleArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveDoubleArray2dJsonDeserializer.js.map