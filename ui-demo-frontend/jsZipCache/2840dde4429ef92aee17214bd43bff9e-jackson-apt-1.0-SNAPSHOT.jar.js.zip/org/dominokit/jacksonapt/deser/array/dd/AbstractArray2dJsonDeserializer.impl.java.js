/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collections = goog.forwardDeclare('java.util.Collections$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');


/**
 * @abstract
 * @template C_T
 * @extends {JsonDeserializer<C_T>}
  */
class AbstractArray2dJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'AbstractArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
  }
  
  /**
   * @template M_C
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializer<M_C>} deserializer
   * @param {JsonDeserializerParameters} params
   * @return {List<List<M_C>>}
   * @public
   */
  m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, deserializer, params) {
    let /** List<List<*>> */ list;
    reader.m_beginArray__();
    let token = reader.m_peek__();
    if ($Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      list = /**@type {List<List<*>>} */ (Collections.m_emptyList__());
    } else {
      list = /**@type {List<List<*>>} */ (this.m_doDeserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_stream_JsonToken(reader, ctx, deserializer, params, token));
    }
    reader.m_endArray__();
    return list;
  }
  
  /**
   * @template M_C
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializer<M_C>} deserializer
   * @param {JsonDeserializerParameters} params
   * @param {JsonToken} token
   * @return {List<List<M_C>>}
   * @public
   */
  m_doDeserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_stream_JsonToken(reader, ctx, deserializer, params, token) {
    let /** List<List<*>> */ list;
    list = /**@type {!ArrayList<List<*>>} */ (ArrayList.$create__());
    let size = -1;
    while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      let /** List<*> */ innerList;
      reader.m_beginArray__();
      let innerToken = reader.m_peek__();
      if ($Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, innerToken)) {
        innerList = /**@type {List<*>} */ (Collections.m_emptyList__());
      } else {
        if (size >= 0) {
          innerList = /**@type {!ArrayList<*>} */ (ArrayList.$create__int(size));
        } else {
          innerList = /**@type {!ArrayList<*>} */ (ArrayList.$create__());
        }
        while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, innerToken)) {
          innerList.add(deserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params));
          innerToken = reader.m_peek__();
        }
        size = innerList.size();
      }
      reader.m_endArray__();
      list.add(innerList);
      token = reader.m_peek__();
    }
    return list;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractArray2dJsonDeserializer.$clinit = function() {};
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Collections = goog.module.get('java.util.Collections$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    JsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer'));




exports = AbstractArray2dJsonDeserializer; 
//# sourceMappingURL=AbstractArray2dJsonDeserializer.js.map