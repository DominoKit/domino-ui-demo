/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IntegerArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader');
const _BaseJsNumberArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.BaseJsNumberArrayReader');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _$Overlay = goog.require('elemental2.core.JsNumber.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var JsIntegerArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader$impl');
exports = JsIntegerArrayReader;
 