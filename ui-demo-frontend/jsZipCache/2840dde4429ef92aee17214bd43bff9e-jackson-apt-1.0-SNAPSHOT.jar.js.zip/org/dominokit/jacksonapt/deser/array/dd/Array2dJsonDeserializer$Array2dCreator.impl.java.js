/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer$Array2dCreator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.Array2dCreator$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.Array2dCreator.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_Array2dCreator_T
 */
class Array2dCreator {
  /**
   * @abstract
   * @param {number} first
   * @param {number} second
   * @return {Array<Array<C_Array2dCreator_T>>}
   * @public
   */
  m_create__int__int(first, second) {
  }
  
  /**
   * @template C_Array2dCreator_T
   * @param {?function(number, number):Array<Array<C_Array2dCreator_T>>} fn
   * @return {Array2dCreator<C_Array2dCreator_T>}
   * @public
   */
  static $adapt(fn) {
    Array2dCreator.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_array_dd_Array2dJsonDeserializer_Array2dCreator;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Array2dCreator.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer.Array2dCreator.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Array2dCreator, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.Array2dJsonDeserializer$Array2dCreator'));


Array2dCreator.$markImplementor(/** @type {Function} */ (Array2dCreator));


exports = Array2dCreator; 
//# sourceMappingURL=Array2dJsonDeserializer$Array2dCreator.js.map