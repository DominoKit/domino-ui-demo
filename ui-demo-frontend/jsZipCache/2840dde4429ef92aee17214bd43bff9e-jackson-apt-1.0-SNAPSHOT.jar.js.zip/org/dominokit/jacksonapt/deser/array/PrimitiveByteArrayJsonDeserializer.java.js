/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveByteArrayJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveByteArrayJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer');
const _Byte = goog.require('java.lang.Byte');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _ByteJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ByteJsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _Base64Utils = goog.require('org.dominokit.jacksonapt.utils.Base64Utils');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$byte = goog.require('vmbootstrap.primitives.$byte');


// Re-exports the implementation.
var PrimitiveByteArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.PrimitiveByteArrayJsonDeserializer$impl');
exports = PrimitiveByteArrayJsonDeserializer;
 