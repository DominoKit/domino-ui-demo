/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _j_l_Object = goog.require('java.lang.Object');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _ArrayCreator = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var ArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$impl');
exports = ArrayJsonDeserializer;
 