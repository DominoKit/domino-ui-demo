/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveByteArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveByteArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Byte = goog.forwardDeclare('java.lang.Byte$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let ByteJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ByteJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let Base64Utils = goog.forwardDeclare('org.dominokit.jacksonapt.utils.Base64Utils$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $byte = goog.forwardDeclare('vmbootstrap.primitives.$byte$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<number>>}
  */
class PrimitiveByteArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveByteArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveByteArrayJsonDeserializer.$clinit();
    return PrimitiveByteArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveByteArrayJsonDeserializer()'.
   * @return {!PrimitiveByteArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveByteArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveByteArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveByteArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<Byte>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, ByteJsonDeserializer.m_getInstance__(), params));
    let result = /**@type {!Array<number>} */ ($Arrays.$create([list.size()], $byte));
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let value = /**@type {Byte} */ ($Casts.$to($iterator.m_next__(), Byte));
      if (!$Equality.$same(null, value)) {
        $Arrays.$set(result, i, value.m_byteValue__());
      }
      i++;
    }
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeNonArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Equality.$same(JsonToken.f_STRING__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return Base64Utils.m_fromBase64__java_lang_String(reader.m_nextString__());
    } else if (ctx.m_isAcceptSingleValueAsArray__()) {
      return this.m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
    } else {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot deserialize a byte[] out of " + j_l_String.m_valueOf__java_lang_Object(reader.m_peek__()) + " token", reader));
    }
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<number>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<number>} */ ($Arrays.$init([/**@type {Byte} */ ($Casts.$to(ByteJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Byte)).m_byteValue__()], $byte));
  }
  
  /**
   * @return {PrimitiveByteArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_() {
    return (PrimitiveByteArrayJsonDeserializer.$clinit(), PrimitiveByteArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveByteArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_(value) {
    (PrimitiveByteArrayJsonDeserializer.$clinit(), PrimitiveByteArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveByteArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveByteArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveByteArrayJsonDeserializer.$clinit = function() {};
    Byte = goog.module.get('java.lang.Byte$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    ByteJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ByteJsonDeserializer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    Base64Utils = goog.module.get('org.dominokit.jacksonapt.utils.Base64Utils$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $byte = goog.module.get('vmbootstrap.primitives.$byte$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveByteArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_ = PrimitiveByteArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveByteArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.PrimitiveByteArrayJsonDeserializer'));


/** @private {PrimitiveByteArrayJsonDeserializer} */
PrimitiveByteArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveByteArrayJsonDeserializer_;




exports = PrimitiveByteArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveByteArrayJsonDeserializer.js.map