/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveBooleanArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveBooleanArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let BooleanJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $boolean = goog.forwardDeclare('vmbootstrap.primitives.$boolean$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<boolean>>}
  */
class PrimitiveBooleanArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveBooleanArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveBooleanArrayJsonDeserializer.$clinit();
    return PrimitiveBooleanArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveBooleanArrayJsonDeserializer()'.
   * @return {!PrimitiveBooleanArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveBooleanArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveBooleanArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveBooleanArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<boolean>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<?boolean>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, BooleanJsonDeserializer.m_getInstance__(), params));
    let result = /**@type {!Array<boolean>} */ ($Arrays.$create([list.size()], $boolean));
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let value = /**@type {?boolean} */ ($Casts.$to($iterator.m_next__(), Boolean));
      if (!$Equality.$same(null, value)) {
        $Arrays.$set(result, i, Boolean.m_booleanValue__java_lang_Boolean(value));
      }
      i++;
    }
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<boolean>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<boolean>} */ ($Arrays.$init([Boolean.m_booleanValue__java_lang_Boolean(/**@type {?boolean} */ ($Casts.$to(BooleanJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Boolean)))], $boolean));
  }
  
  /**
   * @return {PrimitiveBooleanArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_() {
    return (PrimitiveBooleanArrayJsonDeserializer.$clinit(), PrimitiveBooleanArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveBooleanArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_(value) {
    (PrimitiveBooleanArrayJsonDeserializer.$clinit(), PrimitiveBooleanArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveBooleanArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveBooleanArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveBooleanArrayJsonDeserializer.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    BooleanJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $boolean = goog.module.get('vmbootstrap.primitives.$boolean$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveBooleanArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_ = PrimitiveBooleanArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveBooleanArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.PrimitiveBooleanArrayJsonDeserializer'));


/** @private {PrimitiveBooleanArrayJsonDeserializer} */
PrimitiveBooleanArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveBooleanArrayJsonDeserializer_;




exports = PrimitiveBooleanArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveBooleanArrayJsonDeserializer.js.map