/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.StringArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.StringArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<?string>>}
  */
class StringArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {StringArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    StringArrayJsonDeserializer.$clinit();
    return StringArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'StringArrayJsonDeserializer()'.
   * @return {!StringArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    StringArrayJsonDeserializer.$clinit();
    let $instance = new StringArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StringArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<?string>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return JacksonContextProvider.m_get__().m_stringArrayReader__().m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<?string>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<?string>} */ ($Arrays.$init([reader.m_nextString__()], j_l_String));
  }
  
  /**
   * @return {StringArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_() {
    return (StringArrayJsonDeserializer.$clinit(), StringArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_);
  }
  
  /**
   * @param {StringArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_(value) {
    (StringArrayJsonDeserializer.$clinit(), StringArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StringArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StringArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StringArrayJsonDeserializer.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractArrayJsonDeserializer.$clinit();
    StringArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_ = StringArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(StringArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.cast.StringArrayJsonDeserializer'));


/** @private {StringArrayJsonDeserializer} */
StringArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_cast_StringArrayJsonDeserializer_;




exports = StringArrayJsonDeserializer; 
//# sourceMappingURL=StringArrayJsonDeserializer.js.map