/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveShortArray2dJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveShortArray2dJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer');
const _Short = goog.require('java.lang.Short');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _ShortJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ShortJsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$short = goog.require('vmbootstrap.primitives.$short');


// Re-exports the implementation.
var PrimitiveShortArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.PrimitiveShortArray2dJsonDeserializer$impl');
exports = PrimitiveShortArray2dJsonDeserializer;
 