/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const StringArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.StringArrayReader$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.core.JsString.$Overlay$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {StringArrayReader}
  */
class JsStringArrayReader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'JsStringArrayReader()'.
   * @return {!JsStringArrayReader}
   * @public
   */
  static $create__() {
    JsStringArrayReader.$clinit();
    let $instance = new JsStringArrayReader();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_cast_JsStringArrayReader__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JsStringArrayReader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_cast_JsStringArrayReader__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @return {Array<?string>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
    let jsArray = /**@type {!Array<String>} */ (new Array());
    reader.m_beginArray__();
    while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      if ($Equality.$same(JsonToken.f_NULL__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
        reader.m_skipValue__();
        jsArray.push(...$InternalPreconditions.m_checkNotNull__java_lang_Object(null));
      } else {
        jsArray.push(/**@type {String} */ ($Casts.$to(Js.m_cast__java_lang_Object(reader.m_nextString__()), $Overlay)));
      }
    }
    reader.m_endArray__();
    return JsStringArrayReader.m_reinterpretCast__elemental2_core_JsArray_$p_org_dominokit_jacksonapt_deser_array_cast_JsStringArrayReader(jsArray);
  }
  
  /**
   * @param {Array<String>} value
   * @return {Array<?string>}
   * @public
   */
  static m_reinterpretCast__elemental2_core_JsArray_$p_org_dominokit_jacksonapt_deser_array_cast_JsStringArrayReader(value) {
    JsStringArrayReader.$clinit();
    let sliced = /**@type {Array<String>} */ ($Arrays.$castToNative(value.slice()));
    return /**@type {Array<?string>} */ (Js.m_uncheckedCast__java_lang_Object(sliced));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsStringArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsStringArrayReader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsStringArrayReader.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.core.JsString.$Overlay$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsStringArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader'));


StringArrayReader.$markImplementor(JsStringArrayReader);


exports = JsStringArrayReader; 
//# sourceMappingURL=JsStringArrayReader.js.map