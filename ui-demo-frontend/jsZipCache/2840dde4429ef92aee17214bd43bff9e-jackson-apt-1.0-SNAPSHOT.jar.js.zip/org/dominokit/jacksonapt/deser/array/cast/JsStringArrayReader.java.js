/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _StringArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.StringArrayReader');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _$Overlay = goog.require('elemental2.core.JsString.$Overlay');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Js = goog.require('jsinterop.base.Js');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var JsStringArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader$impl');
exports = JsStringArrayReader;
 