/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.dd.PrimitiveByteArray2dJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.dd.PrimitiveByteArray2dJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArray2dJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.dd.AbstractArray2dJsonDeserializer$impl');

let Byte = goog.forwardDeclare('java.lang.Byte$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let ByteJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ByteJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let Base64Utils = goog.forwardDeclare('org.dominokit.jacksonapt.utils.Base64Utils$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $byte = goog.forwardDeclare('vmbootstrap.primitives.$byte$impl');


/**
 * @extends {AbstractArray2dJsonDeserializer<Array<Array<number>>>}
  */
class PrimitiveByteArray2dJsonDeserializer extends AbstractArray2dJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveByteArray2dJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveByteArray2dJsonDeserializer.$clinit();
    return PrimitiveByteArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveByteArray2dJsonDeserializer()'.
   * @return {!PrimitiveByteArray2dJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveByteArray2dJsonDeserializer.$clinit();
    let $instance = new PrimitiveByteArray2dJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveByteArray2dJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_dd_AbstractArray2dJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<Array<number>>}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let /** Array<Array<number>> */ result;
    reader.m_beginArray__();
    let token = reader.m_peek__();
    if ($Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([0, 0], $byte));
    } else if ($Equality.$same(JsonToken.f_STRING__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      let list = /**@type {!ArrayList<Array<number>>} */ (ArrayList.$create__());
      let size = 0;
      while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
        let decoded = Base64Utils.m_fromBase64__java_lang_String(reader.m_nextString__());
        size = Math.max(size, decoded.length);
        list.add(decoded);
        token = reader.m_peek__();
      }
      result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list.size(), size], $byte));
      let i = 0;
      for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
        let value = /**@type {Array<number>} */ ($Arrays.$castTo($iterator.m_next__(), $byte, 1));
        if (!$Equality.$same(null, value)) {
          $Arrays.$set(result, i, value);
        }
        i++;
      }
    } else {
      let list$1$ = /**@type {List<List<Byte>>} */ (this.m_doDeserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_stream_JsonToken(reader, ctx, ByteJsonDeserializer.m_getInstance__(), params, token));
      let firstList = /**@type {List<Byte>} */ ($Casts.$to(list$1$.getAtIndex(0), List));
      if (firstList.isEmpty()) {
        result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list$1$.size(), 0], $byte));
      } else {
        result = /**@type {!Array<Array<number>>} */ ($Arrays.$create([list$1$.size(), firstList.size()], $byte));
        let i$1$ = 0;
        let /** number */ j;
        for (let $iterator$1$ = list$1$.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
          let innerList = /**@type {List<Byte>} */ ($Casts.$to($iterator$1$.m_next__(), List));
          j = 0;
          for (let $iterator$2$ = innerList.m_iterator__(); $iterator$2$.m_hasNext__(); ) {
            let value$1$ = /**@type {Byte} */ ($Casts.$to($iterator$2$.m_next__(), Byte));
            if (!$Equality.$same(null, value$1$)) {
              $Arrays.$set(result[i$1$], j, value$1$.m_byteValue__());
            }
            j++;
          }
          i$1$++;
        }
      }
    }
    reader.m_endArray__();
    return result;
  }
  
  /**
   * @return {PrimitiveByteArray2dJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_() {
    return (PrimitiveByteArray2dJsonDeserializer.$clinit(), PrimitiveByteArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveByteArray2dJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_(value) {
    (PrimitiveByteArray2dJsonDeserializer.$clinit(), PrimitiveByteArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveByteArray2dJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveByteArray2dJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveByteArray2dJsonDeserializer.$clinit = function() {};
    Byte = goog.module.get('java.lang.Byte$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    ByteJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.ByteJsonDeserializer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    Base64Utils = goog.module.get('org.dominokit.jacksonapt.utils.Base64Utils$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $byte = goog.module.get('vmbootstrap.primitives.$byte$impl');
    AbstractArray2dJsonDeserializer.$clinit();
    PrimitiveByteArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_ = PrimitiveByteArray2dJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveByteArray2dJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.dd.PrimitiveByteArray2dJsonDeserializer'));


/** @private {PrimitiveByteArray2dJsonDeserializer} */
PrimitiveByteArray2dJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_dd_PrimitiveByteArray2dJsonDeserializer_;




exports = PrimitiveByteArray2dJsonDeserializer; 
//# sourceMappingURL=PrimitiveByteArray2dJsonDeserializer.js.map