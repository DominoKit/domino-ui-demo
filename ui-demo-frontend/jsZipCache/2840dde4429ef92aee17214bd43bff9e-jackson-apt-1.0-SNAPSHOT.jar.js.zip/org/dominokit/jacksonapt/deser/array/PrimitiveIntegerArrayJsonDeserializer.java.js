/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveIntegerArrayJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveIntegerArrayJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer');
const _Integer = goog.require('java.lang.Integer');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _IntegerJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$int = goog.require('vmbootstrap.primitives.$int');


// Re-exports the implementation.
var PrimitiveIntegerArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.PrimitiveIntegerArrayJsonDeserializer$impl');
exports = PrimitiveIntegerArrayJsonDeserializer;
 