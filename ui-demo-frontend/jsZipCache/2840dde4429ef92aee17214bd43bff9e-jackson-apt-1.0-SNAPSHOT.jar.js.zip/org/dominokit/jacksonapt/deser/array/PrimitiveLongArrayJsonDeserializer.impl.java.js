/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.PrimitiveLongArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.PrimitiveLongArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let Long = goog.forwardDeclare('java.lang.Long$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let LongJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.LongJsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $long = goog.forwardDeclare('vmbootstrap.primitives.$long$impl');


/**
 * @extends {AbstractArrayJsonDeserializer<Array<!$Long>>}
  */
class PrimitiveLongArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {PrimitiveLongArrayJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    PrimitiveLongArrayJsonDeserializer.$clinit();
    return PrimitiveLongArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'PrimitiveLongArrayJsonDeserializer()'.
   * @return {!PrimitiveLongArrayJsonDeserializer}
   * @public
   */
  static $create__() {
    PrimitiveLongArrayJsonDeserializer.$clinit();
    let $instance = new PrimitiveLongArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PrimitiveLongArrayJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<!$Long>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<Long>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, LongJsonDeserializer.m_getInstance__(), params));
    let result = /**@type {!Array<!$Long>} */ ($Arrays.$create([list.size()], $long));
    let i = 0;
    for (let $iterator = list.m_iterator__(); $iterator.m_hasNext__(); ) {
      let value = /**@type {Long} */ ($Casts.$to($iterator.m_next__(), Long));
      if (!$Equality.$same(null, value)) {
        $Arrays.$set(result, i, value.m_longValue__());
      }
      i++;
    }
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<!$Long>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return /**@type {!Array<!$Long>} */ ($Arrays.$init([/**@type {Long} */ ($Casts.$to(LongJsonDeserializer.m_getInstance__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params), Long)).m_longValue__()], $long));
  }
  
  /**
   * @return {PrimitiveLongArrayJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_() {
    return (PrimitiveLongArrayJsonDeserializer.$clinit(), PrimitiveLongArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_);
  }
  
  /**
   * @param {PrimitiveLongArrayJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_(value) {
    (PrimitiveLongArrayJsonDeserializer.$clinit(), PrimitiveLongArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PrimitiveLongArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PrimitiveLongArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PrimitiveLongArrayJsonDeserializer.$clinit = function() {};
    Long = goog.module.get('java.lang.Long$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    LongJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.LongJsonDeserializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $long = goog.module.get('vmbootstrap.primitives.$long$impl');
    AbstractArrayJsonDeserializer.$clinit();
    PrimitiveLongArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_ = PrimitiveLongArrayJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(PrimitiveLongArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.PrimitiveLongArrayJsonDeserializer'));


/** @private {PrimitiveLongArrayJsonDeserializer} */
PrimitiveLongArrayJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_array_PrimitiveLongArrayJsonDeserializer_;




exports = PrimitiveLongArrayJsonDeserializer; 
//# sourceMappingURL=PrimitiveLongArrayJsonDeserializer.js.map