/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractArrayJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.array.AbstractArrayJsonDeserializer$impl');

let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let ArrayCreator = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_T
 * @extends {AbstractArrayJsonDeserializer<Array<C_T>>}
  */
class ArrayJsonDeserializer extends AbstractArrayJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {JsonDeserializer<C_T>} */
    this.f_deserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_;
    /** @public {ArrayCreator<C_T>} */
    this.f_arrayCreator__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_;
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @param {ArrayCreator<M_T>} arrayCreator
   * @return {ArrayJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(deserializer, arrayCreator) {
    ArrayJsonDeserializer.$clinit();
    return /**@type {!ArrayJsonDeserializer<*>} */ (ArrayJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(deserializer, arrayCreator));
  }
  
  /**
   * Factory method corresponding to constructor 'ArrayJsonDeserializer(JsonDeserializer, ArrayCreator)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @param {ArrayCreator<C_T>} arrayCreator
   * @return {!ArrayJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(deserializer, arrayCreator) {
    ArrayJsonDeserializer.$clinit();
    let $instance = new ArrayJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(deserializer, arrayCreator);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ArrayJsonDeserializer(JsonDeserializer, ArrayCreator)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @param {ArrayCreator<C_T>} arrayCreator
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ArrayCreator(deserializer, arrayCreator) {
    this.$ctor__org_dominokit_jacksonapt_deser_array_AbstractArrayJsonDeserializer__();
    if ($Equality.$same(null, deserializer)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("deserializer cannot be null"));
    }
    if ($Equality.$same(null, arrayCreator)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("Cannot deserialize an array without an arrayCreator"));
    }
    this.f_deserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ = deserializer;
    this.f_arrayCreator__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_ = arrayCreator;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<C_T>}
   * @public
   */
  m_doDeserializeArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let list = /**@type {List<C_T>} */ (this.m_deserializeIntoList__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializer__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, this.f_deserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_, params));
    return list.m_toArray__arrayOf_java_lang_Object(this.f_arrayCreator__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_.m_create__int(list.size()));
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Array<C_T>}
   * @public
   */
  m_doDeserializeSingleArray__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let result = this.f_arrayCreator__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_.m_create__int(1);
    $Arrays.$set(result, 0, this.f_deserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params));
    return result;
  }
  
  /**
   * @param {?string} referenceName
   * @param {*} reference
   * @param {Array<C_T>} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__arrayOf_java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    if (!$Equality.$same(null, value) && value.length > 0) {
      for (let $array = value, $index = 0; $index < $array.length; $index++) {
        let val = $array[$index];
        this.f_deserializer__org_dominokit_jacksonapt_deser_array_ArrayJsonDeserializer_.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, val, ctx);
      }
    }
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    this.m_setBackReference__java_lang_String__java_lang_Object__arrayOf_java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {Array<C_T>} */ ($Arrays.$castTo(arg2, j_l_Object, 1)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ArrayJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ArrayJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ArrayJsonDeserializer.$clinit = function() {};
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    AbstractArrayJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ArrayJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer'));




exports = ArrayJsonDeserializer; 
//# sourceMappingURL=ArrayJsonDeserializer.js.map