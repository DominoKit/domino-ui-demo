/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$IntegerJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @extends {BaseNumberJsonDeserializer<Integer>}
  */
class IntegerJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {IntegerJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    IntegerJsonDeserializer.$clinit();
    return IntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'IntegerJsonDeserializer()'.
   * @return {!IntegerJsonDeserializer}
   * @public
   */
  static $create__() {
    IntegerJsonDeserializer.$clinit();
    let $instance = new IntegerJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IntegerJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Integer}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NUMBER__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return Integer.m_valueOf__int(reader.m_nextInt__());
    } else {
      return Integer.m_valueOf__int(Integer.m_parseInt__java_lang_String(reader.m_nextString__()));
    }
  }
  
  /**
   * @return {IntegerJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_() {
    return (IntegerJsonDeserializer.$clinit(), IntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_);
  }
  
  /**
   * @param {IntegerJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_(value) {
    (IntegerJsonDeserializer.$clinit(), IntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IntegerJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IntegerJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IntegerJsonDeserializer.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    BaseNumberJsonDeserializer.$clinit();
    IntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_ = IntegerJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(IntegerJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$IntegerJsonDeserializer'));


/** @private {IntegerJsonDeserializer} */
IntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_IntegerJsonDeserializer_;




exports = IntegerJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$IntegerJsonDeserializer.js.map