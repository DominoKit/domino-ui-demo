/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.AbstractSequentialListJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.AbstractSequentialListJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseListJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseListJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _AbstractSequentialList = goog.require('java.util.AbstractSequentialList');
const _Collection = goog.require('java.util.Collection');
const _LinkedList = goog.require('java.util.LinkedList');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AbstractSequentialListJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.AbstractSequentialListJsonDeserializer$impl');
exports = AbstractSequentialListJsonDeserializer;
 