/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.ArrayListJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.ArrayListJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseListJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseListJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseListJsonDeserializer<ArrayList<C_T>, C_T>}
  */
class ArrayListJsonDeserializer extends BaseListJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {ArrayListJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    ArrayListJsonDeserializer.$clinit();
    return /**@type {!ArrayListJsonDeserializer<*>} */ (ArrayListJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'ArrayListJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!ArrayListJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    ArrayListJsonDeserializer.$clinit();
    let $instance = new ArrayListJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_ArrayListJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ArrayListJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_ArrayListJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseListJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {ArrayList<C_T>}
   * @public
   */
  m_newCollection__() {
    return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {ArrayList<C_T>} */ ($Casts.$to(arg2, ArrayList)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {ArrayList<C_T>} */ ($Casts.$to(arg2, ArrayList)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {ArrayList<C_T>} */ ($Casts.$to(arg2, ArrayList)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ArrayListJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ArrayListJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ArrayListJsonDeserializer.$clinit = function() {};
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseListJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ArrayListJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.ArrayListJsonDeserializer'));




exports = ArrayListJsonDeserializer; 
//# sourceMappingURL=ArrayListJsonDeserializer.js.map