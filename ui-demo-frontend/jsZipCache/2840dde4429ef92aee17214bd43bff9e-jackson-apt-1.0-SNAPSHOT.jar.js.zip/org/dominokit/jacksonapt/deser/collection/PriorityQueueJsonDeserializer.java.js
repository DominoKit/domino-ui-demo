/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.PriorityQueueJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.PriorityQueueJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseQueueJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseQueueJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _Collection = goog.require('java.util.Collection');
const _PriorityQueue = goog.require('java.util.PriorityQueue');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PriorityQueueJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.PriorityQueueJsonDeserializer$impl');
exports = PriorityQueueJsonDeserializer;
 