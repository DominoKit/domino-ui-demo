/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.SortedSetJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.SortedSetJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseSortedSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _Collection = goog.require('java.util.Collection');
const _SortedSet = goog.require('java.util.SortedSet');
const _TreeSet = goog.require('java.util.TreeSet');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SortedSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.SortedSetJsonDeserializer$impl');
exports = SortedSetJsonDeserializer;
 