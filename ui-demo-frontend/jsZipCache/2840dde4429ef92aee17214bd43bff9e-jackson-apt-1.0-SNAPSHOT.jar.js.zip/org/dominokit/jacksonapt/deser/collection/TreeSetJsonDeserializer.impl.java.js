/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.TreeSetJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.TreeSetJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseSortedSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSortedSetJsonDeserializer$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let TreeSet = goog.forwardDeclare('java.util.TreeSet$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseSortedSetJsonDeserializer<TreeSet<C_T>, C_T>}
  */
class TreeSetJsonDeserializer extends BaseSortedSetJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_T
   * @param {JsonDeserializer<M_T>} deserializer
   * @return {TreeSetJsonDeserializer<M_T>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    TreeSetJsonDeserializer.$clinit();
    return /**@type {!TreeSetJsonDeserializer<*>} */ (TreeSetJsonDeserializer.$create__org_dominokit_jacksonapt_JsonDeserializer(deserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'TreeSetJsonDeserializer(JsonDeserializer)'.
   * @template C_T
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {!TreeSetJsonDeserializer<C_T>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    TreeSetJsonDeserializer.$clinit();
    let $instance = new TreeSetJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_collection_TreeSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TreeSetJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_TreeSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseSortedSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {TreeSet<C_T>}
   * @public
   */
  m_newCollection__() {
    return /**@type {!TreeSet<C_T>} */ (TreeSet.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Collection} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {TreeSet<C_T>} */ ($Casts.$to(arg2, TreeSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Iterable} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Iterable__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {TreeSet<C_T>} */ ($Casts.$to(arg2, TreeSet)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {TreeSet<C_T>} */ ($Casts.$to(arg2, TreeSet)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TreeSetJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TreeSetJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TreeSetJsonDeserializer.$clinit = function() {};
    TreeSet = goog.module.get('java.util.TreeSet$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseSortedSetJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TreeSetJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.TreeSetJsonDeserializer'));




exports = TreeSetJsonDeserializer; 
//# sourceMappingURL=TreeSetJsonDeserializer.js.map