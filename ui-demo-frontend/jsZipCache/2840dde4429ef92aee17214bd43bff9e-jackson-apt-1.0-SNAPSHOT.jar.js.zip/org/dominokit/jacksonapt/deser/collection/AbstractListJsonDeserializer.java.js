/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.AbstractListJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.AbstractListJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseListJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseListJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _AbstractList = goog.require('java.util.AbstractList');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AbstractListJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.AbstractListJsonDeserializer$impl');
exports = AbstractListJsonDeserializer;
 