/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.EnumSetJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.EnumSetJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Enum = goog.require('java.lang.Enum');
const _Iterable = goog.require('java.lang.Iterable');
const _Collection = goog.require('java.util.Collection');
const _EnumSet = goog.require('java.util.EnumSet');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _EnumJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.EnumJsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EnumSetJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.EnumSetJsonDeserializer$impl');
exports = EnumSetJsonDeserializer;
 