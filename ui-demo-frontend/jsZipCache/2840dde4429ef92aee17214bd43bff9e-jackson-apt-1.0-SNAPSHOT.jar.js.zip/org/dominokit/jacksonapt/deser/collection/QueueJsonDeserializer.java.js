/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.QueueJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.QueueJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseQueueJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseQueueJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _Collection = goog.require('java.util.Collection');
const _LinkedList = goog.require('java.util.LinkedList');
const _Queue = goog.require('java.util.Queue');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var QueueJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.QueueJsonDeserializer$impl');
exports = QueueJsonDeserializer;
 