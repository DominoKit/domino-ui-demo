/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.IterableJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.IterableJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseIterableJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer');
const _Iterable = goog.require('java.lang.Iterable');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var IterableJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.IterableJsonDeserializer$impl');
exports = IterableJsonDeserializer;
 