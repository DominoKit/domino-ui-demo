/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseQueueJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseQueueJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseCollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer$impl');

let Queue = goog.forwardDeclare('java.util.Queue$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');


/**
 * @abstract
 * @template C_Q, C_T
 * @extends {BaseCollectionJsonDeserializer<C_Q, C_T>}
  */
class BaseQueueJsonDeserializer extends BaseCollectionJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseQueueJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_BaseQueueJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isNullValueAllowed__() {
    return false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseQueueJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseQueueJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseQueueJsonDeserializer.$clinit = function() {};
    BaseCollectionJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseQueueJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.BaseQueueJsonDeserializer'));




exports = BaseQueueJsonDeserializer; 
//# sourceMappingURL=BaseQueueJsonDeserializer.js.map