/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseIterableJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseIterableJsonDeserializer$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_C, C_T
 * @extends {BaseIterableJsonDeserializer<C_C, C_T>}
  */
class BaseCollectionJsonDeserializer extends BaseIterableJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseCollectionJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_BaseCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_C}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Equality.$same(JsonToken.f_BEGIN_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      let result = this.m_newCollection__();
      reader.m_beginArray__();
      while (!$Equality.$same(JsonToken.f_END_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
        let element = this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
        if (this.m_isNullValueAllowed__() || !$Equality.$same(null, element)) {
          /**@type {Collection} */ (result).add(element);
        }
      }
      reader.m_endArray__();
      return result;
    } else if (ctx.m_isAcceptSingleValueAsArray__()) {
      let result$1$ = this.m_newCollection__();
      /**@type {Collection} */ (result$1$).add(this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params));
      return result$1$;
    } else {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot deserialize a java.util.Collection out of " + j_l_String.m_valueOf__java_lang_Object(reader.m_peek__()) + " token", reader));
    }
  }
  
  /**
   * @abstract
   * @return {C_C}
   * @public
   */
  m_newCollection__() {
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isNullValueAllowed__() {
    return true;
  }
  
  /**
   * @param {?string} referenceName
   * @param {*} reference
   * @param {C_C} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Collection__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    if (!$Equality.$same(null, value) && !/**@type {Collection} */ (value).isEmpty()) {
      for (let $iterator = /**@type {Collection} */ (value).m_iterator__(); $iterator.m_hasNext__(); ) {
        let val = $iterator.m_next__();
        this.f_deserializer__org_dominokit_jacksonapt_deser_collection_BaseIterableJsonDeserializer.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, val, ctx);
      }
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseCollectionJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseCollectionJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseCollectionJsonDeserializer.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    BaseIterableJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseCollectionJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer'));




exports = BaseCollectionJsonDeserializer; 
//# sourceMappingURL=BaseCollectionJsonDeserializer.js.map