/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseCollectionJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.collection.BaseCollectionJsonDeserializer$impl');

let Set = goog.forwardDeclare('java.util.Set$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');


/**
 * @abstract
 * @template C_S, C_T
 * @extends {BaseCollectionJsonDeserializer<C_S, C_T>}
  */
class BaseSetJsonDeserializer extends BaseCollectionJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseSetJsonDeserializer(JsonDeserializer)'.
   * @param {JsonDeserializer<C_T>} deserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_collection_BaseSetJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_collection_BaseCollectionJsonDeserializer__org_dominokit_jacksonapt_JsonDeserializer(deserializer);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseSetJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseSetJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseSetJsonDeserializer.$clinit = function() {};
    BaseCollectionJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseSetJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.collection.BaseSetJsonDeserializer'));




exports = BaseSetJsonDeserializer; 
//# sourceMappingURL=BaseSetJsonDeserializer.js.map