/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.CharacterJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _Character = goog.require('java.lang.Character');
const _j_l_String = goog.require('java.lang.String');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Objects = goog.require('vmbootstrap.Objects');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var CharacterJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.CharacterJsonDeserializer$impl');
exports = CharacterJsonDeserializer;
 