/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _Date = goog.require('java.util.Date');
const _$Long = goog.require('nativebootstrap.Long');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var BaseDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$impl');
exports = BaseDateJsonDeserializer;
 