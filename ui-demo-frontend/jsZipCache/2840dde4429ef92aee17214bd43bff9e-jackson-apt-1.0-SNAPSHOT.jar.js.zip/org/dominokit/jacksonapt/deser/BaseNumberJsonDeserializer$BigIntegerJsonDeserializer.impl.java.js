/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$BigIntegerJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.BigIntegerJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let BigInteger = goog.forwardDeclare('java.math.BigInteger$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {BaseNumberJsonDeserializer<BigInteger>}
  */
class BigIntegerJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {BigIntegerJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    BigIntegerJsonDeserializer.$clinit();
    return BigIntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'BigIntegerJsonDeserializer()'.
   * @return {!BigIntegerJsonDeserializer}
   * @public
   */
  static $create__() {
    BigIntegerJsonDeserializer.$clinit();
    let $instance = new BigIntegerJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BigIntegerJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {BigInteger}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return BigInteger.$create__java_lang_String(reader.m_nextString__());
  }
  
  /**
   * @return {BigIntegerJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_() {
    return (BigIntegerJsonDeserializer.$clinit(), BigIntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_);
  }
  
  /**
   * @param {BigIntegerJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_(value) {
    (BigIntegerJsonDeserializer.$clinit(), BigIntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BigIntegerJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BigIntegerJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BigIntegerJsonDeserializer.$clinit = function() {};
    BigInteger = goog.module.get('java.math.BigInteger$impl');
    BaseNumberJsonDeserializer.$clinit();
    BigIntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_ = BigIntegerJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(BigIntegerJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$BigIntegerJsonDeserializer'));


/** @private {BigIntegerJsonDeserializer} */
BigIntegerJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigIntegerJsonDeserializer_;




exports = BigIntegerJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$BigIntegerJsonDeserializer.js.map