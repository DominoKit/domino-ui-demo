/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$LongJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.LongJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let Long = goog.forwardDeclare('java.lang.Long$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {BaseNumberJsonDeserializer<Long>}
  */
class LongJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {LongJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    LongJsonDeserializer.$clinit();
    return LongJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'LongJsonDeserializer()'.
   * @return {!LongJsonDeserializer}
   * @public
   */
  static $create__() {
    LongJsonDeserializer.$clinit();
    let $instance = new LongJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LongJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Long}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return Long.m_valueOf__long(reader.m_nextLong__());
  }
  
  /**
   * @return {LongJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_() {
    return (LongJsonDeserializer.$clinit(), LongJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_);
  }
  
  /**
   * @param {LongJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_(value) {
    (LongJsonDeserializer.$clinit(), LongJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LongJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LongJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LongJsonDeserializer.$clinit = function() {};
    Long = goog.module.get('java.lang.Long$impl');
    BaseNumberJsonDeserializer.$clinit();
    LongJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_ = LongJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(LongJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$LongJsonDeserializer'));


/** @private {LongJsonDeserializer} */
LongJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_LongJsonDeserializer_;




exports = LongJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$LongJsonDeserializer.js.map