/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$BigDecimalJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.BigDecimalJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let BigDecimal = goog.forwardDeclare('java.math.BigDecimal$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {BaseNumberJsonDeserializer<BigDecimal>}
  */
class BigDecimalJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {BigDecimalJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    BigDecimalJsonDeserializer.$clinit();
    return BigDecimalJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'BigDecimalJsonDeserializer()'.
   * @return {!BigDecimalJsonDeserializer}
   * @public
   */
  static $create__() {
    BigDecimalJsonDeserializer.$clinit();
    let $instance = new BigDecimalJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BigDecimalJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {BigDecimal}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return BigDecimal.$create__java_lang_String(reader.m_nextString__());
  }
  
  /**
   * @return {BigDecimalJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_() {
    return (BigDecimalJsonDeserializer.$clinit(), BigDecimalJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_);
  }
  
  /**
   * @param {BigDecimalJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_(value) {
    (BigDecimalJsonDeserializer.$clinit(), BigDecimalJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BigDecimalJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BigDecimalJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BigDecimalJsonDeserializer.$clinit = function() {};
    BigDecimal = goog.module.get('java.math.BigDecimal$impl');
    BaseNumberJsonDeserializer.$clinit();
    BigDecimalJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_ = BigDecimalJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(BigDecimalJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$BigDecimalJsonDeserializer'));


/** @private {BigDecimalJsonDeserializer} */
BigDecimalJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_BigDecimalJsonDeserializer_;




exports = BigDecimalJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$BigDecimalJsonDeserializer.js.map