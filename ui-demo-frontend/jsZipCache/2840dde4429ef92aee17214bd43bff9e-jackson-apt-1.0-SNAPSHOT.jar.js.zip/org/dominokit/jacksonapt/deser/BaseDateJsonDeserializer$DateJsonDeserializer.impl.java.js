/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$DateJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer.DateJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');


/**
 * @extends {BaseDateJsonDeserializer<Date>}
  */
class DateJsonDeserializer extends BaseDateJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {DateJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    DateJsonDeserializer.$clinit();
    return DateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'DateJsonDeserializer()'.
   * @return {!DateJsonDeserializer}
   * @public
   */
  static $create__() {
    DateJsonDeserializer.$clinit();
    let $instance = new DateJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @param {JsonDeserializerParameters} params
   * @return {Date}
   * @public
   */
  m_deserializeNumber__long__org_dominokit_jacksonapt_JsonDeserializerParameters(millis, params) {
    return Date.$create__long(millis);
  }
  
  /**
   * @override
   * @param {?string} date
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {Date}
   * @public
   */
  m_deserializeString__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(date, ctx, params) {
    return JacksonContextProvider.m_get__().m_dateFormat__().m_parse__boolean__java_lang_String__java_lang_Boolean__java_lang_String(ctx.m_isUseBrowserTimezone__(), params.m_getPattern__(), null, date);
  }
  
  /**
   * @return {DateJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_() {
    return (DateJsonDeserializer.$clinit(), DateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_);
  }
  
  /**
   * @param {DateJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_(value) {
    (DateJsonDeserializer.$clinit(), DateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateJsonDeserializer.$clinit = function() {};
    Date = goog.module.get('java.util.Date$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    BaseDateJsonDeserializer.$clinit();
    DateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_ = DateJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(DateJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseDateJsonDeserializer$DateJsonDeserializer'));


/** @private {DateJsonDeserializer} */
DateJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseDateJsonDeserializer_DateJsonDeserializer_;




exports = DateJsonDeserializer; 
//# sourceMappingURL=BaseDateJsonDeserializer$DateJsonDeserializer.js.map