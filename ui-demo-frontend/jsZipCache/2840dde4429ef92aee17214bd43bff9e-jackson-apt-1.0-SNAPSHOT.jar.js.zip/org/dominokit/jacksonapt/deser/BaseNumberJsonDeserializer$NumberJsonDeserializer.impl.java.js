/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$NumberJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.NumberJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let Number = goog.forwardDeclare('java.lang.Number$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {BaseNumberJsonDeserializer<(Number|number)>}
  */
class NumberJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {NumberJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    NumberJsonDeserializer.$clinit();
    return NumberJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'NumberJsonDeserializer()'.
   * @return {!NumberJsonDeserializer}
   * @public
   */
  static $create__() {
    NumberJsonDeserializer.$clinit();
    let $instance = new NumberJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NumberJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {(Number|number)}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return reader.m_nextNumber__();
  }
  
  /**
   * @return {NumberJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_() {
    return (NumberJsonDeserializer.$clinit(), NumberJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_);
  }
  
  /**
   * @param {NumberJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_(value) {
    (NumberJsonDeserializer.$clinit(), NumberJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NumberJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NumberJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NumberJsonDeserializer.$clinit = function() {};
    BaseNumberJsonDeserializer.$clinit();
    NumberJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_ = NumberJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(NumberJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$NumberJsonDeserializer'));


/** @private {NumberJsonDeserializer} */
NumberJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_NumberJsonDeserializer_;




exports = NumberJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$NumberJsonDeserializer.js.map