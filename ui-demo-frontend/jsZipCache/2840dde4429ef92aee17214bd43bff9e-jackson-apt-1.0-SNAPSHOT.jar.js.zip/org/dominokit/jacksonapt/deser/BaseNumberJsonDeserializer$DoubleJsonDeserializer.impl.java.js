/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$DoubleJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.DoubleJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @extends {BaseNumberJsonDeserializer<?number>}
  */
class DoubleJsonDeserializer extends BaseNumberJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {DoubleJsonDeserializer}
   * @public
   */
  static m_getInstance__() {
    DoubleJsonDeserializer.$clinit();
    return DoubleJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'DoubleJsonDeserializer()'.
   * @return {!DoubleJsonDeserializer}
   * @public
   */
  static $create__() {
    DoubleJsonDeserializer.$clinit();
    let $instance = new DoubleJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DoubleJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {?number}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    return reader.m_nextDouble__();
  }
  
  /**
   * @return {DoubleJsonDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_() {
    return (DoubleJsonDeserializer.$clinit(), DoubleJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_);
  }
  
  /**
   * @param {DoubleJsonDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_(value) {
    (DoubleJsonDeserializer.$clinit(), DoubleJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DoubleJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DoubleJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DoubleJsonDeserializer.$clinit = function() {};
    BaseNumberJsonDeserializer.$clinit();
    DoubleJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_ = DoubleJsonDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(DoubleJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer$DoubleJsonDeserializer'));


/** @private {DoubleJsonDeserializer} */
DoubleJsonDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_BaseNumberJsonDeserializer_DoubleJsonDeserializer_;




exports = DoubleJsonDeserializer; 
//# sourceMappingURL=BaseNumberJsonDeserializer$DoubleJsonDeserializer.js.map