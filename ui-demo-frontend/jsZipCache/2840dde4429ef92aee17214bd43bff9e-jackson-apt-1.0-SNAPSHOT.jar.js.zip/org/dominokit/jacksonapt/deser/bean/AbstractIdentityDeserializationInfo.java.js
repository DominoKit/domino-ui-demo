/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractIdentityDeserializationInfo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractIdentityDeserializationInfo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializer');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');
const _Class = goog.require('java.lang.Class');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var AbstractIdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractIdentityDeserializationInfo$impl');
exports = AbstractIdentityDeserializationInfo;
 