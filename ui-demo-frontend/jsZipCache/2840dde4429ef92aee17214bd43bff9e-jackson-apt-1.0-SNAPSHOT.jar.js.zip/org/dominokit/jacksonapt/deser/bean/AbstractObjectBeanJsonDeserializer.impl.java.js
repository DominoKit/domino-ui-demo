/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractObjectBeanJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractObjectBeanJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let NumberJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.NumberJsonDeserializer$impl');
let BooleanJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
let StringJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let ArrayListJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.collection.ArrayListJsonDeserializer$impl');
let LinkedHashMapJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.LinkedHashMapJsonDeserializer$impl');
let StringKeyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.StringKeyDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @extends {AbstractBeanJsonDeserializer<*>}
  */
class AbstractObjectBeanJsonDeserializer extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ArrayListJsonDeserializer<*>} */
    this.f_listJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_;
    /** @public {LinkedHashMapJsonDeserializer<?string, *>} */
    this.f_mapJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_;
  }
  
  /**
   * Initialization from constructor 'AbstractObjectBeanJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_canDeserialize__() {
    return true;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {*}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation) {
    switch (reader.m_peek__().ordinal()) {
      case JsonToken.$ordinal$f_NUMBER__org_dominokit_jacksonapt_stream_JsonToken: 
        return NumberJsonDeserializer.m_getInstance__().m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
      case JsonToken.$ordinal$f_STRING__org_dominokit_jacksonapt_stream_JsonToken: 
        return StringJsonDeserializer.m_getInstance__().m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
      case JsonToken.$ordinal$f_BOOLEAN__org_dominokit_jacksonapt_stream_JsonToken: 
        return BooleanJsonDeserializer.m_getInstance__().m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
      case JsonToken.$ordinal$f_BEGIN_ARRAY__org_dominokit_jacksonapt_stream_JsonToken: 
        if ($Equality.$same(null, this.f_listJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_)) {
          this.f_listJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_ = /**@type {ArrayListJsonDeserializer<*>} */ (ArrayListJsonDeserializer.m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(this));
        }
        return this.f_listJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_.m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
      case JsonToken.$ordinal$f_BEGIN_OBJECT__org_dominokit_jacksonapt_stream_JsonToken: 
        if ($Equality.$same(null, this.f_mapJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_)) {
          this.f_mapJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_ = /**@type {LinkedHashMapJsonDeserializer<?string, *>} */ (LinkedHashMapJsonDeserializer.m_newInstance__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(StringKeyDeserializer.m_getInstance__(), this));
        }
        return this.f_mapJsonDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractObjectBeanJsonDeserializer_.m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
      case JsonToken.$ordinal$f_NULL__org_dominokit_jacksonapt_stream_JsonToken: 
        reader.m_nextNull__();
        return null;
      default: 
        throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Unexpected token " + j_l_String.m_valueOf__java_lang_Object(reader.m_peek__()) + " for java.lang.Object deserialization", reader));
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractObjectBeanJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractObjectBeanJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractObjectBeanJsonDeserializer.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    NumberJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.NumberJsonDeserializer$impl');
    BooleanJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BooleanJsonDeserializer$impl');
    StringJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.StringJsonDeserializer$impl');
    ArrayListJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.collection.ArrayListJsonDeserializer$impl');
    LinkedHashMapJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.map.LinkedHashMapJsonDeserializer$impl');
    StringKeyDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.map.key.StringKeyDeserializer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractObjectBeanJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.AbstractObjectBeanJsonDeserializer'));




exports = AbstractObjectBeanJsonDeserializer; 
//# sourceMappingURL=AbstractObjectBeanJsonDeserializer.js.map