/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.BackReferenceProperty.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T, C_R
 */
class BackReferenceProperty {
  /**
   * @abstract
   * @param {C_T} value
   * @param {C_R} reference
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(value, reference, ctx) {
  }
  
  /**
   * @template C_T, C_R
   * @param {?function(C_T, C_R, JsonDeserializationContext):void} fn
   * @return {BackReferenceProperty<C_T, C_R>}
   * @public
   */
  static $adapt(fn) {
    BackReferenceProperty.$clinit();
    return /**@type {!$LambdaAdaptor<*, *>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty;
  }
  
  /**
   * @public
   */
  static $clinit() {
    BackReferenceProperty.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(BackReferenceProperty, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty'));


BackReferenceProperty.$markImplementor(/** @type {Function} */ (BackReferenceProperty));


exports = BackReferenceProperty; 
//# sourceMappingURL=BackReferenceProperty.js.map