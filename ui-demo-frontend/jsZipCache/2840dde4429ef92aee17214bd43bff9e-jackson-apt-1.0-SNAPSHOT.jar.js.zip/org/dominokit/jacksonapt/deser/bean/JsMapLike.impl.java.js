/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.JsMapLike.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.JsMapLike$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike$impl');

let Any_$Overlay = goog.forwardDeclare('jsinterop.base.Any.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {MapLike<C_T>}
  */
class JsMapLike extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Object<string, C_T>} */
    this.f_map__org_dominokit_jacksonapt_deser_bean_JsMapLike_;
  }
  
  /**
   * Factory method corresponding to constructor 'JsMapLike()'.
   * @template C_T
   * @return {!JsMapLike<C_T>}
   * @public
   */
  static $create__() {
    JsMapLike.$clinit();
    let $instance = new JsMapLike();
    $instance.$ctor__org_dominokit_jacksonapt_deser_bean_JsMapLike__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JsMapLike()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_JsMapLike__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_jacksonapt_deser_bean_JsMapLike();
  }
  
  /**
   * @override
   * @param {?string} key
   * @return {C_T}
   * @public
   */
  m_get__java_lang_String(key) {
    return $Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(this.f_map__org_dominokit_jacksonapt_deser_bean_JsMapLike_, key);
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_put__java_lang_String__java_lang_Object(key, value) {
    $Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(this.f_map__org_dominokit_jacksonapt_deser_bean_JsMapLike_, key, value);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_jacksonapt_deser_bean_JsMapLike() {
    this.f_map__org_dominokit_jacksonapt_deser_bean_JsMapLike_ = /**@type {Object<string, C_T>} */ ($Casts.$to(Any_$Overlay.m_asPropertyMap__jsinterop_base_Any(Js.m_asAny__java_lang_Object(Object.create(null))), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsMapLike;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsMapLike);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsMapLike.$clinit = function() {};
    Any_$Overlay = goog.module.get('jsinterop.base.Any.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsMapLike, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.JsMapLike'));


MapLike.$markImplementor(JsMapLike);


exports = JsMapLike; 
//# sourceMappingURL=JsMapLike.js.map