/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.PropertyIdentityDeserializationInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.PropertyIdentityDeserializationInfo$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_T
 * @implements {IdentityDeserializationInfo<C_T>}
  */
class PropertyIdentityDeserializationInfo extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_propertyName__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_;
    /** @public {Class<?>} */
    this.f_type__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_;
    /** @public {Class<?>} */
    this.f_scope__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_;
  }
  
  /**
   * Factory method corresponding to constructor 'PropertyIdentityDeserializationInfo(String, Class, Class)'.
   * @template C_T
   * @param {?string} propertyName
   * @param {Class<?>} type
   * @param {Class<?>} scope
   * @return {!PropertyIdentityDeserializationInfo<C_T>}
   * @public
   */
  static $create__java_lang_String__java_lang_Class__java_lang_Class(propertyName, type, scope) {
    PropertyIdentityDeserializationInfo.$clinit();
    let $instance = new PropertyIdentityDeserializationInfo();
    $instance.$ctor__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo__java_lang_String__java_lang_Class__java_lang_Class(propertyName, type, scope);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PropertyIdentityDeserializationInfo(String, Class, Class)'.
   * @param {?string} propertyName
   * @param {Class<?>} type
   * @param {Class<?>} scope
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo__java_lang_String__java_lang_Class__java_lang_Class(propertyName, type, scope) {
    this.$ctor__java_lang_Object__();
    this.f_propertyName__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_ = propertyName;
    this.f_type__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_ = type;
    this.f_scope__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_ = scope;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getPropertyName__() {
    return this.f_propertyName__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isProperty__() {
    return true;
  }
  
  /**
   * @override
   * @param {*} id
   * @return {IdKey}
   * @public
   */
  m_newIdKey__java_lang_Object(id) {
    return IdKey.$create__java_lang_Class__java_lang_Class__java_lang_Object(this.f_type__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_, this.f_scope__org_dominokit_jacksonapt_deser_bean_PropertyIdentityDeserializationInfo_, id);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @return {*}
   * @public
   */
  m_readId__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx) {
    throw $Exceptions.toJs(ctx.m_traceError__java_lang_String("readId() is not supported by PropertyIdentitySerializationInfo"));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PropertyIdentityDeserializationInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PropertyIdentityDeserializationInfo);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PropertyIdentityDeserializationInfo.$clinit = function() {};
    IdKey = goog.module.get('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PropertyIdentityDeserializationInfo, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.PropertyIdentityDeserializationInfo'));


IdentityDeserializationInfo.$markImplementor(PropertyIdentityDeserializationInfo);


exports = PropertyIdentityDeserializationInfo; 
//# sourceMappingURL=PropertyIdentityDeserializationInfo.js.map