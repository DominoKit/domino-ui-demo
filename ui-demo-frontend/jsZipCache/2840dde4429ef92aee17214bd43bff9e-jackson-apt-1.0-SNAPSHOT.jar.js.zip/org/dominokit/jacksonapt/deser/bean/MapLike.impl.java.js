/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.MapLike.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @template C_T
 */
class MapLike {
  /**
   * @abstract
   * @param {?string} key
   * @return {C_T}
   * @public
   */
  m_get__java_lang_String(key) {
  }
  
  /**
   * @abstract
   * @param {?string} key
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_put__java_lang_String__java_lang_Object(key, value) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_MapLike = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_bean_MapLike;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_MapLike;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MapLike.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(MapLike, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.MapLike'));


MapLike.$markImplementor(/** @type {Function} */ (MapLike));


exports = MapLike; 
//# sourceMappingURL=MapLike.js.map