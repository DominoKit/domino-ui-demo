/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const BackReferenceProperty = goog.require('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @template C_T, C_R
 * @implements {BackReferenceProperty<C_T, C_R>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_T, C_R, JsonDeserializationContext):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(C_T, C_R, JsonDeserializationContext):void} */
    this.f_$$fn__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$LambdaAdaptor__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_T, C_R, JsonDeserializationContext):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$LambdaAdaptor__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {C_T} arg0
   * @param {C_R} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    {
      let $function = this.f_$$fn__org_dominokit_jacksonapt_deser_bean_BackReferenceProperty_$LambdaAdaptor;
      $function(arg0, arg1, arg2);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$$LambdaAdaptor'));


BackReferenceProperty.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=BackReferenceProperty$$LambdaAdaptor.js.map