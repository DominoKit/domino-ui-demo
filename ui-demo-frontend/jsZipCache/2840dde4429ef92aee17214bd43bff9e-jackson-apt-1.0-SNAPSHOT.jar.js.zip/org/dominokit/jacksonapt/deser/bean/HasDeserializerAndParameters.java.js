/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializer');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var HasDeserializerAndParameters = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');
exports = HasDeserializerAndParameters;
 