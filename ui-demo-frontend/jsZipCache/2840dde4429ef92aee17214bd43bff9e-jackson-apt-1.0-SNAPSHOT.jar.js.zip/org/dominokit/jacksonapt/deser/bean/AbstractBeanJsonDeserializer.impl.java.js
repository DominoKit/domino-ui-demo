/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');
const InternalDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.InternalDeserializer$impl');

let As = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonTypeInfo.As$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Collections = goog.forwardDeclare('java.util.Collections$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Entry = goog.forwardDeclare('java.util.Map.Entry$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let AnySetterDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.AnySetterDeserializer$impl');
let BackReferenceProperty = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let HasDeserializerAndParameters = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');
let SubtypeDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @abstract
 * @template C_T
 * @extends {JsonDeserializer<C_T>}
 * @implements {InternalDeserializer<C_T, AbstractBeanJsonDeserializer<C_T>>}
  */
class AbstractBeanJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {InstanceBuilder<C_T>} */
    this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer;
    /** @public {MapLike<BeanPropertyDeserializer<C_T, ?>>} */
    this.f_deserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {MapLike<BackReferenceProperty<C_T, ?>>} */
    this.f_backReferenceDeserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {Set<?string>} */
    this.f_defaultIgnoredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {Set<?string>} */
    this.f_requiredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {IdentityDeserializationInfo<C_T>} */
    this.f_defaultIdentityInfo__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {TypeDeserializationInfo<C_T>} */
    this.f_defaultTypeInfo__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {Map<Class, SubtypeDeserializer>} */
    this.f_subtypeClassToDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    /** @public {AnySetterDeserializer<C_T, ?>} */
    this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
  }
  
  /**
   * Initialization from constructor 'AbstractBeanJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
    this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer = this.m_initInstanceBuilder__();
    this.f_deserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initDeserializers__();
    this.f_backReferenceDeserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initBackReferenceDeserializers__();
    this.f_defaultIgnoredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initIgnoredProperties__();
    this.f_requiredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initRequiredProperties__();
    this.f_defaultIdentityInfo__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initIdentityInfo__();
    this.f_defaultTypeInfo__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initTypeInfo__();
    this.f_subtypeClassToDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initMapSubtypeClassToDeserializer__();
    this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ = this.m_initAnySetterDeserializer__();
  }
  
  /**
   * @return {InstanceBuilder<C_T>}
   * @public
   */
  m_initInstanceBuilder__() {
    return null;
  }
  
  /**
   * @return {MapLike<BeanPropertyDeserializer<C_T, ?>>}
   * @public
   */
  m_initDeserializers__() {
    return /**@type {MapLike<BeanPropertyDeserializer<C_T, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
  }
  
  /**
   * @return {MapLike<BackReferenceProperty<C_T, ?>>}
   * @public
   */
  m_initBackReferenceDeserializers__() {
    return /**@type {MapLike<BackReferenceProperty<C_T, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
  }
  
  /**
   * @return {Set<?string>}
   * @public
   */
  m_initIgnoredProperties__() {
    return /**@type {Set<?string>} */ (Collections.m_emptySet__());
  }
  
  /**
   * @return {Set<?string>}
   * @public
   */
  m_initRequiredProperties__() {
    return /**@type {Set<?string>} */ (Collections.m_emptySet__());
  }
  
  /**
   * @return {IdentityDeserializationInfo<C_T>}
   * @public
   */
  m_initIdentityInfo__() {
    return null;
  }
  
  /**
   * @return {TypeDeserializationInfo<C_T>}
   * @public
   */
  m_initTypeInfo__() {
    return null;
  }
  
  /**
   * @return {Map<Class, SubtypeDeserializer>}
   * @public
   */
  m_initMapSubtypeClassToDeserializer__() {
    return /**@type {Map<Class, SubtypeDeserializer>} */ (Collections.m_emptyMap__());
  }
  
  /**
   * @return {AnySetterDeserializer<C_T, ?>}
   * @public
   */
  m_initAnySetterDeserializer__() {
    return null;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isDefaultIgnoreUnknown__() {
    return false;
  }
  
  /**
   * @abstract
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let identityInfo = $Equality.$same(null, params.m_getIdentityInfo__()) ? this.f_defaultIdentityInfo__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ : params.m_getIdentityInfo__();
    let typeInfo = $Equality.$same(null, params.m_getTypeInfo__()) ? this.f_defaultTypeInfo__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_ : params.m_getTypeInfo__();
    let token = reader.m_peek__();
    if (!$Equality.$same(null, identityInfo) && !$Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_BEGIN_OBJECT__org_dominokit_jacksonapt_stream_JsonToken, token) && !$Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_BEGIN_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
      let /** * */ id;
      if (identityInfo.m_isProperty__()) {
        let propertyDeserializer = /**@type {HasDeserializerAndParameters} */ ($Casts.$to(this.f_deserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_get__java_lang_String(identityInfo.m_getPropertyName__()), HasDeserializerAndParameters));
        if ($Equality.$same(null, propertyDeserializer)) {
          propertyDeserializer = /**@type {HasDeserializerAndParameters} */ ($Casts.$to(this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer.m_getParametersDeserializer__().m_get__java_lang_String(identityInfo.m_getPropertyName__()), HasDeserializerAndParameters));
        }
        id = propertyDeserializer.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx);
      } else {
        id = identityInfo.m_readId__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx);
      }
      let instance = ctx.m_getObjectWithId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey(identityInfo.m_newIdKey__java_lang_Object(id));
      if ($Equality.$same(null, instance)) {
        throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot find an object with id " + j_l_String.m_valueOf__java_lang_Object(id), reader));
      }
      return /**@type {C_T} */ ($Casts.$to(instance, j_l_Object));
    }
    let /** C_T */ result;
    if (!$Equality.$same(null, typeInfo)) {
      let /** Map<?string, ?string> */ bufferedProperties, /** ?string */ typeInfoProperty, /** ?string */ typeInfoWrapObj, /** ?string */ typeInfoWrapArray;
      let /** As */ include;
      if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_BEGIN_ARRAY__org_dominokit_jacksonapt_stream_JsonToken, token)) {
        include = As.f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As;
      } else {
        include = typeInfo.m_getInclude__();
      }
      switch (include.ordinal()) {
        case As.$ordinal$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As: 
          reader.m_beginObject__();
          bufferedProperties = null;
          typeInfoProperty = null;
          while ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NAME__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
            let name = reader.m_nextName__();
            if (j_l_String.m_equals__java_lang_String__java_lang_Object(typeInfo.m_getPropertyName__(), name)) {
              typeInfoProperty = reader.m_nextString__();
              break;
            } else {
              if ($Equality.$same(null, bufferedProperties)) {
                bufferedProperties = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
              }
              bufferedProperties.put(name, reader.m_nextValue__());
            }
          }
          if ($Equality.$same(null, typeInfoProperty)) {
            throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot find the property " + j_l_String.m_valueOf__java_lang_Object(typeInfo.m_getPropertyName__()) + " containing the type information", reader));
          }
          result = this.m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(reader, ctx, typeInfo, typeInfoProperty).m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, typeInfoProperty, bufferedProperties);
          reader.m_endObject__();
          break;
        case As.$ordinal$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As: 
          reader.m_beginObject__();
          typeInfoWrapObj = reader.m_nextName__();
          result = this.m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(reader, ctx, typeInfo, typeInfoWrapObj).m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInfoWrapObj);
          reader.m_endObject__();
          break;
        case As.$ordinal$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As: 
          reader.m_beginArray__();
          typeInfoWrapArray = reader.m_nextString__();
          result = this.m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(reader, ctx, typeInfo, typeInfoWrapArray).m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInfoWrapArray);
          reader.m_endArray__();
          break;
        default: 
          throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("JsonTypeInfo.As." + j_l_String.m_valueOf__java_lang_Object(typeInfo.m_getInclude__()) + " is not supported", reader));
      }
    } else if (this.m_canDeserialize__()) {
      result = this.m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, null, null);
    } else {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Cannot instantiate the type " + j_l_String.m_valueOf__java_lang_Object(this.m_getDeserializedType__().m_getName__()), reader));
    }
    return result;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_canDeserialize__() {
    return !$Equality.$same(null, this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {C_T}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation) {
    reader.m_beginObject__();
    let result = this.m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, typeInformation, null);
    reader.m_endObject__();
    return result;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} type
   * @param {Map<?string, ?string>} bufferedProperties
   * @return {C_T}
   * @public
   */
  m_deserializeInline__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String__java_util_Map(reader, ctx, params, identityInfo, typeInfo, type, bufferedProperties) {
    let ignoreUnknown = params.m_isIgnoreUnknown__() || this.m_isDefaultIgnoreUnknown__();
    let /** Set<?string> */ ignoredProperties;
    if ($Equality.$same(null, params.m_getIgnoredProperties__())) {
      ignoredProperties = this.f_defaultIgnoredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_;
    } else {
      ignoredProperties = /**@type {!HashSet<?string>} */ (HashSet.$create__java_util_Collection(this.f_defaultIgnoredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_));
      ignoredProperties.addAll(params.m_getIgnoredProperties__());
    }
    let requiredPropertiesLeft = this.f_requiredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.isEmpty() ? /**@type {Set<?string>} */ (Collections.m_emptySet__()) : /**@type {!HashSet<?string>} */ (HashSet.$create__java_util_Collection(this.f_requiredProperties__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_));
    let id = null;
    let bufferedPropertiesValues = null;
    if (!$Equality.$same(null, identityInfo)) {
      let identityReader = null;
      let propertyValue = null;
      if (!$Equality.$same(null, bufferedProperties)) {
        propertyValue = /**@type {?string} */ ($Casts.$to(bufferedProperties.remove(identityInfo.m_getPropertyName__()), j_l_String));
      }
      if (!$Equality.$same(null, propertyValue)) {
        identityReader = ctx.m_newJsonReader__java_lang_String(propertyValue);
      } else {
        while ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NAME__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
          let name = reader.m_nextName__();
          if (ignoredProperties.contains(name)) {
            reader.m_skipValue__();
            continue;
          }
          if (j_l_String.m_equals__java_lang_String__java_lang_Object(identityInfo.m_getPropertyName__(), name)) {
            identityReader = reader;
            break;
          } else {
            if ($Equality.$same(null, bufferedProperties)) {
              bufferedProperties = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
            }
            bufferedProperties.put(name, reader.m_nextValue__());
          }
        }
      }
      if (!$Equality.$same(null, identityReader)) {
        if (identityInfo.m_isProperty__()) {
          let propertyDeserializer = /**@type {HasDeserializerAndParameters} */ ($Casts.$to(this.f_deserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_get__java_lang_String(identityInfo.m_getPropertyName__()), HasDeserializerAndParameters));
          if ($Equality.$same(null, propertyDeserializer)) {
            propertyDeserializer = /**@type {HasDeserializerAndParameters} */ ($Casts.$to(this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer.m_getParametersDeserializer__().m_get__java_lang_String(identityInfo.m_getPropertyName__()), HasDeserializerAndParameters));
            id = propertyDeserializer.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(identityReader, ctx);
            bufferedPropertiesValues = /**@type {!HashMap<?string, *>} */ (HashMap.$create__int(1));
            bufferedPropertiesValues.put(identityInfo.m_getPropertyName__(), id);
          } else {
            id = propertyDeserializer.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(identityReader, ctx);
          }
        } else {
          id = identityInfo.m_readId__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(identityReader, ctx);
        }
      }
    }
    let instance = this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer.m_newInstance__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__java_util_Map__java_util_Map(reader, ctx, params, bufferedProperties, bufferedPropertiesValues);
    let bean = instance.m_getInstance__();
    bufferedProperties = instance.m_getBufferedProperties__();
    if (!$Equality.$same(null, id)) {
      if (identityInfo.m_isProperty__()) {
        let propertyDeserializer$1$ = /**@type {BeanPropertyDeserializer} */ ($Casts.$to(this.f_deserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_get__java_lang_String(identityInfo.m_getPropertyName__()), BeanPropertyDeserializer));
        if (!$Equality.$same(null, propertyDeserializer$1$)) {
          propertyDeserializer$1$.m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(bean, id, ctx);
        }
      }
      ctx.m_addObjectId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Object(identityInfo.m_newIdKey__java_lang_Object(id), bean);
    }
    this.m_flushBufferedProperties__java_lang_Object__java_util_Map__java_util_Set__org_dominokit_jacksonapt_JsonDeserializationContext__boolean__java_util_Set_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(bean, bufferedProperties, requiredPropertiesLeft, ctx, ignoreUnknown, ignoredProperties);
    if (!$Equality.$same(null, typeInfo) && !$Equality.$same(null, typeInfo.m_getPropertyName__()) && !$Equality.$same(null, type)) {
      let deserializer = this.m_getPropertyDeserializer__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__boolean_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(typeInfo.m_getPropertyName__(), ctx, true);
      if (!$Equality.$same(null, deserializer)) {
        deserializer.m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(bean, type, ctx);
      }
    }
    while ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NAME__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      let propertyName = reader.m_nextName__();
      requiredPropertiesLeft.remove(propertyName);
      if (ignoredProperties.contains(propertyName)) {
        reader.m_skipValue__();
        continue;
      }
      let property = this.m_getPropertyDeserializer__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__boolean_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(propertyName, ctx, ignoreUnknown);
      if (!$Equality.$same(null, property)) {
        property.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(reader, bean, ctx);
      } else if (!$Equality.$same(null, this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_)) {
        this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__java_lang_Object__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(reader, bean, propertyName, ctx);
      } else {
        reader.m_skipValue__();
      }
    }
    if (!requiredPropertiesLeft.isEmpty()) {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Required properties are missing : " + j_l_String.m_valueOf__java_lang_Object(requiredPropertiesLeft), reader));
    }
    return bean;
  }
  
  /**
   * @param {C_T} bean
   * @param {Map<?string, ?string>} bufferedProperties
   * @param {Set<?string>} requiredPropertiesLeft
   * @param {JsonDeserializationContext} ctx
   * @param {boolean} ignoreUnknown
   * @param {Set<?string>} ignoredProperties
   * @return {void}
   * @public
   */
  m_flushBufferedProperties__java_lang_Object__java_util_Map__java_util_Set__org_dominokit_jacksonapt_JsonDeserializationContext__boolean__java_util_Set_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(bean, bufferedProperties, requiredPropertiesLeft, ctx, ignoreUnknown, ignoredProperties) {
    if (!$Equality.$same(null, bufferedProperties) && !bufferedProperties.isEmpty()) {
      for (let $iterator = bufferedProperties.m_entrySet__().m_iterator__(); $iterator.m_hasNext__(); ) {
        let bufferedProperty = /**@type {Entry<?string, ?string>} */ ($Casts.$to($iterator.m_next__(), Entry));
        let propertyName = /**@type {?string} */ ($Casts.$to(bufferedProperty.m_getKey__(), j_l_String));
        requiredPropertiesLeft.remove(propertyName);
        if (ignoredProperties.contains(propertyName)) {
          continue;
        }
        let property = this.m_getPropertyDeserializer__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__boolean_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(propertyName, ctx, ignoreUnknown);
        if (!$Equality.$same(null, property)) {
          property.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(ctx.m_newJsonReader__java_lang_String(/**@type {?string} */ ($Casts.$to(bufferedProperty.m_getValue__(), j_l_String))), bean, ctx);
        } else if (!$Equality.$same(null, this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_)) {
          this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__java_lang_Object__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(ctx.m_newJsonReader__java_lang_String(/**@type {?string} */ ($Casts.$to(bufferedProperty.m_getValue__(), j_l_String))), bean, propertyName, ctx);
        }
      }
    }
  }
  
  /**
   * @param {?string} propertyName
   * @param {JsonDeserializationContext} ctx
   * @param {boolean} ignoreUnknown
   * @return {BeanPropertyDeserializer<C_T, ?>}
   * @public
   */
  m_getPropertyDeserializer__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext__boolean_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(propertyName, ctx, ignoreUnknown) {
    let property = /**@type {BeanPropertyDeserializer<C_T, *>} */ ($Casts.$to(this.f_deserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_get__java_lang_String(propertyName), BeanPropertyDeserializer));
    if ($Equality.$same(null, property)) {
      if (!ignoreUnknown && ctx.m_isFailOnUnknownProperties__() && $Equality.$same(null, this.f_anySetterDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_)) {
        throw $Exceptions.toJs(ctx.m_traceError__java_lang_String("Unknown property '" + j_l_String.m_valueOf__java_lang_Object(propertyName) + "'"));
      }
    }
    return property;
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {InternalDeserializer<C_T, ?>}
   * @public
   */
  m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(reader, ctx, typeInfo, typeInformation) {
    let typeClass = typeInfo.m_getTypeClass__java_lang_String(typeInformation);
    if ($Equality.$same(null, typeClass)) {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("Could not find the type associated to " + j_l_String.m_valueOf__java_lang_Object(typeInformation), reader));
    }
    return this.m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__java_lang_Class_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(reader, ctx, typeClass);
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {Class} typeClass
   * @return {InternalDeserializer<C_T, ?>}
   * @public
   */
  m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__java_lang_Class_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(reader, ctx, typeClass) {
    if ($Equality.$same(typeClass, this.m_getDeserializedType__())) {
      return this;
    }
    let deserializer = /**@type {SubtypeDeserializer} */ ($Casts.$to(this.f_subtypeClassToDeserializer__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.get(typeClass), SubtypeDeserializer));
    if ($Equality.$same(null, deserializer)) {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader("No deserializer found for the type " + j_l_String.m_valueOf__java_lang_Object(typeClass.m_getName__()), reader));
    }
    return deserializer;
  }
  
  /**
   * @override
   * @return {AbstractBeanJsonDeserializer<C_T>}
   * @public
   */
  m_getDeserializer__() {
    return this;
  }
  
  /**
   * @override
   * @param {?string} referenceName
   * @param {*} reference
   * @param {C_T} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    if ($Equality.$same(null, value)) {
      return;
    }
    let deserializer = this.m_getDeserializer__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__java_lang_Class_$p_org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer(null, ctx, $Objects.m_getClass__java_lang_Object(value)).m_getDeserializer__();
    if (!$Equality.$same($Objects.m_getClass__java_lang_Object(deserializer), this.m_getClass__())) {
      deserializer.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx);
      return;
    }
    let backReferenceProperty = /**@type {BackReferenceProperty} */ ($Casts.$to(this.f_backReferenceDeserializers__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer_.m_get__java_lang_String(referenceName), BackReferenceProperty));
    if ($Equality.$same(null, backReferenceProperty)) {
      throw $Exceptions.toJs(ctx.m_traceError__java_lang_String("The back reference '" + j_l_String.m_valueOf__java_lang_Object(referenceName) + "' does not exist"));
    }
    backReferenceProperty.m_setBackReference__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(value, reference, ctx);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractBeanJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractBeanJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractBeanJsonDeserializer.$clinit = function() {};
    As = goog.module.get('com.fasterxml.jackson.annotation.JsonTypeInfo.As$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Collections = goog.module.get('java.util.Collections$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    Entry = goog.module.get('java.util.Map.Entry$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    BackReferenceProperty = goog.module.get('org.dominokit.jacksonapt.deser.bean.BackReferenceProperty$impl');
    BeanPropertyDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
    HasDeserializerAndParameters = goog.module.get('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');
    SubtypeDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    JsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractBeanJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer'));


InternalDeserializer.$markImplementor(AbstractBeanJsonDeserializer);


exports = AbstractBeanJsonDeserializer; 
//# sourceMappingURL=AbstractBeanJsonDeserializer.js.map