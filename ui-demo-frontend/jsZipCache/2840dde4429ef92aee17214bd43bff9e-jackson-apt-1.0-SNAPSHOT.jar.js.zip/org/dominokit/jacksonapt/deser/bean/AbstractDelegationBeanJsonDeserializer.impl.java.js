/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractDelegationBeanJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractDelegationBeanJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let IdentityDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');
let TypeDeserializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @abstract
 * @template C_T
 * @extends {AbstractBeanJsonDeserializer<C_T>}
  */
class AbstractDelegationBeanJsonDeserializer extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'AbstractDelegationBeanJsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_AbstractDelegationBeanJsonDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {IdentityDeserializationInfo} identityInfo
   * @param {TypeDeserializationInfo} typeInfo
   * @param {?string} typeInformation
   * @return {C_T}
   * @public
   */
  m_deserializeWrapped__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo__org_dominokit_jacksonapt_deser_bean_TypeDeserializationInfo__java_lang_String(reader, ctx, params, identityInfo, typeInfo, typeInformation) {
    return this.f_instanceBuilder__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer.m_newInstance__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__java_util_Map__java_util_Map(reader, ctx, params, null, null).m_getInstance__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractDelegationBeanJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractDelegationBeanJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractDelegationBeanJsonDeserializer.$clinit = function() {};
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractDelegationBeanJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.AbstractDelegationBeanJsonDeserializer'));




exports = AbstractDelegationBeanJsonDeserializer; 
//# sourceMappingURL=AbstractDelegationBeanJsonDeserializer.js.map