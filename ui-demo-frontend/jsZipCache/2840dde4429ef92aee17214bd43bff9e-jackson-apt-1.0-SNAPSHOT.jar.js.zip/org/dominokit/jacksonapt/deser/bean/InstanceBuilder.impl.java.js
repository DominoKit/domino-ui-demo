/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.InstanceBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let HasDeserializerAndParameters = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');
let Instance = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.Instance$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 * @template C_T
 */
class InstanceBuilder {
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {Map<?string, ?string>} bufferedProperties
   * @param {Map<?string, *>} bufferedPropertiesValues
   * @return {Instance<C_T>}
   * @public
   */
  m_newInstance__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__java_util_Map__java_util_Map(reader, ctx, params, bufferedProperties, bufferedPropertiesValues) {
  }
  
  /**
   * @abstract
   * @return {MapLike<HasDeserializerAndParameters>}
   * @public
   */
  m_getParametersDeserializer__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_InstanceBuilder = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_bean_InstanceBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_InstanceBuilder;
  }
  
  /**
   * @public
   */
  static $clinit() {
    InstanceBuilder.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(InstanceBuilder, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.InstanceBuilder'));


InstanceBuilder.$markImplementor(/** @type {Function} */ (InstanceBuilder));


exports = InstanceBuilder; 
//# sourceMappingURL=InstanceBuilder.js.map