/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer$BeanSubtypeDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer.BeanSubtypeDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SubtypeDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer');
const _Map = goog.require('java.util.Map');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo');
const _TypeDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.TypeDeserializationInfo');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BeanSubtypeDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.SubtypeDeserializer.BeanSubtypeDeserializer$impl');
exports = BeanSubtypeDeserializer;
 