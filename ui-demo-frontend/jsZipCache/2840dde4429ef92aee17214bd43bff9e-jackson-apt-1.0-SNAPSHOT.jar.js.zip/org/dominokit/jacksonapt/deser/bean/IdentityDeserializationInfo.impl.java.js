/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 * @template C_T
 */
class IdentityDeserializationInfo {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getPropertyName__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isProperty__() {
  }
  
  /**
   * @abstract
   * @param {*} id
   * @return {IdKey}
   * @public
   */
  m_newIdKey__java_lang_Object(id) {
  }
  
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @return {*}
   * @public
   */
  m_readId__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_deser_bean_IdentityDeserializationInfo;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IdentityDeserializationInfo.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(IdentityDeserializationInfo, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo'));


IdentityDeserializationInfo.$markImplementor(/** @type {Function} */ (IdentityDeserializationInfo));


exports = IdentityDeserializationInfo; 
//# sourceMappingURL=IdentityDeserializationInfo.js.map