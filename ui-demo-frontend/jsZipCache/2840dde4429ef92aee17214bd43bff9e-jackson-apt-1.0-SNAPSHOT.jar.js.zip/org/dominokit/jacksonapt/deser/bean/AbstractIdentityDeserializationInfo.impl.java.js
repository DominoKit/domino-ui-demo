/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.bean.AbstractIdentityDeserializationInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.bean.AbstractIdentityDeserializationInfo$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializer$impl');
const IdentityDeserializationInfo = goog.require('org.dominokit.jacksonapt.deser.bean.IdentityDeserializationInfo$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @abstract
 * @template C_T, C_V
 * @extends {HasDeserializer<C_V, JsonDeserializer<C_V>>}
 * @implements {IdentityDeserializationInfo<C_T>}
  */
class AbstractIdentityDeserializationInfo extends HasDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_propertyName__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_;
    /** @public {Class<?>} */
    this.f_type__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_;
    /** @public {Class<?>} */
    this.f_scope__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_;
  }
  
  /**
   * Initialization from constructor 'AbstractIdentityDeserializationInfo(String, Class, Class)'.
   * @param {?string} propertyName
   * @param {Class<?>} type
   * @param {Class<?>} scope
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo__java_lang_String__java_lang_Class__java_lang_Class(propertyName, type, scope) {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_HasDeserializer__();
    this.f_propertyName__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_ = propertyName;
    this.f_type__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_ = type;
    this.f_scope__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_ = scope;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getPropertyName__() {
    return this.f_propertyName__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isProperty__() {
    return false;
  }
  
  /**
   * @override
   * @param {*} id
   * @return {IdKey}
   * @public
   */
  m_newIdKey__java_lang_Object(id) {
    return IdKey.$create__java_lang_Class__java_lang_Class__java_lang_Object(this.f_type__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_, this.f_scope__org_dominokit_jacksonapt_deser_bean_AbstractIdentityDeserializationInfo_, id);
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @return {*}
   * @public
   */
  m_readId__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx) {
    return this.m_getDeserializer__().m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractIdentityDeserializationInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractIdentityDeserializationInfo);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractIdentityDeserializationInfo.$clinit = function() {};
    IdKey = goog.module.get('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
    HasDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractIdentityDeserializationInfo, $Util.$makeClassName('org.dominokit.jacksonapt.deser.bean.AbstractIdentityDeserializationInfo'));


IdentityDeserializationInfo.$markImplementor(AbstractIdentityDeserializationInfo);


exports = AbstractIdentityDeserializationInfo; 
//# sourceMappingURL=AbstractIdentityDeserializationInfo.js.map