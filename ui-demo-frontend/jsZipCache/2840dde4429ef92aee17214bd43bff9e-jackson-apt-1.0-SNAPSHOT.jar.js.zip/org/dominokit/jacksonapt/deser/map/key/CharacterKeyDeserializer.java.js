/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.CharacterKeyDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.CharacterKeyDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer');
const _Character = goog.require('java.lang.Character');
const _j_l_String = goog.require('java.lang.String');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');


// Re-exports the implementation.
var CharacterKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.CharacterKeyDeserializer$impl');
exports = CharacterKeyDeserializer;
 