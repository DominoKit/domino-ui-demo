/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.DateDeserializer');
const _KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer');
const _Date = goog.require('java.util.Date');
const _$Long = goog.require('nativebootstrap.Long');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _DateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$impl');
exports = BaseDateKeyDeserializer;
 