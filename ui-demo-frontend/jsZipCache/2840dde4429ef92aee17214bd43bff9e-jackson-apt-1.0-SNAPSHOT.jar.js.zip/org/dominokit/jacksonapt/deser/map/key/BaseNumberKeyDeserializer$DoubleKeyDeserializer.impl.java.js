/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$DoubleKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.DoubleKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let Double = goog.forwardDeclare('java.lang.Double$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<?number>}
  */
class DoubleKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {DoubleKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    DoubleKeyDeserializer.$clinit();
    return DoubleKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'DoubleKeyDeserializer()'.
   * @return {!DoubleKeyDeserializer}
   * @public
   */
  static $create__() {
    DoubleKeyDeserializer.$clinit();
    let $instance = new DoubleKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DoubleKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {?number}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Double.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {DoubleKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_() {
    return (DoubleKeyDeserializer.$clinit(), DoubleKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_);
  }
  
  /**
   * @param {DoubleKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_(value) {
    (DoubleKeyDeserializer.$clinit(), DoubleKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DoubleKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DoubleKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DoubleKeyDeserializer.$clinit = function() {};
    Double = goog.module.get('java.lang.Double$impl');
    BaseNumberKeyDeserializer.$clinit();
    DoubleKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_ = DoubleKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(DoubleKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$DoubleKeyDeserializer'));


/** @private {DoubleKeyDeserializer} */
DoubleKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_DoubleKeyDeserializer_;




exports = DoubleKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$DoubleKeyDeserializer.js.map