/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.CharacterKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.CharacterKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');

let Character = goog.forwardDeclare('java.lang.Character$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {KeyDeserializer<Character>}
  */
class CharacterKeyDeserializer extends KeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {CharacterKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    CharacterKeyDeserializer.$clinit();
    return CharacterKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'CharacterKeyDeserializer()'.
   * @return {!CharacterKeyDeserializer}
   * @public
   */
  static $create__() {
    CharacterKeyDeserializer.$clinit();
    let $instance = new CharacterKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CharacterKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {Character}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Character.m_valueOf__char(j_l_String.m_charAt__java_lang_String__int(key, 0));
  }
  
  /**
   * @return {CharacterKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_() {
    return (CharacterKeyDeserializer.$clinit(), CharacterKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_);
  }
  
  /**
   * @param {CharacterKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_(value) {
    (CharacterKeyDeserializer.$clinit(), CharacterKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CharacterKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CharacterKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CharacterKeyDeserializer.$clinit = function() {};
    Character = goog.module.get('java.lang.Character$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    KeyDeserializer.$clinit();
    CharacterKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_ = CharacterKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(CharacterKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.CharacterKeyDeserializer'));


/** @private {CharacterKeyDeserializer} */
CharacterKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_CharacterKeyDeserializer_;




exports = CharacterKeyDeserializer; 
//# sourceMappingURL=CharacterKeyDeserializer.js.map