/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer$impl');

let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let KeyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_M, C_K, C_V
 * @extends {JsonDeserializer<C_M>}
  */
class BaseMapJsonDeserializer extends JsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {KeyDeserializer<C_K>} */
    this.f_keyDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer;
    /** @public {JsonDeserializer<C_V>} */
    this.f_valueDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer;
  }
  
  /**
   * Initialization from constructor 'BaseMapJsonDeserializer(KeyDeserializer, JsonDeserializer)'.
   * @param {KeyDeserializer<C_K>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    this.$ctor__org_dominokit_jacksonapt_JsonDeserializer__();
    if ($Equality.$same(null, keyDeserializer)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("keyDeserializer cannot be null"));
    }
    if ($Equality.$same(null, valueDeserializer)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("valueDeserializer cannot be null"));
    }
    this.f_keyDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer = keyDeserializer;
    this.f_valueDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer = valueDeserializer;
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_M}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    let result = this.m_newMap__();
    reader.m_beginObject__();
    while (!$Equality.$same(JsonToken.f_END_OBJECT__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      let name = reader.m_nextName__();
      let key = this.f_keyDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer.m_deserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(name, ctx);
      let value = this.f_valueDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
      /**@type {Map} */ (result).put(key, value);
    }
    reader.m_endObject__();
    return result;
  }
  
  /**
   * @abstract
   * @return {C_M}
   * @public
   */
  m_newMap__() {
  }
  
  /**
   * @param {?string} referenceName
   * @param {*} reference
   * @param {C_M} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    if (!$Equality.$same(null, value)) {
      for (let $iterator = /**@type {Map} */ (value).values().m_iterator__(); $iterator.m_hasNext__(); ) {
        let val = $iterator.m_next__();
        this.f_valueDeserializer__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, val, ctx);
      }
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseMapJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseMapJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseMapJsonDeserializer.$clinit = function() {};
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    JsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseMapJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer'));




exports = BaseMapJsonDeserializer; 
//# sourceMappingURL=BaseMapJsonDeserializer.js.map