/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.EnumKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.EnumKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Enum = goog.forwardDeclare('java.lang.Enum$impl');
let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_E
 * @extends {KeyDeserializer<C_E>}
  */
class EnumKeyDeserializer extends KeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Class<C_E>} */
    this.f_enumClass__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer_;
  }
  
  /**
   * @template M_E
   * @param {Class<M_E>} enumClass
   * @return {EnumKeyDeserializer<M_E>}
   * @public
   */
  static m_newInstance__java_lang_Class(enumClass) {
    EnumKeyDeserializer.$clinit();
    return /**@type {!EnumKeyDeserializer<Enum>} */ (EnumKeyDeserializer.$create__java_lang_Class(enumClass));
  }
  
  /**
   * Factory method corresponding to constructor 'EnumKeyDeserializer(Class)'.
   * @template C_E
   * @param {Class<C_E>} enumClass
   * @return {!EnumKeyDeserializer<C_E>}
   * @public
   */
  static $create__java_lang_Class(enumClass) {
    EnumKeyDeserializer.$clinit();
    let $instance = new EnumKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__java_lang_Class(enumClass);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EnumKeyDeserializer(Class)'.
   * @param {Class<C_E>} enumClass
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__java_lang_Class(enumClass) {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__();
    if ($Equality.$same(null, enumClass)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("enumClass cannot be null"));
    }
    this.f_enumClass__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer_ = enumClass;
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {C_E}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    try {
      return Enum.m_valueOf__java_lang_Class__java_lang_String(this.f_enumClass__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer_, key);
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (IllegalArgumentException.$isInstance(__$exc)) {
        let ex = /**@type {IllegalArgumentException} */ (__$exc);
        if (ctx.m_isReadUnknownEnumValuesAsNull__()) {
          return null;
        }
        throw $Exceptions.toJs(ex);
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @return {Class<C_E>}
   * @public
   */
  m_getEnumClass__() {
    return this.f_enumClass__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EnumKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EnumKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EnumKeyDeserializer.$clinit = function() {};
    Enum = goog.module.get('java.lang.Enum$impl');
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    KeyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EnumKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.EnumKeyDeserializer'));




exports = EnumKeyDeserializer; 
//# sourceMappingURL=EnumKeyDeserializer.js.map