/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.EnumMapJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.EnumMapJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Enum = goog.forwardDeclare('java.lang.Enum$impl');
let EnumMap = goog.forwardDeclare('java.util.EnumMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let EnumKeyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.EnumKeyDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_E, C_V
 * @extends {BaseMapJsonDeserializer<EnumMap<C_E, C_V>, C_E, C_V>}
  */
class EnumMapJsonDeserializer extends BaseMapJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Class<C_E>} */
    this.f_enumClass__org_dominokit_jacksonapt_deser_map_EnumMapJsonDeserializer_;
  }
  
  /**
   * @template M_E, M_V
   * @param {EnumKeyDeserializer<M_E>} keyDeserializer
   * @param {JsonDeserializer<M_V>} valueDeserializer
   * @return {EnumMapJsonDeserializer<M_E, M_V>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    EnumMapJsonDeserializer.$clinit();
    return /**@type {!EnumMapJsonDeserializer<Enum, *>} */ (EnumMapJsonDeserializer.$create__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'EnumMapJsonDeserializer(EnumKeyDeserializer, JsonDeserializer)'.
   * @template C_E, C_V
   * @param {EnumKeyDeserializer<C_E>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {!EnumMapJsonDeserializer<C_E, C_V>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    EnumMapJsonDeserializer.$clinit();
    let $instance = new EnumMapJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_EnumMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EnumMapJsonDeserializer(EnumKeyDeserializer, JsonDeserializer)'.
   * @param {EnumKeyDeserializer<C_E>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_EnumMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_EnumKeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer);
    this.f_enumClass__org_dominokit_jacksonapt_deser_map_EnumMapJsonDeserializer_ = keyDeserializer.m_getEnumClass__();
  }
  
  /**
   * @override
   * @return {EnumMap<C_E, C_V>}
   * @public
   */
  m_newMap__() {
    return /**@type {!EnumMap<C_E, C_V>} */ (EnumMap.$create__java_lang_Class(this.f_enumClass__org_dominokit_jacksonapt_deser_map_EnumMapJsonDeserializer_));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Map} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {EnumMap<C_E, C_V>} */ ($Casts.$to(arg2, EnumMap)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {EnumMap<C_E, C_V>} */ ($Casts.$to(arg2, EnumMap)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EnumMapJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EnumMapJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EnumMapJsonDeserializer.$clinit = function() {};
    EnumMap = goog.module.get('java.util.EnumMap$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseMapJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EnumMapJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.EnumMapJsonDeserializer'));




exports = EnumMapJsonDeserializer; 
//# sourceMappingURL=EnumMapJsonDeserializer.js.map