/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlTimestampKeyDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlTimestampKeyDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer');
const _Timestamp = goog.require('java.sql.Timestamp');
const _Date = goog.require('java.util.Date');
const _$Long = goog.require('nativebootstrap.Long');


// Re-exports the implementation.
var SqlTimestampKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlTimestampKeyDeserializer$impl');
exports = SqlTimestampKeyDeserializer;
 