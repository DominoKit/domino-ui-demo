/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$FloatKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.FloatKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let Float = goog.forwardDeclare('java.lang.Float$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<Float>}
  */
class FloatKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {FloatKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    FloatKeyDeserializer.$clinit();
    return FloatKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'FloatKeyDeserializer()'.
   * @return {!FloatKeyDeserializer}
   * @public
   */
  static $create__() {
    FloatKeyDeserializer.$clinit();
    let $instance = new FloatKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FloatKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {Float}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Float.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {FloatKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_() {
    return (FloatKeyDeserializer.$clinit(), FloatKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_);
  }
  
  /**
   * @param {FloatKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_(value) {
    (FloatKeyDeserializer.$clinit(), FloatKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FloatKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FloatKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FloatKeyDeserializer.$clinit = function() {};
    Float = goog.module.get('java.lang.Float$impl');
    BaseNumberKeyDeserializer.$clinit();
    FloatKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_ = FloatKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(FloatKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$FloatKeyDeserializer'));


/** @private {FloatKeyDeserializer} */
FloatKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_FloatKeyDeserializer_;




exports = FloatKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$FloatKeyDeserializer.js.map