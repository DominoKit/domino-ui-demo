/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.JsDateKeyParser.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.JsDateKeyParser');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _Long = goog.require('java.lang.Long');
const _NumberFormatException = goog.require('java.lang.NumberFormatException');
const _j_l_String = goog.require('java.lang.String');
const _Date = goog.require('java.util.Date');
const _DateDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.DateDeserializer');
const _JsonDeserializationException = goog.require('org.dominokit.jacksonapt.exception.JsonDeserializationException');
const _DateTimeFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat');
const _PredefinedFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat.PredefinedFormat');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var JsDateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.JsDateKeyParser$impl');
exports = JsDateKeyParser;
 