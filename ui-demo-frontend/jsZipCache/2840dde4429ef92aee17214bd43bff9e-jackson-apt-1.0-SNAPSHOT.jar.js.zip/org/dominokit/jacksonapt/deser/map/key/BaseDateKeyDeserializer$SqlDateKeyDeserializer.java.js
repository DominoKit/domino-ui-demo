/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlDateKeyDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlDateKeyDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer');
const _Date = goog.require('java.sql.Date');
const _j_u_Date = goog.require('java.util.Date');
const _$Long = goog.require('nativebootstrap.Long');


// Re-exports the implementation.
var SqlDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlDateKeyDeserializer$impl');
exports = SqlDateKeyDeserializer;
 