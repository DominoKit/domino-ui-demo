/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');

let Number = goog.forwardDeclare('java.lang.Number$impl');


/**
 * @abstract
 * @template C_N
 * @extends {KeyDeserializer<C_N>}
  */
class BaseNumberKeyDeserializer extends KeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'BaseNumberKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseNumberKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseNumberKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseNumberKeyDeserializer.$clinit = function() {};
    KeyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseNumberKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer'));




exports = BaseNumberKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer.js.map