/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$ByteKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer.ByteKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseNumberKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$impl');

let Byte = goog.forwardDeclare('java.lang.Byte$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');


/**
 * @extends {BaseNumberKeyDeserializer<Byte>}
  */
class ByteKeyDeserializer extends BaseNumberKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {ByteKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    ByteKeyDeserializer.$clinit();
    return ByteKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'ByteKeyDeserializer()'.
   * @return {!ByteKeyDeserializer}
   * @public
   */
  static $create__() {
    ByteKeyDeserializer.$clinit();
    let $instance = new ByteKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ByteKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {?string} key
   * @param {JsonDeserializationContext} ctx
   * @return {Byte}
   * @public
   */
  m_doDeserialize__java_lang_String__org_dominokit_jacksonapt_JsonDeserializationContext(key, ctx) {
    return Byte.m_valueOf__java_lang_String(key);
  }
  
  /**
   * @return {ByteKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_() {
    return (ByteKeyDeserializer.$clinit(), ByteKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_);
  }
  
  /**
   * @param {ByteKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_(value) {
    (ByteKeyDeserializer.$clinit(), ByteKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ByteKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ByteKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ByteKeyDeserializer.$clinit = function() {};
    Byte = goog.module.get('java.lang.Byte$impl');
    BaseNumberKeyDeserializer.$clinit();
    ByteKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_ = ByteKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(ByteKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseNumberKeyDeserializer$ByteKeyDeserializer'));


/** @private {ByteKeyDeserializer} */
ByteKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseNumberKeyDeserializer_ByteKeyDeserializer_;




exports = ByteKeyDeserializer; 
//# sourceMappingURL=BaseNumberKeyDeserializer$ByteKeyDeserializer.js.map