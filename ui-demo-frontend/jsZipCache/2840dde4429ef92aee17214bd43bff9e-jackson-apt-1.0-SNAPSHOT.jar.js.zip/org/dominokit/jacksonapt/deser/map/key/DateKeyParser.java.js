/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.DateKeyParser.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.DateKeyParser');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Date = goog.require('java.util.Date');
const _DateDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.DateDeserializer');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser.$LambdaAdaptor');


// Re-exports the implementation.
var DateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$impl');
exports = DateKeyParser;
 