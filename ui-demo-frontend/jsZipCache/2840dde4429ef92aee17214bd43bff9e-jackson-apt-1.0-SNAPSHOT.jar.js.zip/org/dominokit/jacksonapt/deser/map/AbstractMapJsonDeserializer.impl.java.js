/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.AbstractMapJsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.AbstractMapJsonDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer$impl');

let AbstractMap = goog.forwardDeclare('java.util.AbstractMap$impl');
let LinkedHashMap = goog.forwardDeclare('java.util.LinkedHashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let KeyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_K, C_V
 * @extends {BaseMapJsonDeserializer<AbstractMap<C_K, C_V>, C_K, C_V>}
  */
class AbstractMapJsonDeserializer extends BaseMapJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @template M_K, M_V
   * @param {KeyDeserializer<M_K>} keyDeserializer
   * @param {JsonDeserializer<M_V>} valueDeserializer
   * @return {AbstractMapJsonDeserializer<M_K, M_V>}
   * @public
   */
  static m_newInstance__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    AbstractMapJsonDeserializer.$clinit();
    return /**@type {!AbstractMapJsonDeserializer<*, *>} */ (AbstractMapJsonDeserializer.$create__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer));
  }
  
  /**
   * Factory method corresponding to constructor 'AbstractMapJsonDeserializer(KeyDeserializer, JsonDeserializer)'.
   * @template C_K, C_V
   * @param {KeyDeserializer<C_K>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {!AbstractMapJsonDeserializer<C_K, C_V>}
   * @public
   */
  static $create__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    AbstractMapJsonDeserializer.$clinit();
    let $instance = new AbstractMapJsonDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_AbstractMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AbstractMapJsonDeserializer(KeyDeserializer, JsonDeserializer)'.
   * @param {KeyDeserializer<C_K>} keyDeserializer
   * @param {JsonDeserializer<C_V>} valueDeserializer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_AbstractMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer) {
    this.$ctor__org_dominokit_jacksonapt_deser_map_BaseMapJsonDeserializer__org_dominokit_jacksonapt_deser_map_key_KeyDeserializer__org_dominokit_jacksonapt_JsonDeserializer(keyDeserializer, valueDeserializer);
  }
  
  /**
   * @override
   * @return {AbstractMap<C_K, C_V>}
   * @public
   */
  m_newMap__() {
    return /**@type {!LinkedHashMap<C_K, C_V>} */ (LinkedHashMap.$create__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {Map} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractMap<C_K, C_V>} */ ($Casts.$to(arg2, AbstractMap)), arg3);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {?string} arg0
   * @param {*} arg1
   * @param {*} arg2
   * @param {JsonDeserializationContext} arg3
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2, arg3) {
    super.m_setBackReference__java_lang_String__java_lang_Object__java_util_Map__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, /**@type {AbstractMap<C_K, C_V>} */ ($Casts.$to(arg2, AbstractMap)), arg3);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractMapJsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractMapJsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractMapJsonDeserializer.$clinit = function() {};
    AbstractMap = goog.module.get('java.util.AbstractMap$impl');
    LinkedHashMap = goog.module.get('java.util.LinkedHashMap$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseMapJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractMapJsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.AbstractMapJsonDeserializer'));




exports = AbstractMapJsonDeserializer; 
//# sourceMappingURL=AbstractMapJsonDeserializer.js.map