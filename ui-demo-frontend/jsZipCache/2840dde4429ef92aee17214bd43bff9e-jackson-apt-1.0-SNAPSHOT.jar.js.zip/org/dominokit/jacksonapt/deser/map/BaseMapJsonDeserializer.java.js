/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _KeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.KeyDeserializer');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');
const _JsonToken = goog.require('org.dominokit.jacksonapt.stream.JsonToken');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var BaseMapJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.BaseMapJsonDeserializer$impl');
exports = BaseMapJsonDeserializer;
 