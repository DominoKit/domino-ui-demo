/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$DateKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.DateKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');


/**
 * @extends {BaseDateKeyDeserializer<Date>}
  */
class DateKeyDeserializer extends BaseDateKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {DateKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    DateKeyDeserializer.$clinit();
    return DateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'DateKeyDeserializer()'.
   * @return {!DateKeyDeserializer}
   * @public
   */
  static $create__() {
    DateKeyDeserializer.$clinit();
    let $instance = new DateKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @return {Date}
   * @public
   */
  m_deserializeMillis__long(millis) {
    return Date.$create__long(millis);
  }
  
  /**
   * @override
   * @param {Date} date
   * @return {Date}
   * @public
   */
  m_deserializeDate__java_util_Date(date) {
    return date;
  }
  
  /**
   * @return {DateKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_() {
    return (DateKeyDeserializer.$clinit(), DateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_);
  }
  
  /**
   * @param {DateKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_(value) {
    (DateKeyDeserializer.$clinit(), DateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateKeyDeserializer.$clinit = function() {};
    Date = goog.module.get('java.util.Date$impl');
    BaseDateKeyDeserializer.$clinit();
    DateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_ = DateKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(DateKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$DateKeyDeserializer'));


/** @private {DateKeyDeserializer} */
DateKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_DateKeyDeserializer_;




exports = DateKeyDeserializer; 
//# sourceMappingURL=BaseDateKeyDeserializer$DateKeyDeserializer.js.map