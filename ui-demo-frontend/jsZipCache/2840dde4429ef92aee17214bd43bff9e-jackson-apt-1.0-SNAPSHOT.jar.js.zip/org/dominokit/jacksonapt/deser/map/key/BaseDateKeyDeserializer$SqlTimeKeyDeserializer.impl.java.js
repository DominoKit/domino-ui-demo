/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlTimeKeyDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer.SqlTimeKeyDeserializer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDateKeyDeserializer = goog.require('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$impl');

let Time = goog.forwardDeclare('java.sql.Time$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');


/**
 * @extends {BaseDateKeyDeserializer<Time>}
  */
class SqlTimeKeyDeserializer extends BaseDateKeyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {SqlTimeKeyDeserializer}
   * @public
   */
  static m_getInstance__() {
    SqlTimeKeyDeserializer.$clinit();
    return SqlTimeKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_;
  }
  
  /**
   * Factory method corresponding to constructor 'SqlTimeKeyDeserializer()'.
   * @return {!SqlTimeKeyDeserializer}
   * @public
   */
  static $create__() {
    SqlTimeKeyDeserializer.$clinit();
    let $instance = new SqlTimeKeyDeserializer();
    $instance.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SqlTimeKeyDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer__() {
    this.$ctor__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer__();
  }
  
  /**
   * @override
   * @param {!$Long} millis
   * @return {Time}
   * @public
   */
  m_deserializeMillis__long(millis) {
    return Time.$create__long(millis);
  }
  
  /**
   * @override
   * @param {Date} date
   * @return {Time}
   * @public
   */
  m_deserializeDate__java_util_Date(date) {
    return this.m_deserializeMillis__long(date.m_getTime__());
  }
  
  /**
   * @return {SqlTimeKeyDeserializer}
   * @public
   */
  static get f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_() {
    return (SqlTimeKeyDeserializer.$clinit(), SqlTimeKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_);
  }
  
  /**
   * @param {SqlTimeKeyDeserializer} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_(value) {
    (SqlTimeKeyDeserializer.$clinit(), SqlTimeKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SqlTimeKeyDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SqlTimeKeyDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SqlTimeKeyDeserializer.$clinit = function() {};
    Time = goog.module.get('java.sql.Time$impl');
    BaseDateKeyDeserializer.$clinit();
    SqlTimeKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_ = SqlTimeKeyDeserializer.$create__();
  }
  
  
};

$Util.$setClassMetadata(SqlTimeKeyDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.deser.map.key.BaseDateKeyDeserializer$SqlTimeKeyDeserializer'));


/** @private {SqlTimeKeyDeserializer} */
SqlTimeKeyDeserializer.$f_INSTANCE__org_dominokit_jacksonapt_deser_map_key_BaseDateKeyDeserializer_SqlTimeKeyDeserializer_;




exports = SqlTimeKeyDeserializer; 
//# sourceMappingURL=BaseDateKeyDeserializer$SqlTimeKeyDeserializer.js.map