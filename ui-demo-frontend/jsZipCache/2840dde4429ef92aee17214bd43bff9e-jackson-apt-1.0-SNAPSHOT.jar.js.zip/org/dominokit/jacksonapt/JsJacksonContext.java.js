/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsJacksonContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JsJacksonContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JacksonContext = goog.require('org.dominokit.jacksonapt.JacksonContext');
const _GwtJacksonJsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters');
const _GwtJacksonJsonSerializerParameters = goog.require('org.dominokit.jacksonapt.GwtJacksonJsonSerializerParameters');
const _DateFormat = goog.require('org.dominokit.jacksonapt.JacksonContext.DateFormat');
const _DoubleArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader');
const _IntegerArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader');
const _IntegerStackFactory = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory');
const _MapLikeFactory = goog.require('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory');
const _ShortArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader');
const _StringArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.StringArrayReader');
const _ValueStringifier = goog.require('org.dominokit.jacksonapt.JacksonContext.ValueStringifier');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters');
const _JsDoubleArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsDoubleArrayReader');
const _JsIntegerArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader');
const _JsShortArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader');
const _JsStringArrayReader = goog.require('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader');
const _JsMapLike = goog.require('org.dominokit.jacksonapt.deser.bean.JsMapLike');
const _JsIntegerStack = goog.require('org.dominokit.jacksonapt.stream.impl.JsIntegerStack');
const _JsDateFormat = goog.require('org.dominokit.jacksonapt.utils.JsDateFormat');


// Re-exports the implementation.
var JsJacksonContext = goog.require('org.dominokit.jacksonapt.JsJacksonContext$impl');
exports = JsJacksonContext;
 