/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonSerializationContext$DefaultBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonSerializationContext.DefaultBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Builder = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder');


// Re-exports the implementation.
var DefaultBuilder = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext.DefaultBuilder$impl');
exports = DefaultBuilder;
 