/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonDeserializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsonDeserializer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonDeserializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let JsonToken = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonToken$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @abstract
 * @template C_T
  */
class JsonDeserializer extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'JsonDeserializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_JsonDeserializer__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @return {C_T}
   * @public
   */
  m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext(reader, ctx) {
    return this.m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, ctx.m_defaultParameters__());
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_deserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(JsonToken.f_NULL__org_dominokit_jacksonapt_stream_JsonToken, reader.m_peek__())) {
      return this.m_deserializeNullValue__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
    }
    return this.m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params);
  }
  
  /**
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_deserializeNullValue__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
    reader.m_skipValue__();
    return null;
  }
  
  /**
   * @abstract
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @return {C_T}
   * @public
   */
  m_doDeserialize__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters(reader, ctx, params) {
  }
  
  /**
   * @param {?string} referenceName
   * @param {*} reference
   * @param {C_T} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setBackReference__java_lang_String__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(referenceName, reference, value, ctx) {
    throw $Exceptions.toJs(JsonDeserializationException.$create__java_lang_String("Cannot set a back reference to the type managed by this deserializer"));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsonDeserializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsonDeserializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonDeserializer.$clinit = function() {};
    JsonDeserializationException = goog.module.get('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
    JsonToken = goog.module.get('org.dominokit.jacksonapt.stream.JsonToken$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsonDeserializer, $Util.$makeClassName('org.dominokit.jacksonapt.JsonDeserializer'));




exports = JsonDeserializer; 
//# sourceMappingURL=JsonDeserializer.js.map