/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.ServerJacksonContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.ServerJacksonContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const JsJacksonContext = goog.require('org.dominokit.jacksonapt.JsJacksonContext$impl');


class ServerJacksonContext extends JsJacksonContext {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ServerJacksonContext()'.
   * @return {!ServerJacksonContext}
   * @public
   */
  static $create__() {
    ServerJacksonContext.$clinit();
    let $instance = new ServerJacksonContext();
    $instance.$ctor__org_dominokit_jacksonapt_ServerJacksonContext__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerJacksonContext()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_ServerJacksonContext__() {
    this.$ctor__org_dominokit_jacksonapt_JsJacksonContext__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerJacksonContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerJacksonContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerJacksonContext.$clinit = function() {};
    JsJacksonContext.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerJacksonContext, $Util.$makeClassName('org.dominokit.jacksonapt.ServerJacksonContext'));




exports = ServerJacksonContext; 
//# sourceMappingURL=ServerJacksonContext.js.map