/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$DateFormat.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.DateFormat$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let JsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializerParameters$impl');
let DateKeyParser = goog.forwardDeclare('org.dominokit.jacksonapt.deser.map.key.DateKeyParser$impl');


/**
 * @interface
 */
class DateFormat {
  /**
   * @abstract
   * @param {Date} date
   * @return {?string}
   * @public
   */
  m_format__java_util_Date(date) {
  }
  
  /**
   * @abstract
   * @param {JsonSerializerParameters} params
   * @param {Date} date
   * @return {?string}
   * @public
   */
  m_format__org_dominokit_jacksonapt_JsonSerializerParameters__java_util_Date(params, date) {
  }
  
  /**
   * @abstract
   * @param {boolean} useBrowserTimezone
   * @param {?string} pattern
   * @param {?boolean} hasTz
   * @param {?string} date
   * @return {Date}
   * @public
   */
  m_parse__boolean__java_lang_String__java_lang_Boolean__java_lang_String(useBrowserTimezone, pattern, hasTz, date) {
  }
  
  /**
   * @abstract
   * @template M_DateFormat_makeDateKeyParser_D
   * @return {DateKeyParser<M_DateFormat_makeDateKeyParser_D>}
   * @public
   */
  m_makeDateKeyParser__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_DateFormat = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_DateFormat;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_DateFormat;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DateFormat.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(DateFormat, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$DateFormat'));


DateFormat.$markImplementor(/** @type {Function} */ (DateFormat));


exports = DateFormat; 
//# sourceMappingURL=JacksonContext$DateFormat.js.map