/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonSerializationContext$DefaultBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonSerializationContext.DefaultBuilder$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Builder = goog.require('org.dominokit.jacksonapt.DefaultJsonSerializationContext.Builder$impl');


class DefaultBuilder extends Builder {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultBuilder()'.
   * @return {!DefaultBuilder}
   * @public
   */
  static $create__() {
    DefaultBuilder.$clinit();
    let $instance = new DefaultBuilder();
    $instance.$ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext_DefaultBuilder__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultBuilder()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext_DefaultBuilder__() {
    this.$ctor__org_dominokit_jacksonapt_DefaultJsonSerializationContext_Builder__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultBuilder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultBuilder.$clinit = function() {};
    Builder.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DefaultBuilder, $Util.$makeClassName('org.dominokit.jacksonapt.DefaultJsonSerializationContext$DefaultBuilder'));




exports = DefaultBuilder; 
//# sourceMappingURL=DefaultJsonSerializationContext$DefaultBuilder.js.map