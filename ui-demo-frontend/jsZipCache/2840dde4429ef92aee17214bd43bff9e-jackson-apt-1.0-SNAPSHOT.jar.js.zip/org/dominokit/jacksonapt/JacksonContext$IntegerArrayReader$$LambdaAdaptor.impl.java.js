/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$IntegerArrayReader$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IntegerArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader$impl');

let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @implements {IntegerArrayReader}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(JsonReader):Array<number>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(JsonReader):Array<number>} */
    this.f_$$fn__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$LambdaAdaptor;
    this.$ctor__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$LambdaAdaptor__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(JsonReader):Array<number>} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$LambdaAdaptor__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {JsonReader} arg0
   * @return {Array<number>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(arg0) {
    let /** ?function(JsonReader):Array<number> */ $function;
    return ($function = this.f_$$fn__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$IntegerArrayReader$$LambdaAdaptor'));


IntegerArrayReader.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=JacksonContext$IntegerArrayReader$$LambdaAdaptor.js.map