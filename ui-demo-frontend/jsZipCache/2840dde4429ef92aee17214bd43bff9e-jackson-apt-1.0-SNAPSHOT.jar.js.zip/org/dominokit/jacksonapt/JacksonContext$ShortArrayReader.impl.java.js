/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$ShortArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader.$LambdaAdaptor$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 */
class ShortArrayReader {
  /**
   * @abstract
   * @param {JsonReader} reader
   * @return {Array<number>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
  }
  
  /**
   * @param {?function(JsonReader):Array<number>} fn
   * @return {ShortArrayReader}
   * @public
   */
  static $adapt(fn) {
    ShortArrayReader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_ShortArrayReader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_ShortArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_ShortArrayReader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ShortArrayReader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ShortArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$ShortArrayReader'));


ShortArrayReader.$markImplementor(/** @type {Function} */ (ShortArrayReader));


exports = ShortArrayReader; 
//# sourceMappingURL=JacksonContext$ShortArrayReader.js.map