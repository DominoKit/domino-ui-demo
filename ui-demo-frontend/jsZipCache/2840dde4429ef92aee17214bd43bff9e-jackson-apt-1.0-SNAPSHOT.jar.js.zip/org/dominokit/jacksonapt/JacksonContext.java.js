/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateFormat = goog.require('org.dominokit.jacksonapt.JacksonContext.DateFormat');
const _DoubleArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader');
const _IntegerArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader');
const _IntegerStackFactory = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory');
const _MapLikeFactory = goog.require('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory');
const _ShortArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader');
const _StringArrayReader = goog.require('org.dominokit.jacksonapt.JacksonContext.StringArrayReader');
const _ValueStringifier = goog.require('org.dominokit.jacksonapt.JacksonContext.ValueStringifier');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters');


// Re-exports the implementation.
var JacksonContext = goog.require('org.dominokit.jacksonapt.JacksonContext$impl');
exports = JacksonContext;
 