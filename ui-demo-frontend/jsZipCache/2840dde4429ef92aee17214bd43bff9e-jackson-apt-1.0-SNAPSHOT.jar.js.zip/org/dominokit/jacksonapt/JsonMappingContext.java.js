/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsonMappingContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JsonMappingContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Logger = goog.require('java.util.logging.Logger');
const _$LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JsonMappingContext.$LambdaAdaptor');


// Re-exports the implementation.
var JsonMappingContext = goog.require('org.dominokit.jacksonapt.JsonMappingContext$impl');
exports = JsonMappingContext;
 