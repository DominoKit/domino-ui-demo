/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.GwtJacksonJsonSerializerParameters.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.GwtJacksonJsonSerializerParameters$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters$impl');

let Shape = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');
let Include = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let IdentitySerializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.IdentitySerializationInfo$impl');
let TypeSerializationInfo = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.TypeSerializationInfo$impl');
let TimeZone = goog.forwardDeclare('org.gwtproject.i18n.client.TimeZone$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {JsonSerializerParameters}
  */
class GwtJacksonJsonSerializerParameters extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_pattern__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {Shape} */
    this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {?string} */
    this.f_locale__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {TimeZone} */
    this.f_timezone__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {Set<?string>} */
    this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {Include} */
    this.f_include__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {IdentitySerializationInfo} */
    this.f_identityInfo__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {TypeSerializationInfo} */
    this.f_typeInfo__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
    /** @public {boolean} */
    this.f_unwrapped__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'GwtJacksonJsonSerializerParameters()'.
   * @return {!GwtJacksonJsonSerializerParameters}
   * @public
   */
  static $create__() {
    GwtJacksonJsonSerializerParameters.$clinit();
    let $instance = new GwtJacksonJsonSerializerParameters();
    $instance.$ctor__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GwtJacksonJsonSerializerParameters()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getPattern__() {
    return this.f_pattern__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {?string} pattern
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setPattern__java_lang_String(pattern) {
    this.f_pattern__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = pattern;
    return this;
  }
  
  /**
   * @override
   * @return {Shape}
   * @public
   */
  m_getShape__() {
    return this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {Shape} shape
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setShape__com_fasterxml_jackson_annotation_JsonFormat_Shape(shape) {
    this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = shape;
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getLocale__() {
    return this.f_locale__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {?string} locale
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setLocale__java_lang_String(locale) {
    this.f_locale__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = locale;
    return this;
  }
  
  /**
   * @override
   * @return {TimeZone}
   * @public
   */
  m_getTimezone__() {
    return this.f_timezone__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {*} timezone
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setTimezone__java_lang_Object(timezone) {
    this.f_timezone__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = /**@type {TimeZone} */ ($Casts.$to(timezone, TimeZone));
    return this;
  }
  
  /**
   * @override
   * @return {Set<?string>}
   * @public
   */
  m_getIgnoredProperties__() {
    return this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {?string} ignoredProperty
   * @return {JsonSerializerParameters}
   * @public
   */
  m_addIgnoredProperty__java_lang_String(ignoredProperty) {
    if ($Equality.$same(null, this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_)) {
      this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = /**@type {!HashSet<?string>} */ (HashSet.$create__());
    }
    this.f_ignoredProperties__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_.add(ignoredProperty);
    return this;
  }
  
  /**
   * @override
   * @return {Include}
   * @public
   */
  m_getInclude__() {
    return this.f_include__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {Include} include
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setInclude__com_fasterxml_jackson_annotation_JsonInclude_Include(include) {
    this.f_include__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = include;
    return this;
  }
  
  /**
   * @override
   * @return {IdentitySerializationInfo}
   * @public
   */
  m_getIdentityInfo__() {
    return this.f_identityInfo__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {IdentitySerializationInfo} identityInfo
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setIdentityInfo__org_dominokit_jacksonapt_ser_bean_IdentitySerializationInfo(identityInfo) {
    this.f_identityInfo__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = identityInfo;
    return this;
  }
  
  /**
   * @override
   * @return {TypeSerializationInfo}
   * @public
   */
  m_getTypeInfo__() {
    return this.f_typeInfo__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {TypeSerializationInfo} typeInfo
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setTypeInfo__org_dominokit_jacksonapt_ser_bean_TypeSerializationInfo(typeInfo) {
    this.f_typeInfo__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = typeInfo;
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isUnwrapped__() {
    return this.f_unwrapped__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_;
  }
  
  /**
   * @override
   * @param {boolean} unwrapped
   * @return {JsonSerializerParameters}
   * @public
   */
  m_setUnwrapped__boolean(unwrapped) {
    this.f_unwrapped__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = unwrapped;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters() {
    this.f_shape__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = Shape.f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape;
    this.f_unwrapped__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters_ = false;
  }
  
  /**
   * @return {JsonSerializerParameters}
   * @public
   */
  static get f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters() {
    return (GwtJacksonJsonSerializerParameters.$clinit(), GwtJacksonJsonSerializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters);
  }
  
  /**
   * @param {JsonSerializerParameters} value
   * @return {void}
   * @public
   */
  static set f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters(value) {
    (GwtJacksonJsonSerializerParameters.$clinit(), GwtJacksonJsonSerializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GwtJacksonJsonSerializerParameters;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GwtJacksonJsonSerializerParameters);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GwtJacksonJsonSerializerParameters.$clinit = function() {};
    Shape = goog.module.get('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    TimeZone = goog.module.get('org.gwtproject.i18n.client.TimeZone$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    GwtJacksonJsonSerializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters = GwtJacksonJsonSerializerParameters.$create__();
  }
  
  
};

$Util.$setClassMetadata(GwtJacksonJsonSerializerParameters, $Util.$makeClassName('org.dominokit.jacksonapt.GwtJacksonJsonSerializerParameters'));


/** @private {JsonSerializerParameters} */
GwtJacksonJsonSerializerParameters.$f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters;


JsonSerializerParameters.$markImplementor(GwtJacksonJsonSerializerParameters);


exports = GwtJacksonJsonSerializerParameters; 
//# sourceMappingURL=GwtJacksonJsonSerializerParameters.js.map