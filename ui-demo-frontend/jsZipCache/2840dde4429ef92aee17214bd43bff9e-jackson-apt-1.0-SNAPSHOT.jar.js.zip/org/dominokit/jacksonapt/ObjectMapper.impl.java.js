/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.ObjectMapper.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.ObjectMapper$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ObjectReader = goog.require('org.dominokit.jacksonapt.ObjectReader$impl');
const ObjectWriter = goog.require('org.dominokit.jacksonapt.ObjectWriter$impl');


/**
 * @interface
 * @template C_T
 * @extends {ObjectReader<C_T>}
 * @extends {ObjectWriter<C_T>}
 */
class ObjectMapper {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ObjectReader.$markImplementor(classConstructor);
    ObjectWriter.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_ObjectMapper = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_ObjectMapper;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_ObjectMapper;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ObjectMapper.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ObjectMapper, $Util.$makeClassName('org.dominokit.jacksonapt.ObjectMapper'));


ObjectMapper.$markImplementor(/** @type {Function} */ (ObjectMapper));


exports = ObjectMapper; 
//# sourceMappingURL=ObjectMapper.js.map