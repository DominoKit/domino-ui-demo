/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$DateFormat.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.DateFormat');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Date = goog.require('java.util.Date');
const _JsonSerializerParameters = goog.require('org.dominokit.jacksonapt.JsonSerializerParameters');
const _DateKeyParser = goog.require('org.dominokit.jacksonapt.deser.map.key.DateKeyParser');


// Re-exports the implementation.
var DateFormat = goog.require('org.dominokit.jacksonapt.JacksonContext.DateFormat$impl');
exports = DateFormat;
 