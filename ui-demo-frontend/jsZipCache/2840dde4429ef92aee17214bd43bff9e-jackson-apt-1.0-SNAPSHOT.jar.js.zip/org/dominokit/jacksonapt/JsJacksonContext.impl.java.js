/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JsJacksonContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JsJacksonContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const JacksonContext = goog.require('org.dominokit.jacksonapt.JacksonContext$impl');

let GwtJacksonJsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters$impl');
let GwtJacksonJsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.GwtJacksonJsonSerializerParameters$impl');
let DateFormat = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.DateFormat$impl');
let DoubleArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.DoubleArrayReader$impl');
let IntegerArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader$impl');
let IntegerStackFactory = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory$impl');
let MapLikeFactory = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory$impl');
let ShortArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.ShortArrayReader$impl');
let StringArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.StringArrayReader$impl');
let ValueStringifier = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.ValueStringifier$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonSerializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializerParameters$impl');
let JsDoubleArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.cast.JsDoubleArrayReader$impl');
let JsIntegerArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader$impl');
let JsShortArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader$impl');
let JsStringArrayReader = goog.forwardDeclare('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader$impl');
let JsMapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.JsMapLike$impl');
let JsIntegerStack = goog.forwardDeclare('org.dominokit.jacksonapt.stream.impl.JsIntegerStack$impl');
let JsDateFormat = goog.forwardDeclare('org.dominokit.jacksonapt.utils.JsDateFormat$impl');


/**
 * @implements {JacksonContext}
  */
class JsJacksonContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'JsJacksonContext()'.
   * @return {!JsJacksonContext}
   * @public
   */
  static $create__() {
    JsJacksonContext.$clinit();
    let $instance = new JsJacksonContext();
    $instance.$ctor__org_dominokit_jacksonapt_JsJacksonContext__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JsJacksonContext()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_JsJacksonContext__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {DateFormat}
   * @public
   */
  m_dateFormat__() {
    return JsDateFormat.$create__();
  }
  
  /**
   * @override
   * @return {IntegerStackFactory}
   * @public
   */
  m_integerStackFactory__() {
    return IntegerStackFactory.$adapt((() =>{
      return JsIntegerStack.$create__();
    }));
  }
  
  /**
   * @override
   * @return {MapLikeFactory}
   * @public
   */
  m_mapLikeFactory__() {
    return MapLikeFactory.$adapt((() =>{
      return /**@type {!JsMapLike<*>} */ (JsMapLike.$create__());
    }));
  }
  
  /**
   * @override
   * @return {ValueStringifier}
   * @public
   */
  m_stringifier__() {
    return ValueStringifier.$adapt(((/** ?string */ value) =>{
      return window.JSON.stringify(value);
    }));
  }
  
  /**
   * @override
   * @return {StringArrayReader}
   * @public
   */
  m_stringArrayReader__() {
    return JsStringArrayReader.$create__();
  }
  
  /**
   * @override
   * @return {ShortArrayReader}
   * @public
   */
  m_shortArrayReader__() {
    return JsShortArrayReader.$create__();
  }
  
  /**
   * @override
   * @return {IntegerArrayReader}
   * @public
   */
  m_integerArrayReader__() {
    return JsIntegerArrayReader.$create__();
  }
  
  /**
   * @override
   * @return {DoubleArrayReader}
   * @public
   */
  m_doubleArrayReader__() {
    return JsDoubleArrayReader.$create__();
  }
  
  /**
   * @override
   * @return {JsonSerializerParameters}
   * @public
   */
  m_defaultSerializerParameters__() {
    return GwtJacksonJsonSerializerParameters.f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonSerializerParameters;
  }
  
  /**
   * @override
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_defaultDeserializerParameters__() {
    return GwtJacksonJsonDeserializerParameters.f_DEFAULT__org_dominokit_jacksonapt_GwtJacksonJsonDeserializerParameters;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsJacksonContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsJacksonContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsJacksonContext.$clinit = function() {};
    GwtJacksonJsonDeserializerParameters = goog.module.get('org.dominokit.jacksonapt.GwtJacksonJsonDeserializerParameters$impl');
    GwtJacksonJsonSerializerParameters = goog.module.get('org.dominokit.jacksonapt.GwtJacksonJsonSerializerParameters$impl');
    IntegerStackFactory = goog.module.get('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory$impl');
    MapLikeFactory = goog.module.get('org.dominokit.jacksonapt.JacksonContext.MapLikeFactory$impl');
    ValueStringifier = goog.module.get('org.dominokit.jacksonapt.JacksonContext.ValueStringifier$impl');
    JsDoubleArrayReader = goog.module.get('org.dominokit.jacksonapt.deser.array.cast.JsDoubleArrayReader$impl');
    JsIntegerArrayReader = goog.module.get('org.dominokit.jacksonapt.deser.array.cast.JsIntegerArrayReader$impl');
    JsShortArrayReader = goog.module.get('org.dominokit.jacksonapt.deser.array.cast.JsShortArrayReader$impl');
    JsStringArrayReader = goog.module.get('org.dominokit.jacksonapt.deser.array.cast.JsStringArrayReader$impl');
    JsMapLike = goog.module.get('org.dominokit.jacksonapt.deser.bean.JsMapLike$impl');
    JsIntegerStack = goog.module.get('org.dominokit.jacksonapt.stream.impl.JsIntegerStack$impl');
    JsDateFormat = goog.module.get('org.dominokit.jacksonapt.utils.JsDateFormat$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsJacksonContext, $Util.$makeClassName('org.dominokit.jacksonapt.JsJacksonContext'));


JacksonContext.$markImplementor(JsJacksonContext);


exports = JsJacksonContext; 
//# sourceMappingURL=JsJacksonContext.js.map