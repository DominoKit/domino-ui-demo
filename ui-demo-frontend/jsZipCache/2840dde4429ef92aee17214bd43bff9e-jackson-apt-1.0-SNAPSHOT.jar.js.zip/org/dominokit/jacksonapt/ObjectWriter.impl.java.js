/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.ObjectWriter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.ObjectWriter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');


/**
 * @interface
 * @template C_T
 */
class ObjectWriter {
  /**
   * @abstract
   * @param {C_T} value
   * @return {?string}
   * @public
   */
  m_write__java_lang_Object(value) {
  }
  
  /**
   * @abstract
   * @param {C_T} value
   * @param {JsonSerializationContext} ctx
   * @return {?string}
   * @public
   */
  m_write__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(value, ctx) {
  }
  
  /**
   * @abstract
   * @return {JsonSerializer<C_T>}
   * @public
   */
  m_getSerializer__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_ObjectWriter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_ObjectWriter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_ObjectWriter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ObjectWriter.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ObjectWriter, $Util.$makeClassName('org.dominokit.jacksonapt.ObjectWriter'));


ObjectWriter.$markImplementor(/** @type {Function} */ (ObjectWriter));


exports = ObjectWriter; 
//# sourceMappingURL=ObjectWriter.js.map