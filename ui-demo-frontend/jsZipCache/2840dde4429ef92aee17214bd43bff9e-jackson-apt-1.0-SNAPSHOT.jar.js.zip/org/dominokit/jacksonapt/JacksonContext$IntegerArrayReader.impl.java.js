/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$IntegerArrayReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader.$LambdaAdaptor$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @interface
 */
class IntegerArrayReader {
  /**
   * @abstract
   * @param {JsonReader} reader
   * @return {Array<number>}
   * @public
   */
  m_readArray__org_dominokit_jacksonapt_stream_JsonReader(reader) {
  }
  
  /**
   * @param {?function(JsonReader):Array<number>} fn
   * @return {IntegerArrayReader}
   * @public
   */
  static $adapt(fn) {
    IntegerArrayReader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_jacksonapt_JacksonContext_IntegerArrayReader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IntegerArrayReader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.jacksonapt.JacksonContext.IntegerArrayReader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(IntegerArrayReader, $Util.$makeClassName('org.dominokit.jacksonapt.JacksonContext$IntegerArrayReader'));


IntegerArrayReader.$markImplementor(/** @type {Function} */ (IntegerArrayReader));


exports = IntegerArrayReader; 
//# sourceMappingURL=JacksonContext$IntegerArrayReader.js.map