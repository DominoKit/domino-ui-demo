/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.Serializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.Serializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Equality = goog.require('nativebootstrap.Equality');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _KeySerializer = goog.require('org.dominokit.jacksonapt.ser.map.key.KeySerializer');


// Re-exports the implementation.
var Serializer = goog.require('org.dominokit.jacksonapt.Serializer$impl');
exports = Serializer;
 