/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.DefaultJsonDeserializationContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.DefaultJsonDeserializationContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let RuntimeException = goog.forwardDeclare('java.lang.RuntimeException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Level = goog.forwardDeclare('java.util.logging.Level$impl');
let Logger = goog.forwardDeclare('java.util.logging.Logger$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Builder = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.Builder$impl');
let DefaultBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.DefaultBuilder$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let JsonDeserializationException = goog.forwardDeclare('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');
let NonBufferedJsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.impl.NonBufferedJsonReader$impl');


/**
 * @implements {JsonDeserializationContext}
  */
class DefaultJsonDeserializationContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<IdKey, *>} */
    this.f_idToObject__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
    /** @public {boolean} */
    this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
    /** @public {boolean} */
    this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
    /** @public {boolean} */
    this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
    /** @public {boolean} */
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
    /** @public {boolean} */
    this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
    /** @public {boolean} */
    this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
    /** @public {boolean} */
    this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = false;
  }
  
  /**
   * @return {Builder}
   * @public
   */
  static m_builder__() {
    DefaultJsonDeserializationContext.$clinit();
    return DefaultBuilder.$create__();
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultJsonDeserializationContext(boolean, boolean, boolean, boolean, boolean, boolean, boolean)'.
   * @param {boolean} failOnUnknownProperties
   * @param {boolean} unwrapRootValue
   * @param {boolean} acceptSingleValueAsArray
   * @param {boolean} wrapExceptions
   * @param {boolean} useSafeEval
   * @param {boolean} readUnknownEnumValuesAsNull
   * @param {boolean} useBrowserTimezone
   * @return {!DefaultJsonDeserializationContext}
   * @public
   */
  static $create__boolean__boolean__boolean__boolean__boolean__boolean__boolean(failOnUnknownProperties, unwrapRootValue, acceptSingleValueAsArray, wrapExceptions, useSafeEval, readUnknownEnumValuesAsNull, useBrowserTimezone) {
    DefaultJsonDeserializationContext.$clinit();
    let $instance = new DefaultJsonDeserializationContext();
    $instance.$ctor__org_dominokit_jacksonapt_DefaultJsonDeserializationContext__boolean__boolean__boolean__boolean__boolean__boolean__boolean(failOnUnknownProperties, unwrapRootValue, acceptSingleValueAsArray, wrapExceptions, useSafeEval, readUnknownEnumValuesAsNull, useBrowserTimezone);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultJsonDeserializationContext(boolean, boolean, boolean, boolean, boolean, boolean, boolean)'.
   * @param {boolean} failOnUnknownProperties
   * @param {boolean} unwrapRootValue
   * @param {boolean} acceptSingleValueAsArray
   * @param {boolean} wrapExceptions
   * @param {boolean} useSafeEval
   * @param {boolean} readUnknownEnumValuesAsNull
   * @param {boolean} useBrowserTimezone
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_DefaultJsonDeserializationContext__boolean__boolean__boolean__boolean__boolean__boolean__boolean(failOnUnknownProperties, unwrapRootValue, acceptSingleValueAsArray, wrapExceptions, useSafeEval, readUnknownEnumValuesAsNull, useBrowserTimezone) {
    this.$ctor__java_lang_Object__();
    this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = failOnUnknownProperties;
    this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = unwrapRootValue;
    this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = acceptSingleValueAsArray;
    this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = wrapExceptions;
    this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = useSafeEval;
    this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = readUnknownEnumValuesAsNull;
    this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = useBrowserTimezone;
  }
  
  /**
   * @override
   * @return {Logger}
   * @public
   */
  m_getLogger__() {
    return DefaultJsonDeserializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isFailOnUnknownProperties__() {
    return this.f_failOnUnknownProperties__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isUnwrapRootValue__() {
    return this.f_unwrapRootValue__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isAcceptSingleValueAsArray__() {
    return this.f_acceptSingleValueAsArray__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isUseSafeEval__() {
    return this.f_useSafeEval__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isReadUnknownEnumValuesAsNull__() {
    return this.f_readUnknownEnumValuesAsNull__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isUseBrowserTimezone__() {
    return this.f_useBrowserTimezone__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;
  }
  
  /**
   * @override
   * @param {?string} input
   * @return {JsonReader}
   * @public
   */
  m_newJsonReader__java_lang_String(input) {
    let reader = NonBufferedJsonReader.$create__java_lang_String(input);
    reader.m_setLenient__boolean(true);
    return reader;
  }
  
  /**
   * @override
   * @param {?string} message
   * @return {JsonDeserializationException}
   * @public
   */
  m_traceError__java_lang_String(message) {
    return this.m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader(message, null);
  }
  
  /**
   * @override
   * @param {?string} message
   * @param {JsonReader} reader
   * @return {JsonDeserializationException}
   * @public
   */
  m_traceError__java_lang_String__org_dominokit_jacksonapt_stream_JsonReader(message, reader) {
    this.m_getLogger__().m_log__java_util_logging_Level__java_lang_String(Level.f_SEVERE__java_util_logging_Level, message);
    this.m_traceReaderInfo__org_dominokit_jacksonapt_stream_JsonReader_$p_org_dominokit_jacksonapt_DefaultJsonDeserializationContext(reader);
    return JsonDeserializationException.$create__java_lang_String(message);
  }
  
  /**
   * @override
   * @param {RuntimeException} cause
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_RuntimeException(cause) {
    this.m_getLogger__().m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable(Level.f_SEVERE__java_util_logging_Level, "Error during deserialization", cause);
    if (this.f_wrapExceptions__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_) {
      return JsonDeserializationException.$create__java_lang_Throwable(cause);
    } else {
      return cause;
    }
  }
  
  /**
   * @override
   * @param {RuntimeException} cause
   * @param {JsonReader} reader
   * @return {RuntimeException}
   * @public
   */
  m_traceError__java_lang_RuntimeException__org_dominokit_jacksonapt_stream_JsonReader(cause, reader) {
    let exception = this.m_traceError__java_lang_RuntimeException(cause);
    this.m_traceReaderInfo__org_dominokit_jacksonapt_stream_JsonReader_$p_org_dominokit_jacksonapt_DefaultJsonDeserializationContext(reader);
    return exception;
  }
  
  /**
   * @param {JsonReader} reader
   * @return {void}
   * @public
   */
  m_traceReaderInfo__org_dominokit_jacksonapt_stream_JsonReader_$p_org_dominokit_jacksonapt_DefaultJsonDeserializationContext(reader) {
    if (!$Equality.$same(null, reader) && this.m_getLogger__().m_isLoggable__java_util_logging_Level(Level.f_INFO__java_util_logging_Level)) {
      this.m_getLogger__().m_log__java_util_logging_Level__java_lang_String(Level.f_INFO__java_util_logging_Level, "Error at line " + reader.m_getLineNumber__() + " and column " + reader.m_getColumnNumber__() + " of input <" + j_l_String.m_valueOf__java_lang_Object(reader.m_getInput__()) + ">");
    }
  }
  
  /**
   * @override
   * @param {IdKey} id
   * @param {*} instance
   * @return {void}
   * @public
   */
  m_addObjectId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Object(id, instance) {
    if ($Equality.$same(null, this.f_idToObject__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_)) {
      this.f_idToObject__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = /**@type {!HashMap<IdKey, *>} */ (HashMap.$create__());
    }
    this.f_idToObject__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_.put(id, instance);
  }
  
  /**
   * @override
   * @param {IdKey} id
   * @return {*}
   * @public
   */
  m_getObjectWithId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey(id) {
    if (!$Equality.$same(null, this.f_idToObject__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_)) {
      return this.f_idToObject__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_.get(id);
    }
    return null;
  }
  
  /**
   * @override
   * @return {JsonDeserializerParameters}
   * @public
   */
  m_defaultParameters__() {
    return JacksonContextProvider.m_get__().m_defaultDeserializerParameters__();
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_() {
    return (DefaultJsonDeserializationContext.$clinit(), DefaultJsonDeserializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_(value) {
    (DefaultJsonDeserializationContext.$clinit(), DefaultJsonDeserializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultJsonDeserializationContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultJsonDeserializationContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultJsonDeserializationContext.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Level = goog.module.get('java.util.logging.Level$impl');
    Logger = goog.module.get('java.util.logging.Logger$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    DefaultBuilder = goog.module.get('org.dominokit.jacksonapt.DefaultJsonDeserializationContext.DefaultBuilder$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    JsonDeserializationException = goog.module.get('org.dominokit.jacksonapt.exception.JsonDeserializationException$impl');
    NonBufferedJsonReader = goog.module.get('org.dominokit.jacksonapt.stream.impl.NonBufferedJsonReader$impl');
    j_l_Object.$clinit();
    DefaultJsonDeserializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_ = Logger.m_getLogger__java_lang_String("JsonDeserialization");
  }
  
  
};

$Util.$setClassMetadata(DefaultJsonDeserializationContext, $Util.$makeClassName('org.dominokit.jacksonapt.DefaultJsonDeserializationContext'));


/** @private {Logger} */
DefaultJsonDeserializationContext.$f_logger__org_dominokit_jacksonapt_DefaultJsonDeserializationContext_;


JsonDeserializationContext.$markImplementor(DefaultJsonDeserializationContext);


exports = DefaultJsonDeserializationContext; 
//# sourceMappingURL=DefaultJsonDeserializationContext.js.map