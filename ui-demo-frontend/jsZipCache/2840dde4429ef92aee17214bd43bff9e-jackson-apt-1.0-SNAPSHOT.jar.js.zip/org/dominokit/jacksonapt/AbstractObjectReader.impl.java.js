/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.AbstractObjectReader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.AbstractObjectReader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper$impl');
const ObjectReader = goog.require('org.dominokit.jacksonapt.ObjectReader$impl');

let UnsupportedOperationException = goog.forwardDeclare('java.lang.UnsupportedOperationException$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @abstract
 * @template C_T
 * @extends {AbstractObjectMapper<C_T>}
 * @implements {ObjectReader<C_T>}
  */
class AbstractObjectReader extends AbstractObjectMapper {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'AbstractObjectReader(String)'.
   * @param {?string} rootName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_AbstractObjectReader__java_lang_String(rootName) {
    this.$ctor__org_dominokit_jacksonapt_AbstractObjectMapper__java_lang_String(rootName);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    throw $Exceptions.toJs(UnsupportedOperationException.$create__java_lang_String("ObjectReader doesn't support serialization"));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractObjectReader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractObjectReader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractObjectReader.$clinit = function() {};
    UnsupportedOperationException = goog.module.get('java.lang.UnsupportedOperationException$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    AbstractObjectMapper.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractObjectReader, $Util.$makeClassName('org.dominokit.jacksonapt.AbstractObjectReader'));


ObjectReader.$markImplementor(AbstractObjectReader);


exports = AbstractObjectReader; 
//# sourceMappingURL=AbstractObjectReader.js.map