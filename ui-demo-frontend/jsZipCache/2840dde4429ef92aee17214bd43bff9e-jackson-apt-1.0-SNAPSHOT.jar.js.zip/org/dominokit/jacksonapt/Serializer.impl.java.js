/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.Serializer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.jacksonapt.Serializer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let KeySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.map.key.KeySerializer$impl');


/**
 * @abstract
 * @template C_T
  */
class Serializer extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {KeySerializer<C_T>} */
    this.f_key__org_dominokit_jacksonapt_Serializer_;
    /** @public {JsonSerializer<C_T>} */
    this.f_json__org_dominokit_jacksonapt_Serializer_;
  }
  
  /**
   * Initialization from constructor 'Serializer()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_jacksonapt_Serializer__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {KeySerializer<C_T>}
   * @public
   */
  m_key__() {
    if ($Equality.$same(null, this.f_key__org_dominokit_jacksonapt_Serializer_)) {
      this.f_key__org_dominokit_jacksonapt_Serializer_ = this.m_createKeySerializer__();
    }
    return this.f_key__org_dominokit_jacksonapt_Serializer_;
  }
  
  /**
   * @abstract
   * @return {KeySerializer<C_T>}
   * @public
   */
  m_createKeySerializer__() {
  }
  
  /**
   * @return {JsonSerializer<C_T>}
   * @public
   */
  m_json__() {
    if ($Equality.$same(null, this.f_json__org_dominokit_jacksonapt_Serializer_)) {
      this.f_json__org_dominokit_jacksonapt_Serializer_ = this.m_createJsonSerializer__();
    }
    return this.f_json__org_dominokit_jacksonapt_Serializer_;
  }
  
  /**
   * @abstract
   * @return {JsonSerializer<C_T>}
   * @public
   */
  m_createJsonSerializer__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Serializer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Serializer);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Serializer.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Serializer, $Util.$makeClassName('org.dominokit.jacksonapt.Serializer'));




exports = Serializer; 
//# sourceMappingURL=Serializer.js.map