/**
 * @fileoverview transpiled from org.dominokit.jacksonapt.JacksonContext$IntegerStackFactory$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IntegerStackFactory = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory');
const _Integer = goog.require('java.lang.Integer');
const _Stack = goog.require('org.dominokit.jacksonapt.stream.Stack');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.jacksonapt.JacksonContext.IntegerStackFactory.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 