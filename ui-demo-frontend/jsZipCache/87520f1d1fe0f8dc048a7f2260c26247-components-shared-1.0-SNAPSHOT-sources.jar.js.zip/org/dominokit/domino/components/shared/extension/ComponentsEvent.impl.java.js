/**
 * @fileoverview transpiled from org.dominokit.domino.components.shared.extension.ComponentsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {DominoEvent<ComponentsContext>}
 */
class ComponentsEvent {
  /**
   * @param {?function():ComponentsContext} fn
   * @return {ComponentsEvent}
   * @public
   */
  static $adapt(fn) {
    ComponentsEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_components_shared_extension_ComponentsEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_components_shared_extension_ComponentsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_components_shared_extension_ComponentsEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentsEvent, $Util.$makeClassName('org.dominokit.domino.components.shared.extension.ComponentsEvent'));


ComponentsEvent.$markImplementor(/** @type {Function} */ (ComponentsEvent));


exports = ComponentsEvent; 
//# sourceMappingURL=ComponentsEvent.js.map