package org.dominokit.domino.components.shared.extension;

import org.dominokit.domino.api.shared.extension.DominoEvent;

public interface ComponentsEvent extends DominoEvent<ComponentsContext> {
}
