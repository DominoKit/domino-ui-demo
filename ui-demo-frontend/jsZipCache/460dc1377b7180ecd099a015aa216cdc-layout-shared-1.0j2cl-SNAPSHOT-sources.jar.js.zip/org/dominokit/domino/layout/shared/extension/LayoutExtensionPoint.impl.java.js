/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');

let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ExtensionPoint<LayoutContext>}
 */
class LayoutExtensionPoint {
  /**
   * @param {?function():LayoutContext} fn
   * @return {LayoutExtensionPoint}
   * @public
   */
  static $adapt(fn) {
    LayoutExtensionPoint.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ExtensionPoint.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(LayoutExtensionPoint, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint'));


LayoutExtensionPoint.$markImplementor(/** @type {Function} */ (LayoutExtensionPoint));


exports = LayoutExtensionPoint; 
//# sourceMappingURL=LayoutExtensionPoint.js.map