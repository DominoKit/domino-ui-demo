/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.SetupModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.setup.client.SetupModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');
const _$1 = goog.require('org.dominokit.domino.setup.client.SetupModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.setup.client.SetupModuleConfiguration.$2');
const _SetupPresenterListenerForComponentCaseEvent = goog.require('org.dominokit.domino.setup.client.listeners.SetupPresenterListenerForComponentCaseEvent');
const _SetupPresenter = goog.require('org.dominokit.domino.setup.client.presenters.SetupPresenter');
const _SetupPresenterCommand = goog.require('org.dominokit.domino.setup.client.presenters.SetupPresenterCommand');


// Re-exports the implementation.
var SetupModuleConfiguration = goog.require('org.dominokit.domino.setup.client.SetupModuleConfiguration$impl');
exports = SetupModuleConfiguration;
 