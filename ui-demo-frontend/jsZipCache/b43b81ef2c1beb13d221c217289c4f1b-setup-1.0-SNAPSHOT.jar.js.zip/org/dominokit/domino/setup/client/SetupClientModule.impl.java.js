/**
 * @fileoverview transpiled from org.dominokit.domino.setup.client.SetupClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.setup.client.SetupClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class SetupClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SetupClientModule()'.
   * @return {!SetupClientModule}
   * @public
   */
  static $create__() {
    SetupClientModule.$clinit();
    let $instance = new SetupClientModule();
    $instance.$ctor__org_dominokit_domino_setup_client_SetupClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SetupClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_setup_client_SetupClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    SetupClientModule.$f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_.m_info__java_lang_String("Initializing Setup frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_() {
    return (SetupClientModule.$clinit(), SetupClientModule.$f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_(value) {
    (SetupClientModule.$clinit(), SetupClientModule.$f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SetupClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SetupClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SetupClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    SetupClientModule.$f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SetupClientModule));
  }
  
  
};

$Util.$setClassMetadata(SetupClientModule, $Util.$makeClassName('org.dominokit.domino.setup.client.SetupClientModule'));


/** @private {Logger} */
SetupClientModule.$f_LOGGER__org_dominokit_domino_setup_client_SetupClientModule_;




exports = SetupClientModule; 
//# sourceMappingURL=SetupClientModule.js.map