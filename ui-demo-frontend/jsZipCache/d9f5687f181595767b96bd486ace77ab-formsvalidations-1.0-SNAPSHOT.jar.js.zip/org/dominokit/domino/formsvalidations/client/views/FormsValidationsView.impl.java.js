/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.views.FormsValidationsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 */
class FormsValidationsView {
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getContent__() {
  }
  
  /**
   * @param {?function():Content} fn
   * @return {FormsValidationsView}
   * @public
   */
  static $adapt(fn) {
    FormsValidationsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_formsvalidations_client_views_FormsValidationsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsValidationsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(FormsValidationsView, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.views.FormsValidationsView'));


FormsValidationsView.$markImplementor(/** @type {Function} */ (FormsValidationsView));


exports = FormsValidationsView; 
//# sourceMappingURL=FormsValidationsView.js.map