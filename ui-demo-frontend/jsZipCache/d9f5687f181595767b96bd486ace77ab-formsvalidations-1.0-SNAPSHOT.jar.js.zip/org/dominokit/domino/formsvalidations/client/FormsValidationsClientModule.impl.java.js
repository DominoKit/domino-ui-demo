/**
 * @fileoverview transpiled from org.dominokit.domino.formsvalidations.client.FormsValidationsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsvalidations.client.FormsValidationsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class FormsValidationsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsValidationsClientModule()'.
   * @return {!FormsValidationsClientModule}
   * @public
   */
  static $create__() {
    FormsValidationsClientModule.$clinit();
    let $instance = new FormsValidationsClientModule();
    $instance.$ctor__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsValidationsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    FormsValidationsClientModule.$f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_.m_info__java_lang_String("Initializing FormsValidations frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_() {
    return (FormsValidationsClientModule.$clinit(), FormsValidationsClientModule.$f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_(value) {
    (FormsValidationsClientModule.$clinit(), FormsValidationsClientModule.$f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsValidationsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsValidationsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsValidationsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    FormsValidationsClientModule.$f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormsValidationsClientModule));
  }
  
  
};

$Util.$setClassMetadata(FormsValidationsClientModule, $Util.$makeClassName('org.dominokit.domino.formsvalidations.client.FormsValidationsClientModule'));


/** @private {Logger} */
FormsValidationsClientModule.$f_LOGGER__org_dominokit_domino_formsvalidations_client_FormsValidationsClientModule_;




exports = FormsValidationsClientModule; 
//# sourceMappingURL=FormsValidationsClientModule.js.map