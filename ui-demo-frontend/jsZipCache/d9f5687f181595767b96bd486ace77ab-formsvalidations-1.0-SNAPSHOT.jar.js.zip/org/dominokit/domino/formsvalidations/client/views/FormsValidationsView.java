package org.dominokit.domino.formsvalidations.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.shared.extension.Content;

public interface FormsValidationsView extends View{
    Content getContent();
}