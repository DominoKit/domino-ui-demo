/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.BreadcrumbClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.breadcrumb.client.BreadcrumbClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class BreadcrumbClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbClientModule()'.
   * @return {!BreadcrumbClientModule}
   * @public
   */
  static $create__() {
    BreadcrumbClientModule.$clinit();
    let $instance = new BreadcrumbClientModule();
    $instance.$ctor__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    BreadcrumbClientModule.$f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_.m_info__java_lang_String("Initializing Breadcrumb frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_() {
    return (BreadcrumbClientModule.$clinit(), BreadcrumbClientModule.$f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_(value) {
    (BreadcrumbClientModule.$clinit(), BreadcrumbClientModule.$f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BreadcrumbClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BreadcrumbClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BreadcrumbClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    BreadcrumbClientModule.$f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(BreadcrumbClientModule));
  }
  
  
};

$Util.$setClassMetadata(BreadcrumbClientModule, $Util.$makeClassName('org.dominokit.domino.breadcrumb.client.BreadcrumbClientModule'));


/** @private {Logger} */
BreadcrumbClientModule.$f_LOGGER__org_dominokit_domino_breadcrumb_client_BreadcrumbClientModule_;




exports = BreadcrumbClientModule; 
//# sourceMappingURL=BreadcrumbClientModule.js.map