/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let BreadcrumbPresenter = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter$impl');


/**
 * @extends {PresenterCommand<BreadcrumbPresenter>}
  */
class BreadcrumbPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbPresenterCommand()'.
   * @return {!BreadcrumbPresenterCommand}
   * @public
   */
  static $create__() {
    BreadcrumbPresenterCommand.$clinit();
    let $instance = new BreadcrumbPresenterCommand();
    $instance.$ctor__org_dominokit_domino_breadcrumb_client_presenters_BreadcrumbPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_breadcrumb_client_presenters_BreadcrumbPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BreadcrumbPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BreadcrumbPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BreadcrumbPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BreadcrumbPresenterCommand, $Util.$makeClassName('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenterCommand'));




exports = BreadcrumbPresenterCommand; 
//# sourceMappingURL=BreadcrumbPresenterCommand.js.map