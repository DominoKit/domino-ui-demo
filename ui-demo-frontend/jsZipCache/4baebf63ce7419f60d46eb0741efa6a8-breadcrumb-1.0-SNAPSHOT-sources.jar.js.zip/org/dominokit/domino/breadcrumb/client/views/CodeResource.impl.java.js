/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.breadcrumb.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_breadcrumb_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_breadcrumb_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_basicBreadcrumb__() {
    CodeResource.$clinit();
    return "Card.create(\"BASIC EXAMPLES\", \"Separators are automatically added for breadcrumb elements\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .addItem(\" Home \", evt -> {\n" + "            }).asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            }).asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement();\n" + "\n" + "\n" + "Card.create(\"WITH ICONS\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            }).asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            }).asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement();";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_breadcrumbWithBackground__() {
    CodeResource.$clinit();
    return "Card.create(\"WITH MATERIAL DESIGN COLORS\", \"You can use material design colors\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.PINK)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.CYAN)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.TEAL)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .addItem(\" File \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.ORANGE)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .addItem(\" File \", evt -> {\n" + "            })\n" + "            .addItem(\" Extensions \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement();\n" + "\n" + "\n" + "Card.create(\"WITH ICONS & MATERIAL DESIGN COLORS\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.PINK)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.CYAN)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.TEAL)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.attachment(), \" File \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.ORANGE)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.attachment(), \" File \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.extension(), \" Extensions \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement()";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_coloredBreadcrumb__() {
    CodeResource.$clinit();
    return "Card.create(\"WITH MATERIAL DESIGN COLORS\", \"You can use material design colors\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.PINK)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.CYAN)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.TEAL)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .addItem(\" File \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.ORANGE)\n" + "            .addItem(\" Home \", evt -> {\n" + "            })\n" + "            .addItem(\" Library \", evt -> {\n" + "            })\n" + "            .addItem(\" Data \", evt -> {\n" + "            })\n" + "            .addItem(\" File \", evt -> {\n" + "            })\n" + "            .addItem(\" Extensions \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement();\n" + "\n" + "\n" + "Card.create(\"WITH ICONS & MATERIAL DESIGN COLORS\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.PINK)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.CYAN)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.TEAL)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.attachment(), \" File \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setColor(Color.ORANGE)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.attachment(), \" File \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.extension(), \" Extensions \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement();";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_alignment__() {
    CodeResource.$clinit();
    return "Card.create(\"ALIGNMENTS\")\n" + "    .appendContent(Breadcrumb.create()\n" + "            .setBackground(Color.PINK)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .alignCenter()\n" + "            .setBackground(Color.CYAN)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .appendContent(Breadcrumb.create()\n" + "            .alignRight()\n" + "            .setBackground(Color.TEAL)\n" + "            .addItem(Icons.ALL.home(), \" Home \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.library_books(), \" Library \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.archive(), \" Data \", evt -> {\n" + "            })\n" + "            .addItem(Icons.ALL.attachment(), \" File \", evt -> {\n" + "            })\n" + "            .asElement())\n" + "    .asElement()";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.breadcrumb.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map