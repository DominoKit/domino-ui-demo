/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ThemesView$ThemeAppliedHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ThemeAppliedHandler = goog.require('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler$impl');


/**
 * @implements {ThemeAppliedHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string):void} */
    this.f_$$fn__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$LambdaAdaptor__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$LambdaAdaptor__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_onThemeApplied__java_lang_String(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_themes_client_views_ThemesView_ThemeAppliedHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.themes.client.views.ThemesView$ThemeAppliedHandler$$LambdaAdaptor'));


ThemeAppliedHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ThemesView$ThemeAppliedHandler$$LambdaAdaptor.js.map