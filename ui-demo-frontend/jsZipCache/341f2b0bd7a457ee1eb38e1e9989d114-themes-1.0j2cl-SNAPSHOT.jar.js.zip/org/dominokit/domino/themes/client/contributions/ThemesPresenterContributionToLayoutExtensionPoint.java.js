/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _LayoutExtensionPoint = goog.require('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint');
const _ThemesPresenter = goog.require('org.dominokit.domino.themes.client.presenters.ThemesPresenter');
const _ThemesPresenterCommand = goog.require('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ThemesPresenterContributionToLayoutExtensionPoint = goog.require('org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint$impl');
exports = ThemesPresenterContributionToLayoutExtensionPoint;
 