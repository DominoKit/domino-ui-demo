/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ThemesView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.themes.client.views.ThemesView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _ThemeAppliedHandler = goog.require('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler');


// Re-exports the implementation.
var ThemesView = goog.require('org.dominokit.domino.themes.client.views.ThemesView$impl');
exports = ThemesView;
 