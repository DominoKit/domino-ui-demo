/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ThemesView = goog.require('org.dominokit.domino.themes.client.views.ThemesView');
const _$Overlay = goog.require('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay');
const _PaddingUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.PaddingUnionType.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _Objects = goog.require('java.util.Objects');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Js = goog.require('jsinterop.base.Js');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _ThemeAppliedHandler = goog.require('org.dominokit.domino.themes.client.views.ThemesView.ThemeAppliedHandler');
const _ThemesPanel = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesPanel');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl.$LambdaAdaptor$3');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Theme = goog.require('org.dominokit.domino.ui.themes.Theme');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ThemesViewImpl = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesViewImpl$impl');
exports = ThemesViewImpl;
 