package org.dominokit.domino.splitPanel.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.layouts.shared.extension.LayoutsEvent;
import org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class SplitPanelPresenterListenerForLayoutsEvent implements DominoEventListener<LayoutsEvent> {
  @Override
  public void listen(LayoutsEvent event) {
    new SplitPanelPresenterCommand().onPresenterReady(presenter -> presenter.listenToMainEvent(event.context())).send();
  }
}
