/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter.$1$impl');
let SplitPanelView = goog.forwardDeclare('org.dominokit.domino.splitPanel.client.views.SplitPanelView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<SplitPanelView>}
  */
class SplitPanelPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SplitPanelPresenter()'.
   * @return {!SplitPanelPresenter}
   * @public
   */
  static $create__() {
    SplitPanelPresenter.$clinit();
    let $instance = new SplitPanelPresenter();
    $instance.$ctor__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitPanelPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {LayoutsEventContext} context
   * @return {void}
   * @public
   */
  m_listenToMainEvent__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter_() {
    return (SplitPanelPresenter.$clinit(), SplitPanelPresenter.$f_LOGGER__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter_(value) {
    (SplitPanelPresenter.$clinit(), SplitPanelPresenter.$f_LOGGER__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SplitPanelPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SplitPanelPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SplitPanelPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    SplitPanelPresenter.$f_LOGGER__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SplitPanelPresenter));
  }
  
  
};

$Util.$setClassMetadata(SplitPanelPresenter, $Util.$makeClassName('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter'));


/** @private {Logger} */
SplitPanelPresenter.$f_LOGGER__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenter_;




exports = SplitPanelPresenter; 
//# sourceMappingURL=SplitPanelPresenter.js.map