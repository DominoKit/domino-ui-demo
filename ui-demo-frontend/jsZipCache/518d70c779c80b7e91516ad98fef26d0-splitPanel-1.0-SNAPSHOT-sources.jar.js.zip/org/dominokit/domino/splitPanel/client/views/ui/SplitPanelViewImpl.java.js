/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.views.ui.SplitPanelViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.splitPanel.client.views.ui.SplitPanelViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _SplitPanelView = goog.require('org.dominokit.domino.splitPanel.client.views.SplitPanelView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _HSplitPanel = goog.require('org.dominokit.domino.ui.splitpanel.HSplitPanel');
const _SplitPanel = goog.require('org.dominokit.domino.ui.splitpanel.SplitPanel');
const _VSplitPanel = goog.require('org.dominokit.domino.ui.splitpanel.VSplitPanel');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SplitPanelViewImpl = goog.require('org.dominokit.domino.splitPanel.client.views.ui.SplitPanelViewImpl$impl');
exports = SplitPanelViewImpl;
 