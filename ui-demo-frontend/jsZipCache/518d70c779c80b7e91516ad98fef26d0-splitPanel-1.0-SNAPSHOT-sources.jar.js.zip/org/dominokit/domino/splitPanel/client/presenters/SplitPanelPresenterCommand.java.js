/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _SplitPanelPresenter = goog.require('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter');


// Re-exports the implementation.
var SplitPanelPresenterCommand = goog.require('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand$impl');
exports = SplitPanelPresenterCommand;
 