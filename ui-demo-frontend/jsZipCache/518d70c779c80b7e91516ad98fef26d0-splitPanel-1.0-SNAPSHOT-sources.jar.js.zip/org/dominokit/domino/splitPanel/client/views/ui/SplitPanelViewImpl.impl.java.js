/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.views.ui.SplitPanelViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.splitPanel.client.views.ui.SplitPanelViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const SplitPanelView = goog.require('org.dominokit.domino.splitPanel.client.views.SplitPanelView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let HSplitPanel = goog.forwardDeclare('org.dominokit.domino.ui.splitpanel.HSplitPanel$impl');
let SplitPanel = goog.forwardDeclare('org.dominokit.domino.ui.splitpanel.SplitPanel$impl');
let VSplitPanel = goog.forwardDeclare('org.dominokit.domino.ui.splitpanel.VSplitPanel$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {SplitPanelView}
  */
class SplitPanelViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'SplitPanelViewImpl()'.
   * @return {!SplitPanelViewImpl}
   * @public
   */
  static $create__() {
    SplitPanelViewImpl.$clinit();
    let $instance = new SplitPanelViewImpl();
    $instance.$ctor__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitPanelViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("SPLIT PANEL").m_asElement__());
    this.m_horizontalSplitPanel___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl();
    this.m_verticalSplitPanel___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl();
    this.m_splitPanelMinMax___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl();
    this.m_multiSplit___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl();
    this.m_combined___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_horizontalSplitPanel___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(Card.m_create__java_lang_String("HORIZONTAL SPLIT PANEL").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {HSplitPanel} */ ($Casts.$to(/**@type {HSplitPanel} */ ($Casts.$to(HSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_BLUE_GREY_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_setHeight__java_lang_String("400px")).m_asElement__());
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl, "horizontalSplitPanel").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_verticalSplitPanel___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(Card.m_create__java_lang_String("VERTICAL SPLIT PANEL").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(VSplitPanel.m_create__().m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TEAL__org_dominokit_domino_ui_style_ColorScheme), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_GREEN_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_GREEN_LIGHTEN_4__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_setHeight__java_lang_String("400px")).m_asElement__());
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl, "verticalSplitPanel").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_splitPanelMinMax___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(Card.m_create__java_lang_String("SPLIT PANEL MIN & MAX").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {HSplitPanel} */ ($Casts.$to(/**@type {HSplitPanel} */ ($Casts.$to(HSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("50%"), SplitPanel)).m_setMinPercent__double(20).m_setMaxPercent__double(70).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("50%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_BLUE_GREY_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_setHeight__java_lang_String("400px")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(VSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("50%"), SplitPanel)).m_setMinPercent__double(20).m_setMaxPercent__double(70).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("50%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_BLUE_GREY_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_setHeight__java_lang_String("400px")).m_asElement__());
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl, "splitPanelMinMax").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_multiSplit___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(Card.m_create__java_lang_String("MULTI SPLIT").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {HSplitPanel} */ ($Casts.$to(/**@type {HSplitPanel} */ ($Casts.$to(/**@type {HSplitPanel} */ ($Casts.$to(HSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("20%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("50%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_BLUE_GREY_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("30%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_setHeight__java_lang_String("400px")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(VSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("20%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("50%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_BLUE_GREY_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("30%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_setHeight__java_lang_String("400px")).m_asElement__());
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl, "multiSplit").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_combined___$p_org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(Card.m_create__java_lang_String("COMBINED SPLIT PANELS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {HSplitPanel} */ ($Casts.$to(/**@type {HSplitPanel} */ ($Casts.$to(/**@type {HSplitPanel} */ ($Casts.$to(HSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("20%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("50%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(/**@type {VSplitPanel} */ ($Casts.$to(VSplitPanel.m_create__().m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("20%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("50%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_BLUE_GREY_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setHeight__java_lang_String("30%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), VSplitPanel)).m_setHeight__java_lang_String("100%")), SplitPanel))), HSplitPanel)).m_appendChild__org_dominokit_domino_ui_splitpanel_SplitPanel(/**@type {SplitPanel} */ ($Casts.$to(/**@type {SplitPanel} */ ($Casts.$to(SplitPanel.m_create__().m_setWidth__java_lang_String("30%"), SplitPanel)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-split-div", Color.f_INDIGO_LIGHTEN_5__org_dominokit_domino_ui_style_Color.m_getBackground__()], j_l_String)))), SplitPanel))), HSplitPanel)).m_setHeight__java_lang_String("400px")).m_asElement__());
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl, "combined").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl() {
    this.f_element__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SplitPanelViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SplitPanelViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SplitPanelViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    HSplitPanel = goog.module.get('org.dominokit.domino.ui.splitpanel.HSplitPanel$impl');
    SplitPanel = goog.module.get('org.dominokit.domino.ui.splitpanel.SplitPanel$impl');
    VSplitPanel = goog.module.get('org.dominokit.domino.ui.splitpanel.VSplitPanel$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SplitPanelViewImpl, $Util.$makeClassName('org.dominokit.domino.splitPanel.client.views.ui.SplitPanelViewImpl'));


/** @public {?string} @const */
SplitPanelViewImpl.f_MODULE_NAME__org_dominokit_domino_splitPanel_client_views_ui_SplitPanelViewImpl = "splitPanel";


SplitPanelView.$markImplementor(SplitPanelViewImpl);


exports = SplitPanelViewImpl; 
//# sourceMappingURL=SplitPanelViewImpl.js.map