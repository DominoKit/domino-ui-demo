/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.SplitPanelClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.splitPanel.client.SplitPanelClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class SplitPanelClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SplitPanelClientModule()'.
   * @return {!SplitPanelClientModule}
   * @public
   */
  static $create__() {
    SplitPanelClientModule.$clinit();
    let $instance = new SplitPanelClientModule();
    $instance.$ctor__org_dominokit_domino_splitPanel_client_SplitPanelClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitPanelClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_splitPanel_client_SplitPanelClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    SplitPanelClientModule.$f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_.m_info__java_lang_String("Initializing SplitPanel frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_() {
    return (SplitPanelClientModule.$clinit(), SplitPanelClientModule.$f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_(value) {
    (SplitPanelClientModule.$clinit(), SplitPanelClientModule.$f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SplitPanelClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SplitPanelClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SplitPanelClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    SplitPanelClientModule.$f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SplitPanelClientModule));
  }
  
  
};

$Util.$setClassMetadata(SplitPanelClientModule, $Util.$makeClassName('org.dominokit.domino.splitPanel.client.SplitPanelClientModule'));


/** @private {Logger} */
SplitPanelClientModule.$f_LOGGER__org_dominokit_domino_splitPanel_client_SplitPanelClientModule_;




exports = SplitPanelClientModule; 
//# sourceMappingURL=SplitPanelClientModule.js.map