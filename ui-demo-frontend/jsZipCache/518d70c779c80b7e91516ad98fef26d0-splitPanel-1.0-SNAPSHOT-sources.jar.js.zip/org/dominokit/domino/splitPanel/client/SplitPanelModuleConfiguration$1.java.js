/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.SplitPanelModuleConfiguration$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.splitPanel.client.SplitPanelModuleConfiguration.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _SplitPanelModuleConfiguration = goog.require('org.dominokit.domino.splitPanel.client.SplitPanelModuleConfiguration');
const _SplitPanelPresenter = goog.require('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.splitPanel.client.SplitPanelModuleConfiguration.$1$impl');
exports = $1;
 