/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.views.SplitPanelView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.splitPanel.client.views.SplitPanelView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.splitPanel.client.views.SplitPanelView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class SplitPanelView {
  /**
   * @param {?function():Content} fn
   * @return {SplitPanelView}
   * @public
   */
  static $adapt(fn) {
    SplitPanelView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_splitPanel_client_views_SplitPanelView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_splitPanel_client_views_SplitPanelView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_splitPanel_client_views_SplitPanelView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SplitPanelView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.splitPanel.client.views.SplitPanelView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SplitPanelView, $Util.$makeClassName('org.dominokit.domino.splitPanel.client.views.SplitPanelView'));


SplitPanelView.$markImplementor(/** @type {Function} */ (SplitPanelView));


exports = SplitPanelView; 
//# sourceMappingURL=SplitPanelView.js.map