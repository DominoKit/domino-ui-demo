/**
 * @fileoverview transpiled from org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let SplitPanelPresenter = goog.forwardDeclare('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenter$impl');


/**
 * @extends {PresenterCommand<SplitPanelPresenter>}
  */
class SplitPanelPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SplitPanelPresenterCommand()'.
   * @return {!SplitPanelPresenterCommand}
   * @public
   */
  static $create__() {
    SplitPanelPresenterCommand.$clinit();
    let $instance = new SplitPanelPresenterCommand();
    $instance.$ctor__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitPanelPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_splitPanel_client_presenters_SplitPanelPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SplitPanelPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SplitPanelPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SplitPanelPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SplitPanelPresenterCommand, $Util.$makeClassName('org.dominokit.domino.splitPanel.client.presenters.SplitPanelPresenterCommand'));




exports = SplitPanelPresenterCommand; 
//# sourceMappingURL=SplitPanelPresenterCommand.js.map