/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements$JsArrayLikeIterator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.Elements.JsArrayLikeIterator$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const Iterator = goog.require('java.util.Iterator$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let NoSuchElementException = goog.forwardDeclare('java.util.NoSuchElementException$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @template C_JsArrayLikeIterator_T
 * @implements {Iterator<C_JsArrayLikeIterator_T>}
  */
class JsArrayLikeIterator extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_pos__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_ = 0;
    /** @public {IArrayLike<?>} */
    this.f_data__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_;
  }
  
  /**
   * Factory method corresponding to constructor 'JsArrayLikeIterator(JsArrayLike)'.
   * @template C_JsArrayLikeIterator_T
   * @param {IArrayLike<?>} nodes
   * @return {!JsArrayLikeIterator<C_JsArrayLikeIterator_T>}
   * @public
   */
  static $create__jsinterop_base_JsArrayLike(nodes) {
    JsArrayLikeIterator.$clinit();
    let $instance = new JsArrayLikeIterator();
    $instance.$ctor__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator__jsinterop_base_JsArrayLike(nodes);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JsArrayLikeIterator(JsArrayLike)'.
   * @param {IArrayLike<?>} nodes
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator__jsinterop_base_JsArrayLike(nodes) {
    this.$ctor__java_lang_Object__();
    this.$init__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator();
    this.f_data__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_ = nodes;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_hasNext__() {
    return this.f_pos__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_ < $Overlay.m_getLength__jsinterop_base_JsArrayLike(this.f_data__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_);
  }
  
  /**
   * @override
   * @return {C_JsArrayLikeIterator_T}
   * @public
   */
  m_next__() {
    if (!this.m_hasNext__()) {
      throw $Exceptions.toJs(NoSuchElementException.$create__());
    }
    return $Overlay.m_getAt__jsinterop_base_JsArrayLike__int(this.f_data__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_, this.f_pos__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_++);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {Consumer<?>} arg0
   * @return {void}
   * @public
   */
  m_forEachRemaining__java_util_function_Consumer(arg0) {
    Iterator.m_forEachRemaining__$default__java_util_Iterator__java_util_function_Consumer(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {void}
   * @public
   */
  m_remove__() {
    Iterator.m_remove__$default__java_util_Iterator(this);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator() {
    this.f_pos__org_jboss_gwt_elemento_core_Elements_JsArrayLikeIterator_ = 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JsArrayLikeIterator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JsArrayLikeIterator);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsArrayLikeIterator.$clinit = function() {};
    NoSuchElementException = goog.module.get('java.util.NoSuchElementException$impl');
    $Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
    Iterator.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JsArrayLikeIterator, $Util.$makeClassName('org.jboss.gwt.elemento.core.Elements$JsArrayLikeIterator'));


Iterator.$markImplementor(JsArrayLikeIterator);


exports = JsArrayLikeIterator; 
//# sourceMappingURL=Elements$JsArrayLikeIterator.js.map