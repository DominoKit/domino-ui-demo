/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.Elements');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLAreaElement_$Overlay = goog.require('elemental2.dom.HTMLAreaElement.$Overlay');
const _HTMLAudioElement_$Overlay = goog.require('elemental2.dom.HTMLAudioElement.$Overlay');
const _HTMLBRElement_$Overlay = goog.require('elemental2.dom.HTMLBRElement.$Overlay');
const _HTMLBodyElement_$Overlay = goog.require('elemental2.dom.HTMLBodyElement.$Overlay');
const _HTMLButtonElement_$Overlay = goog.require('elemental2.dom.HTMLButtonElement.$Overlay');
const _HTMLCanvasElement_$Overlay = goog.require('elemental2.dom.HTMLCanvasElement.$Overlay');
const _HTMLDListElement_$Overlay = goog.require('elemental2.dom.HTMLDListElement.$Overlay');
const _HTMLDataListElement_$Overlay = goog.require('elemental2.dom.HTMLDataListElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLEmbedElement_$Overlay = goog.require('elemental2.dom.HTMLEmbedElement.$Overlay');
const _HTMLFieldSetElement_$Overlay = goog.require('elemental2.dom.HTMLFieldSetElement.$Overlay');
const _HTMLFormElement_$Overlay = goog.require('elemental2.dom.HTMLFormElement.$Overlay');
const _HTMLHRElement_$Overlay = goog.require('elemental2.dom.HTMLHRElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _HTMLImageElement_$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _HTMLInputElement_$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _HTMLLabelElement_$Overlay = goog.require('elemental2.dom.HTMLLabelElement.$Overlay');
const _HTMLLegendElement_$Overlay = goog.require('elemental2.dom.HTMLLegendElement.$Overlay');
const _HTMLMapElement_$Overlay = goog.require('elemental2.dom.HTMLMapElement.$Overlay');
const _HTMLMeterElement_$Overlay = goog.require('elemental2.dom.HTMLMeterElement.$Overlay');
const _HTMLModElement_$Overlay = goog.require('elemental2.dom.HTMLModElement.$Overlay');
const _HTMLOListElement_$Overlay = goog.require('elemental2.dom.HTMLOListElement.$Overlay');
const _HTMLObjectElement_$Overlay = goog.require('elemental2.dom.HTMLObjectElement.$Overlay');
const _HTMLOptGroupElement_$Overlay = goog.require('elemental2.dom.HTMLOptGroupElement.$Overlay');
const _HTMLOptionElement_$Overlay = goog.require('elemental2.dom.HTMLOptionElement.$Overlay');
const _HTMLOutputElement_$Overlay = goog.require('elemental2.dom.HTMLOutputElement.$Overlay');
const _HTMLParagraphElement_$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _HTMLParamElement_$Overlay = goog.require('elemental2.dom.HTMLParamElement.$Overlay');
const _HTMLPreElement_$Overlay = goog.require('elemental2.dom.HTMLPreElement.$Overlay');
const _HTMLProgressElement_$Overlay = goog.require('elemental2.dom.HTMLProgressElement.$Overlay');
const _HTMLQuoteElement_$Overlay = goog.require('elemental2.dom.HTMLQuoteElement.$Overlay');
const _HTMLScriptElement_$Overlay = goog.require('elemental2.dom.HTMLScriptElement.$Overlay');
const _HTMLSelectElement_$Overlay = goog.require('elemental2.dom.HTMLSelectElement.$Overlay');
const _HTMLSourceElement_$Overlay = goog.require('elemental2.dom.HTMLSourceElement.$Overlay');
const _HTMLTableCaptionElement_$Overlay = goog.require('elemental2.dom.HTMLTableCaptionElement.$Overlay');
const _HTMLTableCellElement_$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _HTMLTableColElement_$Overlay = goog.require('elemental2.dom.HTMLTableColElement.$Overlay');
const _HTMLTableElement_$Overlay = goog.require('elemental2.dom.HTMLTableElement.$Overlay');
const _HTMLTableRowElement_$Overlay = goog.require('elemental2.dom.HTMLTableRowElement.$Overlay');
const _HTMLTableSectionElement_$Overlay = goog.require('elemental2.dom.HTMLTableSectionElement.$Overlay');
const _HTMLTextAreaElement_$Overlay = goog.require('elemental2.dom.HTMLTextAreaElement.$Overlay');
const _HTMLTrackElement_$Overlay = goog.require('elemental2.dom.HTMLTrackElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _HTMLVideoElement_$Overlay = goog.require('elemental2.dom.HTMLVideoElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Class = goog.require('java.lang.Class');
const _Iterable = goog.require('java.lang.Iterable');
const _j_l_String = goog.require('java.lang.String');
const _Collections = goog.require('java.util.Collections');
const _Iterator = goog.require('java.util.Iterator');
const _Spliterator = goog.require('java.util.Spliterator');
const _Spliterators = goog.require('java.util.Spliterators');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _IntSupplier = goog.require('java.util.function.IntSupplier');
const _Predicate = goog.require('java.util.function.Predicate');
const _Supplier = goog.require('java.util.function.Supplier');
const _Stream = goog.require('java.util.stream.Stream');
const _StreamSupport = goog.require('java.util.stream.StreamSupport');
const _Any_$Overlay = goog.require('jsinterop.base.Any.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _JsPropertyMap_$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');
const _$1 = goog.require('org.jboss.gwt.elemento.core.Elements.$1');
const _AsHTMLElement = goog.require('org.jboss.gwt.elemento.core.Elements.AsHTMLElement');
const _FilterHTMLElements = goog.require('org.jboss.gwt.elemento.core.Elements.FilterHTMLElements');
const _JsArrayElementIterator = goog.require('org.jboss.gwt.elemento.core.Elements.JsArrayElementIterator');
const _JsArrayLikeIterator = goog.require('org.jboss.gwt.elemento.core.Elements.JsArrayLikeIterator');
const _JsArrayNodeIterator = goog.require('org.jboss.gwt.elemento.core.Elements.JsArrayNodeIterator');
const _InputType = goog.require('org.jboss.gwt.elemento.core.InputType');
const _ElementCreator = goog.require('org.jboss.gwt.elemento.core.builder.ElementCreator');
const _ElementsBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementsBuilder');
const _EmptyContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _InputBuilder = goog.require('org.jboss.gwt.elemento.core.builder.InputBuilder');
const _TextContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TextContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$JavaScriptObject = goog.require('vmbootstrap.JavaScriptObject');


// Re-exports the implementation.
var Elements = goog.require('org.jboss.gwt.elemento.core.Elements$impl');
exports = Elements;
 