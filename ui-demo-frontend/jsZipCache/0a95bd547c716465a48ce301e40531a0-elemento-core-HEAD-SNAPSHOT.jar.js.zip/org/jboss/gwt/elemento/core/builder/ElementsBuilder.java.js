/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementsBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementsBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasElements = goog.require('org.jboss.gwt.elemento.core.HasElements');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Iterable = goog.require('java.lang.Iterable');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ElementsBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementsBuilder$impl');
exports = ElementsBuilder;
 