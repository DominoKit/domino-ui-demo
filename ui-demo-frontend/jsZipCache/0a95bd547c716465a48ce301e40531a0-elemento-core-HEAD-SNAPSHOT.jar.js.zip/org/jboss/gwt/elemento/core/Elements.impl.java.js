/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.Elements$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLAreaElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAreaElement.$Overlay$impl');
let HTMLAudioElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAudioElement.$Overlay$impl');
let HTMLBRElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLBRElement.$Overlay$impl');
let HTMLBodyElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLBodyElement.$Overlay$impl');
let HTMLButtonElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let HTMLCanvasElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLCanvasElement.$Overlay$impl');
let HTMLDListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDListElement.$Overlay$impl');
let HTMLDataListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDataListElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLEmbedElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLEmbedElement.$Overlay$impl');
let HTMLFieldSetElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLFieldSetElement.$Overlay$impl');
let HTMLFormElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLFormElement.$Overlay$impl');
let HTMLHRElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHRElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let HTMLInputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let HTMLLegendElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLegendElement.$Overlay$impl');
let HTMLMapElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLMapElement.$Overlay$impl');
let HTMLMeterElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLMeterElement.$Overlay$impl');
let HTMLModElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLModElement.$Overlay$impl');
let HTMLOListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOListElement.$Overlay$impl');
let HTMLObjectElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLObjectElement.$Overlay$impl');
let HTMLOptGroupElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOptGroupElement.$Overlay$impl');
let HTMLOptionElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOptionElement.$Overlay$impl');
let HTMLOutputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOutputElement.$Overlay$impl');
let HTMLParagraphElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let HTMLParamElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParamElement.$Overlay$impl');
let HTMLPreElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLPreElement.$Overlay$impl');
let HTMLProgressElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLProgressElement.$Overlay$impl');
let HTMLQuoteElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLQuoteElement.$Overlay$impl');
let HTMLScriptElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLScriptElement.$Overlay$impl');
let HTMLSelectElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLSelectElement.$Overlay$impl');
let HTMLSourceElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLSourceElement.$Overlay$impl');
let HTMLTableCaptionElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCaptionElement.$Overlay$impl');
let HTMLTableCellElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let HTMLTableColElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableColElement.$Overlay$impl');
let HTMLTableElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableElement.$Overlay$impl');
let HTMLTableRowElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
let HTMLTableSectionElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
let HTMLTextAreaElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTextAreaElement.$Overlay$impl');
let HTMLTrackElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTrackElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let HTMLVideoElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLVideoElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Collections = goog.forwardDeclare('java.util.Collections$impl');
let Iterator = goog.forwardDeclare('java.util.Iterator$impl');
let Spliterator = goog.forwardDeclare('java.util.Spliterator$impl');
let Spliterators = goog.forwardDeclare('java.util.Spliterators$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let IntSupplier = goog.forwardDeclare('java.util.function.IntSupplier$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Supplier = goog.forwardDeclare('java.util.function.Supplier$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let StreamSupport = goog.forwardDeclare('java.util.stream.StreamSupport$impl');
let Any_$Overlay = goog.forwardDeclare('jsinterop.base.Any.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let JsPropertyMap_$Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let SafeHtml = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtml$impl');
let $1 = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements.$1$impl');
let AsHTMLElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements.AsHTMLElement$impl');
let FilterHTMLElements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements.FilterHTMLElements$impl');
let JsArrayElementIterator = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements.JsArrayElementIterator$impl');
let JsArrayLikeIterator = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements.JsArrayLikeIterator$impl');
let JsArrayNodeIterator = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements.JsArrayNodeIterator$impl');
let InputType = goog.forwardDeclare('org.jboss.gwt.elemento.core.InputType$impl');
let ElementCreator = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.ElementCreator$impl');
let ElementsBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.ElementsBuilder$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let InputBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
let TextContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $JavaScriptObject = goog.forwardDeclare('vmbootstrap.JavaScriptObject$impl');


class Elements extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLBodyElement>}
   * @public
   */
  static m_body__() {
    Elements.$clinit();
    return /**@type {!HtmlContentBuilder<HTMLBodyElement>} */ (HtmlContentBuilder.$create__elemental2_dom_HTMLElement($Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_address__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("address", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_article__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("article", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_aside__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("aside", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_footer__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("footer", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {number} n
   * @return {HtmlContentBuilder<HTMLHeadingElement>}
   * @public
   */
  static m_h__int(n) {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLHeadingElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("h" + n, Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {number} n
   * @param {?string} text
   * @return {HtmlContentBuilder<HTMLHeadingElement>}
   * @public
   */
  static m_h__int__java_lang_String(n, text) {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(n).m_textContent__java_lang_String(text), HtmlContentBuilder));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_header__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("header", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_hgroup__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("hgroup", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_nav__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("nav", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_section__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("section", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLQuoteElement>}
   * @public
   */
  static m_blockquote__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLQuoteElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("blockquote", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_dd__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("dd", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLDivElement>}
   * @public
   */
  static m_div__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLDivElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("div", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLDListElement>}
   * @public
   */
  static m_dl__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLDListElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("dl", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_dt__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("dt", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_figcaption__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("figcaption", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_figure__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("figure", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLHRElement>}
   * @public
   */
  static m_hr__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLHRElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("hr", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLLIElement>}
   * @public
   */
  static m_li__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLLIElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("li", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_main__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("main", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLOListElement>}
   * @public
   */
  static m_ol__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLOListElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("ol", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLParagraphElement>}
   * @public
   */
  static m_p__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLParagraphElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("p", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLPreElement>}
   * @public
   */
  static m_pre__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLPreElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("pre", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLUListElement>}
   * @public
   */
  static m_ul__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLUListElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("ul", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLAnchorElement>}
   * @public
   */
  static m_a__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("a", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {?string} href
   * @return {HtmlContentBuilder<HTMLAnchorElement>}
   * @public
   */
  static m_a__java_lang_String(href) {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", href), HtmlContentBuilder));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_abbr__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("abbr", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_b__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("b", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLBRElement>}
   * @public
   */
  static m_br__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLBRElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("br", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_cite__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("cite", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_code__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("code", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_dfn__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("dfn", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_em__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("em", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_i__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("i", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_kbd__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("kbd", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_mark__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("mark", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLQuoteElement>}
   * @public
   */
  static m_q__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLQuoteElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("q", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_small__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("small", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_span__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("span", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_strong__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("strong", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_sub__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("sub", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_sup__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("sup", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_time__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("time", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_u__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("u", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_var__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("var", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLElement>}
   * @public
   */
  static m_wbr__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("wbr", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLAreaElement>}
   * @public
   */
  static m_area__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLAreaElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("area", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLAudioElement>}
   * @public
   */
  static m_audio__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLAudioElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("audio", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLImageElement>}
   * @public
   */
  static m_img__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLImageElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("img", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {?string} src
   * @return {EmptyContentBuilder<HTMLImageElement>}
   * @public
   */
  static m_img__java_lang_String(src) {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(/**@type {EmptyContentBuilder<HTMLImageElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("img", Class.$get($JavaScriptObject))).m_attr__java_lang_String__java_lang_String("src", src), EmptyContentBuilder));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLMapElement>}
   * @public
   */
  static m_map__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLMapElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("map", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLTrackElement>}
   * @public
   */
  static m_track__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLTrackElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("track", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLVideoElement>}
   * @public
   */
  static m_video__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLVideoElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("video", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLEmbedElement>}
   * @public
   */
  static m_embed__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLEmbedElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("embed", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLObjectElement>}
   * @public
   */
  static m_object__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLObjectElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("object", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLParamElement>}
   * @public
   */
  static m_param__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLParamElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("param", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLSourceElement>}
   * @public
   */
  static m_source__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLSourceElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("source", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLCanvasElement>}
   * @public
   */
  static m_canvas__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLCanvasElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("canvas", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLElement>}
   * @public
   */
  static m_noscript__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("noscript", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {TextContentBuilder<HTMLScriptElement>}
   * @public
   */
  static m_script__() {
    Elements.$clinit();
    return /**@type {TextContentBuilder<HTMLScriptElement>} */ (Elements.m_textElement__java_lang_String__java_lang_Class("script", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLModElement>}
   * @public
   */
  static m_del__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLModElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("del", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLModElement>}
   * @public
   */
  static m_ins__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLModElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("ins", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableCaptionElement>}
   * @public
   */
  static m_caption__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableCaptionElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("caption", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {EmptyContentBuilder<HTMLTableColElement>}
   * @public
   */
  static m_col__() {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLTableColElement>} */ (Elements.m_emptyElement__java_lang_String__java_lang_Class("col", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableColElement>}
   * @public
   */
  static m_colgroup__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableColElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("colgroup", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableElement>}
   * @public
   */
  static m_table__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("table", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableSectionElement>}
   * @public
   */
  static m_tbody__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("tbody", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableCellElement>}
   * @public
   */
  static m_td__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableCellElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("td", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableSectionElement>}
   * @public
   */
  static m_tfoot__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("tfoot", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableCellElement>}
   * @public
   */
  static m_th__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableCellElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("th", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableSectionElement>}
   * @public
   */
  static m_thead__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableSectionElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("thead", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLTableRowElement>}
   * @public
   */
  static m_tr__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLTableRowElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("tr", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLButtonElement>}
   * @public
   */
  static m_button__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLButtonElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("button", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {?string} text
   * @return {HtmlContentBuilder<HTMLButtonElement>}
   * @public
   */
  static m_button__java_lang_String(text) {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(Elements.m_button__().m_textContent__java_lang_String(text), HtmlContentBuilder));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLDataListElement>}
   * @public
   */
  static m_datalist__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLDataListElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("datalist", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLFieldSetElement>}
   * @public
   */
  static m_fieldset__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLFieldSetElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("fieldset", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLFormElement>}
   * @public
   */
  static m_form__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLFormElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("form", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {InputType} type
   * @return {InputBuilder<HTMLInputElement>}
   * @public
   */
  static m_input__org_jboss_gwt_elemento_core_InputType(type) {
    Elements.$clinit();
    return Elements.m_input__java_lang_String(type.name());
  }
  
  /**
   * @param {?string} type
   * @return {InputBuilder<HTMLInputElement>}
   * @public
   */
  static m_input__java_lang_String(type) {
    Elements.$clinit();
    return /**@type {InputBuilder<HTMLInputElement>} */ (Elements.m_input__java_lang_String__java_lang_Class(type, Class.$get($JavaScriptObject)));
  }
  
  /**
   * @template M_E
   * @param {?string} type
   * @param {Class<M_E>} jType
   * @return {InputBuilder<M_E>}
   * @public
   */
  static m_input__java_lang_String__java_lang_Class(type, jType) {
    Elements.$clinit();
    let el = /**@type {HTMLInputElement} */ ($Casts.$to(Elements.m_createElement__java_lang_String__java_lang_Class("input", jType), HTMLInputElement_$Overlay));
    /**@type {HTMLInputElement} */ (el).type = type;
    return /**@type {!InputBuilder<HTMLInputElement>} */ (InputBuilder.$create__elemental2_dom_HTMLInputElement(el));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLLabelElement>}
   * @public
   */
  static m_label__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLLabelElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("label", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {?string} text
   * @return {HtmlContentBuilder<HTMLLabelElement>}
   * @public
   */
  static m_label__java_lang_String(text) {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_textContent__java_lang_String(text), HtmlContentBuilder));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLLegendElement>}
   * @public
   */
  static m_legend__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLLegendElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("legend", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLMeterElement>}
   * @public
   */
  static m_meter__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLMeterElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("meter", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLOptGroupElement>}
   * @public
   */
  static m_optgroup__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLOptGroupElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("optgroup", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {TextContentBuilder<HTMLOptionElement>}
   * @public
   */
  static m_option__() {
    Elements.$clinit();
    return /**@type {TextContentBuilder<HTMLOptionElement>} */ (Elements.m_textElement__java_lang_String__java_lang_Class("option", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @param {?string} text
   * @return {TextContentBuilder<HTMLOptionElement>}
   * @public
   */
  static m_option__java_lang_String(text) {
    Elements.$clinit();
    return /**@type {TextContentBuilder<HTMLOptionElement>} */ ($Casts.$to(Elements.m_option__().m_textContent__java_lang_String(text), TextContentBuilder));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLOutputElement>}
   * @public
   */
  static m_output__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLOutputElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("output", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLProgressElement>}
   * @public
   */
  static m_progress__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLProgressElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("progress", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {HtmlContentBuilder<HTMLSelectElement>}
   * @public
   */
  static m_select__() {
    Elements.$clinit();
    return /**@type {HtmlContentBuilder<HTMLSelectElement>} */ (Elements.m_htmlElement__java_lang_String__java_lang_Class("select", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {TextContentBuilder<HTMLTextAreaElement>}
   * @public
   */
  static m_textarea__() {
    Elements.$clinit();
    return /**@type {TextContentBuilder<HTMLTextAreaElement>} */ (Elements.m_textElement__java_lang_String__java_lang_Class("textarea", Class.$get($JavaScriptObject)));
  }
  
  /**
   * @return {ElementsBuilder}
   * @public
   */
  static m_elements__() {
    Elements.$clinit();
    return ElementsBuilder.$create__();
  }
  
  /**
   * @template M_E
   * @param {?string} tag
   * @param {Class<M_E>} type
   * @return {EmptyContentBuilder<M_E>}
   * @public
   */
  static m_emptyElement__java_lang_String__java_lang_Class(tag, type) {
    Elements.$clinit();
    return /**@type {EmptyContentBuilder<HTMLElement>} */ (Elements.m_emptyElement__java_util_function_Supplier_$p_org_jboss_gwt_elemento_core_Elements(/**@type {Supplier<HTMLElement>} */ (Supplier.$adapt((() =>{
      return Elements.m_createElement__java_lang_String__java_lang_Class(tag, type);
    })))));
  }
  
  /**
   * @template M_E
   * @param {Supplier<M_E>} element
   * @return {EmptyContentBuilder<M_E>}
   * @public
   */
  static m_emptyElement__java_util_function_Supplier_$p_org_jboss_gwt_elemento_core_Elements(element) {
    Elements.$clinit();
    return /**@type {!EmptyContentBuilder<HTMLElement>} */ (EmptyContentBuilder.$create__elemental2_dom_HTMLElement(/**@type {HTMLElement} */ ($Casts.$to(element.m_get__(), HTMLElement_$Overlay))));
  }
  
  /**
   * @template M_E
   * @param {?string} tag
   * @param {Class<M_E>} type
   * @return {TextContentBuilder<M_E>}
   * @public
   */
  static m_textElement__java_lang_String__java_lang_Class(tag, type) {
    Elements.$clinit();
    return /**@type {!TextContentBuilder<HTMLElement>} */ (TextContentBuilder.$create__elemental2_dom_HTMLElement(Elements.m_createElement__java_lang_String__java_lang_Class(tag, type)));
  }
  
  /**
   * @template M_E
   * @param {?string} tag
   * @param {Class<M_E>} type
   * @return {HtmlContentBuilder<M_E>}
   * @public
   */
  static m_htmlElement__java_lang_String__java_lang_Class(tag, type) {
    Elements.$clinit();
    return /**@type {!HtmlContentBuilder<HTMLElement>} */ (HtmlContentBuilder.$create__elemental2_dom_HTMLElement(Elements.m_createElement__java_lang_String__java_lang_Class(tag, type)));
  }
  
  /**
   * @template M_E
   * @param {?string} tag
   * @param {Class<M_E>} type
   * @return {M_E}
   * @public
   */
  static m_createElement__java_lang_String__java_lang_Class(tag, type) {
    Elements.$clinit();
    return Elements.$f_createElement__org_jboss_gwt_elemento_core_Elements.m_create__java_lang_String__java_lang_Class(tag, type);
  }
  
  /**
   * @template M_T
   * @return {Predicate<M_T>}
   * @public
   */
  static m_htmlElements__() {
    Elements.$clinit();
    return /**@type {!FilterHTMLElements<Node>} */ (FilterHTMLElements.$create__());
  }
  
  /**
   * @template M_T
   * @return {j_u_function_Function<M_T, HTMLElement>}
   * @public
   */
  static m_asHtmlElement__() {
    Elements.$clinit();
    return /**@type {!AsHTMLElement<Node>} */ (AsHTMLElement.$create__());
  }
  
  /**
   * @template M_E
   * @param {IArrayLike<M_E>} data
   * @return {Iterator<M_E>}
   * @public
   */
  static m_iterator__jsinterop_base_JsArrayLike(data) {
    Elements.$clinit();
    return !$Equality.$same(data, null) ? /**@type {!JsArrayLikeIterator<*>} */ (JsArrayLikeIterator.$create__jsinterop_base_JsArrayLike(data)) : /**@type {Iterator<*>} */ (Collections.m_emptyIterator__());
  }
  
  /**
   * @param {Node} parent
   * @return {Iterator<Node>}
   * @public
   */
  static m_iterator__elemental2_dom_Node(parent) {
    Elements.$clinit();
    return !$Equality.$same(parent, null) ? JsArrayNodeIterator.$create__elemental2_dom_Node(parent) : /**@type {Iterator<Node>} */ (Collections.m_emptyIterator__());
  }
  
  /**
   * @param {HTMLElement} parent
   * @return {Iterator<HTMLElement>}
   * @public
   */
  static m_iterator__elemental2_dom_HTMLElement(parent) {
    Elements.$clinit();
    return !$Equality.$same(parent, null) ? JsArrayElementIterator.$create__elemental2_dom_HTMLElement(parent) : /**@type {Iterator<HTMLElement>} */ (Collections.m_emptyIterator__());
  }
  
  /**
   * @template M_E
   * @param {IArrayLike<M_E>} nodes
   * @return {Stream<M_E>}
   * @public
   */
  static m_stream__jsinterop_base_JsArrayLike(nodes) {
    Elements.$clinit();
    if ($Equality.$same(nodes, null)) {
      return /**@type {Stream<*>} */ (Stream.m_empty__());
    } else {
      return /**@type {Stream<*>} */ (StreamSupport.m_stream__java_util_Spliterator__boolean(/**@type {Spliterator<*>} */ (Spliterators.m_spliteratorUnknownSize__java_util_Iterator__int(/**@type {Iterator<*>} */ (Elements.m_iterator__jsinterop_base_JsArrayLike(nodes)), 0)), false));
    }
  }
  
  /**
   * @param {Node} parent
   * @return {Stream<Node>}
   * @public
   */
  static m_stream__elemental2_dom_Node(parent) {
    Elements.$clinit();
    if ($Equality.$same(parent, null)) {
      return /**@type {Stream<Node>} */ (Stream.m_empty__());
    } else {
      return /**@type {Stream<Node>} */ (StreamSupport.m_stream__java_util_Spliterator__boolean(/**@type {Spliterator<Node>} */ (Spliterators.m_spliteratorUnknownSize__java_util_Iterator__int(Elements.m_iterator__elemental2_dom_Node(parent), 0)), false));
    }
  }
  
  /**
   * @param {HTMLElement} parent
   * @return {Stream<HTMLElement>}
   * @public
   */
  static m_stream__elemental2_dom_HTMLElement(parent) {
    Elements.$clinit();
    if ($Equality.$same(parent, null)) {
      return /**@type {Stream<HTMLElement>} */ (Stream.m_empty__());
    } else {
      return /**@type {Stream<HTMLElement>} */ (StreamSupport.m_stream__java_util_Spliterator__boolean(/**@type {Spliterator<HTMLElement>} */ (Spliterators.m_spliteratorUnknownSize__java_util_Iterator__int(Elements.m_iterator__elemental2_dom_HTMLElement(parent), 0)), false));
    }
  }
  
  /**
   * @template M_E
   * @param {IArrayLike<M_E>} nodes
   * @return {Iterable<M_E>}
   * @public
   */
  static m_elements__jsinterop_base_JsArrayLike(nodes) {
    Elements.$clinit();
    return /**@type {Iterable<*>} */ (Iterable.$adapt((() =>{
      return /**@type {Iterator<*>} */ (Elements.m_iterator__jsinterop_base_JsArrayLike(nodes));
    })));
  }
  
  /**
   * @param {Node} parent
   * @return {Iterable<Node>}
   * @public
   */
  static m_children__elemental2_dom_Node(parent) {
    Elements.$clinit();
    return Iterable.$adapt((() =>{
      return Elements.m_iterator__elemental2_dom_Node(parent);
    }));
  }
  
  /**
   * @param {HTMLElement} parent
   * @return {Iterable<HTMLElement>}
   * @public
   */
  static m_children__elemental2_dom_HTMLElement(parent) {
    Elements.$clinit();
    return Iterable.$adapt((() =>{
      return Elements.m_iterator__elemental2_dom_HTMLElement(parent);
    }));
  }
  
  /**
   * @param {Element} parent
   * @param {Element} child
   * @return {void}
   * @public
   */
  static m_lazyAppend__elemental2_dom_Element__elemental2_dom_Element(parent, child) {
    Elements.$clinit();
    if (!parent.contains(child)) {
      parent.appendChild(child);
    }
  }
  
  /**
   * @param {Element} newElement
   * @param {Element} after
   * @return {void}
   * @public
   */
  static m_insertAfter__elemental2_dom_Element__elemental2_dom_Element(newElement, after) {
    Elements.$clinit();
    after.parentNode.insertBefore(newElement, after.nextSibling);
  }
  
  /**
   * @param {Element} newElement
   * @param {Element} after
   * @return {void}
   * @public
   */
  static m_lazyInsertAfter__elemental2_dom_Element__elemental2_dom_Element(newElement, after) {
    Elements.$clinit();
    if (!after.parentNode.contains(newElement)) {
      after.parentNode.insertBefore(newElement, after.nextSibling);
    }
  }
  
  /**
   * @param {Element} parent
   * @param {Element} newElement
   * @param {Element} after
   * @return {void}
   * @public
   */
  static m_lazyInsertAfter__elemental2_dom_Element__elemental2_dom_Element__elemental2_dom_Element(parent, newElement, after) {
    Elements.$clinit();
    if (!parent.contains(newElement)) {
      parent.insertBefore(newElement, after.nextSibling);
    }
  }
  
  /**
   * @param {Element} newElement
   * @param {Element} before
   * @return {void}
   * @public
   */
  static m_insertBefore__elemental2_dom_Element__elemental2_dom_Element(newElement, before) {
    Elements.$clinit();
    before.parentNode.insertBefore(newElement, before);
  }
  
  /**
   * @param {Element} newElement
   * @param {Element} before
   * @return {void}
   * @public
   */
  static m_lazyInsertBefore__elemental2_dom_Element__elemental2_dom_Element(newElement, before) {
    Elements.$clinit();
    if (!before.parentNode.contains(newElement)) {
      before.parentNode.insertBefore(newElement, before);
    }
  }
  
  /**
   * @param {Element} parent
   * @param {Element} child
   * @param {Element} before
   * @return {void}
   * @public
   */
  static m_lazyInsertBefore__elemental2_dom_Element__elemental2_dom_Element__elemental2_dom_Element(parent, child, before) {
    Elements.$clinit();
    if (!parent.contains(child)) {
      parent.insertBefore(child, before);
    }
  }
  
  /**
   * @param {Element} element
   * @return {void}
   * @public
   */
  static m_removeChildrenFrom__elemental2_dom_Element(element) {
    Elements.$clinit();
    if (!$Equality.$same(element, null)) {
      while (!$Equality.$same(element.firstChild, null)) {
        element.removeChild(element.firstChild);
      }
    }
  }
  
  /**
   * @param {Element} element
   * @return {boolean}
   * @public
   */
  static m_failSafeRemoveFromParent__elemental2_dom_Element(element) {
    Elements.$clinit();
    return Elements.m_failSafeRemove__elemental2_dom_Node__elemental2_dom_Element(!$Equality.$same(element, null) ? element.parentNode : null, element);
  }
  
  /**
   * @param {Node} parent
   * @param {Element} child
   * @return {boolean}
   * @public
   */
  static m_failSafeRemove__elemental2_dom_Node__elemental2_dom_Element(parent, child) {
    Elements.$clinit();
    if (!$Equality.$same(parent, null) && !$Equality.$same(child, null) && parent.contains(child)) {
      return !$Equality.$same(parent.removeChild(child), null);
    }
    return false;
  }
  
  /**
   * @param {?string} name
   * @return {Element}
   * @public
   */
  static m_dataElement__java_lang_String(name) {
    Elements.$clinit();
    return $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.querySelector("[data-element=" + j_l_String.m_valueOf__java_lang_Object(name) + "]");
  }
  
  /**
   * @param {Element} context
   * @param {?string} name
   * @return {Element}
   * @public
   */
  static m_dataElement__elemental2_dom_Element__java_lang_String(context, name) {
    Elements.$clinit();
    return !$Equality.$same(context, null) ? context.querySelector("[data-element=" + j_l_String.m_valueOf__java_lang_Object(name) + "]") : null;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {boolean}
   * @public
   */
  static m_isVisible__elemental2_dom_HTMLElement(element) {
    Elements.$clinit();
    return !$Equality.$same(element, null) && !j_l_String.m_equals__java_lang_String__java_lang_Object("none", element.style.display);
  }
  
  /**
   * @param {HTMLElement} element
   * @param {boolean} visible
   * @return {void}
   * @public
   */
  static m_setVisible__elemental2_dom_HTMLElement__boolean(element, visible) {
    Elements.$clinit();
    if (!$Equality.$same(element, null)) {
      element.style.display = visible ? "" : "none";
    }
  }
  
  /**
   * @param {HTMLElement} element
   * @param {?string} css
   * @param {boolean} condition
   * @return {void}
   * @public
   */
  static m_toggle__elemental2_dom_HTMLElement__java_lang_String__boolean(element, css, condition) {
    Elements.$clinit();
    if (!$Equality.$same(element, null)) {
      if (condition) {
        element.classList.add(css);
      } else {
        element.classList.remove(css);
      }
    }
  }
  
  /**
   * @param {HTMLElement} element
   * @param {SafeHtml} html
   * @return {void}
   * @public
   */
  static m_innerHtml__elemental2_dom_HTMLElement__org_gwtproject_safehtml_shared_SafeHtml(element, html) {
    Elements.$clinit();
    if (!$Equality.$same(element, null)) {
      element.innerHTML = html.m_asString__();
    }
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_createDocumentUniqueId__() {
    Elements.$clinit();
    return "elemento-uid-" + Elements.$f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_.m_getAsInt__();
  }
  
  /**
   * Factory method corresponding to constructor 'Elements()'.
   * @return {!Elements}
   * @public
   */
  static $create__() {
    Elements.$clinit();
    let $instance = new Elements();
    $instance.$ctor__org_jboss_gwt_elemento_core_Elements__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Elements()'.
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_Elements__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {ElementCreator}
   * @public
   */
  static get f_createElement__org_jboss_gwt_elemento_core_Elements() {
    return (Elements.$clinit(), Elements.$f_createElement__org_jboss_gwt_elemento_core_Elements);
  }
  
  /**
   * @param {ElementCreator} value
   * @return {void}
   * @public
   */
  static set f_createElement__org_jboss_gwt_elemento_core_Elements(value) {
    (Elements.$clinit(), Elements.$f_createElement__org_jboss_gwt_elemento_core_Elements = value);
  }
  
  /**
   * @return {IntSupplier}
   * @public
   */
  static get f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_() {
    return (Elements.$clinit(), Elements.$f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_);
  }
  
  /**
   * @param {IntSupplier} value
   * @return {void}
   * @public
   */
  static set f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_(value) {
    (Elements.$clinit(), Elements.$f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Elements;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Elements);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Elements.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLElement_$Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    HTMLInputElement_$Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    Class = goog.module.get('java.lang.Class$impl');
    Iterable = goog.module.get('java.lang.Iterable$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Collections = goog.module.get('java.util.Collections$impl');
    Spliterators = goog.module.get('java.util.Spliterators$impl');
    IntSupplier = goog.module.get('java.util.function.IntSupplier$impl');
    Supplier = goog.module.get('java.util.function.Supplier$impl');
    Stream = goog.module.get('java.util.stream.Stream$impl');
    StreamSupport = goog.module.get('java.util.stream.StreamSupport$impl');
    Any_$Overlay = goog.module.get('jsinterop.base.Any.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    JsPropertyMap_$Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $1 = goog.module.get('org.jboss.gwt.elemento.core.Elements.$1$impl');
    AsHTMLElement = goog.module.get('org.jboss.gwt.elemento.core.Elements.AsHTMLElement$impl');
    FilterHTMLElements = goog.module.get('org.jboss.gwt.elemento.core.Elements.FilterHTMLElements$impl');
    JsArrayElementIterator = goog.module.get('org.jboss.gwt.elemento.core.Elements.JsArrayElementIterator$impl');
    JsArrayLikeIterator = goog.module.get('org.jboss.gwt.elemento.core.Elements.JsArrayLikeIterator$impl');
    JsArrayNodeIterator = goog.module.get('org.jboss.gwt.elemento.core.Elements.JsArrayNodeIterator$impl');
    ElementsBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.ElementsBuilder$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    InputBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
    TextContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $JavaScriptObject = goog.module.get('vmbootstrap.JavaScriptObject$impl');
    j_l_Object.$clinit();
    Elements.$f_createElement__org_jboss_gwt_elemento_core_Elements = $1.$create__();
    Elements.$f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_ = IntSupplier.$adapt((() =>{
      let map = /**@type {Object<string, *>} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.f_document__elemental2_dom_DomGlobal_$Overlay));
      if (!JsPropertyMap_$Overlay.m_has__jsinterop_base_JsPropertyMap__java_lang_String(map, Elements.f_ELEMENTO_UID__org_jboss_gwt_elemento_core_Elements_)) {
        JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, Elements.f_ELEMENTO_UID__org_jboss_gwt_elemento_core_Elements_, 0);
      }
      let uid = Any_$Overlay.m_asInt__jsinterop_base_Any(JsPropertyMap_$Overlay.m_getAny__jsinterop_base_JsPropertyMap__java_lang_String(map, Elements.f_ELEMENTO_UID__org_jboss_gwt_elemento_core_Elements_)) + 1;
      JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, Elements.f_ELEMENTO_UID__org_jboss_gwt_elemento_core_Elements_, uid);
      return uid;
    }));
  }
  
  
};

$Util.$setClassMetadata(Elements, $Util.$makeClassName('org.jboss.gwt.elemento.core.Elements'));


/** @public {?string} @const */
Elements.f_ELEMENTO_UID__org_jboss_gwt_elemento_core_Elements_ = "elementoUid";


/** @private {ElementCreator} */
Elements.$f_createElement__org_jboss_gwt_elemento_core_Elements;


/** @private {IntSupplier} */
Elements.$f_createDocumentUniqueId__org_jboss_gwt_elemento_core_Elements_;




exports = Elements; 
//# sourceMappingURL=Elements.js.map