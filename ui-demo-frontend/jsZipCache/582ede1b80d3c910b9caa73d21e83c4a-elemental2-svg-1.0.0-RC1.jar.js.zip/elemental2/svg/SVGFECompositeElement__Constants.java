package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGFECompositeElement", namespace = JsPackage.GLOBAL)
class SVGFECompositeElement__Constants {
  static double SVG_FECOMPOSITE_OPERATOR_ARITHMETIC;
  static double SVG_FECOMPOSITE_OPERATOR_ATOP;
  static double SVG_FECOMPOSITE_OPERATOR_IN;
  static double SVG_FECOMPOSITE_OPERATOR_OUT;
  static double SVG_FECOMPOSITE_OPERATOR_OVER;
  static double SVG_FECOMPOSITE_OPERATOR_UNKNOWN;
  static double SVG_FECOMPOSITE_OPERATOR_XOR;
}
