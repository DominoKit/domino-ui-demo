/**
 * @fileoverview transpiled from elemental2.svg.SVGPaint$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGPaint.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_NONE__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_NONE__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_NONE__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_NONE__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_UNKNOWN__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_UNKNOWN__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_UNKNOWN__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_UNKNOWN__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_URI__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_URI__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_URI_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_URI_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_URI_NONE__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_NONE__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_URI_NONE__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_NONE__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_URI_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_URI_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGPaint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
    $Overlay.$f_SVG_PAINTTYPE_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_CURRENTCOLOR;
    $Overlay.$f_SVG_PAINTTYPE_NONE__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_NONE;
    $Overlay.$f_SVG_PAINTTYPE_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_RGBCOLOR;
    $Overlay.$f_SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR;
    $Overlay.$f_SVG_PAINTTYPE_UNKNOWN__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_UNKNOWN;
    $Overlay.$f_SVG_PAINTTYPE_URI__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_URI;
    $Overlay.$f_SVG_PAINTTYPE_URI_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_URI_CURRENTCOLOR;
    $Overlay.$f_SVG_PAINTTYPE_URI_NONE__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_URI_NONE;
    $Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_URI_RGBCOLOR;
    $Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay = SVGPaint.SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR;
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGPaint'));


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_NONE__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_UNKNOWN__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_URI__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_URI_CURRENTCOLOR__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_URI_NONE__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR__elemental2_svg_SVGPaint_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PAINTTYPE_URI_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGPaint_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGPaint$$Overlay.js.map