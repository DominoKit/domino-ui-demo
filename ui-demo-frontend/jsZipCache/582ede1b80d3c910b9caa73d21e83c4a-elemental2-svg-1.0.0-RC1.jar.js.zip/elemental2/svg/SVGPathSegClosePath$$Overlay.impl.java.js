/**
 * @fileoverview transpiled from elemental2.svg.SVGPathSegClosePath$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGPathSegClosePath.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGPathSegClosePath;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGPathSegClosePath'));


exports = $Overlay; 
//# sourceMappingURL=SVGPathSegClosePath$$Overlay.js.map