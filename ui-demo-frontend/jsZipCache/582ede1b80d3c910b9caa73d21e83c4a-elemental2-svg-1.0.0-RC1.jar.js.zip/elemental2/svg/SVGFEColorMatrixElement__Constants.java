package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGFEColorMatrixElement", namespace = JsPackage.GLOBAL)
class SVGFEColorMatrixElement__Constants {
  static double SVG_FECOLORMATRIX_TYPE_HUEROTATE;
  static double SVG_FECOLORMATRIX_TYPE_LUMINANCETOALPHA;
  static double SVG_FECOLORMATRIX_TYPE_MATRIX;
  static double SVG_FECOLORMATRIX_TYPE_SATURATE;
  static double SVG_FECOLORMATRIX_TYPE_UNKNOWN;
}
