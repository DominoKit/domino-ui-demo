package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGFEConvolveMatrixElement", namespace = JsPackage.GLOBAL)
class SVGFEConvolveMatrixElement__Constants {
  static double SVG_EDGEMODE_DUPLICATE;
  static double SVG_EDGEMODE_NONE;
  static double SVG_EDGEMODE_UNKNOWN;
  static double SVG_EDGEMODE_WRAP;
}
