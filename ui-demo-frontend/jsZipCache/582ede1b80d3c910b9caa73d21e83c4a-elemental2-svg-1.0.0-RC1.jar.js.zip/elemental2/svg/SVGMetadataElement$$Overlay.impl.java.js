/**
 * @fileoverview transpiled from elemental2.svg.SVGMetadataElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGMetadataElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGMetadataElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGMetadataElement'));


exports = $Overlay; 
//# sourceMappingURL=SVGMetadataElement$$Overlay.js.map