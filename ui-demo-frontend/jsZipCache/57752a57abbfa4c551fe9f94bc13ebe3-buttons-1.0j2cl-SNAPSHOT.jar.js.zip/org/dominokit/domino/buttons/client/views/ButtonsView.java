package org.dominokit.domino.buttons.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface ButtonsView extends View, DemoView{
}