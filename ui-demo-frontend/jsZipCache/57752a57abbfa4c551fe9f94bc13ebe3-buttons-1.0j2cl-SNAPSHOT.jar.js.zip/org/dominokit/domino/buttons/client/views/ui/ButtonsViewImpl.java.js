/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ButtonsView = goog.require('org.dominokit.domino.buttons.client.views.ButtonsView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _FontSizeUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.FontSizeUnionType.$Overlay');
const _MarginBottomUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay');
const _MarginTopUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.MarginTopUnionType.$Overlay');
const _$Overlay = goog.require('elemental2.dom.CSSProperties.MarginUnionType.$Overlay');
const _MinWidthUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.MinWidthUnionType.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _CodeResource = goog.require('org.dominokit.domino.buttons.client.views.CodeResource');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _ButtonSize = goog.require('org.dominokit.domino.ui.button.ButtonSize');
const _ButtonsToolbar = goog.require('org.dominokit.domino.ui.button.ButtonsToolbar');
const _CircleSize = goog.require('org.dominokit.domino.ui.button.CircleSize');
const _DropdownAction = goog.require('org.dominokit.domino.ui.button.DropdownAction');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');
const _IconButton = goog.require('org.dominokit.domino.ui.button.IconButton');
const _SplitButton = goog.require('org.dominokit.domino.ui.button.SplitButton');
const _ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup');
const _JustifiedGroup = goog.require('org.dominokit.domino.ui.button.group.JustifiedGroup');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ButtonsViewImpl = goog.require('org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl$impl');
exports = ButtonsViewImpl;
 