/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ButtonsView = goog.require('org.dominokit.domino.buttons.client.views.ButtonsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let FontSizeUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.FontSizeUnionType.$Overlay$impl');
let MarginBottomUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
let MarginTopUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginTopUnionType.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginUnionType.$Overlay$impl');
let MinWidthUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MinWidthUnionType.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.buttons.client.views.CodeResource$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let ButtonSize = goog.forwardDeclare('org.dominokit.domino.ui.button.ButtonSize$impl');
let ButtonsToolbar = goog.forwardDeclare('org.dominokit.domino.ui.button.ButtonsToolbar$impl');
let CircleSize = goog.forwardDeclare('org.dominokit.domino.ui.button.CircleSize$impl');
let DropdownAction = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownAction$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let IconButton = goog.forwardDeclare('org.dominokit.domino.ui.button.IconButton$impl');
let SplitButton = goog.forwardDeclare('org.dominokit.domino.ui.button.SplitButton$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
let JustifiedGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.JustifiedGroup$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ButtonsView}
  */
class ButtonsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ButtonsViewImpl()'.
   * @return {!ButtonsViewImpl}
   * @public
   */
  static $create__() {
    ButtonsViewImpl.$clinit();
    let $instance = new ButtonsViewImpl();
    $instance.$ctor__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ButtonsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("BUTTONS").m_asElement__());
    this.m_initBootstrapButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initMaterialDesignButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initButtonSizes___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initBlockButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initDisabledButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initIconButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initTextIconButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("BUTTON GROUPS", "Group a series of buttons together on a single line with the button group").m_asElement__());
    this.m_initButtonsBasicGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initButtonsToolbar___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initSizingGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initNestingGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initVerticalGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initJustifyGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("BUTTON DROPDOWNS", "Use any button to trigger a dropdown menu by placing it within a .btn-group and providing the proper menu markup.").m_asElement__());
    this.m_initSingleDropdownButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initSplitButton___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
    this.m_initDropUp___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDropUp___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("DROPUP VARIATION", "Trigger dropdown menus above elements.");
    let element = DropdownButton.m_createDefault__java_lang_String("DEFAULT").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_dropup__().m_asElement__();
    let primary = DropdownButton.m_createPrimary__java_lang_String("PRIMARY").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_dropup__().m_asElement__();
    let success = DropdownButton.m_createSuccess__java_lang_String("SUCCESS").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_dropup__().m_asElement__();
    let info = DropdownButton.m_createInfo__java_lang_String("INFO").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_dropup__().m_asElement__();
    let danger = DropdownButton.m_createDanger__java_lang_String("Dropdown").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_dropup__();
    let group = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDanger__java_lang_String("DANGER")).m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(danger).m_asElement__();
    element.style.margin = $Overlay.m_of__java_lang_Object("5px");
    primary.style.margin = $Overlay.m_of__java_lang_Object("5px");
    success.style.margin = $Overlay.m_of__java_lang_Object("5px");
    info.style.margin = $Overlay.m_of__java_lang_Object("5px");
    group.style.margin = $Overlay.m_of__java_lang_Object("5px");
    card.m_appendContent__elemental2_dom_Node(element);
    card.m_appendContent__elemental2_dom_Node(primary);
    card.m_appendContent__elemental2_dom_Node(success);
    card.m_appendContent__elemental2_dom_Node(info);
    card.m_appendContent__elemental2_dom_Node(group);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initDropUp__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSplitButton___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("SPLITE BUTTON DROPDOWNS", "Similarly, create split button dropdowns with the same markup changes, only with a separate button.");
    let defaultDropdown = DropdownButton.m_createDefault__java_lang_String("Toggle Dropdown").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let defaultSplit = SplitButton.m_createDefault__java_lang_String("DEFAULT").m_addDropdown__org_dominokit_domino_ui_button_DropdownButton(defaultDropdown).m_asElement__();
    card.m_appendContent__elemental2_dom_Node(defaultSplit);
    let primaryDropdown = DropdownButton.m_createPrimary__java_lang_String("Toggle Dropdown").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let primarySplit = SplitButton.m_createPrimary__java_lang_String("PRIMARY").m_addDropdown__org_dominokit_domino_ui_button_DropdownButton(primaryDropdown).m_asElement__();
    card.m_appendContent__elemental2_dom_Node(primarySplit);
    let warningDropdown = DropdownButton.m_createWarning__java_lang_String("Toggle Dropdown").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let warningSplit = SplitButton.m_createWarning__java_lang_String("WARNING").m_addDropdown__org_dominokit_domino_ui_button_DropdownButton(warningDropdown).m_asElement__();
    card.m_appendContent__elemental2_dom_Node(warningSplit);
    let infoDropdown = DropdownButton.m_createInfo__java_lang_String("Toggle Dropdown").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let infoSplit = SplitButton.m_createInfo__java_lang_String("INFO").m_addDropdown__org_dominokit_domino_ui_button_DropdownButton(infoDropdown).m_asElement__();
    card.m_appendContent__elemental2_dom_Node(infoSplit);
    defaultSplit.style.margin = $Overlay.m_of__java_lang_Object("10px");
    primarySplit.style.margin = $Overlay.m_of__java_lang_Object("10px");
    warningSplit.style.margin = $Overlay.m_of__java_lang_Object("10px");
    infoSplit.style.margin = $Overlay.m_of__java_lang_Object("10px");
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initSplitButton__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSingleDropdownButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("SINGLE BUTTON DROPDOWNS", "Turn a button into a dropdown toggle with some basic markup changes.");
    let defaultDropdown = DropdownButton.m_createDefault__java_lang_String("DEFAULT").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let primaryDropdown = DropdownButton.m_createPrimary__java_lang_String("PRIMARY").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let infoDropdown = DropdownButton.m_createInfo__java_lang_String("INFO").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let dangerButton = DropdownButton.m_createDanger__java_lang_String("DANGER").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let warningDropdown = DropdownButton.m_createWarning__java_lang_String("WARNING").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    let dropdownButton = DropdownButton.$create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_delete__()).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Another action")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Something else here")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Separated link"));
    defaultDropdown.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryDropdown.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoDropdown.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningDropdown.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    dangerButton.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    dropdownButton.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    card.m_appendContent__elemental2_dom_Node(defaultDropdown.m_asElement__());
    card.m_appendContent__elemental2_dom_Node(primaryDropdown.m_asElement__());
    card.m_appendContent__elemental2_dom_Node(infoDropdown.m_asElement__());
    card.m_appendContent__elemental2_dom_Node(warningDropdown.m_asElement__());
    card.m_appendContent__elemental2_dom_Node(dangerButton.m_asElement__());
    card.m_appendContent__elemental2_dom_Node(dropdownButton.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initSingleDropdownButtons__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initJustifyGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let justifiedGroupCard = Card.m_create__java_lang_String__java_lang_String("JUSTIFIED BUTTON GROUPS", "Make a group of buttons stretch at equal sizes to span the entire width of its parent. Also works with button dropdowns within the button group.");
    let dropDown = DropdownButton.m_createDefault__java_lang_String("Drop down").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action")).m_separator__().m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Action2"));
    let justifiedGroup = JustifiedGroup.m_create__();
    justifiedGroup.m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("LEFT"));
    justifiedGroup.m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("MIDDLE"));
    justifiedGroup.m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDanger__java_lang_String("RIGHT"));
    justifiedGroup.m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(dropDown);
    let element1 = justifiedGroup.m_asElement__();
    element1.style.margin = $Overlay.m_of__java_lang_Object("5px");
    element1.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    justifiedGroupCard.m_getBody__().appendChild(justifiedGroup.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(justifiedGroupCard.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initJustifyGroup__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initVerticalGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let verticalGroupCard = Card.m_create__java_lang_String__java_lang_String("VERTICAL VARIATION", "Make a set of buttons appear vertically stacked rather than horizontally.");
    let group = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("Button")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("Button")).m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(DropdownButton.m_createInfo__java_lang_String("Dropdown").m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Dropdown link")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Dropdown link"))).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDanger__java_lang_String("Button")).m_verticalAlign__();
    group.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    verticalGroupCard.m_getBody__().appendChild(group.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(verticalGroupCard.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initVerticalGroup__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initNestingGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("SIZING", "Dropdown can be used inside a group of buttons.");
    let defaultGroup = this.m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
    defaultGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    let primaryGroup = this.m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
    primaryGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    let infoGroup = this.m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
    infoGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    let successGroup = this.m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
    successGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    successGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    let dangerGroup = this.m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
    dangerGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    dangerGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    let warningGroup = this.m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
    warningGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(defaultGroup);
    card.m_appendContent__elemental2_dom_Node(primaryGroup);
    card.m_appendContent__elemental2_dom_Node(infoGroup);
    card.m_appendContent__elemental2_dom_Node(successGroup);
    card.m_appendContent__elemental2_dom_Node(dangerGroup);
    card.m_appendContent__elemental2_dom_Node(warningGroup);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initNestingGroup__()).m_asElement__());
  }
  
  /**
   * @param {StyleType} type
   * @return {HTMLElement}
   * @public
   */
  m_numbersNestedGroup__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(type) {
    let primaryDropDown = DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType("Dropdown", type).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Dropdown link")).m_addAction__org_dominokit_domino_ui_button_DropdownAction(DropdownAction.m_create__java_lang_String("Dropdown link"));
    return ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("1").m_setButtonType__org_dominokit_domino_ui_style_StyleType(type)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("2").m_setButtonType__org_dominokit_domino_ui_style_StyleType(type)).m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(primaryDropDown).m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSizingGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("SIZING", "Instead of applying button sizing classes to every button in a group, size can be applied to the group and will be applied to every button.");
    let row = Row.m_create__();
    let column1 = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_nine__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let largeGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("RIGHT")).m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize).m_asElement__();
    largeGroup.style.margin = $Overlay.m_of__java_lang_Object("15px");
    column1.m_asElement__().appendChild(this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Large Button Group"));
    column1.m_asElement__().appendChild(largeGroup);
    let column2 = column1.m_copy__();
    let defaultGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("RIGHT")).m_asElement__();
    defaultGroup.style.margin = $Overlay.m_of__java_lang_Object("15px");
    column2.m_asElement__().appendChild(this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Default Button Group"));
    column2.m_asElement__().appendChild(defaultGroup);
    let column3 = column1.m_copy__();
    let smallGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("RIGHT")).m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize).m_asElement__();
    smallGroup.style.margin = $Overlay.m_of__java_lang_Object("15px");
    column3.m_asElement__().appendChild(this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Small Button Group"));
    column3.m_asElement__().appendChild(smallGroup);
    let column4 = column1.m_copy__();
    let xsmallGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("RIGHT")).m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize).m_asElement__();
    xsmallGroup.style.margin = $Overlay.m_of__java_lang_Object("15px");
    column4.m_asElement__().appendChild(this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Extra-Small Button Group"));
    column4.m_asElement__().appendChild(xsmallGroup);
    column1.m_asElement__().classList.add("align-center");
    column2.m_asElement__().classList.add("align-center");
    column3.m_asElement__().classList.add("align-center");
    column4.m_asElement__().classList.add("align-center");
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column1).m_addColumn__org_dominokit_domino_ui_column_Column(column2).m_addColumn__org_dominokit_domino_ui_column_Column(column3).m_addColumn__org_dominokit_domino_ui_column_Column(column4);
    card.m_appendContent__elemental2_dom_Node(row.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initSizingGroup__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initButtonsToolbar___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("BUTTON TOOLBAR", "Create buttons toolbar");
    let row = Row.m_create__();
    let firstDefaultGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("1")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("2")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("3"));
    let secondDefaultGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("4")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("5")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("6"));
    let thirdDefaultGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("7"));
    let defaultButtonsToolbar = ButtonsToolbar.m_create__().m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(firstDefaultGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(secondDefaultGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(thirdDefaultGroup);
    defaultButtonsToolbar.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    row.m_asElement__().appendChild(defaultButtonsToolbar.m_asElement__());
    let firstPrimaryGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("1")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("2")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("3"));
    let secondPrimaryGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("4")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("5")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("6"));
    let thirdPrimaryGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("7"));
    let primaryButtonsToolbar = ButtonsToolbar.m_create__().m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(firstPrimaryGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(secondPrimaryGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(thirdPrimaryGroup);
    primaryButtonsToolbar.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    row.m_asElement__().appendChild(primaryButtonsToolbar.m_asElement__());
    let firstInfoGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("1")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("2")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("3"));
    let secondInfoGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("4")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("5")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("6"));
    let thirdInfoGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("7"));
    let infoButtonsToolbar = ButtonsToolbar.m_create__().m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(firstInfoGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(secondInfoGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(thirdInfoGroup);
    infoButtonsToolbar.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    row.m_asElement__().appendChild(infoButtonsToolbar.m_asElement__());
    let firstColorGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("1").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("2").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("3").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color));
    let secondColorGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("4").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("5").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("6").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color));
    let thirdColorGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("7").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color));
    let colorButtonsToolbar = ButtonsToolbar.m_create__().m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(firstColorGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(secondColorGroup).m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(thirdColorGroup);
    colorButtonsToolbar.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    row.m_asElement__().appendChild(colorButtonsToolbar.m_asElement__());
    infoButtonsToolbar.m_asElement__().style.cssFloat = "left";
    defaultButtonsToolbar.m_asElement__().style.cssFloat = "left";
    primaryButtonsToolbar.m_asElement__().style.cssFloat = "left";
    colorButtonsToolbar.m_asElement__().style.cssFloat = "left";
    card.m_appendContent__elemental2_dom_Node(row.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initButtonsToolbar__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initButtonsBasicGroup___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("BASIC EXAMPLE", "Create group of buttons");
    let defaultGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDefault__java_lang_String("RIGHT")).m_asElement__();
    defaultGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(defaultGroup);
    let primaryGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createPrimary__java_lang_String("RIGHT")).m_asElement__();
    primaryGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(primaryGroup);
    let successGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createSuccess__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createSuccess__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createSuccess__java_lang_String("RIGHT")).m_asElement__();
    successGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    successGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(successGroup);
    let infoGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createInfo__java_lang_String("RIGHT")).m_asElement__();
    infoGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(infoGroup);
    let dangerGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDanger__java_lang_String("LEFT")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDanger__java_lang_String("MIDDLE")).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_createDanger__java_lang_String("RIGHT")).m_asElement__();
    dangerGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    dangerGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(dangerGroup);
    let purpleGroup = ButtonsGroup.m_create__().m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("LEFT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("MIDDLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_addButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String("RIGHT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color)).m_asElement__();
    purpleGroup.style.margin = $Overlay.m_of__java_lang_Object("5px");
    purpleGroup.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(purpleGroup);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initButtonsBasicGroup__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initTextIconButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("ICON & TEXT BUTTONS", "Make icon & text buttons");
    let extension = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_extension__()).m_setContent__java_lang_String("EXTENSION").m_asElement__();
    let home = IconButton.m_createPrimary__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__()).m_setContent__java_lang_String("HOME").m_asElement__();
    let lock = IconButton.m_createSuccess__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_lock__()).m_setContent__java_lang_String("LOCK").m_asElement__();
    let scanWifi = IconButton.m_createInfo__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_perm_scan_wifi__()).m_setContent__java_lang_String("SCAN WIFI").m_asElement__();
    let takeOff = IconButton.m_createWarning__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_flight_takeoff__()).m_setContent__java_lang_String("TAKE OFF").m_asElement__();
    let print = IconButton.m_createDanger__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_print__()).m_setContent__java_lang_String("PRINT").m_asElement__();
    extension.style.margin = $Overlay.m_of__java_lang_Object("5px");
    extension.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    home.style.margin = $Overlay.m_of__java_lang_Object("5px");
    home.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    lock.style.margin = $Overlay.m_of__java_lang_Object("5px");
    lock.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    scanWifi.style.margin = $Overlay.m_of__java_lang_Object("5px");
    scanWifi.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    takeOff.style.margin = $Overlay.m_of__java_lang_Object("5px");
    takeOff.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    print.style.margin = $Overlay.m_of__java_lang_Object("5px");
    print.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(extension);
    card.m_appendContent__elemental2_dom_Node(home);
    card.m_appendContent__elemental2_dom_Node(lock);
    card.m_appendContent__elemental2_dom_Node(scanWifi);
    card.m_appendContent__elemental2_dom_Node(takeOff);
    card.m_appendContent__elemental2_dom_Node(print);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initTextIconButtons__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initIconButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("ICON BUTTONS", "Make icon buttons");
    let normal = Row.m_create__();
    let normal_circle = this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Normal Icon Button");
    normal.m_asElement__().appendChild(normal_circle);
    card.m_appendContent__elemental2_dom_Node(normal.m_asElement__());
    let row = Row.m_create__();
    let homeIcon = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_home__()).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let micIcon = IconButton.m_createPrimary__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_mic__()).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let moreIcon = IconButton.m_createInfo__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more__()).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let keyboardIcon = IconButton.m_createSuccess__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard__()).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let acUnitIcon = IconButton.m_createWarning__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_ac_unit__()).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let accessAlarmIcon = IconButton.m_createDanger__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_access_alarm__()).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    homeIcon.style.margin = $Overlay.m_of__java_lang_Object("5px");
    micIcon.style.margin = $Overlay.m_of__java_lang_Object("5px");
    moreIcon.style.margin = $Overlay.m_of__java_lang_Object("5px");
    keyboardIcon.style.margin = $Overlay.m_of__java_lang_Object("5px");
    acUnitIcon.style.margin = $Overlay.m_of__java_lang_Object("5px");
    accessAlarmIcon.style.margin = $Overlay.m_of__java_lang_Object("5px");
    row.m_asElement__().appendChild(homeIcon);
    row.m_asElement__().appendChild(micIcon);
    row.m_asElement__().appendChild(moreIcon);
    row.m_asElement__().appendChild(keyboardIcon);
    row.m_asElement__().appendChild(acUnitIcon);
    row.m_asElement__().appendChild(accessAlarmIcon);
    card.m_appendContent__elemental2_dom_Node(row.m_asElement__());
    let smallCircle = Row.m_create__();
    let small_icon_button = this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Small Circle Icon Button");
    smallCircle.m_asElement__().appendChild(small_icon_button);
    card.m_appendContent__elemental2_dom_Node(smallCircle.m_asElement__());
    let row1 = Row.m_create__();
    let addCircleIconCRL = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_add_circle__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_SMALL__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let placeIconCRL = IconButton.m_createPrimary__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_place__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_SMALL__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let airplaneModeActiveIconCRL = IconButton.m_createInfo__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_airplanemode_active__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_SMALL__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let albumIconCRL = IconButton.m_createSuccess__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_album__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_SMALL__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let weekendIconCRL = IconButton.m_createWarning__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_weekend__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_SMALL__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let airplayIconCRL = IconButton.m_createDanger__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_airplay__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_SMALL__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    addCircleIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    placeIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    airplaneModeActiveIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    albumIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    weekendIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    airplayIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    row1.m_asElement__().appendChild(addCircleIconCRL);
    row1.m_asElement__().appendChild(placeIconCRL);
    row1.m_asElement__().appendChild(airplaneModeActiveIconCRL);
    row1.m_asElement__().appendChild(albumIconCRL);
    row1.m_asElement__().appendChild(weekendIconCRL);
    row1.m_asElement__().appendChild(airplayIconCRL);
    card.m_appendContent__elemental2_dom_Node(row1.m_asElement__());
    let large = Row.m_create__();
    let large_circle = this.m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl("Large Circle Icon Button");
    large.m_asElement__().appendChild(large_circle);
    card.m_appendContent__elemental2_dom_Node(large.m_asElement__());
    let row2 = Row.m_create__();
    let adjustIconCRL = IconButton.m_create__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_adjust__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_LARGE__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let alloutIconCRL = IconButton.m_createPrimary__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_all_out__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_LARGE__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let appsIconCRL = IconButton.m_createInfo__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_apps__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_LARGE__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let artTrackIconCRL = IconButton.m_createSuccess__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_art_track__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_LARGE__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let assessmentIconCRL = IconButton.m_createWarning__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_assessment__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_LARGE__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    let assistantIconCRL = IconButton.m_createDanger__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_assistant__()).m_circle__org_dominokit_domino_ui_button_CircleSize(CircleSize.f_LARGE__org_dominokit_domino_ui_button_CircleSize).m_setButtonType__org_dominokit_domino_ui_style_StyleType(StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType).m_asElement__();
    adjustIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    alloutIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    appsIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    artTrackIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    assessmentIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    assistantIconCRL.style.margin = $Overlay.m_of__java_lang_Object("5px");
    row2.m_asElement__().appendChild(adjustIconCRL);
    row2.m_asElement__().appendChild(alloutIconCRL);
    row2.m_asElement__().appendChild(appsIconCRL);
    row2.m_asElement__().appendChild(artTrackIconCRL);
    row2.m_asElement__().appendChild(assessmentIconCRL);
    row2.m_asElement__().appendChild(assistantIconCRL);
    card.m_appendContent__elemental2_dom_Node(row2.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initIconButtons__()).m_asElement__());
  }
  
  /**
   * @param {?string} content
   * @return {HTMLHeadingElement}
   * @public
   */
  m_heading__java_lang_String_$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl(content) {
    let headingElement = /**@type {HTMLHeadingElement} */ ($Casts.$to(Elements.m_h__int__java_lang_String(2, content).m_asElement__(), HTMLHeadingElement_$Overlay));
    headingElement.style.marginTop = MarginTopUnionType_$Overlay.m_of__java_lang_Object("25px");
    headingElement.style.marginBottom = MarginBottomUnionType_$Overlay.m_of__java_lang_Object("15px");
    headingElement.style.fontSize = FontSizeUnionType_$Overlay.m_of__java_lang_Object("15px");
    headingElement.style.color = "#000";
    headingElement.style.display = "block";
    return headingElement;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDisabledButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("DISABLED BUTTONS", "Make buttons look unclickable by fading them back with opacity");
    let defaultDisabled = Button.m_createDefault__java_lang_String("DEFAULT").m_disable__().m_asElement__();
    let primaryDisabled = Button.m_createPrimary__java_lang_String("PRIMARY").m_disable__().m_asElement__();
    let infoDisabled = Button.m_createInfo__java_lang_String("INFO").m_disable__().m_asElement__();
    let warningDisabled = Button.m_createWarning__java_lang_String("WARNING").m_disable__().m_asElement__();
    let dangerDisabled = Button.m_createDanger__java_lang_String("DANGER").m_disable__().m_asElement__();
    defaultDisabled.style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultDisabled.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    primaryDisabled.style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryDisabled.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    infoDisabled.style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoDisabled.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    warningDisabled.style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningDisabled.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    dangerDisabled.style.margin = $Overlay.m_of__java_lang_Object("5px");
    dangerDisabled.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(defaultDisabled);
    card.m_appendContent__elemental2_dom_Node(primaryDisabled);
    card.m_appendContent__elemental2_dom_Node(infoDisabled);
    card.m_appendContent__elemental2_dom_Node(warningDisabled);
    card.m_appendContent__elemental2_dom_Node(dangerDisabled);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initDisabledButtons__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initBlockButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("BLOCK BUTTONS", "Create block level buttons");
    let defaultBlock = Button.m_createDefault__java_lang_String("DEFAULT").m_setBlock__boolean(true).m_asElement__();
    let primaryBlock = Button.m_createPrimary__java_lang_String("PRIMARY").m_setBlock__boolean(true).m_asElement__();
    let infoBlock = Button.m_createInfo__java_lang_String("INFO").m_setBlock__boolean(true).m_asElement__();
    let warningBlock = Button.m_createWarning__java_lang_String("WARNING").m_setBlock__boolean(true).m_asElement__();
    let dangerBlock = Button.m_createDanger__java_lang_String("DANGER").m_setBlock__boolean(true).m_asElement__();
    defaultBlock.style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultBlock.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    primaryBlock.style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryBlock.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    infoBlock.style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoBlock.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    warningBlock.style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningBlock.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    dangerBlock.style.margin = $Overlay.m_of__java_lang_Object("5px");
    dangerBlock.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(defaultBlock);
    card.m_appendContent__elemental2_dom_Node(primaryBlock);
    card.m_appendContent__elemental2_dom_Node(infoBlock);
    card.m_appendContent__elemental2_dom_Node(warningBlock);
    card.m_appendContent__elemental2_dom_Node(dangerBlock);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initBlockButtons__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initButtonSizes___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("BUTTON SIZES", "You can resize the buttons");
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let defaultLarge = Button.m_createDefault__java_lang_String("LARGE").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
    let defaultBtn = Button.m_createDefault__java_lang_String("DEFAULT");
    let defaultSmall = Button.m_createDefault__java_lang_String("SMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
    let defaultXsmall = Button.m_createDefault__java_lang_String("XSMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
    defaultLarge.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultBtn.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultSmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultXsmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultLarge.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    defaultBtn.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    defaultSmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    defaultXsmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    column.m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(defaultLarge.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(defaultBtn.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(defaultSmall.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(defaultXsmall.m_asElement__()).m_asElement__());
    card.m_appendContent__elemental2_dom_Node(column.m_asElement__());
    let column2 = column.m_copy__();
    let primaryLarge = Button.m_createPrimary__java_lang_String("LARGE").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
    let primaryBtn = Button.m_createPrimary__java_lang_String("DEFAULT");
    let primarySmall = Button.m_createPrimary__java_lang_String("SMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
    let primaryXsmall = Button.m_createPrimary__java_lang_String("XSMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
    primaryLarge.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryBtn.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    primarySmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryXsmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryLarge.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    primaryBtn.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    primarySmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    primaryXsmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    column2.m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(primaryLarge.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(primaryBtn.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(primarySmall.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(primaryXsmall.m_asElement__()).m_asElement__());
    card.m_appendContent__elemental2_dom_Node(column2.m_asElement__());
    let column3 = column.m_copy__();
    let warningLarge = Button.m_createWarning__java_lang_String("LARGE").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
    let warningBtn = Button.m_createWarning__java_lang_String("DEFAULT");
    let warningSmall = Button.m_createWarning__java_lang_String("SMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
    let warningXsmall = Button.m_createWarning__java_lang_String("XSMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
    warningLarge.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningBtn.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningSmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningXsmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningLarge.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    warningBtn.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    warningSmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    warningXsmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    column3.m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(warningLarge.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(warningBtn.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(warningSmall.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(warningXsmall.m_asElement__()).m_asElement__());
    card.m_appendContent__elemental2_dom_Node(column3.m_asElement__());
    let column4 = column.m_copy__();
    let infoLarge = Button.m_createInfo__java_lang_String("LARGE").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
    let infoBtn = Button.m_createInfo__java_lang_String("DEFAULT");
    let infoSmall = Button.m_createInfo__java_lang_String("SMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
    let infoXsmall = Button.m_createInfo__java_lang_String("XSMALL").m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
    infoLarge.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoBtn.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoSmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoXsmall.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoLarge.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    infoBtn.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    infoSmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    infoXsmall.m_asElement__().style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("200px");
    column4.m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(infoLarge.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(infoBtn.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(infoSmall.m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Row.m_create__().m_appendContent__elemental2_dom_HTMLElement(infoXsmall.m_asElement__()).m_asElement__());
    card.m_appendContent__elemental2_dom_Node(column4.m_asElement__());
    let row = Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column).m_addColumn__org_dominokit_domino_ui_column_Column(column2).m_addColumn__org_dominokit_domino_ui_column_Column(column3).m_addColumn__org_dominokit_domino_ui_column_Column(column4);
    row.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("10px");
    card.m_appendContent__elemental2_dom_Node(row.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initButtonSizes__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initBootstrapButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("BOOTSTRAP DEFAULT BUTTONS", "Use any of the available button classes to quickly create a styled button");
    let defaultBtn = Button.m_createDefault__java_lang_String("DEFAULT").m_asElement__();
    let primaryBtn = Button.m_createPrimary__java_lang_String("PRIMARY").m_asElement__();
    let successBtn = Button.m_createSuccess__java_lang_String("SUCCESS").m_asElement__();
    let infoBtn = Button.m_createInfo__java_lang_String("INFO").m_asElement__();
    let warningBtn = Button.m_createWarning__java_lang_String("WARNING").m_asElement__();
    let dangerBtn = Button.m_createDanger__java_lang_String("DANGER").m_asElement__();
    defaultBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    defaultBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(defaultBtn);
    primaryBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    primaryBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(primaryBtn);
    successBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    successBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(successBtn);
    infoBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    infoBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(infoBtn);
    warningBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    warningBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(warningBtn);
    dangerBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    dangerBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(dangerBtn);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initBootstrapButtons__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initMaterialDesignButtons___$p_org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("METARIAL DESIGN BUTTONS", "Use any of the available button classes to quickly create a styled button");
    let redBtn = Button.m_create__java_lang_String("RED").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_asElement__();
    redBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    redBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(redBtn);
    let purpleBtn = Button.m_create__java_lang_String("PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__();
    purpleBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    purpleBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(purpleBtn);
    let indigoBtn = Button.m_create__java_lang_String("INDIGO").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_asElement__();
    indigoBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    indigoBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(indigoBtn);
    let lightBlueBtn = Button.m_create__java_lang_String("LIGHT BLUE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__();
    lightBlueBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    lightBlueBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(lightBlueBtn);
    let greenBtn = Button.m_create__java_lang_String("GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__();
    greenBtn.style.margin = $Overlay.m_of__java_lang_Object("5px");
    greenBtn.style.minWidth = MinWidthUnionType_$Overlay.m_of__java_lang_Object("120px");
    card.m_appendContent__elemental2_dom_Node(greenBtn);
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initMaterialDesignButtons__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl() {
    this.f_element__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_() {
    return (ButtonsViewImpl.$clinit(), ButtonsViewImpl.$f_LOGGER__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_(value) {
    (ButtonsViewImpl.$clinit(), ButtonsViewImpl.$f_LOGGER__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ButtonsViewImpl.$clinit = function() {};
    FontSizeUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.FontSizeUnionType.$Overlay$impl');
    MarginBottomUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
    MarginTopUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginTopUnionType.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginUnionType.$Overlay$impl');
    MinWidthUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MinWidthUnionType.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    Class = goog.module.get('java.lang.Class$impl');
    CodeResource = goog.module.get('org.dominokit.domino.buttons.client.views.CodeResource$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    ButtonSize = goog.module.get('org.dominokit.domino.ui.button.ButtonSize$impl');
    ButtonsToolbar = goog.module.get('org.dominokit.domino.ui.button.ButtonsToolbar$impl');
    CircleSize = goog.module.get('org.dominokit.domino.ui.button.CircleSize$impl');
    DropdownAction = goog.module.get('org.dominokit.domino.ui.button.DropdownAction$impl');
    DropdownButton = goog.module.get('org.dominokit.domino.ui.button.DropdownButton$impl');
    IconButton = goog.module.get('org.dominokit.domino.ui.button.IconButton$impl');
    SplitButton = goog.module.get('org.dominokit.domino.ui.button.SplitButton$impl');
    ButtonsGroup = goog.module.get('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
    JustifiedGroup = goog.module.get('org.dominokit.domino.ui.button.group.JustifiedGroup$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
    ButtonsViewImpl.$f_LOGGER__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ButtonsViewImpl));
  }
  
  
};

$Util.$setClassMetadata(ButtonsViewImpl, $Util.$makeClassName('org.dominokit.domino.buttons.client.views.ui.ButtonsViewImpl'));


/** @private {Logger} */
ButtonsViewImpl.$f_LOGGER__org_dominokit_domino_buttons_client_views_ui_ButtonsViewImpl_;


ButtonsView.$markImplementor(ButtonsViewImpl);


exports = ButtonsViewImpl; 
//# sourceMappingURL=ButtonsViewImpl.js.map