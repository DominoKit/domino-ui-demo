/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.presenters.IconsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.icons.client.presenters.IconsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let IconsPresenter = goog.forwardDeclare('org.dominokit.domino.icons.client.presenters.IconsPresenter$impl');


/**
 * @extends {PresenterCommand<IconsPresenter>}
  */
class IconsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'IconsPresenterCommand()'.
   * @return {!IconsPresenterCommand}
   * @public
   */
  static $create__() {
    IconsPresenterCommand.$clinit();
    let $instance = new IconsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_icons_client_presenters_IconsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_icons_client_presenters_IconsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IconsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IconsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IconsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IconsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.icons.client.presenters.IconsPresenterCommand'));




exports = IconsPresenterCommand; 
//# sourceMappingURL=IconsPresenterCommand.js.map