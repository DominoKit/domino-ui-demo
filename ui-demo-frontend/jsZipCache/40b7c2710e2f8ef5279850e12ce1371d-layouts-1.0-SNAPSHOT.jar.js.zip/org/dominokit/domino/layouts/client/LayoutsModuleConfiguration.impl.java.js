/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.client.LayoutsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.client.LayoutsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.layouts.client.LayoutsModuleConfiguration.$1$impl');
let LayoutsPresenterListenerForComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent$impl');
let LayoutsPresenter = goog.forwardDeclare('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter$impl');
let LayoutsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class LayoutsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutsModuleConfiguration()'.
   * @return {!LayoutsModuleConfiguration}
   * @public
   */
  static $create__() {
    LayoutsModuleConfiguration.$clinit();
    let $instance = new LayoutsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_layouts_client_LayoutsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layouts_client_LayoutsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_layouts_client_LayoutsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(LayoutsPresenter).m_getCanonicalName__(), Class.$get(LayoutsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(LayoutsPresenterCommand).m_getCanonicalName__(), Class.$get(LayoutsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentCaseEvent), LayoutsPresenterListenerForComponentCaseEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {ViewRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(arg0) {
    ModuleConfiguration.m_registerViews__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_ViewRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    $1 = goog.module.get('org.dominokit.domino.layouts.client.LayoutsModuleConfiguration.$1$impl');
    LayoutsPresenterListenerForComponentCaseEvent = goog.module.get('org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent$impl');
    LayoutsPresenter = goog.module.get('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter$impl');
    LayoutsPresenterCommand = goog.module.get('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.layouts.client.LayoutsModuleConfiguration'));


ModuleConfiguration.$markImplementor(LayoutsModuleConfiguration);


exports = LayoutsModuleConfiguration; 
//# sourceMappingURL=LayoutsModuleConfiguration.js.map