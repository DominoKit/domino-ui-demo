/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let LayoutsPresenter = goog.forwardDeclare('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter$impl');
let LayoutsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentCaseEvent>}
  */
class LayoutsPresenterListenerForComponentCaseEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutsPresenterListenerForComponentCaseEvent()'.
   * @return {!LayoutsPresenterListenerForComponentCaseEvent}
   * @public
   */
  static $create__() {
    LayoutsPresenterListenerForComponentCaseEvent.$clinit();
    let $instance = new LayoutsPresenterListenerForComponentCaseEvent();
    $instance.$ctor__org_dominokit_domino_layouts_client_listeners_LayoutsPresenterListenerForComponentCaseEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutsPresenterListenerForComponentCaseEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layouts_client_listeners_LayoutsPresenterListenerForComponentCaseEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(event) {
    LayoutsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** LayoutsPresenter */ presenter) =>{
      presenter.m_listenToCompnentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(event.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(/**@type {ComponentCaseEvent} */ ($Casts.$to(arg0, ComponentCaseEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutsPresenterListenerForComponentCaseEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutsPresenterListenerForComponentCaseEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsPresenterListenerForComponentCaseEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    LayoutsPresenterCommand = goog.module.get('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutsPresenterListenerForComponentCaseEvent, $Util.$makeClassName('org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent'));


DominoEventListener.$markImplementor(LayoutsPresenterListenerForComponentCaseEvent);


exports = LayoutsPresenterListenerForComponentCaseEvent; 
//# sourceMappingURL=LayoutsPresenterListenerForComponentCaseEvent.js.map