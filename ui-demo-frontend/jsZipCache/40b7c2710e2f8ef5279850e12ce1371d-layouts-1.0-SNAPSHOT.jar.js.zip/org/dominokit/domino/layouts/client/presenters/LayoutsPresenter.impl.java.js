/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.client.presenters.LayoutsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter.$1$impl');
let LayoutsEvent = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class LayoutsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutsPresenter()'.
   * @return {!LayoutsPresenter}
   * @public
   */
  static $create__() {
    LayoutsPresenter.$clinit();
    let $instance = new LayoutsPresenter();
    $instance.$ctor__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_listenToCompnentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter(this));
    this.m_fireEvent__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEvent(Class.$get(LayoutsEvent), LayoutsEvent.$adapt((() =>{
      return LayoutsEventContext.$adapt((() =>{
        return context;
      }));
    })));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter_() {
    return (LayoutsPresenter.$clinit(), LayoutsPresenter.$f_LOGGER__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter_(value) {
    (LayoutsPresenter.$clinit(), LayoutsPresenter.$f_LOGGER__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter.$1$impl');
    LayoutsEvent = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
    LayoutsEventContext = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    LayoutsPresenter.$f_LOGGER__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LayoutsPresenter));
  }
  
  
};

$Util.$setClassMetadata(LayoutsPresenter, $Util.$makeClassName('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter'));


/** @private {Logger} */
LayoutsPresenter.$f_LOGGER__org_dominokit_domino_layouts_client_presenters_LayoutsPresenter_;




exports = LayoutsPresenter; 
//# sourceMappingURL=LayoutsPresenter.js.map