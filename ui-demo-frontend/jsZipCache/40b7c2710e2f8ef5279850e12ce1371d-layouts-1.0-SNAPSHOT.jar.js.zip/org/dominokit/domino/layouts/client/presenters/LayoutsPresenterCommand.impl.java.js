/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let LayoutsPresenter = goog.forwardDeclare('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter$impl');


/**
 * @extends {PresenterCommand<LayoutsPresenter>}
  */
class LayoutsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutsPresenterCommand()'.
   * @return {!LayoutsPresenterCommand}
   * @public
   */
  static $create__() {
    LayoutsPresenterCommand.$clinit();
    let $instance = new LayoutsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_layouts_client_presenters_LayoutsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layouts_client_presenters_LayoutsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand'));




exports = LayoutsPresenterCommand; 
//# sourceMappingURL=LayoutsPresenterCommand.js.map