/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.client.LayoutsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.client.LayoutsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class LayoutsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutsClientModule()'.
   * @return {!LayoutsClientModule}
   * @public
   */
  static $create__() {
    LayoutsClientModule.$clinit();
    let $instance = new LayoutsClientModule();
    $instance.$ctor__org_dominokit_domino_layouts_client_LayoutsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layouts_client_LayoutsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    LayoutsClientModule.$f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_.m_info__java_lang_String("Initializing Layouts frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_() {
    return (LayoutsClientModule.$clinit(), LayoutsClientModule.$f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_(value) {
    (LayoutsClientModule.$clinit(), LayoutsClientModule.$f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    LayoutsClientModule.$f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LayoutsClientModule));
  }
  
  
};

$Util.$setClassMetadata(LayoutsClientModule, $Util.$makeClassName('org.dominokit.domino.layouts.client.LayoutsClientModule'));


/** @private {Logger} */
LayoutsClientModule.$f_LOGGER__org_dominokit_domino_layouts_client_LayoutsClientModule_;




exports = LayoutsClientModule; 
//# sourceMappingURL=LayoutsClientModule.js.map