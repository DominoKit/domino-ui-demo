/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');
const _LayoutsPresenter = goog.require('org.dominokit.domino.layouts.client.presenters.LayoutsPresenter');
const _LayoutsPresenterCommand = goog.require('org.dominokit.domino.layouts.client.presenters.LayoutsPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LayoutsPresenterListenerForComponentCaseEvent = goog.require('org.dominokit.domino.layouts.client.listeners.LayoutsPresenterListenerForComponentCaseEvent$impl');
exports = LayoutsPresenterListenerForComponentCaseEvent;
 