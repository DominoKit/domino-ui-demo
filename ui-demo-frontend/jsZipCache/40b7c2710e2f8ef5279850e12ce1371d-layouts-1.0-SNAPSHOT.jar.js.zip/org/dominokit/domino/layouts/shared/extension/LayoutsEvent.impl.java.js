/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.shared.extension.LayoutsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEvent.$LambdaAdaptor$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');


/**
 * @interface
 * @extends {DominoEvent<LayoutsEventContext>}
 */
class LayoutsEvent {
  /**
   * @param {?function():LayoutsEventContext} fn
   * @return {LayoutsEvent}
   * @public
   */
  static $adapt(fn) {
    LayoutsEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layouts_shared_extension_LayoutsEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layouts_shared_extension_LayoutsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layouts_shared_extension_LayoutsEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(LayoutsEvent, $Util.$makeClassName('org.dominokit.domino.layouts.shared.extension.LayoutsEvent'));


LayoutsEvent.$markImplementor(/** @type {Function} */ (LayoutsEvent));


exports = LayoutsEvent; 
//# sourceMappingURL=LayoutsEvent.js.map