/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.shared.extension.LayoutsEventContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {EventContext}
 */
class LayoutsEventContext {
  /**
   * @abstract
   * @return {ComponentCaseContext}
   * @public
   */
  m_getComponentCaseContext__() {
  }
  
  /**
   * @param {?function():ComponentCaseContext} fn
   * @return {LayoutsEventContext}
   * @public
   */
  static $adapt(fn) {
    LayoutsEventContext.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutsEventContext.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(LayoutsEventContext, $Util.$makeClassName('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext'));


LayoutsEventContext.$markImplementor(/** @type {Function} */ (LayoutsEventContext));


exports = LayoutsEventContext; 
//# sourceMappingURL=LayoutsEventContext.js.map