/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.shared.extension.LayoutsEvent$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layouts.shared.extension.LayoutsEvent.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LayoutsEvent = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');

let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {LayoutsEvent}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():LayoutsEventContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():LayoutsEventContext} */
    this.f_$$fn__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$LambdaAdaptor__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():LayoutsEventContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$LambdaAdaptor__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {LayoutsEventContext}
   * @public
   */
  m_context__() {
    let /** ?function():LayoutsEventContext */ $function;
    return /**@type {LayoutsEventContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_layouts_shared_extension_LayoutsEvent_$LambdaAdaptor, $function()), LayoutsEventContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    LayoutsEventContext = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$$LambdaAdaptor'));


LayoutsEvent.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=LayoutsEvent$$LambdaAdaptor.js.map