/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _LayoutsEventContext = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 