package org.dominokit.domino.layouts.shared.extension;

import org.dominokit.domino.api.shared.extension.DominoEvent;

public interface LayoutsEvent extends DominoEvent<LayoutsEventContext> {
}
