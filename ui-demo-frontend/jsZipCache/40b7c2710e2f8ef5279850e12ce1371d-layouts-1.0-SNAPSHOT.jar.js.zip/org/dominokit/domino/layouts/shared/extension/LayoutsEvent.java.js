/**
 * @fileoverview transpiled from org.dominokit.domino.layouts.shared.extension.LayoutsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layouts.shared.extension.LayoutsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent.$LambdaAdaptor');
const _LayoutsEventContext = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext');


// Re-exports the implementation.
var LayoutsEvent = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
exports = LayoutsEvent;
 