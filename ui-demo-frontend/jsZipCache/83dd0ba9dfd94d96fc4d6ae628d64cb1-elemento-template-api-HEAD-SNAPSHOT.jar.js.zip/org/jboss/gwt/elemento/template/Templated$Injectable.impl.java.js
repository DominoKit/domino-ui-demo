/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.Templated$Injectable.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.template.Templated.Injectable$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Injectable>}
  */
class Injectable extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Injectable(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Injectable}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Injectable();
    $instance.$ctor__org_jboss_gwt_elemento_template_Templated_Injectable__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Injectable(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_template_Templated_Injectable__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Injectable}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Injectable.$clinit();
    if ($Equality.$same(Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_, null)) {
      Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_ = $Enums.createMapFromValues(Injectable.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_);
  }
  
  /**
   * @return {!Array<!Injectable>}
   * @public
   */
  static m_values__() {
    Injectable.$clinit();
    return /**@type {!Array<Injectable>} */ ($Arrays.$init([Injectable.$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable, Injectable.$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable, Injectable.$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable], Injectable));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Injectable} */ ($Casts.$to(arg0, Injectable)));
  }
  
  /**
   * @return {!Injectable}
   * @public
   */
  static get f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable() {
    return (Injectable.$clinit(), Injectable.$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable);
  }
  
  /**
   * @param {!Injectable} value
   * @return {void}
   * @public
   */
  static set f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable(value) {
    (Injectable.$clinit(), Injectable.$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable = value);
  }
  
  /**
   * @return {!Injectable}
   * @public
   */
  static get f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable() {
    return (Injectable.$clinit(), Injectable.$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable);
  }
  
  /**
   * @param {!Injectable} value
   * @return {void}
   * @public
   */
  static set f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable(value) {
    (Injectable.$clinit(), Injectable.$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable = value);
  }
  
  /**
   * @return {!Injectable}
   * @public
   */
  static get f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable() {
    return (Injectable.$clinit(), Injectable.$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable);
  }
  
  /**
   * @param {!Injectable} value
   * @return {void}
   * @public
   */
  static set f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable(value) {
    (Injectable.$clinit(), Injectable.$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable = value);
  }
  
  /**
   * @return {Map<?string, !Injectable>}
   * @public
   */
  static get f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_() {
    return (Injectable.$clinit(), Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_);
  }
  
  /**
   * @param {Map<?string, !Injectable>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_(value) {
    (Injectable.$clinit(), Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Injectable;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Injectable);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Injectable.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Injectable.$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable = Injectable.$create__java_lang_String__int($Util.$makeEnumName("TRUE"), Injectable.$ordinal$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable);
    Injectable.$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable = Injectable.$create__java_lang_String__int($Util.$makeEnumName("FALSE"), Injectable.$ordinal$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable);
    Injectable.$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable = Injectable.$create__java_lang_String__int($Util.$makeEnumName("IF_DI_DETECTED"), Injectable.$ordinal$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable);
    Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Injectable, $Util.$makeClassName('org.jboss.gwt.elemento.template.Templated$Injectable'));


/** @private {!Injectable} */
Injectable.$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable;


/** @private {!Injectable} */
Injectable.$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable;


/** @private {!Injectable} */
Injectable.$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable;


/** @private {Map<?string, !Injectable>} */
Injectable.$f_namesToValuesMap__org_jboss_gwt_elemento_template_Templated_Injectable_;


/** @public {number} @const */
Injectable.$ordinal$f_TRUE__org_jboss_gwt_elemento_template_Templated_Injectable = 0;


/** @public {number} @const */
Injectable.$ordinal$f_FALSE__org_jboss_gwt_elemento_template_Templated_Injectable = 1;


/** @public {number} @const */
Injectable.$ordinal$f_IF_DI_DETECTED__org_jboss_gwt_elemento_template_Templated_Injectable = 2;




exports = Injectable; 
//# sourceMappingURL=Templated$Injectable.js.map