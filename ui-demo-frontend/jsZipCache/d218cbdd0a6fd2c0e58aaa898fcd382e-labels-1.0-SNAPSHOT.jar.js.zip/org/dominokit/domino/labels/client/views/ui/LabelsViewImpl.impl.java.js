/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.views.ui.LabelsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.views.ui.LabelsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const LabelsView = goog.require('org.dominokit.domino.labels.client.views.LabelsView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginUnionType.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.labels.client.views.CodeResource$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Label = goog.forwardDeclare('org.dominokit.domino.ui.labels.Label$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {LabelsView}
  */
class LabelsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'LabelsViewImpl()'.
   * @return {!LabelsViewImpl}
   * @public
   */
  static $create__() {
    LabelsViewImpl.$clinit();
    let $instance = new LabelsViewImpl();
    $instance.$ctor__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LabelsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("LABELS").m_asElement__());
    this.m_initLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl();
    this.m_initMaterialLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initMaterialLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl() {
    let labels = Card.m_create__java_lang_String__java_lang_String("LABELS WITH MATERIAL DESIGN COLORS", "You can use material design color with labels");
    let row = Row.m_create__();
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_one__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_two__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let red = Label.m_create__java_lang_String("Red").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_asElement__();
    let pink = Label.m_create__java_lang_String("Pink").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__();
    let purple = Label.m_create__java_lang_String("Purple").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__();
    let deepPurple = Label.m_create__java_lang_String("Deep Purple").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__();
    let indigo = Label.m_create__java_lang_String("Indigo").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_asElement__();
    let blue = Label.m_create__java_lang_String("Blue").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__();
    let lightBlue = Label.m_create__java_lang_String("Light Blue").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__();
    let cyan = Label.m_create__java_lang_String("Cyan").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__();
    let teal = Label.m_create__java_lang_String("Teal").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__();
    let green = Label.m_create__java_lang_String("Green").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__();
    let orange = Label.m_create__java_lang_String("Orange").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__();
    let yellow = Label.m_create__java_lang_String("Yellow").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color).m_asElement__();
    red.style.margin = $Overlay.m_of__java_lang_Object("10px");
    pink.style.margin = $Overlay.m_of__java_lang_Object("10px");
    purple.style.margin = $Overlay.m_of__java_lang_Object("10px");
    deepPurple.style.margin = $Overlay.m_of__java_lang_Object("10px");
    indigo.style.margin = $Overlay.m_of__java_lang_Object("10px");
    blue.style.margin = $Overlay.m_of__java_lang_Object("10px");
    lightBlue.style.margin = $Overlay.m_of__java_lang_Object("10px");
    cyan.style.margin = $Overlay.m_of__java_lang_Object("10px");
    teal.style.margin = $Overlay.m_of__java_lang_Object("10px");
    green.style.margin = $Overlay.m_of__java_lang_Object("10px");
    orange.style.margin = $Overlay.m_of__java_lang_Object("10px");
    yellow.style.margin = $Overlay.m_of__java_lang_Object("10px");
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(red)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(pink)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(purple)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(deepPurple)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(indigo)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(blue)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(lightBlue)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(cyan)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(teal)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(green)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(orange)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(yellow));
    labels.m_appendContent__elemental2_dom_Node(row.m_asElement__());
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(labels.m_asElement__());
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initMaterialLabels__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl() {
    let labels = Card.m_create__java_lang_String("LABELS");
    let row = Row.m_create__();
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_one__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_two__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let defaultLabel = Label.m_createDefault__java_lang_String("DEFAULT").m_asElement__();
    let primaryLabel = Label.m_createPrimary__java_lang_String("PRIMARY").m_asElement__();
    let successLabel = Label.m_createSuccess__java_lang_String("SUCCESS").m_asElement__();
    let infoLabel = Label.m_createInfo__java_lang_String("INFO").m_asElement__();
    let warningLabel = Label.m_createWarning__java_lang_String("WARNING").m_asElement__();
    let dangerLabel = Label.m_createDanger__java_lang_String("DANGER").m_asElement__();
    defaultLabel.style.margin = $Overlay.m_of__java_lang_Object("10px");
    primaryLabel.style.margin = $Overlay.m_of__java_lang_Object("10px");
    successLabel.style.margin = $Overlay.m_of__java_lang_Object("10px");
    infoLabel.style.margin = $Overlay.m_of__java_lang_Object("10px");
    warningLabel.style.margin = $Overlay.m_of__java_lang_Object("10px");
    dangerLabel.style.margin = $Overlay.m_of__java_lang_Object("10px");
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(defaultLabel)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(primaryLabel)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(successLabel)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(infoLabel)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(warningLabel)).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(dangerLabel));
    labels.m_appendContent__elemental2_dom_Node(row.m_asElement__());
    labels.m_appendContent__elemental2_dom_Node(Elements.m_hr__().m_asElement__());
    let h1 = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(1).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    let h2 = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(2).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    let h3 = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    let h4 = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    let h5 = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    let h6 = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    h1.style.textAlign = "left";
    h1.appendChild(Label.m_createDanger__java_lang_String("New").m_asElement__());
    h2.appendChild(Label.m_createWarning__java_lang_String("New").m_asElement__());
    h3.appendChild(Label.m_createInfo__java_lang_String("New").m_asElement__());
    h4.appendChild(Label.m_createSuccess__java_lang_String("New").m_asElement__());
    h5.appendChild(Label.m_createPrimary__java_lang_String("New").m_asElement__());
    h6.appendChild(Label.m_createDefault__java_lang_String("New").m_asElement__());
    labels.m_appendContent__elemental2_dom_Node(h1).m_appendContent__elemental2_dom_Node(h2).m_appendContent__elemental2_dom_Node(h3).m_appendContent__elemental2_dom_Node(h4).m_appendContent__elemental2_dom_Node(h5).m_appendContent__elemental2_dom_Node(h6);
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(labels.m_asElement__());
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initLabels__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl() {
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LabelsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LabelsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LabelsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginUnionType.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.labels.client.views.CodeResource$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Label = goog.module.get('org.dominokit.domino.ui.labels.Label$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LabelsViewImpl, $Util.$makeClassName('org.dominokit.domino.labels.client.views.ui.LabelsViewImpl'));


LabelsView.$markImplementor(LabelsViewImpl);


exports = LabelsViewImpl; 
//# sourceMappingURL=LabelsViewImpl.js.map