/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.contributions.MediaPresenterContributionToComponentsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.media.client.contributions.MediaPresenterContributionToComponentsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let MediaPresenter = goog.forwardDeclare('org.dominokit.domino.media.client.presenters.MediaPresenter$impl');
let MediaPresenterCommand = goog.forwardDeclare('org.dominokit.domino.media.client.presenters.MediaPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentsExtensionPoint>}
  */
class MediaPresenterContributionToComponentsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MediaPresenterContributionToComponentsExtensionPoint()'.
   * @return {!MediaPresenterContributionToComponentsExtensionPoint}
   * @public
   */
  static $create__() {
    MediaPresenterContributionToComponentsExtensionPoint.$clinit();
    let $instance = new MediaPresenterContributionToComponentsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_media_client_contributions_MediaPresenterContributionToComponentsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaPresenterContributionToComponentsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_media_client_contributions_MediaPresenterContributionToComponentsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(extensionPoint) {
    MediaPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** MediaPresenter */ presenter) =>{
      presenter.m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(/**@type {ComponentsExtensionPoint} */ ($Casts.$to(arg0, ComponentsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaPresenterContributionToComponentsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaPresenterContributionToComponentsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaPresenterContributionToComponentsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    MediaPresenterCommand = goog.module.get('org.dominokit.domino.media.client.presenters.MediaPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MediaPresenterContributionToComponentsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.media.client.contributions.MediaPresenterContributionToComponentsExtensionPoint'));


Contribution.$markImplementor(MediaPresenterContributionToComponentsExtensionPoint);


exports = MediaPresenterContributionToComponentsExtensionPoint; 
//# sourceMappingURL=MediaPresenterContributionToComponentsExtensionPoint.js.map