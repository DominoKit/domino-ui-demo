/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.views.ui.MediaViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.media.client.views.ui.MediaViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _MediaView = goog.require('org.dominokit.domino.media.client.views.MediaView');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLImageElement_$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _CodeResource = goog.require('org.dominokit.domino.media.client.views.CodeResource');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _MediaObject = goog.require('org.dominokit.domino.ui.media.MediaObject');
const _MediaAlign = goog.require('org.dominokit.domino.ui.media.MediaObject.MediaAlign');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EmptyContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MediaViewImpl = goog.require('org.dominokit.domino.media.client.views.ui.MediaViewImpl$impl');
exports = MediaViewImpl;
 