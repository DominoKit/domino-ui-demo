/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.media.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_media_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_media_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_defaultMedia__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"DEFAULT MEDIA\",\n" + "            \"The default media displays a media object (images, video, audio) to the left or right of a content block.\")\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .appendContent(new Text(SAMPLE_TEXT))\n" + "                .asElement())\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .appendContent(new Text(SAMPLE_TEXT))\n" + "                .appendContent(MediaObject.create()\n" + "                        .setHeader(\"Media heading\")\n" + "                        .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                                .attr(\"width\", \"64\")\n" + "                                .attr(\"height\", \"64\"))\n" + "                                .asElement())\n" + "                        .appendContent(new Text(SAMPLE_TEXT))\n" + "                        .asElement())\n" + "                .asElement())\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setRightMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .appendContent(new Text(SAMPLE_TEXT))\n" + "                .asElement())\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setRightMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .appendContent(new Text(SAMPLE_TEXT))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_mediaAlignment__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"MEDIA ALIGNMENT\",\"The images or other media can be aligned top, middle, or bottom. The default is top aligned.\")\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .appendContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                .appendContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                .asElement())\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .alignLeftMedia(MediaObject.MediaAlign.MIDDLE)\n" + "                .appendContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                .appendContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                .asElement())\n" + "        .appendContent(MediaObject.create()\n" + "                .setHeader(\"Media heading\")\n" + "                .setLeftMedia(a().add(img(\"http://placehold.it/64x64\")\n" + "                        .attr(\"width\", \"64\")\n" + "                        .attr(\"height\", \"64\"))\n" + "                        .asElement())\n" + "                .alignLeftMedia(MediaObject.MediaAlign.BOTTOM)\n" + "                .appendContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                .appendContent(Paragraph.create(SAMPLE_TEXT).asElement())\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.media.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map