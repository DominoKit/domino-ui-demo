/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.presenters.MediaPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.media.client.presenters.MediaPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.media.client.presenters.MediaPresenter.$1$impl');
let MediaView = goog.forwardDeclare('org.dominokit.domino.media.client.views.MediaView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<MediaView>}
  */
class MediaPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MediaPresenter()'.
   * @return {!MediaPresenter}
   * @public
   */
  static $create__() {
    MediaPresenter.$clinit();
    let $instance = new MediaPresenter();
    $instance.$ctor__org_dominokit_domino_media_client_presenters_MediaPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_media_client_presenters_MediaPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_media_client_presenters_MediaPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_media_client_presenters_MediaPresenter_() {
    return (MediaPresenter.$clinit(), MediaPresenter.$f_LOGGER__org_dominokit_domino_media_client_presenters_MediaPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_media_client_presenters_MediaPresenter_(value) {
    (MediaPresenter.$clinit(), MediaPresenter.$f_LOGGER__org_dominokit_domino_media_client_presenters_MediaPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.media.client.presenters.MediaPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    MediaPresenter.$f_LOGGER__org_dominokit_domino_media_client_presenters_MediaPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(MediaPresenter));
  }
  
  
};

$Util.$setClassMetadata(MediaPresenter, $Util.$makeClassName('org.dominokit.domino.media.client.presenters.MediaPresenter'));


/** @private {Logger} */
MediaPresenter.$f_LOGGER__org_dominokit_domino_media_client_presenters_MediaPresenter_;




exports = MediaPresenter; 
//# sourceMappingURL=MediaPresenter.js.map