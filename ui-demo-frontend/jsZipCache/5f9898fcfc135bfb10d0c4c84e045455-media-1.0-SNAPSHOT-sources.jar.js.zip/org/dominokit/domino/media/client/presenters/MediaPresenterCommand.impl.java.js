/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.presenters.MediaPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.media.client.presenters.MediaPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let MediaPresenter = goog.forwardDeclare('org.dominokit.domino.media.client.presenters.MediaPresenter$impl');


/**
 * @extends {PresenterCommand<MediaPresenter>}
  */
class MediaPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MediaPresenterCommand()'.
   * @return {!MediaPresenterCommand}
   * @public
   */
  static $create__() {
    MediaPresenterCommand.$clinit();
    let $instance = new MediaPresenterCommand();
    $instance.$ctor__org_dominokit_domino_media_client_presenters_MediaPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_media_client_presenters_MediaPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MediaPresenterCommand, $Util.$makeClassName('org.dominokit.domino.media.client.presenters.MediaPresenterCommand'));




exports = MediaPresenterCommand; 
//# sourceMappingURL=MediaPresenterCommand.js.map