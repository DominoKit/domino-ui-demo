/**
 * @fileoverview transpiled from org.slf4j.GWTLoggerAdapter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.GWTLoggerAdapter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _MarkerIgnoringBase = goog.require('org.slf4j.helpers.MarkerIgnoringBase');
const _Throwable = goog.require('java.lang.Throwable');
const _Level = goog.require('java.util.logging.Level');
const _Logger = goog.require('java.util.logging.Logger');
const _MessageFormatter = goog.require('org.slf4j.helpers.MessageFormatter');


// Re-exports the implementation.
var GWTLoggerAdapter = goog.require('org.slf4j.GWTLoggerAdapter$impl');
exports = GWTLoggerAdapter;
 