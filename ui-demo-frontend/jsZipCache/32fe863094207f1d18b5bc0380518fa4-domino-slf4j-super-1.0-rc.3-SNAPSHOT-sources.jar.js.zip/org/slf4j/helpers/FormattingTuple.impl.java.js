/**
 * @fileoverview transpiled from org.slf4j.helpers.FormattingTuple.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.helpers.FormattingTuple$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');


class FormattingTuple extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_message__org_slf4j_helpers_FormattingTuple_;
    /** @public {Throwable} */
    this.f_throwable__org_slf4j_helpers_FormattingTuple_;
    /** @public {Array<*>} */
    this.f_argArray__org_slf4j_helpers_FormattingTuple_;
  }
  
  /**
   * Factory method corresponding to constructor 'FormattingTuple(String)'.
   * @param {?string} message
   * @return {!FormattingTuple}
   * @public
   */
  static $create__java_lang_String(message) {
    FormattingTuple.$clinit();
    let $instance = new FormattingTuple();
    $instance.$ctor__org_slf4j_helpers_FormattingTuple__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormattingTuple(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_helpers_FormattingTuple__java_lang_String(message) {
    this.$ctor__org_slf4j_helpers_FormattingTuple__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(message, null, null);
  }
  
  /**
   * Factory method corresponding to constructor 'FormattingTuple(String, Object[], Throwable)'.
   * @param {?string} message
   * @param {Array<*>} argArray
   * @param {Throwable} throwable
   * @return {!FormattingTuple}
   * @public
   */
  static $create__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(message, argArray, throwable) {
    FormattingTuple.$clinit();
    let $instance = new FormattingTuple();
    $instance.$ctor__org_slf4j_helpers_FormattingTuple__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(message, argArray, throwable);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormattingTuple(String, Object[], Throwable)'.
   * @param {?string} message
   * @param {Array<*>} argArray
   * @param {Throwable} throwable
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_helpers_FormattingTuple__java_lang_String__arrayOf_java_lang_Object__java_lang_Throwable(message, argArray, throwable) {
    this.$ctor__java_lang_Object__();
    this.f_message__org_slf4j_helpers_FormattingTuple_ = message;
    this.f_throwable__org_slf4j_helpers_FormattingTuple_ = throwable;
    this.f_argArray__org_slf4j_helpers_FormattingTuple_ = argArray;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getMessage__() {
    return this.f_message__org_slf4j_helpers_FormattingTuple_;
  }
  
  /**
   * @return {Array<*>}
   * @public
   */
  m_getArgArray__() {
    return this.f_argArray__org_slf4j_helpers_FormattingTuple_;
  }
  
  /**
   * @return {Throwable}
   * @public
   */
  m_getThrowable__() {
    return this.f_throwable__org_slf4j_helpers_FormattingTuple_;
  }
  
  /**
   * @return {FormattingTuple}
   * @public
   */
  static get f_NULL__org_slf4j_helpers_FormattingTuple() {
    return (FormattingTuple.$clinit(), FormattingTuple.$f_NULL__org_slf4j_helpers_FormattingTuple);
  }
  
  /**
   * @param {FormattingTuple} value
   * @return {void}
   * @public
   */
  static set f_NULL__org_slf4j_helpers_FormattingTuple(value) {
    (FormattingTuple.$clinit(), FormattingTuple.$f_NULL__org_slf4j_helpers_FormattingTuple = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormattingTuple;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormattingTuple);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormattingTuple.$clinit = function() {};
    j_l_Object.$clinit();
    FormattingTuple.$f_NULL__org_slf4j_helpers_FormattingTuple = FormattingTuple.$create__java_lang_String(null);
  }
  
  
};

$Util.$setClassMetadata(FormattingTuple, $Util.$makeClassName('org.slf4j.helpers.FormattingTuple'));


/** @private {FormattingTuple} */
FormattingTuple.$f_NULL__org_slf4j_helpers_FormattingTuple;




exports = FormattingTuple; 
//# sourceMappingURL=FormattingTuple.js.map