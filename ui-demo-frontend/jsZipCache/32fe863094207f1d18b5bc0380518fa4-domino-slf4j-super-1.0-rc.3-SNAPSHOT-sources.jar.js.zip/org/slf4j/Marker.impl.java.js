/**
 * @fileoverview transpiled from org.slf4j.Marker.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.Marker$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Iterator = goog.forwardDeclare('java.util.Iterator$impl');


/**
 * @interface
 * @extends {Serializable}
 */
class Marker {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getName__() {
  }
  
  /**
   * @abstract
   * @param {Marker} reference
   * @return {void}
   * @public
   */
  m_add__org_slf4j_Marker(reference) {
  }
  
  /**
   * @abstract
   * @param {Marker} reference
   * @return {boolean}
   * @public
   */
  m_remove__org_slf4j_Marker(reference) {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_hasChildren__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_hasReferences__() {
  }
  
  /**
   * @abstract
   * @return {Iterator<Marker>}
   * @public
   */
  m_iterator__() {
  }
  
  /**
   * @abstract
   * @param {Marker} other
   * @return {boolean}
   * @public
   */
  m_contains__org_slf4j_Marker(other) {
  }
  
  /**
   * @abstract
   * @param {?string} name
   * @return {boolean}
   * @public
   */
  m_contains__java_lang_String(name) {
  }
  
  /**
   * @abstract
   * @param {*} o
   * @return {boolean}
   * @public
   */
  equals(o) {
  }
  
  /**
   * @abstract
   * @return {number}
   * @public
   */
  hashCode() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Serializable.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_slf4j_Marker = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_slf4j_Marker;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_slf4j_Marker;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Marker.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Marker, $Util.$makeClassName('org.slf4j.Marker'));


/** @public {?string} @const */
Marker.f_ANY_MARKER__org_slf4j_Marker = "*";


/** @public {?string} @const */
Marker.f_ANY_NON_NULL_MARKER__org_slf4j_Marker = "+";


Marker.$markImplementor(/** @type {Function} */ (Marker));


exports = Marker; 
//# sourceMappingURL=Marker.js.map