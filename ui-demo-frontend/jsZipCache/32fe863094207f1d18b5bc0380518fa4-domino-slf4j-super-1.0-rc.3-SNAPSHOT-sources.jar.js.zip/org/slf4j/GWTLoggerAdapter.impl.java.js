/**
 * @fileoverview transpiled from org.slf4j.GWTLoggerAdapter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.GWTLoggerAdapter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const MarkerIgnoringBase = goog.require('org.slf4j.helpers.MarkerIgnoringBase$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let Level = goog.forwardDeclare('java.util.logging.Level$impl');
let Logger = goog.forwardDeclare('java.util.logging.Logger$impl');
let MessageFormatter = goog.forwardDeclare('org.slf4j.helpers.MessageFormatter$impl');


class GWTLoggerAdapter extends MarkerIgnoringBase {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Logger} */
    this.f_logger__org_slf4j_GWTLoggerAdapter_;
  }
  
  /**
   * Factory method corresponding to constructor 'GWTLoggerAdapter(String)'.
   * @param {?string} name
   * @return {!GWTLoggerAdapter}
   * @public
   */
  static $create__java_lang_String(name) {
    GWTLoggerAdapter.$clinit();
    let $instance = new GWTLoggerAdapter();
    $instance.$ctor__org_slf4j_GWTLoggerAdapter__java_lang_String(name);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GWTLoggerAdapter(String)'.
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_GWTLoggerAdapter__java_lang_String(name) {
    this.$ctor__org_slf4j_helpers_MarkerIgnoringBase__();
    this.f_name__org_slf4j_helpers_NamedLoggerBase = name;
    this.f_logger__org_slf4j_GWTLoggerAdapter_ = Logger.m_getLogger__java_lang_String(name);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isTraceEnabled__() {
    return this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(Level.f_FINEST__java_util_logging_Level);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_trace__java_lang_String(msg) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINEST__java_util_logging_Level, msg, null);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Object(format, arg) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINEST__java_util_logging_Level, format, [arg]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINEST__java_util_logging_Level, format, [arg1, arg2]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__arrayOf_java_lang_Object(format, argArray) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINEST__java_util_logging_Level, format, argArray);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_trace__java_lang_String__java_lang_Throwable(msg, t) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINEST__java_util_logging_Level, msg, t);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isDebugEnabled__() {
    return this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(Level.f_FINE__java_util_logging_Level);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_debug__java_lang_String(msg) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINE__java_util_logging_Level, msg, null);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Object(format, arg) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINE__java_util_logging_Level, format, [arg]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINE__java_util_logging_Level, format, [arg1, arg2]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__arrayOf_java_lang_Object(format, argArray) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINE__java_util_logging_Level, format, argArray);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_debug__java_lang_String__java_lang_Throwable(msg, t) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_FINE__java_util_logging_Level, msg, t);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isInfoEnabled__() {
    return this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(Level.f_INFO__java_util_logging_Level);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_info__java_lang_String(msg) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_INFO__java_util_logging_Level, msg, null);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Object(format, arg) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_INFO__java_util_logging_Level, format, [arg]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_INFO__java_util_logging_Level, format, [arg1, arg2]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_info__java_lang_String__arrayOf_java_lang_Object(format, argArray) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_INFO__java_util_logging_Level, format, argArray);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_info__java_lang_String__java_lang_Throwable(msg, t) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_INFO__java_util_logging_Level, msg, t);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isWarnEnabled__() {
    return this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(Level.f_WARNING__java_util_logging_Level);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_warn__java_lang_String(msg) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_WARNING__java_util_logging_Level, msg, null);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Object(format, arg) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_WARNING__java_util_logging_Level, format, [arg]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_WARNING__java_util_logging_Level, format, [arg1, arg2]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__arrayOf_java_lang_Object(format, argArray) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_WARNING__java_util_logging_Level, format, argArray);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_warn__java_lang_String__java_lang_Throwable(msg, t) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_WARNING__java_util_logging_Level, msg, t);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isErrorEnabled__() {
    return this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(Level.f_SEVERE__java_util_logging_Level);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @return {void}
   * @public
   */
  m_error__java_lang_String(msg) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_SEVERE__java_util_logging_Level, msg, null);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Object(format, arg) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_SEVERE__java_util_logging_Level, format, [arg]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {*} arg1
   * @param {*} arg2
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Object__java_lang_Object(format, arg1, arg2) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_SEVERE__java_util_logging_Level, format, [arg1, arg2]);
  }
  
  /**
   * @override
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_error__java_lang_String__arrayOf_java_lang_Object(format, argArray) {
    this.m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(Level.f_SEVERE__java_util_logging_Level, format, argArray);
  }
  
  /**
   * @override
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_error__java_lang_String__java_lang_Throwable(msg, t) {
    this.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(Level.f_SEVERE__java_util_logging_Level, msg, t);
  }
  
  /**
   * @param {Level} level
   * @param {?string} msg
   * @param {Throwable} t
   * @return {void}
   * @public
   */
  m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable_$p_org_slf4j_GWTLoggerAdapter(level, msg, t) {
    if (this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(level)) {
      this.f_logger__org_slf4j_GWTLoggerAdapter_.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable(level, msg, t);
    }
  }
  
  /**
   * @param {Level} level
   * @param {?string} format
   * @param {Array<*>} argArray
   * @return {void}
   * @public
   */
  m_formatAndLog__java_util_logging_Level__java_lang_String__arrayOf_java_lang_Object_$p_org_slf4j_GWTLoggerAdapter(level, format, argArray) {
    if (this.f_logger__org_slf4j_GWTLoggerAdapter_.m_isLoggable__java_util_logging_Level(level)) {
      let ft = MessageFormatter.m_arrayFormat__java_lang_String__arrayOf_java_lang_Object(format, argArray);
      this.f_logger__org_slf4j_GWTLoggerAdapter_.m_log__java_util_logging_Level__java_lang_String__java_lang_Throwable(level, ft.m_getMessage__(), ft.m_getThrowable__());
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GWTLoggerAdapter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GWTLoggerAdapter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GWTLoggerAdapter.$clinit = function() {};
    Level = goog.module.get('java.util.logging.Level$impl');
    Logger = goog.module.get('java.util.logging.Logger$impl');
    MessageFormatter = goog.module.get('org.slf4j.helpers.MessageFormatter$impl');
    MarkerIgnoringBase.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GWTLoggerAdapter, $Util.$makeClassName('org.slf4j.GWTLoggerAdapter'));




exports = GWTLoggerAdapter; 
//# sourceMappingURL=GWTLoggerAdapter.js.map