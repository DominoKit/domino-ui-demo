/**
 * @fileoverview transpiled from org.slf4j.ILoggerFactory$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.slf4j.ILoggerFactory.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ILoggerFactory = goog.require('org.slf4j.ILoggerFactory$impl');

let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');


/**
 * @implements {ILoggerFactory}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string):Logger} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string):Logger} */
    this.f_$$fn__org_slf4j_ILoggerFactory_$LambdaAdaptor;
    this.$ctor__org_slf4j_ILoggerFactory_$LambdaAdaptor__org_slf4j_ILoggerFactory_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string):Logger} fn
   * @return {void}
   * @public
   */
  $ctor__org_slf4j_ILoggerFactory_$LambdaAdaptor__org_slf4j_ILoggerFactory_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_slf4j_ILoggerFactory_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @return {Logger}
   * @public
   */
  m_getLogger__java_lang_String(arg0) {
    let /** ?function(?string):Logger */ $function;
    return ($function = this.f_$$fn__org_slf4j_ILoggerFactory_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.slf4j.ILoggerFactory$$LambdaAdaptor'));


ILoggerFactory.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ILoggerFactory$$LambdaAdaptor.js.map