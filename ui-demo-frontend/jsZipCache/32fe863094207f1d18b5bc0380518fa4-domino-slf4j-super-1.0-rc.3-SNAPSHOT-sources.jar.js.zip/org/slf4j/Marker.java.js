/**
 * @fileoverview transpiled from org.slf4j.Marker.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.slf4j.Marker');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _$Util = goog.require('nativebootstrap.Util');
const _Iterator = goog.require('java.util.Iterator');


// Re-exports the implementation.
var Marker = goog.require('org.slf4j.Marker$impl');
exports = Marker;
 