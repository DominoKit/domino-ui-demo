/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let PaginationPresenter = goog.forwardDeclare('org.dominokit.domino.pagination.client.presenters.PaginationPresenter$impl');
let PaginationPresenterCommand = goog.forwardDeclare('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentsExtensionPoint>}
  */
class PaginationPresenterContributionToComponentsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PaginationPresenterContributionToComponentsExtensionPoint()'.
   * @return {!PaginationPresenterContributionToComponentsExtensionPoint}
   * @public
   */
  static $create__() {
    PaginationPresenterContributionToComponentsExtensionPoint.$clinit();
    let $instance = new PaginationPresenterContributionToComponentsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_pagination_client_contributions_PaginationPresenterContributionToComponentsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PaginationPresenterContributionToComponentsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_contributions_PaginationPresenterContributionToComponentsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(extensionPoint) {
    PaginationPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** PaginationPresenter */ presenter) =>{
      presenter.m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(/**@type {ComponentsExtensionPoint} */ ($Casts.$to(arg0, ComponentsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PaginationPresenterContributionToComponentsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PaginationPresenterContributionToComponentsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaginationPresenterContributionToComponentsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    PaginationPresenterCommand = goog.module.get('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PaginationPresenterContributionToComponentsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint'));


Contribution.$markImplementor(PaginationPresenterContributionToComponentsExtensionPoint);


exports = PaginationPresenterContributionToComponentsExtensionPoint; 
//# sourceMappingURL=PaginationPresenterContributionToComponentsExtensionPoint.js.map