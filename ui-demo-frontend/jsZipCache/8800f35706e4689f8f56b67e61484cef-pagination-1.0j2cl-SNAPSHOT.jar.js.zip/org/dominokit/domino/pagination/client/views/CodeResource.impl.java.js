/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_pagination_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_defaultPagination__() {
    CodeResource.$clinit();
    return "Pagination.create(5)\n" + "    .onPageChanged(pageNumber -> DomGlobal.console.info(pageNumber)";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_activePageSample__() {
    CodeResource.$clinit();
    return "Pagination.create(5)\n" + "        .markActivePage()\n" + "        .onPageChanged(pageNumber -> DomGlobal.console.info(pageNumber))\n" + "        .setActivePage(3)";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_sizesSample__() {
    CodeResource.$clinit();
    return "Pagination.create(5)\n" + "    .markActivePage()\n" + "    .onPageChanged(pageNumber -> DomGlobal.console.info(pageNumber))\n" + "    .setActivePage(3)\n" + "    .large()\n" + "    .asElement();\n" + "\n" + "Pagination.create(5)\n" + "    .markActivePage()\n" + "    .onPageChanged(pageNumber -> DomGlobal.console.info(pageNumber))\n" + "    .setActivePage(3)\n" + "    .asElement();\n" + "\n" + "Pagination.create(5)\n" + "    .markActivePage()\n" + "    .onPageChanged(pageNumber -> DomGlobal.console.info(pageNumber))\n" + "    .setActivePage(3)\n" + "    .small()\n" + "    .asElement();";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_pagerSample__() {
    CodeResource.$clinit();
    return "Pager.create()\n" + "    .onNext(() -> DomGlobal.console.info(\"Going to next page.\"))\n" + "    .onPrevious(() -> DomGlobal.console.info(\"Going to previous page.\"))\n" + "    .asElement();\n" + "\n" + "Pager.create()\n" + "    .onNext(() -> DomGlobal.console.info(\"Going to next page.\"))\n" + "    .onPrevious(() -> DomGlobal.console.info(\"Going to previous page.\"))\n" + "    .nextText(\"Newer\")\n" + "    .previousText(\"Older\")\n" + "    .showArrows()\n" + "    .asElement();\n" + "\n" + "Pager.create()\n" + "    .onNext(() -> DomGlobal.console.info(\"Going to next page.\"))\n" + "    .onPrevious(() -> DomGlobal.console.info(\"Going to previous page.\"))\n" + "    .nextText(\"Newer\")\n" + "    .previousText(\"Older\")\n" + "    .showArrows()\n" + "    .expand()\n" + "    .asElement();\n" + "\n" + "Pager.create()\n" + "    .onNext(() -> DomGlobal.console.info(\"Going to next page.\"))\n" + "    .onPrevious(() -> DomGlobal.console.info(\"Going to previous page.\"))\n" + "    .nextText(\"Newer\")\n" + "    .previousText(\"Older\")\n" + "    .showArrows()\n" + "    .expand()\n" + "    .disablePrevious()\n" + "    .asElement();";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.pagination.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map