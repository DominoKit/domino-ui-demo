/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _ComponentsExtensionPoint = goog.require('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint');
const _PaginationPresenter = goog.require('org.dominokit.domino.pagination.client.presenters.PaginationPresenter');
const _PaginationPresenterCommand = goog.require('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var PaginationPresenterContributionToComponentsExtensionPoint = goog.require('org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint$impl');
exports = PaginationPresenterContributionToComponentsExtensionPoint;
 