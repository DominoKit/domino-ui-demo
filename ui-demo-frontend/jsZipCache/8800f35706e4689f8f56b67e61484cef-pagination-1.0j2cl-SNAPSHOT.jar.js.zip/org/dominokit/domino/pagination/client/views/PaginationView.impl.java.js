/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.views.PaginationView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.views.PaginationView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.pagination.client.views.PaginationView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class PaginationView {
  /**
   * @param {?function():Content} fn
   * @return {PaginationView}
   * @public
   */
  static $adapt(fn) {
    PaginationView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_pagination_client_views_PaginationView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_pagination_client_views_PaginationView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_pagination_client_views_PaginationView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaginationView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.pagination.client.views.PaginationView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(PaginationView, $Util.$makeClassName('org.dominokit.domino.pagination.client.views.PaginationView'));


PaginationView.$markImplementor(/** @type {Function} */ (PaginationView));


exports = PaginationView; 
//# sourceMappingURL=PaginationView.js.map