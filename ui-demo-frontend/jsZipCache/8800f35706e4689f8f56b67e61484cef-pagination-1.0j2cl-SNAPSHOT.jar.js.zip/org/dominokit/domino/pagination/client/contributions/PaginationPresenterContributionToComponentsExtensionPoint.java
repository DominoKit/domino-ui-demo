package org.dominokit.domino.pagination.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class PaginationPresenterContributionToComponentsExtensionPoint implements Contribution<ComponentsExtensionPoint> {
  @Override
  public void contribute(ComponentsExtensionPoint extensionPoint) {
    new PaginationPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentsModule(extensionPoint.context())).send();
  }
}
