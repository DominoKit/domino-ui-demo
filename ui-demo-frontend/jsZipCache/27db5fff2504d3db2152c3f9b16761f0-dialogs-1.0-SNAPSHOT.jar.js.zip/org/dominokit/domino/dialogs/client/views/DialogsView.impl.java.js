/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.views.DialogsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.dialogs.client.views.DialogsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.dialogs.client.views.DialogsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class DialogsView {
  /**
   * @param {?function():Content} fn
   * @return {DialogsView}
   * @public
   */
  static $adapt(fn) {
    DialogsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_dialogs_client_views_DialogsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_dialogs_client_views_DialogsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_dialogs_client_views_DialogsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DialogsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.dialogs.client.views.DialogsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DialogsView, $Util.$makeClassName('org.dominokit.domino.dialogs.client.views.DialogsView'));


DialogsView.$markImplementor(/** @type {Function} */ (DialogsView));


exports = DialogsView; 
//# sourceMappingURL=DialogsView.js.map