/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.DialogsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.dialogs.client.DialogsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class DialogsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DialogsClientModule()'.
   * @return {!DialogsClientModule}
   * @public
   */
  static $create__() {
    DialogsClientModule.$clinit();
    let $instance = new DialogsClientModule();
    $instance.$ctor__org_dominokit_domino_dialogs_client_DialogsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DialogsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_dialogs_client_DialogsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    DialogsClientModule.$f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_.m_info__java_lang_String("Initializing Dialogs frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_() {
    return (DialogsClientModule.$clinit(), DialogsClientModule.$f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_(value) {
    (DialogsClientModule.$clinit(), DialogsClientModule.$f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DialogsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DialogsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DialogsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    DialogsClientModule.$f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(DialogsClientModule));
  }
  
  
};

$Util.$setClassMetadata(DialogsClientModule, $Util.$makeClassName('org.dominokit.domino.dialogs.client.DialogsClientModule'));


/** @private {Logger} */
DialogsClientModule.$f_LOGGER__org_dominokit_domino_dialogs_client_DialogsClientModule_;




exports = DialogsClientModule; 
//# sourceMappingURL=DialogsClientModule.js.map