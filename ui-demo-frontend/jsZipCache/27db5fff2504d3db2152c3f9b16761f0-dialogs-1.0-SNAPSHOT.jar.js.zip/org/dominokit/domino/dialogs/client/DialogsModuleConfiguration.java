package org.dominokit.domino.dialogs.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.dialogs.client.listeners.DialogsPresenterListenerForComponentsEvent;
import org.dominokit.domino.dialogs.client.presenters.DialogsPresenter;
import org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand;
import org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class DialogsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(DialogsPresenter.class.getCanonicalName(), DialogsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new DialogsPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(DialogsPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new DialogsViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(DialogsPresenterCommand.class.getCanonicalName(), DialogsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentsEvent.class, new DialogsPresenterListenerForComponentsEvent());
  }
}
