/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _DialogsView = goog.require('org.dominokit.domino.dialogs.client.views.DialogsView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.$LambdaAdaptor$1');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Animation = goog.require('org.dominokit.domino.ui.animations.Animation');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _MessageDialog = goog.require('org.dominokit.domino.ui.dialogs.MessageDialog');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _SimpleListGroup = goog.require('org.dominokit.domino.ui.lists.SimpleListGroup');
const _SimpleListItem = goog.require('org.dominokit.domino.ui.lists.SimpleListItem');
const _CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');
const _OpenHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DialogsViewImpl = goog.require('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl$impl');
exports = DialogsViewImpl;
 