/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const DialogsView = goog.require('org.dominokit.domino.dialogs.client.views.DialogsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.$LambdaAdaptor$1$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let MessageDialog = goog.forwardDeclare('org.dominokit.domino.ui.dialogs.MessageDialog$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let SimpleListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListGroup$impl');
let SimpleListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListItem$impl');
let CloseHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
let OpenHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {DialogsView}
  */
class DialogsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'DialogsViewImpl()'.
   * @return {!DialogsViewImpl}
   * @public
   */
  static $create__() {
    DialogsViewImpl.$clinit();
    let $instance = new DialogsViewImpl();
    $instance.$ctor__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DialogsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(DialogsViewImpl.f_MODULE_NAME__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("DIALOGS").m_asElement__());
    let basicMessage = MessageDialog.m_createMessage__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Here's a message!", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    })));
    let headerAndMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Message header", "Here's a message body!", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    })));
    let successMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Success Operation", "Well done! You successfully read this important alert message.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_success__();
    let errorMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Failed operation", "Oh snap! Change a few things up and try submitting again.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_error__();
    let customColors = /**@type {MessageDialog} */ ($Casts.$to(MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Failed operation", "Oh snap! Change a few things up and try submitting again.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_error__().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), MessageDialog)).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color);
    let warningMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Warning", "Warning! Better check yourself, you're not looking too good.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_warning__();
    let heart = /**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_favorite__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_font_72__org_dominokit_domino_ui_style_Styles, Styles.f_m_b_15__org_dominokit_domino_ui_style_Styles, Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()], j_l_String))).m_get__(), Icon));
    let customHeaderContent = /**@type {MessageDialog} */ ($Casts.$to(MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Custom header", "You can customize the header content", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(OpenHandler.$adapt((() =>{
      Animation.m_create__org_dominokit_domino_ui_utils_BaseDominoElement(heart).m_duration__int(400).m_infinite__().m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_PULSE__org_dominokit_domino_ui_animations_Transition).m_animate__();
    }))), MessageDialog)).m_appendHeaderChild__org_jboss_gwt_elemento_core_IsElement(heart);
    let customContent = /**@type {MessageDialog} */ ($Casts.$to(MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Custom content", "You can customize the dialog content", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(SimpleListGroup.m_create__().m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Cras justo odio").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("14 new").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Dapibus ac facilisis in").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("99 unread").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Morbi leo risus").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("99+").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Porta ac consectetur ac").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("21").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Vestibulum at eros").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("Pending").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color))).m_style__().m_setTextAlign__java_lang_String("left")), MessageDialog));
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(Card.m_create__java_lang_String("EXAMPLES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(basicMessage), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("A basic message")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(basicMessage)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(headerAndMessage), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Message with header")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(headerAndMessage)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(successMessage), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Success message")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(successMessage)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(errorMessage), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Error message")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(errorMessage)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(warningMessage), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Warning message")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(warningMessage)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(customColors), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Custom colors")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(customColors)), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(customHeaderContent), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Custom header content")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(customHeaderContent)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(customContent), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Custom content")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(customContent)), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(DialogsViewImpl.f_MODULE_NAME__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl, "dialogs").m_asElement__());
  }
  
  /**
   * @param {MessageDialog} dialog
   * @return {Button}
   * @public
   */
  m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(dialog) {
    return /**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("CLICK ME").m_style__().m_setMinWidth__java_lang_String("120px").m_get__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      dialog.m_open__();
    }))), Button));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl() {
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DialogsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DialogsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DialogsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.$LambdaAdaptor$1$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Animation = goog.module.get('org.dominokit.domino.ui.animations.Animation$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    MessageDialog = goog.module.get('org.dominokit.domino.ui.dialogs.MessageDialog$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    SimpleListGroup = goog.module.get('org.dominokit.domino.ui.lists.SimpleListGroup$impl');
    SimpleListItem = goog.module.get('org.dominokit.domino.ui.lists.SimpleListItem$impl');
    CloseHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
    OpenHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DialogsViewImpl, $Util.$makeClassName('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl'));


/** @public {?string} @const */
DialogsViewImpl.f_MODULE_NAME__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl = "dialogs";


DialogsView.$markImplementor(DialogsViewImpl);


exports = DialogsViewImpl; 
//# sourceMappingURL=DialogsViewImpl.js.map