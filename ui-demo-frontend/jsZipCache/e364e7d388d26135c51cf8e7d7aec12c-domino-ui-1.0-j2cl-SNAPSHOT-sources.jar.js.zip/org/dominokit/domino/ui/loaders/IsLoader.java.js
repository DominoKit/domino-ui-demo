/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.IsLoader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.loaders.IsLoader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.loaders.IsLoader.$LambdaAdaptor');


// Re-exports the implementation.
var IsLoader = goog.require('org.dominokit.domino.ui.loaders.IsLoader$impl');
exports = IsLoader;
 