/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.IsLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.IsLoader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.loaders.IsLoader.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {IsElement<HTMLDivElement>}
 */
class IsLoader {
  /**
   * @abstract
   * @param {?string} text
   * @return {void}
   * @public
   */
  m_setLoadingText__java_lang_String(text) {
  }
  
  /**
   * @param {?function():HTMLDivElement} fn
   * @return {IsLoader}
   * @public
   */
  static $adapt(fn) {
    IsLoader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {IsLoader} $thisArg
   * @param {?string} text
   * @return {void}
   * @public
   */
  static m_setLoadingText__$default__org_dominokit_domino_ui_loaders_IsLoader__java_lang_String($thisArg, text) {
    IsLoader.$clinit();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    IsElement.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_loaders_IsLoader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_loaders_IsLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_loaders_IsLoader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IsLoader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.loaders.IsLoader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(IsLoader, $Util.$makeClassName('org.dominokit.domino.ui.loaders.IsLoader'));


IsLoader.$markImplementor(/** @type {Function} */ (IsLoader));


exports = IsLoader; 
//# sourceMappingURL=IsLoader.js.map