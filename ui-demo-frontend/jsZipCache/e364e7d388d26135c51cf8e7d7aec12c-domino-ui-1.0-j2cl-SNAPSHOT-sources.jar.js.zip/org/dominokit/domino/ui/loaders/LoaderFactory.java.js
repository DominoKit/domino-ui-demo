/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.LoaderFactory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.loaders.LoaderFactory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _BounceLoader = goog.require('org.dominokit.domino.ui.loaders.BounceLoader');
const _FacebookLoader = goog.require('org.dominokit.domino.ui.loaders.FacebookLoader');
const _IosLoader = goog.require('org.dominokit.domino.ui.loaders.IosLoader');
const _IsLoader = goog.require('org.dominokit.domino.ui.loaders.IsLoader');
const _LoaderEffect = goog.require('org.dominokit.domino.ui.loaders.LoaderEffect');
const _NoneLoader = goog.require('org.dominokit.domino.ui.loaders.NoneLoader');
const _OrbitLoader = goog.require('org.dominokit.domino.ui.loaders.OrbitLoader');
const _RotatePlaneLoader = goog.require('org.dominokit.domino.ui.loaders.RotatePlaneLoader');
const _RotationLoader = goog.require('org.dominokit.domino.ui.loaders.RotationLoader');
const _RoundBounceLoader = goog.require('org.dominokit.domino.ui.loaders.RoundBounceLoader');
const _StretchLoader = goog.require('org.dominokit.domino.ui.loaders.StretchLoader');
const _TimerLoader = goog.require('org.dominokit.domino.ui.loaders.TimerLoader');
const _Win8LinearLoader = goog.require('org.dominokit.domino.ui.loaders.Win8LinearLoader');
const _Win8Loader = goog.require('org.dominokit.domino.ui.loaders.Win8Loader');


// Re-exports the implementation.
var LoaderFactory = goog.require('org.dominokit.domino.ui.loaders.LoaderFactory$impl');
exports = LoaderFactory;
 