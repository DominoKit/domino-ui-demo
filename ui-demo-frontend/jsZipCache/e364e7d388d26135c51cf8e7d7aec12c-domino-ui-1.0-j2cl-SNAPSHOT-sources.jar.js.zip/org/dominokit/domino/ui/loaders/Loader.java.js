/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.Loader.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.loaders.Loader');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _IsLoader = goog.require('org.dominokit.domino.ui.loaders.IsLoader');
const _LoaderEffect = goog.require('org.dominokit.domino.ui.loaders.LoaderEffect');
const _LoaderFactory = goog.require('org.dominokit.domino.ui.loaders.LoaderFactory');


// Re-exports the implementation.
var Loader = goog.require('org.dominokit.domino.ui.loaders.Loader$impl');
exports = Loader;
 