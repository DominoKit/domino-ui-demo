/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.AccordionPanel.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');
const IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Collapsible = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {IsCollapsible<AccordionPanel>}
 * @implements {HasClickableElement}
  */
class AccordionPanel extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {HTMLDivElement} */
    this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {HTMLHeadingElement} */
    this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {HTMLAnchorElement} */
    this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {HTMLDivElement} */
    this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {Collapsible} */
    this.f_collapsible__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {HTMLDivElement} */
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {?string} */
    this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {Icon} */
    this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_;
  }
  
  /**
   * Factory method corresponding to constructor 'AccordionPanel(String)'.
   * @param {?string} title
   * @return {!AccordionPanel}
   * @public
   */
  static $create__java_lang_String(title) {
    AccordionPanel.$clinit();
    let $instance = new AccordionPanel();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String(title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccordionPanel(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String(title) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_collapsible_AccordionPanel();
    this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.textContent = title;
    this.m_init___$p_org_dominokit_domino_ui_collapsible_AccordionPanel();
  }
  
  /**
   * Factory method corresponding to constructor 'AccordionPanel(String, Node)'.
   * @param {?string} title
   * @param {Node} content
   * @return {!AccordionPanel}
   * @public
   */
  static $create__java_lang_String__elemental2_dom_Node(title, content) {
    AccordionPanel.$clinit();
    let $instance = new AccordionPanel();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String__elemental2_dom_Node(title, content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccordionPanel(String, Node)'.
   * @param {?string} title
   * @param {Node} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String__elemental2_dom_Node(title, content) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_collapsible_AccordionPanel();
    this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.textContent = title;
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(content);
    this.m_init___$p_org_dominokit_domino_ui_collapsible_AccordionPanel();
  }
  
  /**
   * @param {?string} title
   * @return {AccordionPanel}
   * @public
   */
  static m_create__java_lang_String(title) {
    AccordionPanel.$clinit();
    return AccordionPanel.$create__java_lang_String(title);
  }
  
  /**
   * @param {?string} title
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   */
  static m_create__java_lang_String__elemental2_dom_Node(title, content) {
    AccordionPanel.$clinit();
    return AccordionPanel.$create__java_lang_String__elemental2_dom_Node(title, content);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_init___$p_org_dominokit_domino_ui_collapsible_AccordionPanel() {
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
  }
  
  /**
   * @param {?string} title
   * @return {AccordionPanel}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.textContent = title;
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   */
  m_setContent__elemental2_dom_Node(content) {
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.textContent = "";
    return this.m_appendContent__elemental2_dom_Node(content);
  }
  
  /**
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.appendChild(content);
    return this;
  }
  
  /**
   * @override
   * @return {AccordionPanel}
   * @public
   */
  m_collapse__() {
    this.f_collapsible__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_collapse__();
    return this;
  }
  
  /**
   * @override
   * @return {AccordionPanel}
   * @public
   */
  m_expand__() {
    this.f_collapsible__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_expand__();
    return this;
  }
  
  /**
   * @override
   * @return {AccordionPanel}
   * @public
   */
  m_toggle__() {
    this.f_collapsible__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_toggle__();
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isCollapsed__() {
    return this.f_collapsible__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_isCollapsed__();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_primary__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-primary");
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_success__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-success");
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_warning__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-warning");
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_danger__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-danger");
  }
  
  /**
   * @param {Color} color
   * @return {AccordionPanel}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-" + j_l_String.m_valueOf__java_lang_Object(color.m_getStyle__()));
  }
  
  /**
   * @param {?string} style
   * @return {AccordionPanel}
   * @public
   */
  m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible(style) {
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.classList.remove(this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_ = style;
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.classList.add(this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    return this;
  }
  
  /**
   * @param {Icon} icon
   * @return {AccordionPanel}
   * @public
   */
  m_setIcon__org_dominokit_domino_ui_icons_Icon(icon) {
    if (Objects.m_nonNull__java_lang_Object(this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_)) {
      this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_asElement__().remove();
    }
    this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_ = icon;
    this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.insertBefore(icon.m_asElement__(), this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.firstChild);
    return this;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getBody__() {
    return this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_collapsible_AccordionPanel() {
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel panel-primary"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-heading"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "tab"), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-title"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
    this.f_clickablElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("role", "button"), HtmlContentBuilder)).m_asElement__(), HTMLAnchorElement_$Overlay));
    this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-collapse"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_collapsible__org_dominokit_domino_ui_collapsible_AccordionPanel_ = Collapsible.m_create__elemental2_dom_HTMLElement(this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-body"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_ = "panel-primary";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AccordionPanel;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AccordionPanel);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AccordionPanel.$clinit = function() {};
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Collapsible = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AccordionPanel, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.AccordionPanel'));


IsElement.$markImplementor(AccordionPanel);
IsCollapsible.$markImplementor(AccordionPanel);
HasClickableElement.$markImplementor(AccordionPanel);


exports = AccordionPanel; 
//# sourceMappingURL=AccordionPanel.js.map