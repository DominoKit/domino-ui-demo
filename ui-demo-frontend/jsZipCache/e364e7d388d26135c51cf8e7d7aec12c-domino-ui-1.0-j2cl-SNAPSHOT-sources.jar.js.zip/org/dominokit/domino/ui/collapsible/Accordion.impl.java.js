/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Accordion.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Accordion$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Accordion.$LambdaAdaptor$7$impl');
let AccordionPanel = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class Accordion extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_;
    /** @public {List<AccordionPanel>} */
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_;
    /** @public {boolean} */
    this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Accordion()'.
   * @return {!Accordion}
   * @public
   */
  static $create__() {
    Accordion.$clinit();
    let $instance = new Accordion();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_Accordion__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Accordion()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_Accordion__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_collapsible_Accordion();
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  static m_create__() {
    Accordion.$clinit();
    return Accordion.$create__();
  }
  
  /**
   * @param {AccordionPanel} panel
   * @return {Accordion}
   * @public
   */
  m_addPanel__org_dominokit_domino_ui_collapsible_AccordionPanel(panel) {
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_.add(panel);
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_.appendChild(panel.m_asElement__());
    panel.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$7(((/** Event */ evt) =>{
      if (!this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_) {
        this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** AccordionPanel */ arg0) =>{
          arg0.m_collapse__();
        })));
      }
      panel.m_toggle__();
    })));
    return this;
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_multiOpen__() {
    this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_ = true;
    return this;
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_primary__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-primary");
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_success__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-success");
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_warning__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-warning");
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_danger__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-danger");
  }
  
  /**
   * @param {Color} color
   * @return {Accordion}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-" + j_l_String.m_valueOf__java_lang_Object(color.m_getStyle__()));
  }
  
  /**
   * @param {?string} style
   * @return {Accordion}
   * @public
   */
  m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion(style) {
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** AccordionPanel */ p) =>{
      p.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible(style);
    })));
    return this;
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_fullBody__() {
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_.classList.add("full-body");
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_collapsible_Accordion_;
  }
  
  /**
   * @return {List<AccordionPanel>}
   * @public
   */
  m_getPanels__() {
    return this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_collapsible_Accordion() {
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_ = /**@type {!LinkedList<AccordionPanel>} */ (LinkedList.$create__());
    this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Accordion;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Accordion);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Accordion.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.ui.collapsible.Accordion.$LambdaAdaptor$7$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Accordion, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Accordion'));


IsElement.$markImplementor(Accordion);


exports = Accordion; 
//# sourceMappingURL=Accordion.js.map