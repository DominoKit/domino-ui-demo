/**
 * @fileoverview transpiled from org.dominokit.domino.ui.notifications.BottomCenterPosition.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.notifications.BottomCenterPosition$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const NotificationPosition = goog.require('org.dominokit.domino.ui.notifications.NotificationPosition$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


class BottomCenterPosition extends NotificationPosition {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BottomCenterPosition()'.
   * @return {!BottomCenterPosition}
   * @public
   */
  static $create__() {
    BottomCenterPosition.$clinit();
    let $instance = new BottomCenterPosition();
    $instance.$ctor__org_dominokit_domino_ui_notifications_BottomCenterPosition__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BottomCenterPosition()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_notifications_BottomCenterPosition__() {
    this.$ctor__org_dominokit_domino_ui_notifications_NotificationPosition__java_lang_String__java_lang_String("bottom-center", "bottom");
  }
  
  /**
   * @override
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_onBeforePosition__elemental2_dom_HTMLElement(element) {
    element.style.setProperty("bottom", "20px");
    element.style.setProperty("right", "0px");
    element.style.setProperty("left", "0px");
  }
  
  /**
   * @override
   * @param {HTMLElement} element
   * @return {number}
   * @public
   */
  m_getOffsetPosition__elemental2_dom_HTMLElement(element) {
    return 20;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BottomCenterPosition;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BottomCenterPosition);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BottomCenterPosition.$clinit = function() {};
    NotificationPosition.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BottomCenterPosition, $Util.$makeClassName('org.dominokit.domino.ui.notifications.BottomCenterPosition'));




exports = BottomCenterPosition; 
//# sourceMappingURL=BottomCenterPosition.js.map