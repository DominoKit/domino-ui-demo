/**
 * @fileoverview transpiled from org.dominokit.domino.ui.notifications.BottomLeftPosition.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.notifications.BottomLeftPosition$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const NotificationPosition = goog.require('org.dominokit.domino.ui.notifications.NotificationPosition$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


class BottomLeftPosition extends NotificationPosition {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BottomLeftPosition()'.
   * @return {!BottomLeftPosition}
   * @public
   */
  static $create__() {
    BottomLeftPosition.$clinit();
    let $instance = new BottomLeftPosition();
    $instance.$ctor__org_dominokit_domino_ui_notifications_BottomLeftPosition__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BottomLeftPosition()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_notifications_BottomLeftPosition__() {
    this.$ctor__org_dominokit_domino_ui_notifications_NotificationPosition__java_lang_String__java_lang_String("bottom-left", "bottom");
  }
  
  /**
   * @override
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_onBeforePosition__elemental2_dom_HTMLElement(element) {
    element.style.setProperty("bottom", "20px");
    element.style.setProperty("left", "20px");
  }
  
  /**
   * @override
   * @param {HTMLElement} element
   * @return {number}
   * @public
   */
  m_getOffsetPosition__elemental2_dom_HTMLElement(element) {
    return 20;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BottomLeftPosition;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BottomLeftPosition);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BottomLeftPosition.$clinit = function() {};
    NotificationPosition.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BottomLeftPosition, $Util.$makeClassName('org.dominokit.domino.ui.notifications.BottomLeftPosition'));




exports = BottomLeftPosition; 
//# sourceMappingURL=BottomLeftPosition.js.map