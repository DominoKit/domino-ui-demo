/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.IconButton.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.IconButton$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Button = goog.require('org.dominokit.domino.ui.button.Button$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let CircleSize = goog.forwardDeclare('org.dominokit.domino.ui.button.CircleSize$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let WaveStyle = goog.forwardDeclare('org.dominokit.domino.ui.style.WaveStyle$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class IconButton extends Button {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Icon} */
    this.f_icon__org_dominokit_domino_ui_button_IconButton_;
    /** @public {?string} */
    this.f_content__org_dominokit_domino_ui_button_IconButton_;
  }
  
  /**
   * Factory method corresponding to constructor 'IconButton(Icon)'.
   * @param {Icon} icon
   * @return {!IconButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    let $instance = new IconButton();
    $instance.$ctor__org_dominokit_domino_ui_button_IconButton__org_dominokit_domino_ui_icons_Icon(icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconButton(Icon)'.
   * @param {Icon} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_IconButton__org_dominokit_domino_ui_icons_Icon(icon) {
    this.$ctor__org_dominokit_domino_ui_button_Button__();
    this.m_setIcon__org_dominokit_domino_ui_icons_Icon(icon);
  }
  
  /**
   * Factory method corresponding to constructor 'IconButton(Icon, StyleType)'.
   * @param {Icon} icon
   * @param {StyleType} type
   * @return {!IconButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    IconButton.$clinit();
    let $instance = new IconButton();
    $instance.$ctor__org_dominokit_domino_ui_button_IconButton__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconButton(Icon, StyleType)'.
   * @param {Icon} icon
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_IconButton__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    this.$ctor__org_dominokit_domino_ui_button_IconButton__org_dominokit_domino_ui_icons_Icon(icon);
    this.m_setButtonType__org_dominokit_domino_ui_style_StyleType(type);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.$create__org_dominokit_domino_ui_icons_Icon(icon);
  }
  
  /**
   * @param {Icon} icon
   * @param {StyleType} type
   * @return {IconButton}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, type) {
    IconButton.$clinit();
    return IconButton.$create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_createDefault__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_createPrimary__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_createSuccess__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_createInfo__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_createWarning__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  static m_createDanger__org_dominokit_domino_ui_icons_Icon(icon) {
    IconButton.$clinit();
    return IconButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_IconButton(icon, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {IconButton}
   * @public
   */
  m_setIcon__org_dominokit_domino_ui_icons_Icon(icon) {
    if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_button_IconButton_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.textContent = "";
      this.f_icon__org_dominokit_domino_ui_button_IconButton_.m_asElement__().remove();
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.appendChild(icon.m_asElement__());
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String(this.f_content__org_dominokit_domino_ui_button_IconButton_), HtmlContentBuilder)).m_asElement__());
    } else {
      this.f_buttonElement__org_dominokit_domino_ui_button_Button.appendChild(icon.m_asElement__());
    }
    this.f_icon__org_dominokit_domino_ui_button_IconButton_ = icon;
    return this;
  }
  
  /**
   * @override
   * @param {CircleSize} size
   * @return {IconButton}
   * @public
   */
  m_circle__org_dominokit_domino_ui_button_CircleSize(size) {
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.classList.add(size.m_getStyle__());
    this.m_applyCircleWaves___$p_org_dominokit_domino_ui_button_IconButton();
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_applyCircleWaves___$p_org_dominokit_domino_ui_button_IconButton() {
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_CIRCLE__org_dominokit_domino_ui_style_WaveStyle);
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_FLOAT__org_dominokit_domino_ui_style_WaveStyle);
  }
  
  /**
   * @override
   * @param {?string} content
   * @return {IconButton}
   * @public
   */
  m_setContent__java_lang_String(content) {
    this.f_content__org_dominokit_domino_ui_button_IconButton_ = content;
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.textContent = "";
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.appendChild(this.f_icon__org_dominokit_domino_ui_button_IconButton_.m_asElement__());
    this.f_buttonElement__org_dominokit_domino_ui_button_Button.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String(content), HtmlContentBuilder)).m_asElement__());
    return this;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IconButton;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IconButton);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IconButton.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    WaveStyle = goog.module.get('org.dominokit.domino.ui.style.WaveStyle$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    Button.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IconButton, $Util.$makeClassName('org.dominokit.domino.ui.button.IconButton'));




exports = IconButton; 
//# sourceMappingURL=IconButton.js.map