/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.JustifiedGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.group.JustifiedGroup$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsGroup = goog.require('org.dominokit.domino.ui.button.group.IsGroup$impl');
const Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');


/**
 * @implements {IsElement<HTMLElement>}
 * @implements {IsGroup<HTMLElement>}
 * @implements {Sizable<JustifiedGroup>}
  */
class JustifiedGroup extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ButtonsGroup} */
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_;
  }
  
  /**
   * @return {JustifiedGroup}
   * @public
   */
  static m_create__() {
    JustifiedGroup.$clinit();
    return JustifiedGroup.$create__();
  }
  
  /**
   * Factory method corresponding to constructor 'JustifiedGroup()'.
   * @return {!JustifiedGroup}
   * @public
   */
  static $create__() {
    JustifiedGroup.$clinit();
    let $instance = new JustifiedGroup();
    $instance.$ctor__org_dominokit_domino_ui_button_group_JustifiedGroup__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JustifiedGroup()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_group_JustifiedGroup__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_button_group_JustifiedGroup();
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_asElement__().classList.add(j_l_String.m_valueOf__java_lang_Object(ButtonsGroup.f_BTN_GROUP__org_dominokit_domino_ui_button_group_ButtonsGroup) + "-justified");
  }
  
  /**
   * @override
   * @param {Button} button
   * @return {HTMLElement}
   * @public
   */
  m_addButton__org_dominokit_domino_ui_button_Button(button) {
    let justify = button.m_justify__();
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_asElement__().appendChild(justify);
    return justify;
  }
  
  /**
   * @override
   * @param {DropdownButton} dropDown
   * @return {HTMLElement}
   * @public
   */
  m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(dropDown) {
    let justify = dropDown.m_justify__();
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_asElement__().appendChild(justify);
    return justify;
  }
  
  /**
   * @override
   * @return {IsGroup<HTMLElement>}
   * @public
   */
  m_verticalAlign__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_verticalAlign__();
    return this;
  }
  
  /**
   * @override
   * @return {IsGroup<HTMLElement>}
   * @public
   */
  m_horizontalAlign__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_horizontalAlign__();
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_asElement__();
  }
  
  /**
   * @override
   * @return {JustifiedGroup}
   * @public
   */
  m_large__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_large__();
    return this;
  }
  
  /**
   * @override
   * @return {JustifiedGroup}
   * @public
   */
  m_small__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_small__();
    return this;
  }
  
  /**
   * @override
   * @return {JustifiedGroup}
   * @public
   */
  m_xSmall__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_xSmall__();
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_group_JustifiedGroup() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_ = ButtonsGroup.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JustifiedGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JustifiedGroup);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JustifiedGroup.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    ButtonsGroup = goog.module.get('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JustifiedGroup, $Util.$makeClassName('org.dominokit.domino.ui.button.group.JustifiedGroup'));


IsElement.$markImplementor(JustifiedGroup);
IsGroup.$markImplementor(JustifiedGroup);
Sizable.$markImplementor(JustifiedGroup);


exports = JustifiedGroup; 
//# sourceMappingURL=JustifiedGroup.js.map