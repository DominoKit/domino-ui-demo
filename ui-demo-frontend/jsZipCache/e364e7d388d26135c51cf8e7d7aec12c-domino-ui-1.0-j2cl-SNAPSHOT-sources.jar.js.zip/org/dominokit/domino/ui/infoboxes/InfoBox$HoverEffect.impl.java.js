/**
 * @fileoverview transpiled from org.dominokit.domino.ui.infoboxes.InfoBox$HoverEffect.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<HoverEffect>}
  */
class HoverEffect extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_effectStyle__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_;
  }
  
  /**
   * Factory method corresponding to constructor 'HoverEffect(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} effectStyle
   * @return {!HoverEffect}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, effectStyle) {
    let $instance = new HoverEffect();
    $instance.$ctor__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect__java_lang_String__int__java_lang_String($name, $ordinal, effectStyle);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HoverEffect(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} effectStyle
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect__java_lang_String__int__java_lang_String($name, $ordinal, effectStyle) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_effectStyle__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_ = effectStyle;
  }
  
  /**
   * @param {string} name
   * @return {!HoverEffect}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    HoverEffect.$clinit();
    if ($Equality.$same(HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_, null)) {
      HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_ = $Enums.createMapFromValues(HoverEffect.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_);
  }
  
  /**
   * @return {!Array<!HoverEffect>}
   * @public
   */
  static m_values__() {
    HoverEffect.$clinit();
    return /**@type {!Array<HoverEffect>} */ ($Arrays.$init([HoverEffect.$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect, HoverEffect.$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect], HoverEffect));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {HoverEffect} */ ($Casts.$to(arg0, HoverEffect)));
  }
  
  /**
   * @return {!HoverEffect}
   * @public
   */
  static get f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect() {
    return (HoverEffect.$clinit(), HoverEffect.$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
  }
  
  /**
   * @param {!HoverEffect} value
   * @return {void}
   * @public
   */
  static set f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(value) {
    (HoverEffect.$clinit(), HoverEffect.$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect = value);
  }
  
  /**
   * @return {!HoverEffect}
   * @public
   */
  static get f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect() {
    return (HoverEffect.$clinit(), HoverEffect.$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
  }
  
  /**
   * @param {!HoverEffect} value
   * @return {void}
   * @public
   */
  static set f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(value) {
    (HoverEffect.$clinit(), HoverEffect.$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect = value);
  }
  
  /**
   * @return {Map<?string, !HoverEffect>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_() {
    return (HoverEffect.$clinit(), HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_);
  }
  
  /**
   * @param {Map<?string, !HoverEffect>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_(value) {
    (HoverEffect.$clinit(), HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HoverEffect;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HoverEffect);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HoverEffect.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    HoverEffect.$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect = HoverEffect.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ZOOM"), HoverEffect.$ordinal$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect, "hover-zoom-effect");
    HoverEffect.$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect = HoverEffect.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("EXPAND"), HoverEffect.$ordinal$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect, "hover-expand-effect");
    HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(HoverEffect, $Util.$makeClassName('org.dominokit.domino.ui.infoboxes.InfoBox$HoverEffect'));


/** @private {!HoverEffect} */
HoverEffect.$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect;


/** @private {!HoverEffect} */
HoverEffect.$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect;


/** @private {Map<?string, !HoverEffect>} */
HoverEffect.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_;


/** @public {number} @const */
HoverEffect.$ordinal$f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect = 0;


/** @public {number} @const */
HoverEffect.$ordinal$f_EXPAND__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect = 1;




exports = HoverEffect; 
//# sourceMappingURL=InfoBox$HoverEffect.js.map