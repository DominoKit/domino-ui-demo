/**
 * @fileoverview transpiled from org.dominokit.domino.ui.infoboxes.InfoBox$Flip.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.infoboxes.InfoBox.Flip$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Flip>}
  */
class Flip extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_;
  }
  
  /**
   * Factory method corresponding to constructor 'Flip(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} flipStyle
   * @return {!Flip}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, flipStyle) {
    let $instance = new Flip();
    $instance.$ctor__org_dominokit_domino_ui_infoboxes_InfoBox_Flip__java_lang_String__int__java_lang_String($name, $ordinal, flipStyle);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Flip(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} flipStyle
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_infoboxes_InfoBox_Flip__java_lang_String__int__java_lang_String($name, $ordinal, flipStyle) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_ = flipStyle;
  }
  
  /**
   * @param {string} name
   * @return {!Flip}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Flip.$clinit();
    if ($Equality.$same(Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_, null)) {
      Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_ = $Enums.createMapFromValues(Flip.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
  }
  
  /**
   * @return {!Array<!Flip>}
   * @public
   */
  static m_values__() {
    Flip.$clinit();
    return /**@type {!Array<Flip>} */ ($Arrays.$init([Flip.$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip, Flip.$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip], Flip));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Flip} */ ($Casts.$to(arg0, Flip)));
  }
  
  /**
   * @return {!Flip}
   * @public
   */
  static get f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip() {
    return (Flip.$clinit(), Flip.$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip);
  }
  
  /**
   * @param {!Flip} value
   * @return {void}
   * @public
   */
  static set f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip(value) {
    (Flip.$clinit(), Flip.$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip = value);
  }
  
  /**
   * @return {!Flip}
   * @public
   */
  static get f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip() {
    return (Flip.$clinit(), Flip.$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip);
  }
  
  /**
   * @param {!Flip} value
   * @return {void}
   * @public
   */
  static set f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip(value) {
    (Flip.$clinit(), Flip.$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip = value);
  }
  
  /**
   * @return {Map<?string, !Flip>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_() {
    return (Flip.$clinit(), Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
  }
  
  /**
   * @param {Map<?string, !Flip>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_(value) {
    (Flip.$clinit(), Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Flip;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Flip);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Flip.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Flip.$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip = Flip.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("RIGHT"), Flip.$ordinal$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip, "info-box-3");
    Flip.$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip = Flip.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("LEFT"), Flip.$ordinal$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip, "info-box");
    Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Flip, $Util.$makeClassName('org.dominokit.domino.ui.infoboxes.InfoBox$Flip'));


/** @private {!Flip} */
Flip.$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;


/** @private {!Flip} */
Flip.$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;


/** @private {Map<?string, !Flip>} */
Flip.$f_namesToValuesMap__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_;


/** @public {number} @const */
Flip.$ordinal$f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip = 0;


/** @public {number} @const */
Flip.$ordinal$f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip = 1;




exports = Flip; 
//# sourceMappingURL=InfoBox$Flip.js.map