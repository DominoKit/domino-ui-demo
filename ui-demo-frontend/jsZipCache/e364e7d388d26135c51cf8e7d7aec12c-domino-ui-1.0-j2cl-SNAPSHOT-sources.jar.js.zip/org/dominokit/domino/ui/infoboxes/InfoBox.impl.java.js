/**
 * @fileoverview transpiled from org.dominokit.domino.ui.infoboxes.InfoBox.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.infoboxes.InfoBox$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Flip = goog.forwardDeclare('org.dominokit.domino.ui.infoboxes.InfoBox.Flip$impl');
let HoverEffect = goog.forwardDeclare('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasBackground<InfoBox>}
  */
class InfoBox extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {HTMLDivElement} */
    this.f_titleElement__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {HTMLDivElement} */
    this.f_valueElement__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {Icon} */
    this.f_icon__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {Color} */
    this.f_counterBackground__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {Color} */
    this.f_iconBackground__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {HoverEffect} */
    this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {Flip} */
    this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_;
    /** @public {Color} */
    this.f_iconColor__org_dominokit_domino_ui_infoboxes_InfoBox_;
  }
  
  /**
   * Factory method corresponding to constructor 'InfoBox()'.
   * @return {!InfoBox}
   * @public
   */
  static $create__() {
    InfoBox.$clinit();
    let $instance = new InfoBox();
    $instance.$ctor__org_dominokit_domino_ui_infoboxes_InfoBox__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InfoBox()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_infoboxes_InfoBox__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_infoboxes_InfoBox();
  }
  
  /**
   * @param {Icon} icon
   * @param {?string} title
   * @param {?string} value
   * @return {InfoBox}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_Icon__java_lang_String__java_lang_String(icon, title, value) {
    InfoBox.$clinit();
    let infoBox = InfoBox.$create__();
    infoBox.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_.appendChild(icon.m_asElement__());
    infoBox.f_titleElement__org_dominokit_domino_ui_infoboxes_InfoBox_.textContent = title;
    infoBox.f_valueElement__org_dominokit_domino_ui_infoboxes_InfoBox_.textContent = value;
    infoBox.f_icon__org_dominokit_domino_ui_infoboxes_InfoBox_ = icon;
    return infoBox;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {InfoBox}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_counterBackground__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.m_asElement__().classList.remove(this.f_counterBackground__org_dominokit_domino_ui_infoboxes_InfoBox_.m_getBackground__());
    }
    this.m_asElement__().classList.add(background.m_getBackground__());
    this.f_counterBackground__org_dominokit_domino_ui_infoboxes_InfoBox_ = background;
    return this;
  }
  
  /**
   * @param {Color} background
   * @return {InfoBox}
   * @public
   */
  m_setIconBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_iconBackground__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_.classList.remove(this.f_iconBackground__org_dominokit_domino_ui_infoboxes_InfoBox_.m_getBackground__());
    }
    this.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_.classList.add(background.m_getBackground__());
    this.f_iconBackground__org_dominokit_domino_ui_infoboxes_InfoBox_ = background;
    return this;
  }
  
  /**
   * @param {HoverEffect} effect
   * @return {InfoBox}
   * @public
   */
  m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(effect) {
    if (Objects.m_nonNull__java_lang_Object(this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.m_asElement__().classList.remove(this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_.f_effectStyle__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_);
    }
    this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_ = effect;
    this.m_asElement__().classList.add(this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_.f_effectStyle__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_);
    return this;
  }
  
  /**
   * @return {InfoBox}
   * @public
   */
  m_removeHoverEffect__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.m_asElement__().classList.remove(this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_.f_effectStyle__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect_);
      this.f_hoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_ = null;
    }
    return this;
  }
  
  /**
   * @return {InfoBox}
   * @public
   */
  m_flipLeft__() {
    this.m_asElement__().classList.remove(this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
    this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_ = Flip.f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;
    this.m_asElement__().classList.add(this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
    return this;
  }
  
  /**
   * @return {InfoBox}
   * @public
   */
  m_flipRight__() {
    this.m_asElement__().classList.remove(this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
    this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_ = Flip.f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;
    this.m_asElement__().classList.add(this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
    return this;
  }
  
  /**
   * @return {InfoBox}
   * @public
   */
  m_flip__() {
    this.m_asElement__().classList.remove(this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(Flip.f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip, this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_ = Flip.f_RIGHT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;
    } else {
      this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_ = Flip.f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;
    }
    this.m_asElement__().classList.add(this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_.f_flipStyle__org_dominokit_domino_ui_infoboxes_InfoBox_Flip_);
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {InfoBox}
   * @public
   */
  m_setIconColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_iconColor__org_dominokit_domino_ui_infoboxes_InfoBox_) && Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.f_icon__org_dominokit_domino_ui_infoboxes_InfoBox_.m_asElement__().classList.remove(this.f_iconColor__org_dominokit_domino_ui_infoboxes_InfoBox_.m_getStyle__());
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_infoboxes_InfoBox_)) {
      this.f_iconColor__org_dominokit_domino_ui_infoboxes_InfoBox_ = color;
      this.f_icon__org_dominokit_domino_ui_infoboxes_InfoBox_.m_asElement__().classList.add(this.f_iconColor__org_dominokit_domino_ui_infoboxes_InfoBox_.m_getStyle__());
    }
    return this;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getIconElement__() {
    return this.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getTitleElement__() {
    return this.f_titleElement__org_dominokit_domino_ui_infoboxes_InfoBox_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getValueElement__() {
    return this.f_valueElement__org_dominokit_domino_ui_infoboxes_InfoBox_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_infoboxes_InfoBox_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_infoboxes_InfoBox() {
    this.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["icon"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_titleElement__org_dominokit_domino_ui_infoboxes_InfoBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["text"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_valueElement__org_dominokit_domino_ui_infoboxes_InfoBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["number", "count-to"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_element__org_dominokit_domino_ui_infoboxes_InfoBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["info-box"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_iconElement__org_dominokit_domino_ui_infoboxes_InfoBox_), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["content"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_titleElement__org_dominokit_domino_ui_infoboxes_InfoBox_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_valueElement__org_dominokit_domino_ui_infoboxes_InfoBox_), IsElement))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_flip__org_dominokit_domino_ui_infoboxes_InfoBox_ = Flip.f_LEFT__org_dominokit_domino_ui_infoboxes_InfoBox_Flip;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InfoBox;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InfoBox);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InfoBox.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Flip = goog.module.get('org.dominokit.domino.ui.infoboxes.InfoBox.Flip$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InfoBox, $Util.$makeClassName('org.dominokit.domino.ui.infoboxes.InfoBox'));


IsElement.$markImplementor(InfoBox);
HasBackground.$markImplementor(InfoBox);


exports = InfoBox; 
//# sourceMappingURL=InfoBox.js.map