/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.ActionIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.ActionIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class ActionIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m__3d_rotation__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_accessibility__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_accessible__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_account_balance__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_account_balance_wallet__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_account_box__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_account_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_shopping_cart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_alarm__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_alarm_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_alarm_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_alarm_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_all_out__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_android__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_announcement__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_aspect_ratio__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assessment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assignment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assignment_ind__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assignment_late__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assignment_return__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assignment_returned__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assignment_turned_in__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_autorenew__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_backup__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_book__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bookmark__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bookmark_border__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bug_report__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_build__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cached__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_camera_enhance__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_card_giftcard__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_card_membership__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_card_travel__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_change_history__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_check_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_chrome_reader_mode__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_classs__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_code__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_compare_arrows__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_copyright__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_credit_card__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dashboard__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_date_range__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_delete__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_delete_forever__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_description__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dns__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_done__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_done_all__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_donut_large__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_donut_small__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_eject__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_euro_symbol__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_event__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_event_seat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exit_to_app__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_explore__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_extension__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_face__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_favorite__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_favorite_border__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_feedback__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_find_in_page__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_find_replace__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fingerprint__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flight_land__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flight_takeoff__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flip_to_back__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flip_to_front__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_g_translate__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gavel__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_get_app__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gif__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_grade__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_group_work__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_help__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_help_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_highlight_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_history__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_home__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hourglass_empty__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hourglass_full__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_http__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_https__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_important_devices__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_info__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_info_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_input__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_invert_colors__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_label__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_label_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_language__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_launch__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_lightbulb_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_line_style__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_line_weight__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_list__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_lock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_lock_open__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_lock_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_loyalty__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_markunread_mailbox__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_motorcycle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_note_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_offline_pin__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_opacity__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_open_in_browser__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_open_in_new__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_open_with__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pageview__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pan_tool__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_payment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_camera_mic__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_contact_calendar__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_data_setting__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_device_information__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_identity__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_media__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_phone_msg__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_perm_scan_wifi__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pets__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_picture_in_picture__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_picture_in_picture_alt__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_play_for_work__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_polymer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_power_settings_new__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pregnant_woman__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_print__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_query_builder__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_question_answer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_receipt__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_record_voice_over__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_redeem__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_remove_shopping_cart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_reorder__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_report_problem__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_restore__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_restore_page__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_room__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rounded_corner__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rowing__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_schedule__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_search__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_applications__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_backup_restore__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_bluetooth__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_brightness__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_cell__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_ethernet__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_input_antenna__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_input_component__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_input_composite__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_input_hdmi__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_input_svideo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_overscan__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_phone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_power__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_remote__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_voice__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_shop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_shop_two__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_shopping_basket__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_shopping_cart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_speaker_notes__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_speaker_notes_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_spellcheck__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_star_rate__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stars__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_store__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_subject__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_supervisor_account__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_swap_horiz__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_swap_vert__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_swap_vertical_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_system_update_alt__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tab__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tab_unselected__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_theaters__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_thumb_down__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_thumb_up__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_thumbs_up_down__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_timeline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_toc__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_today__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_toll__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_touch_app__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_track_changes__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_translate__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_trending_down__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_trending_flat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_trending_up__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_turned_in__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_turned_in_not__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_update__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_verified_user__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_agenda__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_array__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_carousel__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_column__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_day__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_headline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_list__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_module__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_quilt__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_stream__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_week__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_visibility__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_visibility_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_watch_later__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_work__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_youtube_searched_for__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_zoom_in__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_zoom_out__() {
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m__3d_rotation__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("3d_rotation");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_accessibility__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("accessibility");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_accessible__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("accessible");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_account_balance__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("account_balance");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_account_balance_wallet__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("account_balance_wallet");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_account_box__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("account_box");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_account_circle__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("account_circle");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_shopping_cart__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("add_shopping_cart");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_alarm__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("alarm");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_alarm_add__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("alarm_add");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_alarm_off__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("alarm_off");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_alarm_on__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("alarm_on");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_all_out__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("all_out");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_android__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("android");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_announcement__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("announcement");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_aspect_ratio__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("aspect_ratio");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assessment__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assessment");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assignment__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assignment");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assignment_ind__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assignment_ind");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assignment_late__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assignment_late");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assignment_return__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assignment_return");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assignment_returned__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assignment_returned");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assignment_turned_in__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("assignment_turned_in");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_autorenew__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("autorenew");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_backup__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("backup");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_book__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("book");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bookmark__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("bookmark");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bookmark_border__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("bookmark_border");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bug_report__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("bug_report");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_build__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("build");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cached__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("cached");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_camera_enhance__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("camera_enhance");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_card_giftcard__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("card_giftcard");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_card_membership__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("card_membership");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_card_travel__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("card_travel");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_change_history__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("change_history");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_check_circle__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("check_circle");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_chrome_reader_mode__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("chrome_reader_mode");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_classs__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("class");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_code__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("code");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_compare_arrows__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("compare_arrows");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_copyright__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("copyright");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_credit_card__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("credit_card");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dashboard__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("dashboard");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_date_range__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("date_range");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_delete__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("delete");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_delete_forever__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("delete_forever");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_description__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("description");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dns__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("dns");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_done__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("done");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_done_all__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("done_all");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_donut_large__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("donut_large");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_donut_small__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("donut_small");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_eject__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("eject");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_euro_symbol__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("euro_symbol");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_event__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("event");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_event_seat__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("event_seat");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exit_to_app__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("exit_to_app");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_explore__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("explore");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_extension__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("extension");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_face__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("face");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_favorite__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("favorite");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_favorite_border__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("favorite_border");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_feedback__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("feedback");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_find_in_page__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("find_in_page");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_find_replace__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("find_replace");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fingerprint__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("fingerprint");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flight_land__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("flight_land");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flight_takeoff__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("flight_takeoff");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flip_to_back__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("flip_to_back");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flip_to_front__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("flip_to_front");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_g_translate__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("g_translate");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gavel__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("gavel");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_get_app__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("get_app");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gif__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("gif");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_grade__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("grade");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_group_work__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("group_work");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_help__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("help");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_help_outline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("help_outline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_highlight_off__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("highlight_off");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_history__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("history");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_home__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("home");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hourglass_empty__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("hourglass_empty");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hourglass_full__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("hourglass_full");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_http__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("http");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_https__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("https");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_important_devices__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("important_devices");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_info__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("info");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_info_outline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("info_outline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_input__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("input");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_invert_colors__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("invert_colors");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_label__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("label");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_label_outline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("label_outline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_language__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("language");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_launch__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("launch");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_lightbulb_outline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("lightbulb_outline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_line_style__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("line_style");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_line_weight__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("line_weight");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_list__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("list");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_lock__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("lock");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_lock_open__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("lock_open");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_lock_outline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("lock_outline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_loyalty__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("loyalty");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_markunread_mailbox__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("markunread_mailbox");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_motorcycle__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("motorcycle");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_note_add__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("note_add");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_offline_pin__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("offline_pin");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_opacity__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("opacity");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_open_in_browser__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("open_in_browser");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_open_in_new__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("open_in_new");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_open_with__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("open_with");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pageview__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("pageview");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pan_tool__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("pan_tool");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_payment__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("payment");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_camera_mic__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_camera_mic");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_contact_calendar__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_contact_calendar");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_data_setting__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_data_setting");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_device_information__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_device_information");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_identity__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_identity");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_media__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_media");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_phone_msg__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_phone_msg");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_perm_scan_wifi__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("perm_scan_wifi");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pets__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("pets");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_picture_in_picture__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("picture_in_picture");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_picture_in_picture_alt__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("picture_in_picture_alt");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_play_for_work__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("play_for_work");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_polymer__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("polymer");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_power_settings_new__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("power_settings_new");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pregnant_woman__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("pregnant_woman");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_print__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("print");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_query_builder__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("query_builder");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_question_answer__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("question_answer");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_receipt__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("receipt");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_record_voice_over__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("record_voice_over");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_redeem__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("redeem");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_remove_shopping_cart__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("remove_shopping_cart");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_reorder__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("reorder");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_report_problem__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("report_problem");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_restore__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("restore");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_restore_page__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("restore_page");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_room__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("room");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rounded_corner__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("rounded_corner");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rowing__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("rowing");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_schedule__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("schedule");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_search__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("search");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_applications__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_applications");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_backup_restore__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_backup_restore");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_bluetooth__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_bluetooth");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_brightness__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_brightness");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_cell__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_cell");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_ethernet__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_ethernet");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_input_antenna__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_input_antenna");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_input_component__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_input_component");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_input_composite__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_input_composite");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_input_hdmi__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_input_hdmi");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_input_svideo__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_input_svideo");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_overscan__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_overscan");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_phone__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_phone");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_power__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_power");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_remote__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_remote");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_voice__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_voice");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_shop__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("shop");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_shop_two__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("shop_two");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_shopping_basket__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("shopping_basket");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_shopping_cart__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("shopping_cart");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_speaker_notes__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("speaker_notes");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_speaker_notes_off__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("speaker_notes_off");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_spellcheck__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("spellcheck");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_star_rate__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("star_rate");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stars__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("stars");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_store__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("store");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_subject__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("subject");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_supervisor_account__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("supervisor_account");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_swap_horiz__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("swap_horiz");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_swap_vert__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("swap_vert");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_swap_vertical_circle__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("swap_vertical_circle");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_system_update_alt__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("system_update_alt");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tab__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("tab");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tab_unselected__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("tab_unselected");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_theaters__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("theaters");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_thumb_down__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("thumb_down");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_thumb_up__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("thumb_up");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_thumbs_up_down__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("thumbs_up_down");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_timeline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("timeline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_toc__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("toc");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_today__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("today");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_toll__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("toll");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_touch_app__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("touch_app");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_track_changes__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("track_changes");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_translate__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("translate");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_trending_down__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("trending_down");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_trending_flat__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("trending_flat");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_trending_up__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("trending_up");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_turned_in__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("turned_in");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_turned_in_not__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("turned_in_not");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_update__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("update");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_verified_user__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("verified_user");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_agenda__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_agenda");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_array__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_array");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_carousel__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_carousel");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_column__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_column");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_day__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_day");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_headline__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_headline");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_list__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_list");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_module__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_module");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_quilt__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_quilt");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_stream__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_stream");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_week__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("view_week");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_visibility__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("visibility");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_visibility_off__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("visibility_off");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_watch_later__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("watch_later");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_work__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("work");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_youtube_searched_for__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("youtube_searched_for");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_zoom_in__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("zoom_in");
  }
  
  /**
   * @param {ActionIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_zoom_out__$default__org_dominokit_domino_ui_icons_ActionIcons($thisArg) {
    ActionIcons.$clinit();
    return Icon.m_create__java_lang_String("zoom_out");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ActionIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_ActionIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ActionIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ActionIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ActionIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.ActionIcons'));


ActionIcons.$markImplementor(/** @type {Function} */ (ActionIcons));


exports = ActionIcons; 
//# sourceMappingURL=ActionIcons.js.map