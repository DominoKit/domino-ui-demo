/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.PlacesIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.PlacesIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class PlacesIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_ac_unit__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airport_shuttle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_all_inclusive__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_beach_access__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_business_center__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_casino__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_child_care__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_child_friendly__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fitness_center__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_free_breakfast__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_golf_course__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hot_tub__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_kitchen__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pool__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_room_service__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rv_hookup__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_smoke_free__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_smoking_rooms__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_spa__() {
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_ac_unit__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("ac_unit");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airport_shuttle__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("airport_shuttle");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_all_inclusive__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("all_inclusive");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_beach_access__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("beach_access");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_business_center__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("business_center");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_casino__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("casino");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_child_care__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("child_care");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_child_friendly__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("child_friendly");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fitness_center__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("fitness_center");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_free_breakfast__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("free_breakfast");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_golf_course__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("golf_course");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hot_tub__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("hot_tub");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_kitchen__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("kitchen");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pool__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("pool");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_room_service__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("room_service");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rv_hookup__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("rv_hookup");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_smoke_free__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("smoke_free");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_smoking_rooms__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("smoking_rooms");
  }
  
  /**
   * @param {PlacesIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_spa__$default__org_dominokit_domino_ui_icons_PlacesIcons($thisArg) {
    PlacesIcons.$clinit();
    return Icon.m_create__java_lang_String("spa");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_PlacesIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_PlacesIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_PlacesIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PlacesIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(PlacesIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.PlacesIcons'));


PlacesIcons.$markImplementor(/** @type {Function} */ (PlacesIcons));


exports = PlacesIcons; 
//# sourceMappingURL=PlacesIcons.js.map