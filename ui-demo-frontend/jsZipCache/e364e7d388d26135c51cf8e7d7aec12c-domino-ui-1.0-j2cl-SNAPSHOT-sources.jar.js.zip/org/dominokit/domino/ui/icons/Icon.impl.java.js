/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.Icon.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.Icon$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class Icon extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_icon__org_dominokit_domino_ui_icons_Icon_;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_ui_icons_Icon_;
    /** @public {?string} */
    this.f_colorStyle__org_dominokit_domino_ui_icons_Icon_;
  }
  
  /**
   * Factory method corresponding to constructor 'Icon(HTMLElement)'.
   * @param {HTMLElement} icon
   * @return {!Icon}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(icon) {
    Icon.$clinit();
    let $instance = new Icon();
    $instance.$ctor__org_dominokit_domino_ui_icons_Icon__elemental2_dom_HTMLElement(icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Icon(HTMLElement)'.
   * @param {HTMLElement} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_icons_Icon__elemental2_dom_HTMLElement(icon) {
    this.$ctor__java_lang_Object__();
    this.f_icon__org_dominokit_domino_ui_icons_Icon_ = icon;
  }
  
  /**
   * @param {?string} icon
   * @return {Icon}
   * @public
   */
  static m_create__java_lang_String(icon) {
    Icon.$clinit();
    let iconElement = Icon.$create__elemental2_dom_HTMLElement(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["material-icons"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(icon), HtmlContentBuilder)).m_asElement__());
    iconElement.f_name__org_dominokit_domino_ui_icons_Icon_ = icon;
    return iconElement;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_ui_icons_Icon_;
  }
  
  /**
   * @param {Color} color
   * @return {Icon}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_colorStyle__org_dominokit_domino_ui_icons_Icon_)) {
      this.f_icon__org_dominokit_domino_ui_icons_Icon_.classList.remove(this.f_colorStyle__org_dominokit_domino_ui_icons_Icon_);
    }
    this.f_icon__org_dominokit_domino_ui_icons_Icon_.classList.add(color.m_getStyle__());
    this.f_colorStyle__org_dominokit_domino_ui_icons_Icon_ = color.m_getStyle__();
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_icon__org_dominokit_domino_ui_icons_Icon_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Icon;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Icon);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Icon.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Icon, $Util.$makeClassName('org.dominokit.domino.ui.icons.Icon'));


IsElement.$markImplementor(Icon);


exports = Icon; 
//# sourceMappingURL=Icon.js.map