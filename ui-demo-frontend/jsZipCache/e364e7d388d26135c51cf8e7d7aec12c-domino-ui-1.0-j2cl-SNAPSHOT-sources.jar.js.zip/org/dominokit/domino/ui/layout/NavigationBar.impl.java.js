/**
 * @fileoverview transpiled from org.dominokit.domino.ui.layout.NavigationBar.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.layout.NavigationBar$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class NavigationBar extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLAnchorElement} */
    this.f_navBarExpand__org_dominokit_domino_ui_layout_NavigationBar_;
    /** @public {HTMLAnchorElement} */
    this.f_menu__org_dominokit_domino_ui_layout_NavigationBar_;
    /** @public {HTMLAnchorElement} */
    this.f_title__org_dominokit_domino_ui_layout_NavigationBar_;
    /** @public {HTMLUListElement} */
    this.f_topBar__org_dominokit_domino_ui_layout_NavigationBar_;
    /** @public {HTMLDivElement} */
    this.f_navigationBar__org_dominokit_domino_ui_layout_NavigationBar_;
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_layout_NavigationBar_;
    /** @public {boolean} */
    this.f_collapsed__org_dominokit_domino_ui_layout_NavigationBar_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'NavigationBar()'.
   * @return {!NavigationBar}
   * @public
   */
  static $create__() {
    NavigationBar.$clinit();
    let $instance = new NavigationBar();
    $instance.$ctor__org_dominokit_domino_ui_layout_NavigationBar__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NavigationBar()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_layout_NavigationBar__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_layout_NavigationBar();
  }
  
  /**
   * @return {NavigationBar}
   * @public
   */
  static m_create__() {
    NavigationBar.$clinit();
    return NavigationBar.$create__();
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isCollapsed__() {
    return this.f_collapsed__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @param {boolean} collapsed
   * @return {NavigationBar}
   * @public
   */
  m_setCollapsed__boolean(collapsed) {
    this.f_collapsed__org_dominokit_domino_ui_layout_NavigationBar_ = collapsed;
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getNavBarExpand__() {
    return this.f_navBarExpand__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getMenu__() {
    return this.f_menu__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getTitle__() {
    return this.f_title__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @return {HTMLUListElement}
   * @public
   */
  m_getTopBar__() {
    return this.f_topBar__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getNavigationBar__() {
    return this.f_navigationBar__org_dominokit_domino_ui_layout_NavigationBar_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_layout_NavigationBar() {
    this.f_navBarExpand__org_dominokit_domino_ui_layout_NavigationBar_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navbar-toggle", "collapsed"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("data-toggle", "collapse"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("data-target", "#navbar-collapse"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("aria-expanded", "false"), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_menu__org_dominokit_domino_ui_layout_NavigationBar_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bars"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_title__org_dominokit_domino_ui_layout_NavigationBar_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navbar-brand"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_topBar__org_dominokit_domino_ui_layout_NavigationBar_ = /**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["nav", "navbar-nav", "navbar-right"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLUListElement_$Overlay));
    this.f_navigationBar__org_dominokit_domino_ui_layout_NavigationBar_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["collapse", "navbar-collapse"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("id", "navbar-collapse"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_topBar__org_dominokit_domino_ui_layout_NavigationBar_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_element__org_dominokit_domino_ui_layout_NavigationBar_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_nav__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navbar", "bars"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["container-fluid"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navbar-header"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_navBarExpand__org_dominokit_domino_ui_layout_NavigationBar_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_menu__org_dominokit_domino_ui_layout_NavigationBar_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_title__org_dominokit_domino_ui_layout_NavigationBar_), IsElement))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_navigationBar__org_dominokit_domino_ui_layout_NavigationBar_), IsElement))), HtmlContentBuilder)).m_asElement__();
    this.f_collapsed__org_dominokit_domino_ui_layout_NavigationBar_ = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NavigationBar;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NavigationBar);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NavigationBar.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NavigationBar, $Util.$makeClassName('org.dominokit.domino.ui.layout.NavigationBar'));


IsElement.$markImplementor(NavigationBar);


exports = NavigationBar; 
//# sourceMappingURL=NavigationBar.js.map