/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListGroupStyle.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.ListGroupStyle$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<ListGroupStyle>}
  */
class ListGroupStyle extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_lists_ListGroupStyle_;
  }
  
  /**
   * Factory method corresponding to constructor 'ListGroupStyle(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!ListGroupStyle}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new ListGroupStyle();
    $instance.$ctor__org_dominokit_domino_ui_lists_ListGroupStyle__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListGroupStyle(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_ListGroupStyle__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_lists_ListGroupStyle_ = style;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_lists_ListGroupStyle_;
  }
  
  /**
   * @param {string} name
   * @return {!ListGroupStyle}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    ListGroupStyle.$clinit();
    if ($Equality.$same(ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_, null)) {
      ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_ = $Enums.createMapFromValues(ListGroupStyle.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_);
  }
  
  /**
   * @return {!Array<!ListGroupStyle>}
   * @public
   */
  static m_values__() {
    ListGroupStyle.$clinit();
    return /**@type {!Array<ListGroupStyle>} */ ($Arrays.$init([ListGroupStyle.$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle, ListGroupStyle.$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle, ListGroupStyle.$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle, ListGroupStyle.$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle], ListGroupStyle));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {ListGroupStyle} */ ($Casts.$to(arg0, ListGroupStyle)));
  }
  
  /**
   * @return {!ListGroupStyle}
   * @public
   */
  static get f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle() {
    return (ListGroupStyle.$clinit(), ListGroupStyle.$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle);
  }
  
  /**
   * @param {!ListGroupStyle} value
   * @return {void}
   * @public
   */
  static set f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle(value) {
    (ListGroupStyle.$clinit(), ListGroupStyle.$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle = value);
  }
  
  /**
   * @return {!ListGroupStyle}
   * @public
   */
  static get f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle() {
    return (ListGroupStyle.$clinit(), ListGroupStyle.$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle);
  }
  
  /**
   * @param {!ListGroupStyle} value
   * @return {void}
   * @public
   */
  static set f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle(value) {
    (ListGroupStyle.$clinit(), ListGroupStyle.$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle = value);
  }
  
  /**
   * @return {!ListGroupStyle}
   * @public
   */
  static get f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle() {
    return (ListGroupStyle.$clinit(), ListGroupStyle.$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle);
  }
  
  /**
   * @param {!ListGroupStyle} value
   * @return {void}
   * @public
   */
  static set f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle(value) {
    (ListGroupStyle.$clinit(), ListGroupStyle.$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle = value);
  }
  
  /**
   * @return {!ListGroupStyle}
   * @public
   */
  static get f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle() {
    return (ListGroupStyle.$clinit(), ListGroupStyle.$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle);
  }
  
  /**
   * @param {!ListGroupStyle} value
   * @return {void}
   * @public
   */
  static set f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle(value) {
    (ListGroupStyle.$clinit(), ListGroupStyle.$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle = value);
  }
  
  /**
   * @return {Map<?string, !ListGroupStyle>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_() {
    return (ListGroupStyle.$clinit(), ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_);
  }
  
  /**
   * @param {Map<?string, !ListGroupStyle>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_(value) {
    (ListGroupStyle.$clinit(), ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListGroupStyle;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListGroupStyle);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListGroupStyle.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    ListGroupStyle.$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle = ListGroupStyle.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("SUCCESS"), ListGroupStyle.$ordinal$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle, "list-group-item-success");
    ListGroupStyle.$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle = ListGroupStyle.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("WARNING"), ListGroupStyle.$ordinal$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle, "list-group-item-warning");
    ListGroupStyle.$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle = ListGroupStyle.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("INFO"), ListGroupStyle.$ordinal$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle, "list-group-item-info");
    ListGroupStyle.$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle = ListGroupStyle.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ERROR"), ListGroupStyle.$ordinal$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle, "list-group-item-danger");
    ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(ListGroupStyle, $Util.$makeClassName('org.dominokit.domino.ui.lists.ListGroupStyle'));


/** @private {!ListGroupStyle} */
ListGroupStyle.$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle;


/** @private {!ListGroupStyle} */
ListGroupStyle.$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle;


/** @private {!ListGroupStyle} */
ListGroupStyle.$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle;


/** @private {!ListGroupStyle} */
ListGroupStyle.$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle;


/** @private {Map<?string, !ListGroupStyle>} */
ListGroupStyle.$f_namesToValuesMap__org_dominokit_domino_ui_lists_ListGroupStyle_;


/** @public {number} @const */
ListGroupStyle.$ordinal$f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle = 0;


/** @public {number} @const */
ListGroupStyle.$ordinal$f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle = 1;


/** @public {number} @const */
ListGroupStyle.$ordinal$f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle = 2;


/** @public {number} @const */
ListGroupStyle.$ordinal$f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle = 3;




exports = ListGroupStyle; 
//# sourceMappingURL=ListGroupStyle.js.map