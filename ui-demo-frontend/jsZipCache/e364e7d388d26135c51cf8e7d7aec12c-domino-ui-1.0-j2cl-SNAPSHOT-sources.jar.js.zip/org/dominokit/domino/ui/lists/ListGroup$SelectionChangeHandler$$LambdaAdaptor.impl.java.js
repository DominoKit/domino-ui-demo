/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListGroup$SelectionChangeHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SelectionChangeHandler = goog.require('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler$impl');

let ListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListItem$impl');


/**
 * @template C_SelectionChangeHandler_T
 * @implements {SelectionChangeHandler<C_SelectionChangeHandler_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ListItem<C_SelectionChangeHandler_T>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(ListItem<C_SelectionChangeHandler_T>):void} */
    this.f_$$fn__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$LambdaAdaptor__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ListItem<C_SelectionChangeHandler_T>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$LambdaAdaptor__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {ListItem<C_SelectionChangeHandler_T>} arg0
   * @return {void}
   * @public
   */
  m_onSelectionChanged__org_dominokit_domino_ui_lists_ListItem(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.lists.ListGroup$SelectionChangeHandler$$LambdaAdaptor'));


SelectionChangeHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ListGroup$SelectionChangeHandler$$LambdaAdaptor.js.map