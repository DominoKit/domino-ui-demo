/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.SimpleListItem.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.lists.SimpleListItem');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseListItem = goog.require('org.dominokit.domino.ui.lists.BaseListItem');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _IsHtmlComponent = goog.require('org.dominokit.domino.ui.utils.IsHtmlComponent');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _ListGroupStyle = goog.require('org.dominokit.domino.ui.lists.ListGroupStyle');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _HtmlComponentBuilder = goog.require('org.dominokit.domino.ui.utils.HtmlComponentBuilder');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SimpleListItem = goog.require('org.dominokit.domino.ui.lists.SimpleListItem$impl');
exports = SimpleListItem;
 