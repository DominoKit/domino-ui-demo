/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListItem.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.lists.ListItem');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseListItem = goog.require('org.dominokit.domino.ui.lists.BaseListItem');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _HTMLParagraphElement_$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _ListGroupStyle = goog.require('org.dominokit.domino.ui.lists.ListGroupStyle');
const _$LambdaAdaptor$39 = goog.require('org.dominokit.domino.ui.lists.ListItem.$LambdaAdaptor$39');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _HasMultiSelectSupport = goog.require('org.dominokit.domino.ui.utils.HasMultiSelectSupport');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.Selectable.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ListItem = goog.require('org.dominokit.domino.ui.lists.ListItem$impl');
exports = ListItem;
 