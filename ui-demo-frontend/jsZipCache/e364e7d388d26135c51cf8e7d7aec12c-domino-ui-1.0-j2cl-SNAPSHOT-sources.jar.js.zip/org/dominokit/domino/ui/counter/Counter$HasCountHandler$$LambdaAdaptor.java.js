/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasCountHandler$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasCountHandler.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasCountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler');
const _Counter = goog.require('org.dominokit.domino.ui.counter.Counter');
const _CountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.CountHandler');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 