/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable$impl');

let JsDate_$Overlay = goog.forwardDeclare('elemental2.core.JsDate.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement.$LambdaAdaptor$16$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler$impl');
let Selectable_SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Selectable.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @implements {Selectable<DatePickerElement>}
  */
class DatePickerElement extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_;
    /** @public {number} */
    this.f_day__org_dominokit_domino_ui_datepicker_DatePickerElement_ = 0;
    /** @public {number} */
    this.f_month__org_dominokit_domino_ui_datepicker_DatePickerElement_ = 0;
    /** @public {number} */
    this.f_weekDay__org_dominokit_domino_ui_datepicker_DatePickerElement_ = 0;
    /** @public {number} */
    this.f_year__org_dominokit_domino_ui_datepicker_DatePickerElement_ = 0;
    /** @public {?string} */
    this.f_text__org_dominokit_domino_ui_datepicker_DatePickerElement_;
    /** @public {boolean} */
    this.f_selected__org_dominokit_domino_ui_datepicker_DatePickerElement_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'DatePickerElement(HTMLElement)'.
   * @param {HTMLElement} element
   * @return {!DatePickerElement}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(element) {
    DatePickerElement.$clinit();
    let $instance = new DatePickerElement();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePickerElement__elemental2_dom_HTMLElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePickerElement(HTMLElement)'.
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePickerElement__elemental2_dom_HTMLElement(element) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePickerElement();
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_ = element;
  }
  
  /**
   * @param {number} index
   * @param {Array<Array<DatePickerElement>>} monthData
   * @return {DatePickerElement}
   * @public
   */
  static m_createDayHeader__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement(index, monthData) {
    DatePickerElement.$clinit();
    let element = Elements.m_th__().m_asElement__();
    let day = DatePickerElement.$create__elemental2_dom_HTMLElement(element);
    day.m_setDay__int(-1);
    day.m_setMonth__int(-1);
    day.m_setYear__int(-1);
    day.m_setWeekDay__int(-1);
    day.m_setText__java_lang_String("");
    $Arrays.$set(monthData[0], index, day);
    return day;
  }
  
  /**
   * @param {number} indexX
   * @param {number} indexY
   * @param {Array<Array<DatePickerElement>>} monthData
   * @param {SelectionHandler} selectionHandler
   * @return {DatePickerElement}
   * @public
   */
  static m_createDayElement__int__int__arrayOf_arrayOf_org_dominokit_domino_ui_datepicker_DatePickerElement__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler(indexX, indexY, monthData, selectionHandler) {
    DatePickerElement.$clinit();
    let element = Elements.m_div__().m_asElement__();
    let day = DatePickerElement.$create__elemental2_dom_HTMLElement(element);
    day.m_setDay__int(-1);
    day.m_setMonth__int(-1);
    day.m_setYear__int(-1);
    day.m_setWeekDay__int(-1);
    day.m_setText__java_lang_String("");
    $Arrays.$set(monthData[indexX], indexY, day);
    element.addEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$16(((/** Event */ evt) =>{
      selectionHandler.m_selectElement__org_dominokit_domino_ui_datepicker_DatePickerElement(day);
    })));
    return day;
  }
  
  /**
   * @param {?string} text
   * @return {void}
   * @public
   */
  m_setText__java_lang_String(text) {
    this.f_text__org_dominokit_domino_ui_datepicker_DatePickerElement_ = text;
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_.textContent = text;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_setElement__elemental2_dom_HTMLElement(element) {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_ = element;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getDay__() {
    return this.f_day__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @param {number} day
   * @return {void}
   * @public
   */
  m_setDay__int(day) {
    this.f_day__org_dominokit_domino_ui_datepicker_DatePickerElement_ = day;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getMonth__() {
    return this.f_month__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @param {number} month
   * @return {void}
   * @public
   */
  m_setMonth__int(month) {
    this.f_month__org_dominokit_domino_ui_datepicker_DatePickerElement_ = month;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getWeekDay__() {
    return this.f_weekDay__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @param {number} weekDay
   * @return {void}
   * @public
   */
  m_setWeekDay__int(weekDay) {
    this.f_weekDay__org_dominokit_domino_ui_datepicker_DatePickerElement_ = weekDay;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getYear__() {
    return this.f_year__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @param {number} year
   * @return {void}
   * @public
   */
  m_setYear__int(year) {
    this.f_year__org_dominokit_domino_ui_datepicker_DatePickerElement_ = year;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getText__() {
    return this.f_text__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @override
   * @return {DatePickerElement}
   * @public
   */
  m_select__() {
    return this.m_select__boolean(true);
  }
  
  /**
   * @override
   * @return {DatePickerElement}
   * @public
   */
  m_deselect__() {
    return this.m_deselect__boolean(true);
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {DatePickerElement}
   * @public
   */
  m_select__boolean(silent) {
    this.f_selected__org_dominokit_domino_ui_datepicker_DatePickerElement_ = true;
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_.classList.add("selected");
    return this;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {DatePickerElement}
   * @public
   */
  m_deselect__boolean(silent) {
    this.f_selected__org_dominokit_domino_ui_datepicker_DatePickerElement_ = false;
    this.f_element__org_dominokit_domino_ui_datepicker_DatePickerElement_.classList.remove("selected");
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSelected__() {
    return this.f_selected__org_dominokit_domino_ui_datepicker_DatePickerElement_;
  }
  
  /**
   * @return {Date}
   * @public
   */
  m_getDate__() {
    return new Date(Integer.m_valueOf__int(this.f_year__org_dominokit_domino_ui_datepicker_DatePickerElement_), Integer.m_valueOf__int(this.f_month__org_dominokit_domino_ui_datepicker_DatePickerElement_), Integer.m_valueOf__int(this.f_day__org_dominokit_domino_ui_datepicker_DatePickerElement_));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {Selectable_SelectionHandler<DatePickerElement>} arg0
   * @return {void}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(arg0) {
    Selectable.m_addSelectionHandler__$default__org_dominokit_domino_ui_utils_Selectable__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(this, arg0);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datepicker_DatePickerElement() {
    this.f_selected__org_dominokit_domino_ui_datepicker_DatePickerElement_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePickerElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePickerElement);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePickerElement.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePickerElement.$LambdaAdaptor$16$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    j_l_Object.$clinit();
    Selectable.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePickerElement, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePickerElement'));


Selectable.$markImplementor(DatePickerElement);


exports = DatePickerElement; 
//# sourceMappingURL=DatePickerElement.js.map