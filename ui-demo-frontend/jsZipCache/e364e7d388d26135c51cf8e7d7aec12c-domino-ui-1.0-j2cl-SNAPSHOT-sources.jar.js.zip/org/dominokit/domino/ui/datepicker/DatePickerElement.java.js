/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable');
const _JsDate_$Overlay = goog.require('elemental2.core.JsDate.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement.$LambdaAdaptor$16');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler');
const _Selectable_SelectionHandler = goog.require('org.dominokit.domino.ui.utils.Selectable.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var DatePickerElement = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
exports = DatePickerElement;
 