/**
 * @fileoverview transpiled from org.dominokit.domino.ui.code.Code$Block.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.code.Code.Block$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLPreElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Code = goog.forwardDeclare('org.dominokit.domino.ui.code.Code$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLPreElement>}
  */
class Block extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLPreElement} */
    this.f_element__org_dominokit_domino_ui_code_Code_Block_;
  }
  
  /**
   * Factory method corresponding to constructor 'Block(HTMLPreElement)'.
   * @param {HTMLPreElement} element
   * @return {!Block}
   * @public
   */
  static $create__elemental2_dom_HTMLPreElement(element) {
    Block.$clinit();
    let $instance = new Block();
    $instance.$ctor__org_dominokit_domino_ui_code_Code_Block__elemental2_dom_HTMLPreElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Block(HTMLPreElement)'.
   * @param {HTMLPreElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_code_Code_Block__elemental2_dom_HTMLPreElement(element) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_dominokit_domino_ui_code_Code_Block_ = element;
  }
  
  /**
   * @param {?string} code
   * @return {Block}
   * @public
   */
  m_setCode__java_lang_String(code) {
    if (Objects.m_nonNull__java_lang_Object(this.f_element__org_dominokit_domino_ui_code_Code_Block_.firstChild)) {
      this.f_element__org_dominokit_domino_ui_code_Code_Block_.removeChild(this.f_element__org_dominokit_domino_ui_code_Code_Block_.firstChild);
    }
    this.f_element__org_dominokit_domino_ui_code_Code_Block_.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_code__().m_style__java_lang_String(Code.f_CODE_STYLE__org_dominokit_domino_ui_code_Code_), HtmlContentBuilder)).m_textContent__java_lang_String(code), HtmlContentBuilder)).m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLPreElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_code_Code_Block_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Block;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Block);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Block.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    Code = goog.module.get('org.dominokit.domino.ui.code.Code$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Block, $Util.$makeClassName('org.dominokit.domino.ui.code.Code$Block'));


IsElement.$markImplementor(Block);


exports = Block; 
//# sourceMappingURL=Code$Block.js.map