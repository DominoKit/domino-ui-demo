/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select$SelectElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Select.SelectElement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLSelectElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLSelectElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let SVGElement_$Overlay = goog.forwardDeclare('elemental2.svg.SVGElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let SVGUtil = goog.forwardDeclare('org.dominokit.domino.ui.timepicker.SVGUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class SelectElement extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_selectedValueContainer__org_dominokit_domino_ui_forms_Select_SelectElement_;
    /** @public {SVGElement} */
    this.f_caret__org_dominokit_domino_ui_forms_Select_SelectElement_;
    /** @public {HTMLButtonElement} */
    this.f_selectButton__org_dominokit_domino_ui_forms_Select_SelectElement_;
    /** @public {HTMLUListElement} */
    this.f_optionsList__org_dominokit_domino_ui_forms_Select_SelectElement_;
    /** @public {HTMLDivElement} */
    this.f_dropDownMenu__org_dominokit_domino_ui_forms_Select_SelectElement_;
    /** @public {HTMLSelectElement} */
    this.f_selectMenu__org_dominokit_domino_ui_forms_Select_SelectElement_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * Factory method corresponding to constructor 'SelectElement()'.
   * @return {!SelectElement}
   * @public
   */
  static $create__() {
    SelectElement.$clinit();
    let $instance = new SelectElement();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select_SelectElement__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectElement()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select_SelectElement__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_forms_Select_SelectElement();
  }
  
  /**
   * @return {SelectElement}
   * @public
   */
  static m_create__() {
    SelectElement.$clinit();
    return SelectElement.$create__();
  }
  
  /**
   * @return {HTMLButtonElement}
   * @public
   */
  m_getSelectButton__() {
    return this.f_selectButton__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getDropDownMenu__() {
    return this.f_dropDownMenu__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @return {HTMLUListElement}
   * @public
   */
  m_getOptionsList__() {
    return this.f_optionsList__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @return {HTMLSelectElement}
   * @public
   */
  m_getSelectMenu__() {
    return this.f_selectMenu__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getSelectedValueContainer__() {
    return this.f_selectedValueContainer__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_Select_SelectElement() {
    this.f_selectedValueContainer__org_dominokit_domino_ui_forms_Select_SelectElement_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["filter-option", "pull-left"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_caret__org_dominokit_domino_ui_forms_Select_SelectElement_ = SVGUtil.m_createSelectCaret__();
    this.f_selectButton__org_dominokit_domino_ui_forms_Select_SelectElement_ = /**@type {HTMLButtonElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(Elements.m_button__().m_attr__java_lang_String__java_lang_String("type", "button"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("data-toggle", "dropdown"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("aria-expanded", "false"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("tabindex", "1"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["btn", "dropdown-toggle", "btn-default"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_selectedValueContainer__org_dominokit_domino_ui_forms_Select_SelectElement_), HtmlContentBuilder)).m_add__elemental2_dom_Node(new Text("&nbsp;")), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_caret__org_dominokit_domino_ui_forms_Select_SelectElement_), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_optionsList__org_dominokit_domino_ui_forms_Select_SelectElement_ = /**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["dropdown-menu", "inner"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "menu"), HtmlContentBuilder)).m_style__java_lang_String("max-height: 330px; overflow-y: auto; min-height: 82px;"), HtmlContentBuilder)).m_asElement__(), HTMLUListElement_$Overlay));
    this.f_dropDownMenu__org_dominokit_domino_ui_forms_Select_SelectElement_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["dropdown-menu", "open"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("max-height: 340px; overflow: hidden; min-height: 92px;"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_optionsList__org_dominokit_domino_ui_forms_Select_SelectElement_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_selectMenu__org_dominokit_domino_ui_forms_Select_SelectElement_ = /**@type {HTMLSelectElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLSelectElement>} */ ($Casts.$to(Elements.m_select__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-control", "show-tick"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLSelectElement_$Overlay));
    this.f_element__org_dominokit_domino_ui_forms_Select_SelectElement_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["btn-group", "bootstrap-select", "form-control", "show-tick"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_selectButton__org_dominokit_domino_ui_forms_Select_SelectElement_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_dropDownMenu__org_dominokit_domino_ui_forms_Select_SelectElement_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_selectMenu__org_dominokit_domino_ui_forms_Select_SelectElement_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SelectElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SelectElement);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SelectElement.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLButtonElement.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLSelectElement_$Overlay = goog.module.get('elemental2.dom.HTMLSelectElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    SVGUtil = goog.module.get('org.dominokit.domino.ui.timepicker.SVGUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SelectElement, $Util.$makeClassName('org.dominokit.domino.ui.forms.Select$SelectElement'));


IsElement.$markImplementor(SelectElement);


exports = SelectElement; 
//# sourceMappingURL=Select$SelectElement.js.map