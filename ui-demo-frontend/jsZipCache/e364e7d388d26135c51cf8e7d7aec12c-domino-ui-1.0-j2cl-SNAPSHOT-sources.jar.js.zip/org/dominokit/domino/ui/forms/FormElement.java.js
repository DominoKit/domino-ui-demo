/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.FormElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.FormElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasAutoValidation = goog.require('org.dominokit.domino.ui.utils.HasAutoValidation');
const _HasHelperText = goog.require('org.dominokit.domino.ui.utils.HasHelperText');
const _HasLabel = goog.require('org.dominokit.domino.ui.utils.HasLabel');
const _HasName = goog.require('org.dominokit.domino.ui.utils.HasName');
const _HasValidation = goog.require('org.dominokit.domino.ui.utils.HasValidation');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _IsRequired = goog.require('org.dominokit.domino.ui.utils.IsRequired');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');


// Re-exports the implementation.
var FormElement = goog.require('org.dominokit.domino.ui.forms.FormElement$impl');
exports = FormElement;
 