/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.ValueBox.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.ValueBox');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement');
const _Focusable = goog.require('org.dominokit.domino.ui.utils.Focusable');
const _HasPlaceHolder = goog.require('org.dominokit.domino.ui.utils.HasPlaceHolder');
const _$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLabelElement_$Overlay = goog.require('elemental2.dom.HTMLLabelElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$LambdaAdaptor$32 = goog.require('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$32');
const _$LambdaAdaptor$33 = goog.require('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$33');
const _$LambdaAdaptor$34 = goog.require('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$34');
const _$LambdaAdaptor$35 = goog.require('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$35');
const _ValueBoxSize = goog.require('org.dominokit.domino.ui.forms.ValueBox.ValueBoxSize');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ValueBox = goog.require('org.dominokit.domino.ui.forms.ValueBox$impl');
exports = ValueBox;
 