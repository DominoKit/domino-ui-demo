/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.BasicFormElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.BasicFormElement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormElement = goog.require('org.dominokit.domino.ui.forms.FormElement$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ElementValidations = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementValidations$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_T, C_V
 * @implements {FormElement<C_T, C_V>}
 * @implements {IsElement<HTMLElement>}
  */
class BasicFormElement extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLLabelElement} */
    this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_;
    /** @public {HTMLLabelElement} */
    this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_;
    /** @public {ElementValidations} */
    this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_;
    /** @public {?string} */
    this.f_helperText__org_dominokit_domino_ui_forms_BasicFormElement_;
  }
  
  /**
   * Initialization from constructor 'BasicFormElement()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_BasicFormElement__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_forms_BasicFormElement();
  }
  
  /**
   * @override
   * @param {?string} helperText
   * @return {C_T}
   * @public
   */
  m_setHelperText__java_lang_String(helperText) {
    this.f_helperText__org_dominokit_domino_ui_forms_BasicFormElement_ = helperText;
    if (!this.m_getContainer__().contains(this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_)) {
      this.m_getContainer__().appendChild(this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_);
    }
    this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_.textContent = helperText;
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getHelperText__() {
    return this.f_helperText__org_dominokit_domino_ui_forms_BasicFormElement_;
  }
  
  /**
   * @override
   * @param {?string} name
   * @return {C_T}
   * @public
   */
  m_setName__java_lang_String(name) {
    $Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.m_getInputElement__(), BasicFormElement.f_NAME__org_dominokit_domino_ui_forms_BasicFormElement_, name);
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.m_getInputElement__().getAttribute(BasicFormElement.f_NAME__org_dominokit_domino_ui_forms_BasicFormElement_);
  }
  
  /**
   * @override
   * @param {?string} label
   * @return {C_T}
   * @public
   */
  m_setLabel__java_lang_String(label) {
    this.m_getLabelElement__().textContent = label;
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getLabel__() {
    return this.m_getLabelElement__().textContent;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_enable__() {
    this.m_getInputElement__().removeAttribute("disabled");
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return !this.m_getInputElement__().hasAttribute("disabled");
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_disable__() {
    $Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.m_getInputElement__(), "disabled", "disabled");
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.m_getContainer__();
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    return this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_validate__();
  }
  
  /**
   * @override
   * @param {Validator} validator
   * @return {C_T}
   * @public
   */
  m_removeValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_removeValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator);
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @param {Validator} validator
   * @return {boolean}
   * @public
   */
  m_hasValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator) {
    return this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_hasValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator);
  }
  
  /**
   * @override
   * @param {Validator} validator
   * @return {C_T}
   * @public
   */
  m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator);
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @param {?string} errorMessage
   * @return {C_T}
   * @public
   */
  m_invalidate__java_lang_String(errorMessage) {
    this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_.style.display = "none";
    if (!this.m_getContainer__().contains(this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_)) {
      this.m_getContainer__().appendChild(this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_);
    }
    this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_.style.display = "block";
    this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_.textContent = errorMessage;
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_clearInvalid__() {
    this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_.style.display = "block";
    this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_.textContent = "";
    this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_.style.display = "none";
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @param {boolean} required
   * @return {C_T}
   * @public
   */
  m_setRequired__boolean(required) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_setRequired__boolean(required);
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @param {boolean} required
   * @param {?string} message
   * @return {C_T}
   * @public
   */
  m_setRequired__boolean__java_lang_String(required, message) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_setRequired__boolean__java_lang_String(required, message);
    return /**@type {C_T} */ ($Casts.$to(this, BasicFormElement));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isRequired__() {
    return this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_.m_isRequired__();
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_getContainer__() {
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_getLabelElement__() {
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_getInputElement__() {
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_BasicFormElement() {
    this.f_helperLabel__org_dominokit_domino_ui_forms_BasicFormElement_ = /**@type {HTMLLabelElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["help-info"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_errorLabel__org_dominokit_domino_ui_forms_BasicFormElement_ = /**@type {HTMLLabelElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["error"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_elementValidations__org_dominokit_domino_ui_forms_BasicFormElement_ = ElementValidations.$create__org_dominokit_domino_ui_forms_FormElement(this);
  }
  
  /**
   * @abstract
   * @override
   * @return {C_V}
   * @public
   */
  m_getValue__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {C_V} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isAutoValidation__() {
  }
  
  /**
   * @abstract
   * @override
   * @param {boolean} arg0
   * @return {C_T}
   * @public
   */
  m_setAutoValidation__boolean(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @return {C_T}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @abstract
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BasicFormElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BasicFormElement);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BasicFormElement.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ElementValidations = goog.module.get('org.dominokit.domino.ui.utils.ElementValidations$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BasicFormElement, $Util.$makeClassName('org.dominokit.domino.ui.forms.BasicFormElement'));


/** @public {?string} @const */
BasicFormElement.f_NAME__org_dominokit_domino_ui_forms_BasicFormElement_ = "name";


FormElement.$markImplementor(BasicFormElement);
IsElement.$markImplementor(BasicFormElement);


exports = BasicFormElement; 
//# sourceMappingURL=BasicFormElement.js.map