/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.RadioGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.RadioGroup$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormElement = goog.require('org.dominokit.domino.ui.forms.FormElement$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Radio = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio$impl');
let CheckHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
let ElementValidations = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementValidations$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {FormElement<RadioGroup, ?string>}
  */
class RadioGroup extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_container__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {HTMLLabelElement} */
    this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {HTMLLabelElement} */
    this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {HTMLDivElement} */
    this.f_labelContainer__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {ElementValidations} */
    this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {List<Radio>} */
    this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_ui_forms_RadioGroup_;
    /** @public {CheckHandler} */
    this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_;
  }
  
  /**
   * Factory method corresponding to constructor 'RadioGroup(String)'.
   * @param {?string} name
   * @return {!RadioGroup}
   * @public
   */
  static $create__java_lang_String(name) {
    RadioGroup.$clinit();
    let $instance = new RadioGroup();
    $instance.$ctor__org_dominokit_domino_ui_forms_RadioGroup__java_lang_String(name);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RadioGroup(String)'.
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_RadioGroup__java_lang_String(name) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_forms_RadioGroup();
    this.f_container__org_dominokit_domino_ui_forms_RadioGroup_.appendChild(this.f_labelContainer__org_dominokit_domino_ui_forms_RadioGroup_);
    this.m_setName__java_lang_String(name);
  }
  
  /**
   * Factory method corresponding to constructor 'RadioGroup(String, String)'.
   * @param {?string} name
   * @param {?string} label
   * @return {!RadioGroup}
   * @public
   */
  static $create__java_lang_String__java_lang_String(name, label) {
    RadioGroup.$clinit();
    let $instance = new RadioGroup();
    $instance.$ctor__org_dominokit_domino_ui_forms_RadioGroup__java_lang_String__java_lang_String(name, label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RadioGroup(String, String)'.
   * @param {?string} name
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_RadioGroup__java_lang_String__java_lang_String(name, label) {
    this.$ctor__org_dominokit_domino_ui_forms_RadioGroup__java_lang_String(name);
    this.m_setLabel__java_lang_String(label);
  }
  
  /**
   * @param {?string} name
   * @return {RadioGroup}
   * @public
   */
  static m_create__java_lang_String(name) {
    RadioGroup.$clinit();
    return RadioGroup.$create__java_lang_String(name);
  }
  
  /**
   * @param {?string} name
   * @param {?string} label
   * @return {RadioGroup}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(name, label) {
    RadioGroup.$clinit();
    return RadioGroup.$create__java_lang_String__java_lang_String(name, label);
  }
  
  /**
   * @param {Radio} radio
   * @return {RadioGroup}
   * @public
   */
  m_addRadio__org_dominokit_domino_ui_forms_Radio(radio) {
    radio.m_setName__java_lang_String(this.f_name__org_dominokit_domino_ui_forms_RadioGroup_);
    this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.add(radio);
    this.m_asElement__().appendChild(radio.m_asElement__());
    return this;
  }
  
  /**
   * @return {RadioGroup}
   * @public
   */
  m_horizontal__() {
    for (let $iterator = this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let radio = /**@type {Radio} */ ($Casts.$to($iterator.m_next__(), Radio));
      radio.m_asElement__().classList.add("horizontal-radio");
    }
    return this;
  }
  
  /**
   * @return {RadioGroup}
   * @public
   */
  m_vertical__() {
    for (let $iterator = this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let radio = /**@type {Radio} */ ($Casts.$to($iterator.m_next__(), Radio));
      radio.m_asElement__().classList.remove("horizontal-radio");
    }
    return this;
  }
  
  /**
   * @override
   * @param {?string} text
   * @return {RadioGroup}
   * @public
   */
  m_setHelperText__java_lang_String(text) {
    if (!this.f_container__org_dominokit_domino_ui_forms_RadioGroup_.contains(this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_)) {
      this.f_container__org_dominokit_domino_ui_forms_RadioGroup_.appendChild(this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_);
    }
    this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_.textContent = text;
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getHelperText__() {
    return this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_.textContent;
  }
  
  /**
   * @override
   * @param {?string} label
   * @return {RadioGroup}
   * @public
   */
  m_setLabel__java_lang_String(label) {
    this.f_labelContainer__org_dominokit_domino_ui_forms_RadioGroup_.textContent = label;
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_container__org_dominokit_domino_ui_forms_RadioGroup_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getLabel__() {
    return this.f_labelContainer__org_dominokit_domino_ui_forms_RadioGroup_.textContent;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    return this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_validate__();
  }
  
  /**
   * @override
   * @param {Validator} validator
   * @return {RadioGroup}
   * @public
   */
  m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator);
    return this;
  }
  
  /**
   * @override
   * @param {Validator} validator
   * @return {RadioGroup}
   * @public
   */
  m_removeValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_removeValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator);
    return this;
  }
  
  /**
   * @override
   * @param {Validator} validator
   * @return {boolean}
   * @public
   */
  m_hasValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator) {
    return this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_hasValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(validator);
  }
  
  /**
   * @override
   * @param {?string} errorMessage
   * @return {RadioGroup}
   * @public
   */
  m_invalidate__java_lang_String(errorMessage) {
    this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_.style.display = "none";
    if (!this.f_container__org_dominokit_domino_ui_forms_RadioGroup_.contains(this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_)) {
      this.f_container__org_dominokit_domino_ui_forms_RadioGroup_.appendChild(this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_);
    }
    this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_.style.display = "block";
    this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_.textContent = errorMessage;
    return this;
  }
  
  /**
   * @override
   * @return {RadioGroup}
   * @public
   */
  m_clearInvalid__() {
    this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_.style.display = "block";
    this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_.textContent = "";
    this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_.style.display = "none";
    return this;
  }
  
  /**
   * @return {List<Radio>}
   * @public
   */
  m_getRadios__() {
    return this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isSelected__() {
    return !$Equality.$same(this.m_getValue__(), null);
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_String(value) {
    let radioToSelect = /**@type {Radio} */ ($Casts.$to(this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Radio */ radio) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(radio.m_getValue__(), value);
    }))).m_findFirst__().m_orElse__java_lang_Object(null), Radio));
    if (Objects.m_nonNull__java_lang_Object(radioToSelect)) {
      radioToSelect.m_check__();
    }
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return /**@type {?string} */ ($Casts.$to(/**@type {Stream<?string>} */ (this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Radio */ arg0) =>{
      return arg0.m_isChecked__();
    }))).m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** Radio */ arg0$1$) =>{
      return arg0$1$.m_getValue__();
    })))).m_findFirst__().m_orElse__java_lang_Object(null), j_l_String));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return !this.m_isSelected__();
  }
  
  /**
   * @override
   * @return {RadioGroup}
   * @public
   */
  m_clear__() {
    this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Radio */ arg0) =>{
      arg0.m_uncheck__();
    })));
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_ui_forms_RadioGroup_;
  }
  
  /**
   * @override
   * @param {?string} name
   * @return {RadioGroup}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_domino_ui_forms_RadioGroup_ = name;
    return this;
  }
  
  /**
   * @override
   * @return {RadioGroup}
   * @public
   */
  m_enable__() {
    this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Radio */ arg0) =>{
      arg0.m_enable__();
    })));
    return this;
  }
  
  /**
   * @override
   * @return {RadioGroup}
   * @public
   */
  m_disable__() {
    this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Radio */ arg0) =>{
      arg0.m_disable__();
    })));
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_stream__().m_allMatch__java_util_function_Predicate(Predicate.$adapt(((/** Radio */ arg0) =>{
      return arg0.m_isEnabled__();
    })));
  }
  
  /**
   * @override
   * @param {boolean} autoValidation
   * @return {RadioGroup}
   * @public
   */
  m_setAutoValidation__boolean(autoValidation) {
    if (autoValidation) {
      if (Objects.m_isNull__java_lang_Object(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_)) {
        this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_ = CheckHandler.$adapt(((/** boolean */ checked) =>{
          this.m_validate__();
        }));
        this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Radio */ radio) =>{
          radio.m_addCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_);
        })));
      }
    } else {
      this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Radio */ radio$1$) =>{
        radio$1$.m_removeCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_);
      })));
      this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_ = null;
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isAutoValidation__() {
    return Objects.m_nonNull__java_lang_Object(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_RadioGroup_);
  }
  
  /**
   * @override
   * @param {boolean} required
   * @return {RadioGroup}
   * @public
   */
  m_setRequired__boolean(required) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_setRequired__boolean(required);
    return this;
  }
  
  /**
   * @override
   * @param {boolean} required
   * @param {?string} message
   * @return {RadioGroup}
   * @public
   */
  m_setRequired__boolean__java_lang_String(required, message) {
    this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_setRequired__boolean__java_lang_String(required, message);
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isRequired__() {
    return this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_.m_isRequired__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_lang_String(/**@type {?string} */ ($Casts.$to(arg0, j_l_String)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_RadioGroup() {
    this.f_container__org_dominokit_domino_ui_forms_RadioGroup_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_helperLabel__org_dominokit_domino_ui_forms_RadioGroup_ = /**@type {HTMLLabelElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["help-info"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_errorLabel__org_dominokit_domino_ui_forms_RadioGroup_ = /**@type {HTMLLabelElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["error"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_labelContainer__org_dominokit_domino_ui_forms_RadioGroup_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-label"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_elementValidations__org_dominokit_domino_ui_forms_RadioGroup_ = ElementValidations.$create__org_dominokit_domino_ui_forms_FormElement(this);
    this.f_radios__org_dominokit_domino_ui_forms_RadioGroup_ = /**@type {!ArrayList<Radio>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RadioGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RadioGroup);
  }
  
  /**
   * @public
   */
  static $clinit() {
    RadioGroup.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    Radio = goog.module.get('org.dominokit.domino.ui.forms.Radio$impl');
    CheckHandler = goog.module.get('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
    ElementValidations = goog.module.get('org.dominokit.domino.ui.utils.ElementValidations$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(RadioGroup, $Util.$makeClassName('org.dominokit.domino.ui.forms.RadioGroup'));


IsElement.$markImplementor(RadioGroup);
FormElement.$markImplementor(RadioGroup);


exports = RadioGroup; 
//# sourceMappingURL=RadioGroup.js.map