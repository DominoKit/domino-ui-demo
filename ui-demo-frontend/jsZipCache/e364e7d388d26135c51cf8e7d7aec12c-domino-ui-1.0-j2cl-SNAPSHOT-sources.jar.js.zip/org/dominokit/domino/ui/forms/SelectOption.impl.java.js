/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.SelectOption.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.SelectOption$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Selectable.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLLIElement>}
 * @implements {HasValue<?string>}
 * @implements {HasBackground<SelectOption>}
 * @implements {Selectable<SelectOption>}
  */
class SelectOption extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_displayValue__org_dominokit_domino_ui_forms_SelectOption_;
    /** @public {?string} */
    this.f_value__org_dominokit_domino_ui_forms_SelectOption_;
    /** @public {HTMLLIElement} */
    this.f_li__org_dominokit_domino_ui_forms_SelectOption_;
    /** @public {HTMLAnchorElement} */
    this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_;
    /** @public {HTMLElement} */
    this.f_valueContainer__org_dominokit_domino_ui_forms_SelectOption_;
    /** @public {HTMLElement} */
    this.f_checkMark__org_dominokit_domino_ui_forms_SelectOption_;
  }
  
  /**
   * Factory method corresponding to constructor 'SelectOption(String, String)'.
   * @param {?string} value
   * @param {?string} displayValue
   * @return {!SelectOption}
   * @public
   */
  static $create__java_lang_String__java_lang_String(value, displayValue) {
    SelectOption.$clinit();
    let $instance = new SelectOption();
    $instance.$ctor__org_dominokit_domino_ui_forms_SelectOption__java_lang_String__java_lang_String(value, displayValue);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectOption(String, String)'.
   * @param {?string} value
   * @param {?string} displayValue
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_SelectOption__java_lang_String__java_lang_String(value, displayValue) {
    this.$ctor__java_lang_Object__();
    this.f_li__org_dominokit_domino_ui_forms_SelectOption_ = /**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), $Overlay));
    this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("data-tokens", "null"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("tabindex", "0"), HtmlContentBuilder)).m_asElement__(), HTMLAnchorElement_$Overlay));
    this.f_valueContainer__org_dominokit_domino_ui_forms_SelectOption_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["text"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_.appendChild(this.f_valueContainer__org_dominokit_domino_ui_forms_SelectOption_);
    this.f_li__org_dominokit_domino_ui_forms_SelectOption_.appendChild(this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_);
    this.f_checkMark__org_dominokit_domino_ui_forms_SelectOption_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["glyphicon glyphicon-ok check-mark"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.m_setValue__java_lang_String(value);
    this.m_setDisplayValue__java_lang_String(displayValue);
  }
  
  /**
   * Factory method corresponding to constructor 'SelectOption(String)'.
   * @param {?string} value
   * @return {!SelectOption}
   * @public
   */
  static $create__java_lang_String(value) {
    SelectOption.$clinit();
    let $instance = new SelectOption();
    $instance.$ctor__org_dominokit_domino_ui_forms_SelectOption__java_lang_String(value);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectOption(String)'.
   * @param {?string} value
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_SelectOption__java_lang_String(value) {
    this.$ctor__org_dominokit_domino_ui_forms_SelectOption__java_lang_String__java_lang_String(value, value);
  }
  
  /**
   * @param {?string} value
   * @param {?string} displayValue
   * @return {SelectOption}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(value, displayValue) {
    SelectOption.$clinit();
    return SelectOption.$create__java_lang_String__java_lang_String(value, displayValue);
  }
  
  /**
   * @param {?string} value
   * @return {SelectOption}
   * @public
   */
  static m_create__java_lang_String(value) {
    SelectOption.$clinit();
    return SelectOption.$create__java_lang_String(value);
  }
  
  /**
   * @param {Node} node
   * @return {SelectOption}
   * @public
   */
  m_appendContent__elemental2_dom_Node(node) {
    this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_.appendChild(node);
    return this;
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_String(value) {
    this.f_value__org_dominokit_domino_ui_forms_SelectOption_ = value;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return this.f_value__org_dominokit_domino_ui_forms_SelectOption_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDisplayValue__() {
    return this.f_displayValue__org_dominokit_domino_ui_forms_SelectOption_;
  }
  
  /**
   * @param {?string} displayValue
   * @return {SelectOption}
   * @public
   */
  m_setDisplayValue__java_lang_String(displayValue) {
    this.f_displayValue__org_dominokit_domino_ui_forms_SelectOption_ = displayValue;
    this.f_valueContainer__org_dominokit_domino_ui_forms_SelectOption_.textContent = displayValue;
    return this;
  }
  
  /**
   * @override
   * @return {SelectOption}
   * @public
   */
  m_select__() {
    return this.m_select__boolean(false);
  }
  
  /**
   * @override
   * @return {SelectOption}
   * @public
   */
  m_deselect__() {
    return this.m_deselect__boolean(false);
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {SelectOption}
   * @public
   */
  m_select__boolean(silent) {
    this.m_asElement__().classList.add(SelectOption.f_SELECTED__org_dominokit_domino_ui_forms_SelectOption_);
    this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_.appendChild(this.f_checkMark__org_dominokit_domino_ui_forms_SelectOption_);
    return this;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {SelectOption}
   * @public
   */
  m_deselect__boolean(silent) {
    this.m_asElement__().classList.remove(SelectOption.f_SELECTED__org_dominokit_domino_ui_forms_SelectOption_);
    if (this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_.contains(this.f_checkMark__org_dominokit_domino_ui_forms_SelectOption_)) {
      this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_.removeChild(this.f_checkMark__org_dominokit_domino_ui_forms_SelectOption_);
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSelected__() {
    return this.m_asElement__().classList.contains(SelectOption.f_SELECTED__org_dominokit_domino_ui_forms_SelectOption_);
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {SelectOption}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    this.m_asElement__().classList.add(background.m_getBackground__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLLIElement}
   * @public
   */
  m_asElement__() {
    return this.f_li__org_dominokit_domino_ui_forms_SelectOption_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getCheckMark__() {
    return this.f_checkMark__org_dominokit_domino_ui_forms_SelectOption_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getValueContainer__() {
    return this.f_valueContainer__org_dominokit_domino_ui_forms_SelectOption_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_focus__() {
    this.f_aElement__org_dominokit_domino_ui_forms_SelectOption_.focus();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {SelectionHandler<SelectOption>} arg0
   * @return {void}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(arg0) {
    Selectable.m_addSelectionHandler__$default__org_dominokit_domino_ui_utils_Selectable__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(this, arg0);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_lang_String(/**@type {?string} */ ($Casts.$to(arg0, j_l_String)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SelectOption;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SelectOption);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SelectOption.$clinit = function() {};
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    Selectable.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SelectOption, $Util.$makeClassName('org.dominokit.domino.ui.forms.SelectOption'));


/** @public {?string} @const */
SelectOption.f_SELECTED__org_dominokit_domino_ui_forms_SelectOption_ = "selected";


IsElement.$markImplementor(SelectOption);
HasValue.$markImplementor(SelectOption);
HasBackground.$markImplementor(SelectOption);
Selectable.$markImplementor(SelectOption);


exports = SelectOption; 
//# sourceMappingURL=SelectOption.js.map