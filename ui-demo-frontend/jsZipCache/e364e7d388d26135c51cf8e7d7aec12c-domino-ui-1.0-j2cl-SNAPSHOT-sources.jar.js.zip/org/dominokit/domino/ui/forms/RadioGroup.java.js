/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.RadioGroup.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.RadioGroup');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _FormElement = goog.require('org.dominokit.domino.ui.forms.FormElement');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLLabelElement_$Overlay = goog.require('elemental2.dom.HTMLLabelElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _Predicate = goog.require('java.util.function.Predicate');
const _Stream = goog.require('java.util.stream.Stream');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Radio = goog.require('org.dominokit.domino.ui.forms.Radio');
const _CheckHandler = goog.require('org.dominokit.domino.ui.utils.Checkable.CheckHandler');
const _ElementValidations = goog.require('org.dominokit.domino.ui.utils.ElementValidations');
const _Validator = goog.require('org.dominokit.domino.ui.utils.HasValidation.Validator');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var RadioGroup = goog.require('org.dominokit.domino.ui.forms.RadioGroup$impl');
exports = RadioGroup;
 