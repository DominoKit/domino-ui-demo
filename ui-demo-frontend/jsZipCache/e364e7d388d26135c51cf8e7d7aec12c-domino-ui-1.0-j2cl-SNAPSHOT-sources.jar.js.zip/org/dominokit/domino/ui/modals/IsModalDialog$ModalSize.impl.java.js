/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog$ModalSize.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<ModalSize>}
  */
class ModalSize extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize;
  }
  
  /**
   * Factory method corresponding to constructor 'ModalSize(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!ModalSize}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new ModalSize();
    $instance.$ctor__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalSize(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = style;
  }
  
  /**
   * @param {string} name
   * @return {!ModalSize}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    ModalSize.$clinit();
    if ($Equality.$same(ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_, null)) {
      ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_ = $Enums.createMapFromValues(ModalSize.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_);
  }
  
  /**
   * @return {!Array<!ModalSize>}
   * @public
   */
  static m_values__() {
    ModalSize.$clinit();
    return /**@type {!Array<ModalSize>} */ ($Arrays.$init([ModalSize.$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize, ModalSize.$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize, ModalSize.$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize], ModalSize));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {ModalSize} */ ($Casts.$to(arg0, ModalSize)));
  }
  
  /**
   * @return {!ModalSize}
   * @public
   */
  static get f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize() {
    return (ModalSize.$clinit(), ModalSize.$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
  }
  
  /**
   * @param {!ModalSize} value
   * @return {void}
   * @public
   */
  static set f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(value) {
    (ModalSize.$clinit(), ModalSize.$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = value);
  }
  
  /**
   * @return {!ModalSize}
   * @public
   */
  static get f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize() {
    return (ModalSize.$clinit(), ModalSize.$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
  }
  
  /**
   * @param {!ModalSize} value
   * @return {void}
   * @public
   */
  static set f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(value) {
    (ModalSize.$clinit(), ModalSize.$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = value);
  }
  
  /**
   * @return {!ModalSize}
   * @public
   */
  static get f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize() {
    return (ModalSize.$clinit(), ModalSize.$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
  }
  
  /**
   * @param {!ModalSize} value
   * @return {void}
   * @public
   */
  static set f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(value) {
    (ModalSize.$clinit(), ModalSize.$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = value);
  }
  
  /**
   * @return {Map<?string, !ModalSize>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_() {
    return (ModalSize.$clinit(), ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_);
  }
  
  /**
   * @param {Map<?string, !ModalSize>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_(value) {
    (ModalSize.$clinit(), ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalSize;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalSize);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalSize.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    ModalSize.$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = ModalSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("LARGE"), ModalSize.$ordinal$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize, "modal-lg");
    ModalSize.$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = ModalSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ALERT"), ModalSize.$ordinal$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize, "modal-alert");
    ModalSize.$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = ModalSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("SMALL"), ModalSize.$ordinal$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize, "modal-sm");
    ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(ModalSize, $Util.$makeClassName('org.dominokit.domino.ui.modals.IsModalDialog$ModalSize'));


/** @private {!ModalSize} */
ModalSize.$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize;


/** @private {!ModalSize} */
ModalSize.$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize;


/** @private {!ModalSize} */
ModalSize.$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize;


/** @private {Map<?string, !ModalSize>} */
ModalSize.$f_namesToValuesMap__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize_;


/** @public {number} @const */
ModalSize.$ordinal$f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = 0;


/** @public {number} @const */
ModalSize.$ordinal$f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = 1;


/** @public {number} @const */
ModalSize.$ordinal$f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize = 2;




exports = ModalSize; 
//# sourceMappingURL=IsModalDialog$ModalSize.js.map