/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.BaseModal.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.modals.BaseModal');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsModalDialog = goog.require('org.dominokit.domino.ui.modals.IsModalDialog');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _KeyboardEvent_$Overlay = goog.require('elemental2.dom.KeyboardEvent.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Text_$Overlay = goog.require('elemental2.dom.Text.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$LambdaAdaptor$41 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$41');
const _$LambdaAdaptor$42 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$42');
const _$LambdaAdaptor$43 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$43');
const _$LambdaAdaptor$44 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$44');
const _$LambdaAdaptor$45 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$45');
const _$LambdaAdaptor$46 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$46');
const _$LambdaAdaptor$47 = goog.require('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$47');
const _Modal = goog.require('org.dominokit.domino.ui.modals.BaseModal.Modal');
const _CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');
const _ModalSize = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize');
const _OpenHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var BaseModal = goog.require('org.dominokit.domino.ui.modals.BaseModal$impl');
exports = BaseModal;
 