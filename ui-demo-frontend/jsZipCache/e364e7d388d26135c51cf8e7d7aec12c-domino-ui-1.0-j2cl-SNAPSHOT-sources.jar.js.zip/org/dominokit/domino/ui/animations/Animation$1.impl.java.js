/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.animations.Animation.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Timer = goog.require('org.gwtproject.timer.client.Timer$impl');

let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');


class $1 extends Timer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Animation} */
    this.f_$outer_this__org_dominokit_domino_ui_animations_Animation_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new Timer(Animation)'.
   * @param {Animation} $outer_this
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_ui_animations_Animation($outer_this) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_ui_animations_Animation_1__org_dominokit_domino_ui_animations_Animation($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new Timer(Animation)'.
   * @param {Animation} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_animations_Animation_1__org_dominokit_domino_ui_animations_Animation($outer_this) {
    this.f_$outer_this__org_dominokit_domino_ui_animations_Animation_1 = $outer_this;
    this.$ctor__org_gwtproject_timer_client_Timer__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_run__() {
    this.f_$outer_this__org_dominokit_domino_ui_animations_Animation_1.m_animateElement___$p_org_dominokit_domino_ui_animations_Animation();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    Timer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.ui.animations.Animation$1'));




exports = $1; 
//# sourceMappingURL=Animation$1.js.map