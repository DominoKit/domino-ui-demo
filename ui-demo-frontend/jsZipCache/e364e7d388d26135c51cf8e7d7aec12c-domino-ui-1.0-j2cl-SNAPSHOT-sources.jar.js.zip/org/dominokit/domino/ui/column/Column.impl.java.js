/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.column.Column$impl');


const Cloneable = goog.require('java.lang.Cloneable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {Cloneable}
  */
class Column extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_column__org_dominokit_domino_ui_column_Column_;
    /** @public {OnLarge} */
    this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnMedium} */
    this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnSmall} */
    this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnXSmall} */
    this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {List<?string>} */
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_;
  }
  
  /**
   * Factory method corresponding to constructor 'Column(HTMLDivElement)'.
   * @param {HTMLDivElement} htmlDivElement
   * @return {!Column}
   * @public
   */
  static $create__elemental2_dom_HTMLDivElement(htmlDivElement) {
    Column.$clinit();
    let $instance = new Column();
    $instance.$ctor__org_dominokit_domino_ui_column_Column__elemental2_dom_HTMLDivElement(htmlDivElement);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Column(HTMLDivElement)'.
   * @param {HTMLDivElement} htmlDivElement
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_column_Column__elemental2_dom_HTMLDivElement(htmlDivElement) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_column_Column();
    this.f_column__org_dominokit_domino_ui_column_Column_ = htmlDivElement;
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_create__() {
    Column.$clinit();
    return Column.$create__elemental2_dom_HTMLDivElement(/**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay)));
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_copy__() {
    let column = Column.m_create__();
    if (Objects.m_nonNull__java_lang_Object(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (this.m_asElement__().classList.contains(Column.f_ALIGN_CENTER__org_dominokit_domino_ui_column_Column)) {
      column.m_centerContent__();
    }
    for (let i = 0; i < this.f_cssClasses__org_dominokit_domino_ui_column_Column_.size(); i++) {
      column.m_addCssClass__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_cssClasses__org_dominokit_domino_ui_column_Column_.getAtIndex(i), j_l_String)));
    }
    return column;
  }
  
  /**
   * @param {Node} element
   * @return {Column}
   * @public
   */
  m_addElement__elemental2_dom_Node(element) {
    this.m_asElement__().appendChild(element);
    return this;
  }
  
  /**
   * @param {OnLarge} onLarge
   * @return {Column}
   * @public
   */
  m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(onLarge) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_ = onLarge;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnMedium} onMedium
   * @return {Column}
   * @public
   */
  m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(onMedium) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_ = onMedium;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnSmall} onSmall
   * @return {Column}
   * @public
   */
  m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(onSmall) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_ = onSmall;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnXSmall} onXSmall
   * @return {Column}
   * @public
   */
  m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(onXSmall) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_ = onXSmall;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_centerContent__() {
    this.m_asElement__().classList.add(Column.f_ALIGN_CENTER__org_dominokit_domino_ui_column_Column);
    return this;
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_deCenterContent__() {
    this.m_asElement__().classList.remove(Column.f_ALIGN_CENTER__org_dominokit_domino_ui_column_Column);
    return this;
  }
  
  /**
   * @param {?string} cssClass
   * @return {Column}
   * @public
   */
  m_addCssClass__java_lang_String(cssClass) {
    this.m_asElement__().classList.add(cssClass);
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_.add(cssClass);
    return this;
  }
  
  /**
   * @param {?string} cssClass
   * @return {Column}
   * @public
   */
  m_removeCssClass__java_lang_String(cssClass) {
    this.m_asElement__().classList.remove(cssClass);
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_.remove(cssClass);
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_column__org_dominokit_domino_ui_column_Column_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_column_Column() {
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_ = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Column;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Column);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Column.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Column, $Util.$makeClassName('org.dominokit.domino.ui.column.Column'));


/** @public {?string} @const */
Column.f_ALIGN_CENTER__org_dominokit_domino_ui_column_Column = "align-center";


IsElement.$markImplementor(Column);
Cloneable.$markImplementor(Column);


exports = Column; 
//# sourceMappingURL=Column.js.map