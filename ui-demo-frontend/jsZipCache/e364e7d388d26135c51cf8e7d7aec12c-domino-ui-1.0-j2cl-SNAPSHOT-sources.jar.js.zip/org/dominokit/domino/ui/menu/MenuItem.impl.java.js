/**
 * @fileoverview transpiled from org.dominokit.domino.ui.menu.MenuItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.menu.MenuItem$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const WavesElement = goog.require('org.dominokit.domino.ui.style.WavesElement$impl');
const CanActivate = goog.require('org.dominokit.domino.ui.utils.CanActivate$impl');
const CanDeactivate = goog.require('org.dominokit.domino.ui.utils.CanDeactivate$impl');
const HasActiveItem = goog.require('org.dominokit.domino.ui.utils.HasActiveItem$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let $LambdaAdaptor$40 = goog.forwardDeclare('org.dominokit.domino.ui.menu.MenuItem.$LambdaAdaptor$40$impl');
let WaveColor = goog.forwardDeclare('org.dominokit.domino.ui.style.WaveColor$impl');
let WaveStyle = goog.forwardDeclare('org.dominokit.domino.ui.style.WaveStyle$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @extends {WavesElement<MenuItem, HTMLAnchorElement>}
 * @implements {IsElement<HTMLLIElement>}
 * @implements {HasActiveItem<MenuItem>}
 * @implements {CanActivate}
 * @implements {CanDeactivate}
 * @implements {HasClickableElement}
  */
class MenuItem extends WavesElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_title__org_dominokit_domino_ui_menu_MenuItem_;
    /** @public {boolean} */
    this.f_isRoot__org_dominokit_domino_ui_menu_MenuItem_ = false;
    /** @public {HTMLLIElement} */
    this.f_element__org_dominokit_domino_ui_menu_MenuItem_;
    /** @public {HTMLAnchorElement} */
    this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_;
    /** @public {List<MenuItem>} */
    this.f_subItems__org_dominokit_domino_ui_menu_MenuItem_;
    /** @public {MenuItem} */
    this.f_activeMenuItem__org_dominokit_domino_ui_menu_MenuItem_;
    /** @public {HasActiveItem<MenuItem>} */
    this.f_parent__org_dominokit_domino_ui_menu_MenuItem_;
    /** @public {boolean} */
    this.f_active__org_dominokit_domino_ui_menu_MenuItem_ = false;
    /** @public {boolean} */
    this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_ = false;
    /** @public {HTMLUListElement} */
    this.f_childrenContainer__org_dominokit_domino_ui_menu_MenuItem_;
  }
  
  /**
   * Factory method corresponding to constructor 'MenuItem(String, HTMLLIElement, HTMLAnchorElement, HasActiveItem, boolean)'.
   * @param {?string} title
   * @param {HTMLLIElement} element
   * @param {HTMLAnchorElement} menuAnchor
   * @param {HasActiveItem} parent
   * @param {boolean} isRoot
   * @return {!MenuItem}
   * @public
   */
  static $create__java_lang_String__elemental2_dom_HTMLLIElement__elemental2_dom_HTMLAnchorElement__org_dominokit_domino_ui_utils_HasActiveItem__boolean(title, element, menuAnchor, parent, isRoot) {
    MenuItem.$clinit();
    let $instance = new MenuItem();
    $instance.$ctor__org_dominokit_domino_ui_menu_MenuItem__java_lang_String__elemental2_dom_HTMLLIElement__elemental2_dom_HTMLAnchorElement__org_dominokit_domino_ui_utils_HasActiveItem__boolean(title, element, menuAnchor, parent, isRoot);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MenuItem(String, HTMLLIElement, HTMLAnchorElement, HasActiveItem, boolean)'.
   * @param {?string} title
   * @param {HTMLLIElement} element
   * @param {HTMLAnchorElement} menuAnchor
   * @param {HasActiveItem} parent
   * @param {boolean} isRoot
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_menu_MenuItem__java_lang_String__elemental2_dom_HTMLLIElement__elemental2_dom_HTMLAnchorElement__org_dominokit_domino_ui_utils_HasActiveItem__boolean(title, element, menuAnchor, parent, isRoot) {
    this.$ctor__org_dominokit_domino_ui_style_WavesElement__();
    this.$init__org_dominokit_domino_ui_menu_MenuItem();
    this.f_element__org_dominokit_domino_ui_menu_MenuItem_ = element;
    this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_ = menuAnchor;
    this.f_parent__org_dominokit_domino_ui_menu_MenuItem_ = parent;
    this.f_title__org_dominokit_domino_ui_menu_MenuItem_ = title;
    this.f_isRoot__org_dominokit_domino_ui_menu_MenuItem_ = isRoot;
    element.appendChild(menuAnchor);
    super.m_init__org_jboss_gwt_elemento_core_IsElement__elemental2_dom_HTMLElement(this, menuAnchor);
    this.m_setWaveColor__org_dominokit_domino_ui_style_WaveColor(WaveColor.f_THEME__org_dominokit_domino_ui_style_WaveColor);
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_BLOCK__org_dominokit_domino_ui_style_WaveStyle);
  }
  
  /**
   * @override
   * @return {HTMLLIElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_menu_MenuItem_;
  }
  
  /**
   * @override
   * @return {MenuItem}
   * @public
   */
  m_getActiveItem__() {
    return this.f_activeMenuItem__org_dominokit_domino_ui_menu_MenuItem_;
  }
  
  /**
   * @param {MenuItem} activeItem
   * @return {void}
   * @public
   */
  m_setActiveItem__org_dominokit_domino_ui_menu_MenuItem(activeItem) {
    this.f_activeMenuItem__org_dominokit_domino_ui_menu_MenuItem_ = activeItem;
  }
  
  /**
   * @param {?string} title
   * @param {Icon} icon
   * @param {HasActiveItem} parent
   * @return {MenuItem}
   * @public
   */
  static m_createRootItem__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_utils_HasActiveItem_$pp_org_dominokit_domino_ui_menu(title, icon, parent) {
    MenuItem.$clinit();
    let anchor = MenuItem.m_createAnchor___$p_org_dominokit_domino_ui_menu_MenuItem();
    anchor.appendChild(icon.m_asElement__());
    anchor.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String(title), HtmlContentBuilder)).m_asElement__());
    return MenuItem.m_create__java_lang_String__org_dominokit_domino_ui_utils_HasActiveItem__elemental2_dom_HTMLAnchorElement__boolean_$p_org_dominokit_domino_ui_menu_MenuItem(title, parent, anchor, true);
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  static m_createAnchor___$p_org_dominokit_domino_ui_menu_MenuItem() {
    MenuItem.$clinit();
    return /**@type {HTMLAnchorElement} */ ($Casts.$to(Elements.m_a__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?string} title
   * @param {HasActiveItem} parent
   * @return {MenuItem}
   * @public
   */
  static m_createLeafItem__java_lang_String__org_dominokit_domino_ui_utils_HasActiveItem_$pp_org_dominokit_domino_ui_menu(title, parent) {
    MenuItem.$clinit();
    let anchor = MenuItem.m_createAnchor___$p_org_dominokit_domino_ui_menu_MenuItem();
    anchor.textContent = title;
    return MenuItem.m_create__java_lang_String__org_dominokit_domino_ui_utils_HasActiveItem__elemental2_dom_HTMLAnchorElement__boolean_$p_org_dominokit_domino_ui_menu_MenuItem(title, parent, anchor, false);
  }
  
  /**
   * @param {?string} title
   * @param {HasActiveItem} parent
   * @param {HTMLAnchorElement} anchor
   * @param {boolean} b
   * @return {MenuItem}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_utils_HasActiveItem__elemental2_dom_HTMLAnchorElement__boolean_$p_org_dominokit_domino_ui_menu_MenuItem(title, parent, anchor, b) {
    MenuItem.$clinit();
    let menuItem = MenuItem.$create__java_lang_String__elemental2_dom_HTMLLIElement__elemental2_dom_HTMLAnchorElement__org_dominokit_domino_ui_utils_HasActiveItem__boolean(title, /**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), HTMLLIElement_$Overlay)), anchor, parent, b);
    menuItem.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.addEventListener("click", new $LambdaAdaptor$40(((/** Event */ e) =>{
      if (!$Objects.m_equals__java_lang_Object__java_lang_Object(menuItem, parent.m_getActiveItem__())) {
        menuItem.m_activate__();
      }
      menuItem.m_toggle___$p_org_dominokit_domino_ui_menu_MenuItem();
    })));
    return menuItem;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_toggle___$p_org_dominokit_domino_ui_menu_MenuItem() {
    if (!this.f_subItems__org_dominokit_domino_ui_menu_MenuItem_.isEmpty()) {
      if (this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_) {
        this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.classList.remove("toggled");
        this.m_hideChildren___$p_org_dominokit_domino_ui_menu_MenuItem();
      } else {
        this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.classList.add("toggled");
        this.m_showChildren___$p_org_dominokit_domino_ui_menu_MenuItem();
      }
      this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_ = !this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_;
    } else {
      if (!this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_) {
        this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.classList.add("toggled");
        this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_ = true;
      }
    }
  }
  
  /**
   * @param {?string} title
   * @return {MenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String(title) {
    let menuItem = MenuItem.m_createLeafItem__java_lang_String__org_dominokit_domino_ui_utils_HasActiveItem_$pp_org_dominokit_domino_ui_menu(title, this);
    if (this.f_subItems__org_dominokit_domino_ui_menu_MenuItem_.isEmpty()) {
      this.m_prepareForChildren___$p_org_dominokit_domino_ui_menu_MenuItem();
    }
    this.f_subItems__org_dominokit_domino_ui_menu_MenuItem_.add(menuItem);
    this.f_childrenContainer__org_dominokit_domino_ui_menu_MenuItem_.appendChild(menuItem.m_asElement__());
    return menuItem;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_prepareForChildren___$p_org_dominokit_domino_ui_menu_MenuItem() {
    this.f_childrenContainer__org_dominokit_domino_ui_menu_MenuItem_ = /**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["ml-menu"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLUListElement_$Overlay));
    this.m_hideChildren___$p_org_dominokit_domino_ui_menu_MenuItem();
    this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.classList.add("menu-toggle");
    if (!this.f_isRoot__org_dominokit_domino_ui_menu_MenuItem_) {
      this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.textContent = "";
      this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String(this.f_title__org_dominokit_domino_ui_menu_MenuItem_), HtmlContentBuilder)).m_asElement__());
    }
    this.m_asElement__().appendChild(this.f_childrenContainer__org_dominokit_domino_ui_menu_MenuItem_);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_activate__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_parent__org_dominokit_domino_ui_menu_MenuItem_.m_getActiveItem__())) {
      if (/**@type {MenuItem} */ ($Casts.$to(this.f_parent__org_dominokit_domino_ui_menu_MenuItem_.m_getActiveItem__(), MenuItem)).f_toggled__org_dominokit_domino_ui_menu_MenuItem_) {
        /**@type {MenuItem} */ ($Casts.$to(this.f_parent__org_dominokit_domino_ui_menu_MenuItem_.m_getActiveItem__(), MenuItem)).m_toggle___$p_org_dominokit_domino_ui_menu_MenuItem();
      }
      /**@type {MenuItem} */ ($Casts.$to(this.f_parent__org_dominokit_domino_ui_menu_MenuItem_.m_getActiveItem__(), MenuItem)).m_deactivate__();
    }
    this.f_element__org_dominokit_domino_ui_menu_MenuItem_.classList.add("active");
    this.f_parent__org_dominokit_domino_ui_menu_MenuItem_.m_setActiveItem__java_lang_Object(this);
    this.f_active__org_dominokit_domino_ui_menu_MenuItem_ = true;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_hideChildren___$p_org_dominokit_domino_ui_menu_MenuItem() {
    this.f_childrenContainer__org_dominokit_domino_ui_menu_MenuItem_.style.display = "none";
  }
  
  /**
   * @return {void}
   * @public
   */
  m_showChildren___$p_org_dominokit_domino_ui_menu_MenuItem() {
    this.f_childrenContainer__org_dominokit_domino_ui_menu_MenuItem_.style.display = "block";
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_deactivate__() {
    if (this.f_active__org_dominokit_domino_ui_menu_MenuItem_) {
      this.f_element__org_dominokit_domino_ui_menu_MenuItem_.classList.remove("active");
      if (Objects.m_nonNull__java_lang_Object(this.m_getActiveItem__())) {
        this.m_getActiveItem__().f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_.classList.remove("toggled");
        this.m_getActiveItem__().f_toggled__org_dominokit_domino_ui_menu_MenuItem_ = false;
        if (!this.m_getActiveItem__().f_subItems__org_dominokit_domino_ui_menu_MenuItem_.isEmpty()) {
          this.m_getActiveItem__().m_hideChildren___$p_org_dominokit_domino_ui_menu_MenuItem();
        }
        this.m_getActiveItem__().m_deactivate__();
      }
      this.f_parent__org_dominokit_domino_ui_menu_MenuItem_.m_setActiveItem__java_lang_Object(null);
      this.f_active__org_dominokit_domino_ui_menu_MenuItem_ = false;
    }
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.f_menuAnchor__org_dominokit_domino_ui_menu_MenuItem_;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setActiveItem__java_lang_Object(arg0) {
    this.m_setActiveItem__org_dominokit_domino_ui_menu_MenuItem(/**@type {MenuItem} */ ($Casts.$to(arg0, MenuItem)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_menu_MenuItem() {
    this.f_subItems__org_dominokit_domino_ui_menu_MenuItem_ = /**@type {!LinkedList<MenuItem>} */ (LinkedList.$create__());
    this.f_active__org_dominokit_domino_ui_menu_MenuItem_ = false;
    this.f_toggled__org_dominokit_domino_ui_menu_MenuItem_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuItem);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MenuItem.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $LambdaAdaptor$40 = goog.module.get('org.dominokit.domino.ui.menu.MenuItem.$LambdaAdaptor$40$impl');
    WaveColor = goog.module.get('org.dominokit.domino.ui.style.WaveColor$impl');
    WaveStyle = goog.module.get('org.dominokit.domino.ui.style.WaveStyle$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    WavesElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MenuItem, $Util.$makeClassName('org.dominokit.domino.ui.menu.MenuItem'));


IsElement.$markImplementor(MenuItem);
HasActiveItem.$markImplementor(MenuItem);
CanActivate.$markImplementor(MenuItem);
CanDeactivate.$markImplementor(MenuItem);
HasClickableElement.$markImplementor(MenuItem);


exports = MenuItem; 
//# sourceMappingURL=MenuItem.js.map