/**
 * @fileoverview transpiled from org.dominokit.domino.ui.menu.MenuItem.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.menu.MenuItem');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _WavesElement = goog.require('org.dominokit.domino.ui.style.WavesElement');
const _CanActivate = goog.require('org.dominokit.domino.ui.utils.CanActivate');
const _CanDeactivate = goog.require('org.dominokit.domino.ui.utils.CanDeactivate');
const _HasActiveItem = goog.require('org.dominokit.domino.ui.utils.HasActiveItem');
const _HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _$LambdaAdaptor$40 = goog.require('org.dominokit.domino.ui.menu.MenuItem.$LambdaAdaptor$40');
const _WaveColor = goog.require('org.dominokit.domino.ui.style.WaveColor');
const _WaveStyle = goog.require('org.dominokit.domino.ui.style.WaveStyle');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var MenuItem = goog.require('org.dominokit.domino.ui.menu.MenuItem$impl');
exports = MenuItem;
 