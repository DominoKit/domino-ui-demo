package org.dominokit.domino.collapse.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.collapse.client.contributions.CollapsePresenterContributionToComponentsExtensionPoint;
import org.dominokit.domino.collapse.client.presenters.CollapsePresenter;
import org.dominokit.domino.collapse.client.presenters.CollapsePresenterCommand;
import org.dominokit.domino.collapse.client.views.ui.CollapseViewImpl;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class CollapseModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(CollapsePresenter.class.getCanonicalName(), CollapsePresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new CollapsePresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(CollapsePresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new CollapseViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(CollapsePresenterCommand.class.getCanonicalName(), CollapsePresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentsExtensionPoint.class, new CollapsePresenterContributionToComponentsExtensionPoint());
  }
}
