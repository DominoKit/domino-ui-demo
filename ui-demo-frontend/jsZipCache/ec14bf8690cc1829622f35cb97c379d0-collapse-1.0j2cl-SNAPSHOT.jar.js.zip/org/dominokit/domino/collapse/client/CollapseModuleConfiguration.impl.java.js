/**
 * @fileoverview transpiled from org.dominokit.domino.collapse.client.CollapseModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.collapse.client.CollapseModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.collapse.client.CollapseModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.collapse.client.CollapseModuleConfiguration.$2$impl');
let CollapsePresenterContributionToComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.collapse.client.contributions.CollapsePresenterContributionToComponentsExtensionPoint$impl');
let CollapsePresenter = goog.forwardDeclare('org.dominokit.domino.collapse.client.presenters.CollapsePresenter$impl');
let CollapsePresenterCommand = goog.forwardDeclare('org.dominokit.domino.collapse.client.presenters.CollapsePresenterCommand$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');


/**
 * @implements {ModuleConfiguration}
  */
class CollapseModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CollapseModuleConfiguration()'.
   * @return {!CollapseModuleConfiguration}
   * @public
   */
  static $create__() {
    CollapseModuleConfiguration.$clinit();
    let $instance = new CollapseModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_collapse_client_CollapseModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CollapseModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_collapse_client_CollapseModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_collapse_client_CollapseModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(CollapsePresenter).m_getCanonicalName__(), Class.$get(CollapsePresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_collapse_client_CollapseModuleConfiguration__java_lang_String(this, Class.$get(CollapsePresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(CollapsePresenterCommand).m_getCanonicalName__(), Class.$get(CollapsePresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(ComponentsExtensionPoint), CollapsePresenterContributionToComponentsExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CollapseModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CollapseModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CollapseModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.collapse.client.CollapseModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.collapse.client.CollapseModuleConfiguration.$2$impl');
    CollapsePresenterContributionToComponentsExtensionPoint = goog.module.get('org.dominokit.domino.collapse.client.contributions.CollapsePresenterContributionToComponentsExtensionPoint$impl');
    CollapsePresenter = goog.module.get('org.dominokit.domino.collapse.client.presenters.CollapsePresenter$impl');
    CollapsePresenterCommand = goog.module.get('org.dominokit.domino.collapse.client.presenters.CollapsePresenterCommand$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CollapseModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.collapse.client.CollapseModuleConfiguration'));


ModuleConfiguration.$markImplementor(CollapseModuleConfiguration);


exports = CollapseModuleConfiguration; 
//# sourceMappingURL=CollapseModuleConfiguration.js.map