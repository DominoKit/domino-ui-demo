/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let LoadersPresenter = goog.forwardDeclare('org.dominokit.domino.loaders.client.presenters.LoadersPresenter$impl');


/**
 * @extends {PresenterCommand<LoadersPresenter>}
  */
class LoadersPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LoadersPresenterCommand()'.
   * @return {!LoadersPresenterCommand}
   * @public
   */
  static $create__() {
    LoadersPresenterCommand.$clinit();
    let $instance = new LoadersPresenterCommand();
    $instance.$ctor__org_dominokit_domino_loaders_client_presenters_LoadersPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoadersPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_loaders_client_presenters_LoadersPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoadersPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoadersPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoadersPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LoadersPresenterCommand, $Util.$makeClassName('org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand'));




exports = LoadersPresenterCommand; 
//# sourceMappingURL=LoadersPresenterCommand.js.map