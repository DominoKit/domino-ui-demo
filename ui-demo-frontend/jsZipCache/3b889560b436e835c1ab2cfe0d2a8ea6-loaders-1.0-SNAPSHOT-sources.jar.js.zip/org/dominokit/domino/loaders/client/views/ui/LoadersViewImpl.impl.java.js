/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const LoadersView = goog.require('org.dominokit.domino.loaders.client.views.LoadersView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.loaders.client.views.CodeResource$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$1$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$LambdaAdaptor$1$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Loader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.Loader$impl');
let LoaderEffect = goog.forwardDeclare('org.dominokit.domino.ui.loaders.LoaderEffect$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {LoadersView}
  */
class LoadersViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'LoadersViewImpl()'.
   * @return {!LoadersViewImpl}
   * @public
   */
  static $create__() {
    LoadersViewImpl.$clinit();
    let $instance = new LoadersViewImpl();
    $instance.$ctor__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoadersViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("Loaders", "Use loaders to mask an element until some action is completed.").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let row = Row.m_create__();
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_.appendChild(row.m_asElement__());
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect, "Loading ... ", Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color, Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__()));
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect, "Loading ... ", Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color, Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__()));
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect, "Loading ... ", Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color, Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__()));
    let secondRow = Row.m_create__();
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_.appendChild(secondRow.m_asElement__());
    secondRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect, "Waiting ... ", Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color, Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__()));
    secondRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect, "Waiting ... ", Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color, Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__()));
    secondRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect, "Waiting ... ", Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color, Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__()));
    let thirdRow = Row.m_create__();
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_.appendChild(thirdRow.m_asElement__());
    thirdRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect, " ... ", Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color, Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__()));
    thirdRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect, " ... ", Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color, Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__()));
    thirdRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect, " ... ", Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color, Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__()));
    let fourthRow = Row.m_create__();
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_.appendChild(fourthRow.m_asElement__());
    fourthRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect, "", Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color, Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__()));
    fourthRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect, "", Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color, Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__()));
    fourthRow.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(LoaderEffect.f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect, "", Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color, Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__()));
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_loadersSample__()).m_asElement__());
  }
  
  /**
   * @param {LoaderEffect} effect
   * @param {?string} loadingText
   * @param {Color} bodyBackground
   * @param {Color} headerBackground
   * @return {Card}
   * @public
   */
  m_createCard__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__org_dominokit_domino_ui_style_Color__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl(effect, loadingText, bodyBackground, headerBackground) {
    let card = Card.m_create__java_lang_String__java_lang_String(effect.toString(), j_l_String.m_valueOf__java_lang_Object(j_l_String.m_toLowerCase__java_lang_String(effect.toString())) + " loader effect.").m_setBodyBackground__org_dominokit_domino_ui_style_Color(bodyBackground).m_setHeaderBackground__org_dominokit_domino_ui_style_Color(headerBackground);
    let loaderListener = new $LambdaAdaptor$1(((/** Event */ e) =>{
      let loader = Loader.m_create__elemental2_dom_HTMLElement__org_dominokit_domino_ui_loaders_LoaderEffect(card.m_asElement__(), effect).m_setLoadingText__java_lang_String(loadingText).m_start__();
      $1.$create__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl__org_dominokit_domino_ui_loaders_Loader(this, loader).m_schedule__int(7000);
    }));
    let button = Button.m_createDefault__java_lang_String("CLICK ME").m_addClickListener__elemental2_dom_EventListener(loaderListener);
    card.m_appendContent__elemental2_dom_Node(new Text(LoadersViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_)).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_attr__java_lang_String__java_lang_String("style", "text-align: center"), HtmlContentBuilder)).m_add__elemental2_dom_Node(button.m_asElement__()), HtmlContentBuilder)).m_asElement__());
    return card;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl() {
    this.f_element__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoadersViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoadersViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoadersViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeResource = goog.module.get('org.dominokit.domino.loaders.client.views.CodeResource$impl');
    $1 = goog.module.get('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$1$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl.$LambdaAdaptor$1$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Loader = goog.module.get('org.dominokit.domino.ui.loaders.Loader$impl');
    LoaderEffect = goog.module.get('org.dominokit.domino.ui.loaders.LoaderEffect$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LoadersViewImpl, $Util.$makeClassName('org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl'));


/** @public {?string} @const */
LoadersViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_loaders_client_views_ui_LoadersViewImpl_ = "Quis pharetra a pharetra fames blandit. Risus faucibus velit Risus imperdiet mattis neque volutpat, etiam lacinia netus dictum magnis per facilisi sociosqu. Volutpat. Ridiculus nostra.";


LoadersView.$markImplementor(LoadersViewImpl);


exports = LoadersViewImpl; 
//# sourceMappingURL=LoadersViewImpl.js.map