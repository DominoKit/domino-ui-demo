/**
 * @fileoverview transpiled from org.dominokit.domino.loaders.client.presenters.LoadersPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.loaders.client.presenters.LoadersPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.loaders.client.presenters.LoadersPresenter.$1$impl');
let LoadersView = goog.forwardDeclare('org.dominokit.domino.loaders.client.views.LoadersView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<LoadersView>}
  */
class LoadersPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LoadersPresenter()'.
   * @return {!LoadersPresenter}
   * @public
   */
  static $create__() {
    LoadersPresenter.$clinit();
    let $instance = new LoadersPresenter();
    $instance.$ctor__org_dominokit_domino_loaders_client_presenters_LoadersPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoadersPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_loaders_client_presenters_LoadersPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_loaders_client_presenters_LoadersPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_loaders_client_presenters_LoadersPresenter_() {
    return (LoadersPresenter.$clinit(), LoadersPresenter.$f_LOGGER__org_dominokit_domino_loaders_client_presenters_LoadersPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_loaders_client_presenters_LoadersPresenter_(value) {
    (LoadersPresenter.$clinit(), LoadersPresenter.$f_LOGGER__org_dominokit_domino_loaders_client_presenters_LoadersPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoadersPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoadersPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoadersPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.loaders.client.presenters.LoadersPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    LoadersPresenter.$f_LOGGER__org_dominokit_domino_loaders_client_presenters_LoadersPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LoadersPresenter));
  }
  
  
};

$Util.$setClassMetadata(LoadersPresenter, $Util.$makeClassName('org.dominokit.domino.loaders.client.presenters.LoadersPresenter'));


/** @private {Logger} */
LoadersPresenter.$f_LOGGER__org_dominokit_domino_loaders_client_presenters_LoadersPresenter_;




exports = LoadersPresenter; 
//# sourceMappingURL=LoadersPresenter.js.map