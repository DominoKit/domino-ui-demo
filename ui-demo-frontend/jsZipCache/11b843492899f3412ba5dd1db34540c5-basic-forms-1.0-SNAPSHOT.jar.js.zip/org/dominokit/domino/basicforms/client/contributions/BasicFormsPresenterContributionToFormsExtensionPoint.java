package org.dominokit.domino.basicforms.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand;
import org.dominokit.domino.forms.shared.extension.FormsExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class BasicFormsPresenterContributionToFormsExtensionPoint implements Contribution<FormsExtensionPoint> {
  @Override
  public void contribute(FormsExtensionPoint extensionPoint) {
    new BasicFormsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToMainModule(extensionPoint.context())).send();
  }
}
