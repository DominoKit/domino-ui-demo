/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.views.ui.BasicFormsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.basicforms.client.views.ui.BasicFormsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BasicFormsView = goog.require('org.dominokit.domino.basicforms.client.views.BasicFormsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginUnionType.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.basicforms.client.views.CodeResource$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let CheckBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox$impl');
let Radio = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio$impl');
let RadioGroup = goog.forwardDeclare('org.dominokit.domino.ui.forms.RadioGroup$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextArea = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {BasicFormsView}
  */
class BasicFormsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
    /** @public {Card} */
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
    /** @public {Card} */
    this.f_textAreaCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
    /** @public {Card} */
    this.f_selectCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
    /** @public {Card} */
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
    /** @public {Card} */
    this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
    /** @public {Card} */
    this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'BasicFormsViewImpl()'.
   * @return {!BasicFormsViewImpl}
   * @public
   */
  static $create__() {
    BasicFormsViewImpl.$clinit();
    let $instance = new BasicFormsViewImpl();
    $instance.$ctor__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BasicFormsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("BASIC FORM ELEMENTS").m_asElement__());
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = Card.m_create__java_lang_String__java_lang_String("INPUT", "Different sizes and widths.");
    this.f_textAreaCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = Card.m_create__java_lang_String("TEXTAREA");
    this.f_selectCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = Card.m_create__java_lang_String("SELECT");
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = Card.m_create__java_lang_String("CHECKBOX");
    this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = Card.m_create__java_lang_String("RADIO");
    this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = Card.m_create__java_lang_String("SWITCH BUTTONS");
    this.m_initBasicExamples___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initDifferentWidths___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initDifferentSizes___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initFloatingLabel___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initInputStatus___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initBasicTextAreaExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initSelectExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initCheckboxExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initRadioExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.m_initSwitchExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl();
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_textboxSamples__()).m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.f_textAreaCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_textareaSamples__()).m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.f_selectCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_selectSamples__()).m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_checkBoxSamples__()).m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_radioSamples__()).m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_switchSamples__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSwitchExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Basic Examples"), HtmlContentBuilder)).m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String__java_lang_String("OFF", "ON").m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {SwitchButton} */ ($Casts.$to(SwitchButton.m_create__java_lang_String("DISABLED").m_disable__(), SwitchButton)).m_asElement__())).m_asElement__());
    this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("With Material Design Colors"), HtmlContentBuilder)).m_asElement__());
    this.f_switchCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("RED").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("PINK").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("DEEP PURPLE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("INDIGO").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("BLUE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("CYAN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("TEAL").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("GREEN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("LIME").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("YELLOW").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("AMBER").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("ORANGE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(SwitchButton.m_create__java_lang_String("GREY").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initRadioExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    let column = Column.m_create__().m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_nine__org_dominokit_domino_ui_column_Column_OnSmall).m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_six__org_dominokit_domino_ui_column_Column_OnLarge);
    this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Basic Examples"), HtmlContentBuilder)).m_asElement__());
    let radio1 = Radio.m_create__java_lang_String__java_lang_String("radio1", "Radio - 1").m_check__();
    let radio2 = Radio.m_create__java_lang_String__java_lang_String("radio2", "Radio - 2");
    let radio1Gap = Radio.m_create__java_lang_String__java_lang_String("radio1_gap", "Radio 1 - With Gap").m_withGap__();
    let radio2Gap = Radio.m_create__java_lang_String__java_lang_String("radio2_gap", "Radio 2 - With Gap").m_withGap__();
    let horizontalRadioGroup = RadioGroup.m_create__java_lang_String("test").m_addRadio__org_dominokit_domino_ui_forms_Radio(radio1).m_addRadio__org_dominokit_domino_ui_forms_Radio(radio2).m_addRadio__org_dominokit_domino_ui_forms_Radio(radio1Gap).m_addRadio__org_dominokit_domino_ui_forms_Radio(radio2Gap).m_horizontal__();
    let firstDisabledRadio = Radio.m_create__java_lang_String__java_lang_String("radio1_disabled", "Radio - Disabled").m_check__().m_disable__();
    let secondsDisabledRadio = Radio.m_create__java_lang_String__java_lang_String("radio2_disabled", "Radio - Disabled").m_withGap__().m_check__().m_disable__();
    firstDisabledRadio.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    secondsDisabledRadio.m_asElement__().style.margin = $Overlay.m_of__java_lang_Object("5px");
    let firstDisabledGroup = RadioGroup.m_create__java_lang_String("disabled").m_addRadio__org_dominokit_domino_ui_forms_Radio(firstDisabledRadio);
    let secondDisabledGroup = RadioGroup.m_create__java_lang_String("disabled").m_addRadio__org_dominokit_domino_ui_forms_Radio(secondsDisabledRadio);
    this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(horizontalRadioGroup.m_asElement__()).m_addElement__elemental2_dom_Node(firstDisabledGroup.m_asElement__()).m_addElement__elemental2_dom_Node(secondDisabledGroup.m_asElement__())).m_asElement__());
    this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Elements.m_br__().m_asElement__());
    column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_two__org_dominokit_domino_ui_column_Column_OnLarge).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall);
    this.f_radioCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("With Material Design Colors"), HtmlContentBuilder)).m_asElement__()).m_addElement__elemental2_dom_Node(RadioGroup.m_create__java_lang_String("color").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("RED", "RED").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_check__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("PINK", "PINK").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("DEEP PURPLE", "DEEP PURPLE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("INDIGO", "INDIGO").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("BLUE", "BLUE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("CYAN", "CYAN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("TEAL", "TEAL").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("GREEN", "GREEN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("LIME", "LIME").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("YELLOW", "YELLOW").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("AMBER", "AMBER").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("ORANGE", "ORANGE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color)).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("GREY", "GREY").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("With Material Design Colors with gap"), HtmlContentBuilder)).m_asElement__()).m_addElement__elemental2_dom_Node(RadioGroup.m_create__java_lang_String("color-with-gap").m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("RED", "RED").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_withGap__().m_check__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("PINK", "PINK").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("DEEP PURPLE", "DEEP PURPLE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("INDIGO", "INDIGO").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("BLUE", "BLUE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("CYAN", "CYAN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("TEAL", "TEAL").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("GREEN", "GREEN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("LIME", "LIME").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("YELLOW", "YELLOW").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("AMBER", "AMBER").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("ORANGE", "ORANGE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_withGap__()).m_addRadio__org_dominokit_domino_ui_forms_Radio(Radio.m_create__java_lang_String__java_lang_String("GREY", "GREY").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_withGap__()).m_asElement__())).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initCheckboxExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_two__org_dominokit_domino_ui_column_Column_OnLarge).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall);
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Basic Examples"), HtmlContentBuilder)).m_asElement__());
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("Default").m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("Filled In").m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {CheckBox} */ ($Casts.$to(CheckBox.m_create__java_lang_String("Default - Disabled").m_check__().m_disable__(), CheckBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {CheckBox} */ ($Casts.$to(CheckBox.m_create__java_lang_String("Filled In - Disabled").m_check__().m_filledIn__().m_disable__(), CheckBox)).m_asElement__())).m_asElement__());
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("With Material Design Colors"), HtmlContentBuilder)).m_asElement__());
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("RED").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("PINK").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("DEEP PURPLE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("INDIGO").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("BLUE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("CYAN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("TEAL").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("GREEN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("LIME").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("YELLOW").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("AMBER").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("ORANGE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("GREY").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_check__().m_asElement__())).m_asElement__());
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("With Material Design Colors - Filled In"), HtmlContentBuilder)).m_asElement__());
    this.f_checkboxCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("RED").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("PINK").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("DEEP PURPLE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("INDIGO").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("BLUE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("CYAN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("TEAL").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("GREEN").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("LIME").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("YELLOW").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("AMBER").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("ORANGE").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(CheckBox.m_create__java_lang_String("GREY").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_check__().m_filledIn__().m_asElement__())).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSelectExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    let column = Column.m_create__().m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall);
    let select = Select.m_create__().m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("nothing", "-- please select --")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("value10", "10")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("value20", "20")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("value30", "30")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("value40", "40")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String__java_lang_String("value50", "50")).m_selectAt__int(0).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption */ option) =>{
      Notification.m_create__java_lang_String("Item selected [ " + j_l_String.m_valueOf__java_lang_Object(option.m_getValue__()) + " ], [ " + j_l_String.m_valueOf__java_lang_Object(option.m_getDisplayValue__()) + " ]").m_show__();
    })));
    this.f_selectCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(select.m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Select.m_create__().m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("Disabled")).m_selectAt__int(0).m_disable__().m_asElement__())).m_asElement__());
    this.f_selectCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Drop up example").m_asElement__());
    this.f_selectCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Select.m_create__().m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("-- please select --")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("10")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("20")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("30")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("40")).m_addOption__org_dominokit_domino_ui_forms_SelectOption(SelectOption.m_create__java_lang_String("50")).m_selectAt__int(0).m_dropup__().m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption */ option$1$) =>{
      Notification.m_create__java_lang_String("Item selected [ " + j_l_String.m_valueOf__java_lang_Object(option$1$.m_getValue__()) + " ]").m_show__();
    }))).m_asElement__())).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initBasicExamples___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Basic Example").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("Username"), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_password__().m_setPlaceholder__java_lang_String("Password"), TextBox)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDifferentWidths___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    let column6Size = Column.m_create__().m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall);
    let column4Size = Column.m_create__().m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_four__org_dominokit_domino_ui_column_Column_OnSmall);
    let column3Size = Column.m_create__().m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_three__org_dominokit_domino_ui_column_Column_OnSmall);
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Different Widths").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column6Size.m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-6"), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column6Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-6"), TextBox)).m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column4Size.m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-4"), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column4Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-4"), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column4Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-4"), TextBox)).m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column3Size.m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-3"), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column3Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-3"), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column3Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-3"), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column3Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("col-sm-3"), TextBox)).m_asElement__())).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDifferentSizes___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Different Sizes").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("Large Input"), TextBox)).m_large__(), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("Default Input"), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("Small Input"), TextBox)).m_small__(), TextBox)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFloatingLabel___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Floating Label Examples").m_asElement__()).m_appendContent__elemental2_dom_Node(TextBox.m_create__java_lang_String("Username").m_asElement__()).m_appendContent__elemental2_dom_Node(TextBox.m_password__java_lang_String("Password").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Large Input").m_large__(), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(TextBox.m_create__java_lang_String("Default Input").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Small Input").m_small__(), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Always floating").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Age").m_floating__(), TextBox)).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Email").m_floating__(), TextBox)).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initInputStatus___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    let column6Size = Column.m_create__().m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_six__org_dominokit_domino_ui_column_Column_OnSmall);
    this.f_inputCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Input Status").m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column6Size.m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Focused").m_focus__(), TextBox)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column6Size.m_copy__().m_addElement__elemental2_dom_Node(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Disabled").m_disable__(), TextBox)).m_asElement__())).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initBasicTextAreaExample___$p_org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    this.f_textAreaCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Basic Examples").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__().m_setPlaceholder__java_lang_String("Start typing here..."), TextArea)).m_asElement__());
    this.f_textAreaCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Auto Growing Vertical Direction").m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__().m_setPlaceholder__java_lang_String("Start typing here..."), TextArea)).m_autoSize__().m_asElement__());
    this.f_textAreaCard__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_.m_appendContent__elemental2_dom_Node(BlockHeader.m_create__java_lang_String("Text Area With Label").m_asElement__()).m_appendContent__elemental2_dom_Node(TextArea.m_create__java_lang_String("Description").m_autoSize__().m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl() {
    this.f_element__org_dominokit_domino_basicforms_client_views_ui_BasicFormsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BasicFormsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BasicFormsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BasicFormsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginUnionType.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeResource = goog.module.get('org.dominokit.domino.basicforms.client.views.CodeResource$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    CheckBox = goog.module.get('org.dominokit.domino.ui.forms.CheckBox$impl');
    Radio = goog.module.get('org.dominokit.domino.ui.forms.Radio$impl');
    RadioGroup = goog.module.get('org.dominokit.domino.ui.forms.RadioGroup$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextArea = goog.module.get('org.dominokit.domino.ui.forms.TextArea$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BasicFormsViewImpl, $Util.$makeClassName('org.dominokit.domino.basicforms.client.views.ui.BasicFormsViewImpl'));


BasicFormsView.$markImplementor(BasicFormsViewImpl);


exports = BasicFormsViewImpl; 
//# sourceMappingURL=BasicFormsViewImpl.js.map