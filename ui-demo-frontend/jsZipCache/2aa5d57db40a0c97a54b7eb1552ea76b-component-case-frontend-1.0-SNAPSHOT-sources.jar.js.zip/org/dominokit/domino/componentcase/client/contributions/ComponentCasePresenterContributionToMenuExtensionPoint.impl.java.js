/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
let ComponentCasePresenterCommand = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
let MenuContext = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
let MenuExtensionPoint = goog.forwardDeclare('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<MenuExtensionPoint>}
  */
class ComponentCasePresenterContributionToMenuExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCasePresenterContributionToMenuExtensionPoint()'.
   * @return {!ComponentCasePresenterContributionToMenuExtensionPoint}
   * @public
   */
  static $create__() {
    ComponentCasePresenterContributionToMenuExtensionPoint.$clinit();
    let $instance = new ComponentCasePresenterContributionToMenuExtensionPoint();
    $instance.$ctor__org_dominokit_domino_componentcase_client_contributions_ComponentCasePresenterContributionToMenuExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCasePresenterContributionToMenuExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_contributions_ComponentCasePresenterContributionToMenuExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {MenuExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint(extensionPoint) {
    ComponentCasePresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ComponentCasePresenter */ presenter) =>{
      presenter.m_contributeToMenuModule__org_dominokit_domino_menu_shared_extension_MenuContext(/**@type {MenuContext} */ ($Casts.$to(extensionPoint.m_context__(), MenuContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_menu_shared_extension_MenuExtensionPoint(/**@type {MenuExtensionPoint} */ ($Casts.$to(arg0, MenuExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCasePresenterContributionToMenuExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCasePresenterContributionToMenuExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCasePresenterContributionToMenuExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCasePresenterCommand = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
    MenuContext = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuContext$impl');
    MenuExtensionPoint = goog.module.get('org.dominokit.domino.menu.shared.extension.MenuExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCasePresenterContributionToMenuExtensionPoint, $Util.$makeClassName('org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint'));


Contribution.$markImplementor(ComponentCasePresenterContributionToMenuExtensionPoint);


exports = ComponentCasePresenterContributionToMenuExtensionPoint; 
//# sourceMappingURL=ComponentCasePresenterContributionToMenuExtensionPoint.js.map