/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$NoRootMenuException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.NoRootMenuException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');


class NoRootMenuException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ComponentCasePresenter} */
    this.f_$outer_this__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_NoRootMenuException;
  }
  
  /**
   * Factory method corresponding to constructor 'NoRootMenuException(ComponentCasePresenter, String)'.
   * @param {ComponentCasePresenter} $outer_this
   * @param {?string} message
   * @return {!NoRootMenuException}
   * @public
   */
  static $create__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String($outer_this, message) {
    NoRootMenuException.$clinit();
    let $instance = new NoRootMenuException();
    $instance.$ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_NoRootMenuException__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String($outer_this, message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NoRootMenuException(ComponentCasePresenter, String)'.
   * @param {ComponentCasePresenter} $outer_this
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_NoRootMenuException__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter__java_lang_String($outer_this, message) {
    this.f_$outer_this__org_dominokit_domino_componentcase_client_presenters_ComponentCasePresenter_NoRootMenuException = $outer_this;
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NoRootMenuException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NoRootMenuException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NoRootMenuException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NoRootMenuException, $Util.$makeClassName('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$NoRootMenuException'));




exports = NoRootMenuException; 
//# sourceMappingURL=ComponentCasePresenter$NoRootMenuException.js.map