/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToLayoutExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToLayoutExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
let ComponentCasePresenterCommand = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<LayoutExtensionPoint>}
  */
class ComponentCasePresenterContributionToLayoutExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCasePresenterContributionToLayoutExtensionPoint()'.
   * @return {!ComponentCasePresenterContributionToLayoutExtensionPoint}
   * @public
   */
  static $create__() {
    ComponentCasePresenterContributionToLayoutExtensionPoint.$clinit();
    let $instance = new ComponentCasePresenterContributionToLayoutExtensionPoint();
    $instance.$ctor__org_dominokit_domino_componentcase_client_contributions_ComponentCasePresenterContributionToLayoutExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCasePresenterContributionToLayoutExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_contributions_ComponentCasePresenterContributionToLayoutExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(extensionPoint) {
    ComponentCasePresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ComponentCasePresenter */ presenter) =>{
      presenter.m_contributeToLayoutModule__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(extensionPoint.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(/**@type {LayoutExtensionPoint} */ ($Casts.$to(arg0, LayoutExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCasePresenterContributionToLayoutExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCasePresenterContributionToLayoutExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCasePresenterContributionToLayoutExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCasePresenterCommand = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutExtensionPoint = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCasePresenterContributionToLayoutExtensionPoint, $Util.$makeClassName('org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToLayoutExtensionPoint'));


Contribution.$markImplementor(ComponentCasePresenterContributionToLayoutExtensionPoint);


exports = ComponentCasePresenterContributionToLayoutExtensionPoint; 
//# sourceMappingURL=ComponentCasePresenterContributionToLayoutExtensionPoint.js.map