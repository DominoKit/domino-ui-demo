package org.dominokit.domino.componentcase.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand;
import org.dominokit.domino.menu.shared.extension.MenuExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class ComponentCasePresenterContributionToMenuExtensionPoint implements Contribution<MenuExtensionPoint> {
  @Override
  public void contribute(MenuExtensionPoint extensionPoint) {
    new ComponentCasePresenterCommand().onPresenterReady(presenter -> presenter.contributeToMenuModule(extensionPoint.context())).send();
  }
}
