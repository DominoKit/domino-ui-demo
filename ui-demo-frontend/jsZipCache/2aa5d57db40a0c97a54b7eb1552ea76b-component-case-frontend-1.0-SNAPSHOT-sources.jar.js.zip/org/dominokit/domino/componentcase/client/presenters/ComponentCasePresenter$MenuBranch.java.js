/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$MenuBranch.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.MenuBranch');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _ComponentCasePresenter = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter');
const _CanAddMenuItem = goog.require('org.dominokit.domino.menu.shared.extension.MenuContext.CanAddMenuItem');


// Re-exports the implementation.
var MenuBranch = goog.require('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter.MenuBranch$impl');
exports = MenuBranch;
 