package org.dominokit.domino.componentcase.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToLayoutExtensionPoint;
import org.dominokit.domino.componentcase.client.contributions.ComponentCasePresenterContributionToMenuExtensionPoint;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand;
import org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint;
import org.dominokit.domino.menu.shared.extension.MenuExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class ComponentCaseModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(ComponentCasePresenter.class.getCanonicalName(), ComponentCasePresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new ComponentCasePresenter();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(ComponentCasePresenterCommand.class.getCanonicalName(), ComponentCasePresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(LayoutExtensionPoint.class, new ComponentCasePresenterContributionToLayoutExtensionPoint());
    registry.registerContribution(MenuExtensionPoint.class, new ComponentCasePresenterContributionToMenuExtensionPoint());
  }
}
