package org.dominokit.domino.componentcase.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenterCommand;
import org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class ComponentCasePresenterContributionToLayoutExtensionPoint implements Contribution<LayoutExtensionPoint> {
  @Override
  public void contribute(LayoutExtensionPoint extensionPoint) {
    new ComponentCasePresenterCommand().onPresenterReady(presenter -> presenter.contributeToLayoutModule(extensionPoint.context())).send();
  }
}
