/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.views.CodeResource.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.labels.client.views.CodeResource');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var CodeResource = goog.require('org.dominokit.domino.labels.client.views.CodeResource$impl');
exports = CodeResource;
 