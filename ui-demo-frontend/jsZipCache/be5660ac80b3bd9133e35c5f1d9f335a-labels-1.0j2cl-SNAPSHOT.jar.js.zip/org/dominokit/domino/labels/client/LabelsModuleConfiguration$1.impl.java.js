/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.LabelsModuleConfiguration$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.LabelsModuleConfiguration.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');

let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let LabelsModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.labels.client.LabelsModuleConfiguration$impl');
let LabelsPresenter = goog.forwardDeclare('org.dominokit.domino.labels.client.presenters.LabelsPresenter$impl');


class $1 extends LazyPresenterLoader {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {LabelsModuleConfiguration} */
    this.f_$outer_this__org_dominokit_domino_labels_client_LabelsModuleConfiguration_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new LazyPresenterLoader(LabelsModuleConfiguration, String, String)'.
   * @param {LabelsModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @param {?string} $_1
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_labels_client_LabelsModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_labels_client_LabelsModuleConfiguration_1__org_dominokit_domino_labels_client_LabelsModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new LazyPresenterLoader(LabelsModuleConfiguration, String, String)'.
   * @param {LabelsModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @param {?string} $_1
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_LabelsModuleConfiguration_1__org_dominokit_domino_labels_client_LabelsModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1) {
    this.f_$outer_this__org_dominokit_domino_labels_client_LabelsModuleConfiguration_1 = $outer_this;
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader__java_lang_String__java_lang_String($_0, $_1);
  }
  
  /**
   * @override
   * @return {Presentable}
   * @public
   */
  m_make__() {
    return LabelsPresenter.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    LabelsPresenter = goog.module.get('org.dominokit.domino.labels.client.presenters.LabelsPresenter$impl');
    LazyPresenterLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.labels.client.LabelsModuleConfiguration$1'));




exports = $1; 
//# sourceMappingURL=LabelsModuleConfiguration$1.js.map