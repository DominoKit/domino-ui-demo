/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.presenters.LabelsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.presenters.LabelsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let LabelsPresenter = goog.forwardDeclare('org.dominokit.domino.labels.client.presenters.LabelsPresenter$impl');


/**
 * @extends {PresenterCommand<LabelsPresenter>}
  */
class LabelsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LabelsPresenterCommand()'.
   * @return {!LabelsPresenterCommand}
   * @public
   */
  static $create__() {
    LabelsPresenterCommand.$clinit();
    let $instance = new LabelsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_labels_client_presenters_LabelsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LabelsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_presenters_LabelsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LabelsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LabelsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LabelsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LabelsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.labels.client.presenters.LabelsPresenterCommand'));




exports = LabelsPresenterCommand; 
//# sourceMappingURL=LabelsPresenterCommand.js.map