/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_labels_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_initLabels__() {
    CodeResource.$clinit();
    return "Label.createDefault(\"DEFAULT\").asElement();\n" + "Label.createPrimary(\"PRIMARY\").asElement();\n" + "Label.createSuccess(\"SUCCESS\").asElement();\n" + "Label.createInfo(\"INFO\").asElement();\n" + "Label.createWarning(\"WARNING\").asElement();\n" + "Label.createDanger(\"DANGER\").asElement();";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_initMaterialLabels__() {
    CodeResource.$clinit();
    return "Label.create(\"Red\").setBackground(Color.RED).asElement();\n" + "Label.create(\"Pink\").setBackground(Color.PINK).asElement();\n" + "Label.create(\"Purple\").setBackground(Color.PURPLE).asElement();\n" + "Label.create(\"Deep Purple\").setBackground(Color.DEEP_PURPLE).asElement();\n" + "Label.create(\"Indigo\").setBackground(Color.INDIGO).asElement();\n" + "Label.create(\"Blue\").setBackground(Color.BLUE).asElement();\n" + "Label.create(\"Light Blue\").setBackground(Color.LIGHT_BLUE).asElement();\n" + "Label.create(\"Cyan\").setBackground(Color.CYAN).asElement();\n" + "Label.create(\"Teal\").setBackground(Color.TEAL).asElement();";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.labels.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map