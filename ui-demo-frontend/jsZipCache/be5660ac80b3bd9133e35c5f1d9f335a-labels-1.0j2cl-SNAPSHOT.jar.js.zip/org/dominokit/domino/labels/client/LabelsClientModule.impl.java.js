/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.LabelsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.LabelsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class LabelsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LabelsClientModule()'.
   * @return {!LabelsClientModule}
   * @public
   */
  static $create__() {
    LabelsClientModule.$clinit();
    let $instance = new LabelsClientModule();
    $instance.$ctor__org_dominokit_domino_labels_client_LabelsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LabelsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_LabelsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    LabelsClientModule.$f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_.m_info__java_lang_String("Initializing Labels frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_() {
    return (LabelsClientModule.$clinit(), LabelsClientModule.$f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_(value) {
    (LabelsClientModule.$clinit(), LabelsClientModule.$f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LabelsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LabelsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LabelsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    LabelsClientModule.$f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LabelsClientModule));
  }
  
  
};

$Util.$setClassMetadata(LabelsClientModule, $Util.$makeClassName('org.dominokit.domino.labels.client.LabelsClientModule'));


/** @private {Logger} */
LabelsClientModule.$f_LOGGER__org_dominokit_domino_labels_client_LabelsClientModule_;




exports = LabelsClientModule; 
//# sourceMappingURL=LabelsClientModule.js.map