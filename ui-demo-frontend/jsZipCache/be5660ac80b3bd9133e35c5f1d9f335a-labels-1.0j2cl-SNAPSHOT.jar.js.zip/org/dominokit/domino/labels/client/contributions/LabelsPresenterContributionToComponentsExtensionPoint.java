package org.dominokit.domino.labels.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.labels.client.presenters.LabelsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class LabelsPresenterContributionToComponentsExtensionPoint implements Contribution<ComponentsExtensionPoint> {
  @Override
  public void contribute(ComponentsExtensionPoint extensionPoint) {
    new LabelsPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentsModule(extensionPoint.context())).send();
  }
}
