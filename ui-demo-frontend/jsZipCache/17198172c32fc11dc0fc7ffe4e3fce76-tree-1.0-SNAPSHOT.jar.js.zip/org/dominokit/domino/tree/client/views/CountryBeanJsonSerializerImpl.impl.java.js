/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Country$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl.$2$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<Country>}
  */
class CountryBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CountryBeanJsonSerializerImpl()'.
   * @return {!CountryBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    CountryBeanJsonSerializerImpl.$clinit();
    let $instance = new CountryBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CountryBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(Country);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([2], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__java_lang_String(this, "name"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__java_lang_String(this, "cities"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CountryBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CountryBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CountryBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Country = goog.module.get('org.dominokit.domino.tree.client.views.Country$impl');
    $1 = goog.module.get('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl.$2$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CountryBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl'));




exports = CountryBeanJsonSerializerImpl; 
//# sourceMappingURL=CountryBeanJsonSerializerImpl.js.map