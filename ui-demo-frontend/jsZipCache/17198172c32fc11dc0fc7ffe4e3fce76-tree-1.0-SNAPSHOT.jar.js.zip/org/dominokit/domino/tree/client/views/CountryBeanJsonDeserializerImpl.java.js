/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Country = goog.require('org.dominokit.domino.tree.client.views.Country');
const _$1 = goog.require('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$1');
const _$2 = goog.require('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$3');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var CountryBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl$impl');
exports = CountryBeanJsonDeserializerImpl;
 