/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.Countries_MapperImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.Countries_MapperImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper$impl');

let Countries = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Countries$impl');
let CountriesBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl$impl');
let CountriesBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');


/**
 * @extends {AbstractObjectMapper<Countries>}
  */
class Countries__MapperImpl extends AbstractObjectMapper {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Countries_MapperImpl()'.
   * @return {!Countries__MapperImpl}
   * @public
   */
  static $create__() {
    Countries__MapperImpl.$clinit();
    let $instance = new Countries__MapperImpl();
    $instance.$ctor__org_dominokit_domino_tree_client_views_Countries_MapperImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Countries_MapperImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_Countries_MapperImpl__() {
    this.$ctor__org_dominokit_jacksonapt_AbstractObjectMapper__java_lang_String("Countries");
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return CountriesBeanJsonSerializerImpl.$create__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<Countries>}
   * @public
   */
  m_newDeserializer__() {
    return CountriesBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @return {Countries__MapperImpl}
   * @public
   */
  static get f_INSTANCE__org_dominokit_domino_tree_client_views_Countries_MapperImpl() {
    return (Countries__MapperImpl.$clinit(), Countries__MapperImpl.$f_INSTANCE__org_dominokit_domino_tree_client_views_Countries_MapperImpl);
  }
  
  /**
   * @param {Countries__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_domino_tree_client_views_Countries_MapperImpl(value) {
    (Countries__MapperImpl.$clinit(), Countries__MapperImpl.$f_INSTANCE__org_dominokit_domino_tree_client_views_Countries_MapperImpl = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Countries__MapperImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Countries__MapperImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Countries__MapperImpl.$clinit = function() {};
    CountriesBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl$impl');
    CountriesBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl$impl');
    AbstractObjectMapper.$clinit();
    Countries__MapperImpl.$f_INSTANCE__org_dominokit_domino_tree_client_views_Countries_MapperImpl = Countries__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(Countries__MapperImpl, $Util.$makeClassName('org.dominokit.domino.tree.client.views.Countries_MapperImpl'));


/** @private {Countries__MapperImpl} */
Countries__MapperImpl.$f_INSTANCE__org_dominokit_domino_tree_client_views_Countries_MapperImpl;




exports = Countries__MapperImpl; 
//# sourceMappingURL=Countries_MapperImpl.js.map