package org.dominokit.domino.tree.client.views;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.deser.collection.ListJsonDeserializer;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class CountryBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Country> {
  public CountryBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Country.class;
  }

  @Override
  protected InstanceBuilder<Country> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Country>() {
      @Override
      public Instance<Country> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Country>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Country create() {
        return new Country();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Country, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Country, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("name", new BeanPropertyDeserializer<Country, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Country bean, String value, JsonDeserializationContext ctx) {
        bean.setName(value);
      }
    });
    map.put("cities", new BeanPropertyDeserializer<Country, List<String>>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return ListJsonDeserializer.newInstance(StringJsonDeserializer.getInstance());
      }

      @Override
      public void setValue(Country bean, List<String> value, JsonDeserializationContext ctx) {
        bean.setCities(value);
      }
    });
    return map;
  }
}
