/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.ui.TreeViewImpl$$LambdaAdaptor$24.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$24$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$24 extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor$24($JsFunction)'.
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$24.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_$LambdaAdaptor$24;
    this.$ctor__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_$LambdaAdaptor$24__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor$24($JsFunction)'.
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_$LambdaAdaptor$24__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_$LambdaAdaptor$24 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_$LambdaAdaptor$24;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$24;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$24);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$24.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$24, $Util.$makeClassName('org.dominokit.domino.tree.client.views.ui.TreeViewImpl$$LambdaAdaptor$24'));




exports = $LambdaAdaptor$24; 
//# sourceMappingURL=TreeViewImpl$$LambdaAdaptor$24.js.map