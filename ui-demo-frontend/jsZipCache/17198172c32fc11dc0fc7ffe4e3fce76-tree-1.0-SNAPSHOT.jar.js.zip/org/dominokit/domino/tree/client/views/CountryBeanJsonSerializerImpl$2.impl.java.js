/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Collection = goog.forwardDeclare('java.util.Collection$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Country$impl');
let CountryBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let CollectionJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.CollectionJsonSerializer$impl');
let StringJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Country, List<?string>>}
  */
class $2 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {CountryBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(CountryBeanJsonSerializerImpl, String)'.
   * @param {CountryBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl_2__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(CountryBeanJsonSerializerImpl, String)'.
   * @param {CountryBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl_2__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_tree_client_views_CountryBeanJsonSerializerImpl_2 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return /**@type {CollectionJsonSerializer<Collection<*>, ?>} */ (CollectionJsonSerializer.m_newInstance__org_dominokit_jacksonapt_JsonSerializer(StringJsonSerializer.m_getInstance__()));
  }
  
  /**
   * @param {Country} bean
   * @param {JsonSerializationContext} ctx
   * @return {List<?string>}
   * @public
   */
  m_getValue__org_dominokit_domino_tree_client_views_Country__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getCities__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {List<?string>}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_tree_client_views_Country__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Country} */ ($Casts.$to(arg0, Country)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    Country = goog.module.get('org.dominokit.domino.tree.client.views.Country$impl');
    CollectionJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.CollectionJsonSerializer$impl');
    StringJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.StringJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl$2'));




exports = $2; 
//# sourceMappingURL=CountryBeanJsonSerializerImpl$2.js.map