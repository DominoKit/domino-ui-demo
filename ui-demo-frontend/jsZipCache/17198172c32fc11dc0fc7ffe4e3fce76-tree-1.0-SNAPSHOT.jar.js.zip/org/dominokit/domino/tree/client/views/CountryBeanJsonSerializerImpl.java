package org.dominokit.domino.tree.client.views;

import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.CollectionJsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class CountryBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Country> {
  public CountryBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Country.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[2];
    result[0] = new BeanPropertySerializer<Country, String>("name") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Country bean, JsonSerializationContext ctx) {
        return bean.getName();
      }
    };
    result[1] = new BeanPropertySerializer<Country, List<String>>("cities") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return CollectionJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      }

      @Override
      public List<String> getValue(Country bean, JsonSerializationContext ctx) {
        return bean.getCities();
      }
    };
    return result;
  }
}
