/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.Countries.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.Countries$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Countries__MapperImpl = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Countries_MapperImpl$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Country$impl');


class Countries extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {List<Country>} */
    this.f_countries__org_dominokit_domino_tree_client_views_Countries_;
  }
  
  /**
   * Factory method corresponding to constructor 'Countries()'.
   * @return {!Countries}
   * @public
   */
  static $create__() {
    Countries.$clinit();
    let $instance = new Countries();
    $instance.$ctor__org_dominokit_domino_tree_client_views_Countries__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Countries()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_Countries__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {List<Country>}
   * @public
   */
  m_getCountries__() {
    return this.f_countries__org_dominokit_domino_tree_client_views_Countries_;
  }
  
  /**
   * @param {List<Country>} countries
   * @return {void}
   * @public
   */
  m_setCountries__java_util_List(countries) {
    this.f_countries__org_dominokit_domino_tree_client_views_Countries_ = countries;
  }
  
  /**
   * @return {Countries__MapperImpl}
   * @public
   */
  static get f_MAPPER__org_dominokit_domino_tree_client_views_Countries() {
    return (Countries.$clinit(), Countries.$f_MAPPER__org_dominokit_domino_tree_client_views_Countries);
  }
  
  /**
   * @param {Countries__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_MAPPER__org_dominokit_domino_tree_client_views_Countries(value) {
    (Countries.$clinit(), Countries.$f_MAPPER__org_dominokit_domino_tree_client_views_Countries = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Countries;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Countries);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Countries.$clinit = function() {};
    Countries__MapperImpl = goog.module.get('org.dominokit.domino.tree.client.views.Countries_MapperImpl$impl');
    j_l_Object.$clinit();
    Countries.$f_MAPPER__org_dominokit_domino_tree_client_views_Countries = Countries__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(Countries, $Util.$makeClassName('org.dominokit.domino.tree.client.views.Countries'));


/** @private {Countries__MapperImpl} */
Countries.$f_MAPPER__org_dominokit_domino_tree_client_views_Countries;




exports = Countries; 
//# sourceMappingURL=Countries.js.map