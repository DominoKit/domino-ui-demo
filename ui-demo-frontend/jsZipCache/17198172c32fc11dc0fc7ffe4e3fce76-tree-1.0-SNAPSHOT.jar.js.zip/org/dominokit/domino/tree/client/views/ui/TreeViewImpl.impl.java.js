/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.ui.TreeViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.ui.TreeViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const TreeView = goog.require('org.dominokit.domino.tree.client.views.TreeView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Countries = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Countries$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Country$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$17$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$18$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$20$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$22$impl');
let $LambdaAdaptor$23 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$23$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$24$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$25$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$26$impl');
let $LambdaAdaptor$27 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$27$impl');
let $LambdaAdaptor$28 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$28$impl');
let $LambdaAdaptor$29 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$29$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$30 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$30$impl');
let $LambdaAdaptor$31 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$31$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$9$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Tree = goog.forwardDeclare('org.dominokit.domino.ui.tree.Tree$impl');
let TreeItem = goog.forwardDeclare('org.dominokit.domino.ui.tree.TreeItem$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {TreeView}
  */
class TreeViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'TreeViewImpl()'.
   * @return {!TreeViewImpl}
   * @public
   */
  static $create__() {
    TreeViewImpl.$clinit();
    let $instance = new TreeViewImpl();
    $instance.$ctor__org_dominokit_domino_tree_client_views_ui_TreeViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TreeViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_ui_TreeViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_tree_client_views_ui_TreeViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(TreeViewImpl.f_MODULE_NAME__org_dominokit_domino_tree_client_views_ui_TreeViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("Tree").m_asElement__());
    this.m_simpleTree___$p_org_dominokit_domino_tree_client_views_ui_TreeViewImpl();
    this.m_nestedTree___$p_org_dominokit_domino_tree_client_views_ui_TreeViewImpl();
    this.m_activeAndExpandIcons___$p_org_dominokit_domino_tree_client_views_ui_TreeViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_simpleTree___$p_org_dominokit_domino_tree_client_views_ui_TreeViewImpl() {
    let hardwareTree = Tree.m_create__java_lang_String("HARDWARE").m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Computer", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_computer__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      Notification.m_create__java_lang_String("Computer").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Headset", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_headset__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      Notification.m_create__java_lang_String("Headset").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Keyboard", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      Notification.m_create__java_lang_String("Keyboard").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Mouse", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_mouse__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt$3$) =>{
      Notification.m_create__java_lang_String("Mouse").m_show__();
    })))).m_addSeparator__().m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Laptop", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_laptop__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$5(((/** Event */ evt$4$) =>{
      Notification.m_create__java_lang_String("Laptop").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Smart phone", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_smartphone__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$6(((/** Event */ evt$5$) =>{
      Notification.m_create__java_lang_String("Smart phone").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Tablet", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_tablet__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$7(((/** Event */ evt$6$) =>{
      Notification.m_create__java_lang_String("Tablet").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Speaker", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_speaker__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$8(((/** Event */ evt$7$) =>{
      Notification.m_create__java_lang_String("Speaker").m_show__();
    }))));
    let filesTree = Tree.m_create__java_lang_String("FILES").m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$9(((/** Event */ evt$8$) =>{
      Notification.m_create__java_lang_String("Folder").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder open", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$10(((/** Event */ evt$9$) =>{
      Notification.m_create__java_lang_String("Folder open").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Upload", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_file_upload__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$11(((/** Event */ evt$10$) =>{
      Notification.m_create__java_lang_String("Upload").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Download", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_file_download__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$12(((/** Event */ evt$11$) =>{
      Notification.m_create__java_lang_String("Download").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("New folder", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_create_new_folder__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$13(((/** Event */ evt$12$) =>{
      Notification.m_create__java_lang_String("New folder").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Shared", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_shared__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$14(((/** Event */ evt$13$) =>{
      Notification.m_create__java_lang_String("Shared").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Attachments", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$15(((/** Event */ evt$14$) =>{
      Notification.m_create__java_lang_String("Attachments").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Cloud", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$16(((/** Event */ evt$15$) =>{
      Notification.m_create__java_lang_String("Cloud").m_show__();
    }))));
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(Card.m_create__java_lang_String("SIMPLE MENU").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(hardwareTree), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(filesTree), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TreeViewImpl.f_MODULE_NAME__org_dominokit_domino_tree_client_views_ui_TreeViewImpl, "simpleTree").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_nestedTree___$p_org_dominokit_domino_tree_client_views_ui_TreeViewImpl() {
    let hardwareTree = Tree.m_create__java_lang_String("HARDWARE").m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Computer", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_desktop_windows__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$17(((/** Event */ evt) =>{
      Notification.m_create__java_lang_String("Computer").m_show__();
    }))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Headset", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_headset__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$18(((/** Event */ evt$1$) =>{
      Notification.m_create__java_lang_String("Headset").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Keyboard", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$19(((/** Event */ evt$2$) =>{
      Notification.m_create__java_lang_String("Keyboard").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Mouse", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_mouse__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$20(((/** Event */ evt$3$) =>{
      Notification.m_create__java_lang_String("Mouse").m_show__();
    }))))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Laptop", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_laptop__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$21(((/** Event */ evt$4$) =>{
      Notification.m_create__java_lang_String("Laptop").m_show__();
    }))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Chromebook", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_laptop_chromebook__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$22(((/** Event */ evt$5$) =>{
      Notification.m_create__java_lang_String("Chromebook").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("MacBook", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_laptop_mac__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$23(((/** Event */ evt$6$) =>{
      Notification.m_create__java_lang_String("MacBook").m_show__();
    }))))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Smart phone", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_smartphone__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$24(((/** Event */ evt$7$) =>{
      Notification.m_create__java_lang_String("Smart phone").m_show__();
    }))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Tablet", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_tablet__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$25(((/** Event */ evt$8$) =>{
      Notification.m_create__java_lang_String("Tablet").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Android", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_phone_android__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$26(((/** Event */ evt$9$) =>{
      Notification.m_create__java_lang_String("Android").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("iPhone", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_phone_iphone__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$27(((/** Event */ evt$10$) =>{
      Notification.m_create__java_lang_String("iPhone").m_show__();
    })))));
    let hardwareMenu2 = Tree.m_create__java_lang_String("FILES").m_setAutoCollapse__boolean(false).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("My files", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_special__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$28(((/** Event */ evt$11$) =>{
      Notification.m_create__java_lang_String("File 1").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$29(((/** Event */ evt$12$) =>{
      Notification.m_create__java_lang_String("File 2").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$30(((/** Event */ evt$13$) =>{
      Notification.m_create__java_lang_String("File 3").m_show__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$31(((/** Event */ evt$14$) =>{
      Notification.m_create__java_lang_String("File 4").m_show__();
    }))))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Upload", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_file_upload__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Download", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_file_download__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("New folder", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_create_new_folder__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Shared", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_shared__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Attachments", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__()))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Cloud", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Upload", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_upload__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Download", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_download__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Offline", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_off__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Queue", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_cloud_queue__())));
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(Card.m_create__java_lang_String("SIMPLE NESTED MENU").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Auto collapse")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(hardwareTree), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Auto collapse OFF")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(hardwareMenu2), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TreeViewImpl.f_MODULE_NAME__org_dominokit_domino_tree_client_views_ui_TreeViewImpl, "nestedTree").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_activeAndExpandIcons___$p_org_dominokit_domino_tree_client_views_ui_TreeViewImpl() {
    let countries = /**@type {Countries} */ ($Casts.$to(Countries.f_MAPPER__org_dominokit_domino_tree_client_views_Countries.m_read__java_lang_String(TreeViewImpl.f_COUNTRIES__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_), Countries)).m_getCountries__();
    let citiesTree = Tree.m_create__java_lang_String("CITIES").m_setAutoCollapse__boolean(false).m_enableFolding__().m_enableSearch__().m_autoExpandFound__();
    countries.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Country */ country) =>{
      let countryItem = TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(country.m_getName__(), Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_map__());
      citiesTree.m_appendChild__org_dominokit_domino_ui_tree_TreeItem(countryItem);
      country.m_getCities__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ?string */ city) =>{
        let cityItem = TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(city, Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_city__());
        countryItem.m_appendChild__org_dominokit_domino_ui_tree_TreeItem(cityItem);
      })));
    })));
    let foldersExpand = Tree.m_create__java_lang_String("FILES").m_setAutoCollapse__boolean(false).m_enableFolding__().m_enableSearch__().m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 1-1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 1-2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 2-1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 2-2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 3-1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_expand__()).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Folder 3-2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder__()).m_setExpandIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_folder_open__()).m_expand__().m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 1", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 2", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 3", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("File 4", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_setActiveIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__())).m_expand__()).m_expand__());
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(Card.m_create__java_lang_String("ACTIVE/EXPAND ICONS, SEARCH & FOLDING").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Active icon")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(citiesTree), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Expand icon")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(foldersExpand), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(TreeViewImpl.f_MODULE_NAME__org_dominokit_domino_tree_client_views_ui_TreeViewImpl, "featuredTree").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_tree_client_views_ui_TreeViewImpl() {
    this.f_element__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TreeViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TreeViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TreeViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Countries = goog.module.get('org.dominokit.domino.tree.client.views.Countries$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$17$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$18$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$20$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$22$impl');
    $LambdaAdaptor$23 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$23$impl');
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$24$impl');
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$25$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$26$impl');
    $LambdaAdaptor$27 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$27$impl');
    $LambdaAdaptor$28 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$28$impl');
    $LambdaAdaptor$29 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$29$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$30 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$30$impl');
    $LambdaAdaptor$31 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$31$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.tree.client.views.ui.TreeViewImpl.$LambdaAdaptor$9$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Tree = goog.module.get('org.dominokit.domino.ui.tree.Tree$impl');
    TreeItem = goog.module.get('org.dominokit.domino.ui.tree.TreeItem$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TreeViewImpl, $Util.$makeClassName('org.dominokit.domino.tree.client.views.ui.TreeViewImpl'));


/** @public {?string} @const */
TreeViewImpl.f_MODULE_NAME__org_dominokit_domino_tree_client_views_ui_TreeViewImpl = "tree";


/** @public {?string} @const */
TreeViewImpl.f_COUNTRIES__org_dominokit_domino_tree_client_views_ui_TreeViewImpl_ = "{\n  \"countries\": [\n    {\n      \"name\": \"Andorra\",\n      \"cities\": [\n        \"Andorra la Vella\",\n        \"Canillo\",\n        \"Encamp\",\n        \"La Massana\",\n        \"Escaldes-Engordany\",\n        \"Ordino\",\n        \"Sant Julia de Loria\"\n      ]\n    },\n    {\n\n      \"name\": \"United Arab Emirates\",\n      \"cities\": [\n        \"Abu Dhabi\",\n        \"'Ajman\",\n        \"Al Fujayrah\",\n        \"Ash Shariqah (Sharjah)\",\n        \"Dubayy (Dubai)\",\n        \"Ra's al Khaymah\",\n        \"Umm al Qaywayn\"\n      ]\n    },\n    {\n\n      \"name\": \"Afghanistan\",\n      \"cities\": [\n        \"Kabul\",\n        \"Badakhshan\",\n        \"Farah\",\n        \"Khowst\",\n        \"Konar\",\n        \"Kondoz\",\n        \"Paktika\",\n        \"Parvan\",\n        \"Samangan\",\n        \"Sar-e Pol\",\n        \"Takhar\",\n        \"Vardak\",\n        \"Zabol\"\n      ]\n    },\n    {\n      \"name\": \"Anguilla\",\n      \"cities\": [\n        \"The Valley\"\n      ]\n    },\n\n    {\n      \"name\": \"Cameroon\",\n      \"cities\": [\n        \"Yaounde\",\n        \"Adamaoua\",\n        \"Centre\",\n        \"Est\",\n        \"Extreme-Nord\",\n        \"Littoral\",\n        \"Nord\",\n        \"Nord-Ouest\",\n        \"Ouest\",\n        \"Sud\",\n        \"Sud-Ouest\"\n      ]\n    },\n    {\n      \"name\": \"China\",\n      \"cities\": [\n        \"Beijing\",\n        \"Anhui\",\n        \"Chongqing\",\n        \"Fujian\",\n        \"Gansu\",\n        \"Guangdong\",\n        \"Guangxi\",\n        \"Guizhou\",\n        \"Jiangsu\",\n        \"Jiangxi\",\n        \"Jilin\",\n        \"Liaoning\",\n        \"Nei Mongol\",\n        \"Ningxia\",\n        \"Qinghai\",\n        \"Shaanxi\",\n        \"Shandong\",\n        \"Shanghai\",\n        \"Shanxi\",\n        \"Sichuan\",\n        \"Tianjin\",\n        \"Xinjiang\",\n        \"Xizang (Tibet)\",\n        \"Yunnan\",\n        \"Zhejiang\"\n      ]\n    },\n    {\n      \"name\": \"Colombia\",\n      \"cities\": [\n        \"Bogota\",\n        \"Amazonas\",\n        \"Antioquia\",\n        \"Arauca\",\n        \"Atlantico\",\n        \"Bolivar\",\n        \"Boyaca\",\n        \"Cundinamarca\",\n        \"Guaviare\",\n        \"Huila\",\n        \"La Guajira\",\n        \"Meta\",\n        \"Norte de Santander\",\n        \"Putumayo\",\n        \"Quindio\",\n        \"Risaralda\",\n        \"Santander\",\n        \"Sucre\",\n        \"Tolima\",\n        \"Vichada\"\n      ]\n    },\n    {\n      \"name\": \"Costa Rica\",\n      \"cities\": [\n        \"San Jose\",\n        \"Alajuela\",\n        \"Cartago\",\n        \"Guanacaste\",\n        \"Heredia\",\n        \"Limon\",\n        \"Puntarenas\"\n      ]\n    },\n    {\n      \"name\": \"Germany\",\n      \"cities\": [\n        \"Berlin\",\n        \"Baden-Wuerttemberg\",\n        \"Bayern\",\n        \"Berlin\",\n        \"Brandenburg\",\n        \"Bremen\",\n        \"Hamburg\",\n        \"Hessen\",\n        \"Mecklenburg-Vorpommern\",\n        \"Niedersachsen\",\n        \"Nordrhein-Westfalen\",\n        \"Rheinland-Pfalz\",\n        \"Saarland\",\n        \"Sachsen\",\n        \"Sachsen-Anhalt\",\n        \"Schleswig-Holstein\",\n        \"Thueringen\"\n      ]\n    },\n    {\n      \"name\": \"Djibouti\",\n      \"cities\": [\n        \"Djibouti\",\n        \"'Ali Sabih\",\n        \"Dikhil\",\n        \"Obock\",\n        \"Tadjoura\"\n      ]\n    },\n    {\n      \"name\": \"Denmark\",\n      \"cities\": [\n        \"Copenhagen (Kobenhavn)\",\n        \"Arhus\",\n        \"Bornholm\",\n        \"Fredericksberg\",\n        \"Frederiksborg\",\n        \"Fyn\",\n        \"Kobenhavns\",\n        \"Nordjylland\",\n        \"Ribe\",\n        \"Ringkobing\",\n        \"Roskilde\",\n        \"Sonderjylland\",\n        \"Storstrom\",\n        \"Vejle\",\n        \"Vestsjalland\",\n        \"Viborg\"\n      ]\n    },\n    {\n      \"name\": \"Dominica\",\n      \"cities\": [\n        \"Roseau\",\n        \"Saint Andrew\",\n        \"Saint David\",\n        \"Saint George\"\n      ]\n    }\n  ]\n}";


TreeView.$markImplementor(TreeViewImpl);


exports = TreeViewImpl; 
//# sourceMappingURL=TreeViewImpl.js.map