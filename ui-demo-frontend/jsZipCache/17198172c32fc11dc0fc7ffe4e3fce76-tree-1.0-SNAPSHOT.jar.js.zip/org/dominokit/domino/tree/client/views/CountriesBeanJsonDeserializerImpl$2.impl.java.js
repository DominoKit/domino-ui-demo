/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Countries = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Countries$impl');
let CountriesBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Country$impl');
let CountryBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let ListJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.collection.ListJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Countries, List<Country>>}
  */
class $2 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {CountriesBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(CountriesBeanJsonDeserializerImpl)'.
   * @param {CountriesBeanJsonDeserializerImpl} $outer_this
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl($outer_this) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl_2__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(CountriesBeanJsonDeserializerImpl)'.
   * @param {CountriesBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl_2__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl_2 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return /**@type {ListJsonDeserializer<Country>} */ (ListJsonDeserializer.m_newInstance__org_dominokit_jacksonapt_JsonDeserializer(CountryBeanJsonDeserializerImpl.$create__()));
  }
  
  /**
   * @param {Countries} bean
   * @param {List<Country>} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_tree_client_views_Countries__java_util_List__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setCountries__java_util_List(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_tree_client_views_Countries__java_util_List__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Countries} */ ($Casts.$to(arg0, Countries)), /**@type {List<Country>} */ ($Casts.$to(arg1, List)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    List = goog.module.get('java.util.List$impl');
    Countries = goog.module.get('org.dominokit.domino.tree.client.views.Countries$impl');
    CountryBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl$impl');
    ListJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.collection.ListJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl$2'));




exports = $2; 
//# sourceMappingURL=CountriesBeanJsonDeserializerImpl$2.js.map