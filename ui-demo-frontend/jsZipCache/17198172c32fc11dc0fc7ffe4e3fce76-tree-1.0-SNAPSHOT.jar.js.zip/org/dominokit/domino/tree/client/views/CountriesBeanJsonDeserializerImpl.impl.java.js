/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Countries = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Countries$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl.$2$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Countries>}
  */
class CountriesBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CountriesBeanJsonDeserializerImpl()'.
   * @return {!CountriesBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    CountriesBeanJsonDeserializerImpl.$clinit();
    let $instance = new CountriesBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CountriesBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Countries);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Countries>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Countries, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Countries, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("countries", $2.$create__org_dominokit_domino_tree_client_views_CountriesBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CountriesBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CountriesBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CountriesBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Countries = goog.module.get('org.dominokit.domino.tree.client.views.Countries$impl');
    $1 = goog.module.get('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl.$2$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CountriesBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.tree.client.views.CountriesBeanJsonDeserializerImpl'));




exports = CountriesBeanJsonDeserializerImpl; 
//# sourceMappingURL=CountriesBeanJsonDeserializerImpl.js.map