/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.Countries.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tree.client.views.Countries');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _List = goog.require('java.util.List');
const _Countries__MapperImpl = goog.require('org.dominokit.domino.tree.client.views.Countries_MapperImpl');
const _Country = goog.require('org.dominokit.domino.tree.client.views.Country');


// Re-exports the implementation.
var Countries = goog.require('org.dominokit.domino.tree.client.views.Countries$impl');
exports = Countries;
 