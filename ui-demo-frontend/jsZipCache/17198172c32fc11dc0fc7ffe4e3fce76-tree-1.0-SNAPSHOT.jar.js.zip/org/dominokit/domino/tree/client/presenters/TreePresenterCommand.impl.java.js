/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.presenters.TreePresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.presenters.TreePresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let TreePresenter = goog.forwardDeclare('org.dominokit.domino.tree.client.presenters.TreePresenter$impl');


/**
 * @extends {PresenterCommand<TreePresenter>}
  */
class TreePresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TreePresenterCommand()'.
   * @return {!TreePresenterCommand}
   * @public
   */
  static $create__() {
    TreePresenterCommand.$clinit();
    let $instance = new TreePresenterCommand();
    $instance.$ctor__org_dominokit_domino_tree_client_presenters_TreePresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TreePresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_presenters_TreePresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TreePresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TreePresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TreePresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TreePresenterCommand, $Util.$makeClassName('org.dominokit.domino.tree.client.presenters.TreePresenterCommand'));




exports = TreePresenterCommand; 
//# sourceMappingURL=TreePresenterCommand.js.map