package org.dominokit.domino.tree.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.tree.client.presenters.TreePresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class TreePresenterListenerForComponentsEvent implements DominoEventListener<ComponentsEvent> {
  @Override
  public void listen(ComponentsEvent event) {
    new TreePresenterCommand().onPresenterReady(presenter -> presenter.listenToComponentsEvent(event.context())).send();
  }
}
