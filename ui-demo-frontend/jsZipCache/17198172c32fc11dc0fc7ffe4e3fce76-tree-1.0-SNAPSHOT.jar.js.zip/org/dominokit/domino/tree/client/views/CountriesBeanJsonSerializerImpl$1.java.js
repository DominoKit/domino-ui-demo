/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Collection = goog.require('java.util.Collection');
const _List = goog.require('java.util.List');
const _Countries = goog.require('org.dominokit.domino.tree.client.views.Countries');
const _CountriesBeanJsonSerializerImpl = goog.require('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl');
const _Country = goog.require('org.dominokit.domino.tree.client.views.Country');
const _CountryBeanJsonSerializerImpl = goog.require('org.dominokit.domino.tree.client.views.CountryBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _CollectionJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.CollectionJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl.$1$impl');
exports = $1;
 