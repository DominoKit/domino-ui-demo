/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.TreeModuleConfiguration$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.TreeModuleConfiguration.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');

let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let TreeModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.tree.client.TreeModuleConfiguration$impl');
let TreePresenter = goog.forwardDeclare('org.dominokit.domino.tree.client.presenters.TreePresenter$impl');


class $1 extends LazyPresenterLoader {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TreeModuleConfiguration} */
    this.f_$outer_this__org_dominokit_domino_tree_client_TreeModuleConfiguration_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new LazyPresenterLoader(TreeModuleConfiguration, String, String)'.
   * @param {TreeModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @param {?string} $_1
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_tree_client_TreeModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_tree_client_TreeModuleConfiguration_1__org_dominokit_domino_tree_client_TreeModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new LazyPresenterLoader(TreeModuleConfiguration, String, String)'.
   * @param {TreeModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @param {?string} $_1
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_TreeModuleConfiguration_1__org_dominokit_domino_tree_client_TreeModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1) {
    this.f_$outer_this__org_dominokit_domino_tree_client_TreeModuleConfiguration_1 = $outer_this;
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader__java_lang_String__java_lang_String($_0, $_1);
  }
  
  /**
   * @override
   * @return {Presentable}
   * @public
   */
  m_make__() {
    return TreePresenter.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    TreePresenter = goog.module.get('org.dominokit.domino.tree.client.presenters.TreePresenter$impl');
    LazyPresenterLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.tree.client.TreeModuleConfiguration$1'));




exports = $1; 
//# sourceMappingURL=TreeModuleConfiguration$1.js.map