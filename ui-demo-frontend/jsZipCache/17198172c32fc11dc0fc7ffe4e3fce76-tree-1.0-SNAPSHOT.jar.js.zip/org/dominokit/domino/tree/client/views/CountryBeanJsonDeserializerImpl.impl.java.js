/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.tree.client.views.Country$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$3$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Country>}
  */
class CountryBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CountryBeanJsonDeserializerImpl()'.
   * @return {!CountryBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    CountryBeanJsonDeserializerImpl.$clinit();
    let $instance = new CountryBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_tree_client_views_CountryBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CountryBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_CountryBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Country);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Country>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_tree_client_views_CountryBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Country, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Country, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("name", $2.$create__org_dominokit_domino_tree_client_views_CountryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("cities", $3.$create__org_dominokit_domino_tree_client_views_CountryBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CountryBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CountryBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CountryBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Country = goog.module.get('org.dominokit.domino.tree.client.views.Country$impl');
    $1 = goog.module.get('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl.$3$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CountryBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.tree.client.views.CountryBeanJsonDeserializerImpl'));




exports = CountryBeanJsonDeserializerImpl; 
//# sourceMappingURL=CountryBeanJsonDeserializerImpl.js.map