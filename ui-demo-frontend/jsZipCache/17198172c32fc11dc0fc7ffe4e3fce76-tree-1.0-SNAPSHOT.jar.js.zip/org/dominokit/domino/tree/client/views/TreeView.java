package org.dominokit.domino.tree.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface TreeView extends View, DemoView {
}