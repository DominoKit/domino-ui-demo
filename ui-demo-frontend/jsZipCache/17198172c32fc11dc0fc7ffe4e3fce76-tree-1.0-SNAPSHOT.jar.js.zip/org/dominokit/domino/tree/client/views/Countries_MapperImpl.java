package org.dominokit.domino.tree.client.views;

import java.lang.Override;
import org.dominokit.jacksonapt.AbstractObjectMapper;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonSerializer;

public final class Countries_MapperImpl extends AbstractObjectMapper<Countries> {
  public static final Countries_MapperImpl INSTANCE = new Countries_MapperImpl();

  public Countries_MapperImpl() {
    super("Countries");
  }

  @Override
  protected JsonSerializer<?> newSerializer() {
    return new CountriesBeanJsonSerializerImpl();
  }

  @Override
  protected JsonDeserializer<Countries> newDeserializer() {
    return new CountriesBeanJsonDeserializerImpl();
  }
}
