/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.TreeModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.TreeModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.tree.client.TreeModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.tree.client.TreeModuleConfiguration.$2$impl');
let TreePresenterListenerForComponentsEvent = goog.forwardDeclare('org.dominokit.domino.tree.client.listeners.TreePresenterListenerForComponentsEvent$impl');
let TreePresenter = goog.forwardDeclare('org.dominokit.domino.tree.client.presenters.TreePresenter$impl');
let TreePresenterCommand = goog.forwardDeclare('org.dominokit.domino.tree.client.presenters.TreePresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class TreeModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TreeModuleConfiguration()'.
   * @return {!TreeModuleConfiguration}
   * @public
   */
  static $create__() {
    TreeModuleConfiguration.$clinit();
    let $instance = new TreeModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_tree_client_TreeModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TreeModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_TreeModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_tree_client_TreeModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(TreePresenter).m_getCanonicalName__(), Class.$get(TreePresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_tree_client_TreeModuleConfiguration__java_lang_String(this, Class.$get(TreePresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(TreePresenterCommand).m_getCanonicalName__(), Class.$get(TreePresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentsEvent), TreePresenterListenerForComponentsEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TreeModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TreeModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TreeModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    $1 = goog.module.get('org.dominokit.domino.tree.client.TreeModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.tree.client.TreeModuleConfiguration.$2$impl');
    TreePresenterListenerForComponentsEvent = goog.module.get('org.dominokit.domino.tree.client.listeners.TreePresenterListenerForComponentsEvent$impl');
    TreePresenter = goog.module.get('org.dominokit.domino.tree.client.presenters.TreePresenter$impl');
    TreePresenterCommand = goog.module.get('org.dominokit.domino.tree.client.presenters.TreePresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TreeModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.tree.client.TreeModuleConfiguration'));


ModuleConfiguration.$markImplementor(TreeModuleConfiguration);


exports = TreeModuleConfiguration; 
//# sourceMappingURL=TreeModuleConfiguration.js.map