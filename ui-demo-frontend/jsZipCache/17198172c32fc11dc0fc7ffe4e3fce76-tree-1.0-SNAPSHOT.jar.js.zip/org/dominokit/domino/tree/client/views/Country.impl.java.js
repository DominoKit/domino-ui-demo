/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.Country.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.views.Country$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');


class Country extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_dominokit_domino_tree_client_views_Country_;
    /** @public {List<?string>} */
    this.f_cities__org_dominokit_domino_tree_client_views_Country_;
  }
  
  /**
   * Factory method corresponding to constructor 'Country()'.
   * @return {!Country}
   * @public
   */
  static $create__() {
    Country.$clinit();
    let $instance = new Country();
    $instance.$ctor__org_dominokit_domino_tree_client_views_Country__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Country()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_Country__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * Factory method corresponding to constructor 'Country(String)'.
   * @param {?string} name
   * @return {!Country}
   * @public
   */
  static $create__java_lang_String(name) {
    Country.$clinit();
    let $instance = new Country();
    $instance.$ctor__org_dominokit_domino_tree_client_views_Country__java_lang_String(name);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Country(String)'.
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_views_Country__java_lang_String(name) {
    this.$ctor__java_lang_Object__();
    this.f_name__org_dominokit_domino_tree_client_views_Country_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_tree_client_views_Country_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_domino_tree_client_views_Country_ = name;
  }
  
  /**
   * @return {List<?string>}
   * @public
   */
  m_getCities__() {
    return this.f_cities__org_dominokit_domino_tree_client_views_Country_;
  }
  
  /**
   * @param {List<?string>} cities
   * @return {void}
   * @public
   */
  m_setCities__java_util_List(cities) {
    this.f_cities__org_dominokit_domino_tree_client_views_Country_ = cities;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Country;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Country);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Country.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Country, $Util.$makeClassName('org.dominokit.domino.tree.client.views.Country'));




exports = Country; 
//# sourceMappingURL=Country.js.map