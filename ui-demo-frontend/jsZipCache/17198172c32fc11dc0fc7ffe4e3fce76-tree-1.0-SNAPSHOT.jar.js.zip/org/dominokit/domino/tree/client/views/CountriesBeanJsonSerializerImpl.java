package org.dominokit.domino.tree.client.views;

import java.lang.Class;
import java.lang.Override;
import java.util.List;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.CollectionJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class CountriesBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Countries> {
  public CountriesBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Countries.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[1];
    result[0] = new BeanPropertySerializer<Countries, List<Country>>("countries") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return CollectionJsonSerializer.newInstance(new CountryBeanJsonSerializerImpl());
      }

      @Override
      public List<Country> getValue(Countries bean, JsonSerializationContext ctx) {
        return bean.getCountries();
      }
    };
    return result;
  }
}
