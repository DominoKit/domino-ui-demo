/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.presenters.TreePresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.tree.client.presenters.TreePresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.tree.client.presenters.TreePresenter.$1$impl');
let TreeView = goog.forwardDeclare('org.dominokit.domino.tree.client.views.TreeView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<TreeView>}
  */
class TreePresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TreePresenter()'.
   * @return {!TreePresenter}
   * @public
   */
  static $create__() {
    TreePresenter.$clinit();
    let $instance = new TreePresenter();
    $instance.$ctor__org_dominokit_domino_tree_client_presenters_TreePresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TreePresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_tree_client_presenters_TreePresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_listenToComponentsEvent__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_tree_client_presenters_TreePresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_tree_client_presenters_TreePresenter_() {
    return (TreePresenter.$clinit(), TreePresenter.$f_LOGGER__org_dominokit_domino_tree_client_presenters_TreePresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_tree_client_presenters_TreePresenter_(value) {
    (TreePresenter.$clinit(), TreePresenter.$f_LOGGER__org_dominokit_domino_tree_client_presenters_TreePresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TreePresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TreePresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TreePresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.tree.client.presenters.TreePresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    TreePresenter.$f_LOGGER__org_dominokit_domino_tree_client_presenters_TreePresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(TreePresenter));
  }
  
  
};

$Util.$setClassMetadata(TreePresenter, $Util.$makeClassName('org.dominokit.domino.tree.client.presenters.TreePresenter'));


/** @private {Logger} */
TreePresenter.$f_LOGGER__org_dominokit_domino_tree_client_presenters_TreePresenter_;




exports = TreePresenter; 
//# sourceMappingURL=TreePresenter.js.map