/**
 * @fileoverview transpiled from org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer');
const _Class = goog.require('java.lang.Class');
const _Countries = goog.require('org.dominokit.domino.tree.client.views.Countries');
const _$1 = goog.require('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl.$1');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var CountriesBeanJsonSerializerImpl = goog.require('org.dominokit.domino.tree.client.views.CountriesBeanJsonSerializerImpl$impl');
exports = CountriesBeanJsonSerializerImpl;
 