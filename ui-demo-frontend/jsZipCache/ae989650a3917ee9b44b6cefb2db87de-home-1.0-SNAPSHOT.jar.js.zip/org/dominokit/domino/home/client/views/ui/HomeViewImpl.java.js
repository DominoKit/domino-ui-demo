/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.views.ui.HomeViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.home.client.views.ui.HomeViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _HomeView = goog.require('org.dominokit.domino.home.client.views.HomeView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var HomeViewImpl = goog.require('org.dominokit.domino.home.client.views.ui.HomeViewImpl$impl');
exports = HomeViewImpl;
 