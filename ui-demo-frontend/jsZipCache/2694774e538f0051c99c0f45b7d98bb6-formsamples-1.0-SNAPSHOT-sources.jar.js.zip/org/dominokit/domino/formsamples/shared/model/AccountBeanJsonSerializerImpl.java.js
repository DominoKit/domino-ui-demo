/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer');
const _Class = goog.require('java.lang.Class');
const _Account = goog.require('org.dominokit.domino.formsamples.shared.model.Account');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$1');
const _$10 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$10');
const _$11 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$11');
const _$12 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$12');
const _$13 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$13');
const _$14 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$14');
const _$15 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$15');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$5');
const _$6 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$6');
const _$7 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$7');
const _$8 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$8');
const _$9 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$9');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var AccountBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl$impl');
exports = AccountBeanJsonSerializerImpl;
 