package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class AccountBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Account> {
  public AccountBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Account.class;
  }

  @Override
  protected InstanceBuilder<Account> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Account>() {
      @Override
      public Instance<Account> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Account>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Account create() {
        return new Account();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Account, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Account, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("accountAlias", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setAccountAlias(value);
      }
    });
    map.put("accountState", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setAccountState(value);
      }
    });
    map.put("country", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setCountry(value);
      }
    });
    map.put("processInstanceId", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setProcessInstanceId(value);
      }
    });
    map.put("updatedBy", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setUpdatedBy(value);
      }
    });
    map.put("bicCode", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setBicCode(value);
      }
    });
    map.put("updatedDate", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setUpdatedDate(value);
      }
    });
    map.put("accountNumber", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setAccountNumber(value);
      }
    });
    map.put("bank", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setBank(value);
      }
    });
    map.put("createdDate", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setCreatedDate(value);
      }
    });
    map.put("createdBy", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setCreatedBy(value);
      }
    });
    map.put("iban", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setIban(value);
      }
    });
    map.put("tenantId", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setTenantId(value);
      }
    });
    map.put("currency", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setCurrency(value);
      }
    });
    map.put("id", new BeanPropertyDeserializer<Account, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Account bean, String value, JsonDeserializationContext ctx) {
        bean.setId(value);
      }
    });
    return map;
  }
}
