package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class AccountBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Account> {
  public AccountBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Account.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[15];
    result[0] = new BeanPropertySerializer<Account, String>("accountAlias") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getAccountAlias();
      }
    };
    result[1] = new BeanPropertySerializer<Account, String>("accountState") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getAccountState();
      }
    };
    result[2] = new BeanPropertySerializer<Account, String>("country") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getCountry();
      }
    };
    result[3] = new BeanPropertySerializer<Account, String>("processInstanceId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getProcessInstanceId();
      }
    };
    result[4] = new BeanPropertySerializer<Account, String>("updatedBy") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getUpdatedBy();
      }
    };
    result[5] = new BeanPropertySerializer<Account, String>("bicCode") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getBicCode();
      }
    };
    result[6] = new BeanPropertySerializer<Account, String>("updatedDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getUpdatedDate();
      }
    };
    result[7] = new BeanPropertySerializer<Account, String>("accountNumber") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getAccountNumber();
      }
    };
    result[8] = new BeanPropertySerializer<Account, String>("bank") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getBank();
      }
    };
    result[9] = new BeanPropertySerializer<Account, String>("createdDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getCreatedDate();
      }
    };
    result[10] = new BeanPropertySerializer<Account, String>("createdBy") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getCreatedBy();
      }
    };
    result[11] = new BeanPropertySerializer<Account, String>("iban") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getIban();
      }
    };
    result[12] = new BeanPropertySerializer<Account, String>("tenantId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getTenantId();
      }
    };
    result[13] = new BeanPropertySerializer<Account, String>("currency") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getCurrency();
      }
    };
    result[14] = new BeanPropertySerializer<Account, String>("id") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Account bean, JsonSerializationContext ctx) {
        return bean.getId();
      }
    };
    return result;
  }
}
