/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Address = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Address$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$14$impl');
let $15 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$15$impl');
let $16 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$16$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$9$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Address>}
  */
class AddressBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AddressBeanJsonDeserializerImpl()'.
   * @return {!AddressBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    AddressBeanJsonDeserializerImpl.$clinit();
    let $instance = new AddressBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AddressBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Address);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Address>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Address, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Address, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("processInstanceId", $2.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("zipCode", $3.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedBy", $4.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("city", $5.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("countryISOCode", $6.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedDate", $7.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdDate", $8.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("mailBox", $9.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdBy", $10.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("street", $11.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("tenantId", $12.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("id", $13.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("apartment", $14.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("phoneNumber", $15.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("faxNumber", $16.$create__org_dominokit_domino_formsamples_shared_model_AddressBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AddressBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AddressBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AddressBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Address = goog.module.get('org.dominokit.domino.formsamples.shared.model.Address$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$14$impl');
    $15 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$15$impl');
    $16 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$16$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$9$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AddressBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl'));




exports = AddressBeanJsonDeserializerImpl; 
//# sourceMappingURL=AddressBeanJsonDeserializerImpl.js.map