/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Address.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Address$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Address extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_zipCode__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_city__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_countryISOCode__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_mailBox__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_street__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_id__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_apartment__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_phoneNumber__org_dominokit_domino_formsamples_shared_model_Address_;
    /** @public {?string} */
    this.f_faxNumber__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * Factory method corresponding to constructor 'Address()'.
   * @return {!Address}
   * @public
   */
  static $create__() {
    Address.$clinit();
    let $instance = new Address();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Address__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Address()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Address__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} processInstanceId
   * @return {void}
   * @public
   */
  m_setProcessInstanceId__java_lang_String(processInstanceId) {
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Address_ = processInstanceId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getProcessInstanceId__() {
    return this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} zipCode
   * @return {void}
   * @public
   */
  m_setZipCode__java_lang_String(zipCode) {
    this.f_zipCode__org_dominokit_domino_formsamples_shared_model_Address_ = zipCode;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getZipCode__() {
    return this.f_zipCode__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} updatedBy
   * @return {void}
   * @public
   */
  m_setUpdatedBy__java_lang_String(updatedBy) {
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Address_ = updatedBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedBy__() {
    return this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} city
   * @return {void}
   * @public
   */
  m_setCity__java_lang_String(city) {
    this.f_city__org_dominokit_domino_formsamples_shared_model_Address_ = city;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCity__() {
    return this.f_city__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} countryISOCode
   * @return {void}
   * @public
   */
  m_setCountryISOCode__java_lang_String(countryISOCode) {
    this.f_countryISOCode__org_dominokit_domino_formsamples_shared_model_Address_ = countryISOCode;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCountryISOCode__() {
    return this.f_countryISOCode__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} updatedDate
   * @return {void}
   * @public
   */
  m_setUpdatedDate__java_lang_String(updatedDate) {
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Address_ = updatedDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedDate__() {
    return this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} createdDate
   * @return {void}
   * @public
   */
  m_setCreatedDate__java_lang_String(createdDate) {
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Address_ = createdDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedDate__() {
    return this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} mailBox
   * @return {void}
   * @public
   */
  m_setMailBox__java_lang_String(mailBox) {
    this.f_mailBox__org_dominokit_domino_formsamples_shared_model_Address_ = mailBox;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getMailBox__() {
    return this.f_mailBox__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} createdBy
   * @return {void}
   * @public
   */
  m_setCreatedBy__java_lang_String(createdBy) {
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Address_ = createdBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedBy__() {
    return this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} street
   * @return {void}
   * @public
   */
  m_setStreet__java_lang_String(street) {
    this.f_street__org_dominokit_domino_formsamples_shared_model_Address_ = street;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStreet__() {
    return this.f_street__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} tenantId
   * @return {void}
   * @public
   */
  m_setTenantId__java_lang_String(tenantId) {
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Address_ = tenantId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTenantId__() {
    return this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} id
   * @return {void}
   * @public
   */
  m_setId__java_lang_String(id) {
    this.f_id__org_dominokit_domino_formsamples_shared_model_Address_ = id;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getId__() {
    return this.f_id__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} apartment
   * @return {void}
   * @public
   */
  m_setApartment__java_lang_String(apartment) {
    this.f_apartment__org_dominokit_domino_formsamples_shared_model_Address_ = apartment;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getApartment__() {
    return this.f_apartment__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPhoneNumber__() {
    return this.f_phoneNumber__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} phoneNumber
   * @return {void}
   * @public
   */
  m_setPhoneNumber__java_lang_String(phoneNumber) {
    this.f_phoneNumber__org_dominokit_domino_formsamples_shared_model_Address_ = phoneNumber;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getFaxNumber__() {
    return this.f_faxNumber__org_dominokit_domino_formsamples_shared_model_Address_;
  }
  
  /**
   * @param {?string} faxNumber
   * @return {void}
   * @public
   */
  m_setFaxNumber__java_lang_String(faxNumber) {
    this.f_faxNumber__org_dominokit_domino_formsamples_shared_model_Address_ = faxNumber;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Address;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Address);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Address.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Address, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Address'));




exports = Address; 
//# sourceMappingURL=Address.js.map