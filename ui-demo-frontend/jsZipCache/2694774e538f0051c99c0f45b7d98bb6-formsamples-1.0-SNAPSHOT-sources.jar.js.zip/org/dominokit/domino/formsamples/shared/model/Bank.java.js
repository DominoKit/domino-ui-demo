/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Bank.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Bank');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _List = goog.require('java.util.List');
const _Address = goog.require('org.dominokit.domino.formsamples.shared.model.Address');
const _Bank__MapperImpl = goog.require('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl');
const _Branch = goog.require('org.dominokit.domino.formsamples.shared.model.Branch');
const _ContactPerson = goog.require('org.dominokit.domino.formsamples.shared.model.ContactPerson');


// Re-exports the implementation.
var Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank$impl');
exports = Bank;
 