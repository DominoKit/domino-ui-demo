/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$3.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$3');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _Applicant = goog.require('org.dominokit.domino.formsamples.shared.model.Applicant');
const _ApplicantBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl');
const _FeesAndChargesSettlementAccount = goog.require('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount');
const _FeesAndChargesSettlementAccountBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccountBeanJsonDeserializerImpl');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $3 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$3$impl');
exports = $3;
 