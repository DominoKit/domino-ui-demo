package org.dominokit.domino.formsamples.shared.model;

import java.lang.Override;
import org.dominokit.jacksonapt.AbstractObjectMapper;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonSerializer;

public final class Bank_MapperImpl extends AbstractObjectMapper<Bank> {
  public static final Bank_MapperImpl INSTANCE = new Bank_MapperImpl();

  public Bank_MapperImpl() {
    super("Bank");
  }

  @Override
  protected JsonSerializer<?> newSerializer() {
    return new BankBeanJsonSerializerImpl();
  }

  @Override
  protected JsonDeserializer<Bank> newDeserializer() {
    return new BankBeanJsonDeserializerImpl();
  }
}
