/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Applicant = goog.require('org.dominokit.domino.formsamples.shared.model.Applicant');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$1');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$5');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var ApplicantBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$impl');
exports = ApplicantBeanJsonDeserializerImpl;
 