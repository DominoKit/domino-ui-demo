package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.deser.collection.ListJsonDeserializer;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class BankBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Bank> {
  public BankBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Bank.class;
  }

  @Override
  protected InstanceBuilder<Bank> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Bank>() {
      @Override
      public Instance<Bank> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Bank>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Bank create() {
        return new Bank();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Bank, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Bank, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("address", new BeanPropertyDeserializer<Bank, Address>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return new AddressBeanJsonDeserializerImpl();
      }

      @Override
      public void setValue(Bank bean, Address value, JsonDeserializationContext ctx) {
        bean.setAddress(value);
      }
    });
    map.put("contactPerson", new BeanPropertyDeserializer<Bank, ContactPerson>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return new ContactPersonBeanJsonDeserializerImpl();
      }

      @Override
      public void setValue(Bank bean, ContactPerson value, JsonDeserializationContext ctx) {
        bean.setContactPerson(value);
      }
    });
    map.put("name", new BeanPropertyDeserializer<Bank, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Bank bean, String value, JsonDeserializationContext ctx) {
        bean.setName(value);
      }
    });
    map.put("shortName", new BeanPropertyDeserializer<Bank, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Bank bean, String value, JsonDeserializationContext ctx) {
        bean.setShortName(value);
      }
    });
    map.put("swiftCode", new BeanPropertyDeserializer<Bank, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Bank bean, String value, JsonDeserializationContext ctx) {
        bean.setSwiftCode(value);
      }
    });
    map.put("branches", new BeanPropertyDeserializer<Bank, List<Branch>>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return ListJsonDeserializer.newInstance(new BranchBeanJsonDeserializerImpl());
      }

      @Override
      public void setValue(Bank bean, List<Branch> value, JsonDeserializationContext ctx) {
        bean.setBranches(value);
      }
    });
    return map;
  }
}
