/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Integer = goog.require('java.lang.Integer');
const _AirwayBill = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBill');
const _AirwayBillBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _IntegerJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.BaseNumberJsonSerializer.IntegerJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$2$impl');
exports = $2;
 