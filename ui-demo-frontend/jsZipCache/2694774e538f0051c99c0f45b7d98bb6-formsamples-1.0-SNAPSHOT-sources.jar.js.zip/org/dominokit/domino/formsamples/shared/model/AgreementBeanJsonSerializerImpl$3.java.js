/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl$3.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl.$3');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Agreement = goog.require('org.dominokit.domino.formsamples.shared.model.Agreement');
const _AgreementBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _StringJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.StringJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $3 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonSerializerImpl.$3$impl');
exports = $3;
 