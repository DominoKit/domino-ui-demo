package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class ApplicantBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Applicant> {
  public ApplicantBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Applicant.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[4];
    result[0] = new BeanPropertySerializer<Applicant, LcSettlementAccount>("lcSettlementAccount") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return new LcSettlementAccountBeanJsonSerializerImpl();
      }

      @Override
      public LcSettlementAccount getValue(Applicant bean, JsonSerializationContext ctx) {
        return bean.getLcSettlementAccount();
      }
    };
    result[1] = new BeanPropertySerializer<Applicant, FeesAndChargesSettlementAccount>("feesAndChargesSettlementAccount") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return new FeesAndChargesSettlementAccountBeanJsonSerializerImpl();
      }

      @Override
      public FeesAndChargesSettlementAccount getValue(Applicant bean,
          JsonSerializationContext ctx) {
        return bean.getFeesAndChargesSettlementAccount();
      }
    };
    result[2] = new BeanPropertySerializer<Applicant, String>("value") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Applicant bean, JsonSerializationContext ctx) {
        return bean.getValue();
      }
    };
    result[3] = new BeanPropertySerializer<Applicant, CollateralSettlementAccount>("collateralSettlementAccount") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return new CollateralSettlementAccountBeanJsonSerializerImpl();
      }

      @Override
      public CollateralSettlementAccount getValue(Applicant bean, JsonSerializationContext ctx) {
        return bean.getCollateralSettlementAccount();
      }
    };
    return result;
  }
}
