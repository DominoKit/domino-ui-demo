/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl$3.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$3');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Account = goog.require('org.dominokit.domino.formsamples.shared.model.Account');
const _AccountBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _StringJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.StringJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $3 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$3$impl');
exports = $3;
 