package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class AddressBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Address> {
  public AddressBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Address.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[15];
    result[0] = new BeanPropertySerializer<Address, String>("processInstanceId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getProcessInstanceId();
      }
    };
    result[1] = new BeanPropertySerializer<Address, String>("zipCode") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getZipCode();
      }
    };
    result[2] = new BeanPropertySerializer<Address, String>("updatedBy") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getUpdatedBy();
      }
    };
    result[3] = new BeanPropertySerializer<Address, String>("city") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getCity();
      }
    };
    result[4] = new BeanPropertySerializer<Address, String>("countryISOCode") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getCountryISOCode();
      }
    };
    result[5] = new BeanPropertySerializer<Address, String>("updatedDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getUpdatedDate();
      }
    };
    result[6] = new BeanPropertySerializer<Address, String>("createdDate") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getCreatedDate();
      }
    };
    result[7] = new BeanPropertySerializer<Address, String>("mailBox") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getMailBox();
      }
    };
    result[8] = new BeanPropertySerializer<Address, String>("createdBy") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getCreatedBy();
      }
    };
    result[9] = new BeanPropertySerializer<Address, String>("street") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getStreet();
      }
    };
    result[10] = new BeanPropertySerializer<Address, String>("tenantId") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getTenantId();
      }
    };
    result[11] = new BeanPropertySerializer<Address, String>("id") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getId();
      }
    };
    result[12] = new BeanPropertySerializer<Address, String>("apartment") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getApartment();
      }
    };
    result[13] = new BeanPropertySerializer<Address, String>("phoneNumber") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getPhoneNumber();
      }
    };
    result[14] = new BeanPropertySerializer<Address, String>("faxNumber") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Address bean, JsonSerializationContext ctx) {
        return bean.getFaxNumber();
      }
    };
    return result;
  }
}
