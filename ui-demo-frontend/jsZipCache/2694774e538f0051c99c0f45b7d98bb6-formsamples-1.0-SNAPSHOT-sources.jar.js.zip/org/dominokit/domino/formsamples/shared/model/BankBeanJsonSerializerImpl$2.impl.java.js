/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let BankBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$impl');
let ContactPerson = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');
let ContactPersonBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPersonBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Bank, ContactPerson>}
  */
class $2 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {BankBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(BankBeanJsonSerializerImpl, String)'.
   * @param {BankBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_2__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(BankBeanJsonSerializerImpl, String)'.
   * @param {BankBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_2__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl_2 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return ContactPersonBeanJsonSerializerImpl.$create__();
  }
  
  /**
   * @param {Bank} bean
   * @param {JsonSerializationContext} ctx
   * @return {ContactPerson}
   * @public
   */
  m_getValue__org_dominokit_domino_formsamples_shared_model_Bank__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getContactPerson__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {ContactPerson}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_formsamples_shared_model_Bank__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Bank} */ ($Casts.$to(arg0, Bank)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    ContactPersonBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.ContactPersonBeanJsonSerializerImpl$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$2'));




exports = $2; 
//# sourceMappingURL=BankBeanJsonSerializerImpl$2.js.map