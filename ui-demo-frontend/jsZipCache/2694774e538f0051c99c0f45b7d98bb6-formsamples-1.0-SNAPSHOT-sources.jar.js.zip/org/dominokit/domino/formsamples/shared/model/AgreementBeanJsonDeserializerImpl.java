package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Integer;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class AgreementBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Agreement> {
  public AgreementBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Agreement.class;
  }

  @Override
  protected InstanceBuilder<Agreement> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Agreement>() {
      @Override
      public Instance<Agreement> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Agreement>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Agreement create() {
        return new Agreement();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Agreement, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Agreement, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("processInstanceId", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setProcessInstanceId(value);
      }
    });
    map.put("amount", new BeanPropertyDeserializer<Agreement, Integer>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BaseNumberJsonDeserializer.IntegerJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, Integer value, JsonDeserializationContext ctx) {
        bean.setAmount(value);
      }
    });
    map.put("code", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setCode(value);
      }
    });
    map.put("updatedBy", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setUpdatedBy(value);
      }
    });
    map.put("toDate", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setToDate(value);
      }
    });
    map.put("description", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setDescription(value);
      }
    });
    map.put("updatedDate", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setUpdatedDate(value);
      }
    });
    map.put("fromDate", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setFromDate(value);
      }
    });
    map.put("reference", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setReference(value);
      }
    });
    map.put("createdDate", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setCreatedDate(value);
      }
    });
    map.put("createdBy", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setCreatedBy(value);
      }
    });
    map.put("profileId", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setProfileId(value);
      }
    });
    map.put("tenantId", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setTenantId(value);
      }
    });
    map.put("currency", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setCurrency(value);
      }
    });
    map.put("remainingBalance", new BeanPropertyDeserializer<Agreement, Integer>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BaseNumberJsonDeserializer.IntegerJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, Integer value, JsonDeserializationContext ctx) {
        bean.setRemainingBalance(value);
      }
    });
    map.put("id", new BeanPropertyDeserializer<Agreement, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Agreement bean, String value, JsonDeserializationContext ctx) {
        bean.setId(value);
      }
    });
    return map;
  }
}
