package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class ApplicantBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Applicant> {
  public ApplicantBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Applicant.class;
  }

  @Override
  protected InstanceBuilder<Applicant> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Applicant>() {
      @Override
      public Instance<Applicant> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Applicant>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Applicant create() {
        return new Applicant();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Applicant, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Applicant, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("lcSettlementAccount", new BeanPropertyDeserializer<Applicant, LcSettlementAccount>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return new LcSettlementAccountBeanJsonDeserializerImpl();
      }

      @Override
      public void setValue(Applicant bean, LcSettlementAccount value,
          JsonDeserializationContext ctx) {
        bean.setLcSettlementAccount(value);
      }
    });
    map.put("feesAndChargesSettlementAccount", new BeanPropertyDeserializer<Applicant, FeesAndChargesSettlementAccount>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return new FeesAndChargesSettlementAccountBeanJsonDeserializerImpl();
      }

      @Override
      public void setValue(Applicant bean, FeesAndChargesSettlementAccount value,
          JsonDeserializationContext ctx) {
        bean.setFeesAndChargesSettlementAccount(value);
      }
    });
    map.put("value", new BeanPropertyDeserializer<Applicant, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Applicant bean, String value, JsonDeserializationContext ctx) {
        bean.setValue(value);
      }
    });
    map.put("collateralSettlementAccount", new BeanPropertyDeserializer<Applicant, CollateralSettlementAccount>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return new CollateralSettlementAccountBeanJsonDeserializerImpl();
      }

      @Override
      public void setValue(Applicant bean, CollateralSettlementAccount value,
          JsonDeserializationContext ctx) {
        bean.setCollateralSettlementAccount(value);
      }
    });
    return map;
  }
}
