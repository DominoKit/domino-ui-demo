/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Account = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Account$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$14$impl');
let $15 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$15$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$9$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<Account>}
  */
class AccountBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AccountBeanJsonSerializerImpl()'.
   * @return {!AccountBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    AccountBeanJsonSerializerImpl.$clinit();
    let $instance = new AccountBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccountBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(Account);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([15], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "accountAlias"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "accountState"));
    $Arrays.$set(result, 2, $3.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "country"));
    $Arrays.$set(result, 3, $4.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "processInstanceId"));
    $Arrays.$set(result, 4, $5.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "updatedBy"));
    $Arrays.$set(result, 5, $6.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "bicCode"));
    $Arrays.$set(result, 6, $7.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "updatedDate"));
    $Arrays.$set(result, 7, $8.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "accountNumber"));
    $Arrays.$set(result, 8, $9.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "bank"));
    $Arrays.$set(result, 9, $10.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "createdDate"));
    $Arrays.$set(result, 10, $11.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "createdBy"));
    $Arrays.$set(result, 11, $12.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "iban"));
    $Arrays.$set(result, 12, $13.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "tenantId"));
    $Arrays.$set(result, 13, $14.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "currency"));
    $Arrays.$set(result, 14, $15.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonSerializerImpl__java_lang_String(this, "id"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AccountBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AccountBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AccountBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Account = goog.module.get('org.dominokit.domino.formsamples.shared.model.Account$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$14$impl');
    $15 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$15$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl.$9$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AccountBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonSerializerImpl'));




exports = AccountBeanJsonSerializerImpl; 
//# sourceMappingURL=AccountBeanJsonSerializerImpl.js.map