/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer');
const _Class = goog.require('java.lang.Class');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$1');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$5');
const _$6 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$6');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var BankBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$impl');
exports = BankBeanJsonSerializerImpl;
 