/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Beneficiary.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Beneficiary');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _List = goog.require('java.util.List');
const _Account = goog.require('org.dominokit.domino.formsamples.shared.model.Account');
const _Address = goog.require('org.dominokit.domino.formsamples.shared.model.Address');
const _Agreement = goog.require('org.dominokit.domino.formsamples.shared.model.Agreement');
const _Beneficiary__MapperImpl = goog.require('org.dominokit.domino.formsamples.shared.model.Beneficiary_MapperImpl');
const _ContactPerson = goog.require('org.dominokit.domino.formsamples.shared.model.ContactPerson');


// Re-exports the implementation.
var Beneficiary = goog.require('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
exports = Beneficiary;
 