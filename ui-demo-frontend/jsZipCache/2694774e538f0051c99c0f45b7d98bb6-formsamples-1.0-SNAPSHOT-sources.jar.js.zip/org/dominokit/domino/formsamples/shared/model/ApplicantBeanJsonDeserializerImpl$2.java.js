/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _Applicant = goog.require('org.dominokit.domino.formsamples.shared.model.Applicant');
const _ApplicantBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl');
const _LcSettlementAccount = goog.require('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount');
const _LcSettlementAccountBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.LcSettlementAccountBeanJsonDeserializerImpl');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonDeserializerImpl.$2$impl');
exports = $2;
 