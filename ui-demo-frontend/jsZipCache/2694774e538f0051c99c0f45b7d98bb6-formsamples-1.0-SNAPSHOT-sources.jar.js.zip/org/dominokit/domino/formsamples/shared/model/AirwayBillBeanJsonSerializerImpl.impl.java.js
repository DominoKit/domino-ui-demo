/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let AirwayBill = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$3$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<AirwayBill>}
  */
class AirwayBillBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AirwayBillBeanJsonSerializerImpl()'.
   * @return {!AirwayBillBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    AirwayBillBeanJsonSerializerImpl.$clinit();
    let $instance = new AirwayBillBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AirwayBillBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(AirwayBill);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([3], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonSerializerImpl__java_lang_String(this, "description"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonSerializerImpl__java_lang_String(this, "numberOfCopies"));
    $Arrays.$set(result, 2, $3.$create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonSerializerImpl__java_lang_String(this, "required"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AirwayBillBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AirwayBillBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AirwayBillBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    AirwayBill = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl.$3$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AirwayBillBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonSerializerImpl'));




exports = AirwayBillBeanJsonSerializerImpl; 
//# sourceMappingURL=AirwayBillBeanJsonSerializerImpl.js.map