package org.dominokit.domino.formsamples.shared.model;

import java.lang.Boolean;
import java.lang.Class;
import java.lang.Integer;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer;
import org.dominokit.jacksonapt.deser.BooleanJsonDeserializer;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class AirwayBillBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<AirwayBill> {
  public AirwayBillBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return AirwayBill.class;
  }

  @Override
  protected InstanceBuilder<AirwayBill> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<AirwayBill>() {
      @Override
      public Instance<AirwayBill> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<AirwayBill>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private AirwayBill create() {
        return new AirwayBill();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<AirwayBill, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<AirwayBill, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("description", new BeanPropertyDeserializer<AirwayBill, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(AirwayBill bean, String value, JsonDeserializationContext ctx) {
        bean.setDescription(value);
      }
    });
    map.put("numberOfCopies", new BeanPropertyDeserializer<AirwayBill, Integer>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BaseNumberJsonDeserializer.IntegerJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(AirwayBill bean, Integer value, JsonDeserializationContext ctx) {
        bean.setNumberOfCopies(value);
      }
    });
    map.put("required", new BeanPropertyDeserializer<AirwayBill, Boolean>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return BooleanJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(AirwayBill bean, Boolean value, JsonDeserializationContext ctx) {
        bean.setRequired(value);
      }
    });
    return map;
  }
}
