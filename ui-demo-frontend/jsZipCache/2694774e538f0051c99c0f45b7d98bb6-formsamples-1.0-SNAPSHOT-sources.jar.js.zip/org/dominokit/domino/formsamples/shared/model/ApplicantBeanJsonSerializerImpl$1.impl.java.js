/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Applicant = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
let ApplicantBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl$impl');
let LcSettlementAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount$impl');
let LcSettlementAccountBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LcSettlementAccountBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<Applicant, LcSettlementAccount>}
  */
class $1 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ApplicantBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(ApplicantBeanJsonSerializerImpl, String)'.
   * @param {ApplicantBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl_1__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(ApplicantBeanJsonSerializerImpl, String)'.
   * @param {ApplicantBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl_1__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_ApplicantBeanJsonSerializerImpl_1 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return LcSettlementAccountBeanJsonSerializerImpl.$create__();
  }
  
  /**
   * @param {Applicant} bean
   * @param {JsonSerializationContext} ctx
   * @return {LcSettlementAccount}
   * @public
   */
  m_getValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getLcSettlementAccount__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {LcSettlementAccount}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_formsamples_shared_model_Applicant__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {Applicant} */ ($Casts.$to(arg0, Applicant)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    Applicant = goog.module.get('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
    LcSettlementAccountBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.LcSettlementAccountBeanJsonSerializerImpl$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl$1'));




exports = $1; 
//# sourceMappingURL=ApplicantBeanJsonSerializerImpl$1.js.map