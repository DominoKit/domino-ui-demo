/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Account = goog.require('org.dominokit.domino.formsamples.shared.model.Account');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$1');
const _$10 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$10');
const _$11 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$11');
const _$12 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$12');
const _$13 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$13');
const _$14 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$14');
const _$15 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$15');
const _$16 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$16');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$5');
const _$6 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$6');
const _$7 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$7');
const _$8 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$8');
const _$9 = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$9');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var AccountBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl$impl');
exports = AccountBeanJsonDeserializerImpl;
 