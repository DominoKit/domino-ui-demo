package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Map;
import org.dominokit.jacksonapt.JacksonContextProvider;
import org.dominokit.jacksonapt.JsonDeserializationContext;
import org.dominokit.jacksonapt.JsonDeserializer;
import org.dominokit.jacksonapt.JsonDeserializerParameters;
import org.dominokit.jacksonapt.deser.StringJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer;
import org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer;
import org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters;
import org.dominokit.jacksonapt.deser.bean.Instance;
import org.dominokit.jacksonapt.deser.bean.InstanceBuilder;
import org.dominokit.jacksonapt.deser.bean.MapLike;
import org.dominokit.jacksonapt.stream.JsonReader;

public final class AddressBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer<Address> {
  public AddressBeanJsonDeserializerImpl() {
  }

  @Override
  public Class getDeserializedType() {
    return Address.class;
  }

  @Override
  protected InstanceBuilder<Address> initInstanceBuilder() {
    final MapLike<HasDeserializerAndParameters> deserializers = null;
    return new InstanceBuilder<Address>() {
      @Override
      public Instance<Address> newInstance(JsonReader reader, JsonDeserializationContext ctx,
          JsonDeserializerParameters params, Map<String, String> bufferedProperties,
          Map<String, Object> bufferedPropertiesValues) {
        return new Instance<Address>(create(), bufferedProperties);
      }

      @Override
      public MapLike<HasDeserializerAndParameters> getParametersDeserializer() {
        return deserializers;
      }

      private Address create() {
        return new Address();
      }
    };
  }

  @Override
  protected MapLike<BeanPropertyDeserializer<Address, ?>> initDeserializers() {
    MapLike<BeanPropertyDeserializer<Address, ?>> map = JacksonContextProvider.get().mapLikeFactory().make();
    map.put("processInstanceId", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setProcessInstanceId(value);
      }
    });
    map.put("zipCode", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setZipCode(value);
      }
    });
    map.put("updatedBy", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setUpdatedBy(value);
      }
    });
    map.put("city", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setCity(value);
      }
    });
    map.put("countryISOCode", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setCountryISOCode(value);
      }
    });
    map.put("updatedDate", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setUpdatedDate(value);
      }
    });
    map.put("createdDate", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setCreatedDate(value);
      }
    });
    map.put("mailBox", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setMailBox(value);
      }
    });
    map.put("createdBy", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setCreatedBy(value);
      }
    });
    map.put("street", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setStreet(value);
      }
    });
    map.put("tenantId", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setTenantId(value);
      }
    });
    map.put("id", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setId(value);
      }
    });
    map.put("apartment", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setApartment(value);
      }
    });
    map.put("phoneNumber", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setPhoneNumber(value);
      }
    });
    map.put("faxNumber", new BeanPropertyDeserializer<Address, String>() {
      @Override
      protected JsonDeserializer<?> newDeserializer() {
        return StringJsonDeserializer.getInstance();
      }

      @Override
      public void setValue(Address bean, String value, JsonDeserializationContext ctx) {
        bean.setFaxNumber(value);
      }
    });
    return map;
  }
}
