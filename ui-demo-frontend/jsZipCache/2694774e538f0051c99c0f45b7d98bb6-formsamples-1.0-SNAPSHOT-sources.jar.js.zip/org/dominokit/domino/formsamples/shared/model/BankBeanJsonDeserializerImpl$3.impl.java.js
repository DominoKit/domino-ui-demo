/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl$3.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl.$3$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let BankBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl$impl');
let ContactPerson = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');
let ContactPersonBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPersonBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Bank, ContactPerson>}
  */
class $3 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {BankBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl_3;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(BankBeanJsonDeserializerImpl)'.
   * @param {BankBeanJsonDeserializerImpl} $outer_this
   * @return {!$3}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl($outer_this) {
    $3.$clinit();
    let $instance = new $3();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(BankBeanJsonDeserializerImpl)'.
   * @param {BankBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl_3__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_BankBeanJsonDeserializerImpl_3 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return ContactPersonBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @param {Bank} bean
   * @param {ContactPerson} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_formsamples_shared_model_Bank__org_dominokit_domino_formsamples_shared_model_ContactPerson__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setContactPerson__org_dominokit_domino_formsamples_shared_model_ContactPerson(value);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_formsamples_shared_model_Bank__org_dominokit_domino_formsamples_shared_model_ContactPerson__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Bank} */ ($Casts.$to(arg0, Bank)), /**@type {ContactPerson} */ ($Casts.$to(arg1, ContactPerson)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $3;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $3);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $3.$clinit = function() {};
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    ContactPerson = goog.module.get('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');
    ContactPersonBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.ContactPersonBeanJsonDeserializerImpl$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($3, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl$3'));




exports = $3; 
//# sourceMappingURL=BankBeanJsonDeserializerImpl$3.js.map