/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Beneficiary = goog.require('org.dominokit.domino.formsamples.shared.model.Beneficiary');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$1');
const _$10 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$10');
const _$11 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$11');
const _$12 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$12');
const _$13 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$13');
const _$14 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$14');
const _$15 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$15');
const _$16 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$16');
const _$17 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$17');
const _$18 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$18');
const _$19 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$19');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$2');
const _$20 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$20');
const _$21 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$21');
const _$22 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$22');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$5');
const _$6 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$6');
const _$7 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$7');
const _$8 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$8');
const _$9 = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$9');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var BeneficiaryBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl$impl');
exports = BeneficiaryBeanJsonDeserializerImpl;
 