/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Beneficiary.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Account = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Account$impl');
let Address = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Address$impl');
let Agreement = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Agreement$impl');
let Beneficiary__MapperImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Beneficiary_MapperImpl$impl');
let ContactPerson = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.ContactPerson$impl');


class Beneficiary extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {Address} */
    this.f_address__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {List<Agreement>} */
    this.f_agreements__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {ContactPerson} */
    this.f_contactPerson__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_description__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_expiryDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_poBox__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_profileType__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_phone__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {List<Account>} */
    this.f_accounts__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_id__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_state__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_fax__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_startingDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
    /** @public {?string} */
    this.f_email__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * Factory method corresponding to constructor 'Beneficiary()'.
   * @return {!Beneficiary}
   * @public
   */
  static $create__() {
    Beneficiary.$clinit();
    let $instance = new Beneficiary();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Beneficiary__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Beneficiary()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Beneficiary__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} processInstanceId
   * @return {void}
   * @public
   */
  m_setProcessInstanceId__java_lang_String(processInstanceId) {
    this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = processInstanceId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getProcessInstanceId__() {
    return this.f_processInstanceId__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {Address} address
   * @return {void}
   * @public
   */
  m_setAddress__org_dominokit_domino_formsamples_shared_model_Address(address) {
    this.f_address__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = address;
  }
  
  /**
   * @return {Address}
   * @public
   */
  m_getAddress__() {
    return this.f_address__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} updatedBy
   * @return {void}
   * @public
   */
  m_setUpdatedBy__java_lang_String(updatedBy) {
    this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = updatedBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedBy__() {
    return this.f_updatedBy__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {List<Agreement>} agreements
   * @return {void}
   * @public
   */
  m_setAgreements__java_util_List(agreements) {
    this.f_agreements__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = agreements;
  }
  
  /**
   * @return {List<Agreement>}
   * @public
   */
  m_getAgreements__() {
    return this.f_agreements__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {ContactPerson} contactPerson
   * @return {void}
   * @public
   */
  m_setContactPerson__org_dominokit_domino_formsamples_shared_model_ContactPerson(contactPerson) {
    this.f_contactPerson__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = contactPerson;
  }
  
  /**
   * @return {ContactPerson}
   * @public
   */
  m_getContactPerson__() {
    return this.f_contactPerson__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} description
   * @return {void}
   * @public
   */
  m_setDescription__java_lang_String(description) {
    this.f_description__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = description;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDescription__() {
    return this.f_description__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} updatedDate
   * @return {void}
   * @public
   */
  m_setUpdatedDate__java_lang_String(updatedDate) {
    this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = updatedDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getUpdatedDate__() {
    return this.f_updatedDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} expiryDate
   * @return {void}
   * @public
   */
  m_setExpiryDate__java_lang_String(expiryDate) {
    this.f_expiryDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = expiryDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getExpiryDate__() {
    return this.f_expiryDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} poBox
   * @return {void}
   * @public
   */
  m_setPoBox__java_lang_String(poBox) {
    this.f_poBox__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = poBox;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPoBox__() {
    return this.f_poBox__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} createdDate
   * @return {void}
   * @public
   */
  m_setCreatedDate__java_lang_String(createdDate) {
    this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = createdDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedDate__() {
    return this.f_createdDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} profileType
   * @return {void}
   * @public
   */
  m_setProfileType__java_lang_String(profileType) {
    this.f_profileType__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = profileType;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getProfileType__() {
    return this.f_profileType__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} createdBy
   * @return {void}
   * @public
   */
  m_setCreatedBy__java_lang_String(createdBy) {
    this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = createdBy;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCreatedBy__() {
    return this.f_createdBy__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} phone
   * @return {void}
   * @public
   */
  m_setPhone__java_lang_String(phone) {
    this.f_phone__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = phone;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPhone__() {
    return this.f_phone__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} tenantId
   * @return {void}
   * @public
   */
  m_setTenantId__java_lang_String(tenantId) {
    this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = tenantId;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTenantId__() {
    return this.f_tenantId__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {List<Account>} accounts
   * @return {void}
   * @public
   */
  m_setAccounts__java_util_List(accounts) {
    this.f_accounts__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = accounts;
  }
  
  /**
   * @return {List<Account>}
   * @public
   */
  m_getAccounts__() {
    return this.f_accounts__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} id
   * @return {void}
   * @public
   */
  m_setId__java_lang_String(id) {
    this.f_id__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = id;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getId__() {
    return this.f_id__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} state
   * @return {void}
   * @public
   */
  m_setState__java_lang_String(state) {
    this.f_state__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = state;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getState__() {
    return this.f_state__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} fax
   * @return {void}
   * @public
   */
  m_setFax__java_lang_String(fax) {
    this.f_fax__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = fax;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getFax__() {
    return this.f_fax__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} startingDate
   * @return {void}
   * @public
   */
  m_setStartingDate__java_lang_String(startingDate) {
    this.f_startingDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = startingDate;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStartingDate__() {
    return this.f_startingDate__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @param {?string} email
   * @return {void}
   * @public
   */
  m_setEmail__java_lang_String(email) {
    this.f_email__org_dominokit_domino_formsamples_shared_model_Beneficiary_ = email;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getEmail__() {
    return this.f_email__org_dominokit_domino_formsamples_shared_model_Beneficiary_;
  }
  
  /**
   * @return {Beneficiary__MapperImpl}
   * @public
   */
  static get f_MAPPER__org_dominokit_domino_formsamples_shared_model_Beneficiary() {
    return (Beneficiary.$clinit(), Beneficiary.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Beneficiary);
  }
  
  /**
   * @param {Beneficiary__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_MAPPER__org_dominokit_domino_formsamples_shared_model_Beneficiary(value) {
    (Beneficiary.$clinit(), Beneficiary.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Beneficiary = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Beneficiary;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Beneficiary);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Beneficiary.$clinit = function() {};
    Beneficiary__MapperImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.Beneficiary_MapperImpl$impl');
    j_l_Object.$clinit();
    Beneficiary.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Beneficiary = Beneficiary__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(Beneficiary, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Beneficiary'));


/** @private {Beneficiary__MapperImpl} */
Beneficiary.$f_MAPPER__org_dominokit_domino_formsamples_shared_model_Beneficiary;




exports = Beneficiary; 
//# sourceMappingURL=Beneficiary.js.map