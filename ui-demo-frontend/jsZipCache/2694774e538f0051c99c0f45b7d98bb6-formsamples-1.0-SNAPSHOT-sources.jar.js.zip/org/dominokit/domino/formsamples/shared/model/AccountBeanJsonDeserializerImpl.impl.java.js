/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Account = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Account$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$14$impl');
let $15 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$15$impl');
let $16 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$16$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$9$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Account>}
  */
class AccountBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AccountBeanJsonDeserializerImpl()'.
   * @return {!AccountBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    AccountBeanJsonDeserializerImpl.$clinit();
    let $instance = new AccountBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccountBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Account);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Account>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Account, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Account, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("accountAlias", $2.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("accountState", $3.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("country", $4.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("processInstanceId", $5.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedBy", $6.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("bicCode", $7.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedDate", $8.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("accountNumber", $9.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("bank", $10.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdDate", $11.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdBy", $12.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("iban", $13.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("tenantId", $14.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("currency", $15.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("id", $16.$create__org_dominokit_domino_formsamples_shared_model_AccountBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AccountBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AccountBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AccountBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Account = goog.module.get('org.dominokit.domino.formsamples.shared.model.Account$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$14$impl');
    $15 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$15$impl');
    $16 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$16$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl.$9$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AccountBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AccountBeanJsonDeserializerImpl'));




exports = AccountBeanJsonDeserializerImpl; 
//# sourceMappingURL=AccountBeanJsonDeserializerImpl.js.map