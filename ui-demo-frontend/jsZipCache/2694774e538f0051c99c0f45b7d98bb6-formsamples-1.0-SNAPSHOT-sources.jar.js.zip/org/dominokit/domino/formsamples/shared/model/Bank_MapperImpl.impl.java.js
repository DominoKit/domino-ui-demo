/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper$impl');

let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let BankBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl$impl');
let BankBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');


/**
 * @extends {AbstractObjectMapper<Bank>}
  */
class Bank__MapperImpl extends AbstractObjectMapper {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Bank_MapperImpl()'.
   * @return {!Bank__MapperImpl}
   * @public
   */
  static $create__() {
    Bank__MapperImpl.$clinit();
    let $instance = new Bank__MapperImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Bank_MapperImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl__() {
    this.$ctor__org_dominokit_jacksonapt_AbstractObjectMapper__java_lang_String("Bank");
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return BankBeanJsonSerializerImpl.$create__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<Bank>}
   * @public
   */
  m_newDeserializer__() {
    return BankBeanJsonDeserializerImpl.$create__();
  }
  
  /**
   * @return {Bank__MapperImpl}
   * @public
   */
  static get f_INSTANCE__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl() {
    return (Bank__MapperImpl.$clinit(), Bank__MapperImpl.$f_INSTANCE__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl);
  }
  
  /**
   * @param {Bank__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_INSTANCE__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl(value) {
    (Bank__MapperImpl.$clinit(), Bank__MapperImpl.$f_INSTANCE__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Bank__MapperImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Bank__MapperImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Bank__MapperImpl.$clinit = function() {};
    BankBeanJsonDeserializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonDeserializerImpl$impl');
    BankBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$impl');
    AbstractObjectMapper.$clinit();
    Bank__MapperImpl.$f_INSTANCE__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl = Bank__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(Bank__MapperImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.Bank_MapperImpl'));


/** @private {Bank__MapperImpl} */
Bank__MapperImpl.$f_INSTANCE__org_dominokit_domino_formsamples_shared_model_Bank_MapperImpl;




exports = Bank__MapperImpl; 
//# sourceMappingURL=Bank_MapperImpl.js.map