/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer');
const _Class = goog.require('java.lang.Class');
const _Applicant = goog.require('org.dominokit.domino.formsamples.shared.model.Applicant');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$1');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl.$4');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var ApplicantBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.ApplicantBeanJsonSerializerImpl$impl');
exports = ApplicantBeanJsonSerializerImpl;
 