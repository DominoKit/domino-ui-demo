/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$6.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$6');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Collection = goog.require('java.util.Collection');
const _List = goog.require('java.util.List');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _BankBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl');
const _Branch = goog.require('org.dominokit.domino.formsamples.shared.model.Branch');
const _BranchBeanJsonSerializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.BranchBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _CollectionJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.CollectionJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $6 = goog.require('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$6$impl');
exports = $6;
 