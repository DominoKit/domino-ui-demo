/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Beneficiary = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$14$impl');
let $15 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$15$impl');
let $16 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$16$impl');
let $17 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$17$impl');
let $18 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$18$impl');
let $19 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$19$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$2$impl');
let $20 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$20$impl');
let $21 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$21$impl');
let $22 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$22$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$9$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Beneficiary>}
  */
class BeneficiaryBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BeneficiaryBeanJsonDeserializerImpl()'.
   * @return {!BeneficiaryBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    BeneficiaryBeanJsonDeserializerImpl.$clinit();
    let $instance = new BeneficiaryBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BeneficiaryBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Beneficiary);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Beneficiary>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Beneficiary, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Beneficiary, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("processInstanceId", $2.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("address", $3.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedBy", $4.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("agreements", $5.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("contactPerson", $6.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("description", $7.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("updatedDate", $8.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("expiryDate", $9.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("poBox", $10.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdDate", $11.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("profileType", $12.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("createdBy", $13.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("phone", $14.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("name", $15.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("tenantId", $16.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("accounts", $17.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("id", $18.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("state", $19.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("fax", $20.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("startingDate", $21.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("email", $22.$create__org_dominokit_domino_formsamples_shared_model_BeneficiaryBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BeneficiaryBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BeneficiaryBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BeneficiaryBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Beneficiary = goog.module.get('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$14$impl');
    $15 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$15$impl');
    $16 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$16$impl');
    $17 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$17$impl');
    $18 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$18$impl');
    $19 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$19$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$2$impl');
    $20 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$20$impl');
    $21 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$21$impl');
    $22 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$22$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl.$9$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BeneficiaryBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.BeneficiaryBeanJsonDeserializerImpl'));




exports = BeneficiaryBeanJsonDeserializerImpl; 
//# sourceMappingURL=BeneficiaryBeanJsonDeserializerImpl.js.map