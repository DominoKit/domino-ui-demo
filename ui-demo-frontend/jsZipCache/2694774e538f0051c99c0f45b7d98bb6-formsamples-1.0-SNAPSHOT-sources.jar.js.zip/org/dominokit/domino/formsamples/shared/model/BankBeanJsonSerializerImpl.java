package org.dominokit.domino.formsamples.shared.model;

import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.CollectionJsonSerializer;
import org.dominokit.jacksonapt.ser.StringJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class BankBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<Bank> {
  public BankBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return Bank.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[6];
    result[0] = new BeanPropertySerializer<Bank, Address>("address") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return new AddressBeanJsonSerializerImpl();
      }

      @Override
      public Address getValue(Bank bean, JsonSerializationContext ctx) {
        return bean.getAddress();
      }
    };
    result[1] = new BeanPropertySerializer<Bank, ContactPerson>("contactPerson") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return new ContactPersonBeanJsonSerializerImpl();
      }

      @Override
      public ContactPerson getValue(Bank bean, JsonSerializationContext ctx) {
        return bean.getContactPerson();
      }
    };
    result[2] = new BeanPropertySerializer<Bank, String>("name") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Bank bean, JsonSerializationContext ctx) {
        return bean.getName();
      }
    };
    result[3] = new BeanPropertySerializer<Bank, String>("shortName") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Bank bean, JsonSerializationContext ctx) {
        return bean.getShortName();
      }
    };
    result[4] = new BeanPropertySerializer<Bank, String>("swiftCode") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return StringJsonSerializer.getInstance();
      }

      @Override
      public String getValue(Bank bean, JsonSerializationContext ctx) {
        return bean.getSwiftCode();
      }
    };
    result[5] = new BeanPropertySerializer<Bank, List<Branch>>("branches") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return CollectionJsonSerializer.newInstance(new BranchBeanJsonSerializerImpl());
      }

      @Override
      public List<Branch> getValue(Bank bean, JsonSerializationContext ctx) {
        return bean.getBranches();
      }
    };
    return result;
  }
}
