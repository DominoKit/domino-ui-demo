/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$6$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<Bank>}
  */
class BankBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BankBeanJsonSerializerImpl()'.
   * @return {!BankBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    BankBeanJsonSerializerImpl.$clinit();
    let $instance = new BankBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BankBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(Bank);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([6], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String(this, "address"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String(this, "contactPerson"));
    $Arrays.$set(result, 2, $3.$create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String(this, "name"));
    $Arrays.$set(result, 3, $4.$create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String(this, "shortName"));
    $Arrays.$set(result, 4, $5.$create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String(this, "swiftCode"));
    $Arrays.$set(result, 5, $6.$create__org_dominokit_domino_formsamples_shared_model_BankBeanJsonSerializerImpl__java_lang_String(this, "branches"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BankBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BankBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BankBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    $1 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl.$6$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BankBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.BankBeanJsonSerializerImpl'));




exports = BankBeanJsonSerializerImpl; 
//# sourceMappingURL=BankBeanJsonSerializerImpl.js.map