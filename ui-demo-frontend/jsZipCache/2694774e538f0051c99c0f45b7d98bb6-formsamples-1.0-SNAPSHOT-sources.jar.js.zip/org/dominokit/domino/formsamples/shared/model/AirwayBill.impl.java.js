/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBill.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');


class AirwayBill extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_description__org_dominokit_domino_formsamples_shared_model_AirwayBill_;
    /** @public {number} */
    this.f_numberOfCopies__org_dominokit_domino_formsamples_shared_model_AirwayBill_ = 0;
    /** @public {boolean} */
    this.f_required__org_dominokit_domino_formsamples_shared_model_AirwayBill_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'AirwayBill()'.
   * @return {!AirwayBill}
   * @public
   */
  static $create__() {
    AirwayBill.$clinit();
    let $instance = new AirwayBill();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AirwayBill__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AirwayBill()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AirwayBill__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} description
   * @return {void}
   * @public
   */
  m_setDescription__java_lang_String(description) {
    this.f_description__org_dominokit_domino_formsamples_shared_model_AirwayBill_ = description;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDescription__() {
    return this.f_description__org_dominokit_domino_formsamples_shared_model_AirwayBill_;
  }
  
  /**
   * @param {number} numberOfCopies
   * @return {void}
   * @public
   */
  m_setNumberOfCopies__int(numberOfCopies) {
    this.f_numberOfCopies__org_dominokit_domino_formsamples_shared_model_AirwayBill_ = numberOfCopies;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getNumberOfCopies__() {
    return this.f_numberOfCopies__org_dominokit_domino_formsamples_shared_model_AirwayBill_;
  }
  
  /**
   * @param {boolean} required
   * @return {void}
   * @public
   */
  m_setRequired__boolean(required) {
    this.f_required__org_dominokit_domino_formsamples_shared_model_AirwayBill_ = required;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isRequired__() {
    return this.f_required__org_dominokit_domino_formsamples_shared_model_AirwayBill_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "AirwayBill{" + "description = '" + j_l_String.m_valueOf__java_lang_Object(this.f_description__org_dominokit_domino_formsamples_shared_model_AirwayBill_) + j_l_String.m_valueOf__char(39 /* '\'' */) + ",numberOfCopies = '" + this.f_numberOfCopies__org_dominokit_domino_formsamples_shared_model_AirwayBill_ + j_l_String.m_valueOf__char(39 /* '\'' */) + ",required = '" + this.f_required__org_dominokit_domino_formsamples_shared_model_AirwayBill_ + j_l_String.m_valueOf__char(39 /* '\'' */) + "}";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AirwayBill;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AirwayBill);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AirwayBill.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AirwayBill, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AirwayBill'));




exports = AirwayBill; 
//# sourceMappingURL=AirwayBill.js.map