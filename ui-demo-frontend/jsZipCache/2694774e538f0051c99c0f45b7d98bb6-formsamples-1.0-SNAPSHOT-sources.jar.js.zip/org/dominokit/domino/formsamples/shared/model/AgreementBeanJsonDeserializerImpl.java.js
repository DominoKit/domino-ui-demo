/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Agreement = goog.require('org.dominokit.domino.formsamples.shared.model.Agreement');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$1');
const _$10 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$10');
const _$11 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$11');
const _$12 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$12');
const _$13 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$13');
const _$14 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$14');
const _$15 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$15');
const _$16 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$16');
const _$17 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$17');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$5');
const _$6 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$6');
const _$7 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$7');
const _$8 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$8');
const _$9 = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl.$9');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var AgreementBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AgreementBeanJsonDeserializerImpl$impl');
exports = AgreementBeanJsonDeserializerImpl;
 