/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer');
const _Class = goog.require('java.lang.Class');
const _Address = goog.require('org.dominokit.domino.formsamples.shared.model.Address');
const _$1 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$1');
const _$10 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$10');
const _$11 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$11');
const _$12 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$12');
const _$13 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$13');
const _$14 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$14');
const _$15 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$15');
const _$16 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$16');
const _$2 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$2');
const _$3 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$3');
const _$4 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$4');
const _$5 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$5');
const _$6 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$6');
const _$7 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$7');
const _$8 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$8');
const _$9 = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl.$9');
const _JacksonContextProvider = goog.require('org.dominokit.jacksonapt.JacksonContextProvider');
const _BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');


// Re-exports the implementation.
var AddressBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.formsamples.shared.model.AddressBeanJsonDeserializerImpl$impl');
exports = AddressBeanJsonDeserializerImpl;
 