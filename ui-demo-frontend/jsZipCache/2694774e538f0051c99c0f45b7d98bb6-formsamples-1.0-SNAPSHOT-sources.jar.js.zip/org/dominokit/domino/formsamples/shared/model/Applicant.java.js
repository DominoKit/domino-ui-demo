/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.Applicant.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.Applicant');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _CollateralSettlementAccount = goog.require('org.dominokit.domino.formsamples.shared.model.CollateralSettlementAccount');
const _FeesAndChargesSettlementAccount = goog.require('org.dominokit.domino.formsamples.shared.model.FeesAndChargesSettlementAccount');
const _LcSettlementAccount = goog.require('org.dominokit.domino.formsamples.shared.model.LcSettlementAccount');


// Re-exports the implementation.
var Applicant = goog.require('org.dominokit.domino.formsamples.shared.model.Applicant$impl');
exports = Applicant;
 