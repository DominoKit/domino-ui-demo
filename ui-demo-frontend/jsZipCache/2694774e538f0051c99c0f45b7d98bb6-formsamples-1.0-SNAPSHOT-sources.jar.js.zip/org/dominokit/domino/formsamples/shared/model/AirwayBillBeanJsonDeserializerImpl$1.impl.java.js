/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl.$1$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let AirwayBill = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
let AirwayBillBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializerParameters = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializerParameters$impl');
let HasDeserializerAndParameters = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters$impl');
let Instance = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.Instance$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');
let JsonReader = goog.forwardDeclare('org.dominokit.jacksonapt.stream.JsonReader$impl');


/**
 * @implements {InstanceBuilder<AirwayBill>}
  */
class $1 extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {AirwayBillBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_1;
    /** @public {MapLike<HasDeserializerAndParameters>} */
    this.$c_deserializers;
  }
  
  /**
   * Factory method corresponding to constructor 'new InstanceBuilder(AirwayBillBeanJsonDeserializerImpl, MapLike)'.
   * @param {AirwayBillBeanJsonDeserializerImpl} $outer_this
   * @param {MapLike<HasDeserializerAndParameters>} $c_deserializers
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike($outer_this, $c_deserializers) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_1__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike($outer_this, $c_deserializers);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new InstanceBuilder(AirwayBillBeanJsonDeserializerImpl, MapLike)'.
   * @param {AirwayBillBeanJsonDeserializerImpl} $outer_this
   * @param {MapLike<HasDeserializerAndParameters>} $c_deserializers
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_1__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike($outer_this, $c_deserializers) {
    this.f_$outer_this__org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_1 = $outer_this;
    this.$c_deserializers = $c_deserializers;
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {JsonReader} reader
   * @param {JsonDeserializationContext} ctx
   * @param {JsonDeserializerParameters} params
   * @param {Map<?string, ?string>} bufferedProperties
   * @param {Map<?string, *>} bufferedPropertiesValues
   * @return {Instance<AirwayBill>}
   * @public
   */
  m_newInstance__org_dominokit_jacksonapt_stream_JsonReader__org_dominokit_jacksonapt_JsonDeserializationContext__org_dominokit_jacksonapt_JsonDeserializerParameters__java_util_Map__java_util_Map(reader, ctx, params, bufferedProperties, bufferedPropertiesValues) {
    return /**@type {!Instance<AirwayBill>} */ (Instance.$create__java_lang_Object__java_util_Map(this.m_create___$p_org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_1(), bufferedProperties));
  }
  
  /**
   * @override
   * @return {MapLike<HasDeserializerAndParameters>}
   * @public
   */
  m_getParametersDeserializer__() {
    return this.$c_deserializers;
  }
  
  /**
   * @return {AirwayBill}
   * @public
   */
  m_create___$p_org_dominokit_domino_formsamples_shared_model_AirwayBillBeanJsonDeserializerImpl_1() {
    return AirwayBill.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    AirwayBill = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
    Instance = goog.module.get('org.dominokit.jacksonapt.deser.bean.Instance$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.formsamples.shared.model.AirwayBillBeanJsonDeserializerImpl$1'));


InstanceBuilder.$markImplementor($1);


exports = $1; 
//# sourceMappingURL=AirwayBillBeanJsonDeserializerImpl$1.js.map