/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.$LambdaAdaptor$20$impl');
let Insurance = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Insurance$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class InsurancePolicyPart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_insuranceCompanyTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
    /** @public {TextBox} */
    this.f_insurancePolicyNumberTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
    /** @public {SwitchButton} */
    this.f_insurancePolicyRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
    /** @public {Card} */
    this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
  }
  
  /**
   * Factory method corresponding to constructor 'InsurancePolicyPart()'.
   * @return {!InsurancePolicyPart}
   * @public
   */
  static $create__() {
    InsurancePolicyPart.$clinit();
    let $instance = new InsurancePolicyPart();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InsurancePolicyPart()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart();
    this.f_insuranceCompanyTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Insurance company").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_business__()), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setRequired__boolean(true), TextBox));
    this.f_insuranceCompanyTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$19(((/** Event */ evt) =>{
      this.m_revalidate__();
    })));
    this.f_insurancePolicyNumberTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Insurance policy number").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_phone__()), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setRequired__boolean(true), TextBox));
    this.f_insurancePolicyNumberTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$20(((/** Event */ evt$1$) =>{
      this.m_revalidate__();
    })));
    this.f_insurancePolicyRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_ = /**@type {SwitchButton} */ ($Casts.$to(SwitchButton.m_create__().m_style__().m_setMarginBottom__java_lang_String("0px").m_get__(), SwitchButton)).m_setOnTitle__java_lang_String("Applicant").m_setOffTitle__java_lang_String("Beneficiary").m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_expand__();
      } else {
        this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_ = Card.m_create__java_lang_String("Insurance policy required by").m_setBodyPaddingTop__java_lang_String("40px").m_collapse__();
    this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_insurancePolicyRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_asElement__());
    let insurancePolicyRow = /**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_insuranceCompanyTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_insurancePolicyNumberTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_), Column)));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.appendChild(this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(insurancePolicyRow).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let documentsRequired = letterOfCredit.m_getDocumentsRequired__();
    if (!this.f_insurancePolicyRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_isChecked__()) {
      let insurance = Insurance.$create__();
      insurance.m_setInsuranceCompany__java_lang_String(this.f_insuranceCompanyTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_getValue__());
      insurance.m_setInsurancePolicyNumber__java_lang_String(this.f_insurancePolicyNumberTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_getValue__());
      documentsRequired.m_setInsurance__org_dominokit_domino_formsamples_shared_model_Insurance(insurance);
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_) && this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_insurancePolicyCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_, true, false);
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart() {
    return !Boolean.m_booleanValue__java_lang_Boolean(this.f_insurancePolicyRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_getValue__()) || this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_.m_validate__().m_isValid__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart() {
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_ = FieldsGrouping.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_InsurancePolicyPart_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InsurancePolicyPart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InsurancePolicyPart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InsurancePolicyPart.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.$LambdaAdaptor$20$impl');
    Insurance = goog.module.get('org.dominokit.domino.formsamples.shared.model.Insurance$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InsurancePolicyPart, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart'));


ImportSection.$markImplementor(InsurancePolicyPart);


exports = InsurancePolicyPart; 
//# sourceMappingURL=InsurancePolicyPart.js.map