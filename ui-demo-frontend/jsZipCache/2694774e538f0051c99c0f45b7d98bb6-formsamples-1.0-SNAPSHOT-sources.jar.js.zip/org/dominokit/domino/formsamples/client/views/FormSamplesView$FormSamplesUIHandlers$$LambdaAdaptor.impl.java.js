/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.FormSamplesView$FormSamplesUIHandlers$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormSamplesUIHandlers = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers$impl');

let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');


/**
 * @implements {FormSamplesUIHandlers}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(LetterOfCredit):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(LetterOfCredit):void} */
    this.f_$$fn__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$LambdaAdaptor__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(LetterOfCredit):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$LambdaAdaptor__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {LetterOfCredit} arg0
   * @return {void}
   * @public
   */
  m_onCreate__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.FormSamplesView$FormSamplesUIHandlers$$LambdaAdaptor'));


FormSamplesUIHandlers.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=FormSamplesView$FormSamplesUIHandlers$$LambdaAdaptor.js.map