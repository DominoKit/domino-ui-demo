/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.Constants.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Constants extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Constants()'.
   * @return {!Constants}
   * @public
   */
  static $create__() {
    Constants.$clinit();
    let $instance = new Constants();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_Constants__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Constants()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_Constants__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Constants;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Constants);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Constants.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Constants, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.Constants'));


/** @public {?string} @const */
Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants = "dd-MM-yyyy";


/** @public {?string} @const */
Constants.f_NUMBERS_ONLY__org_dominokit_domino_formsamples_client_views_ui_Constants = "Numbers only";




exports = Constants; 
//# sourceMappingURL=Constants.js.map