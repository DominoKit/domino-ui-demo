/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.FormSamplesView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.FormSamplesView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasUiHandlers = goog.require('org.dominokit.domino.api.client.mvp.view.HasUiHandlers$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let FormSamplesUIHandlers = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 * @extends {HasUiHandlers<FormSamplesUIHandlers>}
 */
class FormSamplesView {
  /**
   * @abstract
   * @param {?string} bodyAsString
   * @return {void}
   * @public
   */
  m_onSuccessCreate__java_lang_String(bodyAsString) {
  }
  
  /**
   * @abstract
   * @param {?string} errorMessage
   * @return {void}
   * @public
   */
  m_onErrorCreate__java_lang_String(errorMessage) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    HasUiHandlers.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_formsamples_client_views_FormSamplesView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_formsamples_client_views_FormSamplesView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_formsamples_client_views_FormSamplesView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormSamplesView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(FormSamplesView, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.FormSamplesView'));


FormSamplesView.$markImplementor(/** @type {Function} */ (FormSamplesView));


exports = FormSamplesView; 
//# sourceMappingURL=FormSamplesView.js.map