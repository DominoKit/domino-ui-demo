/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _List = goog.require('java.util.List');
const _CertificateOfOriginPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart');
const _DraftsPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart');
const _InsurancePolicyPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart');
const _OtherDocumentsPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart');
const _PackingListPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart');
const _ShippingDocumentsPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart');
const _SignedCommercialInvoicePart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _Country = goog.require('org.dominokit.domino.formsamples.shared.model.Country');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DocumentsRequiredSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection$impl');
exports = DocumentsRequiredSection;
 