/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let AccountDetails = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetails$impl');
let AccountDetailsPopupPosition = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition$impl');
let CorporateAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let Tooltip = goog.forwardDeclare('org.dominokit.domino.ui.popover.Tooltip$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
 * @implements {IsCollapsible<CorporateAccountsSelect>}
  */
class CorporateAccountsSelect extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<CorporateAccount>} */
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_;
    /** @public {AccountDetails} */
    this.f_accountDetails__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_;
  }
  
  /**
   * @param {?string} title
   * @param {CorporateProfile} corporateProfile
   * @return {CorporateAccountsSelect}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile(title, corporateProfile) {
    CorporateAccountsSelect.$clinit();
    return CorporateAccountsSelect.$create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile(title, corporateProfile);
  }
  
  /**
   * Factory method corresponding to constructor 'CorporateAccountsSelect(String, CorporateProfile)'.
   * @param {?string} title
   * @param {CorporateProfile} corporateProfile
   * @return {!CorporateAccountsSelect}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile(title, corporateProfile) {
    CorporateAccountsSelect.$clinit();
    let $instance = new CorporateAccountsSelect();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile(title, corporateProfile);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CorporateAccountsSelect(String, CorporateProfile)'.
   * @param {?string} title
   * @param {CorporateProfile} corporateProfile
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile(title, corporateProfile) {
    this.$ctor__java_lang_Object__();
    this.f_accountDetails__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_ = AccountDetails.$create__();
    let correspondentChargesAccountIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Style<HTMLElement, Icon>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_info_outline__())).m_setProperty__java_lang_String__java_lang_String("cursor", "pointer").m_get__(), Icon));
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_ = /**@type {Select<CorporateAccount>} */ (Select.m_create__java_lang_String(title)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_account_balance_wallet__()).m_setRightAddon__org_jboss_gwt_elemento_core_IsElement(correspondentChargesAccountIcon);
    Tooltip.m_create__elemental2_dom_HTMLElement__java_lang_String(correspondentChargesAccountIcon.m_asElement__(), "Show details");
    /**@type {Style<HTMLDivElement, Popover>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(correspondentChargesAccountIcon.m_asElement__(), "Account details", this.f_accountDetails__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_asElement__()).m_position__org_dominokit_domino_ui_popover_PopupPosition(AccountDetailsPopupPosition.$create__org_dominokit_domino_ui_forms_Select(this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_)))).m_setWidth__java_lang_String("330px");
    for (let $iterator = corporateProfile.m_getCorporateAccounts__().m_iterator__(); $iterator.m_hasNext__(); ) {
      let corporateAccount = /**@type {CorporateAccount} */ ($Casts.$to($iterator.m_next__(), CorporateAccount));
      this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<CorporateAccount>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(corporateAccount, corporateAccount.m_getAccountAlias__())));
    }
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<CorporateAccount> */ option) =>{
      this.f_accountDetails__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_setAccount__org_dominokit_domino_formsamples_shared_model_CorporateAccount(/**@type {CorporateAccount} */ ($Casts.$to(option.m_getValue__(), CorporateAccount)));
    })));
  }
  
  /**
   * @return {Select<CorporateAccount>}
   * @public
   */
  m_getAccountSelect__() {
    return this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_asElement__();
  }
  
  /**
   * @override
   * @return {CorporateAccountsSelect}
   * @public
   */
  m_collapse__() {
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_collapse__();
    return this;
  }
  
  /**
   * @override
   * @return {CorporateAccountsSelect}
   * @public
   */
  m_expand__() {
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_expand__();
    return this;
  }
  
  /**
   * @override
   * @return {CorporateAccountsSelect}
   * @public
   */
  m_toggleDisplay__() {
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_toggleDisplay__();
    return this;
  }
  
  /**
   * @override
   * @param {boolean} state
   * @return {CorporateAccountsSelect}
   * @public
   */
  m_toggleDisplay__boolean(state) {
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_toggleDisplay__boolean(state);
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isCollapsed__() {
    return this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_CorporateAccountsSelect_.m_isCollapsed__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CorporateAccountsSelect;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CorporateAccountsSelect);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CorporateAccountsSelect.$clinit = function() {};
    AccountDetails = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetails$impl');
    AccountDetailsPopupPosition = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition$impl');
    CorporateAccount = goog.module.get('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    Tooltip = goog.module.get('org.dominokit.domino.ui.popover.Tooltip$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CorporateAccountsSelect, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect'));


IsElement.$markImplementor(CorporateAccountsSelect);
IsCollapsible.$markImplementor(CorporateAccountsSelect);


exports = CorporateAccountsSelect; 
//# sourceMappingURL=CorporateAccountsSelect.js.map