/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.FormSamplesView$FormSamplesUIHandlers.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _UiHandlers = goog.require('org.dominokit.domino.api.client.mvp.view.UiHandlers');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers.$LambdaAdaptor');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');


// Re-exports the implementation.
var FormSamplesUIHandlers = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers$impl');
exports = FormSamplesUIHandlers;
 