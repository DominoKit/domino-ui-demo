/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.FormSamplesViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.FormSamplesViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _FormSamplesView = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView');
const _FormSamplesUIHandlers = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Arrays = goog.require('java.util.Arrays');
const _List = goog.require('java.util.List');
const _UiHandlers = goog.require('org.dominokit.domino.api.client.mvp.view.UiHandlers');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _AddLCImportComponent = goog.require('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _Beneficiary = goog.require('org.dominokit.domino.formsamples.shared.model.Beneficiary');
const _CorporateProfile = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateProfile');
const _Countries = goog.require('org.dominokit.domino.formsamples.shared.model.Countries');
const _Country = goog.require('org.dominokit.domino.formsamples.shared.model.Country');
const _Currencies = goog.require('org.dominokit.domino.formsamples.shared.model.Currencies');
const _CurrencyData = goog.require('org.dominokit.domino.formsamples.shared.model.CurrencyData');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _MessageDialog = goog.require('org.dominokit.domino.ui.dialogs.MessageDialog');
const _CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _ArrayCreator = goog.require('org.dominokit.jacksonapt.deser.array.ArrayJsonDeserializer.ArrayCreator');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var FormSamplesViewImpl = goog.require('org.dominokit.domino.formsamples.client.views.ui.FormSamplesViewImpl$impl');
exports = FormSamplesViewImpl;
 