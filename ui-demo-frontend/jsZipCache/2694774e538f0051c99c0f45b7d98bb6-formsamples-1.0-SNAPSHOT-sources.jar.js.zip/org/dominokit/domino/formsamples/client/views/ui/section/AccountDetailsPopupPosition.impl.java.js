/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let CorporateAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');


/**
 * @implements {PopupPosition}
  */
class AccountDetailsPopupPosition extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<CorporateAccount>} */
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetailsPopupPosition_;
  }
  
  /**
   * Factory method corresponding to constructor 'AccountDetailsPopupPosition(Select)'.
   * @param {Select<CorporateAccount>} accountSelect
   * @return {!AccountDetailsPopupPosition}
   * @public
   */
  static $create__org_dominokit_domino_ui_forms_Select(accountSelect) {
    AccountDetailsPopupPosition.$clinit();
    let $instance = new AccountDetailsPopupPosition();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetailsPopupPosition__org_dominokit_domino_ui_forms_Select(accountSelect);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccountDetailsPopupPosition(Select)'.
   * @param {Select<CorporateAccount>} accountSelect
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetailsPopupPosition__org_dominokit_domino_ui_forms_Select(accountSelect) {
    this.$ctor__java_lang_Object__();
    this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetailsPopupPosition_ = accountSelect;
  }
  
  /**
   * @override
   * @param {HTMLElement} tooltip
   * @param {HTMLElement} target
   * @return {void}
   * @public
   */
  m_position__elemental2_dom_HTMLElement__elemental2_dom_HTMLElement(tooltip, target) {
    let targetRect = this.f_accountSelect__org_dominokit_domino_formsamples_client_views_ui_section_AccountDetailsPopupPosition_.m_asElement__().getBoundingClientRect();
    let tooltipRect = tooltip.getBoundingClientRect();
    tooltip.style.setProperty("top", ((targetRect.top + window.window.scrollY) - tooltipRect.height) + "px");
    tooltip.style.setProperty("left", targetRect.left + window.window.scrollX + ((targetRect.width - tooltipRect.width) / 2) + "px");
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getDirectionClass__() {
    return "top";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AccountDetailsPopupPosition;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AccountDetailsPopupPosition);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AccountDetailsPopupPosition.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AccountDetailsPopupPosition, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition'));


PopupPosition.$markImplementor(AccountDetailsPopupPosition);


exports = AccountDetailsPopupPosition; 
//# sourceMappingURL=AccountDetailsPopupPosition.js.map