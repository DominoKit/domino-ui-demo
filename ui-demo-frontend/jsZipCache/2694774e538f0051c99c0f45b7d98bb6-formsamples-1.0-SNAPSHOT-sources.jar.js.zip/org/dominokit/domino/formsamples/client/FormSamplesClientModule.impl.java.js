/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.FormSamplesClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.FormSamplesClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class FormSamplesClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormSamplesClientModule()'.
   * @return {!FormSamplesClientModule}
   * @public
   */
  static $create__() {
    FormSamplesClientModule.$clinit();
    let $instance = new FormSamplesClientModule();
    $instance.$ctor__org_dominokit_domino_formsamples_client_FormSamplesClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormSamplesClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_FormSamplesClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    FormSamplesClientModule.$f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_.m_info__java_lang_String("Initializing FormSamples frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_() {
    return (FormSamplesClientModule.$clinit(), FormSamplesClientModule.$f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_(value) {
    (FormSamplesClientModule.$clinit(), FormSamplesClientModule.$f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormSamplesClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormSamplesClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormSamplesClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    FormSamplesClientModule.$f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormSamplesClientModule));
  }
  
  
};

$Util.$setClassMetadata(FormSamplesClientModule, $Util.$makeClassName('org.dominokit.domino.formsamples.client.FormSamplesClientModule'));


/** @private {Logger} */
FormSamplesClientModule.$f_LOGGER__org_dominokit_domino_formsamples_client_FormSamplesClientModule_;




exports = FormSamplesClientModule; 
//# sourceMappingURL=FormSamplesClientModule.js.map