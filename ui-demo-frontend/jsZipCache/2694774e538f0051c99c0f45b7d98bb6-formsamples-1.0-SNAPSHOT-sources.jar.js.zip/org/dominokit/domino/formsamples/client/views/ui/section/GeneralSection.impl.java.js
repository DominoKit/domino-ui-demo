/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.GeneralSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.GeneralSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let Constants = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class GeneralSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DateBox} */
    this.f_creationDateBox__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_;
    /** @public {TextBox} */
    this.f_placeTextBox__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'GeneralSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {!GeneralSection}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    GeneralSection.$clinit();
    let $instance = new GeneralSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GeneralSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_.appendChild(BlockHeader.m_create__java_lang_String("General").m_asElement__());
    this.f_creationDateBox__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_ = DateBox.m_create__();
    this.f_placeTextBox__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_ = /**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Place").m_value__java_lang_Object("Amman"), TextBox));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_.appendChild(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_style__().m_setMarginBottom__java_lang_String("0px").m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(this.f_creationDateBox__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_.m_setPattern__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants).m_setHelperText__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants), DateBox)).m_setLabel__java_lang_String("Date"), DateBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_date_range__()), DateBox)).m_setReadOnly__boolean(true).m_value__java_lang_Object(Date.$create__())), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_style__().m_setMarginBottom__java_lang_String("0px").m_get__(), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(this.f_placeTextBox__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_.m_setReadOnly__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_on__()), TextBox)).m_value__java_lang_Object(j_l_String.m_valueOf__java_lang_Object(corporateProfile.m_getAddress__().m_getCountryISOCode__()) + " - " + j_l_String.m_valueOf__java_lang_Object(corporateProfile.m_getAddress__().m_getCity__()))), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    return true;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_GeneralSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GeneralSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GeneralSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GeneralSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Date = goog.module.get('java.util.Date$impl');
    Constants = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GeneralSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.GeneralSection'));


ImportSection.$markImplementor(GeneralSection);


exports = GeneralSection; 
//# sourceMappingURL=GeneralSection.js.map