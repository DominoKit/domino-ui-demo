/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _FormSamplesUIHandlers = goog.require('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent.$LambdaAdaptor$1');
const _ApplicantSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ApplicantSection');
const _AuthorizationSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection');
const _BeneficiarySection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.BeneficiarySection');
const _ConfirmationInstructionsSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ConfirmationInstructionsSection');
const _CorrespondentChargesInstructionsSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection');
const _CreditAmountAndToleranceSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection');
const _DocumentsRequiredSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection');
const _GeneralSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.GeneralSection');
const _GoodsDescriptionSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection');
const _IssuerBankSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.IssuerBankSection');
const _PaymentScheduleSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection');
const _ShipmentDetailsSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection');
const _ValiditySection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _Beneficiary = goog.require('org.dominokit.domino.formsamples.shared.model.Beneficiary');
const _CorporateProfile = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateProfile');
const _Country = goog.require('org.dominokit.domino.formsamples.shared.model.Country');
const _CurrencyData = goog.require('org.dominokit.domino.formsamples.shared.model.CurrencyData');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AddLCImportComponent = goog.require('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent$impl');
exports = AddLCImportComponent;
 