/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Constants = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart.$LambdaAdaptor$17$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart.$LambdaAdaptor$18$impl');
let DraftsItem = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.DraftsItem$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class DraftsPart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_validationMessage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {Select<?string>} */
    this.f_draftDrawnOnSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {TextBox} */
    this.f_atDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {Select<?string>} */
    this.f_documentsRequiredFromSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {TextBox} */
    this.f_draftsPercentage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {Select<?string>} */
    this.f_draftsOf__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {SwitchButton} */
    this.f_draftsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {ListGroup<DraftsItem>} */
    this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {Card} */
    this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
  }
  
  /**
   * Factory method corresponding to constructor 'DraftsPart()'.
   * @return {!DraftsPart}
   * @public
   */
  static $create__() {
    DraftsPart.$clinit();
    let $instance = new DraftsPart();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DraftsPart()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
    this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {ListGroup<DraftsItem>} */ (ListGroup.m_create__()).m_setSelectable__boolean(false);
    this.f_draftDrawnOnSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Draft Drawn On")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_business__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Progressoft", "Progressoft"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Clusus", "Clusus"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Bank XYZ", "Bank XYZ"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Bank ABC", "Bank ABC")));
    this.f_atDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String("At (Days)")), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setHelperText__java_lang_String(Constants.f_NUMBERS_ONLY__org_dominokit_domino_formsamples_client_views_ui_Constants), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_looks_one__()), TextBox));
    this.f_documentsRequiredFromSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("From")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_date_range__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("shipmentDate", "Shipment Date"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("commercialDate", "Commercial Date"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("billOfLading", "Bill Of Lading")));
    this.f_draftsPercentage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String("Percentage")), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), TextBox)).m_setHelperText__java_lang_String(Constants.f_NUMBERS_ONLY__org_dominokit_domino_formsamples_client_views_ui_Constants), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(Validator.$adapt((() =>{
      return CustomElements.m_validatePercent__org_dominokit_domino_ui_forms_TextBox(this.f_draftsPercentage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_);
    }))), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas", "fa-percent", "fa-sm"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("margin-left: 15px;padding-right: 6px;")), TextBox));
    this.f_draftsOf__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Of")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_insert_drive_file__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Invoice value", "Invoice value"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("IC value", "IC value")));
    this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = Card.m_create__java_lang_String("Drafts").m_setBodyPaddingTop__java_lang_String("40px").m_collapse__();
    let addDraftButton = this.m_initAddButton___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
    this.f_draftsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = CustomElements.m_createRequiredField__();
    this.f_draftsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_expand__();
        addDraftButton.m_expand__();
      } else {
        this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_collapse__();
        addDraftButton.m_collapse__();
        this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
      }
    })));
    this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getHeaderBar__().m_appendChild__elemental2_dom_Node(addDraftButton.m_asElement__());
    this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_draftsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.appendChild(this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_draftDrawnOnSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_atDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_documentsRequiredFromSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_draftsPercentage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_draftsOf__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_), Column)))).m_asElement__());
  }
  
  /**
   * @return {Button}
   * @public
   */
  m_initAddButton___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart() {
    let addDraftButton = /**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createDefault__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_add__()).m_setContent__java_lang_String("ADD"), Button)).m_linkify__(), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$18(((/** Event */ evt) =>{
      if (this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_validate__().m_isValid__()) {
        let draftsItem = this.m_makeDraftItem___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
        let draftsItemListItem = this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_addItem__java_lang_Object__java_lang_String(draftsItem, this.m_formattedDraftItem__org_dominokit_domino_formsamples_shared_model_DraftsItem_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart(draftsItem));
        let delete$1$ = /**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_delete__().m_style__().m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles).m_setMarginTop__java_lang_String("-3px").m_setMarginLeft__java_lang_String("10px").m_get__(), Icon));
        delete$1$.m_asElement__().addEventListener("click", new $LambdaAdaptor$17(((/** Event */ evt1) =>{
          this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_removeItem__org_dominokit_domino_ui_lists_ListItem(draftsItemListItem);
          this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
        })));
        draftsItemListItem.m_appendChild__org_jboss_gwt_elemento_core_IsElement(delete$1$);
        this.f_atDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_clear__();
        this.f_draftDrawnOnSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_clear__();
        this.f_documentsRequiredFromSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_clear__();
        this.f_draftsPercentage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_clear__();
        this.f_draftsOf__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_clear__();
        this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_clearInvalid__();
        this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
      }
    }))), Button));
    addDraftButton.m_collapse__();
    return addDraftButton;
  }
  
  /**
   * @param {DraftsItem} draftsItem
   * @return {?string}
   * @public
   */
  m_formattedDraftItem__org_dominokit_domino_formsamples_shared_model_DraftsItem_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart(draftsItem) {
    return draftsItem.m_formatted__java_lang_String__java_lang_String(j_l_String.m_toLowerCase__java_lang_String(this.f_documentsRequiredFromSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getSelectedOption__().m_getDisplayValue__()), j_l_String.m_toLowerCase__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_draftsOf__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__(), j_l_String))));
  }
  
  /**
   * @return {DraftsItem}
   * @public
   */
  m_makeDraftItem___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart() {
    return DraftsItem.$create__int__java_lang_String__java_lang_String__int(Integer.m_parseInt__java_lang_String(this.f_atDaysTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__()), /**@type {?string} */ ($Casts.$to(this.f_draftDrawnOnSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__(), j_l_String)), /**@type {?string} */ ($Casts.$to(this.f_documentsRequiredFromSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__(), j_l_String)), Integer.m_parseInt__java_lang_String(this.f_draftsPercentage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__()));
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let documentsRequired = letterOfCredit.m_getDocumentsRequired__();
    documentsRequired.m_setDraftRequired__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_draftsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__()));
    if (documentsRequired.m_isDraftRequired__()) {
      documentsRequired.m_setDrafts__java_util_List(this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getAllValues__());
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_, valid);
    this.m_markWithValidationMessage__boolean_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart(valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_)) {
      let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart();
      if (valid) {
        CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_, true, false);
        this.m_markWithValidationMessage__boolean_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart(valid);
      }
    }
  }
  
  /**
   * @param {boolean} valid
   * @return {void}
   * @public
   */
  m_markWithValidationMessage__boolean_$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart(valid) {
    if (!valid) {
      this.f_draftsCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_validationMessage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_);
    } else {
      this.f_validationMessage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.remove();
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart() {
    return !Boolean.m_booleanValue__java_lang_Boolean(this.f_draftsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getValue__()) || !this.f_draftsListGroup__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_.m_getAllValues__().isEmpty();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart() {
    this.f_validationMessage__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_small__().m_textContent__java_lang_String("At least one draft should be provided."), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = FieldsGrouping.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_DraftsPart_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DraftsPart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DraftsPart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DraftsPart.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Constants = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart.$LambdaAdaptor$17$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart.$LambdaAdaptor$18$impl');
    DraftsItem = goog.module.get('org.dominokit.domino.formsamples.shared.model.DraftsItem$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ListGroup = goog.module.get('org.dominokit.domino.ui.lists.ListGroup$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Validator = goog.module.get('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DraftsPart, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart'));


ImportSection.$markImplementor(DraftsPart);


exports = DraftsPart; 
//# sourceMappingURL=DraftsPart.js.map