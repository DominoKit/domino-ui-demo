/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ConfirmationInstructionsSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ConfirmationInstructionsSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let CorporateAccountsSelect = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
let CorporateAccount = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateAccount$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class ConfirmationInstructionsSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {SwitchButton} */
    this.f_chargesInstructionsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_;
    /** @public {SwitchButton} */
    this.f_confirmationChargesOnSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_;
    /** @public {CorporateAccountsSelect} */
    this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_;
    /** @public {Card} */
    this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'ConfirmationInstructionsSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {!ConfirmationInstructionsSection}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    ConfirmationInstructionsSection.$clinit();
    let $instance = new ConfirmationInstructionsSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ConfirmationInstructionsSection(CorporateProfile)'.
   * @param {CorporateProfile} corporateProfile
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection__org_dominokit_domino_formsamples_shared_model_CorporateProfile(corporateProfile) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection();
    this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_ = CorporateAccountsSelect.m_create__java_lang_String__org_dominokit_domino_formsamples_shared_model_CorporateProfile("Confirmation charges account", corporateProfile);
    /**@type {Select<CorporateAccount>} */ ($Casts.$to(this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getAccountSelect__().m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<CorporateAccount> */ option) =>{
      this.m_revalidate__();
    }))).m_collapse__();
    this.f_chargesInstructionsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_ = /**@type {SwitchButton} */ ($Casts.$to(/**@type {Style<HTMLElement, SwitchButton>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(SwitchButton.m_create__())).m_setMarginBottom__java_lang_String("0px").m_get__(), SwitchButton)).m_setOffTitle__java_lang_String("Required").m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_expand__();
      } else {
        this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_confirmationChargesOnSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_ = SwitchButton.m_create__java_lang_String__java_lang_String__java_lang_String("Confirmation charges on", "Beneficiary", "Applicant").m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value$1$) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value$1$)) {
        this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_expand__();
      } else {
        this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_ = Card.m_create__java_lang_String__java_lang_String("Confirmation Instructions", "").m_collapse__();
    this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_chargesInstructionsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_asElement__());
    this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_bodyStyle__().m_setPaddingTop__java_lang_String("40px");
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.appendChild(this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_confirmationChargesOnSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let confirmationInstructions = letterOfCredit.m_getConfirmationInstructions__();
    confirmationInstructions.m_setConfirmationRequired__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_chargesInstructionsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getValue__()));
    if (confirmationInstructions.m_isConfirmationRequired__()) {
      confirmationInstructions.m_setConfirmationChargesOn__java_lang_String(Boolean.m_booleanValue__java_lang_Boolean(this.f_confirmationChargesOnSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getValue__()) ? "APPLICANT" : "BENEFICIARIES");
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_) && this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_confirmationInstructionsCard__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_, true, false);
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection() {
    return !Boolean.m_booleanValue__java_lang_Boolean(this.f_chargesInstructionsRequiredSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getValue__()) || (!Boolean.m_booleanValue__java_lang_Boolean(this.f_confirmationChargesOnSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getValue__()) || this.f_confirmationChargesAccountSelect__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_.m_getAccountSelect__().m_validate__().m_isValid__());
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ConfirmationInstructionsSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ConfirmationInstructionsSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ConfirmationInstructionsSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ConfirmationInstructionsSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    CorporateAccountsSelect = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CorporateAccountsSelect$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ConfirmationInstructionsSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.ConfirmationInstructionsSection'));


ImportSection.$markImplementor(ConfirmationInstructionsSection);


exports = ConfirmationInstructionsSection; 
//# sourceMappingURL=ConfirmationInstructionsSection.js.map