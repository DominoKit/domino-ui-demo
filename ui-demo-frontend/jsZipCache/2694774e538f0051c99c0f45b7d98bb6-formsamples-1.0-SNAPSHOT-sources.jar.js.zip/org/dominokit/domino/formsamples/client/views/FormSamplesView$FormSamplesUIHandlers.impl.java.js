/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.FormSamplesView$FormSamplesUIHandlers.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const UiHandlers = goog.require('org.dominokit.domino.api.client.mvp.view.UiHandlers$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers.$LambdaAdaptor$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');


/**
 * @interface
 * @extends {UiHandlers}
 */
class FormSamplesUIHandlers {
  /**
   * @abstract
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_onCreate__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
  }
  
  /**
   * @param {?function(LetterOfCredit):void} fn
   * @return {FormSamplesUIHandlers}
   * @public
   */
  static $adapt(fn) {
    FormSamplesUIHandlers.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    UiHandlers.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormSamplesUIHandlers.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(FormSamplesUIHandlers, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.FormSamplesView$FormSamplesUIHandlers'));


FormSamplesUIHandlers.$markImplementor(/** @type {Function} */ (FormSamplesUIHandlers));


exports = FormSamplesUIHandlers; 
//# sourceMappingURL=FormSamplesView$FormSamplesUIHandlers.js.map