/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _CorporateAccount = goog.require('org.dominokit.domino.formsamples.shared.model.CorporateAccount');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');


// Re-exports the implementation.
var AccountDetailsPopupPosition = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.AccountDetailsPopupPosition$impl');
exports = AccountDetailsPopupPosition;
 