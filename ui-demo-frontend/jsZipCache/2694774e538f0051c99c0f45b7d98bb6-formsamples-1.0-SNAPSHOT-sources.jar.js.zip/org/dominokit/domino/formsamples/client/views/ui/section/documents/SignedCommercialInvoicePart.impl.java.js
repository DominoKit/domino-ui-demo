/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$27 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.$LambdaAdaptor$27$impl');
let $LambdaAdaptor$28 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.$LambdaAdaptor$28$impl');
let $LambdaAdaptor$29 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.$LambdaAdaptor$29$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Country$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let SignedCommercialInvoice = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.SignedCommercialInvoice$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class SignedCommercialInvoicePart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_signedCommercialInvoiceOriginalCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {TextBox} */
    this.f_signedCommercialInvoiceCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {SwitchButton} */
    this.f_signedCommercialInvoiceRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {TextBox} */
    this.f_signedCommercialInvoiceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {Select<?string>} */
    this.f_signedCommercialLocalizationEntitiesSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {Select<Country>} */
    this.f_signedCommercialOriginCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {Select<Country>} */
    this.f_signedCommercialOriginOfGoodsCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {Select<Country>} */
    this.f_signedCommercialOriginOfLocalizationEntityCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {Card} */
    this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
  }
  
  /**
   * Factory method corresponding to constructor 'SignedCommercialInvoicePart(List)'.
   * @param {List<Country>} countries
   * @return {!SignedCommercialInvoicePart}
   * @public
   */
  static $create__java_util_List(countries) {
    SignedCommercialInvoicePart.$clinit();
    let $instance = new SignedCommercialInvoicePart();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart__java_util_List(countries);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SignedCommercialInvoicePart(List)'.
   * @param {List<Country>} countries
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart__java_util_List(countries) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart();
    this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = Card.m_create__java_lang_String("Signed commercial invoice in").m_setBodyPaddingTop__java_lang_String("40px").m_collapse__();
    this.f_signedCommercialInvoiceOriginalCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(CustomElements.m_createCopiesField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), TextBox)).m_setLabel__java_lang_String("Number of original copies"), TextBox));
    this.f_signedCommercialInvoiceOriginalCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$27(((/** Event */ evt) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialInvoiceCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {TextBox} */ ($Casts.$to(CustomElements.m_createCopiesField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), TextBox));
    this.f_signedCommercialInvoiceCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$28(((/** Event */ evt$1$) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialInvoiceRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {SwitchButton} */ ($Casts.$to(CustomElements.m_createRequiredField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), SwitchButton)).m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_expand__();
      } else {
        this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_signedCommercialInvoiceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {TextBox} */ ($Casts.$to(CustomElements.m_createDescriptionField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), TextBox));
    this.f_signedCommercialInvoiceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$29(((/** Event */ evt$2$) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialLocalizationEntitiesSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Legalization entities")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Select)).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_domain__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Chamber of commerce", "Chamber of commerce"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Official trade office", "Official trade office"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Chamber of industries", "Chamber of industries"))).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialOriginCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {Select<Country>} */ ($Casts.$to(/**@type {Select<Country>} */ ($Casts.$to(CustomElements.m_createCountriesSelect__java_lang_String__java_util_List("Country of origins", countries).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Select)).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Country> */ option$1$) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialOriginOfGoodsCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {Select<Country>} */ ($Casts.$to(/**@type {Select<Country>} */ ($Casts.$to(CustomElements.m_createCountriesSelect__java_lang_String__java_util_List("Origin of goods", countries).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Select)).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Country> */ option$2$) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialOriginOfLocalizationEntityCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {Select<Country>} */ ($Casts.$to(/**@type {Select<Country>} */ ($Casts.$to(CustomElements.m_createCountriesSelect__java_lang_String__java_util_List("Country of legalization entities", countries).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Select)).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Country> */ option$3$) =>{
      this.m_revalidate__();
    })));
    this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_signedCommercialInvoiceRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.appendChild(this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialInvoiceOriginalCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialInvoiceCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span8__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialInvoiceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialLocalizationEntitiesSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialOriginCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialOriginOfGoodsCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_signedCommercialOriginOfLocalizationEntityCountrySelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let documentsRequired = letterOfCredit.m_getDocumentsRequired__();
    let signedCommercialInvoice = SignedCommercialInvoice.$create__();
    signedCommercialInvoice.m_setRequired__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_signedCommercialInvoiceRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getValue__()));
    if (signedCommercialInvoice.m_isRequired__()) {
      signedCommercialInvoice.m_setDescription__java_lang_String(this.f_signedCommercialInvoiceTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getValue__());
      signedCommercialInvoice.m_setNumberOfCopies__int(Integer.m_parseInt__java_lang_String(this.f_signedCommercialInvoiceCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getValue__()));
    }
    documentsRequired.m_setSignedCommercialInvoice__org_dominokit_domino_formsamples_shared_model_SignedCommercialInvoice(signedCommercialInvoice);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_) && this.m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_signedCommercialInvoiceInCard__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_, true, false);
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isValid___$p_org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart() {
    return !Boolean.m_booleanValue__java_lang_Boolean(this.f_signedCommercialInvoiceRequiredSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_getValue__()) || this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_.m_validate__().m_isValid__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart() {
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = FieldsGrouping.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_SignedCommercialInvoicePart_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SignedCommercialInvoicePart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SignedCommercialInvoicePart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SignedCommercialInvoicePart.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$27 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.$LambdaAdaptor$27$impl');
    $LambdaAdaptor$28 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.$LambdaAdaptor$28$impl');
    $LambdaAdaptor$29 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart.$LambdaAdaptor$29$impl');
    SignedCommercialInvoice = goog.module.get('org.dominokit.domino.formsamples.shared.model.SignedCommercialInvoice$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SignedCommercialInvoicePart, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart'));


ImportSection.$markImplementor(SignedCommercialInvoicePart);


exports = SignedCommercialInvoicePart; 
//# sourceMappingURL=SignedCommercialInvoicePart.js.map