/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.$LambdaAdaptor$25$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.$LambdaAdaptor$26$impl');
let AirwayBill = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let OceanBillsOfLanding = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.OceanBillsOfLanding$impl');
let TruckConsignmentNote = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.TruckConsignmentNote$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class ShippingDocumentsPart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {SwitchButton} */
    this.f_shippingDocumentsSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {TextBox} */
    this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {TextBox} */
    this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {Select<?string>} */
    this.f_shippingDocumentsTypeSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {Select<Bank>} */
    this.f_orderOfBankSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {Select<?string>} */
    this.f_freightSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
  }
  
  /**
   * Factory method corresponding to constructor 'ShippingDocumentsPart(List)'.
   * @param {List<Bank>} banks
   * @return {!ShippingDocumentsPart}
   * @public
   */
  static $create__java_util_List(banks) {
    ShippingDocumentsPart.$clinit();
    let $instance = new ShippingDocumentsPart();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart__java_util_List(banks);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ShippingDocumentsPart(List)'.
   * @param {List<Bank>} banks
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart__java_util_List(banks) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart();
    let shippingDocumentInfoRow = Row.m_create__();
    let shippingDocumentSelectRow = Row.m_create__();
    this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(CustomElements.m_createCopiesField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setRequired__boolean(true), TextBox));
    this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$25(((/** Event */ evt) =>{
      this.m_revalidate__();
    })));
    this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(CustomElements.m_createDescriptionField__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setRequired__boolean(true), TextBox));
    this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$26(((/** Event */ evt$1$) =>{
      this.m_revalidate__();
    })));
    this.f_orderOfBankSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = /**@type {Select<Bank>} */ ($Casts.$to(/**@type {Select<Bank>} */ ($Casts.$to(/**@type {Select<Bank>} */ (Select.m_create__java_lang_String("Order of")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Select)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_domain__()).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Bank> */ option) =>{
      this.m_revalidate__();
    })));
    for (let $iterator = banks.m_iterator__(); $iterator.m_hasNext__(); ) {
      let bank = /**@type {Bank} */ ($Casts.$to($iterator.m_next__(), Bank));
      this.f_orderOfBankSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Bank>} */ (SelectOption.m_create__java_lang_Object__java_lang_String__java_lang_String(bank, bank.m_getSwiftCode__(), bank.m_getName__())));
    }
    this.f_freightSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Freight")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Select)).m_setAutoValidation__boolean(true).m_setRequired__boolean(true), Select)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_credit_card__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Prepaid", "Prepaid"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Payable at destination", "Payable at destination"))).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option$1$) =>{
      this.m_revalidate__();
    })));
    this.f_shippingDocumentsTypeSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Shipping documents type")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_local_shipping__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Ocean bills of lading in", "Ocean bills of lading in"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Airway bill in", "Airway bill in"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Truck consignment note", "Truck consignment note"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("Multimodal transport document", "Multimodal transport document"))).m_selectAt__int(0).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option$2$) =>{
      this.m_revalidate__();
    })));
    this.f_shippingDocumentsSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = CustomElements.m_createRequiredField__().m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(value)) {
        this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_expand__();
      } else {
        this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_collapse__();
        this.m_revalidate__();
      }
    })));
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = Card.m_create__java_lang_String("Shipping documents").m_setBodyPaddingTop__java_lang_String("40px").m_collapse__();
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getHeaderDescription__().m_appendChild__elemental2_dom_Node(this.f_shippingDocumentsSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.appendChild(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_shippingDocumentsTypeSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(shippingDocumentInfoRow.m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Column))).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(shippingDocumentSelectRow.m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_orderOfBankSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Column))).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_freightSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_), Column)))).m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    if (Boolean.m_booleanValue__java_lang_Boolean(this.f_shippingDocumentsSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__())) {
      let documentsRequired = letterOfCredit.m_getDocumentsRequired__();
      if (j_l_String.m_equals__java_lang_String__java_lang_Object("Ocean bills of lading in", this.f_shippingDocumentsTypeSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__())) {
        let oceanBillsOfLanding = OceanBillsOfLanding.$create__();
        oceanBillsOfLanding.m_setRequired__boolean(true);
        oceanBillsOfLanding.m_setNumberOfCopies__int(Integer.m_parseInt__java_lang_String(this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__()));
        oceanBillsOfLanding.m_setDescription__java_lang_String(this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__());
        documentsRequired.m_setOceanBillsOfLanding__org_dominokit_domino_formsamples_shared_model_OceanBillsOfLanding(oceanBillsOfLanding);
      } else if (j_l_String.m_equals__java_lang_String__java_lang_Object("Airway bill in", this.f_shippingDocumentsTypeSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__())) {
        let airwayBill = AirwayBill.$create__();
        airwayBill.m_setRequired__boolean(true);
        airwayBill.m_setNumberOfCopies__int(Integer.m_parseInt__java_lang_String(this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__()));
        airwayBill.m_setDescription__java_lang_String(this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__());
        documentsRequired.m_setAirwayBill__org_dominokit_domino_formsamples_shared_model_AirwayBill(airwayBill);
      } else if (j_l_String.m_equals__java_lang_String__java_lang_Object("Truck consignment note", this.f_shippingDocumentsTypeSelect__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__())) {
        let truckConsignmentNote = TruckConsignmentNote.$create__();
        truckConsignmentNote.m_setRequired__boolean(true);
        truckConsignmentNote.m_setNumberOfCopies__int(Integer.m_parseInt__java_lang_String(this.f_shippingDocumentsCopiesTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__()));
        truckConsignmentNote.m_setDescription__java_lang_String(this.f_shippingDocumentsDescriptionTextBox__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__());
        documentsRequired.m_setTruckConsignmentNote__org_dominokit_domino_formsamples_shared_model_TruckConsignmentNote(truckConsignmentNote);
      }
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = !Boolean.m_booleanValue__java_lang_Boolean(this.f_shippingDocumentsSwitchButton__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_getValue__()) || this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_, valid);
    return valid;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate__() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_) && this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_.m_validate__().m_isValid__()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_, true, false);
    }
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart() {
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = FieldsGrouping.m_create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_documents_ShippingDocumentsPart_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ShippingDocumentsPart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ShippingDocumentsPart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ShippingDocumentsPart.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.$LambdaAdaptor$25$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.$LambdaAdaptor$26$impl');
    AirwayBill = goog.module.get('org.dominokit.domino.formsamples.shared.model.AirwayBill$impl');
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    OceanBillsOfLanding = goog.module.get('org.dominokit.domino.formsamples.shared.model.OceanBillsOfLanding$impl');
    TruckConsignmentNote = goog.module.get('org.dominokit.domino.formsamples.shared.model.TruckConsignmentNote$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ShippingDocumentsPart, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart'));


ImportSection.$markImplementor(ShippingDocumentsPart);


exports = ShippingDocumentsPart; 
//# sourceMappingURL=ShippingDocumentsPart.js.map