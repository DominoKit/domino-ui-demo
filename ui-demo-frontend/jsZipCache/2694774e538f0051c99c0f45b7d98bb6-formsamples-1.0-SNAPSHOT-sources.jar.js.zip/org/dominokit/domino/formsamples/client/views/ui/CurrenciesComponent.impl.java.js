/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JsNumber_$Overlay = goog.forwardDeclare('elemental2.core.JsNumber.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let Exception = goog.forwardDeclare('java.lang.Exception$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent.$LambdaAdaptor$2$impl');
let CurrencyData = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CurrencyData$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


class CurrenciesComponent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<CurrencyData>} */
    this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_;
    /** @public {TextBox} */
    this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_;
    /** @public {?string} */
    this.f_oldCurrencyCode__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_;
  }
  
  /**
   * Factory method corresponding to constructor 'CurrenciesComponent()'.
   * @return {!CurrenciesComponent}
   * @public
   */
  static $create__() {
    CurrenciesComponent.$clinit();
    let $instance = new CurrenciesComponent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CurrenciesComponent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent__() {
    this.$ctor__java_lang_Object__();
    this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_ = /**@type {Select<CurrencyData>} */ (Select.m_create__java_lang_String("Currency")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas", "fa-money-bill-alt", "fa-lg"], j_l_String))));
    this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_ = /**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Amount").m_setHelperText__java_lang_String("Numbers only"), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attach_money__()), TextBox))), TextBox));
    this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("change", new $LambdaAdaptor$2(((/** Event */ evt) =>{
      this.m_formatAmount__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent(this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_getSelectedOption__());
    })));
    this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<CurrencyData> */ arg0) =>{
      this.m_formatAmount__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent(arg0);
    })));
  }
  
  /**
   * @param {SelectOption<CurrencyData>} option
   * @return {void}
   * @public
   */
  m_formatAmount__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent(option) {
    if (Objects.m_nonNull__java_lang_Object(option) && !this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_isEmpty__()) {
      let value = this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_getValue__();
      let currencyCode = option.m_getKey__();
      let amount = this.m_parseAmount__java_lang_String__java_lang_String_$p_org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent(this.f_oldCurrencyCode__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_, value);
      let options = /**@type {Object<string, ?string>} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
      $Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(options, "style", "currency");
      $Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(options, "currency", currencyCode);
      let formattedAmount = JsNumber_$Overlay.m_toLocaleString__elemental2_core_JsNumber__java_lang_String__java_lang_Object(new Number(amount), "en", options);
      this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_setValue__java_lang_Object(formattedAmount);
      this.f_oldCurrencyCode__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_ = option.m_getKey__();
    }
  }
  
  /**
   * @param {?string} currencyCode
   * @param {?string} amount
   * @return {number}
   * @public
   */
  m_parseAmount__java_lang_String__java_lang_String_$p_org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent(currencyCode, amount) {
    try {
      return Number.parseFloat(amount);
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (Exception.$isInstance(__$exc)) {
        let ex = /**@type {Exception} */ (__$exc);
        return Double.m_parseDouble__java_lang_String(amount);
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @return {CurrenciesComponent}
   * @public
   */
  static m_create__() {
    CurrenciesComponent.$clinit();
    return CurrenciesComponent.$create__();
  }
  
  /**
   * @param {List<CurrencyData>} currencies
   * @return {CurrenciesComponent}
   * @public
   */
  m_setCurrencies__java_util_List(currencies) {
    this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_removeAllOptions__();
    for (let $iterator = currencies.m_iterator__(); $iterator.m_hasNext__(); ) {
      let cd = /**@type {CurrencyData} */ ($Casts.$to($iterator.m_next__(), CurrencyData));
      this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<CurrencyData>} */ (SelectOption.m_create__java_lang_Object__java_lang_String__java_lang_String(cd, cd.m_getCurrencyCode__(), j_l_String.m_valueOf__java_lang_Object(cd.m_getCurrencyCode__()) + " - " + j_l_String.m_valueOf__java_lang_Object(cd.m_getDisplayName__()))));
    }
    return this;
  }
  
  /**
   * @return {Select<CurrencyData>}
   * @public
   */
  m_getCurrencySelect__() {
    return this.f_currencySelect__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_;
  }
  
  /**
   * @return {TextBox}
   * @public
   */
  m_getAmountField__() {
    return this.f_amountField__org_dominokit_domino_formsamples_client_views_ui_CurrenciesComponent_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CurrenciesComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CurrenciesComponent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CurrenciesComponent.$clinit = function() {};
    JsNumber_$Overlay = goog.module.get('elemental2.core.JsNumber.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    Exception = goog.module.get('java.lang.Exception$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent.$LambdaAdaptor$2$impl');
    CurrencyData = goog.module.get('org.dominokit.domino.formsamples.shared.model.CurrencyData$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CurrenciesComponent, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent'));




exports = CurrenciesComponent; 
//# sourceMappingURL=CurrenciesComponent.js.map