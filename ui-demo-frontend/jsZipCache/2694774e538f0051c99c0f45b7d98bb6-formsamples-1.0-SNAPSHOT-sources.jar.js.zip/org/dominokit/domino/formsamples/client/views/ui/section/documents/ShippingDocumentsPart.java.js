/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _$LambdaAdaptor$25 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.$LambdaAdaptor$25');
const _$LambdaAdaptor$26 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart.$LambdaAdaptor$26');
const _AirwayBill = goog.require('org.dominokit.domino.formsamples.shared.model.AirwayBill');
const _Bank = goog.require('org.dominokit.domino.formsamples.shared.model.Bank');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _OceanBillsOfLanding = goog.require('org.dominokit.domino.formsamples.shared.model.OceanBillsOfLanding');
const _TruckConsignmentNote = goog.require('org.dominokit.domino.formsamples.shared.model.TruckConsignmentNote');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ShippingDocumentsPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart$impl');
exports = ShippingDocumentsPart;
 