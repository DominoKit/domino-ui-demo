/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.BanksComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.BanksComponent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let Branch = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Branch$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class BanksComponent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<Bank>} */
    this.f_banksSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_;
    /** @public {Select<Branch>} */
    this.f_branchesSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_;
  }
  
  /**
   * Factory method corresponding to constructor 'BanksComponent()'.
   * @return {!BanksComponent}
   * @public
   */
  static $create__() {
    BanksComponent.$clinit();
    let $instance = new BanksComponent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_BanksComponent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BanksComponent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_BanksComponent__() {
    this.$ctor__java_lang_Object__();
    this.f_banksSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_ = /**@type {Select<Bank>} */ (Select.m_create__java_lang_String("Bank")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas", "fa-university", "fa-lg"], j_l_String))));
    this.f_branchesSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_ = /**@type {Select<Branch>} */ (Select.m_create__java_lang_String("Branch")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_domain__()).m_disable__();
    this.f_banksSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Bank> */ option) =>{
      this.f_branchesSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_.m_enable__();
      let bank = /**@type {Bank} */ ($Casts.$to(option.m_getValue__(), Bank));
      let branches = bank.m_getBranches__();
      this.f_branchesSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_.m_removeAllOptions__();
      for (let $iterator = branches.m_iterator__(); $iterator.m_hasNext__(); ) {
        let branch = /**@type {Branch} */ ($Casts.$to($iterator.m_next__(), Branch));
        this.f_branchesSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Branch>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(branch, branch.m_getName__())));
      }
    })));
  }
  
  /**
   * Factory method corresponding to constructor 'BanksComponent(List)'.
   * @param {List<Bank>} banks
   * @return {!BanksComponent}
   * @public
   */
  static $create__java_util_List(banks) {
    BanksComponent.$clinit();
    let $instance = new BanksComponent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_BanksComponent__java_util_List(banks);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BanksComponent(List)'.
   * @param {List<Bank>} banks
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_BanksComponent__java_util_List(banks) {
    this.$ctor__org_dominokit_domino_formsamples_client_views_ui_BanksComponent__();
    this.m_setBanks__java_util_List(banks);
  }
  
  /**
   * @return {BanksComponent}
   * @public
   */
  static m_create__() {
    BanksComponent.$clinit();
    return BanksComponent.$create__();
  }
  
  /**
   * @param {List<Bank>} banks
   * @return {BanksComponent}
   * @public
   */
  static m_create__java_util_List(banks) {
    BanksComponent.$clinit();
    return BanksComponent.$create__java_util_List(banks);
  }
  
  /**
   * @param {List<Bank>} banks
   * @return {BanksComponent}
   * @public
   */
  m_setBanks__java_util_List(banks) {
    this.f_banksSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_.m_removeAllOptions__();
    for (let $iterator = banks.m_iterator__(); $iterator.m_hasNext__(); ) {
      let bank = /**@type {Bank} */ ($Casts.$to($iterator.m_next__(), Bank));
      this.f_banksSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Bank>} */ (SelectOption.m_create__java_lang_Object__java_lang_String__java_lang_String(bank, bank.m_getSwiftCode__(), bank.m_getName__())));
    }
    return this;
  }
  
  /**
   * @return {Select<Bank>}
   * @public
   */
  m_getBanksSelect__() {
    return this.f_banksSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_;
  }
  
  /**
   * @return {Select<Branch>}
   * @public
   */
  m_getBranchesSelect__() {
    return this.f_branchesSelect__org_dominokit_domino_formsamples_client_views_ui_BanksComponent_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BanksComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BanksComponent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BanksComponent.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Bank = goog.module.get('org.dominokit.domino.formsamples.shared.model.Bank$impl');
    Branch = goog.module.get('org.dominokit.domino.formsamples.shared.model.Branch$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BanksComponent, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.BanksComponent'));




exports = BanksComponent; 
//# sourceMappingURL=BanksComponent.js.map