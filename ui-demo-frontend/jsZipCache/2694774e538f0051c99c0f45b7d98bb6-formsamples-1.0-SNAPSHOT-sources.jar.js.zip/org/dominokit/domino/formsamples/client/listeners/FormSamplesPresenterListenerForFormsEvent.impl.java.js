/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.listeners.FormSamplesPresenterListenerForFormsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.listeners.FormSamplesPresenterListenerForFormsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsEvent = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
let FormSamplesPresenter = goog.forwardDeclare('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter$impl');
let FormSamplesPresenterCommand = goog.forwardDeclare('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<FormsEvent>}
  */
class FormSamplesPresenterListenerForFormsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormSamplesPresenterListenerForFormsEvent()'.
   * @return {!FormSamplesPresenterListenerForFormsEvent}
   * @public
   */
  static $create__() {
    FormSamplesPresenterListenerForFormsEvent.$clinit();
    let $instance = new FormSamplesPresenterListenerForFormsEvent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_listeners_FormSamplesPresenterListenerForFormsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormSamplesPresenterListenerForFormsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_listeners_FormSamplesPresenterListenerForFormsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {FormsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_forms_shared_extension_FormsEvent(event) {
    FormSamplesPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** FormSamplesPresenter */ presenter) =>{
      presenter.m_onFormsEvent__org_dominokit_domino_forms_shared_extension_FormsContext(/**@type {FormsContext} */ ($Casts.$to(event.m_context__(), FormsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_forms_shared_extension_FormsEvent(/**@type {FormsEvent} */ ($Casts.$to(arg0, FormsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormSamplesPresenterListenerForFormsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormSamplesPresenterListenerForFormsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormSamplesPresenterListenerForFormsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsEvent = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsEvent$impl');
    FormSamplesPresenterCommand = goog.module.get('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormSamplesPresenterListenerForFormsEvent, $Util.$makeClassName('org.dominokit.domino.formsamples.client.listeners.FormSamplesPresenterListenerForFormsEvent'));


DominoEventListener.$markImplementor(FormSamplesPresenterListenerForFormsEvent);


exports = FormSamplesPresenterListenerForFormsEvent; 
//# sourceMappingURL=FormSamplesPresenterListenerForFormsEvent.js.map