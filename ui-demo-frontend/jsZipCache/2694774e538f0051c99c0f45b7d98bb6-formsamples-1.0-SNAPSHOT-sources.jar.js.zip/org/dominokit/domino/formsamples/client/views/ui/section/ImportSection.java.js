/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ImportSection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');


// Re-exports the implementation.
var ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');
exports = ImportSection;
 