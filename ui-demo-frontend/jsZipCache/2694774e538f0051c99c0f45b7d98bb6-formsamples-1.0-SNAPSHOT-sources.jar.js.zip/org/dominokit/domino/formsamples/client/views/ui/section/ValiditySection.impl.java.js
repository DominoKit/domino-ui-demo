/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Constants = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
let CountriesComponent = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CountriesComponent$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection.$LambdaAdaptor$13$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Country$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let DateTimeFormat = goog.forwardDeclare('org.gwtproject.i18n.client.DateTimeFormat$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class ValiditySection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<Country>} */
    this.f_countrySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
    /** @public {Select<?string>} */
    this.f_citySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
    /** @public {DateBox} */
    this.f_validityExpiryDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
    /** @public {TextBox} */
    this.f_daysForShipmentTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
  }
  
  /**
   * Factory method corresponding to constructor 'ValiditySection(List)'.
   * @param {List<Country>} countries
   * @return {!ValiditySection}
   * @public
   */
  static $create__java_util_List(countries) {
    ValiditySection.$clinit();
    let $instance = new ValiditySection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection__java_util_List(countries);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ValiditySection(List)'.
   * @param {List<Country>} countries
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection__java_util_List(countries) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.appendChild(BlockHeader.m_create__java_lang_String("Validity *").m_asElement__());
    let countriesComponent = CountriesComponent.m_create__java_util_List(countries);
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = Card.m_create__();
    this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    this.f_countrySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = /**@type {Select<Country>} */ ($Casts.$to(/**@type {Select<Country>} */ ($Casts.$to(countriesComponent.m_getCountriesSelect__().m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Country> */ option) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    })));
    this.f_citySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(countriesComponent.m_getCitiesSelect__().m_setLabel__java_lang_String("City / Town"), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), Select)).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option$1$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    })));
    this.f_validityExpiryDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = /**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(DateBox.m_create__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), DateBox)).m_setRequired__boolean(true), DateBox)).m_setAutoValidation__boolean(true), DateBox)).m_setPattern__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants).m_setLabel__java_lang_String("Expiry Date Of Credit"), DateBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_date_range__()), DateBox)).m_setHelperText__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants), DateBox));
    this.f_validityExpiryDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$12(((/** Event */ evt) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    })));
    this.f_validityExpiryDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getDatePicker__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    })));
    this.f_daysForShipmentTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Days for Shipping Documents").m_value__java_lang_Object("21"), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_looks_one__()), TextBox)).m_setHelperText__java_lang_String(Constants.f_NUMBERS_ONLY__org_dominokit_domino_formsamples_client_views_ui_Constants), TextBox));
    this.f_daysForShipmentTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$13(((/** Event */ evt$1$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection();
    })));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.appendChild(/**@type {Card} */ ($Casts.$to(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_validityExpiryDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_countrySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_citySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(this.f_daysForShipmentTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_), IsElement))), Column)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_) && this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_validate__().m_isValid__()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_, true, false);
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_, valid);
    return valid;
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let validity = letterOfCredit.m_getValidity__();
    validity.m_setCity__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_citySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getValue__(), j_l_String)));
    validity.m_setCountry__java_lang_String(/**@type {Country} */ ($Casts.$to(this.f_countrySelect__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getValue__(), Country)).m_getIso__());
    validity.m_setDaysForPresentingDocuments__int(Integer.m_parseInt__java_lang_String(this.f_daysForShipmentTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getValue__()));
    validity.m_setExpiryDateOfCredit__java_lang_String(DateTimeFormat.m_getFormat__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants).m_format__java_util_Date(this.f_validityExpiryDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_.m_getValue__()));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ValiditySection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ValiditySection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ValiditySection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ValiditySection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Constants = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
    CountriesComponent = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CountriesComponent$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection.$LambdaAdaptor$13$impl');
    Country = goog.module.get('org.dominokit.domino.formsamples.shared.model.Country$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    DateTimeFormat = goog.module.get('org.gwtproject.i18n.client.DateTimeFormat$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ValiditySection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection'));


ImportSection.$markImplementor(ValiditySection);


exports = ValiditySection; 
//# sourceMappingURL=ValiditySection.js.map