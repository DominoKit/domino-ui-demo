/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let FormSamplesUIHandlers = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.FormSamplesView.FormSamplesUIHandlers$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent.$LambdaAdaptor$1$impl');
let ApplicantSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ApplicantSection$impl');
let AuthorizationSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection$impl');
let BeneficiarySection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.BeneficiarySection$impl');
let ConfirmationInstructionsSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ConfirmationInstructionsSection$impl');
let CorrespondentChargesInstructionsSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection$impl');
let CreditAmountAndToleranceSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection$impl');
let DocumentsRequiredSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection$impl');
let GeneralSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.GeneralSection$impl');
let GoodsDescriptionSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection$impl');
let IssuerBankSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.IssuerBankSection$impl');
let PaymentScheduleSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection$impl');
let ShipmentDetailsSection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection$impl');
let ValiditySection = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let Beneficiary = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Beneficiary$impl');
let CorporateProfile = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CorporateProfile$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Country$impl');
let CurrencyData = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.CurrencyData$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
  */
class AddLCImportComponent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {CorporateProfile} */
    this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {List<Country>} */
    this.f_countries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {List<Beneficiary>} */
    this.f_beneficiaries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {List<Bank>} */
    this.f_banks__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {List<CurrencyData>} */
    this.f_currencies__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {GeneralSection} */
    this.f_generalSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {IssuerBankSection} */
    this.f_issuerBankSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {AuthorizationSection} */
    this.f_authorizationSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {ApplicantSection} */
    this.f_applicantSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {BeneficiarySection} */
    this.f_beneficiarySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {CreditAmountAndToleranceSection} */
    this.f_creditAmountAndToleranceSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {PaymentScheduleSection} */
    this.f_paymentScheduleSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {ValiditySection} */
    this.f_validitySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {ShipmentDetailsSection} */
    this.f_shipmentDetailsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {DocumentsRequiredSection} */
    this.f_documentsRequiredSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {GoodsDescriptionSection} */
    this.f_goodsDescriptionSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {ConfirmationInstructionsSection} */
    this.f_confirmationInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {CorrespondentChargesInstructionsSection} */
    this.f_correspondentChargesInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
    /** @public {FormSamplesUIHandlers} */
    this.f_uiHandlers__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
  }
  
  /**
   * Factory method corresponding to constructor 'AddLCImportComponent(CorporateProfile, List, List, List, List)'.
   * @param {CorporateProfile} corporateProfile
   * @param {List<Country>} countries
   * @param {List<Beneficiary>} beneficiaries
   * @param {List<Bank>} banks
   * @param {List<CurrencyData>} currencies
   * @return {!AddLCImportComponent}
   * @public
   */
  static $create__org_dominokit_domino_formsamples_shared_model_CorporateProfile__java_util_List__java_util_List__java_util_List__java_util_List(corporateProfile, countries, beneficiaries, banks, currencies) {
    AddLCImportComponent.$clinit();
    let $instance = new AddLCImportComponent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent__org_dominokit_domino_formsamples_shared_model_CorporateProfile__java_util_List__java_util_List__java_util_List__java_util_List(corporateProfile, countries, beneficiaries, banks, currencies);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AddLCImportComponent(CorporateProfile, List, List, List, List)'.
   * @param {CorporateProfile} corporateProfile
   * @param {List<Country>} countries
   * @param {List<Beneficiary>} beneficiaries
   * @param {List<Bank>} banks
   * @param {List<CurrencyData>} currencies
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent__org_dominokit_domino_formsamples_shared_model_CorporateProfile__java_util_List__java_util_List__java_util_List__java_util_List(corporateProfile, countries, beneficiaries, banks, currencies) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent();
    this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = corporateProfile;
    this.f_countries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = countries;
    this.f_beneficiaries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = beneficiaries;
    this.f_banks__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = banks;
    this.f_currencies__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = currencies;
    this.f_generalSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = GeneralSection.$create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_issuerBankSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = IssuerBankSection.$create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_authorizationSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = AuthorizationSection.$create__();
    this.f_applicantSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = ApplicantSection.$create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_beneficiarySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = BeneficiarySection.$create__java_util_List(this.f_beneficiaries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_creditAmountAndToleranceSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = CreditAmountAndToleranceSection.$create__java_util_List(this.f_currencies__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_paymentScheduleSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = PaymentScheduleSection.$create__();
    this.f_validitySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = ValiditySection.$create__java_util_List(this.f_countries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_shipmentDetailsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = ShipmentDetailsSection.$create__();
    this.f_documentsRequiredSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = DocumentsRequiredSection.$create__java_util_List__java_util_List(this.f_banks__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_, this.f_countries__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_goodsDescriptionSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = GoodsDescriptionSection.$create__();
    this.f_confirmationInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = ConfirmationInstructionsSection.$create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_correspondentChargesInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = CorrespondentChargesInstructionsSection.$create__org_dominokit_domino_formsamples_shared_model_CorporateProfile(this.f_corporateProfile__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_);
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_generalSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_issuerBankSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_authorizationSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_applicantSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_beneficiarySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_creditAmountAndToleranceSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_paymentScheduleSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_validitySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_shipmentDetailsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_documentsRequiredSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_goodsDescriptionSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(BlockHeader.m_create__java_lang_String("Instructions").m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_confirmationInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(this.f_correspondentChargesInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_style__().m_setMarginBottom__java_lang_String("50px").m_get__(), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("Submit").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      if (this.m_isFormValid__()) {
        this.f_uiHandlers__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_onCreate__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(this.m_createLetterOfCredit___$p_org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent());
      }
    }))), Button)).m_style__().m_setMinWidth__java_lang_String("120px").m_get__()), Column))), Row__12)).m_asElement__());
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isFormValid__() {
    return !!(+!!(+!!(+!!(+!!(+!!(+!!(+!!(+!!(+!!(+!!(+!!(+this.f_correspondentChargesInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__() & +this.f_confirmationInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_goodsDescriptionSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_documentsRequiredSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_shipmentDetailsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_validitySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_paymentScheduleSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_creditAmountAndToleranceSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_beneficiarySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_applicantSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_authorizationSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_issuerBankSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__()) & +this.f_generalSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_validate__());
  }
  
  /**
   * @param {FormSamplesUIHandlers} uiHandlers
   * @return {void}
   * @public
   */
  m_setUiHandlers__org_dominokit_domino_formsamples_client_views_FormSamplesView_FormSamplesUIHandlers(uiHandlers) {
    this.f_uiHandlers__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = uiHandlers;
  }
  
  /**
   * @return {LetterOfCredit}
   * @public
   */
  m_createLetterOfCredit___$p_org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent() {
    let letterOfCredit = LetterOfCredit.$create__();
    this.f_generalSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_issuerBankSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_authorizationSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_applicantSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_beneficiarySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_creditAmountAndToleranceSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_paymentScheduleSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_validitySection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_shipmentDetailsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_documentsRequiredSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_goodsDescriptionSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_confirmationInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_correspondentChargesInstructionsSection__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    return letterOfCredit;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_AddLCImportComponent_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["content-margin"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AddLCImportComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AddLCImportComponent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AddLCImportComponent.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent.$LambdaAdaptor$1$impl');
    ApplicantSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ApplicantSection$impl');
    AuthorizationSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.AuthorizationSection$impl');
    BeneficiarySection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.BeneficiarySection$impl');
    ConfirmationInstructionsSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ConfirmationInstructionsSection$impl');
    CorrespondentChargesInstructionsSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CorrespondentChargesInstructionsSection$impl');
    CreditAmountAndToleranceSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.CreditAmountAndToleranceSection$impl');
    DocumentsRequiredSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection$impl');
    GeneralSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.GeneralSection$impl');
    GoodsDescriptionSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.GoodsDescriptionSection$impl');
    IssuerBankSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.IssuerBankSection$impl');
    PaymentScheduleSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.PaymentScheduleSection$impl');
    ShipmentDetailsSection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection$impl');
    ValiditySection = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ValiditySection$impl');
    LetterOfCredit = goog.module.get('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AddLCImportComponent, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.AddLCImportComponent'));


IsElement.$markImplementor(AddLCImportComponent);


exports = AddLCImportComponent; 
//# sourceMappingURL=AddLCImportComponent.js.map