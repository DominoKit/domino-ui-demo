/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsNumber_$Overlay = goog.require('elemental2.core.JsNumber.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _Double = goog.require('java.lang.Double');
const _Exception = goog.require('java.lang.Exception');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent.$LambdaAdaptor$2');
const _CurrencyData = goog.require('org.dominokit.domino.formsamples.shared.model.CurrencyData');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var CurrenciesComponent = goog.require('org.dominokit.domino.formsamples.client.views.ui.CurrenciesComponent$impl');
exports = CurrenciesComponent;
 