package org.dominokit.domino.formsamples.client.views.ui;

public class Constants {
    public static final String DATE_PATTERN = "dd-MM-yyyy";
    public static final String NUMBERS_ONLY = "Numbers only";
}
