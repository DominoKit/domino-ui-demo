/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let Constants = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
let CustomElements = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$9$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let DateTimeFormat = goog.forwardDeclare('org.gwtproject.i18n.client.DateTimeFormat$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class ShipmentDetailsSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DateBox} */
    this.f_latestDateOfShipmentDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {Select<?string>} */
    this.f_shipmentBySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {SwitchButton} */
    this.f_partialShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {SwitchButton} */
    this.f_transShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {TextBox} */
    this.f_shipmentFromTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {TextBox} */
    this.f_shipmentToTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {TextBox} */
    this.f_placeOfDestinationTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {Select<?string>} */
    this.f_termsOfDeliverySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'ShipmentDetailsSection()'.
   * @return {!ShipmentDetailsSection}
   * @public
   */
  static $create__() {
    ShipmentDetailsSection.$clinit();
    let $instance = new ShipmentDetailsSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ShipmentDetailsSection()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = Card.m_create__();
    this.f_latestDateOfShipmentDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(DateBox.m_create__().m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), DateBox)).m_setRequired__boolean(true), DateBox)).m_setAutoValidation__boolean(true), DateBox)).m_setPattern__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants).m_setHelperText__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants), DateBox)).m_setLabel__java_lang_String("Latest Date Of Shipment"), DateBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_date_range__()), DateBox));
    this.f_latestDateOfShipmentDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getDatePicker__().m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_latestDateOfShipmentDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$8(((/** Event */ evt) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_shipmentBySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Shipment By")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_local_shipping__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("AIR_FREIGHT", "Air Freight"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("SEA_FREIGHT", "Sea Freight"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("LAND", "Land"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("MULTIMODAL", "Multimodal"))).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_partialShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = SwitchButton.m_create__java_lang_String__java_lang_String__java_lang_String("Partial Shipments", "Not permitted", "Permitted").m_value__java_lang_Boolean(true);
    this.f_transShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = SwitchButton.m_create__java_lang_String__java_lang_String__java_lang_String("Transshipment", "Not permitted", "Permitted");
    this.f_shipmentFromTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Shipment From").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_on__()), TextBox));
    this.f_shipmentFromTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$9(((/** Event */ evt$1$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_shipmentToTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Shipment To").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_on__()), TextBox));
    this.f_shipmentToTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$10(((/** Event */ evt$2$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_placeOfDestinationTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Place Of Destination").m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), TextBox)).m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_on__()), TextBox));
    this.f_placeOfDestinationTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", new $LambdaAdaptor$11(((/** Event */ evt$3$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_termsOfDeliverySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__java_lang_String("Terms Of Delivery (Incoterms 2010)")).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Select)).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_card_membership__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("EXW", "EXW \u2013 Ex Works (named place of delivery)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("FCA", "FCA \u2013 Free Carrier (named place of delivery)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("CPT", "CPT \u2013 Carriage Paid To (named place of destination)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("CIP", "CIP \u2013 Carriage and Insurance Paid to (named place of destination)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("DAT", "DAT \u2013 Delivered At Terminal (named terminal at port or place of destination)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("DAP", "DAP \u2013 Delivered At Place (named place of destination)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("DDP", "DDP \u2013 Delivered Duty Paid (named place of destination)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("FAS", "FAS \u2013 Free Alongside Ship (named port of shipment)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("FOB", "FOB \u2013 Free on Board (named port of shipment)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("CFR", "CFR \u2013 Cost and Freight (named port of destination)"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("CIF", "CIF \u2013 Cost, Insurance & Freight (named port of destination)"))).m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option$1$) =>{
      this.m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection();
    })));
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.appendChild(BlockHeader.m_create__java_lang_String("Shipment Details *").m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.appendChild(/**@type {Card} */ ($Casts.$to(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_style__().m_setPaddingTop__java_lang_String("20px").m_get__(), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_latestDateOfShipmentDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_transShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_shipmentBySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_partialShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_shipmentFromTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_shipmentToTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_termsOfDeliverySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_placeOfDestinationTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_), Column)))).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_revalidate___$p_org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection() {
    if (CustomElements.m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_) && this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_validate__().m_isValid__()) {
      CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_, true, false);
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    let valid = this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_validate__().m_isValid__();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(this.f_card__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_, valid);
    return valid;
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    let shipmentDetails = letterOfCredit.m_getShipmentDetails__();
    shipmentDetails.m_setLatestDateOfShipment__java_lang_String(DateTimeFormat.m_getFormat__java_lang_String(Constants.f_DATE_PATTERN__org_dominokit_domino_formsamples_client_views_ui_Constants).m_format__java_util_Date(this.f_latestDateOfShipmentDateBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__()));
    shipmentDetails.m_setPartialShipmentsPermitted__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_partialShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__()));
    shipmentDetails.m_setTransshipmentPermitted__boolean(Boolean.m_booleanValue__java_lang_Boolean(this.f_transShipmentSwitch__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__()));
    shipmentDetails.m_setShipmentBy__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_shipmentBySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__(), j_l_String)));
    shipmentDetails.m_setShipmentFrom__java_lang_String(this.f_shipmentFromTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__());
    shipmentDetails.m_setShipmentTo__java_lang_String(this.f_shipmentToTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__());
    shipmentDetails.m_setPlaceOfDestination__java_lang_String(this.f_placeOfDestinationTextBox__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__());
    shipmentDetails.m_setTermsOfDelivery__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_termsOfDeliverySelect__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_.m_getValue__(), j_l_String)));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_fieldsGrouping__org_dominokit_domino_formsamples_client_views_ui_section_ShipmentDetailsSection_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ShipmentDetailsSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ShipmentDetailsSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ShipmentDetailsSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Constants = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
    CustomElements = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection.$LambdaAdaptor$9$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    DateTimeFormat = goog.module.get('org.gwtproject.i18n.client.DateTimeFormat$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ShipmentDetailsSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.ShipmentDetailsSection'));


ImportSection.$markImplementor(ShipmentDetailsSection);


exports = ShipmentDetailsSection; 
//# sourceMappingURL=ShipmentDetailsSection.js.map