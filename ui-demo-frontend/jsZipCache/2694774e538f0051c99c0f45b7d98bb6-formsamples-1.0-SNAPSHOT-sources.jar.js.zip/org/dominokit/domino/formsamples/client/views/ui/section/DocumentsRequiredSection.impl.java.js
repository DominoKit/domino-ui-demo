/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let CertificateOfOriginPart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart$impl');
let DraftsPart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart$impl');
let InsurancePolicyPart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart$impl');
let OtherDocumentsPart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart$impl');
let PackingListPart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart$impl');
let ShippingDocumentsPart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart$impl');
let SignedCommercialInvoicePart = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart$impl');
let Bank = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Bank$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Country$impl');
let LetterOfCredit = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.LetterOfCredit$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ImportSection}
  */
class DocumentsRequiredSection extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DraftsPart} */
    this.f_draftsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {SignedCommercialInvoicePart} */
    this.f_signedCommercialInvoicePart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {CertificateOfOriginPart} */
    this.f_certificateOfOriginPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {PackingListPart} */
    this.f_packingListPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {ShippingDocumentsPart} */
    this.f_shippingDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {InsurancePolicyPart} */
    this.f_insurancePolicyPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {OtherDocumentsPart} */
    this.f_otherDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
  }
  
  /**
   * Factory method corresponding to constructor 'DocumentsRequiredSection(List, List)'.
   * @param {List<Bank>} banks
   * @param {List<Country>} countries
   * @return {!DocumentsRequiredSection}
   * @public
   */
  static $create__java_util_List__java_util_List(banks, countries) {
    DocumentsRequiredSection.$clinit();
    let $instance = new DocumentsRequiredSection();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection__java_util_List__java_util_List(banks, countries);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DocumentsRequiredSection(List, List)'.
   * @param {List<Bank>} banks
   * @param {List<Country>} countries
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection__java_util_List__java_util_List(banks, countries) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(BlockHeader.m_create__java_lang_String("Documents Required").m_asElement__());
    this.f_draftsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = DraftsPart.$create__();
    this.f_signedCommercialInvoicePart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = SignedCommercialInvoicePart.$create__java_util_List(countries);
    this.f_certificateOfOriginPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = CertificateOfOriginPart.$create__java_util_List(countries);
    this.f_packingListPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = PackingListPart.$create__();
    this.f_shippingDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = ShippingDocumentsPart.$create__java_util_List(banks);
    this.f_insurancePolicyPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = InsurancePolicyPart.$create__();
    this.f_otherDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = OtherDocumentsPart.$create__();
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_draftsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_signedCommercialInvoicePart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_certificateOfOriginPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_packingListPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_shippingDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_insurancePolicyPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.appendChild(this.f_otherDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_asElement__());
  }
  
  /**
   * @override
   * @param {LetterOfCredit} letterOfCredit
   * @return {void}
   * @public
   */
  m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit) {
    this.f_shippingDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_draftsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_signedCommercialInvoicePart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_packingListPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_insurancePolicyPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
    this.f_otherDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_collect__org_dominokit_domino_formsamples_shared_model_LetterOfCredit(letterOfCredit);
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_validate__() {
    return !!(+!!(+!!(+!!(+!!(+this.f_draftsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_validate__() & +this.f_signedCommercialInvoicePart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_validate__()) & +this.f_certificateOfOriginPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_validate__()) & +this.f_packingListPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_validate__()) & +this.f_shippingDocumentsPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_validate__()) & +this.f_insurancePolicyPart__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_.m_validate__());
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection() {
    this.f_element__org_dominokit_domino_formsamples_client_views_ui_section_DocumentsRequiredSection_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DocumentsRequiredSection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DocumentsRequiredSection);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DocumentsRequiredSection.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CertificateOfOriginPart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.CertificateOfOriginPart$impl');
    DraftsPart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.DraftsPart$impl');
    InsurancePolicyPart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart$impl');
    OtherDocumentsPart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.OtherDocumentsPart$impl');
    PackingListPart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.PackingListPart$impl');
    ShippingDocumentsPart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.ShippingDocumentsPart$impl');
    SignedCommercialInvoicePart = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.section.documents.SignedCommercialInvoicePart$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DocumentsRequiredSection, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.section.DocumentsRequiredSection'));


ImportSection.$markImplementor(DocumentsRequiredSection);


exports = DocumentsRequiredSection; 
//# sourceMappingURL=DocumentsRequiredSection.js.map