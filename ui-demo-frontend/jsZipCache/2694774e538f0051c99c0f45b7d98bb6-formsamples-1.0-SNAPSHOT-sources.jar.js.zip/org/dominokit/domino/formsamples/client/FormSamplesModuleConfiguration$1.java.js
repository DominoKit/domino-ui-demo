/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.FormSamplesModuleConfiguration$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.FormSamplesModuleConfiguration.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _FormSamplesModuleConfiguration = goog.require('org.dominokit.domino.formsamples.client.FormSamplesModuleConfiguration');
const _FormSamplesPresenter = goog.require('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.formsamples.client.FormSamplesModuleConfiguration.$1$impl');
exports = $1;
 