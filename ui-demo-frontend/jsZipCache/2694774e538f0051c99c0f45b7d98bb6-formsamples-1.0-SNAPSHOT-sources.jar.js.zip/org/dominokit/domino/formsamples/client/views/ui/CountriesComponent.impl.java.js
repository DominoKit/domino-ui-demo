/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.CountriesComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.CountriesComponent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Country$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class CountriesComponent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Select<Country>} */
    this.f_countriesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_;
    /** @public {Select<?string>} */
    this.f_citiesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_;
  }
  
  /**
   * Factory method corresponding to constructor 'CountriesComponent()'.
   * @return {!CountriesComponent}
   * @public
   */
  static $create__() {
    CountriesComponent.$clinit();
    let $instance = new CountriesComponent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CountriesComponent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent__() {
    this.$ctor__java_lang_Object__();
    this.f_countriesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_ = /**@type {Select<Country>} */ (Select.m_create__java_lang_String("Country")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas", "fa-globe", "fa-lg"], j_l_String))));
    this.f_citiesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_ = /**@type {Select<?string>} */ (Select.m_create__java_lang_String("City")).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_location_city__()).m_disable__();
    this.f_countriesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Country> */ option) =>{
      this.f_citiesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_.m_enable__();
      this.f_citiesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_.m_removeAllOptions__();
      let country = /**@type {Country} */ ($Casts.$to(option.m_getValue__(), Country));
      for (let $iterator = country.m_getCities__().m_iterator__(); $iterator.m_hasNext__(); ) {
        let city = /**@type {?string} */ ($Casts.$to($iterator.m_next__(), j_l_String));
        this.f_citiesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(city, city)));
      }
    })));
  }
  
  /**
   * Factory method corresponding to constructor 'CountriesComponent(List)'.
   * @param {List<Country>} countries
   * @return {!CountriesComponent}
   * @public
   */
  static $create__java_util_List(countries) {
    CountriesComponent.$clinit();
    let $instance = new CountriesComponent();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent__java_util_List(countries);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CountriesComponent(List)'.
   * @param {List<Country>} countries
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent__java_util_List(countries) {
    this.$ctor__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent__();
    this.m_setCountries__java_util_List(countries);
  }
  
  /**
   * @param {List<Country>} countries
   * @return {CountriesComponent}
   * @public
   */
  static m_create__java_util_List(countries) {
    CountriesComponent.$clinit();
    return CountriesComponent.$create__java_util_List(countries);
  }
  
  /**
   * @return {CountriesComponent}
   * @public
   */
  static m_create__() {
    CountriesComponent.$clinit();
    return CountriesComponent.$create__();
  }
  
  /**
   * @param {List<Country>} countries
   * @return {CountriesComponent}
   * @public
   */
  m_setCountries__java_util_List(countries) {
    this.f_countriesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_.m_removeAllOptions__();
    for (let $iterator = countries.m_iterator__(); $iterator.m_hasNext__(); ) {
      let country = /**@type {Country} */ ($Casts.$to($iterator.m_next__(), Country));
      this.f_countriesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Country>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(country, country.m_getName__())));
    }
    return this;
  }
  
  /**
   * @return {Select<Country>}
   * @public
   */
  m_getCountriesSelect__() {
    return this.f_countriesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_;
  }
  
  /**
   * @return {Select<?string>}
   * @public
   */
  m_getCitiesSelect__() {
    return this.f_citiesSelect__org_dominokit_domino_formsamples_client_views_ui_CountriesComponent_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CountriesComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CountriesComponent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CountriesComponent.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Country = goog.module.get('org.dominokit.domino.formsamples.shared.model.Country$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CountriesComponent, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.CountriesComponent'));




exports = CountriesComponent; 
//# sourceMappingURL=CountriesComponent.js.map