/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let FormSamplesPresenter = goog.forwardDeclare('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenter$impl');


/**
 * @extends {PresenterCommand<FormSamplesPresenter>}
  */
class FormSamplesPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormSamplesPresenterCommand()'.
   * @return {!FormSamplesPresenterCommand}
   * @public
   */
  static $create__() {
    FormSamplesPresenterCommand.$clinit();
    let $instance = new FormSamplesPresenterCommand();
    $instance.$ctor__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormSamplesPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_presenters_FormSamplesPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormSamplesPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormSamplesPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormSamplesPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormSamplesPresenterCommand, $Util.$makeClassName('org.dominokit.domino.formsamples.client.presenters.FormSamplesPresenterCommand'));




exports = FormSamplesPresenterCommand; 
//# sourceMappingURL=FormSamplesPresenterCommand.js.map