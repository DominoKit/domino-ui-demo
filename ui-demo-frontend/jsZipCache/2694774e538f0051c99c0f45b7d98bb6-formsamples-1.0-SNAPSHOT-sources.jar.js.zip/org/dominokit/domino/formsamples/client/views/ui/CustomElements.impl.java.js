/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.CustomElements.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let NumberFormatException = goog.forwardDeclare('java.lang.NumberFormatException$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Constants = goog.forwardDeclare('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
let Country = goog.forwardDeclare('org.dominokit.domino.formsamples.shared.model.Country$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let ValidationResult = goog.forwardDeclare('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


class CustomElements extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CustomElements()'.
   * @return {!CustomElements}
   * @public
   */
  static $create__() {
    CustomElements.$clinit();
    let $instance = new CustomElements();
    $instance.$ctor__org_dominokit_domino_formsamples_client_views_ui_CustomElements__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CustomElements()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_formsamples_client_views_ui_CustomElements__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {TextBox}
   * @public
   */
  static m_createDescriptionField__() {
    CustomElements.$clinit();
    return /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Description").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setRequired__boolean(true), TextBox));
  }
  
  /**
   * @return {SwitchButton}
   * @public
   */
  static m_createRequiredField__() {
    CustomElements.$clinit();
    return /**@type {SwitchButton} */ ($Casts.$to(SwitchButton.m_create__().m_setOffTitle__java_lang_String("Required").m_style__().m_setMarginBottom__java_lang_String("0px").m_get__(), SwitchButton));
  }
  
  /**
   * @return {TextBox}
   * @public
   */
  static m_createCopiesField__() {
    CustomElements.$clinit();
    return /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(ElementUtil.m_numbersOnly__org_dominokit_domino_ui_forms_HasInputElement(TextBox.m_create__java_lang_String(CustomElements.f_NUMBER_OF_COPIES__org_dominokit_domino_formsamples_client_views_ui_CustomElements)), TextBox)).m_setHelperText__java_lang_String(Constants.f_NUMBERS_ONLY__org_dominokit_domino_formsamples_client_views_ui_Constants), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_content_copy__()), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_setRequired__boolean(true), TextBox));
  }
  
  /**
   * @param {?string} label
   * @param {List<Country>} countries
   * @return {Select<Country>}
   * @public
   */
  static m_createCountriesSelect__java_lang_String__java_util_List(label, countries) {
    CustomElements.$clinit();
    let countrySelect = /**@type {Select<Country>} */ (Select.m_create__java_lang_String(label));
    countrySelect.m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_map__());
    countries.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Country */ country) =>{
      countrySelect.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Country>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(country, country.m_getName__())));
    })));
    return countrySelect;
  }
  
  /**
   * @param {Card} card
   * @param {boolean} isValid
   * @param {boolean} scroll
   * @return {void}
   * @public
   */
  static m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(card, isValid, scroll) {
    CustomElements.$clinit();
    if (!isValid) {
      card.m_style__().m_add__java_lang_String("invalid-section");
      if (scroll) {
        ElementUtil.m_scrollToElement__org_jboss_gwt_elemento_core_IsElement(card);
        $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.scrollTop = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.scrollTop - 110;
        $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.documentElement.scrollTop = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.documentElement.scrollTop - 110;
      }
    } else {
      card.m_style__().m_remove__java_lang_String("invalid-section");
    }
  }
  
  /**
   * @param {Card} card
   * @return {boolean}
   * @public
   */
  static m_isInvalidatedCard__org_dominokit_domino_ui_cards_Card(card) {
    CustomElements.$clinit();
    return card.m_style__().m_contains__java_lang_String("invalid-section");
  }
  
  /**
   * @param {Card} card
   * @param {boolean} isValid
   * @return {void}
   * @public
   */
  static m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean(card, isValid) {
    CustomElements.$clinit();
    CustomElements.m_markCardValidation__org_dominokit_domino_ui_cards_Card__boolean__boolean(card, isValid, true);
  }
  
  /**
   * @param {TextBox} textBox
   * @return {ValidationResult}
   * @public
   */
  static m_validatePercent__org_dominokit_domino_ui_forms_TextBox(textBox) {
    CustomElements.$clinit();
    try {
      let percent = Integer.m_parseInt__java_lang_String(textBox.m_getValue__());
      if ((percent > 0 && percent <= 100)) {
        return ValidationResult.m_valid__();
      }
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (NumberFormatException.$isInstance(__$exc)) {
        let ex = /**@type {NumberFormatException} */ (__$exc);
        return ValidationResult.m_invalid__java_lang_String("Accepted value between 1 - 100");
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
    return ValidationResult.m_invalid__java_lang_String("Accepted value between 1 - 100");
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CustomElements;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CustomElements);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CustomElements.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    NumberFormatException = goog.module.get('java.lang.NumberFormatException$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Constants = goog.module.get('org.dominokit.domino.formsamples.client.views.ui.Constants$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    ValidationResult = goog.module.get('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CustomElements, $Util.$makeClassName('org.dominokit.domino.formsamples.client.views.ui.CustomElements'));


/** @public {?string} @const */
CustomElements.f_NUMBER_OF_COPIES__org_dominokit_domino_formsamples_client_views_ui_CustomElements = "Number of copies";




exports = CustomElements; 
//# sourceMappingURL=CustomElements.js.map