/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ImportSection = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.ImportSection');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.$LambdaAdaptor$19');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart.$LambdaAdaptor$20');
const _Insurance = goog.require('org.dominokit.domino.formsamples.shared.model.Insurance');
const _LetterOfCredit = goog.require('org.dominokit.domino.formsamples.shared.model.LetterOfCredit');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var InsurancePolicyPart = goog.require('org.dominokit.domino.formsamples.client.views.ui.section.documents.InsurancePolicyPart$impl');
exports = InsurancePolicyPart;
 