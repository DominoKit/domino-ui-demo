/**
 * @fileoverview transpiled from org.dominokit.domino.formsamples.client.views.ui.CustomElements.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.formsamples.client.views.ui.CustomElements');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _NumberFormatException = goog.require('java.lang.NumberFormatException');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _Constants = goog.require('org.dominokit.domino.formsamples.client.views.ui.Constants');
const _Country = goog.require('org.dominokit.domino.formsamples.shared.model.Country');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _ValidationResult = goog.require('org.dominokit.domino.ui.forms.validations.ValidationResult');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var CustomElements = goog.require('org.dominokit.domino.formsamples.client.views.ui.CustomElements$impl');
exports = CustomElements;
 