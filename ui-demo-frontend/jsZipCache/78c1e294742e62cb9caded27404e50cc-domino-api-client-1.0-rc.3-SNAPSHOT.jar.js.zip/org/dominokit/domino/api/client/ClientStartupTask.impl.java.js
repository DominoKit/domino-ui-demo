/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientStartupTask.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientStartupTask$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientStartupTask.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ClientStartupTask {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_execute__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {ClientStartupTask}
   * @public
   */
  static $adapt(fn) {
    ClientStartupTask.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientStartupTask = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientStartupTask;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientStartupTask;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientStartupTask.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientStartupTask.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ClientStartupTask, $Util.$makeClassName('org.dominokit.domino.api.client.ClientStartupTask'));


ClientStartupTask.$markImplementor(/** @type {Function} */ (ClientStartupTask));


exports = ClientStartupTask; 
//# sourceMappingURL=ClientStartupTask.js.map