/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let DominoView = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView$impl');
let RemovedHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler$impl');
let RevealedHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_V
  */
class ViewBaseClientPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {C_V} */
    this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter;
  }
  
  /**
   * Factory method corresponding to constructor 'ViewBaseClientPresenter()'.
   * @template C_V
   * @return {!ViewBaseClientPresenter<C_V>}
   * @public
   */
  static $create__() {
    ViewBaseClientPresenter.$clinit();
    let $instance = new ViewBaseClientPresenter();
    $instance.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ViewBaseClientPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initialize__() {
    this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter = this.m_loadView___$p_org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter();
    if (DominoView.$isInstance(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter)) {
      (/**@type {DominoView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, DominoView))).m_setRevealHandler__org_dominokit_domino_api_client_mvp_view_DominoView_RevealedHandler(this.m_onRevealed__());
      (/**@type {DominoView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, DominoView))).m_setRemoveHandler__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler(this.m_onRemoved__());
    }
    this.m_initView__org_dominokit_domino_api_client_mvp_view_View(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter);
    super.m_initialize__();
  }
  
  /**
   * @param {C_V} view
   * @return {void}
   * @public
   */
  m_initView__org_dominokit_domino_api_client_mvp_view_View(view) {
  }
  
  /**
   * @return {RevealedHandler}
   * @public
   */
  m_onRevealed__() {
    return null;
  }
  
  /**
   * @return {RemovedHandler}
   * @public
   */
  m_onRemoved__() {
    return null;
  }
  
  /**
   * @return {C_V}
   * @public
   */
  m_loadView___$p_org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter() {
    return /**@type {C_V} */ ($Casts.$to(ClientApp.m_make__().m_getViewsRepository__().m_getView__java_lang_String(this.m_getName__()), View));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ViewBaseClientPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ViewBaseClientPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ViewBaseClientPresenter.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    DominoView = goog.module.get('org.dominokit.domino.api.client.mvp.view.DominoView$impl');
    View = goog.module.get('org.dominokit.domino.api.client.mvp.view.View$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseClientPresenter.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ViewBaseClientPresenter, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter'));




exports = ViewBaseClientPresenter; 
//# sourceMappingURL=ViewBaseClientPresenter.js.map