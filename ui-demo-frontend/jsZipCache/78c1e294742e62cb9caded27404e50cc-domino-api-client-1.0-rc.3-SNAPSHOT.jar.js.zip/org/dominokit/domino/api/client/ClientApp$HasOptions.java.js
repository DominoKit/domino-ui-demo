/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasOptions.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasOptions');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CanBuildClientApp = goog.require('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions.$LambdaAdaptor');
const _DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions');


// Re-exports the implementation.
var HasOptions = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions$impl');
exports = HasOptions;
 