/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.EventProcessor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.events.EventProcessor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.events.EventProcessor.$LambdaAdaptor');


// Re-exports the implementation.
var EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor$impl');
exports = EventProcessor;
 