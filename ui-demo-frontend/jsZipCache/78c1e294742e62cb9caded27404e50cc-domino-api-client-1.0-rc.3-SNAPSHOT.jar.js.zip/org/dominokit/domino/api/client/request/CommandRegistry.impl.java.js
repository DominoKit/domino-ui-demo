/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CommandRegistry.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.CommandRegistry$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CommandRegistry {
  /**
   * @abstract
   * @param {?string} commandName
   * @param {?string} presenterName
   * @return {void}
   * @public
   */
  m_registerCommand__java_lang_String__java_lang_String(commandName, presenterName) {
  }
  
  /**
   * @param {?function(?string, ?string):void} fn
   * @return {CommandRegistry}
   * @public
   */
  static $adapt(fn) {
    CommandRegistry.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CommandRegistry = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_CommandRegistry;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CommandRegistry;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CommandRegistry.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.CommandRegistry.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CommandRegistry, $Util.$makeClassName('org.dominokit.domino.api.client.request.CommandRegistry'));


CommandRegistry.$markImplementor(/** @type {Function} */ (CommandRegistry));


exports = CommandRegistry; 
//# sourceMappingURL=CommandRegistry.js.map