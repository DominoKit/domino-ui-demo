package org.dominokit.domino.api.client.request;

public interface CanFailOrSend extends HasFail, CanSend{
}
