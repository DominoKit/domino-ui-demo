/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestsLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestsLoader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let CommandsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestsLoader.$LambdaAdaptor$impl');


/**
 * @interface
 */
class RequestsLoader {
  /**
   * @abstract
   * @param {CommandsRepository} repository
   * @return {void}
   * @public
   */
  m_load__org_dominokit_domino_api_client_request_CommandsRepository(repository) {
  }
  
  /**
   * @param {?function(CommandsRepository):void} fn
   * @return {RequestsLoader}
   * @public
   */
  static $adapt(fn) {
    RequestsLoader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestsLoader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_RequestsLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestsLoader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestsLoader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.RequestsLoader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestsLoader, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestsLoader'));


RequestsLoader.$markImplementor(/** @type {Function} */ (RequestsLoader));


exports = RequestsLoader; 
//# sourceMappingURL=RequestsLoader.js.map