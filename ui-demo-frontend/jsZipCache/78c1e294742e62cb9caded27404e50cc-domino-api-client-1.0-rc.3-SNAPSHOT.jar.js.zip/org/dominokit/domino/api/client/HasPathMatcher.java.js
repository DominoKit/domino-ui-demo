/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.HasPathMatcher.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.HasPathMatcher');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DynamicServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot');
const _HasServiceRoot = goog.require('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.HasPathMatcher.$LambdaAdaptor');


// Re-exports the implementation.
var HasPathMatcher = goog.require('org.dominokit.domino.api.client.HasPathMatcher$impl');
exports = HasPathMatcher;
 