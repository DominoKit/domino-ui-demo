/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.DominoView$RemovedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class RemovedHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onRemoved__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {RemovedHandler}
   * @public
   */
  static $adapt(fn) {
    RemovedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_DominoView_RemovedHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RemovedHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RemovedHandler, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.DominoView$RemovedHandler'));


RemovedHandler.$markImplementor(/** @type {Function} */ (RemovedHandler));


exports = RemovedHandler; 
//# sourceMappingURL=DominoView$RemovedHandler.js.map