/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$ServerFailedRequestStateContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext');
const _FailedResponseBean = goog.require('org.dominokit.domino.api.shared.request.FailedResponseBean');


// Re-exports the implementation.
var ServerFailedRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext$impl');
exports = ServerFailedRequestStateContext;
 