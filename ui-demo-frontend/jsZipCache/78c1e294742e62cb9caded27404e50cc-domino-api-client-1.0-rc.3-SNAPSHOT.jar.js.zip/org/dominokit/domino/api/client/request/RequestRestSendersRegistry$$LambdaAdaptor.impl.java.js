/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSendersRegistry$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSendersRegistry.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');

let LazyRequestRestSenderLoader = goog.forwardDeclare('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader$impl');


/**
 * @implements {RequestRestSendersRegistry}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string, LazyRequestRestSenderLoader):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string, LazyRequestRestSenderLoader):void} */
    this.f_$$fn__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string, LazyRequestRestSenderLoader):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @param {LazyRequestRestSenderLoader} arg1
   * @return {void}
   * @public
   */
  m_registerRequestRestSender__java_lang_String__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_request_RequestRestSendersRegistry_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$$LambdaAdaptor'));


RequestRestSendersRegistry.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=RequestRestSendersRegistry$$LambdaAdaptor.js.map