/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasHistory$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasHistory.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasHistory = goog.require('org.dominokit.domino.api.client.ClientApp.HasHistory$impl');

let HasAsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner$impl');
let AsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner$impl');


/**
 * @implements {HasHistory}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(AsyncRunner):HasAsyncRunner} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(AsyncRunner):HasAsyncRunner} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasHistory_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasHistory_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasHistory_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(AsyncRunner):HasAsyncRunner} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasHistory_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasHistory_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasHistory_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {AsyncRunner} arg0
   * @return {HasAsyncRunner}
   * @public
   */
  m_asyncRunner__org_dominokit_domino_api_client_async_AsyncRunner(arg0) {
    let /** ?function(AsyncRunner):HasAsyncRunner */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasHistory_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasHistory$$LambdaAdaptor'));


HasHistory.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasHistory$$LambdaAdaptor.js.map