/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.DominoEventsRegistry$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.extension.DominoEventsRegistry.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _Class = goog.require('java.lang.Class');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 