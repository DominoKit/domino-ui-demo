/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.DynamicServiceRoot$PathMatcher.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher.$LambdaAdaptor$impl');


/**
 * @interface
 */
class PathMatcher {
  /**
   * @abstract
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_isMatch__java_lang_String(path) {
  }
  
  /**
   * @param {?function(?string):boolean} fn
   * @return {PathMatcher}
   * @public
   */
  static $adapt(fn) {
    PathMatcher.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_DynamicServiceRoot_PathMatcher;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PathMatcher.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.DynamicServiceRoot.PathMatcher.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(PathMatcher, $Util.$makeClassName('org.dominokit.domino.api.client.DynamicServiceRoot$PathMatcher'));


PathMatcher.$markImplementor(/** @type {Function} */ (PathMatcher));


exports = PathMatcher; 
//# sourceMappingURL=DynamicServiceRoot$PathMatcher.js.map