package org.dominokit.domino.api.client.request;

public interface CanSend {
    void send();
}
