/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSendersRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSendersRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyRequestRestSenderLoader = goog.require('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader');
const _RequestRestSender = goog.require('org.dominokit.domino.api.client.request.RequestRestSender');


// Re-exports the implementation.
var RequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository$impl');
exports = RequestRestSendersRepository;
 