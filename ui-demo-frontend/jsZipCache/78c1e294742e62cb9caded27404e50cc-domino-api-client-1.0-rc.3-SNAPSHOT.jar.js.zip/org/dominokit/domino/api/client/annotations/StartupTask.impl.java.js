/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.StartupTask.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.StartupTask$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.annotations.StartupTask.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class StartupTask {
  /**
   * @param {?function():Class<?>} fn
   * @return {StartupTask}
   * @public
   */
  static $adapt(fn) {
    StartupTask.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_StartupTask = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_StartupTask;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_StartupTask;
  }
  
  /**
   * @public
   */
  static $clinit() {
    StartupTask.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.annotations.StartupTask.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(StartupTask, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.StartupTask'));


StartupTask.$markImplementor(/** @type {Function} */ (StartupTask));


exports = StartupTask; 
//# sourceMappingURL=StartupTask.js.map