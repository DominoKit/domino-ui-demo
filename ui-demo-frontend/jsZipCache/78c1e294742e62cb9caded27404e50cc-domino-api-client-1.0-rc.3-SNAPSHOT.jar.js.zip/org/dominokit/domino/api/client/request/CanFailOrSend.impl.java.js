/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CanFailOrSend.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.CanFailOrSend$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const CanSend = goog.require('org.dominokit.domino.api.client.request.CanSend$impl');
const HasFail = goog.require('org.dominokit.domino.api.client.request.HasFail$impl');


/**
 * @interface
 * @extends {HasFail}
 * @extends {CanSend}
 */
class CanFailOrSend {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    HasFail.$markImplementor(classConstructor);
    CanSend.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CanFailOrSend = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_CanFailOrSend;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CanFailOrSend;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanFailOrSend.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(CanFailOrSend, $Util.$makeClassName('org.dominokit.domino.api.client.request.CanFailOrSend'));


CanFailOrSend.$markImplementor(/** @type {Function} */ (CanFailOrSend));


exports = CanFailOrSend; 
//# sourceMappingURL=CanFailOrSend.js.map