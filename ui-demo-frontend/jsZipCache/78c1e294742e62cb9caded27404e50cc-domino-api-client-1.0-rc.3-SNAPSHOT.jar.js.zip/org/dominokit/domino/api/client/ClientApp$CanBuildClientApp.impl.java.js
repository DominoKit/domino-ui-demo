/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$CanBuildClientApp.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CanBuildClientApp {
  /**
   * @abstract
   * @return {ClientApp}
   * @public
   */
  m_build__() {
  }
  
  /**
   * @param {?function():ClientApp} fn
   * @return {CanBuildClientApp}
   * @public
   */
  static $adapt(fn) {
    CanBuildClientApp.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_CanBuildClientApp = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_CanBuildClientApp;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_CanBuildClientApp;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanBuildClientApp.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CanBuildClientApp, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$CanBuildClientApp'));


CanBuildClientApp.$markImplementor(/** @type {Function} */ (CanBuildClientApp));


exports = CanBuildClientApp; 
//# sourceMappingURL=ClientApp$CanBuildClientApp.js.map