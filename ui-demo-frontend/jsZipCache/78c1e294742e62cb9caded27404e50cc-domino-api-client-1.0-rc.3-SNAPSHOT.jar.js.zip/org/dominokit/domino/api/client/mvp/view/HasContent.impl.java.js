/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.HasContent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.HasContent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.$LambdaAdaptor$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @interface
 */
class HasContent {
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getContent__() {
  }
  
  /**
   * @abstract
   * @param {CreateHandler} createHandler
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(createHandler) {
  }
  
  /**
   * @param {?function():Content} fn
   * @return {HasContent}
   * @public
   */
  static $adapt(fn) {
    HasContent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {HasContent} $thisArg
   * @param {CreateHandler} createHandler
   * @return {Content}
   * @public
   */
  static m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler($thisArg, createHandler) {
    HasContent.$clinit();
    return $thisArg.m_getContent__();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_HasContent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_HasContent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_HasContent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasContent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasContent, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.HasContent'));


HasContent.$markImplementor(/** @type {Function} */ (HasContent));


exports = HasContent; 
//# sourceMappingURL=HasContent.js.map