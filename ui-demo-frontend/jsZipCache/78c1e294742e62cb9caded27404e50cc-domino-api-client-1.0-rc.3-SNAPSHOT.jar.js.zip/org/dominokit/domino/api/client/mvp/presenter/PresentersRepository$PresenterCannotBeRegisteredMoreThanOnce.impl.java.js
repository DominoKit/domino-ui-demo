/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$PresenterCannotBeRegisteredMoreThanOnce.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterCannotBeRegisteredMoreThanOnce$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class PresenterCannotBeRegisteredMoreThanOnce extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PresenterCannotBeRegisteredMoreThanOnce(String)'.
   * @param {?string} message
   * @return {!PresenterCannotBeRegisteredMoreThanOnce}
   * @public
   */
  static $create__java_lang_String(message) {
    PresenterCannotBeRegisteredMoreThanOnce.$clinit();
    let $instance = new PresenterCannotBeRegisteredMoreThanOnce();
    $instance.$ctor__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository_PresenterCannotBeRegisteredMoreThanOnce__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PresenterCannotBeRegisteredMoreThanOnce(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository_PresenterCannotBeRegisteredMoreThanOnce__java_lang_String(message) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PresenterCannotBeRegisteredMoreThanOnce;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PresenterCannotBeRegisteredMoreThanOnce);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PresenterCannotBeRegisteredMoreThanOnce.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PresenterCannotBeRegisteredMoreThanOnce, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$PresenterCannotBeRegisteredMoreThanOnce'));


/** @public {!$Long} @const */
PresenterCannotBeRegisteredMoreThanOnce.f_serialVersionUID__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository_PresenterCannotBeRegisteredMoreThanOnce_ = $Long.fromBits(1535676304, 222606372) /* 956087089156886416 */;




exports = PresenterCannotBeRegisteredMoreThanOnce; 
//# sourceMappingURL=PresentersRepository$PresenterCannotBeRegisteredMoreThanOnce.js.map