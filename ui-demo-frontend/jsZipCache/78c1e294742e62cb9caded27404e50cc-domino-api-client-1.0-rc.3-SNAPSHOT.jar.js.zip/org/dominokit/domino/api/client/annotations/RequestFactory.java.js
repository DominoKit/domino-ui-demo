/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.RequestFactory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.annotations.RequestFactory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var RequestFactory = goog.require('org.dominokit.domino.api.client.annotations.RequestFactory$impl');
exports = RequestFactory;
 