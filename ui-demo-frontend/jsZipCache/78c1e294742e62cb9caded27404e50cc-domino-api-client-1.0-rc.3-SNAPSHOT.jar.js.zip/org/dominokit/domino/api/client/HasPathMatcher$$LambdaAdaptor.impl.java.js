/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.HasPathMatcher$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.HasPathMatcher.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasPathMatcher = goog.require('org.dominokit.domino.api.client.HasPathMatcher$impl');

let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');
let HasServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot$impl');


/**
 * @implements {HasPathMatcher}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(HasServiceRoot):DynamicServiceRoot} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(HasServiceRoot):DynamicServiceRoot} */
    this.f_$$fn__org_dominokit_domino_api_client_HasPathMatcher_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_HasPathMatcher_$LambdaAdaptor__org_dominokit_domino_api_client_HasPathMatcher_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(HasServiceRoot):DynamicServiceRoot} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_HasPathMatcher_$LambdaAdaptor__org_dominokit_domino_api_client_HasPathMatcher_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_HasPathMatcher_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {HasServiceRoot} arg0
   * @return {DynamicServiceRoot}
   * @public
   */
  m_serviceRoot__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot(arg0) {
    let /** ?function(HasServiceRoot):DynamicServiceRoot */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_HasPathMatcher_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.HasPathMatcher$$LambdaAdaptor'));


HasPathMatcher.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=HasPathMatcher$$LambdaAdaptor.js.map