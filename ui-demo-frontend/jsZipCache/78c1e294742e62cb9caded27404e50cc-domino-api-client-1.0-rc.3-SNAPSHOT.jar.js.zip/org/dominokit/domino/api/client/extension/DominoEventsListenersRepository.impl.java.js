/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.DominoEventsListenersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let DominoEventListener = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');


/**
 * @interface
 */
class DominoEventsListenersRepository {
  /**
   * @abstract
   * @param {Class<?>} dominoEvent
   * @param {DominoEventListener} dominoEventListener
   * @return {void}
   * @public
   */
  m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(dominoEvent, dominoEventListener) {
  }
  
  /**
   * @abstract
   * @param {Class<?>} dominoEvent
   * @return {Set<DominoEventListener>}
   * @public
   */
  m_getEventListeners__java_lang_Class(dominoEvent) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_DominoEventsListenersRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_extension_DominoEventsListenersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_DominoEventsListenersRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoEventsListenersRepository.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(DominoEventsListenersRepository, $Util.$makeClassName('org.dominokit.domino.api.client.extension.DominoEventsListenersRepository'));


DominoEventsListenersRepository.$markImplementor(/** @type {Function} */ (DominoEventsListenersRepository));


exports = DominoEventsListenersRepository; 
//# sourceMappingURL=DominoEventsListenersRepository.js.map