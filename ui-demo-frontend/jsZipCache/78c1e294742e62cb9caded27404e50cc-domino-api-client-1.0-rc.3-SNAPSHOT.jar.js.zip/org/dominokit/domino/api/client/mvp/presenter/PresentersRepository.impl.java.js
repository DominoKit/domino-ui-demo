/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let LazyPresenterLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');
let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');


/**
 * @interface
 */
class PresentersRepository {
  /**
   * @abstract
   * @param {LazyPresenterLoader} lazyPresenterLoader
   * @return {void}
   * @public
   */
  m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader(lazyPresenterLoader) {
  }
  
  /**
   * @abstract
   * @param {?string} presenterName
   * @return {Presentable}
   * @public
   */
  m_getPresenter__java_lang_String(presenterName) {
  }
  
  /**
   * @abstract
   * @param {?string} concreteName
   * @return {?string}
   * @public
   */
  m_getNameFromConcreteName__java_lang_String(concreteName) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    PresentersRepository.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(PresentersRepository, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository'));


PresentersRepository.$markImplementor(/** @type {Function} */ (PresentersRepository));


exports = PresentersRepository; 
//# sourceMappingURL=PresentersRepository.js.map