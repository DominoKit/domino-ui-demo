/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$ContextAggregatorBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.ContextAggregatorBuilder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CanWaitForContext = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.CanWaitForContext$impl');

let LinkedHashSet = goog.forwardDeclare('java.util.LinkedHashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let ContextAggregator = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator$impl');
let ContextWait = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');
let ReadyHandler = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');


/**
 * @implements {CanWaitForContext}
  */
class ContextAggregatorBuilder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Set<ContextWait>} */
    this.f_contextSet__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContextAggregatorBuilder(ContextWait)'.
   * @param {ContextWait} context
   * @return {!ContextAggregatorBuilder}
   * @public
   */
  static $create__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context) {
    ContextAggregatorBuilder.$clinit();
    let $instance = new ContextAggregatorBuilder();
    $instance.$ctor__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContextAggregatorBuilder(ContextWait)'.
   * @param {ContextWait} context
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder();
    this.f_contextSet__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder_.add(context);
  }
  
  /**
   * @param {ContextWait} context
   * @return {CanWaitForContext}
   * @public
   */
  static m_waitForContext__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context) {
    ContextAggregatorBuilder.$clinit();
    return ContextAggregatorBuilder.$create__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context);
  }
  
  /**
   * @override
   * @param {ContextWait} context
   * @return {CanWaitForContext}
   * @public
   */
  m_and__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context) {
    this.f_contextSet__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder_.add(context);
    return this;
  }
  
  /**
   * @override
   * @param {ReadyHandler} handler
   * @return {ContextAggregator}
   * @public
   */
  m_onReady__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(handler) {
    return ContextAggregator.$create__java_util_Set__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(this.f_contextSet__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder_, handler);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder() {
    this.f_contextSet__org_dominokit_domino_api_client_extension_ContextAggregator_ContextAggregatorBuilder_ = /**@type {!LinkedHashSet<ContextWait>} */ (LinkedHashSet.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContextAggregatorBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContextAggregatorBuilder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContextAggregatorBuilder.$clinit = function() {};
    LinkedHashSet = goog.module.get('java.util.LinkedHashSet$impl');
    ContextAggregator = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContextAggregatorBuilder, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContextAggregator$ContextAggregatorBuilder'));


CanWaitForContext.$markImplementor(ContextAggregatorBuilder);


exports = ContextAggregatorBuilder; 
//# sourceMappingURL=ContextAggregator$ContextAggregatorBuilder.js.map