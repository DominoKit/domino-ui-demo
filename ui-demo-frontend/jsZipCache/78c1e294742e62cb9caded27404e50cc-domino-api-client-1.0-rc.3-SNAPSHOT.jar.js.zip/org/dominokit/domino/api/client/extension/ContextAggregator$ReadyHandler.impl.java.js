/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$ReadyHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ReadyHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onReady__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {ReadyHandler}
   * @public
   */
  static $adapt(fn) {
    ReadyHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ReadyHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ReadyHandler, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContextAggregator$ReadyHandler'));


ReadyHandler.$markImplementor(/** @type {Function} */ (ReadyHandler));


exports = ReadyHandler; 
//# sourceMappingURL=ContextAggregator$ReadyHandler.js.map