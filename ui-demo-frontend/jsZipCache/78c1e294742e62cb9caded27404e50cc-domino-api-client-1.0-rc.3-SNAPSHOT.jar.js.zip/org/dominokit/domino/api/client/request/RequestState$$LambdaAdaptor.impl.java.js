/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestState$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestState.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestState = goog.require('org.dominokit.domino.api.client.request.RequestState$impl');

let RequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestStateContext$impl');


/**
 * @template C_C
 * @implements {RequestState<C_C>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_C):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(C_C):void} */
    this.f_$$fn__org_dominokit_domino_api_client_request_RequestState_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_RequestState_$LambdaAdaptor__org_dominokit_domino_api_client_request_RequestState_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_C):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_RequestState_$LambdaAdaptor__org_dominokit_domino_api_client_request_RequestState_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_RequestState_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {C_C} arg0
   * @return {void}
   * @public
   */
  m_execute__org_dominokit_domino_api_client_request_RequestStateContext(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_request_RequestState_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestState$$LambdaAdaptor'));


RequestState.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=RequestState$$LambdaAdaptor.js.map