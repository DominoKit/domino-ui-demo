/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$ReadyHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ReadyHandler = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');


/**
 * @implements {ReadyHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():void} */
    this.f_$$fn__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$LambdaAdaptor__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$LambdaAdaptor__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onReady__() {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$LambdaAdaptor;
      $function();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContextAggregator$ReadyHandler$$LambdaAdaptor'));


ReadyHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ContextAggregator$ReadyHandler$$LambdaAdaptor.js.map