/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.async.AsyncRunner$AsyncTask.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let AsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask.$LambdaAdaptor$impl');


/**
 * @interface
 */
class AsyncTask {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onSuccess__() {
  }
  
  /**
   * @abstract
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  m_onFailed__java_lang_Throwable(error) {
  }
  
  /**
   * @param {?function():void} fn
   * @return {AsyncTask}
   * @public
   */
  static $adapt(fn) {
    AsyncTask.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {AsyncTask} $thisArg
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  static m_onFailed__$default__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask__java_lang_Throwable($thisArg, error) {
    AsyncTask.$clinit();
    AsyncRunner.f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner.m_error__java_lang_String__java_lang_Throwable("Failed to run async task : ", error);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AsyncTask.$clinit = function() {};
    AsyncRunner = goog.module.get('org.dominokit.domino.api.client.async.AsyncRunner$impl');
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(AsyncTask, $Util.$makeClassName('org.dominokit.domino.api.client.async.AsyncRunner$AsyncTask'));


AsyncTask.$markImplementor(/** @type {Function} */ (AsyncTask));


exports = AsyncTask; 
//# sourceMappingURL=AsyncRunner$AsyncTask.js.map