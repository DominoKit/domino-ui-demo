/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.EventProcessor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.EventProcessor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventProcessor.$LambdaAdaptor$impl');


/**
 * @interface
 */
class EventProcessor {
  /**
   * @abstract
   * @param {Event} event
   * @return {void}
   * @public
   */
  m_process__org_dominokit_domino_api_client_events_Event(event) {
  }
  
  /**
   * @param {?function(Event):void} fn
   * @return {EventProcessor}
   * @public
   */
  static $adapt(fn) {
    EventProcessor.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_EventProcessor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_events_EventProcessor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_EventProcessor;
  }
  
  /**
   * @public
   */
  static $clinit() {
    EventProcessor.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.events.EventProcessor.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(EventProcessor, $Util.$makeClassName('org.dominokit.domino.api.client.events.EventProcessor'));


EventProcessor.$markImplementor(/** @type {Function} */ (EventProcessor));


exports = EventProcessor; 
//# sourceMappingURL=EventProcessor.js.map