/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CommandRegistry$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.CommandRegistry.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry$impl');


/**
 * @implements {CommandRegistry}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string, ?string):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string, ?string):void} */
    this.f_$$fn__org_dominokit_domino_api_client_request_CommandRegistry_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_request_CommandRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_request_CommandRegistry_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(?string, ?string):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_CommandRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_request_CommandRegistry_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_request_CommandRegistry_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @param {?string} arg1
   * @return {void}
   * @public
   */
  m_registerCommand__java_lang_String__java_lang_String(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_request_CommandRegistry_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.request.CommandRegistry$$LambdaAdaptor'));


CommandRegistry.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=CommandRegistry$$LambdaAdaptor.js.map