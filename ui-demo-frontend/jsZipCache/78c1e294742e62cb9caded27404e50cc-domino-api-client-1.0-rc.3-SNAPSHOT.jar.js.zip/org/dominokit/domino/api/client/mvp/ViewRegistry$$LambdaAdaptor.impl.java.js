/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.ViewRegistry$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.ViewRegistry.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');

let LazyViewLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');


/**
 * @implements {ViewRegistry}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(LazyViewLoader):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(LazyViewLoader):void} */
    this.f_$$fn__org_dominokit_domino_api_client_mvp_ViewRegistry_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_mvp_ViewRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_ViewRegistry_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(LazyViewLoader):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_ViewRegistry_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_ViewRegistry_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_mvp_ViewRegistry_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {LazyViewLoader} arg0
   * @return {void}
   * @public
   */
  m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_mvp_ViewRegistry_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.ViewRegistry$$LambdaAdaptor'));


ViewRegistry.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ViewRegistry$$LambdaAdaptor.js.map