/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasServerRouter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasServerRouter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasEventBus = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasEventBus$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasServerRouter.$LambdaAdaptor$impl');
let EventsBus = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus$impl');


/**
 * @interface
 */
class HasServerRouter {
  /**
   * @abstract
   * @param {EventsBus} eventsBus
   * @return {HasEventBus}
   * @public
   */
  m_eventsBus__org_dominokit_domino_api_client_events_EventsBus(eventsBus) {
  }
  
  /**
   * @param {?function(EventsBus):HasEventBus} fn
   * @return {HasServerRouter}
   * @public
   */
  static $adapt(fn) {
    HasServerRouter.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasServerRouter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasServerRouter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasServerRouter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasServerRouter.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasServerRouter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasServerRouter, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasServerRouter'));


HasServerRouter.$markImplementor(/** @type {Function} */ (HasServerRouter));


exports = HasServerRouter; 
//# sourceMappingURL=ClientApp$HasServerRouter.js.map