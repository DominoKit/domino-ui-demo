/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSendersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSendersRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let LazyRequestRestSenderLoader = goog.forwardDeclare('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader$impl');
let RequestRestSender = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSender$impl');


/**
 * @interface
 */
class RequestRestSendersRepository {
  /**
   * @abstract
   * @param {?string} requestName
   * @param {LazyRequestRestSenderLoader} loader
   * @return {void}
   * @public
   */
  m_registerSender__java_lang_String__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader(requestName, loader) {
  }
  
  /**
   * @abstract
   * @param {?string} requestName
   * @return {RequestRestSender}
   * @public
   */
  m_get__java_lang_String(requestName) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestRestSendersRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_RequestRestSendersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestRestSendersRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestRestSendersRepository.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestRestSendersRepository, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestRestSendersRepository'));


RequestRestSendersRepository.$markImplementor(/** @type {Function} */ (RequestRestSendersRepository));


exports = RequestRestSendersRepository; 
//# sourceMappingURL=RequestRestSendersRepository.js.map