/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.BaseDominoView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.BaseDominoView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoView = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView');
const _HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent');
const _Objects = goog.require('java.util.Objects');
const _RemovedHandler = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView.RemovedHandler');
const _RevealedHandler = goog.require('org.dominokit.domino.api.client.mvp.view.DominoView.RevealedHandler');
const _CreateHandler = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BaseDominoView = goog.require('org.dominokit.domino.api.client.mvp.view.BaseDominoView$impl');
exports = BaseDominoView;
 