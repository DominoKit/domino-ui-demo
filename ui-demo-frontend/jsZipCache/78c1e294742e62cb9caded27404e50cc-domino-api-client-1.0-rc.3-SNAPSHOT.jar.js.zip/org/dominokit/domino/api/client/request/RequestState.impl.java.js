/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestState.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestState$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestState.$LambdaAdaptor$impl');
let RequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestStateContext$impl');


/**
 * @interface
 * @template C_C
 */
class RequestState {
  /**
   * @abstract
   * @param {C_C} request
   * @return {void}
   * @public
   */
  m_execute__org_dominokit_domino_api_client_request_RequestStateContext(request) {
  }
  
  /**
   * @template C_C
   * @param {?function(C_C):void} fn
   * @return {RequestState<C_C>}
   * @public
   */
  static $adapt(fn) {
    RequestState.$clinit();
    return /**@type {!$LambdaAdaptor<RequestStateContext>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestState = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_RequestState;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestState;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestState.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.RequestState.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestState, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestState'));


RequestState.$markImplementor(/** @type {Function} */ (RequestState));


exports = RequestState; 
//# sourceMappingURL=RequestState.js.map