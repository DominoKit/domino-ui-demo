/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.ViewsLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.ViewsLoader$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsLoader.$LambdaAdaptor$impl');
let ViewsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');


/**
 * @interface
 */
class ViewsLoader {
  /**
   * @abstract
   * @param {ViewsRepository} repository
   * @return {void}
   * @public
   */
  m_load__org_dominokit_domino_api_client_mvp_view_ViewsRepository(repository) {
  }
  
  /**
   * @param {?function(ViewsRepository):void} fn
   * @return {ViewsLoader}
   * @public
   */
  static $adapt(fn) {
    ViewsLoader.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_ViewsLoader = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_ViewsLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_ViewsLoader;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ViewsLoader.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.mvp.view.ViewsLoader.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ViewsLoader, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.ViewsLoader'));


ViewsLoader.$markImplementor(/** @type {Function} */ (ViewsLoader));


exports = ViewsLoader; 
//# sourceMappingURL=ViewsLoader.js.map