/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.UiHandlers.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.UiHandlers$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class UiHandlers {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_UiHandlers = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_UiHandlers;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_UiHandlers;
  }
  
  /**
   * @public
   */
  static $clinit() {
    UiHandlers.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(UiHandlers, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.UiHandlers'));


UiHandlers.$markImplementor(/** @type {Function} */ (UiHandlers));


exports = UiHandlers; 
//# sourceMappingURL=UiHandlers.js.map