/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Success.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Success$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.Success.$LambdaAdaptor$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @interface
 * @template C_S
 */
class Success {
  /**
   * @abstract
   * @param {C_S} response
   * @return {void}
   * @public
   */
  m_onSuccess__org_dominokit_domino_api_shared_request_ResponseBean(response) {
  }
  
  /**
   * @template C_S
   * @param {?function(C_S):void} fn
   * @return {Success<C_S>}
   * @public
   */
  static $adapt(fn) {
    Success.$clinit();
    return /**@type {!$LambdaAdaptor<ResponseBean>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Success = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_Success;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Success;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Success.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.Success.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Success, $Util.$makeClassName('org.dominokit.domino.api.client.request.Success'));


Success.$markImplementor(/** @type {Function} */ (Success));


exports = Success; 
//# sourceMappingURL=Success.js.map