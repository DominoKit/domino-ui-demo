/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.ServerRequestCallBack.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.ServerRequestCallBack');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Throwable = goog.require('java.lang.Throwable');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');


// Re-exports the implementation.
var ServerRequestCallBack = goog.require('org.dominokit.domino.api.client.request.ServerRequestCallBack$impl');
exports = ServerRequestCallBack;
 