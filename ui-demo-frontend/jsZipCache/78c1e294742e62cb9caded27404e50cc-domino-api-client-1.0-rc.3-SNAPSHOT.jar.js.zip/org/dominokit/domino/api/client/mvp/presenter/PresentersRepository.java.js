/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');


// Re-exports the implementation.
var PresentersRepository = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');
exports = PresentersRepository;
 