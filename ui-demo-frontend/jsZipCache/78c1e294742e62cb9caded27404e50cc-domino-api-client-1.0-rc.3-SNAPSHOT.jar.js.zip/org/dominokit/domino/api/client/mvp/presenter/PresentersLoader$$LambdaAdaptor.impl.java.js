/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresentersLoader$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresentersLoader.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const PresentersLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersLoader$impl');

let PresentersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');


/**
 * @implements {PresentersLoader}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(PresentersRepository):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(PresentersRepository):void} */
    this.f_$$fn__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(PresentersRepository):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {PresentersRepository} arg0
   * @return {void}
   * @public
   */
  m_load__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_mvp_presenter_PresentersLoader_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.PresentersLoader$$LambdaAdaptor'));


PresentersLoader.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=PresentersLoader$$LambdaAdaptor.js.map