/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$ContextWait.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _LinkedHashSet = goog.require('java.util.LinkedHashSet');
const _Set = goog.require('java.util.Set');
const _Consumer = goog.require('java.util.function.Consumer');
const _ReadyHandler = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler');


// Re-exports the implementation.
var ContextWait = goog.require('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');
exports = ContextWait;
 