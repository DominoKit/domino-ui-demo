/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasAsyncRunner.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner.$LambdaAdaptor');
const _HasOptions = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions');
const _MainDominoEvent = goog.require('org.dominokit.domino.api.shared.extension.MainDominoEvent');


// Re-exports the implementation.
var HasAsyncRunner = goog.require('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner$impl');
exports = HasAsyncRunner;
 