/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.ContentView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.ContentView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ContentView.$LambdaAdaptor$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @interface
 * @extends {View}
 * @extends {HasContent}
 */
class ContentView {
  /**
   * @param {?function():Content} fn
   * @return {ContentView}
   * @public
   */
  static $adapt(fn) {
    ContentView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    HasContent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_ContentView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_ContentView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_ContentView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContentView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.mvp.view.ContentView.$LambdaAdaptor$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(ContentView, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.ContentView'));


ContentView.$markImplementor(/** @type {Function} */ (ContentView));


exports = ContentView; 
//# sourceMappingURL=ContentView.js.map