/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.ContentView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.ContentView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView.$LambdaAdaptor');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');


// Re-exports the implementation.
var ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');
exports = ContentView;
 