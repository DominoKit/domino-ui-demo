/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.async.AsyncRunner.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.async.AsyncRunner');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.$LambdaAdaptor');
const _AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var AsyncRunner = goog.require('org.dominokit.domino.api.client.async.AsyncRunner$impl');
exports = AsyncRunner;
 