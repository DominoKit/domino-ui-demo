/**
 * @fileoverview transpiled from org.gwtproject.event.shared.HandlerRegistrations.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.event.shared.HandlerRegistrations$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let HandlerRegistration = goog.forwardDeclare('org.gwtproject.event.shared.HandlerRegistration$impl');
let HandlerRegistrationCollection = goog.forwardDeclare('org.gwtproject.event.shared.HandlerRegistrations.HandlerRegistrationCollection$impl');


class HandlerRegistrations extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * @param {Array<HandlerRegistration>} handlers
   * @return {HandlerRegistration}
   * @public
   */
  static m_compose__arrayOf_org_gwtproject_event_shared_HandlerRegistration(handlers) {
    HandlerRegistrations.$clinit();
    return HandlerRegistrationCollection.$create__arrayOf_org_gwtproject_event_shared_HandlerRegistration(handlers);
  }
  
  /**
   * Factory method corresponding to constructor 'HandlerRegistrations()'.
   * @return {!HandlerRegistrations}
   * @public
   */
  static $create__() {
    HandlerRegistrations.$clinit();
    let $instance = new HandlerRegistrations();
    $instance.$ctor__org_gwtproject_event_shared_HandlerRegistrations__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HandlerRegistrations()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_event_shared_HandlerRegistrations__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HandlerRegistrations;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HandlerRegistrations);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HandlerRegistrations.$clinit = function() {};
    HandlerRegistrationCollection = goog.module.get('org.gwtproject.event.shared.HandlerRegistrations.HandlerRegistrationCollection$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HandlerRegistrations, $Util.$makeClassName('org.gwtproject.event.shared.HandlerRegistrations'));




exports = HandlerRegistrations; 
//# sourceMappingURL=HandlerRegistrations.js.map