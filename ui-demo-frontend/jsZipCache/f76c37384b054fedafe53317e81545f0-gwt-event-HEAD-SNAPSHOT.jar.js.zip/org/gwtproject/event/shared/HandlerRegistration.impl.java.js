/**
 * @fileoverview transpiled from org.gwtproject.event.shared.HandlerRegistration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.event.shared.HandlerRegistration$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.gwtproject.event.shared.HandlerRegistration.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HandlerRegistration {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_removeHandler__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {HandlerRegistration}
   * @public
   */
  static $adapt(fn) {
    HandlerRegistration.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_event_shared_HandlerRegistration = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_event_shared_HandlerRegistration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_event_shared_HandlerRegistration;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HandlerRegistration.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.gwtproject.event.shared.HandlerRegistration.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HandlerRegistration, $Util.$makeClassName('org.gwtproject.event.shared.HandlerRegistration'));


HandlerRegistration.$markImplementor(/** @type {Function} */ (HandlerRegistration));


exports = HandlerRegistration; 
//# sourceMappingURL=HandlerRegistration.js.map