/**
 * @fileoverview transpiled from org.gwtproject.event.shared.HandlerRegistrations$HandlerRegistrationCollection.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.HandlerRegistrations.HandlerRegistrationCollection');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');
const _$Equality = goog.require('nativebootstrap.Equality');


// Re-exports the implementation.
var HandlerRegistrationCollection = goog.require('org.gwtproject.event.shared.HandlerRegistrations.HandlerRegistrationCollection$impl');
exports = HandlerRegistrationCollection;
 