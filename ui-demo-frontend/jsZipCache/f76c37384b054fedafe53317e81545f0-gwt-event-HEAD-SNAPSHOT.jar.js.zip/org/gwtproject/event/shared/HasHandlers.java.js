/**
 * @fileoverview transpiled from org.gwtproject.event.shared.HasHandlers.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.HasHandlers');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event = goog.require('org.gwtproject.event.shared.Event');
const _$LambdaAdaptor = goog.require('org.gwtproject.event.shared.HasHandlers.$LambdaAdaptor');


// Re-exports the implementation.
var HasHandlers = goog.require('org.gwtproject.event.shared.HasHandlers$impl');
exports = HasHandlers;
 