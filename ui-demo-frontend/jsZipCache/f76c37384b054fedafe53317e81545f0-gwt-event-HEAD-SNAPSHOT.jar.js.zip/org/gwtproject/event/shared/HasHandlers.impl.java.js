/**
 * @fileoverview transpiled from org.gwtproject.event.shared.HasHandlers.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.event.shared.HasHandlers$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Event = goog.forwardDeclare('org.gwtproject.event.shared.Event$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.gwtproject.event.shared.HasHandlers.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasHandlers {
  /**
   * @abstract
   * @param {Event<?>} event
   * @return {void}
   * @public
   */
  m_fireEvent__org_gwtproject_event_shared_Event(event) {
  }
  
  /**
   * @param {?function(Event<?>):void} fn
   * @return {HasHandlers}
   * @public
   */
  static $adapt(fn) {
    HasHandlers.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_event_shared_HasHandlers = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_event_shared_HasHandlers;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_event_shared_HasHandlers;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasHandlers.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.gwtproject.event.shared.HasHandlers.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasHandlers, $Util.$makeClassName('org.gwtproject.event.shared.HasHandlers'));


HasHandlers.$markImplementor(/** @type {Function} */ (HasHandlers));


exports = HasHandlers; 
//# sourceMappingURL=HasHandlers.js.map