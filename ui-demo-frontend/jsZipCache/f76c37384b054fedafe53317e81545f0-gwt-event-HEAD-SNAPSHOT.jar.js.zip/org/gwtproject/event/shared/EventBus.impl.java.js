/**
 * @fileoverview transpiled from org.gwtproject.event.shared.EventBus.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.event.shared.EventBus$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasHandlers = goog.require('org.gwtproject.event.shared.HasHandlers$impl');

let Event = goog.forwardDeclare('org.gwtproject.event.shared.Event$impl');
let Type = goog.forwardDeclare('org.gwtproject.event.shared.Event.Type$impl');
let HandlerRegistration = goog.forwardDeclare('org.gwtproject.event.shared.HandlerRegistration$impl');


/**
 * @abstract
 * @implements {HasHandlers}
  */
class EventBus extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'EventBus()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_event_shared_EventBus__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @template M_H
   * @param {Event<M_H>} event
   * @param {M_H} handler
   * @return {void}
   * @public
   */
  static m_dispatchEvent__org_gwtproject_event_shared_Event__java_lang_Object(event, handler) {
    EventBus.$clinit();
    event.m_dispatch__java_lang_Object(handler);
  }
  
  /**
   * @param {Event<?>} event
   * @param {*} source
   * @return {void}
   * @public
   */
  static m_setSourceOfEvent__org_gwtproject_event_shared_Event__java_lang_Object(event, source) {
    EventBus.$clinit();
    event.m_setSource__java_lang_Object(source);
  }
  
  /**
   * @abstract
   * @template M_H
   * @param {Type<M_H>} type
   * @param {M_H} handler
   * @return {HandlerRegistration}
   * @public
   */
  m_addHandler__org_gwtproject_event_shared_Event_Type__java_lang_Object(type, handler) {
  }
  
  /**
   * @abstract
   * @template M_H
   * @param {Type<M_H>} type
   * @param {*} source
   * @param {M_H} handler
   * @return {HandlerRegistration}
   * @public
   */
  m_addHandlerToSource__org_gwtproject_event_shared_Event_Type__java_lang_Object__java_lang_Object(type, source, handler) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Event<?>} event
   * @return {void}
   * @public
   */
  m_fireEvent__org_gwtproject_event_shared_Event(event) {
  }
  
  /**
   * @abstract
   * @param {Event<?>} event
   * @param {*} source
   * @return {void}
   * @public
   */
  m_fireEventFromSource__org_gwtproject_event_shared_Event__java_lang_Object(event, source) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EventBus;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EventBus);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EventBus.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EventBus, $Util.$makeClassName('org.gwtproject.event.shared.EventBus'));


HasHandlers.$markImplementor(EventBus);


exports = EventBus; 
//# sourceMappingURL=EventBus.js.map