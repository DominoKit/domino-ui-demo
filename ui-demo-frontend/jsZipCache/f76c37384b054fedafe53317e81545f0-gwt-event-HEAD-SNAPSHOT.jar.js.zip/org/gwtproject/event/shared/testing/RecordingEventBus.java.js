/**
 * @fileoverview transpiled from org.gwtproject.event.shared.testing.RecordingEventBus.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.testing.RecordingEventBus');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EventBus = goog.require('org.gwtproject.event.shared.EventBus');
const _HashSet = goog.require('java.util.HashSet');
const _Set = goog.require('java.util.Set');
const _Event = goog.require('org.gwtproject.event.shared.Event');
const _Type = goog.require('org.gwtproject.event.shared.Event.Type');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');
const _SimpleEventBus = goog.require('org.gwtproject.event.shared.SimpleEventBus');


// Re-exports the implementation.
var RecordingEventBus = goog.require('org.gwtproject.event.shared.testing.RecordingEventBus$impl');
exports = RecordingEventBus;
 