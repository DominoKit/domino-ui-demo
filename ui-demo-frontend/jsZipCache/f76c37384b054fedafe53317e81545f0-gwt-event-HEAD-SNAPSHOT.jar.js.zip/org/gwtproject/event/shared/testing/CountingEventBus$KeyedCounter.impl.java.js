/**
 * @fileoverview transpiled from org.gwtproject.event.shared.testing.CountingEventBus$KeyedCounter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.event.shared.testing.CountingEventBus.KeyedCounter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_KeyedCounter_K
  */
class KeyedCounter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<C_KeyedCounter_K, Integer>} */
    this.f_counts__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter_;
  }
  
  /**
   * Factory method corresponding to constructor 'KeyedCounter()'.
   * @template C_KeyedCounter_K
   * @return {!KeyedCounter<C_KeyedCounter_K>}
   * @public
   */
  static $create__() {
    KeyedCounter.$clinit();
    let $instance = new KeyedCounter();
    $instance.$ctor__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'KeyedCounter()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter();
  }
  
  /**
   * @param {C_KeyedCounter_K} key
   * @return {number}
   * @public
   */
  m_getCount__java_lang_Object_$pp_org_gwtproject_event_shared_testing(key) {
    let count = /**@type {Integer} */ ($Casts.$to(this.f_counts__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter_.get(key), Integer));
    return $Equality.$same(count, null) ? 0 : count.m_intValue__();
  }
  
  /**
   * @param {C_KeyedCounter_K} key
   * @return {void}
   * @public
   */
  m_decrement__java_lang_Object_$pp_org_gwtproject_event_shared_testing(key) {
    this.f_counts__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter_.put(key, Integer.m_valueOf__int(this.m_getCount__java_lang_Object_$pp_org_gwtproject_event_shared_testing(key) - 1));
  }
  
  /**
   * @param {C_KeyedCounter_K} key
   * @return {void}
   * @public
   */
  m_increment__java_lang_Object_$pp_org_gwtproject_event_shared_testing(key) {
    this.f_counts__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter_.put(key, Integer.m_valueOf__int(this.m_getCount__java_lang_Object_$pp_org_gwtproject_event_shared_testing(key) + 1));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter() {
    this.f_counts__org_gwtproject_event_shared_testing_CountingEventBus_KeyedCounter_ = /**@type {!HashMap<C_KeyedCounter_K, Integer>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof KeyedCounter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, KeyedCounter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    KeyedCounter.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(KeyedCounter, $Util.$makeClassName('org.gwtproject.event.shared.testing.CountingEventBus$KeyedCounter'));




exports = KeyedCounter; 
//# sourceMappingURL=CountingEventBus$KeyedCounter.js.map