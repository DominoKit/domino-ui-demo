/**
 * @fileoverview transpiled from org.gwtproject.event.shared.UmbrellaException.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.UmbrellaException');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _RuntimeException = goog.require('java.lang.RuntimeException');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _Throwable = goog.require('java.lang.Throwable');
const _Collections = goog.require('java.util.Collections');
const _Set = goog.require('java.util.Set');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var UmbrellaException = goog.require('org.gwtproject.event.shared.UmbrellaException$impl');
exports = UmbrellaException;
 