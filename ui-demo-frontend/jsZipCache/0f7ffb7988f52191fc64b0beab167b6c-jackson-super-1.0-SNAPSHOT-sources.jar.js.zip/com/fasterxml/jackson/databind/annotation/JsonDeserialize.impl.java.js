/**
 * @fileoverview transpiled from com.fasterxml.jackson.databind.annotation.JsonDeserialize.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.databind.annotation.JsonDeserialize$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonDeserialize {
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_using__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_contentUsing__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_keyUsing__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_converter__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_contentConverter__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_as__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_keyAs__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_contentAs__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_builder__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_databind_annotation_JsonDeserialize = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_databind_annotation_JsonDeserialize;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_databind_annotation_JsonDeserialize;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonDeserialize.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonDeserialize, $Util.$makeClassName('com.fasterxml.jackson.databind.annotation.JsonDeserialize'));


JsonDeserialize.$markImplementor(/** @type {Function} */ (JsonDeserialize));


exports = JsonDeserialize; 
//# sourceMappingURL=JsonDeserialize.js.map