/**
 * @fileoverview transpiled from com.fasterxml.jackson.databind.annotation.JsonDeserialize.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.databind.annotation.JsonDeserialize');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');


// Re-exports the implementation.
var JsonDeserialize = goog.require('com.fasterxml.jackson.databind.annotation.JsonDeserialize$impl');
exports = JsonDeserialize;
 