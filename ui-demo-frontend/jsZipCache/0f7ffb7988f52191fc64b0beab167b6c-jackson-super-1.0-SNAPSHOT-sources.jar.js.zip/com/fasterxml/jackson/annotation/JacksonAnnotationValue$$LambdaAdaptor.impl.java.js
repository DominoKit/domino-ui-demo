/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JacksonAnnotationValue$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JacksonAnnotationValue.$LambdaAdaptor$impl');


const JacksonAnnotationValue = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotationValue$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Annotation = goog.forwardDeclare('java.lang.annotation.Annotation$impl');


/**
 * @template C_A
 * @implements {JacksonAnnotationValue<C_A>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<C_A>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Class<C_A>} */
    this.f_$$fn__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$LambdaAdaptor;
    this.$ctor__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$LambdaAdaptor__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<C_A>} fn
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$LambdaAdaptor__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Class<C_A>}
   * @public
   */
  m_valueFor__() {
    let /** ?function():Class<C_A> */ $function;
    return ($function = this.f_$$fn__com_fasterxml_jackson_annotation_JacksonAnnotationValue_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('com.fasterxml.jackson.annotation.JacksonAnnotationValue$$LambdaAdaptor'));


JacksonAnnotationValue.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=JacksonAnnotationValue$$LambdaAdaptor.js.map