/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonFormat.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonFormat$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Feature = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonFormat.Feature$impl');
let Shape = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonFormat {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_pattern__() {
  }
  
  /**
   * @abstract
   * @return {Shape}
   * @public
   */
  m_shape__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_locale__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_timezone__() {
  }
  
  /**
   * @abstract
   * @return {Array<Feature>}
   * @public
   */
  m_with__() {
  }
  
  /**
   * @abstract
   * @return {Array<Feature>}
   * @public
   */
  m_without__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonFormat = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonFormat;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonFormat;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonFormat.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonFormat, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonFormat'));


/** @public {?string} @const */
JsonFormat.f_DEFAULT_LOCALE__com_fasterxml_jackson_annotation_JsonFormat = "##default";


/** @public {?string} @const */
JsonFormat.f_DEFAULT_TIMEZONE__com_fasterxml_jackson_annotation_JsonFormat = "##default";


JsonFormat.$markImplementor(/** @type {Function} */ (JsonFormat));


exports = JsonFormat; 
//# sourceMappingURL=JsonFormat.js.map