/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JacksonAnnotation$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JacksonAnnotation.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _JacksonAnnotation = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotation');
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Annotation = goog.require('java.lang.annotation.Annotation');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotation.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 