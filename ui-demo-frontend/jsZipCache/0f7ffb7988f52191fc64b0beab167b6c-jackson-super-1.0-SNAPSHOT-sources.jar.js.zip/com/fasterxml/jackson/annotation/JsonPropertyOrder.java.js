/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonPropertyOrder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonPropertyOrder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var JsonPropertyOrder = goog.require('com.fasterxml.jackson.annotation.JsonPropertyOrder$impl');
exports = JsonPropertyOrder;
 