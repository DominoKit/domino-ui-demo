/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonTypeInfo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonTypeInfo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _As = goog.require('com.fasterxml.jackson.annotation.JsonTypeInfo.As');
const _Id = goog.require('com.fasterxml.jackson.annotation.JsonTypeInfo.Id');
const _Class = goog.require('java.lang.Class');


// Re-exports the implementation.
var JsonTypeInfo = goog.require('com.fasterxml.jackson.annotation.JsonTypeInfo$impl');
exports = JsonTypeInfo;
 