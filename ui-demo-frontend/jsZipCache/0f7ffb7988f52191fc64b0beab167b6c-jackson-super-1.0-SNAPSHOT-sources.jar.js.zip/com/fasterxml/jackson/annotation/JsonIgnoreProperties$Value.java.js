/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonIgnoreProperties$Value.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _JacksonAnnotationValue = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotationValue');
const _Serializable = goog.require('java.io.Serializable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');
const _JsonIgnoreProperties = goog.require('com.fasterxml.jackson.annotation.JsonIgnoreProperties');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _Collections = goog.require('java.util.Collections');
const _HashSet = goog.require('java.util.HashSet');
const _Set = goog.require('java.util.Set');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var Value = goog.require('com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value$impl');
exports = Value;
 