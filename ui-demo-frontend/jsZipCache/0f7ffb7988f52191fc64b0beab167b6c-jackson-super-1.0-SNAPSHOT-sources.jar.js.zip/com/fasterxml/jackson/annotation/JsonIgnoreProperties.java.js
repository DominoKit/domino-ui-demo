/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonIgnoreProperties.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonIgnoreProperties');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var JsonIgnoreProperties = goog.require('com.fasterxml.jackson.annotation.JsonIgnoreProperties$impl');
exports = JsonIgnoreProperties;
 