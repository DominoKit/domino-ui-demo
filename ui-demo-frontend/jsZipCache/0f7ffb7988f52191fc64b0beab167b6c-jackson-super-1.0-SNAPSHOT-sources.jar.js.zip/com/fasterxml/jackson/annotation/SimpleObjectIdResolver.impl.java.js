/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.SimpleObjectIdResolver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.SimpleObjectIdResolver$impl');


const ObjectIdResolver = goog.require('com.fasterxml.jackson.annotation.ObjectIdResolver$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let IllegalStateException = goog.forwardDeclare('java.lang.IllegalStateException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {ObjectIdResolver}
  */
class SimpleObjectIdResolver extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<IdKey, *>} */
    this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver;
  }
  
  /**
   * Factory method corresponding to constructor 'SimpleObjectIdResolver()'.
   * @return {!SimpleObjectIdResolver}
   * @public
   */
  static $create__() {
    SimpleObjectIdResolver.$clinit();
    let $instance = new SimpleObjectIdResolver();
    $instance.$ctor__com_fasterxml_jackson_annotation_SimpleObjectIdResolver__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SimpleObjectIdResolver()'.
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_SimpleObjectIdResolver__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {IdKey} id
   * @param {*} ob
   * @return {void}
   * @public
   */
  m_bindItem__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Object(id, ob) {
    if ($Equality.$same(this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver, null)) {
      this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver = /**@type {!HashMap<IdKey, *>} */ (HashMap.$create__());
    } else if (this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver.containsKey(id)) {
      throw $Exceptions.toJs(IllegalStateException.$create__java_lang_String("Already had POJO for id (" + j_l_String.m_valueOf__java_lang_Object($Objects.m_getClass__java_lang_Object(id.f_key__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey).m_getName__()) + ") [" + j_l_String.m_valueOf__java_lang_Object(id) + "]"));
    }
    this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver.put(id, ob);
  }
  
  /**
   * @override
   * @param {IdKey} id
   * @return {*}
   * @public
   */
  m_resolveId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey(id) {
    return $Equality.$same(this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver, null) ? null : this.f__items__com_fasterxml_jackson_annotation_SimpleObjectIdResolver.get(id);
  }
  
  /**
   * @override
   * @param {ObjectIdResolver} resolverType
   * @return {boolean}
   * @public
   */
  m_canUseFor__com_fasterxml_jackson_annotation_ObjectIdResolver(resolverType) {
    return $Equality.$same($Objects.m_getClass__java_lang_Object(resolverType), this.m_getClass__());
  }
  
  /**
   * @override
   * @param {*} context
   * @return {ObjectIdResolver}
   * @public
   */
  m_newForDeserialization__java_lang_Object(context) {
    return SimpleObjectIdResolver.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SimpleObjectIdResolver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SimpleObjectIdResolver);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SimpleObjectIdResolver.$clinit = function() {};
    IllegalStateException = goog.module.get('java.lang.IllegalStateException$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SimpleObjectIdResolver, $Util.$makeClassName('com.fasterxml.jackson.annotation.SimpleObjectIdResolver'));


ObjectIdResolver.$markImplementor(SimpleObjectIdResolver);


exports = SimpleObjectIdResolver; 
//# sourceMappingURL=SimpleObjectIdResolver.js.map