/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAutoDetect.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAutoDetect$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Visibility = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonAutoDetect {
  /**
   * @abstract
   * @return {Visibility}
   * @public
   */
  m_getterVisibility__() {
  }
  
  /**
   * @abstract
   * @return {Visibility}
   * @public
   */
  m_isGetterVisibility__() {
  }
  
  /**
   * @abstract
   * @return {Visibility}
   * @public
   */
  m_setterVisibility__() {
  }
  
  /**
   * @abstract
   * @return {Visibility}
   * @public
   */
  m_creatorVisibility__() {
  }
  
  /**
   * @abstract
   * @return {Visibility}
   * @public
   */
  m_fieldVisibility__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonAutoDetect = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonAutoDetect;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonAutoDetect;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonAutoDetect.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonAutoDetect, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonAutoDetect'));


JsonAutoDetect.$markImplementor(/** @type {Function} */ (JsonAutoDetect));


exports = JsonAutoDetect; 
//# sourceMappingURL=JsonAutoDetect.js.map