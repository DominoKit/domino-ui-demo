/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JacksonAnnotationValue.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JacksonAnnotationValue');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotationValue.$LambdaAdaptor');
const _Class = goog.require('java.lang.Class');
const _Annotation = goog.require('java.lang.annotation.Annotation');


// Re-exports the implementation.
var JacksonAnnotationValue = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotationValue$impl');
exports = JacksonAnnotationValue;
 