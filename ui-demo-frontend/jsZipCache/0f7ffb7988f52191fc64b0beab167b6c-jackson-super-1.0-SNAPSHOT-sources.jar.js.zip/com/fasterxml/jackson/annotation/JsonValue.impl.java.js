/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonValue.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonValue$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonValue {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonValue = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonValue;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonValue;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonValue.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonValue, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonValue'));


JsonValue.$markImplementor(/** @type {Function} */ (JsonValue));


exports = JsonValue; 
//# sourceMappingURL=JsonValue.js.map