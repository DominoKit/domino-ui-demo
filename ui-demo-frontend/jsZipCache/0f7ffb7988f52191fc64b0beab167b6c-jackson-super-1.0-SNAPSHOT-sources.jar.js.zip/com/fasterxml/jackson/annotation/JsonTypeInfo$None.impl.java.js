/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonTypeInfo$None.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonTypeInfo.None$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @abstract
  */
class None extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'None()'.
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonTypeInfo_None__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof None;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, None);
  }
  
  /**
   * @public
   */
  static $clinit() {
    None.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(None, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonTypeInfo$None'));




exports = None; 
//# sourceMappingURL=JsonTypeInfo$None.js.map