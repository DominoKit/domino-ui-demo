/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.ObjectIdResolver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.ObjectIdResolver$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');


/**
 * @interface
 */
class ObjectIdResolver {
  /**
   * @abstract
   * @param {IdKey} id
   * @param {*} pojo
   * @return {void}
   * @public
   */
  m_bindItem__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Object(id, pojo) {
  }
  
  /**
   * @abstract
   * @param {IdKey} id
   * @return {*}
   * @public
   */
  m_resolveId__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey(id) {
  }
  
  /**
   * @abstract
   * @param {*} context
   * @return {ObjectIdResolver}
   * @public
   */
  m_newForDeserialization__java_lang_Object(context) {
  }
  
  /**
   * @abstract
   * @param {ObjectIdResolver} resolverType
   * @return {boolean}
   * @public
   */
  m_canUseFor__com_fasterxml_jackson_annotation_ObjectIdResolver(resolverType) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_ObjectIdResolver = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_ObjectIdResolver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_ObjectIdResolver;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ObjectIdResolver.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ObjectIdResolver, $Util.$makeClassName('com.fasterxml.jackson.annotation.ObjectIdResolver'));


ObjectIdResolver.$markImplementor(/** @type {Function} */ (ObjectIdResolver));


exports = ObjectIdResolver; 
//# sourceMappingURL=ObjectIdResolver.js.map