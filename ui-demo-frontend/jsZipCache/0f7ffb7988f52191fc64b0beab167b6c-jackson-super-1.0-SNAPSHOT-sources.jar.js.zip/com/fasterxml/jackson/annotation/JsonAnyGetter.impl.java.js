/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAnyGetter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAnyGetter$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonAnyGetter.$LambdaAdaptor$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonAnyGetter {
  /**
   * @param {?function():Class<?>} fn
   * @return {JsonAnyGetter}
   * @public
   */
  static $adapt(fn) {
    JsonAnyGetter.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonAnyGetter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonAnyGetter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonAnyGetter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonAnyGetter.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('com.fasterxml.jackson.annotation.JsonAnyGetter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonAnyGetter, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonAnyGetter'));


JsonAnyGetter.$markImplementor(/** @type {Function} */ (JsonAnyGetter));


exports = JsonAnyGetter; 
//# sourceMappingURL=JsonAnyGetter.js.map