/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JacksonAnnotation.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JacksonAnnotation$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('com.fasterxml.jackson.annotation.JacksonAnnotation.$LambdaAdaptor$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JacksonAnnotation {
  /**
   * @param {?function():Class<?>} fn
   * @return {JacksonAnnotation}
   * @public
   */
  static $adapt(fn) {
    JacksonAnnotation.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JacksonAnnotation = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JacksonAnnotation;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JacksonAnnotation;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JacksonAnnotation.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('com.fasterxml.jackson.annotation.JacksonAnnotation.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JacksonAnnotation, $Util.$makeClassName('com.fasterxml.jackson.annotation.JacksonAnnotation'));


JacksonAnnotation.$markImplementor(/** @type {Function} */ (JacksonAnnotation));


exports = JacksonAnnotation; 
//# sourceMappingURL=JacksonAnnotation.js.map