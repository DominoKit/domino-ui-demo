/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.ObjectIdGenerator$IdKey.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
exports = IdKey;
 