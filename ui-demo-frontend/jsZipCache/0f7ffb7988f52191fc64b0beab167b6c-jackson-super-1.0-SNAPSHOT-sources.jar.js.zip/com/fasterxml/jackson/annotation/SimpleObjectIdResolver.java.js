/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.SimpleObjectIdResolver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.SimpleObjectIdResolver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _ObjectIdResolver = goog.require('com.fasterxml.jackson.annotation.ObjectIdResolver');
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var SimpleObjectIdResolver = goog.require('com.fasterxml.jackson.annotation.SimpleObjectIdResolver$impl');
exports = SimpleObjectIdResolver;
 