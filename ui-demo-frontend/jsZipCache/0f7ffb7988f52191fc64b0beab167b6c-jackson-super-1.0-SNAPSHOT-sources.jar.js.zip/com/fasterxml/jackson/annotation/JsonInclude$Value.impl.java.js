/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonInclude$Value.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonInclude.Value$impl');


const JacksonAnnotationValue = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotationValue$impl');
const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JsonInclude = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonInclude$impl');
let Include = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {JacksonAnnotationValue<JsonInclude>}
 * @implements {Serializable}
  */
class Value extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Include} */
    this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value;
    /** @public {Include} */
    this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value;
  }
  
  /**
   * Factory method corresponding to constructor 'Value(JsonInclude)'.
   * @param {JsonInclude} src
   * @return {!Value}
   * @public
   */
  static $create__com_fasterxml_jackson_annotation_JsonInclude(src) {
    Value.$clinit();
    let $instance = new Value();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonInclude_Value__com_fasterxml_jackson_annotation_JsonInclude(src);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Value(JsonInclude)'.
   * @param {JsonInclude} src
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonInclude_Value__com_fasterxml_jackson_annotation_JsonInclude(src) {
    this.$ctor__com_fasterxml_jackson_annotation_JsonInclude_Value__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(src.m_value__(), src.m_content__());
  }
  
  /**
   * Factory method corresponding to constructor 'Value(Include, Include)'.
   * @param {Include} vi
   * @param {Include} ci
   * @return {!Value}
   * @public
   */
  static $create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(vi, ci) {
    Value.$clinit();
    let $instance = new Value();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonInclude_Value__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(vi, ci);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Value(Include, Include)'.
   * @param {Include} vi
   * @param {Include} ci
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonInclude_Value__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(vi, ci) {
    this.$ctor__java_lang_Object__();
    this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value = $Equality.$same(vi, null) ? Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include : vi;
    this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value = $Equality.$same(ci, null) ? Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include : ci;
  }
  
  /**
   * @return {Value}
   * @public
   */
  static m_empty__() {
    Value.$clinit();
    return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value;
  }
  
  /**
   * @return {*}
   * @public
   */
  m_readResolve__() {
    if ($Equality.$same(this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include) && $Equality.$same(this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include)) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value;
    }
    return this;
  }
  
  /**
   * @param {Value} overrides
   * @return {Value}
   * @public
   */
  m_withOverrides__com_fasterxml_jackson_annotation_JsonInclude_Value(overrides) {
    if ($Equality.$same(overrides, null) || $Equality.$same(overrides, Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value)) {
      return this;
    }
    let vi = overrides.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value;
    let ci = overrides.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value;
    let viDiff = (!$Equality.$same(vi, this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value)) && (!$Equality.$same(vi, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include));
    let ciDiff = (!$Equality.$same(ci, this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value)) && (!$Equality.$same(ci, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include));
    if (viDiff) {
      if (ciDiff) {
        return Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(vi, ci);
      }
      return Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(vi, this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value);
    } else if (ciDiff) {
      return Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value, ci);
    }
    return this;
  }
  
  /**
   * @param {Include} valueIncl
   * @param {Include} contentIncl
   * @return {Value}
   * @public
   */
  static m_construct__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(valueIncl, contentIncl) {
    Value.$clinit();
    if (($Equality.$same(valueIncl, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include) || $Equality.$same(valueIncl, null)) && ($Equality.$same(contentIncl, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include) || $Equality.$same(contentIncl, null))) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value;
    }
    return Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(valueIncl, contentIncl);
  }
  
  /**
   * @param {JsonInclude} src
   * @return {Value}
   * @public
   */
  static m_from__com_fasterxml_jackson_annotation_JsonInclude(src) {
    Value.$clinit();
    if ($Equality.$same(src, null)) {
      return null;
    }
    let vi = src.m_value__();
    let ci = src.m_content__();
    if ($Equality.$same(vi, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include) && $Equality.$same(ci, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include)) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value;
    }
    return Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(vi, ci);
  }
  
  /**
   * @param {Include} incl
   * @return {Value}
   * @public
   */
  m_withValueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Include(incl) {
    return $Equality.$same(incl, this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value) ? this : Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(incl, this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value);
  }
  
  /**
   * @param {Include} incl
   * @return {Value}
   * @public
   */
  m_withContentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Include(incl) {
    return $Equality.$same(incl, this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value) ? this : Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value, incl);
  }
  
  /**
   * @override
   * @return {Class<JsonInclude>}
   * @public
   */
  m_valueFor__() {
    return Class.$get(JsonInclude);
  }
  
  /**
   * @return {Include}
   * @public
   */
  m_getValueInclusion__() {
    return this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value;
  }
  
  /**
   * @return {Include}
   * @public
   */
  m_getContentInclusion__() {
    return this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "[value=" + j_l_String.m_valueOf__java_lang_Object(this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value) + ",content=" + j_l_String.m_valueOf__java_lang_Object(this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value) + "]";
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return ($Objects.m_hashCode__java_lang_Object(this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value) << 2) + $Objects.m_hashCode__java_lang_Object(this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value);
  }
  
  /**
   * @override
   * @param {*} o
   * @return {boolean}
   * @public
   */
  equals(o) {
    if ($Equality.$same(o, this)) {
      return true;
    }
    if ($Equality.$same(o, null)) {
      return false;
    }
    if (!$Equality.$same($Objects.m_getClass__java_lang_Object(o), this.m_getClass__())) {
      return false;
    }
    let other = /**@type {Value} */ ($Casts.$to(o, Value));
    return $Equality.$same(other.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value, this.f__valueInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value) && $Equality.$same(other.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value, this.f__contentInclusion__com_fasterxml_jackson_annotation_JsonInclude_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  static get f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value() {
    return (Value.$clinit(), Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value);
  }
  
  /**
   * @param {Value} value
   * @return {void}
   * @public
   */
  static set f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value(value) {
    (Value.$clinit(), Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Value;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Value);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Value.$clinit = function() {};
    JsonInclude = goog.module.get('com.fasterxml.jackson.annotation.JsonInclude$impl');
    Include = goog.module.get('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');
    Class = goog.module.get('java.lang.Class$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
    Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value = Value.$create__com_fasterxml_jackson_annotation_JsonInclude_Include__com_fasterxml_jackson_annotation_JsonInclude_Include(Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include, Include.f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  
};

$Util.$setClassMetadata(Value, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonInclude$Value'));


/** @public {!$Long} @const */
Value.f_serialVersionUID__com_fasterxml_jackson_annotation_JsonInclude_Value_ = $Long.fromInt(1);


/** @private {Value} */
Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Value;


JacksonAnnotationValue.$markImplementor(Value);
Serializable.$markImplementor(Value);


exports = Value; 
//# sourceMappingURL=JsonInclude$Value.js.map