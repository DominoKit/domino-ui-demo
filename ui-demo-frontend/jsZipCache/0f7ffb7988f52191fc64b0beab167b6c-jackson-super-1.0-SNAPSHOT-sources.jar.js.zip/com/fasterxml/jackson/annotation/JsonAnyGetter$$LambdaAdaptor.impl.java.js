/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAnyGetter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAnyGetter.$LambdaAdaptor$impl');


const JsonAnyGetter = goog.require('com.fasterxml.jackson.annotation.JsonAnyGetter$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Annotation = goog.forwardDeclare('java.lang.annotation.Annotation$impl');


/**
 * @implements {JsonAnyGetter}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Class<?>} */
    this.f_$$fn__com_fasterxml_jackson_annotation_JsonAnyGetter_$LambdaAdaptor;
    this.$ctor__com_fasterxml_jackson_annotation_JsonAnyGetter_$LambdaAdaptor__com_fasterxml_jackson_annotation_JsonAnyGetter_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonAnyGetter_$LambdaAdaptor__com_fasterxml_jackson_annotation_JsonAnyGetter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__com_fasterxml_jackson_annotation_JsonAnyGetter_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Class<?>}
   * @public
   */
  m_annotationType__() {
    let /** ?function():Class<?> */ $function;
    return ($function = this.f_$$fn__com_fasterxml_jackson_annotation_JsonAnyGetter_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonAnyGetter$$LambdaAdaptor'));


JsonAnyGetter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=JsonAnyGetter$$LambdaAdaptor.js.map