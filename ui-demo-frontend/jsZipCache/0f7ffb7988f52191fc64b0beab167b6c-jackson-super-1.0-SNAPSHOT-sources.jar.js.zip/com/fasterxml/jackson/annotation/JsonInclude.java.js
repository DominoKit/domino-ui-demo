/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonInclude.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonInclude');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Include = goog.require('com.fasterxml.jackson.annotation.JsonInclude.Include');


// Re-exports the implementation.
var JsonInclude = goog.require('com.fasterxml.jackson.annotation.JsonInclude$impl');
exports = JsonInclude;
 