/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonFormat$Feature.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonFormat.Feature$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Feature>}
  */
class Feature extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Feature(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Feature}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Feature();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonFormat_Feature__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Feature(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonFormat_Feature__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Feature}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Feature.$clinit();
    if ($Equality.$same(Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_, null)) {
      Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_ = $Enums.createMapFromValues(Feature.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_);
  }
  
  /**
   * @return {!Array<!Feature>}
   * @public
   */
  static m_values__() {
    Feature.$clinit();
    return /**@type {!Array<Feature>} */ ($Arrays.$init([Feature.$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature, Feature.$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature, Feature.$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature, Feature.$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature, Feature.$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature], Feature));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Feature} */ ($Casts.$to(arg0, Feature)));
  }
  
  /**
   * @return {!Feature}
   * @public
   */
  static get f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature() {
    return (Feature.$clinit(), Feature.$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature);
  }
  
  /**
   * @param {!Feature} value
   * @return {void}
   * @public
   */
  static set f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature(value) {
    (Feature.$clinit(), Feature.$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature = value);
  }
  
  /**
   * @return {!Feature}
   * @public
   */
  static get f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature() {
    return (Feature.$clinit(), Feature.$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature);
  }
  
  /**
   * @param {!Feature} value
   * @return {void}
   * @public
   */
  static set f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature(value) {
    (Feature.$clinit(), Feature.$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature = value);
  }
  
  /**
   * @return {!Feature}
   * @public
   */
  static get f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature() {
    return (Feature.$clinit(), Feature.$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature);
  }
  
  /**
   * @param {!Feature} value
   * @return {void}
   * @public
   */
  static set f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature(value) {
    (Feature.$clinit(), Feature.$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature = value);
  }
  
  /**
   * @return {!Feature}
   * @public
   */
  static get f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature() {
    return (Feature.$clinit(), Feature.$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature);
  }
  
  /**
   * @param {!Feature} value
   * @return {void}
   * @public
   */
  static set f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature(value) {
    (Feature.$clinit(), Feature.$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature = value);
  }
  
  /**
   * @return {!Feature}
   * @public
   */
  static get f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature() {
    return (Feature.$clinit(), Feature.$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature);
  }
  
  /**
   * @param {!Feature} value
   * @return {void}
   * @public
   */
  static set f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature(value) {
    (Feature.$clinit(), Feature.$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature = value);
  }
  
  /**
   * @return {Map<?string, !Feature>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_() {
    return (Feature.$clinit(), Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_);
  }
  
  /**
   * @param {Map<?string, !Feature>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_(value) {
    (Feature.$clinit(), Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Feature;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Feature);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Feature.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Feature.$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature = Feature.$create__java_lang_String__int($Util.$makeEnumName("ACCEPT_SINGLE_VALUE_AS_ARRAY"), Feature.$ordinal$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature);
    Feature.$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature = Feature.$create__java_lang_String__int($Util.$makeEnumName("WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS"), Feature.$ordinal$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature);
    Feature.$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature = Feature.$create__java_lang_String__int($Util.$makeEnumName("WRITE_DATES_WITH_ZONE_ID"), Feature.$ordinal$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature);
    Feature.$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature = Feature.$create__java_lang_String__int($Util.$makeEnumName("WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED"), Feature.$ordinal$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature);
    Feature.$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature = Feature.$create__java_lang_String__int($Util.$makeEnumName("WRITE_SORTED_MAP_ENTRIES"), Feature.$ordinal$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature);
    Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Feature, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonFormat$Feature'));


/** @private {!Feature} */
Feature.$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature;


/** @private {!Feature} */
Feature.$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature;


/** @private {!Feature} */
Feature.$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature;


/** @private {!Feature} */
Feature.$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature;


/** @private {!Feature} */
Feature.$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature;


/** @private {Map<?string, !Feature>} */
Feature.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Feature_;


/** @public {number} @const */
Feature.$ordinal$f_ACCEPT_SINGLE_VALUE_AS_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Feature = 0;


/** @public {number} @const */
Feature.$ordinal$f_WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS__com_fasterxml_jackson_annotation_JsonFormat_Feature = 1;


/** @public {number} @const */
Feature.$ordinal$f_WRITE_DATES_WITH_ZONE_ID__com_fasterxml_jackson_annotation_JsonFormat_Feature = 2;


/** @public {number} @const */
Feature.$ordinal$f_WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED__com_fasterxml_jackson_annotation_JsonFormat_Feature = 3;


/** @public {number} @const */
Feature.$ordinal$f_WRITE_SORTED_MAP_ENTRIES__com_fasterxml_jackson_annotation_JsonFormat_Feature = 4;




exports = Feature; 
//# sourceMappingURL=JsonFormat$Feature.js.map