/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.ObjectIdResolver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.ObjectIdResolver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');


// Re-exports the implementation.
var ObjectIdResolver = goog.require('com.fasterxml.jackson.annotation.ObjectIdResolver$impl');
exports = ObjectIdResolver;
 