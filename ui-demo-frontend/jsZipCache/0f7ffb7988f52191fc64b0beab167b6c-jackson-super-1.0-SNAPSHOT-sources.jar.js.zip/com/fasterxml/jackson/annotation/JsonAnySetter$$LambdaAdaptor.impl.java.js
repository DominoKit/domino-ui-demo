/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAnySetter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAnySetter.$LambdaAdaptor$impl');


const JsonAnySetter = goog.require('com.fasterxml.jackson.annotation.JsonAnySetter$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Annotation = goog.forwardDeclare('java.lang.annotation.Annotation$impl');


/**
 * @implements {JsonAnySetter}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Class<?>} */
    this.f_$$fn__com_fasterxml_jackson_annotation_JsonAnySetter_$LambdaAdaptor;
    this.$ctor__com_fasterxml_jackson_annotation_JsonAnySetter_$LambdaAdaptor__com_fasterxml_jackson_annotation_JsonAnySetter_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():Class<?>} fn
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonAnySetter_$LambdaAdaptor__com_fasterxml_jackson_annotation_JsonAnySetter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__com_fasterxml_jackson_annotation_JsonAnySetter_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Class<?>}
   * @public
   */
  m_annotationType__() {
    let /** ?function():Class<?> */ $function;
    return ($function = this.f_$$fn__com_fasterxml_jackson_annotation_JsonAnySetter_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonAnySetter$$LambdaAdaptor'));


JsonAnySetter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=JsonAnySetter$$LambdaAdaptor.js.map