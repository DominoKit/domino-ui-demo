/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAnyGetter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAnyGetter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('com.fasterxml.jackson.annotation.JsonAnyGetter.$LambdaAdaptor');
const _Class = goog.require('java.lang.Class');


// Re-exports the implementation.
var JsonAnyGetter = goog.require('com.fasterxml.jackson.annotation.JsonAnyGetter$impl');
exports = JsonAnyGetter;
 