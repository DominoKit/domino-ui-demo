/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonTypeInfo$As.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonTypeInfo.As$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<As>}
  */
class As extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'As(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!As}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new As();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonTypeInfo_As__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'As(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonTypeInfo_As__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!As}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    As.$clinit();
    if ($Equality.$same(As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_, null)) {
      As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_ = $Enums.createMapFromValues(As.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_);
  }
  
  /**
   * @return {!Array<!As>}
   * @public
   */
  static m_values__() {
    As.$clinit();
    return /**@type {!Array<As>} */ ($Arrays.$init([As.$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As, As.$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As, As.$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As, As.$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As, As.$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As], As));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {As} */ ($Casts.$to(arg0, As)));
  }
  
  /**
   * @return {!As}
   * @public
   */
  static get f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As() {
    return (As.$clinit(), As.$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
  }
  
  /**
   * @param {!As} value
   * @return {void}
   * @public
   */
  static set f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As(value) {
    (As.$clinit(), As.$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = value);
  }
  
  /**
   * @return {!As}
   * @public
   */
  static get f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As() {
    return (As.$clinit(), As.$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
  }
  
  /**
   * @param {!As} value
   * @return {void}
   * @public
   */
  static set f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As(value) {
    (As.$clinit(), As.$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As = value);
  }
  
  /**
   * @return {!As}
   * @public
   */
  static get f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As() {
    return (As.$clinit(), As.$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
  }
  
  /**
   * @param {!As} value
   * @return {void}
   * @public
   */
  static set f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As(value) {
    (As.$clinit(), As.$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = value);
  }
  
  /**
   * @return {!As}
   * @public
   */
  static get f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As() {
    return (As.$clinit(), As.$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
  }
  
  /**
   * @param {!As} value
   * @return {void}
   * @public
   */
  static set f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As(value) {
    (As.$clinit(), As.$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = value);
  }
  
  /**
   * @return {!As}
   * @public
   */
  static get f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As() {
    return (As.$clinit(), As.$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
  }
  
  /**
   * @param {!As} value
   * @return {void}
   * @public
   */
  static set f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As(value) {
    (As.$clinit(), As.$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = value);
  }
  
  /**
   * @return {Map<?string, !As>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_() {
    return (As.$clinit(), As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_);
  }
  
  /**
   * @param {Map<?string, !As>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_(value) {
    (As.$clinit(), As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof As;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, As);
  }
  
  /**
   * @public
   */
  static $clinit() {
    As.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    As.$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = As.$create__java_lang_String__int($Util.$makeEnumName("PROPERTY"), As.$ordinal$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
    As.$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As = As.$create__java_lang_String__int($Util.$makeEnumName("WRAPPER_OBJECT"), As.$ordinal$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
    As.$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = As.$create__java_lang_String__int($Util.$makeEnumName("WRAPPER_ARRAY"), As.$ordinal$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
    As.$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = As.$create__java_lang_String__int($Util.$makeEnumName("EXTERNAL_PROPERTY"), As.$ordinal$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
    As.$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = As.$create__java_lang_String__int($Util.$makeEnumName("EXISTING_PROPERTY"), As.$ordinal$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As);
    As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(As, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonTypeInfo$As'));


/** @private {!As} */
As.$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As;


/** @private {!As} */
As.$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As;


/** @private {!As} */
As.$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As;


/** @private {!As} */
As.$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As;


/** @private {!As} */
As.$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As;


/** @private {Map<?string, !As>} */
As.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_As_;


/** @public {number} @const */
As.$ordinal$f_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = 0;


/** @public {number} @const */
As.$ordinal$f_WRAPPER_OBJECT__com_fasterxml_jackson_annotation_JsonTypeInfo_As = 1;


/** @public {number} @const */
As.$ordinal$f_WRAPPER_ARRAY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = 2;


/** @public {number} @const */
As.$ordinal$f_EXTERNAL_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = 3;


/** @public {number} @const */
As.$ordinal$f_EXISTING_PROPERTY__com_fasterxml_jackson_annotation_JsonTypeInfo_As = 4;




exports = As; 
//# sourceMappingURL=JsonTypeInfo$As.js.map