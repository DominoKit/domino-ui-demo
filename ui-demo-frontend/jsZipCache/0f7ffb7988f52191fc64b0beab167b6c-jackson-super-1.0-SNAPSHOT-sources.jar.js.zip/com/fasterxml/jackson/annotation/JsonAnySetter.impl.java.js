/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAnySetter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAnySetter$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonAnySetter.$LambdaAdaptor$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonAnySetter {
  /**
   * @param {?function():Class<?>} fn
   * @return {JsonAnySetter}
   * @public
   */
  static $adapt(fn) {
    JsonAnySetter.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonAnySetter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonAnySetter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonAnySetter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonAnySetter.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('com.fasterxml.jackson.annotation.JsonAnySetter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonAnySetter, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonAnySetter'));


JsonAnySetter.$markImplementor(/** @type {Function} */ (JsonAnySetter));


exports = JsonAnySetter; 
//# sourceMappingURL=JsonAnySetter.js.map