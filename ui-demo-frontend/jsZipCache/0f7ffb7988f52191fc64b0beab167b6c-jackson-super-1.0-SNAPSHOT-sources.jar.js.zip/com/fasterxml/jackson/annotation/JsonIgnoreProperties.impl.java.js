/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonIgnoreProperties.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonIgnoreProperties$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonIgnoreProperties {
  /**
   * @abstract
   * @return {Array<?string>}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_ignoreUnknown__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_allowGetters__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_allowSetters__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonIgnoreProperties = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonIgnoreProperties;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonIgnoreProperties;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonIgnoreProperties.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonIgnoreProperties, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonIgnoreProperties'));


JsonIgnoreProperties.$markImplementor(/** @type {Function} */ (JsonIgnoreProperties));


exports = JsonIgnoreProperties; 
//# sourceMappingURL=JsonIgnoreProperties.js.map