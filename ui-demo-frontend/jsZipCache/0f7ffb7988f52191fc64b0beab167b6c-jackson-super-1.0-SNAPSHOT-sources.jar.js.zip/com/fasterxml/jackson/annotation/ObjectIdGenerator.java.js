/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.ObjectIdGenerator.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.ObjectIdGenerator');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IdKey = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey');
const _Class = goog.require('java.lang.Class');


// Re-exports the implementation.
var ObjectIdGenerator = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator$impl');
exports = ObjectIdGenerator;
 