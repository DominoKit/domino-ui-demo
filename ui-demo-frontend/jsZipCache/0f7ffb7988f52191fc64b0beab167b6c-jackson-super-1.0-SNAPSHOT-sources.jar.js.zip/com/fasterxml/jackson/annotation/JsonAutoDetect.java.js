/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAutoDetect.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAutoDetect');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Visibility = goog.require('com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility');


// Re-exports the implementation.
var JsonAutoDetect = goog.require('com.fasterxml.jackson.annotation.JsonAutoDetect$impl');
exports = JsonAutoDetect;
 