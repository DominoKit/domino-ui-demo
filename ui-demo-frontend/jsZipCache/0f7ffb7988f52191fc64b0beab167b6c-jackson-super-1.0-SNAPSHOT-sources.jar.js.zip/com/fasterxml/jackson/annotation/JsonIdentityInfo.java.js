/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonIdentityInfo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonIdentityInfo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _ObjectIdGenerator = goog.require('com.fasterxml.jackson.annotation.ObjectIdGenerator');
const _ObjectIdResolver = goog.require('com.fasterxml.jackson.annotation.ObjectIdResolver');
const _Class = goog.require('java.lang.Class');


// Re-exports the implementation.
var JsonIdentityInfo = goog.require('com.fasterxml.jackson.annotation.JsonIdentityInfo$impl');
exports = JsonIdentityInfo;
 