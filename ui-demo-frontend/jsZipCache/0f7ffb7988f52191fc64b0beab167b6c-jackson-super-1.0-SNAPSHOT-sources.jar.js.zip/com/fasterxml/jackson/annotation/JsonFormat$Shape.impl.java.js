/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonFormat$Shape.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonFormat.Shape$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Shape>}
  */
class Shape extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Shape(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Shape}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Shape();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonFormat_Shape__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Shape(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonFormat_Shape__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isNumeric__() {
    return $Equality.$same(this, Shape.$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape) || $Equality.$same(this, Shape.$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape) || $Equality.$same(this, Shape.$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isStructured__() {
    return $Equality.$same(this, Shape.$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape) || $Equality.$same(this, Shape.$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {string} name
   * @return {!Shape}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Shape.$clinit();
    if ($Equality.$same(Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_, null)) {
      Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_ = $Enums.createMapFromValues(Shape.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_);
  }
  
  /**
   * @return {!Array<!Shape>}
   * @public
   */
  static m_values__() {
    Shape.$clinit();
    return /**@type {!Array<Shape>} */ ($Arrays.$init([Shape.$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape, Shape.$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape], Shape));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Shape} */ ($Casts.$to(arg0, Shape)));
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {!Shape}
   * @public
   */
  static get f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape() {
    return (Shape.$clinit(), Shape.$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape);
  }
  
  /**
   * @param {!Shape} value
   * @return {void}
   * @public
   */
  static set f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape(value) {
    (Shape.$clinit(), Shape.$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape = value);
  }
  
  /**
   * @return {Map<?string, !Shape>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_() {
    return (Shape.$clinit(), Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_);
  }
  
  /**
   * @param {Map<?string, !Shape>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_(value) {
    (Shape.$clinit(), Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Shape;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Shape);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Shape.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Shape.$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("ANY"), Shape.$ordinal$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("SCALAR"), Shape.$ordinal$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("ARRAY"), Shape.$ordinal$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("OBJECT"), Shape.$ordinal$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("NUMBER"), Shape.$ordinal$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("NUMBER_FLOAT"), Shape.$ordinal$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("NUMBER_INT"), Shape.$ordinal$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("STRING"), Shape.$ordinal$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape = Shape.$create__java_lang_String__int($Util.$makeEnumName("BOOLEAN"), Shape.$ordinal$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape);
    Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Shape, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonFormat$Shape'));


/** @private {!Shape} */
Shape.$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {!Shape} */
Shape.$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape;


/** @private {Map<?string, !Shape>} */
Shape.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonFormat_Shape_;


/** @public {number} @const */
Shape.$ordinal$f_ANY__com_fasterxml_jackson_annotation_JsonFormat_Shape = 0;


/** @public {number} @const */
Shape.$ordinal$f_SCALAR__com_fasterxml_jackson_annotation_JsonFormat_Shape = 1;


/** @public {number} @const */
Shape.$ordinal$f_ARRAY__com_fasterxml_jackson_annotation_JsonFormat_Shape = 2;


/** @public {number} @const */
Shape.$ordinal$f_OBJECT__com_fasterxml_jackson_annotation_JsonFormat_Shape = 3;


/** @public {number} @const */
Shape.$ordinal$f_NUMBER__com_fasterxml_jackson_annotation_JsonFormat_Shape = 4;


/** @public {number} @const */
Shape.$ordinal$f_NUMBER_FLOAT__com_fasterxml_jackson_annotation_JsonFormat_Shape = 5;


/** @public {number} @const */
Shape.$ordinal$f_NUMBER_INT__com_fasterxml_jackson_annotation_JsonFormat_Shape = 6;


/** @public {number} @const */
Shape.$ordinal$f_STRING__com_fasterxml_jackson_annotation_JsonFormat_Shape = 7;


/** @public {number} @const */
Shape.$ordinal$f_BOOLEAN__com_fasterxml_jackson_annotation_JsonFormat_Shape = 8;




exports = Shape; 
//# sourceMappingURL=JsonFormat$Shape.js.map