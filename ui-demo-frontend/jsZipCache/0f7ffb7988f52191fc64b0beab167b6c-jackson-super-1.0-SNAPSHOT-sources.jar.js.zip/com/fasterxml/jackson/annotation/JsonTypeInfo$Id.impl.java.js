/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonTypeInfo$Id.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonTypeInfo.Id$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Id>}
  */
class Id extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f__defaultPropertyName__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_;
  }
  
  /**
   * Factory method corresponding to constructor 'Id(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} defProp
   * @return {!Id}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, defProp) {
    let $instance = new Id();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonTypeInfo_Id__java_lang_String__int__java_lang_String($name, $ordinal, defProp);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Id(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} defProp
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonTypeInfo_Id__java_lang_String__int__java_lang_String($name, $ordinal, defProp) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f__defaultPropertyName__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_ = defProp;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDefaultPropertyName__() {
    return this.f__defaultPropertyName__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_;
  }
  
  /**
   * @param {string} name
   * @return {!Id}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Id.$clinit();
    if ($Equality.$same(Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_, null)) {
      Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_ = $Enums.createMapFromValues(Id.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_);
  }
  
  /**
   * @return {!Array<!Id>}
   * @public
   */
  static m_values__() {
    Id.$clinit();
    return /**@type {!Array<Id>} */ ($Arrays.$init([Id.$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, Id.$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, Id.$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, Id.$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, Id.$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id], Id));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Id} */ ($Casts.$to(arg0, Id)));
  }
  
  /**
   * @return {!Id}
   * @public
   */
  static get f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id() {
    return (Id.$clinit(), Id.$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id);
  }
  
  /**
   * @param {!Id} value
   * @return {void}
   * @public
   */
  static set f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id(value) {
    (Id.$clinit(), Id.$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = value);
  }
  
  /**
   * @return {!Id}
   * @public
   */
  static get f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id() {
    return (Id.$clinit(), Id.$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id);
  }
  
  /**
   * @param {!Id} value
   * @return {void}
   * @public
   */
  static set f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id(value) {
    (Id.$clinit(), Id.$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = value);
  }
  
  /**
   * @return {!Id}
   * @public
   */
  static get f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id() {
    return (Id.$clinit(), Id.$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id);
  }
  
  /**
   * @param {!Id} value
   * @return {void}
   * @public
   */
  static set f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id(value) {
    (Id.$clinit(), Id.$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = value);
  }
  
  /**
   * @return {!Id}
   * @public
   */
  static get f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id() {
    return (Id.$clinit(), Id.$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id);
  }
  
  /**
   * @param {!Id} value
   * @return {void}
   * @public
   */
  static set f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id(value) {
    (Id.$clinit(), Id.$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = value);
  }
  
  /**
   * @return {!Id}
   * @public
   */
  static get f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id() {
    return (Id.$clinit(), Id.$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id);
  }
  
  /**
   * @param {!Id} value
   * @return {void}
   * @public
   */
  static set f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id(value) {
    (Id.$clinit(), Id.$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = value);
  }
  
  /**
   * @return {Map<?string, !Id>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_() {
    return (Id.$clinit(), Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_);
  }
  
  /**
   * @param {Map<?string, !Id>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_(value) {
    (Id.$clinit(), Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Id;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Id);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Id.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Id.$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = Id.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("NONE"), Id.$ordinal$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, null);
    Id.$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = Id.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("CLASS"), Id.$ordinal$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, "@class");
    Id.$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = Id.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("MINIMAL_CLASS"), Id.$ordinal$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, "@c");
    Id.$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = Id.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("NAME"), Id.$ordinal$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, "@type");
    Id.$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = Id.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("CUSTOM"), Id.$ordinal$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id, null);
    Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Id, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonTypeInfo$Id'));


/** @private {!Id} */
Id.$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id;


/** @private {!Id} */
Id.$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id;


/** @private {!Id} */
Id.$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id;


/** @private {!Id} */
Id.$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id;


/** @private {!Id} */
Id.$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id;


/** @private {Map<?string, !Id>} */
Id.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonTypeInfo_Id_;


/** @public {number} @const */
Id.$ordinal$f_NONE__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = 0;


/** @public {number} @const */
Id.$ordinal$f_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = 1;


/** @public {number} @const */
Id.$ordinal$f_MINIMAL_CLASS__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = 2;


/** @public {number} @const */
Id.$ordinal$f_NAME__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = 3;


/** @public {number} @const */
Id.$ordinal$f_CUSTOM__com_fasterxml_jackson_annotation_JsonTypeInfo_Id = 4;




exports = Id; 
//# sourceMappingURL=JsonTypeInfo$Id.js.map