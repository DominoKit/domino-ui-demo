/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonFormat.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('com.fasterxml.jackson.annotation.JsonFormat');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Feature = goog.require('com.fasterxml.jackson.annotation.JsonFormat.Feature');
const _Shape = goog.require('com.fasterxml.jackson.annotation.JsonFormat.Shape');


// Re-exports the implementation.
var JsonFormat = goog.require('com.fasterxml.jackson.annotation.JsonFormat$impl');
exports = JsonFormat;
 