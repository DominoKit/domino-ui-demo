/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonIgnoreProperties$Value.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value$impl');


const JacksonAnnotationValue = goog.require('com.fasterxml.jackson.annotation.JacksonAnnotationValue$impl');
const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JsonIgnoreProperties = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonIgnoreProperties$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Collections = goog.forwardDeclare('java.util.Collections$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {JacksonAnnotationValue<JsonIgnoreProperties>}
 * @implements {Serializable}
  */
class Value extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Set<?string>} */
    this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    /** @public {boolean} */
    this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = false;
    /** @public {boolean} */
    this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = false;
    /** @public {boolean} */
    this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = false;
    /** @public {boolean} */
    this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Value(Set, boolean, boolean, boolean, boolean)'.
   * @param {Set<?string>} ignored
   * @param {boolean} ignoreUnknown
   * @param {boolean} allowGetters
   * @param {boolean} allowSetters
   * @param {boolean} merge
   * @return {!Value}
   * @public
   */
  static $create__java_util_Set__boolean__boolean__boolean__boolean(ignored, ignoreUnknown, allowGetters, allowSetters, merge) {
    Value.$clinit();
    let $instance = new Value();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value__java_util_Set__boolean__boolean__boolean__boolean(ignored, ignoreUnknown, allowGetters, allowSetters, merge);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Value(Set, boolean, boolean, boolean, boolean)'.
   * @param {Set<?string>} ignored
   * @param {boolean} ignoreUnknown
   * @param {boolean} allowGetters
   * @param {boolean} allowSetters
   * @param {boolean} merge
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value__java_util_Set__boolean__boolean__boolean__boolean(ignored, ignoreUnknown, allowGetters, allowSetters, merge) {
    this.$ctor__java_lang_Object__();
    if ($Equality.$same(ignored, null)) {
      this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = /**@type {Set<?string>} */ (Collections.m_emptySet__());
    } else {
      this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = ignored;
    }
    this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = ignoreUnknown;
    this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = allowGetters;
    this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = allowSetters;
    this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = merge;
  }
  
  /**
   * @param {JsonIgnoreProperties} src
   * @return {Value}
   * @public
   */
  static m_from__com_fasterxml_jackson_annotation_JsonIgnoreProperties(src) {
    Value.$clinit();
    if ($Equality.$same(src, null)) {
      return null;
    }
    return Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(Value.m__asSet__arrayOf_java_lang_String_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(src.m_value__()), src.m_ignoreUnknown__(), src.m_allowGetters__(), src.m_allowSetters__(), false);
  }
  
  /**
   * @param {Set<?string>} ignored
   * @param {boolean} ignoreUnknown
   * @param {boolean} allowGetters
   * @param {boolean} allowSetters
   * @param {boolean} merge
   * @return {Value}
   * @public
   */
  static m_construct__java_util_Set__boolean__boolean__boolean__boolean(ignored, ignoreUnknown, allowGetters, allowSetters, merge) {
    Value.$clinit();
    if (Value.m__empty__java_util_Set__boolean__boolean__boolean__boolean_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(ignored, ignoreUnknown, allowGetters, allowSetters, merge)) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    }
    if (Value.m__empty__java_util_Set__boolean__boolean__boolean__boolean_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(ignored, ignoreUnknown, allowGetters, allowSetters, merge)) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    }
    return Value.$create__java_util_Set__boolean__boolean__boolean__boolean(ignored, ignoreUnknown, allowGetters, allowSetters, merge);
  }
  
  /**
   * @return {Value}
   * @public
   */
  static m_empty__() {
    Value.$clinit();
    return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @param {Value} base
   * @param {Value} overrides
   * @return {Value}
   * @public
   */
  static m_merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(base, overrides) {
    Value.$clinit();
    return $Equality.$same(base, null) ? overrides : base.m_withOverrides__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(overrides);
  }
  
  /**
   * @param {Array<Value>} values
   * @return {Value}
   * @public
   */
  static m_mergeAll__arrayOf_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(values) {
    Value.$clinit();
    let result = null;
    for (let $array = values, $index = 0; $index < $array.length; $index++) {
      let curr = $array[$index];
      if (!$Equality.$same(curr, null)) {
        result = $Equality.$same(result, null) ? curr : result.m_withOverrides__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(curr);
      }
    }
    return result;
  }
  
  /**
   * @param {Set<?string>} propNames
   * @return {Value}
   * @public
   */
  static m_forIgnoredProperties__java_util_Set(propNames) {
    Value.$clinit();
    return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.m_withIgnored__java_util_Set(propNames);
  }
  
  /**
   * @param {Array<?string>} propNames
   * @return {Value}
   * @public
   */
  static m_forIgnoredProperties__arrayOf_java_lang_String(propNames) {
    Value.$clinit();
    if (propNames.length == 0) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    }
    return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.m_withIgnored__java_util_Set(Value.m__asSet__arrayOf_java_lang_String_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(propNames));
  }
  
  /**
   * @param {boolean} state
   * @return {Value}
   * @public
   */
  static m_forIgnoreUnknown__boolean(state) {
    Value.$clinit();
    return state ? Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.m_withIgnoreUnknown__() : Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.m_withoutIgnoreUnknown__();
  }
  
  /**
   * @param {Value} overrides
   * @return {Value}
   * @public
   */
  m_withOverrides__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(overrides) {
    if ($Equality.$same(overrides, null) || $Equality.$same(overrides, Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value)) {
      return this;
    }
    if (!overrides.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) {
      return overrides;
    }
    if (Value.m__equals__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(this, overrides)) {
      return this;
    }
    let ignored = Value.m__merge__java_util_Set__java_util_Set_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, overrides.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
    let ignoreUnknown = this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value || overrides.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    let allowGetters = this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value || overrides.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    let allowSetters = this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value || overrides.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    return Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(ignored, ignoreUnknown, allowGetters, allowSetters, true);
  }
  
  /**
   * @param {Set<?string>} ignored
   * @return {Value}
   * @public
   */
  m_withIgnored__java_util_Set(ignored) {
    return Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(ignored, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @param {Array<?string>} ignored
   * @return {Value}
   * @public
   */
  m_withIgnored__arrayOf_java_lang_String(ignored) {
    return Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(Value.m__asSet__arrayOf_java_lang_String_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(ignored), this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withoutIgnored__() {
    return Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(null, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withIgnoreUnknown__() {
    return this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, true, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withoutIgnoreUnknown__() {
    return !this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, false, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withAllowGetters__() {
    return this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, true, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withoutAllowGetters__() {
    return !this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, false, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withAllowSetters__() {
    return this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, true, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withoutAllowSetters__() {
    return !this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, false, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withMerge__() {
    return this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, true);
  }
  
  /**
   * @return {Value}
   * @public
   */
  m_withoutMerge__() {
    return !this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? this : Value.m_construct__java_util_Set__boolean__boolean__boolean__boolean(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, false);
  }
  
  /**
   * @override
   * @return {Class<JsonIgnoreProperties>}
   * @public
   */
  m_valueFor__() {
    return Class.$get(JsonIgnoreProperties);
  }
  
  /**
   * @return {*}
   * @public
   */
  m_readResolve__() {
    if (Value.m__empty__java_util_Set__boolean__boolean__boolean__boolean_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value)) {
      return Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
    }
    return this;
  }
  
  /**
   * @return {Set<?string>}
   * @public
   */
  m_getIgnored__() {
    return this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @return {Set<?string>}
   * @public
   */
  m_findIgnoredForSerialization__() {
    if (this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) {
      return /**@type {Set<?string>} */ (Collections.m_emptySet__());
    }
    return this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @return {Set<?string>}
   * @public
   */
  m_findIgnoredForDeserialization__() {
    if (this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) {
      return /**@type {Set<?string>} */ (Collections.m_emptySet__());
    }
    return this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_getIgnoreUnknown__() {
    return this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_getAllowGetters__() {
    return this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_getAllowSetters__() {
    return this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_getMerge__() {
    return this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "[" + "ignored=" + j_l_String.m_valueOf__java_lang_Object(this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) + ",ignoreUnknown=" + this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value + ",allowGetters=" + this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value + ",allowSetters=" + this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value + ",merge=" + this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value + "]";
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return this.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.size() + (this.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? 1 : -3) + (this.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? 3 : -7) + (this.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? 7 : -11) + (this.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value ? 11 : -13);
  }
  
  /**
   * @override
   * @param {*} o
   * @return {boolean}
   * @public
   */
  equals(o) {
    if ($Equality.$same(o, this)) {
      return true;
    }
    if ($Equality.$same(o, null)) {
      return false;
    }
    return $Equality.$same($Objects.m_getClass__java_lang_Object(o), this.m_getClass__()) && Value.m__equals__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(this, /**@type {Value} */ ($Casts.$to(o, Value)));
  }
  
  /**
   * @param {Value} a
   * @param {Value} b
   * @return {boolean}
   * @public
   */
  static m__equals__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(a, b) {
    Value.$clinit();
    return (a.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value == b.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && (a.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value == b.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && (a.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value == b.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && (a.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value == b.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && $Objects.m_equals__java_lang_Object__java_lang_Object(a.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value, b.f__ignored__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @param {Array<?string>} v
   * @return {Set<?string>}
   * @public
   */
  static m__asSet__arrayOf_java_lang_String_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(v) {
    Value.$clinit();
    if ($Equality.$same(v, null) || v.length == 0) {
      return /**@type {Set<?string>} */ (Collections.m_emptySet__());
    }
    let s = /**@type {!HashSet<?string>} */ (HashSet.$create__int(v.length));
    for (let $array = v, $index = 0; $index < $array.length; $index++) {
      let str = $array[$index];
      s.add(str);
    }
    return s;
  }
  
  /**
   * @param {Set<?string>} s1
   * @param {Set<?string>} s2
   * @return {Set<?string>}
   * @public
   */
  static m__merge__java_util_Set__java_util_Set_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(s1, s2) {
    Value.$clinit();
    if (s1.isEmpty()) {
      return s2;
    } else if (s2.isEmpty()) {
      return s1;
    }
    let result = /**@type {!HashSet<?string>} */ (HashSet.$create__int(s1.size() + s2.size()));
    result.addAll(s1);
    result.addAll(s2);
    return result;
  }
  
  /**
   * @param {Set<?string>} ignored
   * @param {boolean} ignoreUnknown
   * @param {boolean} allowGetters
   * @param {boolean} allowSetters
   * @param {boolean} merge
   * @return {boolean}
   * @public
   */
  static m__empty__java_util_Set__boolean__boolean__boolean__boolean_$p_com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(ignored, ignoreUnknown, allowGetters, allowSetters, merge) {
    Value.$clinit();
    if ((ignoreUnknown == Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.f__ignoreUnknown__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && (allowGetters == Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.f__allowGetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && (allowSetters == Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.f__allowSetters__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value) && (merge == Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value.f__merge__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value)) {
      return ($Equality.$same(ignored, null) || ignored.size() == 0);
    }
    return false;
  }
  
  /**
   * @return {Value}
   * @public
   */
  static get f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value() {
    return (Value.$clinit(), Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value);
  }
  
  /**
   * @param {Value} value
   * @return {void}
   * @public
   */
  static set f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value(value) {
    (Value.$clinit(), Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Value;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Value);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Value.$clinit = function() {};
    JsonIgnoreProperties = goog.module.get('com.fasterxml.jackson.annotation.JsonIgnoreProperties$impl');
    Class = goog.module.get('java.lang.Class$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Collections = goog.module.get('java.util.Collections$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
    Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value = Value.$create__java_util_Set__boolean__boolean__boolean__boolean(/**@type {Set<?string>} */ (Collections.m_emptySet__()), false, false, false, true);
  }
  
  
};

$Util.$setClassMetadata(Value, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonIgnoreProperties$Value'));


/** @public {!$Long} @const */
Value.f_serialVersionUID__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value_ = $Long.fromInt(1);


/** @private {Value} */
Value.$f_EMPTY__com_fasterxml_jackson_annotation_JsonIgnoreProperties_Value;


JacksonAnnotationValue.$markImplementor(Value);
Serializable.$markImplementor(Value);


exports = Value; 
//# sourceMappingURL=JsonIgnoreProperties$Value.js.map