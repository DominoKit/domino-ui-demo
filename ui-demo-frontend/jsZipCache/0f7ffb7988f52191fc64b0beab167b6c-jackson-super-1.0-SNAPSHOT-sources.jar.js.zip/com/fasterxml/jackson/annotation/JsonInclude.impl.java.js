/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonInclude.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonInclude$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Include = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonInclude {
  /**
   * @abstract
   * @return {Include}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @abstract
   * @return {Include}
   * @public
   */
  m_content__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonInclude = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonInclude;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonInclude;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonInclude.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonInclude, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonInclude'));


JsonInclude.$markImplementor(/** @type {Function} */ (JsonInclude));


exports = JsonInclude; 
//# sourceMappingURL=JsonInclude.js.map