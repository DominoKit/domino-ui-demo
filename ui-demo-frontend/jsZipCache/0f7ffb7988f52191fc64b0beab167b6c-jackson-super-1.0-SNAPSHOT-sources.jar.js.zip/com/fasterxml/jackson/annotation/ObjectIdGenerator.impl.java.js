/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.ObjectIdGenerator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.ObjectIdGenerator$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let IdKey = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @abstract
 * @template C_T
 * @implements {Serializable}
  */
class ObjectIdGenerator extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'ObjectIdGenerator()'.
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_ObjectIdGenerator__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_getScope__() {
  }
  
  /**
   * @abstract
   * @param {ObjectIdGenerator<?>} gen
   * @return {boolean}
   * @public
   */
  m_canUseFor__com_fasterxml_jackson_annotation_ObjectIdGenerator(gen) {
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_maySerializeAsObject__() {
    return false;
  }
  
  /**
   * @param {?string} name
   * @param {*} parser
   * @return {boolean}
   * @public
   */
  m_isValidReferencePropertyName__java_lang_String__java_lang_Object(name, parser) {
    return false;
  }
  
  /**
   * @abstract
   * @param {Class<?>} scope
   * @return {ObjectIdGenerator<C_T>}
   * @public
   */
  m_forScope__java_lang_Class(scope) {
  }
  
  /**
   * @abstract
   * @param {*} context
   * @return {ObjectIdGenerator<C_T>}
   * @public
   */
  m_newForSerialization__java_lang_Object(context) {
  }
  
  /**
   * @abstract
   * @param {*} key
   * @return {IdKey}
   * @public
   */
  m_key__java_lang_Object(key) {
  }
  
  /**
   * @abstract
   * @param {*} forPojo
   * @return {C_T}
   * @public
   */
  m_generateId__java_lang_Object(forPojo) {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ObjectIdGenerator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ObjectIdGenerator);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ObjectIdGenerator.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ObjectIdGenerator, $Util.$makeClassName('com.fasterxml.jackson.annotation.ObjectIdGenerator'));


Serializable.$markImplementor(ObjectIdGenerator);


exports = ObjectIdGenerator; 
//# sourceMappingURL=ObjectIdGenerator.js.map