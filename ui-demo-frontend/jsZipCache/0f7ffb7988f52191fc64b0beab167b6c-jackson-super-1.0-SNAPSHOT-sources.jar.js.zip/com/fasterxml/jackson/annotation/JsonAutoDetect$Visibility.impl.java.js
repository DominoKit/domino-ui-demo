/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonAutoDetect$Visibility.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Visibility>}
  */
class Visibility extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Visibility(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Visibility}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Visibility();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Visibility(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Visibility}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Visibility.$clinit();
    if ($Equality.$same(Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_, null)) {
      Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_ = $Enums.createMapFromValues(Visibility.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_);
  }
  
  /**
   * @return {!Array<!Visibility>}
   * @public
   */
  static m_values__() {
    Visibility.$clinit();
    return /**@type {!Array<Visibility>} */ ($Arrays.$init([Visibility.$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility, Visibility.$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility, Visibility.$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility, Visibility.$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility, Visibility.$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility, Visibility.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility], Visibility));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Visibility} */ ($Casts.$to(arg0, Visibility)));
  }
  
  /**
   * @return {!Visibility}
   * @public
   */
  static get f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility() {
    return (Visibility.$clinit(), Visibility.$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
  }
  
  /**
   * @param {!Visibility} value
   * @return {void}
   * @public
   */
  static set f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility(value) {
    (Visibility.$clinit(), Visibility.$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = value);
  }
  
  /**
   * @return {!Visibility}
   * @public
   */
  static get f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility() {
    return (Visibility.$clinit(), Visibility.$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
  }
  
  /**
   * @param {!Visibility} value
   * @return {void}
   * @public
   */
  static set f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility(value) {
    (Visibility.$clinit(), Visibility.$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = value);
  }
  
  /**
   * @return {!Visibility}
   * @public
   */
  static get f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility() {
    return (Visibility.$clinit(), Visibility.$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
  }
  
  /**
   * @param {!Visibility} value
   * @return {void}
   * @public
   */
  static set f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility(value) {
    (Visibility.$clinit(), Visibility.$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = value);
  }
  
  /**
   * @return {!Visibility}
   * @public
   */
  static get f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility() {
    return (Visibility.$clinit(), Visibility.$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
  }
  
  /**
   * @param {!Visibility} value
   * @return {void}
   * @public
   */
  static set f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility(value) {
    (Visibility.$clinit(), Visibility.$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = value);
  }
  
  /**
   * @return {!Visibility}
   * @public
   */
  static get f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility() {
    return (Visibility.$clinit(), Visibility.$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
  }
  
  /**
   * @param {!Visibility} value
   * @return {void}
   * @public
   */
  static set f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility(value) {
    (Visibility.$clinit(), Visibility.$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = value);
  }
  
  /**
   * @return {!Visibility}
   * @public
   */
  static get f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility() {
    return (Visibility.$clinit(), Visibility.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
  }
  
  /**
   * @param {!Visibility} value
   * @return {void}
   * @public
   */
  static set f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility(value) {
    (Visibility.$clinit(), Visibility.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = value);
  }
  
  /**
   * @return {Map<?string, !Visibility>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_() {
    return (Visibility.$clinit(), Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_);
  }
  
  /**
   * @param {Map<?string, !Visibility>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_(value) {
    (Visibility.$clinit(), Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Visibility;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Visibility);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Visibility.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Visibility.$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = Visibility.$create__java_lang_String__int($Util.$makeEnumName("ANY"), Visibility.$ordinal$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
    Visibility.$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = Visibility.$create__java_lang_String__int($Util.$makeEnumName("NON_PRIVATE"), Visibility.$ordinal$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
    Visibility.$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = Visibility.$create__java_lang_String__int($Util.$makeEnumName("PROTECTED_AND_PUBLIC"), Visibility.$ordinal$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
    Visibility.$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = Visibility.$create__java_lang_String__int($Util.$makeEnumName("PUBLIC_ONLY"), Visibility.$ordinal$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
    Visibility.$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = Visibility.$create__java_lang_String__int($Util.$makeEnumName("NONE"), Visibility.$ordinal$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
    Visibility.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = Visibility.$create__java_lang_String__int($Util.$makeEnumName("DEFAULT"), Visibility.$ordinal$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility);
    Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Visibility, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonAutoDetect$Visibility'));


/** @private {!Visibility} */
Visibility.$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility;


/** @private {!Visibility} */
Visibility.$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility;


/** @private {!Visibility} */
Visibility.$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility;


/** @private {!Visibility} */
Visibility.$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility;


/** @private {!Visibility} */
Visibility.$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility;


/** @private {!Visibility} */
Visibility.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility;


/** @private {Map<?string, !Visibility>} */
Visibility.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility_;


/** @public {number} @const */
Visibility.$ordinal$f_ANY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = 0;


/** @public {number} @const */
Visibility.$ordinal$f_NON_PRIVATE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = 1;


/** @public {number} @const */
Visibility.$ordinal$f_PROTECTED_AND_PUBLIC__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = 2;


/** @public {number} @const */
Visibility.$ordinal$f_PUBLIC_ONLY__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = 3;


/** @public {number} @const */
Visibility.$ordinal$f_NONE__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = 4;


/** @public {number} @const */
Visibility.$ordinal$f_DEFAULT__com_fasterxml_jackson_annotation_JsonAutoDetect_Visibility = 5;




exports = Visibility; 
//# sourceMappingURL=JsonAutoDetect$Visibility.js.map