/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonCreator$Mode.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonCreator.Mode$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Mode>}
  */
class Mode extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Mode(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Mode}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Mode();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonCreator_Mode__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Mode(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonCreator_Mode__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Mode}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Mode.$clinit();
    if ($Equality.$same(Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_, null)) {
      Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_ = $Enums.createMapFromValues(Mode.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_);
  }
  
  /**
   * @return {!Array<!Mode>}
   * @public
   */
  static m_values__() {
    Mode.$clinit();
    return /**@type {!Array<Mode>} */ ($Arrays.$init([Mode.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode, Mode.$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode, Mode.$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode, Mode.$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode], Mode));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Mode} */ ($Casts.$to(arg0, Mode)));
  }
  
  /**
   * @return {!Mode}
   * @public
   */
  static get f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode() {
    return (Mode.$clinit(), Mode.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode);
  }
  
  /**
   * @param {!Mode} value
   * @return {void}
   * @public
   */
  static set f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode(value) {
    (Mode.$clinit(), Mode.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode = value);
  }
  
  /**
   * @return {!Mode}
   * @public
   */
  static get f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode() {
    return (Mode.$clinit(), Mode.$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode);
  }
  
  /**
   * @param {!Mode} value
   * @return {void}
   * @public
   */
  static set f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode(value) {
    (Mode.$clinit(), Mode.$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode = value);
  }
  
  /**
   * @return {!Mode}
   * @public
   */
  static get f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode() {
    return (Mode.$clinit(), Mode.$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode);
  }
  
  /**
   * @param {!Mode} value
   * @return {void}
   * @public
   */
  static set f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode(value) {
    (Mode.$clinit(), Mode.$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode = value);
  }
  
  /**
   * @return {!Mode}
   * @public
   */
  static get f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode() {
    return (Mode.$clinit(), Mode.$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode);
  }
  
  /**
   * @param {!Mode} value
   * @return {void}
   * @public
   */
  static set f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode(value) {
    (Mode.$clinit(), Mode.$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode = value);
  }
  
  /**
   * @return {Map<?string, !Mode>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_() {
    return (Mode.$clinit(), Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_);
  }
  
  /**
   * @param {Map<?string, !Mode>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_(value) {
    (Mode.$clinit(), Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Mode;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Mode);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Mode.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Mode.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode = Mode.$create__java_lang_String__int($Util.$makeEnumName("DEFAULT"), Mode.$ordinal$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode);
    Mode.$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode = Mode.$create__java_lang_String__int($Util.$makeEnumName("DELEGATING"), Mode.$ordinal$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode);
    Mode.$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode = Mode.$create__java_lang_String__int($Util.$makeEnumName("PROPERTIES"), Mode.$ordinal$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode);
    Mode.$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode = Mode.$create__java_lang_String__int($Util.$makeEnumName("DISABLED"), Mode.$ordinal$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode);
    Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Mode, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonCreator$Mode'));


/** @private {!Mode} */
Mode.$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode;


/** @private {!Mode} */
Mode.$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode;


/** @private {!Mode} */
Mode.$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode;


/** @private {!Mode} */
Mode.$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode;


/** @private {Map<?string, !Mode>} */
Mode.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonCreator_Mode_;


/** @public {number} @const */
Mode.$ordinal$f_DEFAULT__com_fasterxml_jackson_annotation_JsonCreator_Mode = 0;


/** @public {number} @const */
Mode.$ordinal$f_DELEGATING__com_fasterxml_jackson_annotation_JsonCreator_Mode = 1;


/** @public {number} @const */
Mode.$ordinal$f_PROPERTIES__com_fasterxml_jackson_annotation_JsonCreator_Mode = 2;


/** @public {number} @const */
Mode.$ordinal$f_DISABLED__com_fasterxml_jackson_annotation_JsonCreator_Mode = 3;




exports = Mode; 
//# sourceMappingURL=JsonCreator$Mode.js.map