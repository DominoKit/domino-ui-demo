/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonIdentityInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonIdentityInfo$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ObjectIdGenerator = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdGenerator$impl');
let ObjectIdResolver = goog.forwardDeclare('com.fasterxml.jackson.annotation.ObjectIdResolver$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonIdentityInfo {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_property__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_generator__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_resolver__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_scope__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonIdentityInfo = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonIdentityInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonIdentityInfo;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonIdentityInfo.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonIdentityInfo, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonIdentityInfo'));


JsonIdentityInfo.$markImplementor(/** @type {Function} */ (JsonIdentityInfo));


exports = JsonIdentityInfo; 
//# sourceMappingURL=JsonIdentityInfo.js.map