/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.ObjectIdGenerator$IdKey.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {Serializable}
  */
class IdKey extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Class<?>} */
    this.f_type__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey;
    /** @public {Class<?>} */
    this.f_scope__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey;
    /** @public {*} */
    this.f_key__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey;
    /** @public {number} */
    this.f_hashCode__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey_ = 0;
  }
  
  /**
   * Factory method corresponding to constructor 'IdKey(Class, Class, Object)'.
   * @param {Class<?>} type
   * @param {Class<?>} scope
   * @param {*} key
   * @return {!IdKey}
   * @public
   */
  static $create__java_lang_Class__java_lang_Class__java_lang_Object(type, scope, key) {
    IdKey.$clinit();
    let $instance = new IdKey();
    $instance.$ctor__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Class__java_lang_Class__java_lang_Object(type, scope, key);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IdKey(Class, Class, Object)'.
   * @param {Class<?>} type
   * @param {Class<?>} scope
   * @param {*} key
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey__java_lang_Class__java_lang_Class__java_lang_Object(type, scope, key) {
    this.$ctor__java_lang_Object__();
    if ($Equality.$same(key, null)) {
      throw $Exceptions.toJs(IllegalArgumentException.$create__java_lang_String("Can not construct IdKey for null key"));
    }
    this.f_type__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey = type;
    this.f_scope__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey = scope;
    this.f_key__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey = key;
    let h = $Objects.m_hashCode__java_lang_Object(key) + j_l_String.m_hashCode__java_lang_String(type.m_getName__());
    if (!$Equality.$same(scope, null)) {
      h ^= j_l_String.m_hashCode__java_lang_String(scope.m_getName__());
    }
    this.f_hashCode__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey_ = h;
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return this.f_hashCode__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey_;
  }
  
  /**
   * @override
   * @param {*} o
   * @return {boolean}
   * @public
   */
  equals(o) {
    if ($Equality.$same(o, this)) {
      return true;
    }
    if ($Equality.$same(o, null)) {
      return false;
    }
    if (!$Equality.$same($Objects.m_getClass__java_lang_Object(o), this.m_getClass__())) {
      return false;
    }
    let other = /**@type {IdKey} */ ($Casts.$to(o, IdKey));
    return $Objects.m_equals__java_lang_Object__java_lang_Object(other.f_key__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey, this.f_key__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey) && $Equality.$same(other.f_type__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey, this.f_type__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey) && $Equality.$same(other.f_scope__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey, this.f_scope__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey);
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "[ObjectId: key=" + j_l_String.m_valueOf__java_lang_Object(this.f_key__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey) + ", type=" + j_l_String.m_valueOf__java_lang_Object(($Equality.$same(this.f_type__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey, null) ? "NONE" : this.f_type__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey.m_getName__())) + ", scope=" + j_l_String.m_valueOf__java_lang_Object(($Equality.$same(this.f_scope__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey, null) ? "NONE" : this.f_scope__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey.m_getName__())) + "]";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IdKey;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IdKey);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IdKey.$clinit = function() {};
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IdKey, $Util.$makeClassName('com.fasterxml.jackson.annotation.ObjectIdGenerator$IdKey'));


/** @public {!$Long} @const */
IdKey.f_serialVersionUID__com_fasterxml_jackson_annotation_ObjectIdGenerator_IdKey_ = $Long.fromInt(1);


Serializable.$markImplementor(IdKey);


exports = IdKey; 
//# sourceMappingURL=ObjectIdGenerator$IdKey.js.map