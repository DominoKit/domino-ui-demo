/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JacksonAnnotationValue.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JacksonAnnotationValue$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('com.fasterxml.jackson.annotation.JacksonAnnotationValue.$LambdaAdaptor$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let Annotation = goog.forwardDeclare('java.lang.annotation.Annotation$impl');


/**
 * @interface
 * @template C_A
 */
class JacksonAnnotationValue {
  /**
   * @abstract
   * @return {Class<C_A>}
   * @public
   */
  m_valueFor__() {
  }
  
  /**
   * @template C_A
   * @param {?function():Class<C_A>} fn
   * @return {JacksonAnnotationValue<C_A>}
   * @public
   */
  static $adapt(fn) {
    JacksonAnnotationValue.$clinit();
    return /**@type {!$LambdaAdaptor<Annotation>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JacksonAnnotationValue = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JacksonAnnotationValue;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JacksonAnnotationValue;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JacksonAnnotationValue.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('com.fasterxml.jackson.annotation.JacksonAnnotationValue.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(JacksonAnnotationValue, $Util.$makeClassName('com.fasterxml.jackson.annotation.JacksonAnnotationValue'));


JacksonAnnotationValue.$markImplementor(/** @type {Function} */ (JacksonAnnotationValue));


exports = JacksonAnnotationValue; 
//# sourceMappingURL=JacksonAnnotationValue.js.map