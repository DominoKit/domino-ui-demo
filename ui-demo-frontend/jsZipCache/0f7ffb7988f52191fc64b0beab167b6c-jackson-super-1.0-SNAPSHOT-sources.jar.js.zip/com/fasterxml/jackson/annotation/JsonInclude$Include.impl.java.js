/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonInclude$Include.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonInclude.Include$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Include>}
  */
class Include extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Include(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Include}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Include();
    $instance.$ctor__com_fasterxml_jackson_annotation_JsonInclude_Include__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Include(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__com_fasterxml_jackson_annotation_JsonInclude_Include__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Include}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Include.$clinit();
    if ($Equality.$same(Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_, null)) {
      Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_ = $Enums.createMapFromValues(Include.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_);
  }
  
  /**
   * @return {!Array<!Include>}
   * @public
   */
  static m_values__() {
    Include.$clinit();
    return /**@type {!Array<Include>} */ ($Arrays.$init([Include.$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include, Include.$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include, Include.$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include, Include.$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include, Include.$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include, Include.$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include], Include));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Include} */ ($Casts.$to(arg0, Include)));
  }
  
  /**
   * @return {!Include}
   * @public
   */
  static get f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include() {
    return (Include.$clinit(), Include.$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  /**
   * @param {!Include} value
   * @return {void}
   * @public
   */
  static set f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include(value) {
    (Include.$clinit(), Include.$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include = value);
  }
  
  /**
   * @return {!Include}
   * @public
   */
  static get f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include() {
    return (Include.$clinit(), Include.$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  /**
   * @param {!Include} value
   * @return {void}
   * @public
   */
  static set f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include(value) {
    (Include.$clinit(), Include.$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include = value);
  }
  
  /**
   * @return {!Include}
   * @public
   */
  static get f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include() {
    return (Include.$clinit(), Include.$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  /**
   * @param {!Include} value
   * @return {void}
   * @public
   */
  static set f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include(value) {
    (Include.$clinit(), Include.$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include = value);
  }
  
  /**
   * @return {!Include}
   * @public
   */
  static get f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include() {
    return (Include.$clinit(), Include.$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  /**
   * @param {!Include} value
   * @return {void}
   * @public
   */
  static set f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include(value) {
    (Include.$clinit(), Include.$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include = value);
  }
  
  /**
   * @return {!Include}
   * @public
   */
  static get f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include() {
    return (Include.$clinit(), Include.$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  /**
   * @param {!Include} value
   * @return {void}
   * @public
   */
  static set f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include(value) {
    (Include.$clinit(), Include.$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include = value);
  }
  
  /**
   * @return {!Include}
   * @public
   */
  static get f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include() {
    return (Include.$clinit(), Include.$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include);
  }
  
  /**
   * @param {!Include} value
   * @return {void}
   * @public
   */
  static set f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include(value) {
    (Include.$clinit(), Include.$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include = value);
  }
  
  /**
   * @return {Map<?string, !Include>}
   * @public
   */
  static get f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_() {
    return (Include.$clinit(), Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_);
  }
  
  /**
   * @param {Map<?string, !Include>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_(value) {
    (Include.$clinit(), Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Include;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Include);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Include.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Include.$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include = Include.$create__java_lang_String__int($Util.$makeEnumName("ALWAYS"), Include.$ordinal$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include);
    Include.$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include = Include.$create__java_lang_String__int($Util.$makeEnumName("NON_NULL"), Include.$ordinal$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include);
    Include.$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include = Include.$create__java_lang_String__int($Util.$makeEnumName("NON_ABSENT"), Include.$ordinal$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include);
    Include.$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include = Include.$create__java_lang_String__int($Util.$makeEnumName("NON_EMPTY"), Include.$ordinal$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include);
    Include.$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include = Include.$create__java_lang_String__int($Util.$makeEnumName("NON_DEFAULT"), Include.$ordinal$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include);
    Include.$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include = Include.$create__java_lang_String__int($Util.$makeEnumName("USE_DEFAULTS"), Include.$ordinal$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include);
    Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Include, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonInclude$Include'));


/** @private {!Include} */
Include.$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include;


/** @private {!Include} */
Include.$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include;


/** @private {!Include} */
Include.$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include;


/** @private {!Include} */
Include.$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include;


/** @private {!Include} */
Include.$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include;


/** @private {!Include} */
Include.$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include;


/** @private {Map<?string, !Include>} */
Include.$f_namesToValuesMap__com_fasterxml_jackson_annotation_JsonInclude_Include_;


/** @public {number} @const */
Include.$ordinal$f_ALWAYS__com_fasterxml_jackson_annotation_JsonInclude_Include = 0;


/** @public {number} @const */
Include.$ordinal$f_NON_NULL__com_fasterxml_jackson_annotation_JsonInclude_Include = 1;


/** @public {number} @const */
Include.$ordinal$f_NON_ABSENT__com_fasterxml_jackson_annotation_JsonInclude_Include = 2;


/** @public {number} @const */
Include.$ordinal$f_NON_EMPTY__com_fasterxml_jackson_annotation_JsonInclude_Include = 3;


/** @public {number} @const */
Include.$ordinal$f_NON_DEFAULT__com_fasterxml_jackson_annotation_JsonInclude_Include = 4;


/** @public {number} @const */
Include.$ordinal$f_USE_DEFAULTS__com_fasterxml_jackson_annotation_JsonInclude_Include = 5;




exports = Include; 
//# sourceMappingURL=JsonInclude$Include.js.map