/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonCreator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonCreator$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Mode = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonCreator.Mode$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonCreator {
  /**
   * @abstract
   * @return {Mode}
   * @public
   */
  m_mode__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonCreator = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonCreator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonCreator;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonCreator.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonCreator, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonCreator'));


JsonCreator.$markImplementor(/** @type {Function} */ (JsonCreator));


exports = JsonCreator; 
//# sourceMappingURL=JsonCreator.js.map