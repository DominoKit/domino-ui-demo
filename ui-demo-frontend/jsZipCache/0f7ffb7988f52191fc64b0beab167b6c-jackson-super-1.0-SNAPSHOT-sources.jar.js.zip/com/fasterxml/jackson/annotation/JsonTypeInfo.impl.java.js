/**
 * @fileoverview transpiled from com.fasterxml.jackson.annotation.JsonTypeInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.fasterxml.jackson.annotation.JsonTypeInfo$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let As = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonTypeInfo.As$impl');
let Id = goog.forwardDeclare('com.fasterxml.jackson.annotation.JsonTypeInfo.Id$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class JsonTypeInfo {
  /**
   * @abstract
   * @return {Id}
   * @public
   */
  m_use__() {
  }
  
  /**
   * @abstract
   * @return {As}
   * @public
   */
  m_include__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_property__() {
  }
  
  /**
   * @abstract
   * @return {Class<?>}
   * @public
   */
  m_defaultImpl__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_visible__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonTypeInfo = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_fasterxml_jackson_annotation_JsonTypeInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_fasterxml_jackson_annotation_JsonTypeInfo;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsonTypeInfo.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(JsonTypeInfo, $Util.$makeClassName('com.fasterxml.jackson.annotation.JsonTypeInfo'));


JsonTypeInfo.$markImplementor(/** @type {Function} */ (JsonTypeInfo));


exports = JsonTypeInfo; 
//# sourceMappingURL=JsonTypeInfo.js.map