/**
 * @fileoverview transpiled from java.util.UUID.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('java.util.UUID');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _Comparable = goog.require('java.lang.Comparable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');
const _$Primitives = goog.require('vmbootstrap.Primitives');
const _$char = goog.require('vmbootstrap.primitives.$char');


// Re-exports the implementation.
var UUID = goog.require('java.util.UUID$impl');
exports = UUID;
 