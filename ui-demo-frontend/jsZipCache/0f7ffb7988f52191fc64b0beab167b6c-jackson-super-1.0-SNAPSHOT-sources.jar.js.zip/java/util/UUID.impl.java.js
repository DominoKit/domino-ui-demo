/**
 * @fileoverview transpiled from java.util.UUID.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('java.util.UUID$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const Comparable = goog.require('java.lang.Comparable$impl');
const j_l_Object = goog.require('java.lang.Object$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');
let $char = goog.forwardDeclare('vmbootstrap.primitives.$char$impl');


/**
 * @implements {Serializable}
 * @implements {Comparable<UUID>}
  */
class UUID extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_value__java_util_UUID_;
  }
  
  /**
   * Factory method corresponding to constructor 'UUID()'.
   * @return {!UUID}
   * @public
   */
  static $create__() {
    UUID.$clinit();
    let $instance = new UUID();
    $instance.$ctor__java_util_UUID__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'UUID()'.
   * @return {void}
   * @public
   */
  $ctor__java_util_UUID__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} uuidString
   * @return {UUID}
   * @public
   */
  static m_fromString__java_lang_String(uuidString) {
    UUID.$clinit();
    let uuid = UUID.$create__();
    uuid.f_value__java_util_UUID_ = uuidString;
    return uuid;
  }
  
  /**
   * @return {UUID}
   * @public
   */
  static m_randomUUID__() {
    UUID.$clinit();
    return UUID.m_fromString__java_lang_String(UUID.m_generateUUIDString___$p_java_util_UUID());
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_generateUUIDString___$p_java_util_UUID() {
    UUID.$clinit();
    let uuid = /**@type {!Array<number>} */ ($Arrays.$create([36], $char));
    let /** number */ r;
    $Arrays.$set(uuid, 8, $Arrays.$set(uuid, 13, $Arrays.$set(uuid, 18, $Arrays.$set(uuid, 23, 45 /* '-' */))));
    $Arrays.$set(uuid, 14, 52 /* '4' */);
    for (let i = 0; i < 36; i++) {
      if (uuid[i] == 0) {
        r = $Primitives.$narrowDoubleToInt((Math.random() * 16));
        $Arrays.$set(uuid, i, UUID.$f_CHARS__java_util_UUID_[(i == 19) ? (r & 3) | 8 : r & 15]);
      }
    }
    return j_l_String.$create__arrayOf_char(uuid);
  }
  
  /**
   * @param {UUID} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_util_UUID(arg0) {
    return j_l_String.m_compareTo__java_lang_String__java_lang_String(this.f_value__java_util_UUID_, arg0.f_value__java_util_UUID_);
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    let prime = 31;
    let result = 1;
    result = prime * result + ($Equality.$same(this.f_value__java_util_UUID_, null) ? 0 : j_l_String.m_hashCode__java_lang_String(this.f_value__java_util_UUID_));
    return result;
  }
  
  /**
   * @override
   * @param {*} obj
   * @return {boolean}
   * @public
   */
  equals(obj) {
    if ($Equality.$same(this, obj)) {
      return true;
    }
    if ($Equality.$same(obj, null)) {
      return false;
    }
    if (!$Equality.$same(this.m_getClass__(), $Objects.m_getClass__java_lang_Object(obj))) {
      return false;
    }
    let other = /**@type {UUID} */ ($Casts.$to(obj, UUID));
    if ($Equality.$same(this.f_value__java_util_UUID_, null)) {
      if (!$Equality.$same(other.f_value__java_util_UUID_, null)) {
        return false;
      }
    } else if (!j_l_String.m_equals__java_lang_String__java_lang_Object(this.f_value__java_util_UUID_, other.f_value__java_util_UUID_)) {
      return false;
    }
    return true;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return this.f_value__java_util_UUID_;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return this.m_compareTo__java_util_UUID(/**@type {UUID} */ ($Casts.$to(arg0, UUID)));
  }
  
  /**
   * @return {Array<number>}
   * @public
   */
  static get f_CHARS__java_util_UUID_() {
    return (UUID.$clinit(), UUID.$f_CHARS__java_util_UUID_);
  }
  
  /**
   * @param {Array<number>} value
   * @return {void}
   * @public
   */
  static set f_CHARS__java_util_UUID_(value) {
    (UUID.$clinit(), UUID.$f_CHARS__java_util_UUID_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof UUID;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, UUID);
  }
  
  /**
   * @public
   */
  static $clinit() {
    UUID.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    $char = goog.module.get('vmbootstrap.primitives.$char$impl');
    j_l_Object.$clinit();
    UUID.$f_CHARS__java_util_UUID_ = j_l_String.m_toCharArray__java_lang_String("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
  }
  
  
};

$Util.$setClassMetadata(UUID, $Util.$makeClassName('java.util.UUID'));


/** @public {!$Long} @const */
UUID.f_serialVersionUID__java_util_UUID_ = $Long.fromBits(-173416031, 1716740831) /* 7373345728974414241 */;


/** @private {Array<number>} */
UUID.$f_CHARS__java_util_UUID_;


Serializable.$markImplementor(UUID);
Comparable.$markImplementor(UUID);


exports = UUID; 
//# sourceMappingURL=UUID.js.map