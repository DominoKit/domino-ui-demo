/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');

let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let InfoBoxModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration$impl');
let InfoBoxPresenter = goog.forwardDeclare('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter$impl');


class $1 extends LazyPresenterLoader {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {InfoBoxModuleConfiguration} */
    this.f_$outer_this__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new LazyPresenterLoader(InfoBoxModuleConfiguration, String, String)'.
   * @param {InfoBoxModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @param {?string} $_1
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration_1__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new LazyPresenterLoader(InfoBoxModuleConfiguration, String, String)'.
   * @param {InfoBoxModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @param {?string} $_1
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration_1__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration__java_lang_String__java_lang_String($outer_this, $_0, $_1) {
    this.f_$outer_this__org_dominokit_domino_infobox_client_InfoBoxModuleConfiguration_1 = $outer_this;
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader__java_lang_String__java_lang_String($_0, $_1);
  }
  
  /**
   * @override
   * @return {Presentable}
   * @public
   */
  m_make__() {
    return InfoBoxPresenter.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    InfoBoxPresenter = goog.module.get('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter$impl');
    LazyPresenterLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration$1'));




exports = $1; 
//# sourceMappingURL=InfoBoxModuleConfiguration$1.js.map