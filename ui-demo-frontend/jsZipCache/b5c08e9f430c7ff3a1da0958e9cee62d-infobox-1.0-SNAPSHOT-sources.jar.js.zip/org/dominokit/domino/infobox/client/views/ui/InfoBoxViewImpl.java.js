/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.views.ui.InfoBoxViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.infobox.client.views.ui.InfoBoxViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _InfoBoxView = goog.require('org.dominokit.domino.infobox.client.views.InfoBoxView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _CodeResource = goog.require('org.dominokit.domino.infobox.client.views.CodeResource');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _Counter = goog.require('org.dominokit.domino.ui.counter.Counter');
const _CountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.CountHandler');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _InfoBox = goog.require('org.dominokit.domino.ui.infoboxes.InfoBox');
const _HoverEffect = goog.require('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var InfoBoxViewImpl = goog.require('org.dominokit.domino.infobox.client.views.ui.InfoBoxViewImpl$impl');
exports = InfoBoxViewImpl;
 