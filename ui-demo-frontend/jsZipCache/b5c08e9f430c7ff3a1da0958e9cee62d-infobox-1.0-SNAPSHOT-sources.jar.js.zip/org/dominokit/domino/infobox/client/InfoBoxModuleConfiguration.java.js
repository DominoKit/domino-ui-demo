/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentsExtensionPoint = goog.require('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint');
const _$1 = goog.require('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration.$2');
const _InfoBoxPresenterContributionToComponentsExtensionPoint = goog.require('org.dominokit.domino.infobox.client.contributions.InfoBoxPresenterContributionToComponentsExtensionPoint');
const _InfoBoxPresenter = goog.require('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter');
const _InfoBoxPresenterCommand = goog.require('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenterCommand');


// Re-exports the implementation.
var InfoBoxModuleConfiguration = goog.require('org.dominokit.domino.infobox.client.InfoBoxModuleConfiguration$impl');
exports = InfoBoxModuleConfiguration;
 