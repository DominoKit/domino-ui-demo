/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.views.InfoBoxView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.infobox.client.views.InfoBoxView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView');


// Re-exports the implementation.
var InfoBoxView = goog.require('org.dominokit.domino.infobox.client.views.InfoBoxView$impl');
exports = InfoBoxView;
 