/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.presenters.InfoBoxPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let InfoBoxPresenter = goog.forwardDeclare('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenter$impl');


/**
 * @extends {PresenterCommand<InfoBoxPresenter>}
  */
class InfoBoxPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'InfoBoxPresenterCommand()'.
   * @return {!InfoBoxPresenterCommand}
   * @public
   */
  static $create__() {
    InfoBoxPresenterCommand.$clinit();
    let $instance = new InfoBoxPresenterCommand();
    $instance.$ctor__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InfoBoxPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_infobox_client_presenters_InfoBoxPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InfoBoxPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InfoBoxPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InfoBoxPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InfoBoxPresenterCommand, $Util.$makeClassName('org.dominokit.domino.infobox.client.presenters.InfoBoxPresenterCommand'));




exports = InfoBoxPresenterCommand; 
//# sourceMappingURL=InfoBoxPresenterCommand.js.map