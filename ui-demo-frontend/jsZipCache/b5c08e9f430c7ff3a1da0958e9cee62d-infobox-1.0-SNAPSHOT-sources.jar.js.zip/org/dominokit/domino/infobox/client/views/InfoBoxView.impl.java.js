/**
 * @fileoverview transpiled from org.dominokit.domino.infobox.client.views.InfoBoxView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.infobox.client.views.InfoBoxView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class InfoBoxView {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_restartCounters__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_infobox_client_views_InfoBoxView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_infobox_client_views_InfoBoxView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_infobox_client_views_InfoBoxView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    InfoBoxView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(InfoBoxView, $Util.$makeClassName('org.dominokit.domino.infobox.client.views.InfoBoxView'));


InfoBoxView.$markImplementor(/** @type {Function} */ (InfoBoxView));


exports = InfoBoxView; 
//# sourceMappingURL=InfoBoxView.js.map