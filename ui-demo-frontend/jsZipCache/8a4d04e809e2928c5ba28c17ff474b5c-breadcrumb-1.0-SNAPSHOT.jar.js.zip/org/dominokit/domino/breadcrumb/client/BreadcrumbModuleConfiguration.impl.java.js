/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration.$2$impl');
let BreadcrumbPresenterListenerForComponentsEvent = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.listeners.BreadcrumbPresenterListenerForComponentsEvent$impl');
let BreadcrumbPresenter = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter$impl');
let BreadcrumbPresenterCommand = goog.forwardDeclare('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenterCommand$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');


/**
 * @implements {ModuleConfiguration}
  */
class BreadcrumbModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbModuleConfiguration()'.
   * @return {!BreadcrumbModuleConfiguration}
   * @public
   */
  static $create__() {
    BreadcrumbModuleConfiguration.$clinit();
    let $instance = new BreadcrumbModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_breadcrumb_client_BreadcrumbModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_breadcrumb_client_BreadcrumbModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_breadcrumb_client_BreadcrumbModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(BreadcrumbPresenter).m_getCanonicalName__(), Class.$get(BreadcrumbPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_breadcrumb_client_BreadcrumbModuleConfiguration__java_lang_String(this, Class.$get(BreadcrumbPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(BreadcrumbPresenterCommand).m_getCanonicalName__(), Class.$get(BreadcrumbPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentsEvent), BreadcrumbPresenterListenerForComponentsEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BreadcrumbModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BreadcrumbModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BreadcrumbModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration.$2$impl');
    BreadcrumbPresenterListenerForComponentsEvent = goog.module.get('org.dominokit.domino.breadcrumb.client.listeners.BreadcrumbPresenterListenerForComponentsEvent$impl');
    BreadcrumbPresenter = goog.module.get('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter$impl');
    BreadcrumbPresenterCommand = goog.module.get('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenterCommand$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BreadcrumbModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.breadcrumb.client.BreadcrumbModuleConfiguration'));


ModuleConfiguration.$markImplementor(BreadcrumbModuleConfiguration);


exports = BreadcrumbModuleConfiguration; 
//# sourceMappingURL=BreadcrumbModuleConfiguration.js.map