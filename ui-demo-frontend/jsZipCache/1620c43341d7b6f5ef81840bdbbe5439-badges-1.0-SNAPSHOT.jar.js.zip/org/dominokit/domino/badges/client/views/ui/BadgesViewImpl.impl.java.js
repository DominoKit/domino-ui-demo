/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.views.ui.BadgesViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.badges.client.views.ui.BadgesViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BadgesView = goog.require('org.dominokit.domino.badges.client.views.BadgesView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {BadgesView}
  */
class BadgesViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'BadgesViewImpl()'.
   * @return {!BadgesViewImpl}
   * @public
   */
  static $create__() {
    BadgesViewImpl.$clinit();
    let $instance = new BadgesViewImpl();
    $instance.$ctor__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BadgesViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(BadgesViewImpl.f_MODULE_NAME__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("BADGES").m_asElement__());
    this.m_buttonExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
    this.m_buttonExamplesWithMaterialDesignColors___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
    this.m_listExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_buttonExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(Card.m_create__java_lang_String("BUTTON EXAMPLES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createSuccess__java_lang_String("SUCCESS ").m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("4"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createPrimary__java_lang_String("PRIMARY").m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("10+"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createDanger__java_lang_String("DANGER").m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("8"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createWarning__java_lang_String("WARNING").m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("3"))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BadgesViewImpl.f_MODULE_NAME__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl, "buttonExample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_buttonExamplesWithMaterialDesignColors___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(Card.m_create__java_lang_String("BUTTON EXAMPLES WITH MATERIAL DESIGN COLORS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("2"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("BLUE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("10+"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("RED").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("13"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("ORANGE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("5"))), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("PINK").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("14"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("CYAN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("99+"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("TEAL").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("26"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color), Button)).m_large__(), Button)).m_block__(), Button)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("47"))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BadgesViewImpl.f_MODULE_NAME__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl, "buttonExamplesWithMaterialDesignColors").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_listExample___$p_org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    let listGroup = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Cras justo odio").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("14 new").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color));
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Dapibus ac facilisis in").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("99 unread").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color));
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Morbi leo risus").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("99+").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color));
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Porta ac consectetur ac").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("21").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color));
    listGroup.m_addItem__java_lang_Object("SomeValue").m_setText__java_lang_String("Vestibulum at eros").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Badge.m_create__java_lang_String("18").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color));
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("LIST EXAMPLE", "You can also put badge to list and use the material design colors.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(listGroup).m_asElement__());
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(BadgesViewImpl.f_MODULE_NAME__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl, "listExample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl() {
    this.f_element__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BadgesViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BadgesViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BadgesViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ListGroup = goog.module.get('org.dominokit.domino.ui.lists.ListGroup$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BadgesViewImpl, $Util.$makeClassName('org.dominokit.domino.badges.client.views.ui.BadgesViewImpl'));


/** @public {?string} @const */
BadgesViewImpl.f_MODULE_NAME__org_dominokit_domino_badges_client_views_ui_BadgesViewImpl = "badges";


BadgesView.$markImplementor(BadgesViewImpl);


exports = BadgesViewImpl; 
//# sourceMappingURL=BadgesViewImpl.js.map