/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.BadgesModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.badges.client.BadgesModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _$1 = goog.require('org.dominokit.domino.badges.client.BadgesModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.badges.client.BadgesModuleConfiguration.$2');
const _BadgesPresenterListenerForComponentsEvent = goog.require('org.dominokit.domino.badges.client.listeners.BadgesPresenterListenerForComponentsEvent');
const _BadgesPresenter = goog.require('org.dominokit.domino.badges.client.presenters.BadgesPresenter');
const _BadgesPresenterCommand = goog.require('org.dominokit.domino.badges.client.presenters.BadgesPresenterCommand');
const _ComponentsEvent = goog.require('org.dominokit.domino.components.shared.extension.ComponentsEvent');


// Re-exports the implementation.
var BadgesModuleConfiguration = goog.require('org.dominokit.domino.badges.client.BadgesModuleConfiguration$impl');
exports = BadgesModuleConfiguration;
 