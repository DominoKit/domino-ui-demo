/**
 * @fileoverview transpiled from org.dominokit.domino.badges.client.presenters.BadgesPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.badges.client.presenters.BadgesPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let BadgesPresenter = goog.forwardDeclare('org.dominokit.domino.badges.client.presenters.BadgesPresenter$impl');


/**
 * @extends {PresenterCommand<BadgesPresenter>}
  */
class BadgesPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BadgesPresenterCommand()'.
   * @return {!BadgesPresenterCommand}
   * @public
   */
  static $create__() {
    BadgesPresenterCommand.$clinit();
    let $instance = new BadgesPresenterCommand();
    $instance.$ctor__org_dominokit_domino_badges_client_presenters_BadgesPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BadgesPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_badges_client_presenters_BadgesPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BadgesPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BadgesPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BadgesPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BadgesPresenterCommand, $Util.$makeClassName('org.dominokit.domino.badges.client.presenters.BadgesPresenterCommand'));




exports = BadgesPresenterCommand; 
//# sourceMappingURL=BadgesPresenterCommand.js.map