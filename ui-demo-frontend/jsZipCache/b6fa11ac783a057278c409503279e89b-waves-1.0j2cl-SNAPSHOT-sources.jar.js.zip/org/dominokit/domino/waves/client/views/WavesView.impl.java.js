/**
 * @fileoverview transpiled from org.dominokit.domino.waves.client.views.WavesView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.waves.client.views.WavesView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.waves.client.views.WavesView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class WavesView {
  /**
   * @param {?function():Content} fn
   * @return {WavesView}
   * @public
   */
  static $adapt(fn) {
    WavesView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_waves_client_views_WavesView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_waves_client_views_WavesView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_waves_client_views_WavesView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    WavesView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.waves.client.views.WavesView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(WavesView, $Util.$makeClassName('org.dominokit.domino.waves.client.views.WavesView'));


WavesView.$markImplementor(/** @type {Function} */ (WavesView));


exports = WavesView; 
//# sourceMappingURL=WavesView.js.map