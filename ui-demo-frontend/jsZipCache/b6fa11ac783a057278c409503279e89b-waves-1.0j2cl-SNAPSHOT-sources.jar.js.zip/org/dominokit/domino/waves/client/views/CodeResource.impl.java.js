/**
 * @fileoverview transpiled from org.dominokit.domino.waves.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.waves.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_waves_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_waves_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_waves__() {
    CodeResource.$clinit();
    return "//Elements extending WaveElement will have waves by default\n" + "//to add Waves to elements that does not extend from WaveElement use the WaveSupport class\n" + "\n" + "WavesSupport.addFor(element)\n" + "    .setWavesColor(WaveColor.YELLOW)\n" + "    .applyWaveStyle(WaveStyle.CIRCLE);";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.waves.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map