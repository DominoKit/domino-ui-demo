/**
 * @fileoverview transpiled from org.dominokit.domino.carousel.client.CarouselClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.carousel.client.CarouselClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class CarouselClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CarouselClientModule()'.
   * @return {!CarouselClientModule}
   * @public
   */
  static $create__() {
    CarouselClientModule.$clinit();
    let $instance = new CarouselClientModule();
    $instance.$ctor__org_dominokit_domino_carousel_client_CarouselClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CarouselClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_carousel_client_CarouselClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    CarouselClientModule.$f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_.m_info__java_lang_String("Initializing Carousel frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_() {
    return (CarouselClientModule.$clinit(), CarouselClientModule.$f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_(value) {
    (CarouselClientModule.$clinit(), CarouselClientModule.$f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CarouselClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CarouselClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CarouselClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    CarouselClientModule.$f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(CarouselClientModule));
  }
  
  
};

$Util.$setClassMetadata(CarouselClientModule, $Util.$makeClassName('org.dominokit.domino.carousel.client.CarouselClientModule'));


/** @private {Logger} */
CarouselClientModule.$f_LOGGER__org_dominokit_domino_carousel_client_CarouselClientModule_;




exports = CarouselClientModule; 
//# sourceMappingURL=CarouselClientModule.js.map