/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _NotificationsView = goog.require('org.dominokit.domino.notifications.client.views.NotificationsView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$10 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$10');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$11');
const _$LambdaAdaptor$12 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$12');
const _$LambdaAdaptor$13 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$13');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$15');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$16');
const _$LambdaAdaptor$17 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$17');
const _$LambdaAdaptor$18 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$18');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$19');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$20');
const _$LambdaAdaptor$21 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$21');
const _$LambdaAdaptor$22 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$22');
const _$LambdaAdaptor$23 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$23');
const _$LambdaAdaptor$24 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$24');
const _$LambdaAdaptor$25 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$25');
const _$LambdaAdaptor$26 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$26');
const _$LambdaAdaptor$27 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$27');
const _$LambdaAdaptor$28 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$28');
const _$LambdaAdaptor$29 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$29');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$3');
const _$LambdaAdaptor$30 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$30');
const _$LambdaAdaptor$31 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$31');
const _$LambdaAdaptor$32 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$32');
const _$LambdaAdaptor$33 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$33');
const _$LambdaAdaptor$34 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$34');
const _$LambdaAdaptor$35 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$35');
const _$LambdaAdaptor$36 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$36');
const _$LambdaAdaptor$37 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$37');
const _$LambdaAdaptor$38 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$38');
const _$LambdaAdaptor$39 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$39');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$4');
const _$LambdaAdaptor$40 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$40');
const _$LambdaAdaptor$41 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$41');
const _$LambdaAdaptor$42 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$42');
const _$LambdaAdaptor$43 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$43');
const _$LambdaAdaptor$44 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$44');
const _$LambdaAdaptor$45 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$45');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$5');
const _$LambdaAdaptor$6 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$6');
const _$LambdaAdaptor$7 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$7');
const _$LambdaAdaptor$8 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$8');
const _$LambdaAdaptor$9 = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$9');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var NotificationsViewImpl = goog.require('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl$impl');
exports = NotificationsViewImpl;
 