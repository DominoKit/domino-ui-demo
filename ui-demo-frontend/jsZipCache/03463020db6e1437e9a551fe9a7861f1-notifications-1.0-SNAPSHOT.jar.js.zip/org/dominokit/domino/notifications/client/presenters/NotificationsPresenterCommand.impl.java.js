/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let NotificationsPresenter = goog.forwardDeclare('org.dominokit.domino.notifications.client.presenters.NotificationsPresenter$impl');


/**
 * @extends {PresenterCommand<NotificationsPresenter>}
  */
class NotificationsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'NotificationsPresenterCommand()'.
   * @return {!NotificationsPresenterCommand}
   * @public
   */
  static $create__() {
    NotificationsPresenterCommand.$clinit();
    let $instance = new NotificationsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_notifications_client_presenters_NotificationsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NotificationsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_notifications_client_presenters_NotificationsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NotificationsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NotificationsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NotificationsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NotificationsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand'));




exports = NotificationsPresenterCommand; 
//# sourceMappingURL=NotificationsPresenterCommand.js.map