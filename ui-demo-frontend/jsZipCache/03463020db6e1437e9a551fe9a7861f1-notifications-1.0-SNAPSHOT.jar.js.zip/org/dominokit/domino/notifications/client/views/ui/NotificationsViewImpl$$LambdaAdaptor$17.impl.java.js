/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl$$LambdaAdaptor$17.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$17$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$17 extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor$17($JsFunction)'.
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$17.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_$LambdaAdaptor$17;
    this.$ctor__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_$LambdaAdaptor$17__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor$17($JsFunction)'.
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_$LambdaAdaptor$17__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_$LambdaAdaptor$17 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_$LambdaAdaptor$17;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$17;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$17);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$17.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$17, $Util.$makeClassName('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl$$LambdaAdaptor$17'));




exports = $LambdaAdaptor$17; 
//# sourceMappingURL=NotificationsViewImpl$$LambdaAdaptor$17.js.map