package org.dominokit.domino.notifications.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.notifications.client.presenters.NotificationsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class NotificationsPresenterListenerForComponentsEvent implements DominoEventListener<ComponentsEvent> {
  @Override
  public void listen(ComponentsEvent event) {
    new NotificationsPresenterCommand().onPresenterReady(presenter -> presenter.onComponentCaseEvent(event.context())).send();
  }
}
