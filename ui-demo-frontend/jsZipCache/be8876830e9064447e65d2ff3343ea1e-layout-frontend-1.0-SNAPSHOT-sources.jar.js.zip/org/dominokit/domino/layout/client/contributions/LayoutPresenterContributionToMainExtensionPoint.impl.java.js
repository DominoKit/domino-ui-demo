/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.contributions.LayoutPresenterContributionToMainExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.contributions.LayoutPresenterContributionToMainExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let MainContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainContext$impl');
let MainExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');
let LayoutPresenter = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');
let LayoutPresenterCommand = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<MainExtensionPoint>}
  */
class LayoutPresenterContributionToMainExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutPresenterContributionToMainExtensionPoint()'.
   * @return {!LayoutPresenterContributionToMainExtensionPoint}
   * @public
   */
  static $create__() {
    LayoutPresenterContributionToMainExtensionPoint.$clinit();
    let $instance = new LayoutPresenterContributionToMainExtensionPoint();
    $instance.$ctor__org_dominokit_domino_layout_client_contributions_LayoutPresenterContributionToMainExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutPresenterContributionToMainExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_contributions_LayoutPresenterContributionToMainExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {MainExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_MainExtensionPoint(extensionPoint) {
    LayoutPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** LayoutPresenter */ presenter) =>{
      presenter.m_contributeToMainModule__org_dominokit_domino_api_shared_extension_MainContext(/**@type {MainContext} */ ($Casts.$to(extensionPoint.m_context__(), MainContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_api_shared_extension_MainExtensionPoint(/**@type {MainExtensionPoint} */ ($Casts.$to(arg0, MainExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutPresenterContributionToMainExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutPresenterContributionToMainExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutPresenterContributionToMainExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    MainContext = goog.module.get('org.dominokit.domino.api.shared.extension.MainContext$impl');
    MainExtensionPoint = goog.module.get('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');
    LayoutPresenterCommand = goog.module.get('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutPresenterContributionToMainExtensionPoint, $Util.$makeClassName('org.dominokit.domino.layout.client.contributions.LayoutPresenterContributionToMainExtensionPoint'));


Contribution.$markImplementor(LayoutPresenterContributionToMainExtensionPoint);


exports = LayoutPresenterContributionToMainExtensionPoint; 
//# sourceMappingURL=LayoutPresenterContributionToMainExtensionPoint.js.map