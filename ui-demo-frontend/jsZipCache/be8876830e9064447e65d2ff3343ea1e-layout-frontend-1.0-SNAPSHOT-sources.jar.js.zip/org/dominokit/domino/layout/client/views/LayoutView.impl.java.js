/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.views.LayoutView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.views.LayoutView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler$impl');


/**
 * @interface
 * @extends {View}
 * @extends {IsLayout}
 */
class LayoutView {
  /**
   * @abstract
   * @param {?string} iconName
   * @param {SelectionHandler} selectionHandler
   * @return {void}
   * @public
   */
  m_addActionItem__java_lang_String__org_dominokit_domino_layout_shared_extension_LayoutContext_SelectionHandler(iconName, selectionHandler) {
  }
  
  /**
   * @abstract
   * @override
   * @param {Content} content
   * @return {void}
   * @public
   */
  m_setRightPanelContent__org_dominokit_domino_api_shared_extension_Content(content) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    IsLayout.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layout_client_views_LayoutView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layout_client_views_LayoutView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layout_client_views_LayoutView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(LayoutView, $Util.$makeClassName('org.dominokit.domino.layout.client.views.LayoutView'));


LayoutView.$markImplementor(/** @type {Function} */ (LayoutView));


exports = LayoutView; 
//# sourceMappingURL=LayoutView.js.map