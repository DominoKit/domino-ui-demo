package org.dominokit.domino.layout.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.api.shared.extension.MainExtensionPoint;
import org.dominokit.domino.layout.client.contributions.LayoutPresenterContributionToMainExtensionPoint;
import org.dominokit.domino.layout.client.presenters.LayoutPresenter;
import org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class LayoutModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(LayoutPresenter.class.getCanonicalName(), LayoutPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new LayoutPresenter();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(LayoutPresenterCommand.class.getCanonicalName(), LayoutPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(MainExtensionPoint.class, new LayoutPresenterContributionToMainExtensionPoint());
  }
}
