/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BreadcrumbView = goog.require('org.dominokit.domino.breadcrumb.client.views.BreadcrumbView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _CodeResource = goog.require('org.dominokit.domino.breadcrumb.client.views.CodeResource');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$10 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$10');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$11');
const _$LambdaAdaptor$12 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$12');
const _$LambdaAdaptor$13 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$13');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$15');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$16');
const _$LambdaAdaptor$17 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$17');
const _$LambdaAdaptor$18 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$18');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$19');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$20');
const _$LambdaAdaptor$21 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$21');
const _$LambdaAdaptor$22 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$22');
const _$LambdaAdaptor$23 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$23');
const _$LambdaAdaptor$24 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$24');
const _$LambdaAdaptor$25 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$25');
const _$LambdaAdaptor$26 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$26');
const _$LambdaAdaptor$27 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$27');
const _$LambdaAdaptor$28 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$28');
const _$LambdaAdaptor$29 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$29');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$3');
const _$LambdaAdaptor$30 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$30');
const _$LambdaAdaptor$31 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$31');
const _$LambdaAdaptor$32 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$32');
const _$LambdaAdaptor$33 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$33');
const _$LambdaAdaptor$34 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$34');
const _$LambdaAdaptor$35 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$35');
const _$LambdaAdaptor$36 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$36');
const _$LambdaAdaptor$37 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$37');
const _$LambdaAdaptor$38 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$38');
const _$LambdaAdaptor$39 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$39');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$4');
const _$LambdaAdaptor$40 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$40');
const _$LambdaAdaptor$41 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$41');
const _$LambdaAdaptor$42 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$42');
const _$LambdaAdaptor$43 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$43');
const _$LambdaAdaptor$44 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$44');
const _$LambdaAdaptor$45 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$45');
const _$LambdaAdaptor$46 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$46');
const _$LambdaAdaptor$47 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$47');
const _$LambdaAdaptor$48 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$48');
const _$LambdaAdaptor$49 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$49');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$5');
const _$LambdaAdaptor$50 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$50');
const _$LambdaAdaptor$51 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$51');
const _$LambdaAdaptor$52 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$52');
const _$LambdaAdaptor$53 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$53');
const _$LambdaAdaptor$54 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$54');
const _$LambdaAdaptor$55 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$55');
const _$LambdaAdaptor$56 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$56');
const _$LambdaAdaptor$57 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$57');
const _$LambdaAdaptor$58 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$58');
const _$LambdaAdaptor$59 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$59');
const _$LambdaAdaptor$6 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$6');
const _$LambdaAdaptor$60 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$60');
const _$LambdaAdaptor$61 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$61');
const _$LambdaAdaptor$62 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$62');
const _$LambdaAdaptor$63 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$63');
const _$LambdaAdaptor$64 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$64');
const _$LambdaAdaptor$65 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$65');
const _$LambdaAdaptor$66 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$66');
const _$LambdaAdaptor$67 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$67');
const _$LambdaAdaptor$68 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$68');
const _$LambdaAdaptor$69 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$69');
const _$LambdaAdaptor$7 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$7');
const _$LambdaAdaptor$70 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$70');
const _$LambdaAdaptor$71 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$71');
const _$LambdaAdaptor$72 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$72');
const _$LambdaAdaptor$73 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$73');
const _$LambdaAdaptor$74 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$74');
const _$LambdaAdaptor$75 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$75');
const _$LambdaAdaptor$76 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$76');
const _$LambdaAdaptor$77 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$77');
const _$LambdaAdaptor$8 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$8');
const _$LambdaAdaptor$9 = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$9');
const _Breadcrumb = goog.require('org.dominokit.domino.ui.breadcrumbs.Breadcrumb');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BreadcrumbViewImpl = goog.require('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl$impl');
exports = BreadcrumbViewImpl;
 