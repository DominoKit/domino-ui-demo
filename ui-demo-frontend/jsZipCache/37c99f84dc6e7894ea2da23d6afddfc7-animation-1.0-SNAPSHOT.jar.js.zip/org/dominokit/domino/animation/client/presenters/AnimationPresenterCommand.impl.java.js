/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let AnimationPresenter = goog.forwardDeclare('org.dominokit.domino.animation.client.presenters.AnimationPresenter$impl');


/**
 * @extends {PresenterCommand<AnimationPresenter>}
  */
class AnimationPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AnimationPresenterCommand()'.
   * @return {!AnimationPresenterCommand}
   * @public
   */
  static $create__() {
    AnimationPresenterCommand.$clinit();
    let $instance = new AnimationPresenterCommand();
    $instance.$ctor__org_dominokit_domino_animation_client_presenters_AnimationPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnimationPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_animation_client_presenters_AnimationPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnimationPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnimationPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnimationPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnimationPresenterCommand, $Util.$makeClassName('org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand'));




exports = AnimationPresenterCommand; 
//# sourceMappingURL=AnimationPresenterCommand.js.map