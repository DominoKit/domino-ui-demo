/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.views.ui.AnimationViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.animation.client.views.ui.AnimationViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AnimationView = goog.require('org.dominokit.domino.animation.client.views.AnimationView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.animation.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.animation.client.views.ui.AnimationViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.animation.client.views.ui.AnimationViewImpl.$LambdaAdaptor$2$impl');
let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {AnimationView}
  */
class AnimationViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'AnimationViewImpl()'.
   * @return {!AnimationViewImpl}
   * @public
   */
  static $create__() {
    AnimationViewImpl.$clinit();
    let $instance = new AnimationViewImpl();
    $instance.$ctor__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnimationViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("CSS ANIMATIONS").m_appendText__java_lang_String("Pure css animations - ").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://daneden.github.io/animate.css/"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_textContent__java_lang_String("daneden.github.io/animate.css"), HtmlContentBuilder)).m_asElement__()).m_asElement__());
    let image = /**@type {HTMLImageElement} */ ($Casts.$to(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("static/images/animation-bg.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_asElement__(), $Overlay));
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FLASH__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_PULSE__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SHAKE__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SWING__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_TADA__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_WOBBLE__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_JELLO__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FLIP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_HINGE__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROLL_IN__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(this.m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(Transition.f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_animation__()).m_asElement__());
  }
  
  /**
   * @param {Transition} transition
   * @return {Card}
   * @public
   */
  m_createCard__org_dominokit_domino_ui_animations_Transition_$p_org_dominokit_domino_animation_client_views_ui_AnimationViewImpl(transition) {
    let animationCard = Card.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("static/images/animation-bg.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_asElement__());
    let card = Card.m_create__java_lang_String__java_lang_String(transition.m_getName__(), j_l_String.m_valueOf__java_lang_Object(transition.m_getStyle__()) + " animation.").m_setBodyBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color);
    let animate = Button.m_createDefault__java_lang_String(transition.m_getName__()).m_large__();
    animate.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$1(((/** Event */ e) =>{
      Animation.m_create__elemental2_dom_HTMLElement(animationCard.m_asElement__()).m_transition__org_dominokit_domino_ui_animations_Transition(transition).m_duration__int(1000).m_animate__();
    })));
    let infiniteAnimate = Button.m_createDefault__java_lang_String("INFINITE").m_large__();
    infiniteAnimate.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$2(((/** Event */ e$1$) =>{
      let animation = Animation.m_create__elemental2_dom_HTMLElement(animationCard.m_asElement__()).m_transition__org_dominokit_domino_ui_animations_Transition(transition).m_infinite__().m_duration__int(1000);
      if (animationCard.m_asElement__().classList.contains("animated")) {
        animation.m_stop__();
        animate.m_asElement__().style.display = "inline-block";
        infiniteAnimate.m_setContent__java_lang_String("INFINITE");
      } else {
        animation.m_animate__();
        animate.m_asElement__().style.display = "none";
        infiniteAnimate.m_setContent__java_lang_String("STOP");
      }
    })));
    card.m_appendContent__elemental2_dom_Node(animationCard.m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["button-demo"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("style", "text-align: center"), HtmlContentBuilder)).m_add__elemental2_dom_Node(animate.m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(infiniteAnimate.m_asElement__()), HtmlContentBuilder)).m_asElement__());
    return card;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl() {
    this.f_element__org_dominokit_domino_animation_client_views_ui_AnimationViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnimationViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnimationViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnimationViewImpl.$clinit = function() {};
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLImageElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeResource = goog.module.get('org.dominokit.domino.animation.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.animation.client.views.ui.AnimationViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.animation.client.views.ui.AnimationViewImpl.$LambdaAdaptor$2$impl');
    Animation = goog.module.get('org.dominokit.domino.ui.animations.Animation$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnimationViewImpl, $Util.$makeClassName('org.dominokit.domino.animation.client.views.ui.AnimationViewImpl'));


AnimationView.$markImplementor(AnimationViewImpl);


exports = AnimationViewImpl; 
//# sourceMappingURL=AnimationViewImpl.js.map