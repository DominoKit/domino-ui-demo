/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.presenters.AnimationPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.animation.client.presenters.AnimationPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.animation.client.presenters.AnimationPresenter.$1$impl');
let AnimationView = goog.forwardDeclare('org.dominokit.domino.animation.client.views.AnimationView$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<AnimationView>}
  */
class AnimationPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AnimationPresenter()'.
   * @return {!AnimationPresenter}
   * @public
   */
  static $create__() {
    AnimationPresenter.$clinit();
    let $instance = new AnimationPresenter();
    $instance.$ctor__org_dominokit_domino_animation_client_presenters_AnimationPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnimationPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_animation_client_presenters_AnimationPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_animation_client_presenters_AnimationPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_animation_client_presenters_AnimationPresenter_() {
    return (AnimationPresenter.$clinit(), AnimationPresenter.$f_LOGGER__org_dominokit_domino_animation_client_presenters_AnimationPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_animation_client_presenters_AnimationPresenter_(value) {
    (AnimationPresenter.$clinit(), AnimationPresenter.$f_LOGGER__org_dominokit_domino_animation_client_presenters_AnimationPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnimationPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnimationPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnimationPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.animation.client.presenters.AnimationPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    AnimationPresenter.$f_LOGGER__org_dominokit_domino_animation_client_presenters_AnimationPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AnimationPresenter));
  }
  
  
};

$Util.$setClassMetadata(AnimationPresenter, $Util.$makeClassName('org.dominokit.domino.animation.client.presenters.AnimationPresenter'));


/** @private {Logger} */
AnimationPresenter.$f_LOGGER__org_dominokit_domino_animation_client_presenters_AnimationPresenter_;




exports = AnimationPresenter; 
//# sourceMappingURL=AnimationPresenter.js.map