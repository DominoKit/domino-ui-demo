/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.alerts.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_alerts_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_alerts_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_basicAlerts__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"BASIC ALERTS\", \"Use one of the pre-customized alert types.\")\n" + "                .appendContent(Alert.success().appendStrong(\"Well done! \")\n" + "                    .appendText(\"You successfully read this important alert message.\").asElement())\n" + "                .appendContent(Alert.info().appendStrong(\"Heads up! \")\n" + "                    .appendText(\"This alert needs your attention, but it's not super important.\").asElement())\n" + "                .appendContent(Alert.warning().appendStrong(\"Warning! \")\n" + "                    .appendText(\"Better check yourself, you're not looking too good.\").asElement())\n" + "                .appendContent(Alert.error().appendStrong(\"Oh snap! \").appendText(\"Change a few things up and try submitting again.\")\n" + "                    .asElement())\n" + "                .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_customBackgrounds__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"MATERIAL DESIGN ALERTS\", \"ou can use material design colors backgrounds\")\n" + "                .appendContent(Alert.create(Color.PINK)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.ORANGE)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.TEAL)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.GREEN)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.RED)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .asElement())\n" + "                .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_dismissibleAlerts__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"DISMISSIBLE ALERTS\", \"Add a close button to any alert by making it dismissible\")\n" + "                .appendContent(Alert.warning()\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .dismissible()\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.PINK)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .dismissible()\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.TEAL)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .dismissible()\n" + "                        .asElement())\n" + "                .appendContent(Alert.create(Color.GREEN)\n" + "                        .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id\")\n" + "                        .dismissible()\n" + "                        .asElement())\n" + "                .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_linksInAlerts__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"LINKS IN ALERTS\", \"Use the appendLink utility class to quickly provide matching colored links within any alert.\")\n" + "            .appendContent(Alert.success()\n" + "                    .appendStrong(\"Well done! \")\n" + "                    .appendText(\"You successfully read \")\n" + "                    .appendLink(Elements.a().add(\"important alert message.\").asElement())\n" + "                    .asElement())\n" + "            .appendContent(Alert.info()\n" + "                    .appendStrong(\"Heads up! \")\n" + "                    .appendText(\"This \")\n" + "                    .appendLink(Elements.a().add(\"alert needs your attention, \").asElement())\n" + "                    .appendText(\"but it's not super important.\")\n" + "                    .asElement())\n" + "            .appendContent(Alert.warning()\n" + "                    .appendStrong(\"Warning! \")\n" + "                    .appendText(\"Better check yourself, \")\n" + "                    .appendLink(Elements.a().add(\"you're not looking too good.\").asElement())\n" + "                    .asElement())\n" + "            .appendContent(Alert.error()\n" + "                    .appendStrong(\"Oh snap! \")\n" + "                    .appendLink(Elements.a().add(\"Change a few things up\").asElement())\n" + "                    .appendText(\" and try submitting again.\")\n" + "                    .asElement())\n" + "            .appendContent(Alert.create(Color.PINK)\n" + "                    .appendText(\"Lorem ipsum dolor sit amet, id fugit tollit pro, illud nostrud aliquando ad est, quo esse dolorum id \")\n" + "                    .appendLink(Elements.a().add(\"alert link.\").asElement())\n" + "                    .asElement())\n" + "            .asElement());";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.alerts.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map