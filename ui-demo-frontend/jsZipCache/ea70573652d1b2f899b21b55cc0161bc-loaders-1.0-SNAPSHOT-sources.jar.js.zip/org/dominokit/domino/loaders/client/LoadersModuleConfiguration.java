package org.dominokit.domino.loaders.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.loaders.client.listeners.LoadersPresenterListenerForComponentsEvent;
import org.dominokit.domino.loaders.client.presenters.LoadersPresenter;
import org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand;
import org.dominokit.domino.loaders.client.views.ui.LoadersViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class LoadersModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(LoadersPresenter.class.getCanonicalName(), LoadersPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new LoadersPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(LoadersPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new LoadersViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(LoadersPresenterCommand.class.getCanonicalName(), LoadersPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentsEvent.class, new LoadersPresenterListenerForComponentsEvent());
  }
}
