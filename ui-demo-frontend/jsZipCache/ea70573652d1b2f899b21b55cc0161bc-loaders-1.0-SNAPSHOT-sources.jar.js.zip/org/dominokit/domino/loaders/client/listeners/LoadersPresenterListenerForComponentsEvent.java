package org.dominokit.domino.loaders.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.loaders.client.presenters.LoadersPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class LoadersPresenterListenerForComponentsEvent implements DominoEventListener<ComponentsEvent> {
  @Override
  public void listen(ComponentsEvent event) {
    new LoadersPresenterCommand().onPresenterReady(presenter -> presenter.onComponentsModule(event.context())).send();
  }
}
