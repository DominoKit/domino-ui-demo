/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.Content.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.extension.Content');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.shared.extension.Content.$LambdaAdaptor');


// Re-exports the implementation.
var Content = goog.require('org.dominokit.domino.api.shared.extension.Content$impl');
exports = Content;
 