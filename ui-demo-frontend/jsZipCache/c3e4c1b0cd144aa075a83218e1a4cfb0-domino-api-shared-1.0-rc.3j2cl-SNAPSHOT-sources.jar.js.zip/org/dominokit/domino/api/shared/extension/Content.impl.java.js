/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.Content.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.Content$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 */
class Content {
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_get__() {
  }
  
  /**
   * @template C_T
   * @param {?function():C_T} fn
   * @return {Content<C_T>}
   * @public
   */
  static $adapt(fn) {
    Content.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_Content = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_Content;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_Content;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Content.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.extension.Content.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Content, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.Content'));


Content.$markImplementor(/** @type {Function} */ (Content));


exports = Content; 
//# sourceMappingURL=Content.js.map