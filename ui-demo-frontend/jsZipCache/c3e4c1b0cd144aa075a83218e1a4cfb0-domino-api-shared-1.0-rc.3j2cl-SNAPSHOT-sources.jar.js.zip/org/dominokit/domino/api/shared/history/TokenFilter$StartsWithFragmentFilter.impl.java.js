/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$StartsWithFragmentFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFragmentFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class StartsWithFragmentFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_prefix__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFragmentFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'StartsWithFragmentFilter(String)'.
   * @param {?string} prefix
   * @return {!StartsWithFragmentFilter}
   * @public
   */
  static $create__java_lang_String(prefix) {
    StartsWithFragmentFilter.$clinit();
    let $instance = new StartsWithFragmentFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFragmentFilter__java_lang_String(prefix);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StartsWithFragmentFilter(String)'.
   * @param {?string} prefix
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFragmentFilter__java_lang_String(prefix) {
    this.$ctor__java_lang_Object__();
    this.f_prefix__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFragmentFilter_ = prefix;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_startsWith__java_lang_String__java_lang_String(token.m_fragment__(), this.f_prefix__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFragmentFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StartsWithFragmentFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StartsWithFragmentFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StartsWithFragmentFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(StartsWithFragmentFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$StartsWithFragmentFilter'));


TokenFilter.$markImplementor(StartsWithFragmentFilter);


exports = StartsWithFragmentFilter; 
//# sourceMappingURL=TokenFilter$StartsWithFragmentFilter.js.map