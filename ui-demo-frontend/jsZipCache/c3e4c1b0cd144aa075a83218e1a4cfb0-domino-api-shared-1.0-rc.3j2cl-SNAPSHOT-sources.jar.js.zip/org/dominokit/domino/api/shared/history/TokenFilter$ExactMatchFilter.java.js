/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$ExactMatchFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.ExactMatchFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');
const _j_l_String = goog.require('java.lang.String');
const _HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken');


// Re-exports the implementation.
var ExactMatchFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.ExactMatchFilter$impl');
exports = ExactMatchFilter;
 