/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DirectState = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectState$impl');
let StateListener = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');
let TokenFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter$impl');


/**
 * @interface
 */
class DominoHistory {
  /**
   * @abstract
   * @param {StateListener} listener
   * @return {DirectState}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(listener) {
  }
  
  /**
   * @abstract
   * @param {TokenFilter} tokenFilter
   * @param {StateListener} listener
   * @return {DirectState}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(tokenFilter, listener) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_back__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_forward__() {
  }
  
  /**
   * @abstract
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {void}
   * @public
   */
  m_pushState__java_lang_String__java_lang_String__java_lang_String(token, title, data) {
  }
  
  /**
   * @abstract
   * @param {?string} token
   * @return {void}
   * @public
   */
  m_pushState__java_lang_String(token) {
  }
  
  /**
   * @abstract
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {void}
   * @public
   */
  m_replaceState__java_lang_String__java_lang_String__java_lang_String(token, title, data) {
  }
  
  /**
   * @abstract
   * @return {HistoryToken}
   * @public
   */
  m_currentToken__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_DominoHistory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoHistory.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(DominoHistory, $Util.$makeClassName('org.dominokit.domino.api.shared.history.DominoHistory'));


DominoHistory.$markImplementor(/** @type {Function} */ (DominoHistory));


exports = DominoHistory; 
//# sourceMappingURL=DominoHistory.js.map