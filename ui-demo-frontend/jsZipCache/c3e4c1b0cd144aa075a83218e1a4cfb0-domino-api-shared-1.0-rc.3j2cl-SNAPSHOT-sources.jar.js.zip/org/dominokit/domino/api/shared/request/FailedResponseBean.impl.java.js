/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.FailedResponseBean.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');


/**
 * @implements {ResponseBean}
  */
class FailedResponseBean extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Throwable} */
    this.f_error__org_dominokit_domino_api_shared_request_FailedResponseBean_;
  }
  
  /**
   * Factory method corresponding to constructor 'FailedResponseBean()'.
   * @return {!FailedResponseBean}
   * @public
   */
  static $create__() {
    FailedResponseBean.$clinit();
    let $instance = new FailedResponseBean();
    $instance.$ctor__org_dominokit_domino_api_shared_request_FailedResponseBean__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FailedResponseBean()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_request_FailedResponseBean__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * Factory method corresponding to constructor 'FailedResponseBean(Throwable)'.
   * @param {Throwable} error
   * @return {!FailedResponseBean}
   * @public
   */
  static $create__java_lang_Throwable(error) {
    FailedResponseBean.$clinit();
    let $instance = new FailedResponseBean();
    $instance.$ctor__org_dominokit_domino_api_shared_request_FailedResponseBean__java_lang_Throwable(error);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FailedResponseBean(Throwable)'.
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_request_FailedResponseBean__java_lang_Throwable(error) {
    this.$ctor__java_lang_Object__();
    this.f_error__org_dominokit_domino_api_shared_request_FailedResponseBean_ = error;
  }
  
  /**
   * @return {Throwable}
   * @public
   */
  m_getError__() {
    return this.f_error__org_dominokit_domino_api_shared_request_FailedResponseBean_;
  }
  
  /**
   * @param {Throwable} error
   * @return {void}
   * @public
   */
  m_setError__java_lang_Throwable(error) {
    this.f_error__org_dominokit_domino_api_shared_request_FailedResponseBean_ = error;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FailedResponseBean;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FailedResponseBean);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FailedResponseBean.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FailedResponseBean, $Util.$makeClassName('org.dominokit.domino.api.shared.request.FailedResponseBean'));


/** @public {!$Long} @const */
FailedResponseBean.f_serialVersionUID__org_dominokit_domino_api_shared_request_FailedResponseBean_ = $Long.fromBits(531353381, 1663868056) /* 7146258885910449957 */;


ResponseBean.$markImplementor(FailedResponseBean);


exports = FailedResponseBean; 
//# sourceMappingURL=FailedResponseBean.js.map