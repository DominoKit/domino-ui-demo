/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(HistoryToken):boolean} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(HistoryToken):boolean} */
    this.f_$$fn__org_dominokit_domino_api_shared_history_TokenFilter_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_$LambdaAdaptor__org_dominokit_domino_api_shared_history_TokenFilter_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(HistoryToken):boolean} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_$LambdaAdaptor__org_dominokit_domino_api_shared_history_TokenFilter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_shared_history_TokenFilter_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {HistoryToken} arg0
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(arg0) {
    let /** ?function(HistoryToken):boolean */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_shared_history_TokenFilter_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$$LambdaAdaptor'));


TokenFilter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=TokenFilter$$LambdaAdaptor.js.map