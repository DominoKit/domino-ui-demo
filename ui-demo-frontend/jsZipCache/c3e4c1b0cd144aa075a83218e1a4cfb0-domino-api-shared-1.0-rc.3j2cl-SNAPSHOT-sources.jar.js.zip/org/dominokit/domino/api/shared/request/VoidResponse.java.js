/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.VoidResponse.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.request.VoidResponse');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');


// Re-exports the implementation.
var VoidResponse = goog.require('org.dominokit.domino.api.shared.request.VoidResponse$impl');
exports = VoidResponse;
 