/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.FailedResponseBean.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.request.FailedResponseBean');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Long = goog.require('nativebootstrap.Long');
const _$Util = goog.require('nativebootstrap.Util');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');
const _Throwable = goog.require('java.lang.Throwable');


// Re-exports the implementation.
var FailedResponseBean = goog.require('org.dominokit.domino.api.shared.request.FailedResponseBean$impl');
exports = FailedResponseBean;
 