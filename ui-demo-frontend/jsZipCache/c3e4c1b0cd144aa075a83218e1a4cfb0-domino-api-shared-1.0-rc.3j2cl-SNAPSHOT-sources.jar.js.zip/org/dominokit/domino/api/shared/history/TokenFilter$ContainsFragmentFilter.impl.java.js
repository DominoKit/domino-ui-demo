/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$ContainsFragmentFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFragmentFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class ContainsFragmentFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_matchingPart__org_dominokit_domino_api_shared_history_TokenFilter_ContainsFragmentFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContainsFragmentFilter(String)'.
   * @param {?string} matchingPart
   * @return {!ContainsFragmentFilter}
   * @public
   */
  static $create__java_lang_String(matchingPart) {
    ContainsFragmentFilter.$clinit();
    let $instance = new ContainsFragmentFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_ContainsFragmentFilter__java_lang_String(matchingPart);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContainsFragmentFilter(String)'.
   * @param {?string} matchingPart
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_ContainsFragmentFilter__java_lang_String(matchingPart) {
    this.$ctor__java_lang_Object__();
    this.f_matchingPart__org_dominokit_domino_api_shared_history_TokenFilter_ContainsFragmentFilter_ = matchingPart;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_contains__java_lang_String__java_lang_CharSequence(token.m_fragment__(), this.f_matchingPart__org_dominokit_domino_api_shared_history_TokenFilter_ContainsFragmentFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContainsFragmentFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContainsFragmentFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContainsFragmentFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContainsFragmentFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$ContainsFragmentFilter'));


TokenFilter.$markImplementor(ContainsFragmentFilter);


exports = ContainsFragmentFilter; 
//# sourceMappingURL=TokenFilter$ContainsFragmentFilter.js.map