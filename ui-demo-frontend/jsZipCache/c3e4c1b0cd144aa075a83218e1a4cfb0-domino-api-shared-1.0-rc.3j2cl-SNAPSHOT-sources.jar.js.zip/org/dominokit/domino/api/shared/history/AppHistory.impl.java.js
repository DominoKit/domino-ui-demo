/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.AppHistory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.AppHistory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const CurrentStateHistory = goog.require('org.dominokit.domino.api.shared.history.CurrentStateHistory$impl');
const DominoHistory = goog.require('org.dominokit.domino.api.shared.history.DominoHistory$impl');


/**
 * @interface
 * @extends {DominoHistory}
 * @extends {CurrentStateHistory}
 */
class AppHistory {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoHistory.$markImplementor(classConstructor);
    CurrentStateHistory.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_AppHistory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_AppHistory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_AppHistory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AppHistory.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(AppHistory, $Util.$makeClassName('org.dominokit.domino.api.shared.history.AppHistory'));


AppHistory.$markImplementor(/** @type {Function} */ (AppHistory));


exports = AppHistory; 
//# sourceMappingURL=AppHistory.js.map