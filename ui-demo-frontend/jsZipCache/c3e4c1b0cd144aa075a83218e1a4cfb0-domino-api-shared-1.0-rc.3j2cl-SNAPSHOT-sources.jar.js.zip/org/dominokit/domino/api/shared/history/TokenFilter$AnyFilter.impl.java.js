/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$AnyFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.AnyFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class AnyFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AnyFilter()'.
   * @return {!AnyFilter}
   * @public
   */
  static $create__() {
    AnyFilter.$clinit();
    let $instance = new AnyFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_AnyFilter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnyFilter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_AnyFilter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnyFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnyFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnyFilter.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnyFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$AnyFilter'));


TokenFilter.$markImplementor(AnyFilter);


exports = AnyFilter; 
//# sourceMappingURL=TokenFilter$AnyFilter.js.map