/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.DominoHistory$State.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @interface
 */
class State {
  /**
   * @abstract
   * @return {HistoryToken}
   * @public
   */
  m_token__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_data__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_title__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_State = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_DominoHistory_State;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_DominoHistory_State;
  }
  
  /**
   * @public
   */
  static $clinit() {
    State.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(State, $Util.$makeClassName('org.dominokit.domino.api.shared.history.DominoHistory$State'));


State.$markImplementor(/** @type {Function} */ (State));


exports = State; 
//# sourceMappingURL=DominoHistory$State.js.map