/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$StartsWithFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class StartsWithFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_prefix__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'StartsWithFilter(String)'.
   * @param {?string} prefix
   * @return {!StartsWithFilter}
   * @public
   */
  static $create__java_lang_String(prefix) {
    StartsWithFilter.$clinit();
    let $instance = new StartsWithFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFilter__java_lang_String(prefix);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StartsWithFilter(String)'.
   * @param {?string} prefix
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFilter__java_lang_String(prefix) {
    this.$ctor__java_lang_Object__();
    this.f_prefix__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFilter_ = prefix;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_startsWith__java_lang_String__java_lang_String(token.m_value__(), this.f_prefix__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StartsWithFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StartsWithFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StartsWithFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(StartsWithFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$StartsWithFilter'));


TokenFilter.$markImplementor(StartsWithFilter);


exports = StartsWithFilter; 
//# sourceMappingURL=TokenFilter$StartsWithFilter.js.map