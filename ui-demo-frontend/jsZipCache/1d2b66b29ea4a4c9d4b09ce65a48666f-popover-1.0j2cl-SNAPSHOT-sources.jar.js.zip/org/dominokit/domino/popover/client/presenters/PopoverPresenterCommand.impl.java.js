/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.presenters.PopoverPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.popover.client.presenters.PopoverPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let PopoverPresenter = goog.forwardDeclare('org.dominokit.domino.popover.client.presenters.PopoverPresenter$impl');


/**
 * @extends {PresenterCommand<PopoverPresenter>}
  */
class PopoverPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PopoverPresenterCommand()'.
   * @return {!PopoverPresenterCommand}
   * @public
   */
  static $create__() {
    PopoverPresenterCommand.$clinit();
    let $instance = new PopoverPresenterCommand();
    $instance.$ctor__org_dominokit_domino_popover_client_presenters_PopoverPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PopoverPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_popover_client_presenters_PopoverPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PopoverPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PopoverPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PopoverPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PopoverPresenterCommand, $Util.$makeClassName('org.dominokit.domino.popover.client.presenters.PopoverPresenterCommand'));




exports = PopoverPresenterCommand; 
//# sourceMappingURL=PopoverPresenterCommand.js.map