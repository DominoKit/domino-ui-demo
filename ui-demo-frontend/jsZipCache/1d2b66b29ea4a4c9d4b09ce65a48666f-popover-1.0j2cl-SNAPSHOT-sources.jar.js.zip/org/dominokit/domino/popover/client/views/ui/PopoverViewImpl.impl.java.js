/**
 * @fileoverview transpiled from org.dominokit.domino.popover.client.views.ui.PopoverViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.popover.client.views.ui.PopoverViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const PopoverView = goog.require('org.dominokit.domino.popover.client.views.PopoverView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.popover.client.views.CodeResource$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Tooltip = goog.forwardDeclare('org.dominokit.domino.ui.popover.Tooltip$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {PopoverView}
  */
class PopoverViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'PopoverViewImpl()'.
   * @return {!PopoverViewImpl}
   * @public
   */
  static $create__() {
    PopoverViewImpl.$clinit();
    let $instance = new PopoverViewImpl();
    $instance.$ctor__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PopoverViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("TOOLTIPS & POPOVER").m_asElement__());
    this.m_tooltips___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl();
    this.m_popover___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_tooltips___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl() {
    let tooltip_on_right = Button.m_createPrimary__java_lang_String("TOOLTIP ON RIGHT").m_block__().m_asElement__();
    Tooltip.m_create__elemental2_dom_HTMLElement__java_lang_String(tooltip_on_right, "Tooltip on right").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_RIGHT__org_dominokit_domino_ui_popover_PopupPosition);
    let tooltip_on_top = Button.m_createPrimary__java_lang_String("TOOLTIP ON TOP").m_block__().m_asElement__();
    Tooltip.m_create__elemental2_dom_HTMLElement__java_lang_String(tooltip_on_top, "Tooltip on top").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition);
    let tooltip_on_bottom = Button.m_createPrimary__java_lang_String("TOOLTIP ON BOTTOM").m_block__().m_asElement__();
    Tooltip.m_create__elemental2_dom_HTMLElement__java_lang_String(tooltip_on_bottom, "Tooltip on bottom").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_BOTTOM__org_dominokit_domino_ui_popover_PopupPosition);
    let tooltip_on_left = Button.m_createPrimary__java_lang_String("TOOLTIP ON LEFT").m_block__().m_asElement__();
    Tooltip.m_create__elemental2_dom_HTMLElement__java_lang_String(tooltip_on_left, "Tooltip on left").m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_LEFT__org_dominokit_domino_ui_popover_PopupPosition);
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(Card.m_create__java_lang_String("TOOLTIPS").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(tooltip_on_right)).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(tooltip_on_top)).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(tooltip_on_bottom)).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(tooltip_on_left)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_tooltips__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_popover___$p_org_dominokit_domino_popover_client_views_ui_PopoverViewImpl() {
    let popover_on_right = Button.m_createPrimary__java_lang_String("POPOVER ON RIGHT").m_block__().m_asElement__();
    Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(popover_on_right, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.").m_asElement__()).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_RIGHT__org_dominokit_domino_ui_popover_PopupPosition);
    let popover_on_top = Button.m_createPrimary__java_lang_String("POPOVER ON TOP").m_block__().m_asElement__();
    Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(popover_on_top, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.").m_asElement__()).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP__org_dominokit_domino_ui_popover_PopupPosition);
    let popover_on_bottom = Button.m_createPrimary__java_lang_String("POPOVER ON BOTTOM").m_block__().m_asElement__();
    Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(popover_on_bottom, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.").m_asElement__()).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_BOTTOM__org_dominokit_domino_ui_popover_PopupPosition);
    let popover_on_left = Button.m_createPrimary__java_lang_String("POPOVER ON LEFT").m_block__().m_asElement__();
    Popover.m_create__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_Node(popover_on_left, "Popover on right", Paragraph.m_create__java_lang_String("Vivamus sagittis lacus vel augue laoreet rutrum faucibus.").m_asElement__()).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_LEFT__org_dominokit_domino_ui_popover_PopupPosition);
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(Card.m_create__java_lang_String("POPOVER").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(popover_on_right)).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(popover_on_top)).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(popover_on_bottom)).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(popover_on_left)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_popover__()).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl() {
    this.f_element__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_column__org_dominokit_domino_popover_client_views_ui_PopoverViewImpl_ = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_three__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_three__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PopoverViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PopoverViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PopoverViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.popover.client.views.CodeResource$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Tooltip = goog.module.get('org.dominokit.domino.ui.popover.Tooltip$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PopoverViewImpl, $Util.$makeClassName('org.dominokit.domino.popover.client.views.ui.PopoverViewImpl'));


PopoverView.$markImplementor(PopoverViewImpl);


exports = PopoverViewImpl; 
//# sourceMappingURL=PopoverViewImpl.js.map