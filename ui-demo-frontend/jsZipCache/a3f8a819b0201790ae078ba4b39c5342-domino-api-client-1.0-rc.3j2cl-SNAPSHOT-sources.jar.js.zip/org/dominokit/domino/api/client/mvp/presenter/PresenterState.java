package org.dominokit.domino.api.client.mvp.presenter;

@FunctionalInterface
public interface PresenterState {
    void process();
}
