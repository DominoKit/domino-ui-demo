/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.UiHandlers.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.UiHandlers');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var UiHandlers = goog.require('org.dominokit.domino.api.client.mvp.view.UiHandlers$impl');
exports = UiHandlers;
 