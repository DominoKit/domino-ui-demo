/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresenterState$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresenterState.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterState = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresenterState$impl');


/**
 * @implements {PresenterState}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():void} */
    this.f_$$fn__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$LambdaAdaptor__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_process__() {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_client_mvp_presenter_PresenterState_$LambdaAdaptor;
      $function();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.PresenterState$$LambdaAdaptor'));


PresenterState.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=PresenterState$$LambdaAdaptor.js.map