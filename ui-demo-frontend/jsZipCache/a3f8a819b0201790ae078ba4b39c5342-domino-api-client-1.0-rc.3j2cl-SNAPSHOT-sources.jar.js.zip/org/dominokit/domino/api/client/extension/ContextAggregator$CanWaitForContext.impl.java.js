/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator$CanWaitForContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator.CanWaitForContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ContextAggregator = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator$impl');
let ContextWait = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');
let ReadyHandler = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');


/**
 * @interface
 */
class CanWaitForContext {
  /**
   * @abstract
   * @param {ContextWait} context
   * @return {CanWaitForContext}
   * @public
   */
  m_and__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context) {
  }
  
  /**
   * @abstract
   * @param {ReadyHandler} handler
   * @return {ContextAggregator}
   * @public
   */
  m_onReady__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(handler) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContextAggregator_CanWaitForContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_extension_ContextAggregator_CanWaitForContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContextAggregator_CanWaitForContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanWaitForContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(CanWaitForContext, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContextAggregator$CanWaitForContext'));


CanWaitForContext.$markImplementor(/** @type {Function} */ (CanWaitForContext));


exports = CanWaitForContext; 
//# sourceMappingURL=ContextAggregator$CanWaitForContext.js.map