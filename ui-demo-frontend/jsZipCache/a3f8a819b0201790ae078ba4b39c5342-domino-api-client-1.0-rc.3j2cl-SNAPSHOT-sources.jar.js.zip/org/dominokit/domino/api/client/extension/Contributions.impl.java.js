/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.Contributions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.Contributions$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');


class Contributions extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Contributions()'.
   * @return {!Contributions}
   * @public
   */
  static $create__() {
    Contributions.$clinit();
    let $instance = new Contributions();
    $instance.$ctor__org_dominokit_domino_api_client_extension_Contributions__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Contributions()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_Contributions__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @template M_E
   * @param {Class<M_E>} extensionPointInterface
   * @param {M_E} extensionPoint
   * @return {void}
   * @public
   */
  static m_apply__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPointInterface, extensionPoint) {
    Contributions.$clinit();
    ClientApp.m_make__().m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPointInterface, extensionPoint);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Contributions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Contributions);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Contributions.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Contributions, $Util.$makeClassName('org.dominokit.domino.api.client.extension.Contributions'));




exports = Contributions; 
//# sourceMappingURL=Contributions.js.map