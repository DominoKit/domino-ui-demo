/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.Domino.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.Domino$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Level = goog.forwardDeclare('java.util.logging.Level$impl');
let Logger = goog.forwardDeclare('java.util.logging.Logger$impl');


class Domino extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Domino()'.
   * @return {!Domino}
   * @public
   */
  static $create__() {
    Domino.$clinit();
    let $instance = new Domino();
    $instance.$ctor__org_dominokit_domino_api_client_Domino__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Domino()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_Domino__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    Domino.$f_LOGGER__org_dominokit_domino_api_client_Domino_.m_log__java_util_logging_Level__java_lang_String(Level.f_INFO__java_util_logging_Level, "Domino");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_api_client_Domino_() {
    return (Domino.$clinit(), Domino.$f_LOGGER__org_dominokit_domino_api_client_Domino_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_api_client_Domino_(value) {
    (Domino.$clinit(), Domino.$f_LOGGER__org_dominokit_domino_api_client_Domino_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Domino;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Domino);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Domino.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Level = goog.module.get('java.util.logging.Level$impl');
    Logger = goog.module.get('java.util.logging.Logger$impl');
    j_l_Object.$clinit();
    Domino.$f_LOGGER__org_dominokit_domino_api_client_Domino_ = Logger.m_getLogger__java_lang_String(Class.$get(Domino).m_getName__());
  }
  
  
};

$Util.$setClassMetadata(Domino, $Util.$makeClassName('org.dominokit.domino.api.client.Domino'));


/** @private {Logger} */
Domino.$f_LOGGER__org_dominokit_domino_api_client_Domino_;




exports = Domino; 
//# sourceMappingURL=Domino.js.map