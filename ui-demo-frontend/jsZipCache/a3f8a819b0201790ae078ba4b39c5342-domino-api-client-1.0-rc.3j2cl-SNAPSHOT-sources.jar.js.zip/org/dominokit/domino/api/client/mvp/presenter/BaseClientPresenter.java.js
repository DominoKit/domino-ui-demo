/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ClientPresenter');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');
const _Contributions = goog.require('org.dominokit.domino.api.client.extension.Contributions');
const _PresenterState = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresenterState');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _DominoHistory = goog.require('org.dominokit.domino.api.shared.history.DominoHistory');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');
exports = BaseClientPresenter;
 