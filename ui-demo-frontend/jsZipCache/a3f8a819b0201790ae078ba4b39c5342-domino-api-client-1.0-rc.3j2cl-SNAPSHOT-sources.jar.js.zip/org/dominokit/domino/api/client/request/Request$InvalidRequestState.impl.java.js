/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$InvalidRequestState.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Request.InvalidRequestState$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class InvalidRequestState extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'InvalidRequestState(String)'.
   * @param {?string} message
   * @return {!InvalidRequestState}
   * @public
   */
  static $create__java_lang_String(message) {
    InvalidRequestState.$clinit();
    let $instance = new InvalidRequestState();
    $instance.$ctor__org_dominokit_domino_api_client_request_Request_InvalidRequestState__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InvalidRequestState(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Request_InvalidRequestState__java_lang_String(message) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InvalidRequestState;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InvalidRequestState);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InvalidRequestState.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InvalidRequestState, $Util.$makeClassName('org.dominokit.domino.api.client.request.Request$InvalidRequestState'));


/** @public {!$Long} @const */
InvalidRequestState.f_serialVersionUID__org_dominokit_domino_api_client_request_Request_InvalidRequestState_ = $Long.fromBits(1184902670, 460156274) /* 1976356149064117774 */;




exports = InvalidRequestState; 
//# sourceMappingURL=Request$InvalidRequestState.js.map