/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasRequestRestSendersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasHistory = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasHistory$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository.$LambdaAdaptor$impl');
let AppHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.AppHistory$impl');


/**
 * @interface
 */
class HasRequestRestSendersRepository {
  /**
   * @abstract
   * @param {AppHistory} history
   * @return {HasHistory}
   * @public
   */
  m_history__org_dominokit_domino_api_shared_history_AppHistory(history) {
  }
  
  /**
   * @param {?function(AppHistory):HasHistory} fn
   * @return {HasRequestRestSendersRepository}
   * @public
   */
  static $adapt(fn) {
    HasRequestRestSendersRepository.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasRequestRestSendersRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasRequestRestSendersRepository.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasRequestRestSendersRepository, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasRequestRestSendersRepository'));


HasRequestRestSendersRepository.$markImplementor(/** @type {Function} */ (HasRequestRestSendersRepository));


exports = HasRequestRestSendersRepository; 
//# sourceMappingURL=ClientApp$HasRequestRestSendersRepository.js.map