/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRouter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRouter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Request = goog.require('org.dominokit.domino.api.client.request.Request');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.request.RequestRouter.$LambdaAdaptor');


// Re-exports the implementation.
var RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter$impl');
exports = RequestRouter;
 