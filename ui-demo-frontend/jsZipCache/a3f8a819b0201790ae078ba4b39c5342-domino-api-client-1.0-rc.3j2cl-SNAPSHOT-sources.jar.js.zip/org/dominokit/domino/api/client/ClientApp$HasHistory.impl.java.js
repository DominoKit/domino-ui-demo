/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasHistory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasHistory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasAsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasHistory.$LambdaAdaptor$impl');
let AsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner$impl');


/**
 * @interface
 */
class HasHistory {
  /**
   * @abstract
   * @param {AsyncRunner} asyncRunner
   * @return {HasAsyncRunner}
   * @public
   */
  m_asyncRunner__org_dominokit_domino_api_client_async_AsyncRunner(asyncRunner) {
  }
  
  /**
   * @param {?function(AsyncRunner):HasAsyncRunner} fn
   * @return {HasHistory}
   * @public
   */
  static $adapt(fn) {
    HasHistory.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasHistory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasHistory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasHistory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasHistory.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasHistory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasHistory, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasHistory'));


HasHistory.$markImplementor(/** @type {Function} */ (HasHistory));


exports = HasHistory; 
//# sourceMappingURL=ClientApp$HasHistory.js.map