/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @abstract
  */
class LazyPresenterLoader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_;
    /** @public {Presentable} */
    this.f_presenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_;
    /** @public {?string} */
    this.f_concreteName__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_;
  }
  
  /**
   * Initialization from constructor 'LazyPresenterLoader(String, String)'.
   * @param {?string} name
   * @param {?string} concreteName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader__java_lang_String__java_lang_String(name, concreteName) {
    this.$ctor__java_lang_Object__();
    this.f_name__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_ = name;
    this.f_concreteName__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_ = concreteName;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_;
  }
  
  /**
   * @return {Presentable}
   * @public
   */
  m_getPresenter__() {
    if (Objects.m_isNull__java_lang_Object(this.f_presenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_)) {
      this.f_presenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_ = this.m_makeInitialized___$p_org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader();
    }
    return this.f_presenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_;
  }
  
  /**
   * @return {Presentable}
   * @public
   */
  m_makeInitialized___$p_org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader() {
    return this.m_make__().m_init__();
  }
  
  /**
   * @abstract
   * @return {Presentable}
   * @public
   */
  m_make__() {
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getConcreteName__() {
    return this.f_concreteName__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_;
  }
  
  /**
   * @override
   * @param {*} other
   * @return {boolean}
   * @public
   */
  equals(other) {
    if ($Equality.$same(this, other)) {
      return true;
    }
    if ($Equality.$same(other, null) || !$Equality.$same(this.m_getClass__(), $Objects.m_getClass__java_lang_Object(other))) {
      return false;
    }
    return j_l_String.m_equals__java_lang_String__java_lang_Object(this.f_name__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_, (/**@type {LazyPresenterLoader} */ ($Casts.$to(other, LazyPresenterLoader))).f_name__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_) && j_l_String.m_equals__java_lang_String__java_lang_Object(this.m_getConcreteName__(), (/**@type {LazyPresenterLoader} */ ($Casts.$to(other, LazyPresenterLoader))).m_getConcreteName__());
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return j_l_String.m_hashCode__java_lang_String(this.f_name__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LazyPresenterLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LazyPresenterLoader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LazyPresenterLoader.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LazyPresenterLoader, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader'));




exports = LazyPresenterLoader; 
//# sourceMappingURL=LazyPresenterLoader.js.map