/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Objects = goog.forwardDeclare('java.util.Objects$impl');
let RequestRestSender = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSender$impl');


/**
 * @abstract
  */
class LazyRequestRestSenderLoader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {RequestRestSender} */
    this.f_sender__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader_;
  }
  
  /**
   * Initialization from constructor 'LazyRequestRestSenderLoader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {RequestRestSender}
   * @public
   */
  m_get__() {
    if (Objects.m_isNull__java_lang_Object(this.f_sender__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader_)) {
      this.f_sender__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader_ = this.m_make__();
    }
    return this.f_sender__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader_;
  }
  
  /**
   * @abstract
   * @return {RequestRestSender}
   * @public
   */
  m_make__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LazyRequestRestSenderLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LazyRequestRestSenderLoader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LazyRequestRestSenderLoader.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LazyRequestRestSenderLoader, $Util.$makeClassName('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader'));




exports = LazyRequestRestSenderLoader; 
//# sourceMappingURL=LazyRequestRestSenderLoader.js.map