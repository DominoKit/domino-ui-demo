/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasViewRepository$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasViewRepository.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasViewRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');

let HasContributionsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasContributionsRepository$impl');
let ContributionsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');


/**
 * @implements {HasViewRepository}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ContributionsRepository):HasContributionsRepository} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(ContributionsRepository):HasContributionsRepository} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(ContributionsRepository):HasContributionsRepository} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {ContributionsRepository} arg0
   * @return {HasContributionsRepository}
   * @public
   */
  m_contributionsRepository__org_dominokit_domino_api_client_extension_ContributionsRepository(arg0) {
    let /** ?function(ContributionsRepository):HasContributionsRepository */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasViewRepository_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasViewRepository$$LambdaAdaptor'));


HasViewRepository.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasViewRepository$$LambdaAdaptor.js.map