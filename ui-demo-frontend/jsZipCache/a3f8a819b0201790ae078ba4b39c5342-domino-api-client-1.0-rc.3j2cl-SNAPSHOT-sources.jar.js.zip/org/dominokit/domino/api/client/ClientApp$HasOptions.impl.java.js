/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasOptions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasOptions$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let CanBuildClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasOptions.$LambdaAdaptor$impl');
let DominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.DominoOptions$impl');


/**
 * @interface
 */
class HasOptions {
  /**
   * @abstract
   * @param {DominoOptions} dominoOptions
   * @return {CanBuildClientApp}
   * @public
   */
  m_dominoOptions__org_dominokit_domino_api_client_DominoOptions(dominoOptions) {
  }
  
  /**
   * @param {?function(DominoOptions):CanBuildClientApp} fn
   * @return {HasOptions}
   * @public
   */
  static $adapt(fn) {
    HasOptions.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasOptions = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasOptions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasOptions;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasOptions.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasOptions.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasOptions, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasOptions'));


HasOptions.$markImplementor(/** @type {Function} */ (HasOptions));


exports = HasOptions; 
//# sourceMappingURL=ClientApp$HasOptions.js.map