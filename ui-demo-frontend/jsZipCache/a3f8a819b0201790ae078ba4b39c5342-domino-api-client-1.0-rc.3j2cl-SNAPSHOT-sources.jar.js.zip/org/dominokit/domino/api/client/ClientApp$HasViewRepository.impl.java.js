/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasViewRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasContributionsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasContributionsRepository$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasViewRepository.$LambdaAdaptor$impl');
let ContributionsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');


/**
 * @interface
 */
class HasViewRepository {
  /**
   * @abstract
   * @param {ContributionsRepository} contributionsRepository
   * @return {HasContributionsRepository}
   * @public
   */
  m_contributionsRepository__org_dominokit_domino_api_client_extension_ContributionsRepository(contributionsRepository) {
  }
  
  /**
   * @param {?function(ContributionsRepository):HasContributionsRepository} fn
   * @return {HasViewRepository}
   * @public
   */
  static $adapt(fn) {
    HasViewRepository.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasViewRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasViewRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasViewRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasViewRepository.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasViewRepository.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasViewRepository, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasViewRepository'));


HasViewRepository.$markImplementor(/** @type {Function} */ (HasViewRepository));


exports = HasViewRepository; 
//# sourceMappingURL=ClientApp$HasViewRepository.js.map