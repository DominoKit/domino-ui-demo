/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.ClientRequestEventFactory$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.ClientRequestEventFactory.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ClientRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory$impl');

let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');


/**
 * @implements {ClientRequestEventFactory}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(PresenterCommand):Event} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(PresenterCommand):Event} */
    this.f_$$fn__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$LambdaAdaptor__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(PresenterCommand):Event} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$LambdaAdaptor__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {PresenterCommand} arg0
   * @return {Event}
   * @public
   */
  m_make__org_dominokit_domino_api_client_request_PresenterCommand(arg0) {
    let /** ?function(PresenterCommand):Event */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_events_ClientRequestEventFactory_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.events.ClientRequestEventFactory$$LambdaAdaptor'));


ClientRequestEventFactory.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientRequestEventFactory$$LambdaAdaptor.js.map