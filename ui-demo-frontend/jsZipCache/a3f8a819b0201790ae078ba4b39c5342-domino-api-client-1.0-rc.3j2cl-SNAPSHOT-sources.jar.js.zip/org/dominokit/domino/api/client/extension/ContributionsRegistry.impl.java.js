/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContributionsRegistry.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry.$LambdaAdaptor$impl');
let Contribution = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');


/**
 * @interface
 */
class ContributionsRegistry {
  /**
   * @abstract
   * @param {Class<?>} extensionPoint
   * @param {Contribution} contribution
   * @return {void}
   * @public
   */
  m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(extensionPoint, contribution) {
  }
  
  /**
   * @param {?function(Class<?>, Contribution):void} fn
   * @return {ContributionsRegistry}
   * @public
   */
  static $adapt(fn) {
    ContributionsRegistry.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContributionsRegistry = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_extension_ContributionsRegistry;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContributionsRegistry;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContributionsRegistry.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.extension.ContributionsRegistry.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ContributionsRegistry, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContributionsRegistry'));


ContributionsRegistry.$markImplementor(/** @type {Function} */ (ContributionsRegistry));


exports = ContributionsRegistry; 
//# sourceMappingURL=ContributionsRegistry.js.map