/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasOptions$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasOptions.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasOptions = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions$impl');

let CanBuildClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp$impl');
let DominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.DominoOptions$impl');


/**
 * @implements {HasOptions}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(DominoOptions):CanBuildClientApp} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(DominoOptions):CanBuildClientApp} */
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasOptions_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_client_ClientApp_HasOptions_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasOptions_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(DominoOptions):CanBuildClientApp} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_HasOptions_$LambdaAdaptor__org_dominokit_domino_api_client_ClientApp_HasOptions_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasOptions_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {DominoOptions} arg0
   * @return {CanBuildClientApp}
   * @public
   */
  m_dominoOptions__org_dominokit_domino_api_client_DominoOptions(arg0) {
    let /** ?function(DominoOptions):CanBuildClientApp */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_api_client_ClientApp_HasOptions_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasOptions$$LambdaAdaptor'));


HasOptions.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ClientApp$HasOptions$$LambdaAdaptor.js.map