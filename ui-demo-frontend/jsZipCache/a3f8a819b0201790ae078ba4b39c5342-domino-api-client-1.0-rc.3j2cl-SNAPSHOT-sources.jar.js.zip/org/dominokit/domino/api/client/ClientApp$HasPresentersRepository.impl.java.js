/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasPresentersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository.$LambdaAdaptor$impl');
let HasViewRepository = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.HasViewRepository$impl');
let ViewsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');


/**
 * @interface
 */
class HasPresentersRepository {
  /**
   * @abstract
   * @param {ViewsRepository} viewsRepository
   * @return {HasViewRepository}
   * @public
   */
  m_viewsRepository__org_dominokit_domino_api_client_mvp_view_ViewsRepository(viewsRepository) {
  }
  
  /**
   * @param {?function(ViewsRepository):HasViewRepository} fn
   * @return {HasPresentersRepository}
   * @public
   */
  static $adapt(fn) {
    HasPresentersRepository.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_HasPresentersRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasPresentersRepository.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasPresentersRepository, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$HasPresentersRepository'));


HasPresentersRepository.$markImplementor(/** @type {Function} */ (HasPresentersRepository));


exports = HasPresentersRepository; 
//# sourceMappingURL=ClientApp$HasPresentersRepository.js.map