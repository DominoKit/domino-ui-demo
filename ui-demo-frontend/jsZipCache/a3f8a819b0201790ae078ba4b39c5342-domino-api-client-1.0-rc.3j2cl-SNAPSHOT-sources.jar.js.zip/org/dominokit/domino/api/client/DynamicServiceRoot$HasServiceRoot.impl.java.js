/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.DynamicServiceRoot$HasServiceRoot.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasServiceRoot {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_onMatch__() {
  }
  
  /**
   * @param {?function():?string} fn
   * @return {HasServiceRoot}
   * @public
   */
  static $adapt(fn) {
    HasServiceRoot.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_DynamicServiceRoot_HasServiceRoot;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasServiceRoot.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.DynamicServiceRoot.HasServiceRoot.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasServiceRoot, $Util.$makeClassName('org.dominokit.domino.api.client.DynamicServiceRoot$HasServiceRoot'));


HasServiceRoot.$markImplementor(/** @type {Function} */ (HasServiceRoot));


exports = HasServiceRoot; 
//# sourceMappingURL=DynamicServiceRoot$HasServiceRoot.js.map