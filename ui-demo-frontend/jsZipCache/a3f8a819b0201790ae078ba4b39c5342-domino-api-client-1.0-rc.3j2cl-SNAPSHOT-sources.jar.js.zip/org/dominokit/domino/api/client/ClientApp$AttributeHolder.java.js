/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$AttributeHolder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.AttributeHolder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var AttributeHolder = goog.require('org.dominokit.domino.api.client.ClientApp.AttributeHolder$impl');
exports = AttributeHolder;
 