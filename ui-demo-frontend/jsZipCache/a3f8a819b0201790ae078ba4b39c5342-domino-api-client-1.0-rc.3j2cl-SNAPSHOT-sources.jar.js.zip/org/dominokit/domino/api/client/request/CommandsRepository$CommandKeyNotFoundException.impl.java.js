/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CommandsRepository$CommandKeyNotFoundException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.CommandsRepository.CommandKeyNotFoundException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CommandKeyNotFoundException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CommandKeyNotFoundException(String)'.
   * @param {?string} message
   * @return {!CommandKeyNotFoundException}
   * @public
   */
  static $create__java_lang_String(message) {
    CommandKeyNotFoundException.$clinit();
    let $instance = new CommandKeyNotFoundException();
    $instance.$ctor__org_dominokit_domino_api_client_request_CommandsRepository_CommandKeyNotFoundException__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CommandKeyNotFoundException(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_CommandsRepository_CommandKeyNotFoundException__java_lang_String(message) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CommandKeyNotFoundException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CommandKeyNotFoundException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CommandKeyNotFoundException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CommandKeyNotFoundException, $Util.$makeClassName('org.dominokit.domino.api.client.request.CommandsRepository$CommandKeyNotFoundException'));


/** @public {!$Long} @const */
CommandKeyNotFoundException.f_serialVersionUID__org_dominokit_domino_api_client_request_CommandsRepository_CommandKeyNotFoundException_ = $Long.fromBits(334776110, -1416650704) /* -6084468443200600274 */;




exports = CommandKeyNotFoundException; 
//# sourceMappingURL=CommandsRepository$CommandKeyNotFoundException.js.map