/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.ClientRequestEventFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.ClientRequestEventFactory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.events.ClientRequestEventFactory.$LambdaAdaptor$impl');
let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');


/**
 * @interface
 */
class ClientRequestEventFactory {
  /**
   * @abstract
   * @param {PresenterCommand} request
   * @return {Event}
   * @public
   */
  m_make__org_dominokit_domino_api_client_request_PresenterCommand(request) {
  }
  
  /**
   * @param {?function(PresenterCommand):Event} fn
   * @return {ClientRequestEventFactory}
   * @public
   */
  static $adapt(fn) {
    ClientRequestEventFactory.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_ClientRequestEventFactory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_events_ClientRequestEventFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_ClientRequestEventFactory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientRequestEventFactory.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.events.ClientRequestEventFactory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ClientRequestEventFactory, $Util.$makeClassName('org.dominokit.domino.api.client.events.ClientRequestEventFactory'));


ClientRequestEventFactory.$markImplementor(/** @type {Function} */ (ClientRequestEventFactory));


exports = ClientRequestEventFactory; 
//# sourceMappingURL=ClientRequestEventFactory.js.map