/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.EventsBus.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.EventsBus$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus.$LambdaAdaptor$impl');
let RequestEvent = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus.RequestEvent$impl');


/**
 * @interface
 * @template C_T
 */
class EventsBus {
  /**
   * @abstract
   * @param {RequestEvent<C_T>} event
   * @return {void}
   * @public
   */
  m_publishEvent__org_dominokit_domino_api_client_events_EventsBus_RequestEvent(event) {
  }
  
  /**
   * @template C_T
   * @param {?function(RequestEvent<C_T>):void} fn
   * @return {EventsBus<C_T>}
   * @public
   */
  static $adapt(fn) {
    EventsBus.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_EventsBus = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_events_EventsBus;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_EventsBus;
  }
  
  /**
   * @public
   */
  static $clinit() {
    EventsBus.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.events.EventsBus.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(EventsBus, $Util.$makeClassName('org.dominokit.domino.api.client.events.EventsBus'));


EventsBus.$markImplementor(/** @type {Function} */ (EventsBus));


exports = EventsBus; 
//# sourceMappingURL=EventsBus.js.map