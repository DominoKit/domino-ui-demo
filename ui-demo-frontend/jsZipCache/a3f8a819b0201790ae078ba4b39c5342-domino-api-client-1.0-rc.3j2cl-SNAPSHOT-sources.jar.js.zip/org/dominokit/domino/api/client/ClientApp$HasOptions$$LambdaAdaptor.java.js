/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasOptions$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasOptions.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasOptions = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions');
const _CanBuildClientApp = goog.require('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp');
const _DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 