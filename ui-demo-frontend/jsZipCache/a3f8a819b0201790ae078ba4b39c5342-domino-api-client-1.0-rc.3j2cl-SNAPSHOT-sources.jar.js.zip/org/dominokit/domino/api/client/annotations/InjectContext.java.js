/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.InjectContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.annotations.InjectContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');


// Re-exports the implementation.
var InjectContext = goog.require('org.dominokit.domino.api.client.annotations.InjectContext$impl');
exports = InjectContext;
 