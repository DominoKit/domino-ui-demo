/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.PresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.PresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseRequest = goog.require('org.dominokit.domino.api.client.request.BaseRequest$impl');

let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DefaultRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext$impl');
let RequestState = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestState$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_P
  */
class PresenterCommand extends BaseRequest {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {PresenterHandler<C_P>} */
    this.f_handler__org_dominokit_domino_api_client_request_PresenterCommand_;
    /** @public {RequestState<DefaultRequestStateContext>} */
    this.f_sent__org_dominokit_domino_api_client_request_PresenterCommand_;
  }
  
  /**
   * Initialization from constructor 'PresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_PresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_BaseRequest__();
    this.$init__org_dominokit_domino_api_client_request_PresenterCommand();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_startRouting__() {
    this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_sent__org_dominokit_domino_api_client_request_PresenterCommand_;
    this.f_clientApp__org_dominokit_domino_api_client_request_BaseRequest.m_getClientRouter__().m_routeRequest__org_dominokit_domino_api_client_request_Request(this);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_send__() {
    this.m_execute__();
  }
  
  /**
   * @param {PresenterHandler<C_P>} presenterHandler
   * @return {PresenterCommand<C_P>}
   * @public
   */
  m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(presenterHandler) {
    this.f_handler__org_dominokit_domino_api_client_request_PresenterCommand_ = presenterHandler;
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getKey__() {
    return this.f_key__org_dominokit_domino_api_client_request_BaseRequest;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_request_PresenterCommand() {
    this.f_handler__org_dominokit_domino_api_client_request_PresenterCommand_ = /**@type {PresenterHandler<C_P>} */ (PresenterHandler.$adapt(((/** Presentable */ presenter) =>{
    })));
    this.f_sent__org_dominokit_domino_api_client_request_PresenterCommand_ = RequestState.$adapt(((/** DefaultRequestStateContext */ context) =>{
      this.f_handler__org_dominokit_domino_api_client_request_PresenterCommand_.m_onReady__java_lang_Object(/**@type {Presentable} */ ($Casts.$to(this.m_getRequestPresenter__(), Presentable)));
      this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_completed__org_dominokit_domino_api_client_request_BaseRequest;
    }));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PresenterCommand.$clinit = function() {};
    Presentable = goog.module.get('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    RequestState = goog.module.get('org.dominokit.domino.api.client.request.RequestState$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseRequest.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PresenterCommand, $Util.$makeClassName('org.dominokit.domino.api.client.request.PresenterCommand'));




exports = PresenterCommand; 
//# sourceMappingURL=PresenterCommand.js.map