/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.RequestRestSender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.RequestRestSender$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Map = goog.forwardDeclare('java.util.Map$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSender.$LambdaAdaptor$impl');
let ServerRequestCallBack = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequestCallBack$impl');
let RequestBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.RequestBean$impl');


/**
 * @interface
 * @template C_T
 */
class RequestRestSender {
  /**
   * @abstract
   * @param {C_T} request
   * @param {Map<?string, ?string>} headers
   * @param {ServerRequestCallBack} callBack
   * @return {void}
   * @public
   */
  m_send__org_dominokit_domino_api_shared_request_RequestBean__java_util_Map__org_dominokit_domino_api_client_request_ServerRequestCallBack(request, headers, callBack) {
  }
  
  /**
   * @template C_T
   * @param {?function(C_T, Map<?string, ?string>, ServerRequestCallBack):void} fn
   * @return {RequestRestSender<C_T>}
   * @public
   */
  static $adapt(fn) {
    RequestRestSender.$clinit();
    return /**@type {!$LambdaAdaptor<RequestBean>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestRestSender = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_RequestRestSender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_RequestRestSender;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestRestSender.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.RequestRestSender.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestRestSender, $Util.$makeClassName('org.dominokit.domino.api.client.request.RequestRestSender'));


RequestRestSender.$markImplementor(/** @type {Function} */ (RequestRestSender));


exports = RequestRestSender; 
//# sourceMappingURL=RequestRestSender.js.map