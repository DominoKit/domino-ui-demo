/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.ClientPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.ClientPresenter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');


/**
 * @abstract
 * @template C_V
  */
class ClientPresenter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'ClientPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_ClientPresenter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {C_V} view
   * @return {void}
   * @public
   */
  m_initView__org_dominokit_domino_api_client_mvp_view_View(view) {
  }
  
  /**
   * @abstract
   * @return {ClientPresenter<C_V>}
   * @public
   */
  m_prepare__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientPresenter.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ClientPresenter, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.ClientPresenter'));




exports = ClientPresenter; 
//# sourceMappingURL=ClientPresenter.js.map