/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$ClientAppBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.ClientAppBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _CanBuildClientApp = goog.require('org.dominokit.domino.api.client.ClientApp.CanBuildClientApp');
const _HasAsyncRunner = goog.require('org.dominokit.domino.api.client.ClientApp.HasAsyncRunner');
const _HasClientRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasClientRouter');
const _HasContributionsRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasContributionsRepository');
const _HasEventBus = goog.require('org.dominokit.domino.api.client.ClientApp.HasEventBus');
const _HasHistory = goog.require('org.dominokit.domino.api.client.ClientApp.HasHistory');
const _HasOptions = goog.require('org.dominokit.domino.api.client.ClientApp.HasOptions');
const _HasPresentersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository');
const _HasRequestRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRepository');
const _HasRequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository');
const _HasServerRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasServerRouter');
const _HasViewRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasViewRepository');
const _LinkedList = goog.require('java.util.LinkedList');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _ClientStartupTask = goog.require('org.dominokit.domino.api.client.ClientStartupTask');
const _DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions');
const _AsyncRunner = goog.require('org.dominokit.domino.api.client.async.AsyncRunner');
const _EventsBus = goog.require('org.dominokit.domino.api.client.events.EventsBus');
const _ContributionsRepository = goog.require('org.dominokit.domino.api.client.extension.ContributionsRepository');
const _PresentersRepository = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository');
const _ViewsRepository = goog.require('org.dominokit.domino.api.client.mvp.view.ViewsRepository');
const _CommandsRepository = goog.require('org.dominokit.domino.api.client.request.CommandsRepository');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _RequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository');
const _RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _MainExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.MainExtensionPoint');
const _AppHistory = goog.require('org.dominokit.domino.api.shared.history.AppHistory');


// Re-exports the implementation.
var ClientAppBuilder = goog.require('org.dominokit.domino.api.client.ClientApp.ClientAppBuilder$impl');
exports = ClientAppBuilder;
 