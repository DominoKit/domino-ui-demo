/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.ClientRequestEventFactory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.events.ClientRequestEventFactory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory.$LambdaAdaptor');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');


// Re-exports the implementation.
var ClientRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ClientRequestEventFactory$impl');
exports = ClientRequestEventFactory;
 