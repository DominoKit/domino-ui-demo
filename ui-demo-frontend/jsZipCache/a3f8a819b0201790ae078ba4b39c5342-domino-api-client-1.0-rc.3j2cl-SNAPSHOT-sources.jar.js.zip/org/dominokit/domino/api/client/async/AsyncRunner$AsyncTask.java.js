/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.async.AsyncRunner$AsyncTask.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Throwable = goog.require('java.lang.Throwable');
const _AsyncRunner = goog.require('org.dominokit.domino.api.client.async.AsyncRunner');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask.$LambdaAdaptor');


// Re-exports the implementation.
var AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
exports = AsyncTask;
 