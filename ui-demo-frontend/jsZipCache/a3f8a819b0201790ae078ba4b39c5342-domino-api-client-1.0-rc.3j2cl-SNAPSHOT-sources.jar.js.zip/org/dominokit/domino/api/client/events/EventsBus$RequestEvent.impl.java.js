/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.EventsBus$RequestEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.EventsBus.RequestEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus.RequestEvent.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_RequestEvent_T
 */
class RequestEvent {
  /**
   * @abstract
   * @return {C_RequestEvent_T}
   * @public
   */
  m_asEvent__() {
  }
  
  /**
   * @template C_RequestEvent_T
   * @param {?function():C_RequestEvent_T} fn
   * @return {RequestEvent<C_RequestEvent_T>}
   * @public
   */
  static $adapt(fn) {
    RequestEvent.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_EventsBus_RequestEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_events_EventsBus_RequestEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_EventsBus_RequestEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.events.EventsBus.RequestEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestEvent, $Util.$makeClassName('org.dominokit.domino.api.client.events.EventsBus$RequestEvent'));


RequestEvent.$markImplementor(/** @type {Function} */ (RequestEvent));


exports = RequestEvent; 
//# sourceMappingURL=EventsBus$RequestEvent.js.map