/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.BaseRequest.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.BaseRequest');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Request = goog.require('org.dominokit.domino.api.client.request.Request');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _DefaultRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext');
const _InvalidRequestState = goog.require('org.dominokit.domino.api.client.request.Request.InvalidRequestState');
const _RequestState = goog.require('org.dominokit.domino.api.client.request.RequestState');
const _RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var BaseRequest = goog.require('org.dominokit.domino.api.client.request.BaseRequest$impl');
exports = BaseRequest;
 