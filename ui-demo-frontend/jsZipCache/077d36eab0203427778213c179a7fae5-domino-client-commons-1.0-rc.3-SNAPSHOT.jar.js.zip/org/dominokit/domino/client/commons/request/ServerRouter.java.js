/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.ServerRouter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.request.ServerRouter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter');
const _Request = goog.require('org.dominokit.domino.api.client.request.Request');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _RequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.RequestAsyncSender');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ServerRouter = goog.require('org.dominokit.domino.client.commons.request.ServerRouter$impl');
exports = ServerRouter;
 