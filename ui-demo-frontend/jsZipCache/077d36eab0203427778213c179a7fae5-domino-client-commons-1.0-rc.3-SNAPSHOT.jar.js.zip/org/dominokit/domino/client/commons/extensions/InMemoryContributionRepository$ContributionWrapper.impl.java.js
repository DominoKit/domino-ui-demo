/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository$ContributionWrapper.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository.ContributionWrapper$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Contribution = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution$impl');
let InMemoryContributionRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


class ContributionWrapper extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {InMemoryContributionRepository} */
    this.f_$outer_this__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper;
    /** @public {Contribution} */
    this.f_contribution__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContributionWrapper(InMemoryContributionRepository, Contribution)'.
   * @param {InMemoryContributionRepository} $outer_this
   * @param {Contribution} contribution
   * @return {!ContributionWrapper}
   * @public
   */
  static $create__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository__org_dominokit_domino_api_shared_extension_Contribution($outer_this, contribution) {
    ContributionWrapper.$clinit();
    let $instance = new ContributionWrapper();
    $instance.$ctor__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository__org_dominokit_domino_api_shared_extension_Contribution($outer_this, contribution);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContributionWrapper(InMemoryContributionRepository, Contribution)'.
   * @param {InMemoryContributionRepository} $outer_this
   * @param {Contribution} contribution
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository__org_dominokit_domino_api_shared_extension_Contribution($outer_this, contribution) {
    this.f_$outer_this__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_contribution__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper_ = contribution;
  }
  
  /**
   * @override
   * @param {*} other
   * @return {boolean}
   * @public
   */
  equals(other) {
    if (Objects.m_isNull__java_lang_Object(other)) {
      return false;
    }
    return j_l_String.m_equals__java_lang_String__java_lang_Object($Objects.m_getClass__java_lang_Object(this.f_contribution__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper_).m_getCanonicalName__(), $Objects.m_getClass__java_lang_Object((/**@type {ContributionWrapper} */ ($Casts.$to(other, ContributionWrapper))).f_contribution__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper_).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return j_l_String.m_hashCode__java_lang_String($Objects.m_getClass__java_lang_Object(this.f_contribution__org_dominokit_domino_client_commons_extensions_InMemoryContributionRepository_ContributionWrapper_).m_getCanonicalName__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContributionWrapper;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContributionWrapper);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContributionWrapper.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContributionWrapper, $Util.$makeClassName('org.dominokit.domino.client.commons.extensions.InMemoryContributionRepository$ContributionWrapper'));




exports = ContributionWrapper; 
//# sourceMappingURL=InMemoryContributionRepository$ContributionWrapper.js.map