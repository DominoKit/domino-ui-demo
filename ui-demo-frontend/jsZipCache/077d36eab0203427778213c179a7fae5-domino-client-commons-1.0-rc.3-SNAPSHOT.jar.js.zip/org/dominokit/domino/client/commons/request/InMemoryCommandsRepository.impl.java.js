/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.InMemoryCommandsRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CommandsRepository = goog.require('org.dominokit.domino.api.client.request.CommandsRepository$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let CommandCannotBeRegisteredMoreThanOnce = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository.CommandCannotBeRegisteredMoreThanOnce$impl');
let CommandKeyNotFoundException = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository.CommandKeyNotFoundException$impl');
let RequestHolder = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestHolder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {CommandsRepository}
  */
class InMemoryCommandsRepository extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HashMap<?string, RequestHolder>} */
    this.f_requestPresenterWrappers__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository_;
  }
  
  /**
   * Factory method corresponding to constructor 'InMemoryCommandsRepository()'.
   * @return {!InMemoryCommandsRepository}
   * @public
   */
  static $create__() {
    InMemoryCommandsRepository.$clinit();
    let $instance = new InMemoryCommandsRepository();
    $instance.$ctor__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InMemoryCommandsRepository()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository();
  }
  
  /**
   * @override
   * @param {RequestHolder} requestHolder
   * @return {void}
   * @public
   */
  m_registerCommand__org_dominokit_domino_api_client_request_RequestHolder(requestHolder) {
    if (this.m_isRegisteredRequest__java_lang_String_$p_org_dominokit_domino_client_commons_request_InMemoryCommandsRepository(requestHolder.m_getRequestName__())) {
      throw $Exceptions.toJs(CommandCannotBeRegisteredMoreThanOnce.$create__java_lang_String("Request key [" + j_l_String.m_valueOf__java_lang_Object(requestHolder.m_getRequestName__()) + "]"));
    }
    this.f_requestPresenterWrappers__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository_.put(requestHolder.m_getRequestName__(), requestHolder);
  }
  
  /**
   * @override
   * @param {?string} requestName
   * @return {RequestHolder}
   * @public
   */
  m_findRequestPresenterWrapper__java_lang_String(requestName) {
    if (this.m_isRegisteredRequest__java_lang_String_$p_org_dominokit_domino_client_commons_request_InMemoryCommandsRepository(requestName)) {
      return /**@type {RequestHolder} */ ($Casts.$to(this.f_requestPresenterWrappers__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository_.get(requestName), RequestHolder));
    }
    throw $Exceptions.toJs(CommandKeyNotFoundException.$create__java_lang_String("Request Key [" + j_l_String.m_valueOf__java_lang_Object(requestName) + "]"));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_requestPresenterWrappers__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository_.clear();
  }
  
  /**
   * @param {?string} requestName
   * @return {boolean}
   * @public
   */
  m_isRegisteredRequest__java_lang_String_$p_org_dominokit_domino_client_commons_request_InMemoryCommandsRepository(requestName) {
    return this.f_requestPresenterWrappers__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository_.containsKey(requestName);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository() {
    this.f_requestPresenterWrappers__org_dominokit_domino_client_commons_request_InMemoryCommandsRepository_ = /**@type {!HashMap<?string, RequestHolder>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InMemoryCommandsRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InMemoryCommandsRepository);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InMemoryCommandsRepository.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    CommandCannotBeRegisteredMoreThanOnce = goog.module.get('org.dominokit.domino.api.client.request.CommandsRepository.CommandCannotBeRegisteredMoreThanOnce$impl');
    CommandKeyNotFoundException = goog.module.get('org.dominokit.domino.api.client.request.CommandsRepository.CommandKeyNotFoundException$impl');
    RequestHolder = goog.module.get('org.dominokit.domino.api.client.request.RequestHolder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InMemoryCommandsRepository, $Util.$makeClassName('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository'));


CommandsRepository.$markImplementor(InMemoryCommandsRepository);


exports = InMemoryCommandsRepository; 
//# sourceMappingURL=InMemoryCommandsRepository.js.map