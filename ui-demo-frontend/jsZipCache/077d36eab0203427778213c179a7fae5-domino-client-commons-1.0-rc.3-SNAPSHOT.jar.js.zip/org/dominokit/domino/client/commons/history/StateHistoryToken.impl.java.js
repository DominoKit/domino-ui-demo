/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.history.StateHistoryToken.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Entry = goog.forwardDeclare('java.util.Map.Entry$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let IntPredicate = goog.forwardDeclare('java.util.function.IntPredicate$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Supplier = goog.forwardDeclare('java.util.function.Supplier$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let IntStream = goog.forwardDeclare('java.util.stream.IntStream$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let TokenCannotBeNullException = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken.TokenCannotBeNullException$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $int = goog.forwardDeclare('vmbootstrap.primitives.$int$impl');


/**
 * @implements {HistoryToken}
  */
class StateHistoryToken extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {List<?string>} */
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_;
    /** @public {Map<?string, ?string>} */
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_;
    /** @public {List<?string>} */
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_;
  }
  
  /**
   * Factory method corresponding to constructor 'StateHistoryToken(String)'.
   * @param {?string} token
   * @return {!StateHistoryToken}
   * @public
   */
  static $create__java_lang_String(token) {
    StateHistoryToken.$clinit();
    let $instance = new StateHistoryToken();
    $instance.$ctor__org_dominokit_domino_client_commons_history_StateHistoryToken__java_lang_String(token);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StateHistoryToken(String)'.
   * @param {?string} token
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_history_StateHistoryToken__java_lang_String(token) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_history_StateHistoryToken();
    if (Objects.m_isNull__java_lang_Object(token)) {
      throw $Exceptions.toJs(TokenCannotBeNullException.$create__());
    }
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.addAll(this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token));
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.putAll(this.m_asQueryParameters__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token));
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.addAll(this.m_parseFragments__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token));
  }
  
  /**
   * @param {?string} token
   * @param {?string} root
   * @return {?string}
   * @public
   */
  m_getPathToRoot__java_lang_String__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token, root) {
    if (j_l_String.m_isEmpty__java_lang_String(token)) {
      return root;
    }
    return j_l_String.m_endsWith__java_lang_String__java_lang_String(token, "/") ? j_l_String.m_valueOf__java_lang_Object(token) + j_l_String.m_valueOf__java_lang_Object(root) : j_l_String.m_valueOf__java_lang_Object(token) + "/" + j_l_String.m_valueOf__java_lang_Object(root);
  }
  
  /**
   * @param {?string} token
   * @return {List<?string>}
   * @public
   */
  m_parseFragments__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token) {
    if (j_l_String.m_contains__java_lang_String__java_lang_CharSequence(token, "#")) {
      return this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(j_l_String.m_split__java_lang_String__java_lang_String(token, StateHistoryToken.f_FRAGMENT_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_)[1]);
    }
    return /**@type {!LinkedList<?string>} */ (LinkedList.$create__());
  }
  
  /**
   * @override
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_startsWithPath__java_lang_String(path) {
    if (this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path)) {
      return false;
    }
    return this.m_startsWith__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_paths__(), this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path));
  }
  
  /**
   * @override
   * @param {?string} fragment
   * @return {boolean}
   * @public
   */
  m_fragmentsStartsWith__java_lang_String(fragment) {
    if (this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment)) {
      return false;
    }
    return this.m_startsWith__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_fragments__(), this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment));
  }
  
  /**
   * @param {List<?string>} paths
   * @param {List<?string>} targets
   * @return {boolean}
   * @public
   */
  m_startsWith__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets) {
    if (this.m_isValidSize__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets)) {
      return IntStream.m_range__int__int(0, targets.size()).m_allMatch__java_util_function_IntPredicate(IntPredicate.$adapt(((/** number */ i) =>{
        return j_l_String.m_equals__java_lang_String__java_lang_Object(/**@type {?string} */ ($Casts.$to(targets.getAtIndex(i), j_l_String)), paths.getAtIndex(i));
      })));
    }
    return false;
  }
  
  /**
   * @override
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_endsWithPath__java_lang_String(path) {
    if (this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path)) {
      return false;
    }
    return this.m_endsWith__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_paths__(), this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path));
  }
  
  /**
   * @override
   * @param {?string} fragment
   * @return {boolean}
   * @public
   */
  m_endsWithFragment__java_lang_String(fragment) {
    if (this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment)) {
      return false;
    }
    return this.m_endsWith__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_fragments__(), this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment));
  }
  
  /**
   * @param {List<?string>} paths
   * @param {List<?string>} targets
   * @return {boolean}
   * @public
   */
  m_endsWith__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets) {
    if (this.m_isValidSize__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets)) {
      return this.m_matchEnds__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets);
    }
    return false;
  }
  
  /**
   * @param {List<?string>} paths
   * @param {List<?string>} targets
   * @return {boolean}
   * @public
   */
  m_matchEnds__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets) {
    let offset = paths.size() - targets.size();
    return IntStream.m_range__int__int(0, targets.size()).m_allMatch__java_util_function_IntPredicate(IntPredicate.$adapt(((/** number */ i) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(/**@type {?string} */ ($Casts.$to(targets.getAtIndex(i), j_l_String)), paths.getAtIndex(i + offset));
    })));
  }
  
  /**
   * @override
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_containsPath__java_lang_String(path) {
    if (this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path)) {
      return false;
    }
    return this.m_contains__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_paths__(), this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path));
  }
  
  /**
   * @override
   * @param {?string} fragment
   * @return {boolean}
   * @public
   */
  m_containsFragment__java_lang_String(fragment) {
    if (this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment)) {
      return false;
    }
    return this.m_contains__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_fragments__(), this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment));
  }
  
  /**
   * @param {List<?string>} paths
   * @param {List<?string>} targets
   * @return {boolean}
   * @public
   */
  m_contains__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets) {
    return IntStream.m_rangeClosed__int__int(0, paths.size() - targets.size()).m_anyMatch__java_util_function_IntPredicate(IntPredicate.$adapt(((/** number */ i) =>{
      return this.m_isOrderedEquals__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths.subList(i, i + targets.size()), targets);
    })));
  }
  
  /**
   * @param {List<?string>} subList
   * @param {List<?string>} targets
   * @return {boolean}
   * @public
   */
  m_isOrderedEquals__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(subList, targets) {
    return IntStream.m_of__arrayOf_int(/**@type {!Array<number>} */ ($Arrays.$init([0, subList.size() - 1], $int))).m_allMatch__java_util_function_IntPredicate(IntPredicate.$adapt(((/** number */ i) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(/**@type {?string} */ ($Casts.$to(subList.getAtIndex(i), j_l_String)), targets.getAtIndex(i));
    })));
  }
  
  /**
   * @override
   * @return {List<?string>}
   * @public
   */
  m_paths__() {
    return this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_;
  }
  
  /**
   * @override
   * @return {List<?string>}
   * @public
   */
  m_fragments__() {
    return this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_path__() {
    return j_l_String.m_join__java_lang_CharSequence__java_lang_Iterable("/", this.m_paths__());
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_query__() {
    return /**@type {?string} */ ($Casts.$to(/**@type {Stream<?string>} */ (this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.m_entrySet__().m_stream__().m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** Entry<?string, ?string> */ entry) =>{
      return j_l_String.m_valueOf__java_lang_Object(/**@type {?string} */ ($Casts.$to(entry.m_getKey__(), j_l_String))) + "=" + j_l_String.m_valueOf__java_lang_Object(/**@type {?string} */ ($Casts.$to(entry.m_getValue__(), j_l_String)));
    })))).m_collect__java_util_stream_Collector(Collectors.m_joining__java_lang_CharSequence("&")), j_l_String));
  }
  
  /**
   * @override
   * @param {?string} name
   * @return {boolean}
   * @public
   */
  m_hasQueryParameter__java_lang_String(name) {
    return this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.containsKey(name);
  }
  
  /**
   * @override
   * @return {Map<?string, ?string>}
   * @public
   */
  m_queryParameters__() {
    return this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_;
  }
  
  /**
   * @override
   * @param {?string} name
   * @return {?string}
   * @public
   */
  m_parameterValue__java_lang_String(name) {
    return /**@type {?string} */ ($Casts.$to(this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.get(name), j_l_String));
  }
  
  /**
   * @override
   * @param {?string} path
   * @return {HistoryToken}
   * @public
   */
  m_appendPath__java_lang_String(path) {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.addAll(this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path));
    return this;
  }
  
  /**
   * @override
   * @param {?string} fragment
   * @return {HistoryToken}
   * @public
   */
  m_appendFragment__java_lang_String(fragment) {
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.addAll(this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment));
    return this;
  }
  
  /**
   * @override
   * @param {?string} name
   * @param {?string} value
   * @return {HistoryToken}
   * @public
   */
  m_appendParameter__java_lang_String__java_lang_String(name, value) {
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.put(Objects.m_isNull__java_lang_Object(name) ? "null" : name, Objects.m_isNull__java_lang_Object(value) ? "null" : value);
    return this;
  }
  
  /**
   * @override
   * @param {?string} path
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replacePath__java_lang_String__java_lang_String(path, replacement) {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_ = this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(this.m_path__(), path, replacement));
    return this;
  }
  
  /**
   * @override
   * @param {?string} fragment
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replaceFragment__java_lang_String__java_lang_String(fragment, replacement) {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_ = this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(this.m_fragment__(), fragment, replacement));
    return this;
  }
  
  /**
   * @override
   * @param {?string} name
   * @param {?string} replacementName
   * @param {?string} replacementValue
   * @return {HistoryToken}
   * @public
   */
  m_replaceParameter__java_lang_String__java_lang_String__java_lang_String(name, replacementName, replacementValue) {
    if (this.m_hasQueryParameter__java_lang_String(name)) {
      this.m_appendParameter__java_lang_String__java_lang_String(replacementName, replacementValue);
      this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.remove(name);
    }
    return this;
  }
  
  /**
   * @override
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replaceLastPath__java_lang_String(replacement) {
    if (!this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.isEmpty()) {
      this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.removeAtIndex(this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.size() - 1);
      this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.add(replacement);
    }
    return this;
  }
  
  /**
   * @override
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replaceLastFragment__java_lang_String(replacement) {
    if (!this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.isEmpty()) {
      this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.removeAtIndex(this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.size() - 1);
      this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.add(replacement);
    }
    return this;
  }
  
  /**
   * @override
   * @param {?string} newPath
   * @return {HistoryToken}
   * @public
   */
  m_replaceAllPaths__java_lang_String(newPath) {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_ = this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(newPath);
    return this;
  }
  
  /**
   * @override
   * @param {?string} newFragment
   * @return {HistoryToken}
   * @public
   */
  m_replaceAllFragments__java_lang_String(newFragment) {
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_ = this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(newFragment);
    return this;
  }
  
  /**
   * @override
   * @param {?string} newQuery
   * @return {HistoryToken}
   * @public
   */
  m_replaceQuery__java_lang_String(newQuery) {
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_ = this.m_parsedParameters__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(newQuery);
    return this;
  }
  
  /**
   * @override
   * @return {HistoryToken}
   * @public
   */
  m_clearQuery__() {
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.clear();
    return this;
  }
  
  /**
   * @override
   * @param {?string} name
   * @return {HistoryToken}
   * @public
   */
  m_removeParameter__java_lang_String(name) {
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_.remove(name);
    return this;
  }
  
  /**
   * @override
   * @return {HistoryToken}
   * @public
   */
  m_clearPaths__() {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.clear();
    return this;
  }
  
  /**
   * @override
   * @return {HistoryToken}
   * @public
   */
  m_clearFragments__() {
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.clear();
    return this;
  }
  
  /**
   * @override
   * @param {?string} path
   * @return {HistoryToken}
   * @public
   */
  m_removePath__java_lang_String(path) {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_.removeAll(this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path));
    return this;
  }
  
  /**
   * @override
   * @param {?string} fragment
   * @return {HistoryToken}
   * @public
   */
  m_removeFragment__java_lang_String(fragment) {
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_.removeAll(this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(fragment));
    return this;
  }
  
  /**
   * @override
   * @return {HistoryToken}
   * @public
   */
  m_clear__() {
    this.m_clearPaths__();
    this.m_clearQuery__();
    this.m_clearFragments__();
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_fragment__() {
    return j_l_String.m_join__java_lang_CharSequence__java_lang_Iterable("/", this.m_fragments__());
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_value__() {
    return j_l_String.m_valueOf__java_lang_Object(this.m_path__()) + j_l_String.m_valueOf__java_lang_Object(this.m_appendQuery__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_query__())) + j_l_String.m_valueOf__java_lang_Object(this.m_appendFragment___$p_org_dominokit_domino_client_commons_history_StateHistoryToken());
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_appendFragment___$p_org_dominokit_domino_client_commons_history_StateHistoryToken() {
    return this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_fragment__()) ? "" : "#" + j_l_String.m_valueOf__java_lang_Object(this.m_fragment__());
  }
  
  /**
   * @param {?string} query
   * @return {?string}
   * @public
   */
  m_appendQuery__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(query) {
    return this.m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(query) ? "" : "?" + j_l_String.m_valueOf__java_lang_Object(query);
  }
  
  /**
   * @param {?string} pathValue
   * @return {List<?string>}
   * @public
   */
  m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(pathValue) {
    if (Objects.m_isNull__java_lang_Object(pathValue)) {
      return this.m_asPathsList__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken("null");
    }
    return /**@type {List<?string>} */ ($Casts.$to(/**@type {Stream<?string>} */ (Arrays.m_stream__arrayOf_java_lang_Object(this.m_splittedPaths__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(pathValue))).m_filter__java_util_function_Predicate(Predicate.$adapt(((/** ?string */ p) =>{
      return !j_l_String.m_isEmpty__java_lang_String(p);
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<?string, ?, LinkedList<?string>>} */ (Collectors.m_toCollection__java_util_function_Supplier(Supplier.$adapt((() =>{
      return /**@type {!LinkedList<?string>} */ (LinkedList.$create__());
    }))))), List));
  }
  
  /**
   * @param {?string} pathString
   * @return {Array<?string>}
   * @public
   */
  m_splittedPaths__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(pathString) {
    return j_l_String.m_split__java_lang_String__java_lang_String(this.m_parsePathPart__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(pathString), "/");
  }
  
  /**
   * @param {?string} pathString
   * @return {?string}
   * @public
   */
  m_parsePathPart__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(pathString) {
    return j_l_String.m_split__java_lang_String__java_lang_String(j_l_String.m_split__java_lang_String__java_lang_String(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(pathString, "!", ""), StateHistoryToken.f_QUERY_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_)[0], StateHistoryToken.f_FRAGMENT_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_)[0];
  }
  
  /**
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_isEmpty__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(path) {
    return Objects.m_isNull__java_lang_Object(path) || j_l_String.m_isEmpty__java_lang_String(path);
  }
  
  /**
   * @param {List<?string>} paths
   * @param {List<?string>} targets
   * @return {boolean}
   * @public
   */
  m_isValidSize__java_util_List__java_util_List_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(paths, targets) {
    return !targets.isEmpty() && targets.size() <= paths.size();
  }
  
  /**
   * @param {?string} token
   * @return {Map<?string, ?string>}
   * @public
   */
  m_asQueryParameters__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token) {
    if (!j_l_String.m_contains__java_lang_String__java_lang_CharSequence(token, "?")) {
      return /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
    }
    return this.m_parsedParameters__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(this.m_queryPart__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token));
  }
  
  /**
   * @param {?string} queryString
   * @return {Map<?string, ?string>}
   * @public
   */
  m_parsedParameters__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(queryString) {
    return /**@type {Map<?string, ?string>} */ ($Casts.$to(/**@type {Stream<Array<?string>>} */ (/**@type {Stream<?string>} */ (Stream.m_of__arrayOf_java_lang_Object(j_l_String.m_split__java_lang_String__java_lang_String(queryString, "&"))).m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** ?string */ part) =>{
      return j_l_String.m_split__java_lang_String__java_lang_String(part, "=");
    })))).m_collect__java_util_stream_Collector(/**@type {Collector<Array<?string>, ?, Map<?string, ?string>>} */ (Collectors.m_toMap__java_util_function_Function__java_util_function_Function(j_u_function_Function.$adapt(((/** Array<?string> */ e) =>{
      return e[StateHistoryToken.f_NAME_INDEX__org_dominokit_domino_client_commons_history_StateHistoryToken_];
    })), j_u_function_Function.$adapt(((/** Array<?string> */ e$1$) =>{
      return e$1$[StateHistoryToken.f_VALUE_INDEX__org_dominokit_domino_client_commons_history_StateHistoryToken_];
    }))))), Map));
  }
  
  /**
   * @param {?string} token
   * @return {?string}
   * @public
   */
  m_queryPart__java_lang_String_$p_org_dominokit_domino_client_commons_history_StateHistoryToken(token) {
    return j_l_String.m_split__java_lang_String__java_lang_String(j_l_String.m_split__java_lang_String__java_lang_String(token, StateHistoryToken.f_QUERY_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_)[1], StateHistoryToken.f_FRAGMENT_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_)[0];
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_history_StateHistoryToken() {
    this.f_paths__org_dominokit_domino_client_commons_history_StateHistoryToken_ = /**@type {!LinkedList<?string>} */ (LinkedList.$create__());
    this.f_queryParameters__org_dominokit_domino_client_commons_history_StateHistoryToken_ = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
    this.f_fragments__org_dominokit_domino_client_commons_history_StateHistoryToken_ = /**@type {!LinkedList<?string>} */ (LinkedList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StateHistoryToken;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StateHistoryToken);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StateHistoryToken.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    List = goog.module.get('java.util.List$impl');
    Map = goog.module.get('java.util.Map$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    IntPredicate = goog.module.get('java.util.function.IntPredicate$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Supplier = goog.module.get('java.util.function.Supplier$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    IntStream = goog.module.get('java.util.stream.IntStream$impl');
    Stream = goog.module.get('java.util.stream.Stream$impl');
    TokenCannotBeNullException = goog.module.get('org.dominokit.domino.api.shared.history.HistoryToken.TokenCannotBeNullException$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $int = goog.module.get('vmbootstrap.primitives.$int$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(StateHistoryToken, $Util.$makeClassName('org.dominokit.domino.client.commons.history.StateHistoryToken'));


/** @public {?string} @const */
StateHistoryToken.f_QUERY_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_ = "\\?";


/** @public {?string} @const */
StateHistoryToken.f_FRAGMENT_REGEX__org_dominokit_domino_client_commons_history_StateHistoryToken_ = "\\#";


/** @public {number} @const */
StateHistoryToken.f_NAME_INDEX__org_dominokit_domino_client_commons_history_StateHistoryToken_ = 0;


/** @public {number} @const */
StateHistoryToken.f_VALUE_INDEX__org_dominokit_domino_client_commons_history_StateHistoryToken_ = 1;


HistoryToken.$markImplementor(StateHistoryToken);


exports = StateHistoryToken; 
//# sourceMappingURL=StateHistoryToken.js.map