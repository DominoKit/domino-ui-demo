/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRepository$impl');

let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let LazyRequestRestSenderLoader = goog.forwardDeclare('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader$impl');
let RequestRestSender = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSender$impl');
let SenderCannotBeRegisteredMoreThanOnce = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderCannotBeRegisteredMoreThanOnce$impl');
let SenderNotFoundException = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderNotFoundException$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {RequestRestSendersRepository}
  */
class InMemoryRequestRestSendersRepository extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Map<?string, LazyRequestRestSenderLoader>} */
    this.f_senders__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository_;
  }
  
  /**
   * Factory method corresponding to constructor 'InMemoryRequestRestSendersRepository()'.
   * @return {!InMemoryRequestRestSendersRepository}
   * @public
   */
  static $create__() {
    InMemoryRequestRestSendersRepository.$clinit();
    let $instance = new InMemoryRequestRestSendersRepository();
    $instance.$ctor__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InMemoryRequestRestSendersRepository()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository();
  }
  
  /**
   * @override
   * @param {?string} requestName
   * @param {LazyRequestRestSenderLoader} loader
   * @return {void}
   * @public
   */
  m_registerSender__java_lang_String__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader(requestName, loader) {
    if (this.m_isRegisteredSender__java_lang_String_$p_org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository(requestName)) {
      throw $Exceptions.toJs(SenderCannotBeRegisteredMoreThanOnce.$create__java_lang_String(requestName));
    }
    this.f_senders__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository_.put(requestName, loader);
  }
  
  /**
   * @param {?string} requestName
   * @return {boolean}
   * @public
   */
  m_isRegisteredSender__java_lang_String_$p_org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository(requestName) {
    return this.f_senders__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository_.containsKey(requestName);
  }
  
  /**
   * @override
   * @param {?string} requestName
   * @return {RequestRestSender}
   * @public
   */
  m_get__java_lang_String(requestName) {
    if (this.m_isRegisteredSender__java_lang_String_$p_org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository(requestName)) {
      return /**@type {LazyRequestRestSenderLoader} */ ($Casts.$to(this.f_senders__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository_.get(requestName), LazyRequestRestSenderLoader)).m_get__();
    }
    throw $Exceptions.toJs(SenderNotFoundException.$create__java_lang_String(requestName));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_senders__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository_.clear();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository() {
    this.f_senders__org_dominokit_domino_client_commons_request_InMemoryRequestRestSendersRepository_ = /**@type {!HashMap<?string, LazyRequestRestSenderLoader>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InMemoryRequestRestSendersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InMemoryRequestRestSendersRepository);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InMemoryRequestRestSendersRepository.$clinit = function() {};
    HashMap = goog.module.get('java.util.HashMap$impl');
    LazyRequestRestSenderLoader = goog.module.get('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader$impl');
    SenderCannotBeRegisteredMoreThanOnce = goog.module.get('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderCannotBeRegisteredMoreThanOnce$impl');
    SenderNotFoundException = goog.module.get('org.dominokit.domino.api.client.request.RequestRestSendersRepository.SenderNotFoundException$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InMemoryRequestRestSendersRepository, $Util.$makeClassName('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository'));


RequestRestSendersRepository.$markImplementor(InMemoryRequestRestSendersRepository);


exports = InMemoryRequestRestSendersRepository; 
//# sourceMappingURL=InMemoryRequestRestSendersRepository.js.map