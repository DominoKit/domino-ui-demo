/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.ServerRouter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.ServerRouter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter$impl');

let Request = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let RequestAsyncSender = goog.forwardDeclare('org.dominokit.domino.client.commons.request.RequestAsyncSender$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {RequestRouter<ServerRequest>}
  */
class ServerRouter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {RequestAsyncSender} */
    this.f_requestAsyncRunner__org_dominokit_domino_client_commons_request_ServerRouter_;
  }
  
  /**
   * Factory method corresponding to constructor 'ServerRouter(RequestAsyncSender)'.
   * @param {RequestAsyncSender} requestAsyncRunner
   * @return {!ServerRouter}
   * @public
   */
  static $create__org_dominokit_domino_client_commons_request_RequestAsyncSender(requestAsyncRunner) {
    ServerRouter.$clinit();
    let $instance = new ServerRouter();
    $instance.$ctor__org_dominokit_domino_client_commons_request_ServerRouter__org_dominokit_domino_client_commons_request_RequestAsyncSender(requestAsyncRunner);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerRouter(RequestAsyncSender)'.
   * @param {RequestAsyncSender} requestAsyncRunner
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_ServerRouter__org_dominokit_domino_client_commons_request_RequestAsyncSender(requestAsyncRunner) {
    this.$ctor__java_lang_Object__();
    this.f_requestAsyncRunner__org_dominokit_domino_client_commons_request_ServerRouter_ = requestAsyncRunner;
  }
  
  /**
   * @param {ServerRequest} request
   * @return {void}
   * @public
   */
  m_routeRequest__org_dominokit_domino_api_client_request_ServerRequest(request) {
    this.f_requestAsyncRunner__org_dominokit_domino_client_commons_request_ServerRouter_.m_send__org_dominokit_domino_api_client_request_ServerRequest(request);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {Request} arg0
   * @return {void}
   * @public
   */
  m_routeRequest__org_dominokit_domino_api_client_request_Request(arg0) {
    this.m_routeRequest__org_dominokit_domino_api_client_request_ServerRequest(/**@type {ServerRequest} */ ($Casts.$to(arg0, ServerRequest)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerRouter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerRouter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerRouter.$clinit = function() {};
    ServerRequest = goog.module.get('org.dominokit.domino.api.client.request.ServerRequest$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerRouter, $Util.$makeClassName('org.dominokit.domino.client.commons.request.ServerRouter'));


RequestRouter.$markImplementor(ServerRouter);


exports = ServerRouter; 
//# sourceMappingURL=ServerRouter.js.map