/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const PresentersRepository = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let LazyPresenterLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');
let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let PresenterCannotBeRegisteredMoreThanOnce = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterCannotBeRegisteredMoreThanOnce$impl');
let PresenterNotFoundException = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterNotFoundException$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {PresentersRepository}
  */
class InMemoryPresentersRepository extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HashMap<?string, LazyPresenterLoader>} */
    this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_;
    /** @public {HashMap<?string, ?string>} */
    this.f_names__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_;
  }
  
  /**
   * Factory method corresponding to constructor 'InMemoryPresentersRepository()'.
   * @return {!InMemoryPresentersRepository}
   * @public
   */
  static $create__() {
    InMemoryPresentersRepository.$clinit();
    let $instance = new InMemoryPresentersRepository();
    $instance.$ctor__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'InMemoryPresentersRepository()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.clear();
  }
  
  /**
   * @override
   * @param {LazyPresenterLoader} lazyPresenterLoader
   * @return {void}
   * @public
   */
  m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader(lazyPresenterLoader) {
    if (this.m_isRegisteredPresenter__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository(lazyPresenterLoader.m_getName__())) {
      throw $Exceptions.toJs(PresenterCannotBeRegisteredMoreThanOnce.$create__java_lang_String(lazyPresenterLoader.m_getName__()));
    }
    this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.put(lazyPresenterLoader.m_getName__(), lazyPresenterLoader);
    this.f_names__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.put(lazyPresenterLoader.m_getConcreteName__(), lazyPresenterLoader.m_getName__());
  }
  
  /**
   * @override
   * @param {?string} presenterName
   * @return {Presentable}
   * @public
   */
  m_getPresenter__java_lang_String(presenterName) {
    if (this.m_isRegisteredPresenter__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository(presenterName)) {
      return /**@type {LazyPresenterLoader} */ ($Casts.$to(this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.get(presenterName), LazyPresenterLoader)).m_getPresenter__();
    }
    throw $Exceptions.toJs(PresenterNotFoundException.$create__java_lang_String(presenterName));
  }
  
  /**
   * @param {?string} presenterName
   * @return {LazyPresenterLoader}
   * @public
   */
  m_getPresenterLoader__java_lang_String(presenterName) {
    if (this.m_isRegisteredPresenter__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository(presenterName)) {
      return /**@type {LazyPresenterLoader} */ ($Casts.$to(this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.get(presenterName), LazyPresenterLoader));
    }
    throw $Exceptions.toJs(PresenterNotFoundException.$create__java_lang_String(presenterName));
  }
  
  /**
   * @override
   * @param {?string} concreteName
   * @return {?string}
   * @public
   */
  m_getNameFromConcreteName__java_lang_String(concreteName) {
    if (this.m_isRegisteredName__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository(concreteName)) {
      return /**@type {?string} */ ($Casts.$to(this.f_names__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.get(concreteName), j_l_String));
    }
    throw $Exceptions.toJs(PresenterNotFoundException.$create__java_lang_String(concreteName));
  }
  
  /**
   * @param {?string} presenterName
   * @return {boolean}
   * @public
   */
  m_isRegisteredPresenter__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository(presenterName) {
    return this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.containsKey(presenterName);
  }
  
  /**
   * @param {?string} concreteName
   * @return {boolean}
   * @public
   */
  m_isRegisteredName__java_lang_String_$p_org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository(concreteName) {
    return this.f_names__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_.containsKey(concreteName);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository() {
    this.f_presenters__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_ = /**@type {!HashMap<?string, LazyPresenterLoader>} */ (HashMap.$create__());
    this.f_names__org_dominokit_domino_client_commons_mvp_presenter_InMemoryPresentersRepository_ = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InMemoryPresentersRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InMemoryPresentersRepository);
  }
  
  /**
   * @public
   */
  static $clinit() {
    InMemoryPresentersRepository.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    LazyPresenterLoader = goog.module.get('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');
    PresenterCannotBeRegisteredMoreThanOnce = goog.module.get('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterCannotBeRegisteredMoreThanOnce$impl');
    PresenterNotFoundException = goog.module.get('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterNotFoundException$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(InMemoryPresentersRepository, $Util.$makeClassName('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository'));


PresentersRepository.$markImplementor(InMemoryPresentersRepository);


exports = InMemoryPresentersRepository; 
//# sourceMappingURL=InMemoryPresentersRepository.js.map