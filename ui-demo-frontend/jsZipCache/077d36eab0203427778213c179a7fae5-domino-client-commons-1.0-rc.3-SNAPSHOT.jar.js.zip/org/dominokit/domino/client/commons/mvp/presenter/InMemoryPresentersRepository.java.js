/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _PresentersRepository = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _PresenterCannotBeRegisteredMoreThanOnce = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterCannotBeRegisteredMoreThanOnce');
const _PresenterNotFoundException = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterNotFoundException');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var InMemoryPresentersRepository = goog.require('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository$impl');
exports = InMemoryPresentersRepository;
 