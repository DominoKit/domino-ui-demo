/**
 * @fileoverview transpiled from org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.RequestAsyncSender$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let ServerRequestEventFactory = goog.forwardDeclare('org.dominokit.domino.api.client.events.ServerRequestEventFactory$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let RequestAsyncTask = goog.forwardDeclare('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.RequestAsyncTask$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @abstract
 * @implements {RequestAsyncSender}
  */
class AbstractRequestAsyncSender extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ServerRequestEventFactory} */
    this.f_requestEventFactory__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_;
  }
  
  /**
   * Initialization from constructor 'AbstractRequestAsyncSender(ServerRequestEventFactory)'.
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory) {
    this.$ctor__java_lang_Object__();
    this.f_requestEventFactory__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_ = requestEventFactory;
  }
  
  /**
   * @override
   * @param {ServerRequest} request
   * @return {void}
   * @public
   */
  m_send__org_dominokit_domino_api_client_request_ServerRequest(request) {
    ClientApp.m_make__().m_getAsyncRunner__().m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(RequestAsyncTask.$create__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_request_ServerRequest(this, request));
  }
  
  /**
   * @abstract
   * @param {ServerRequest} request
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  m_sendRequest__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_client_events_ServerRequestEventFactory(request, requestEventFactory) {
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_() {
    return (AbstractRequestAsyncSender.$clinit(), AbstractRequestAsyncSender.$f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_(value) {
    (AbstractRequestAsyncSender.$clinit(), AbstractRequestAsyncSender.$f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractRequestAsyncSender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractRequestAsyncSender);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractRequestAsyncSender.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    RequestAsyncTask = goog.module.get('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender.RequestAsyncTask$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    AbstractRequestAsyncSender.$f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(RequestAsyncSender));
  }
  
  
};

$Util.$setClassMetadata(AbstractRequestAsyncSender, $Util.$makeClassName('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender'));


/** @private {Logger} */
AbstractRequestAsyncSender.$f_LOGGER__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender_;


RequestAsyncSender.$markImplementor(AbstractRequestAsyncSender);


exports = AbstractRequestAsyncSender; 
//# sourceMappingURL=AbstractRequestAsyncSender.js.map