/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let LayoutPresenter = goog.forwardDeclare('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');


/**
 * @extends {PresenterCommand<LayoutPresenter>}
  */
class LayoutPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutPresenterCommand()'.
   * @return {!LayoutPresenterCommand}
   * @public
   */
  static $create__() {
    LayoutPresenterCommand.$clinit();
    let $instance = new LayoutPresenterCommand();
    $instance.$ctor__org_dominokit_domino_layout_client_presenters_LayoutPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_presenters_LayoutPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutPresenterCommand, $Util.$makeClassName('org.dominokit.domino.layout.client.presenters.LayoutPresenterCommand'));




exports = LayoutPresenterCommand; 
//# sourceMappingURL=LayoutPresenterCommand.js.map