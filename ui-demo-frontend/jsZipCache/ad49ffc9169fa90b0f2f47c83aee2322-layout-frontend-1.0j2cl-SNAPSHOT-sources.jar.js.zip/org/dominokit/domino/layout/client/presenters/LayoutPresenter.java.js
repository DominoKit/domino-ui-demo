/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.presenters.LayoutPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.client.presenters.LayoutPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext');
const _Class = goog.require('java.lang.Class');
const _MainContext = goog.require('org.dominokit.domino.api.shared.extension.MainContext');
const _LayoutView = goog.require('org.dominokit.domino.layout.client.views.LayoutView');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _LayoutExtensionPoint = goog.require('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LayoutPresenter = goog.require('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');
exports = LayoutPresenter;
 