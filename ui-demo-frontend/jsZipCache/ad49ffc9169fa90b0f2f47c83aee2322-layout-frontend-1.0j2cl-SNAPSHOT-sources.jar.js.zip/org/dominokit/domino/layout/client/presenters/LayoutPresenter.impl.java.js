/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.presenters.LayoutPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.presenters.LayoutPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');
const LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let MainContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainContext$impl');
let LayoutView = goog.forwardDeclare('org.dominokit.domino.layout.client.views.LayoutView$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let LayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseClientPresenter<LayoutView>}
 * @implements {LayoutContext}
  */
class LayoutPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutPresenter()'.
   * @return {!LayoutPresenter}
   * @public
   */
  static $create__() {
    LayoutPresenter.$clinit();
    let $instance = new LayoutPresenter();
    $instance.$ctor__org_dominokit_domino_layout_client_presenters_LayoutPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_presenters_LayoutPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {MainContext} context
   * @return {void}
   * @public
   */
  m_contributeToMainModule__org_dominokit_domino_api_shared_extension_MainContext(context) {
    /**@type {LayoutView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter, LayoutView)).m_show__();
    this.m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(Class.$get(LayoutExtensionPoint), LayoutExtensionPoint.$adapt((() =>{
      return this;
    })));
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_getLayout__() {
    return /**@type {IsLayout} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter, IsLayout));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_layout_client_presenters_LayoutPresenter_() {
    return (LayoutPresenter.$clinit(), LayoutPresenter.$f_LOGGER__org_dominokit_domino_layout_client_presenters_LayoutPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_layout_client_presenters_LayoutPresenter_(value) {
    (LayoutPresenter.$clinit(), LayoutPresenter.$f_LOGGER__org_dominokit_domino_layout_client_presenters_LayoutPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LayoutView = goog.module.get('org.dominokit.domino.layout.client.views.LayoutView$impl');
    IsLayout = goog.module.get('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
    LayoutExtensionPoint = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseClientPresenter.$clinit();
    LayoutPresenter.$f_LOGGER__org_dominokit_domino_layout_client_presenters_LayoutPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LayoutPresenter));
  }
  
  
};

$Util.$setClassMetadata(LayoutPresenter, $Util.$makeClassName('org.dominokit.domino.layout.client.presenters.LayoutPresenter'));


/** @private {Logger} */
LayoutPresenter.$f_LOGGER__org_dominokit_domino_layout_client_presenters_LayoutPresenter_;


LayoutContext.$markImplementor(LayoutPresenter);


exports = LayoutPresenter; 
//# sourceMappingURL=LayoutPresenter.js.map