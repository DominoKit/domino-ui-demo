/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.views.ui.ProgressViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const ProgressView = goog.require('org.dominokit.domino.progress.client.views.ProgressView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let ComponentRevealedHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl.$1$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Progress = goog.forwardDeclare('org.dominokit.domino.ui.progress.Progress$impl');
let ProgressBar = goog.forwardDeclare('org.dominokit.domino.ui.progress.ProgressBar$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ProgressView}
  */
class ProgressViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_;
    /** @public {ProgressBar} */
    this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_;
    /** @public {number} */
    this.f_animationFrame__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_ = 0;
    /** @public {?function(number):void} */
    this.f_animationFrameCallback__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ProgressViewImpl()'.
   * @return {!ProgressViewImpl}
   * @public
   */
  static $create__() {
    ProgressViewImpl.$clinit();
    let $instance = new ProgressViewImpl();
    $instance.$ctor__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProgressViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("PROGRESS BARS").m_asElement__());
    this.m_basicSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
    this.m_contextualAlternatives___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
    this.m_stripedSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
    this.m_animatedSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
    this.m_stackedSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
    this.m_materialDesignColors___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_ = ProgressBar.m_create__int(1000);
    this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_asElement__().style.setProperty("transition", "width 500ms linear", "important");
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(Card.m_create__java_lang_String("BASIC EXAMPLES").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_setValue__double(90))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_setValue__double(60))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_textExpression__java_lang_String("{value} out of {maxValue} completed").m_setValue__double(75))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_textExpression__java_lang_String("{value} out of {maxValue} completed").m_setValue__double(40))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_)).m_asElement__());
    this.f_animationFrameCallback__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_ = ((/** number */ p0) =>{
      if (this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_getValue__() >= this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_getMaxValue__()) {
        this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_textExpression__java_lang_String("Done");
      } else {
        this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_setValue__double(this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_getValue__() + 1);
      }
      this.f_animationFrame__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_ = window.requestAnimationFrame(this.f_animationFrameCallback__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_);
    });
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, "basicSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_contextualAlternatives___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("CONTEXTUAL ALTERNATIVES", "Progress bars use some of the same button and alert classes for consistent styles.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_success__().m_setValue__double(80))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_warning__().m_setValue__double(60))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_info__().m_setValue__double(70))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_danger__().m_setValue__double(30))).m_asElement__());
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, "contextualAlternatives").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_stripedSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("STRIPED", "Uses a gradient to create a striped effect.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_striped__().m_success__().m_setValue__double(80))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_striped__().m_warning__().m_setValue__double(60))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_striped__().m_info__().m_setValue__double(70))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_striped__().m_danger__().m_setValue__double(30))).m_asElement__());
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, "stripedSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_animatedSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ANIMATED", "Animating the bar will add stripes by default.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_animate__().m_success__().m_setValue__double(80))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_animate__().m_warning__().m_setValue__double(60))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_animate__().m_info__().m_setValue__double(70))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_animate__().m_danger__().m_setValue__double(30))).m_asElement__());
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, "animatedSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_stackedSample___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("STACKED", "You can stack more than one progress bar in a progress element.").m_appendChild__elemental2_dom_Node(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_animate__().m_success__().m_setValue__double(40)).m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_warning__().m_setValue__double(30)).m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_striped__().m_danger__().m_setValue__double(20)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, "stackedSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_materialDesignColors___$p_org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("WITH MATERIAL DESIGN COLORS", "You use material design colors to style the progress bar.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_striped__().m_setValue__double(90))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_showText__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_striped__().m_setValue__double(60))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_striped__().m_setValue__double(75))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Progress.m_create__().m_appendChild__org_dominokit_domino_ui_progress_ProgressBar(ProgressBar.m_create__int(100).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BROWN__org_dominokit_domino_ui_style_Color).m_striped__().m_setValue__double(40))).m_asElement__());
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl, "materialDesignColors").m_asElement__());
  }
  
  /**
   * @override
   * @return {ComponentRevealedHandler}
   * @public
   */
  m_restartProgress__() {
    return ComponentRevealedHandler.$adapt((() =>{
      window.cancelAnimationFrame(this.f_animationFrame__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_);
      this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_setValue__double(0);
      this.f_movingBar__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_.m_textExpression__java_lang_String("{percent}%");
      $1.$create__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl(this).m_schedule__int(1000);
    }));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl() {
    this.f_element__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_animationFrame__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl_ = 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProgressViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProgressViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProgressViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    ComponentRevealedHandler = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler$impl');
    $1 = goog.module.get('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl.$1$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Progress = goog.module.get('org.dominokit.domino.ui.progress.Progress$impl');
    ProgressBar = goog.module.get('org.dominokit.domino.ui.progress.ProgressBar$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProgressViewImpl, $Util.$makeClassName('org.dominokit.domino.progress.client.views.ui.ProgressViewImpl'));


/** @public {?string} @const */
ProgressViewImpl.f_MODULE_NAME__org_dominokit_domino_progress_client_views_ui_ProgressViewImpl = "progress";


ProgressView.$markImplementor(ProgressViewImpl);


exports = ProgressViewImpl; 
//# sourceMappingURL=ProgressViewImpl.js.map