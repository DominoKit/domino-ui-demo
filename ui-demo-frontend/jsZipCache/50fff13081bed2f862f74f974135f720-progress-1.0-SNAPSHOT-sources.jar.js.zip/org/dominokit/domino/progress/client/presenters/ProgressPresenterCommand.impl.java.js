/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ProgressPresenter = goog.forwardDeclare('org.dominokit.domino.progress.client.presenters.ProgressPresenter$impl');


/**
 * @extends {PresenterCommand<ProgressPresenter>}
  */
class ProgressPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProgressPresenterCommand()'.
   * @return {!ProgressPresenterCommand}
   * @public
   */
  static $create__() {
    ProgressPresenterCommand.$clinit();
    let $instance = new ProgressPresenterCommand();
    $instance.$ctor__org_dominokit_domino_progress_client_presenters_ProgressPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProgressPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_progress_client_presenters_ProgressPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProgressPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProgressPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProgressPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProgressPresenterCommand, $Util.$makeClassName('org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand'));




exports = ProgressPresenterCommand; 
//# sourceMappingURL=ProgressPresenterCommand.js.map