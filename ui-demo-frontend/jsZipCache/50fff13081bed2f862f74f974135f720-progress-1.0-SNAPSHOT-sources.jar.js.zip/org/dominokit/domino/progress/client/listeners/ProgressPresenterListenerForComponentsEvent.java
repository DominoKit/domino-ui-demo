package org.dominokit.domino.progress.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class ProgressPresenterListenerForComponentsEvent implements DominoEventListener<ComponentsEvent> {
  @Override
  public void listen(ComponentsEvent event) {
    new ProgressPresenterCommand().onPresenterReady(presenter -> presenter.onComponentsEvent(event.context())).send();
  }
}
