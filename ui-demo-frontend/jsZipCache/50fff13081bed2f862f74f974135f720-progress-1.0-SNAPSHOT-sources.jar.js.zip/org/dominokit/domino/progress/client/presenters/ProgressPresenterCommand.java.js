/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ProgressPresenter = goog.require('org.dominokit.domino.progress.client.presenters.ProgressPresenter');


// Re-exports the implementation.
var ProgressPresenterCommand = goog.require('org.dominokit.domino.progress.client.presenters.ProgressPresenterCommand$impl');
exports = ProgressPresenterCommand;
 