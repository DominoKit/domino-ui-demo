/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.presenters.ProgressPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.progress.client.presenters.ProgressPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.progress.client.presenters.ProgressPresenter.$1$impl');
let ProgressView = goog.forwardDeclare('org.dominokit.domino.progress.client.views.ProgressView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<ProgressView>}
  */
class ProgressPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProgressPresenter()'.
   * @return {!ProgressPresenter}
   * @public
   */
  static $create__() {
    ProgressPresenter.$clinit();
    let $instance = new ProgressPresenter();
    $instance.$ctor__org_dominokit_domino_progress_client_presenters_ProgressPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProgressPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_progress_client_presenters_ProgressPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_onComponentsEvent__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_progress_client_presenters_ProgressPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_progress_client_presenters_ProgressPresenter_() {
    return (ProgressPresenter.$clinit(), ProgressPresenter.$f_LOGGER__org_dominokit_domino_progress_client_presenters_ProgressPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_progress_client_presenters_ProgressPresenter_(value) {
    (ProgressPresenter.$clinit(), ProgressPresenter.$f_LOGGER__org_dominokit_domino_progress_client_presenters_ProgressPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProgressPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProgressPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProgressPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.progress.client.presenters.ProgressPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    ProgressPresenter.$f_LOGGER__org_dominokit_domino_progress_client_presenters_ProgressPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ProgressPresenter));
  }
  
  
};

$Util.$setClassMetadata(ProgressPresenter, $Util.$makeClassName('org.dominokit.domino.progress.client.presenters.ProgressPresenter'));


/** @private {Logger} */
ProgressPresenter.$f_LOGGER__org_dominokit_domino_progress_client_presenters_ProgressPresenter_;




exports = ProgressPresenter; 
//# sourceMappingURL=ProgressPresenter.js.map