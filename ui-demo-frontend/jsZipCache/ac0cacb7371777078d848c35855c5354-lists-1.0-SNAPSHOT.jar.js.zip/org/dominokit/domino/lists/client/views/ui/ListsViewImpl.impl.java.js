/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.views.ui.ListsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.lists.client.views.ui.ListsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const ListsView = goog.require('org.dominokit.domino.lists.client.views.ListsView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup$impl');
let SimpleListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListGroup$impl');
let SimpleListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListItem$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ListsView}
  */
class ListsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ListsViewImpl()'.
   * @return {!ListsViewImpl}
   * @public
   */
  static $create__() {
    ListsViewImpl.$clinit();
    let $instance = new ListsViewImpl();
    $instance.$ctor__org_dominokit_domino_lists_client_views_ui_ListsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_lists_client_views_ui_ListsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_lists_client_views_ui_ListsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(ListsViewImpl.f_MODULE_NAME__org_dominokit_domino_lists_client_views_ui_ListsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("LIST GROUPS").m_asElement__());
    this.m_basicListsSample___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl();
    this.m_selectableSample___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl();
    this.m_coloredSample___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl();
    this.m_richItems___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicListsSample___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl() {
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("BASIC EXAMPLES", "The most basic list group is simply an unordered list with list items, and the proper classes.").m_appendChild__elemental2_dom_Node(SimpleListGroup.m_create__().m_appendChild__java_lang_String("Cras justo odio").m_appendChild__java_lang_String("Dapibus ac facilisis in").m_appendChild__java_lang_String("Morbi leo risus").m_appendChild__java_lang_String("Porta ac consectetur ac").m_appendChild__java_lang_String("Vestibulum at eros").m_asElement__()).m_asElement__()), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("BADGES", "Add the badges component to any list group item and it will automatically be positioned on the right.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(SimpleListGroup.m_create__().m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Cras justo odio").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("14 new").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Dapibus ac facilisis in").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("99 unread").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Morbi leo risus").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("99+").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Porta ac consectetur ac").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("21").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color))).m_appendChild__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Vestibulum at eros").m_appendChild__org_dominokit_domino_ui_badges_Badge(Badge.m_create__java_lang_String("Pending").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color))))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ListsViewImpl.f_MODULE_NAME__org_dominokit_domino_lists_client_views_ui_ListsViewImpl, "basicListsSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_selectableSample___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl() {
    let listGroup = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    listGroup.m_multiSelect__().m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("Value1", "Cras justo odio").m_select__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("Value2", "Dapibus ac facilisis in")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("Value3", "Morbi leo risus")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("Value4", "Porta ac consectetur ac")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("Value5", "Vestibulum at eros"));
    let disabledItems = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    disabledItems.m_appendChild__org_dominokit_domino_ui_lists_ListItem(disabledItems.m_createItem__java_lang_Object__java_lang_String("Value1", "Cras justo odio").m_disable__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(disabledItems.m_createItem__java_lang_Object__java_lang_String("Value2", "Dapibus ac facilisis in").m_select__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(disabledItems.m_createItem__java_lang_Object__java_lang_String("Value3", "Morbi leo risus").m_disable__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(disabledItems.m_createItem__java_lang_Object__java_lang_String("Value4", "Porta ac consectetur ac")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(disabledItems.m_createItem__java_lang_Object__java_lang_String("Value5", "Vestibulum at eros"));
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("SELECTABLE ITEMS", "Use ListGroup instead of SimpleListGroup to make items selectable, use multiSelect to select more than one item.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(listGroup)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("DISABLED ITEMS", "List group items can be disabled and prevented from being selected.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(disabledItems)), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ListsViewImpl.f_MODULE_NAME__org_dominokit_domino_lists_client_views_ui_ListsViewImpl, "selectableSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_coloredSample___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl() {
    let contextualGroup = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    contextualGroup.m_appendChild__org_dominokit_domino_ui_lists_ListItem(contextualGroup.m_createItem__java_lang_Object__java_lang_String("Value1", "Cras justo odio").m_select__().m_success__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(contextualGroup.m_createItem__java_lang_Object__java_lang_String("Value2", "Dapibus ac facilisis in").m_info__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(contextualGroup.m_createItem__java_lang_Object__java_lang_String("Value3", "Morbi leo risus").m_warning__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(contextualGroup.m_createItem__java_lang_Object__java_lang_String("Value4", "Porta ac consectetur ac").m_error__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(contextualGroup.m_createItem__java_lang_Object__java_lang_String("Value5", "Vestibulum at eros"));
    let coloredGroup = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    coloredGroup.m_appendChild__org_dominokit_domino_ui_lists_ListItem(coloredGroup.m_createItem__java_lang_Object__java_lang_String("Value1", "Cras justo odio").m_disable__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_lists_ListItem(coloredGroup.m_createItem__java_lang_Object__java_lang_String("Value2", "Dapibus ac facilisis in").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_lists_ListItem(coloredGroup.m_createItem__java_lang_Object__java_lang_String("Value3", "Morbi leo risus").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_lists_ListItem(coloredGroup.m_createItem__java_lang_Object__java_lang_String("Value4", "Porta ac consectetur ac").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color)).m_appendChild__org_dominokit_domino_ui_lists_ListItem(coloredGroup.m_createItem__java_lang_Object__java_lang_String("Value5", "Vestibulum at eros").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color));
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("CONTEXTUAL CLASSES", "Use contextual classes to style list items.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(contextualGroup)), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__java_lang_String__java_lang_String("MATERIAL DESIGN COLORS", "Use Material design background colors to style list items.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(coloredGroup)), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ListsViewImpl.f_MODULE_NAME__org_dominokit_domino_lists_client_views_ui_ListsViewImpl, "coloredSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_richItems___$p_org_dominokit_domino_lists_client_views_ui_ListsViewImpl() {
    let listGroup = /**@type {ListGroup<?string>} */ (ListGroup.m_create__());
    listGroup.m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("value1", ListsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_).m_setHeading__java_lang_String("Cras justo odio")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("value2", ListsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_).m_setHeading__java_lang_String("Dapibus ac facilisis in")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("value3", ListsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_).m_setHeading__java_lang_String("Morbi leo risus")).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("value4", ListsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_).m_setHeading__java_lang_String("Porta ac consectetur ac").m_select__()).m_appendChild__org_dominokit_domino_ui_lists_ListItem(listGroup.m_createItem__java_lang_Object__java_lang_String("value5", ListsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_).m_setHeading__java_lang_String("Vestibulum at eros"));
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("RICH ITEMS", "Add rich items with header and description.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(listGroup).m_asElement__());
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ListsViewImpl.f_MODULE_NAME__org_dominokit_domino_lists_client_views_ui_ListsViewImpl, "richItems").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_lists_client_views_ui_ListsViewImpl() {
    this.f_element__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ListGroup = goog.module.get('org.dominokit.domino.ui.lists.ListGroup$impl');
    SimpleListGroup = goog.module.get('org.dominokit.domino.ui.lists.SimpleListGroup$impl');
    SimpleListItem = goog.module.get('org.dominokit.domino.ui.lists.SimpleListItem$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ListsViewImpl, $Util.$makeClassName('org.dominokit.domino.lists.client.views.ui.ListsViewImpl'));


/** @public {?string} @const */
ListsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_lists_client_views_ui_ListsViewImpl_ = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales orci ante, sed ornare eros vestibulum ut. Ut accumsan vitae eros sit amet tristique. Nullam scelerisque nunc enim, non dignissim nibh faucibus ullamcorper. Fusce pulvinar libero vel ligula iaculis ullamcorper. Integer dapibus, mi ac tempor varius, purus nibh mattis erat, vitae porta nunc nisi non tellus. Vivamus mollis ante non massa egestas fringilla. Vestibulum egestas consectetur nunc at ultricies. Morbi quis consectetur nunc.";


/** @public {?string} @const */
ListsViewImpl.f_MODULE_NAME__org_dominokit_domino_lists_client_views_ui_ListsViewImpl = "lists";


ListsView.$markImplementor(ListsViewImpl);


exports = ListsViewImpl; 
//# sourceMappingURL=ListsViewImpl.js.map