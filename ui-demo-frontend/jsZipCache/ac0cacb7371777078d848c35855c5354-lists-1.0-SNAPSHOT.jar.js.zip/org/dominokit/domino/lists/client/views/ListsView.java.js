/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.views.ListsView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.lists.client.views.ListsView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.lists.client.views.ListsView.$LambdaAdaptor');


// Re-exports the implementation.
var ListsView = goog.require('org.dominokit.domino.lists.client.views.ListsView$impl');
exports = ListsView;
 