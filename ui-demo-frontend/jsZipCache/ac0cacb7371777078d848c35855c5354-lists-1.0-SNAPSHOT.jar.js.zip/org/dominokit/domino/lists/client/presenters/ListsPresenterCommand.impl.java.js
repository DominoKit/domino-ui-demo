/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.presenters.ListsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.lists.client.presenters.ListsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ListsPresenter = goog.forwardDeclare('org.dominokit.domino.lists.client.presenters.ListsPresenter$impl');


/**
 * @extends {PresenterCommand<ListsPresenter>}
  */
class ListsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ListsPresenterCommand()'.
   * @return {!ListsPresenterCommand}
   * @public
   */
  static $create__() {
    ListsPresenterCommand.$clinit();
    let $instance = new ListsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_lists_client_presenters_ListsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_lists_client_presenters_ListsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ListsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.lists.client.presenters.ListsPresenterCommand'));




exports = ListsPresenterCommand; 
//# sourceMappingURL=ListsPresenterCommand.js.map