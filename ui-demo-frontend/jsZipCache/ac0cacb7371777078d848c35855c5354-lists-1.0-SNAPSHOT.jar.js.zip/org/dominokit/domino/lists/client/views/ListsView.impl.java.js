/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.views.ListsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.lists.client.views.ListsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.lists.client.views.ListsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class ListsView {
  /**
   * @param {?function():Content} fn
   * @return {ListsView}
   * @public
   */
  static $adapt(fn) {
    ListsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_lists_client_views_ListsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_lists_client_views_ListsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_lists_client_views_ListsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.lists.client.views.ListsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ListsView, $Util.$makeClassName('org.dominokit.domino.lists.client.views.ListsView'));


ListsView.$markImplementor(/** @type {Function} */ (ListsView));


exports = ListsView; 
//# sourceMappingURL=ListsView.js.map