/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.TimeZoneInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.TimeZoneInfo$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JsArray_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Any_$Overlay = goog.forwardDeclare('jsinterop.base.Any.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class TimeZoneInfo extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_id__org_gwtproject_i18n_client_TimeZoneInfo_;
    /** @public {Array<?string>} */
    this.f_names__org_gwtproject_i18n_client_TimeZoneInfo_;
    /** @public {number} */
    this.f_std_offset__org_gwtproject_i18n_client_TimeZoneInfo_ = 0;
    /** @public {Array<Integer>} */
    this.f_transitions__org_gwtproject_i18n_client_TimeZoneInfo_;
  }
  
  /**
   * @param {?string} json
   * @return {TimeZoneInfo}
   * @public
   */
  static m_buildTimeZoneData__java_lang_String(json) {
    TimeZoneInfo.$clinit();
    let timeZoneInfo = TimeZoneInfo.$create__();
    let parsed = /**@type {Object<string, *>} */ ($Casts.$to(Js.m_cast__java_lang_Object(window.JSON.parse(json)), $Overlay));
    timeZoneInfo.f_id__org_gwtproject_i18n_client_TimeZoneInfo_ = /**@type {?string} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(parsed, "id")), j_l_String));
    timeZoneInfo.f_std_offset__org_gwtproject_i18n_client_TimeZoneInfo_ = /**@type {Integer} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(parsed, "std_offset")), Integer)).m_intValue__();
    timeZoneInfo.f_names__org_gwtproject_i18n_client_TimeZoneInfo_ = /**@type {Array<?string>} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(parsed, "names")), JsArray_$Overlay));
    let jsTransitions = /**@type {Array<*>} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.m_get__jsinterop_base_JsPropertyMap__java_lang_String(parsed, "transitions")), JsArray_$Overlay));
    for (let i = 0; i < jsTransitions.length; i++) {
      timeZoneInfo.f_transitions__org_gwtproject_i18n_client_TimeZoneInfo_.push(Integer.m_valueOf__int(Any_$Overlay.m_asInt__jsinterop_base_Any(/**@type {*} */ ($Casts.$to(JsArrayLike_$Overlay.m_getAt__jsinterop_base_JsArrayLike__int(jsTransitions, i), Any_$Overlay)))));
    }
    return timeZoneInfo;
  }
  
  /**
   * Factory method corresponding to constructor 'TimeZoneInfo()'.
   * @return {!TimeZoneInfo}
   * @public
   */
  static $create__() {
    TimeZoneInfo.$clinit();
    let $instance = new TimeZoneInfo();
    $instance.$ctor__org_gwtproject_i18n_client_TimeZoneInfo__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TimeZoneInfo()'.
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_TimeZoneInfo__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_gwtproject_i18n_client_TimeZoneInfo();
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getID__() {
    return this.f_id__org_gwtproject_i18n_client_TimeZoneInfo_;
  }
  
  /**
   * @return {Array<?string>}
   * @public
   */
  m_getNames__() {
    return this.f_names__org_gwtproject_i18n_client_TimeZoneInfo_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getStandardOffset__() {
    return this.f_std_offset__org_gwtproject_i18n_client_TimeZoneInfo_;
  }
  
  /**
   * @return {Array<Integer>}
   * @public
   */
  m_getTransitions__() {
    return this.f_transitions__org_gwtproject_i18n_client_TimeZoneInfo_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_gwtproject_i18n_client_TimeZoneInfo() {
    this.f_names__org_gwtproject_i18n_client_TimeZoneInfo_ = /**@type {!Array<?string>} */ (new Array());
    this.f_transitions__org_gwtproject_i18n_client_TimeZoneInfo_ = /**@type {!Array<Integer>} */ (new Array());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TimeZoneInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TimeZoneInfo);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TimeZoneInfo.$clinit = function() {};
    JsArray_$Overlay = goog.module.get('elemental2.core.JsArray.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Any_$Overlay = goog.module.get('jsinterop.base.Any.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    JsArrayLike_$Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TimeZoneInfo, $Util.$makeClassName('org.gwtproject.i18n.client.TimeZoneInfo'));




exports = TimeZoneInfo; 
//# sourceMappingURL=TimeZoneInfo.js.map