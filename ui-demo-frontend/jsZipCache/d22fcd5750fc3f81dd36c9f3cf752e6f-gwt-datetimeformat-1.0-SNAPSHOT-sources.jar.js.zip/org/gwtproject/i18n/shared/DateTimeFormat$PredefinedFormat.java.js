/**
 * @fileoverview transpiled from org.gwtproject.i18n.shared.DateTimeFormat$PredefinedFormat.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.shared.DateTimeFormat.PredefinedFormat');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Enum = goog.require('java.lang.Enum');
const _$Util = goog.require('nativebootstrap.Util');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Enums = goog.require('vmbootstrap.Enums');


// Re-exports the implementation.
var PredefinedFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat.PredefinedFormat$impl');
exports = PredefinedFormat;
 