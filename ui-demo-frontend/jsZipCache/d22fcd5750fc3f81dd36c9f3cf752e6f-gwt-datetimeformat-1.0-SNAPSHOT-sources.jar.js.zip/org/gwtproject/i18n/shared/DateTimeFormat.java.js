/**
 * @fileoverview transpiled from org.gwtproject.i18n.shared.DateTimeFormat.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.shared.DateTimeFormat');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _ArrayList = goog.require('java.util.ArrayList');
const _Date = goog.require('java.util.Date');
const _HashMap = goog.require('java.util.HashMap');
const _Locale = goog.require('java.util.Locale');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _TimeZone = goog.require('org.gwtproject.i18n.client.TimeZone');
const _PatternPart = goog.require('org.gwtproject.i18n.shared.DateTimeFormat.PatternPart');
const _PredefinedFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat.PredefinedFormat');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _DefaultDateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DefaultDateTimeFormatInfo');
const _org_gwtproject_i18n_shared_TimeZone = goog.require('org.gwtproject.i18n.shared.TimeZone');
const _DateRecord = goog.require('org.gwtproject.i18n.shared.impl.DateRecord');
const _DateTimeFormatInfo__factory = goog.require('org.gwtproject.i18n.shared.impl.cldr.DateTimeFormatInfo_factory');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$LongUtils = goog.require('vmbootstrap.LongUtils');
const _$Primitives = goog.require('vmbootstrap.Primitives');
const _$int = goog.require('vmbootstrap.primitives.$int');


// Re-exports the implementation.
var DateTimeFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat$impl');
exports = DateTimeFormat;
 