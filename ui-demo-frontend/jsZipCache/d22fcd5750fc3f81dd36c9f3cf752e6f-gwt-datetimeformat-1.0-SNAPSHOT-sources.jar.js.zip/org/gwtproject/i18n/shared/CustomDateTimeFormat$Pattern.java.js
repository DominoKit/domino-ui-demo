/**
 * @fileoverview transpiled from org.gwtproject.i18n.shared.CustomDateTimeFormat$Pattern.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.shared.CustomDateTimeFormat.Pattern');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var Pattern = goog.require('org.gwtproject.i18n.shared.CustomDateTimeFormat.Pattern$impl');
exports = Pattern;
 