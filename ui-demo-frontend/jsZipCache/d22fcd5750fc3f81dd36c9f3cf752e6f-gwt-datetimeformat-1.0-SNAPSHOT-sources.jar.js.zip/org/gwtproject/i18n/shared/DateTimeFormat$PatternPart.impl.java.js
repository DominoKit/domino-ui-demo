/**
 * @fileoverview transpiled from org.gwtproject.i18n.shared.DateTimeFormat$PatternPart.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.shared.DateTimeFormat.PatternPart$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class PatternPart extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_text__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart;
    /** @public {number} */
    this.f_count__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart = 0;
    /** @public {boolean} */
    this.f_abutStart__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart = false;
  }
  
  /**
   * Factory method corresponding to constructor 'PatternPart(String, int)'.
   * @param {?string} txt
   * @param {number} cnt
   * @return {!PatternPart}
   * @public
   */
  static $create__java_lang_String__int(txt, cnt) {
    PatternPart.$clinit();
    let $instance = new PatternPart();
    $instance.$ctor__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart__java_lang_String__int(txt, cnt);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PatternPart(String, int)'.
   * @param {?string} txt
   * @param {number} cnt
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart__java_lang_String__int(txt, cnt) {
    this.$ctor__java_lang_Object__();
    this.f_text__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart = txt;
    this.f_count__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart = cnt;
    this.f_abutStart__org_gwtproject_i18n_shared_DateTimeFormat_PatternPart = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PatternPart;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PatternPart);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PatternPart.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PatternPart, $Util.$makeClassName('org.gwtproject.i18n.shared.DateTimeFormat$PatternPart'));




exports = PatternPart; 
//# sourceMappingURL=DateTimeFormat$PatternPart.js.map