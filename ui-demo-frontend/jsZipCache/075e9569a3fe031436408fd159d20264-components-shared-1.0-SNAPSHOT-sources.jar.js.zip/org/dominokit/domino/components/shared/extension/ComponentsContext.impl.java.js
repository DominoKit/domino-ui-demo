/**
 * @fileoverview transpiled from org.dominokit.domino.components.shared.extension.ComponentsContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Context = goog.require('org.dominokit.domino.api.shared.extension.Context$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {Context}
 */
class ComponentsContext {
  /**
   * @abstract
   * @return {ComponentCaseContext}
   * @public
   */
  m_getComponentCaseContext__() {
  }
  
  /**
   * @param {?function():ComponentCaseContext} fn
   * @return {ComponentsContext}
   * @public
   */
  static $adapt(fn) {
    ComponentsContext.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Context.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_components_shared_extension_ComponentsContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_components_shared_extension_ComponentsContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_components_shared_extension_ComponentsContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsContext.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentsContext, $Util.$makeClassName('org.dominokit.domino.components.shared.extension.ComponentsContext'));


ComponentsContext.$markImplementor(/** @type {Function} */ (ComponentsContext));


exports = ComponentsContext; 
//# sourceMappingURL=ComponentsContext.js.map