package org.dominokit.domino.components.shared.extension;

import org.dominokit.domino.api.shared.extension.ExtensionPoint;

public interface ComponentsExtensionPoint extends ExtensionPoint<ComponentsContext>{
}
