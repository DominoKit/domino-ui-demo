/**
 * @fileoverview transpiled from org.dominokit.domino.components.shared.extension.ComponentsContext$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.components.shared.extension.ComponentsContext.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 