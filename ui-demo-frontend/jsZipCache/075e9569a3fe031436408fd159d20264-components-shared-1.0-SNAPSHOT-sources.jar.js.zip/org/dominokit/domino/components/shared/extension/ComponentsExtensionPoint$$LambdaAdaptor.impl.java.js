/**
 * @fileoverview transpiled from org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentsExtensionPoint = goog.require('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');

let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ComponentsExtensionPoint}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentsContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():ComponentsContext} */
    this.f_$$fn__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$LambdaAdaptor__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentsContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$LambdaAdaptor__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {ComponentsContext}
   * @public
   */
  m_context__() {
    let /** ?function():ComponentsContext */ $function;
    return /**@type {ComponentsContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint_$LambdaAdaptor, $function()), ComponentsContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$$LambdaAdaptor'));


ComponentsExtensionPoint.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ComponentsExtensionPoint$$LambdaAdaptor.js.map