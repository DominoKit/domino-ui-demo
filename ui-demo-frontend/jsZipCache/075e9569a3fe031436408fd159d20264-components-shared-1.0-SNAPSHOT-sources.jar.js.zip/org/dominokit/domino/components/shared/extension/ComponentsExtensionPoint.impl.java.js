/**
 * @fileoverview transpiled from org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');

let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ExtensionPoint<ComponentsContext>}
 */
class ComponentsExtensionPoint {
  /**
   * @param {?function():ComponentsContext} fn
   * @return {ComponentsExtensionPoint}
   * @public
   */
  static $adapt(fn) {
    ComponentsExtensionPoint.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ExtensionPoint.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint'));


ComponentsExtensionPoint.$markImplementor(/** @type {Function} */ (ComponentsExtensionPoint));


exports = ComponentsExtensionPoint; 
//# sourceMappingURL=ComponentsExtensionPoint.js.map