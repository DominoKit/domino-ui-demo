/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentCaseView = goog.require('org.dominokit.domino.componentcase.client.views.ComponentCaseView$impl');

let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {ComponentCaseView}
  */
class ComponentCaseViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_contentPanel__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_;
    /** @public {Content} */
    this.f_content__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCaseViewImpl()'.
   * @return {!ComponentCaseViewImpl}
   * @public
   */
  static $create__() {
    ComponentCaseViewImpl.$clinit();
    let $instance = new ComponentCaseViewImpl();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCaseViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
    this.f_contentPanel__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_ = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(layout.m_getContentPanel__().m_get__()), $Overlay));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_contentPanel__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_.textContent = "";
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_scrollTop__() {
    DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.scrollTop = 0.0;
    DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.documentElement.scrollTop = 0.0;
  }
  
  /**
   * @override
   * @param {Content} content
   * @return {void}
   * @public
   */
  m_showContent__org_dominokit_domino_api_shared_extension_Content(content) {
    this.f_content__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_ = content;
    if (Objects.m_nonNull__java_lang_Object(content)) {
      this.f_contentPanel__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_.appendChild(/**@type {Node} */ ($Casts.$to(Js.m_cast__java_lang_Object(content.m_get__()), Node_$Overlay)));
    }
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    return this.f_content__org_dominokit_domino_componentcase_client_ui_views_ComponentCaseViewImpl_;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCaseViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCaseViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseViewImpl.$clinit = function() {};
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    Node_$Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCaseViewImpl, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl'));


ComponentCaseView.$markImplementor(ComponentCaseViewImpl);


exports = ComponentCaseViewImpl; 
//# sourceMappingURL=ComponentCaseViewImpl.js.map