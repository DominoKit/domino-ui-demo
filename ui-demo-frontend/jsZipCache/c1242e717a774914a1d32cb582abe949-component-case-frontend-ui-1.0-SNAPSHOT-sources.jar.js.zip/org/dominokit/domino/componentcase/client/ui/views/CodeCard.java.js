/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.CodeCard.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.CodeCard');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _ClipboardEvent_$Overlay = goog.require('elemental2.dom.ClipboardEvent.$Overlay');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLInputElement_$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard.$LambdaAdaptor$2');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Code = goog.require('org.dominokit.domino.ui.code.Code');
const _Block = goog.require('org.dominokit.domino.ui.code.Code.Block');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Response = goog.require('org.dominokit.rest.shared.Response');
const _RestfulRequest = goog.require('org.dominokit.rest.shared.RestfulRequest');
const _SuccessHandler = goog.require('org.dominokit.rest.shared.RestfulRequest.SuccessHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _InputType = goog.require('org.jboss.gwt.elemento.core.InputType');
const _InputBuilder = goog.require('org.jboss.gwt.elemento.core.builder.InputBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
exports = CodeCard;
 