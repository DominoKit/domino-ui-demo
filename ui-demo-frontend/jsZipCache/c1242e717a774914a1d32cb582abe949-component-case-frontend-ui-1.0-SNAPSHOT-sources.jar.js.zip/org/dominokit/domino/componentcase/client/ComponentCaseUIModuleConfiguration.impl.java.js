/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration.$1$impl');
let ComponentCasePresenter = goog.forwardDeclare('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');


/**
 * @implements {ModuleConfiguration}
  */
class ComponentCaseUIModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCaseUIModuleConfiguration()'.
   * @return {!ComponentCaseUIModuleConfiguration}
   * @public
   */
  static $create__() {
    ComponentCaseUIModuleConfiguration.$clinit();
    let $instance = new ComponentCaseUIModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCaseUIModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($1.$create__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration__java_lang_String(this, Class.$get(ComponentCasePresenter).m_getCanonicalName__()));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DominoEventsRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(arg0) {
    ModuleConfiguration.m_registerListeners__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_extension_DominoEventsRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {PresenterRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(arg0) {
    ModuleConfiguration.m_registerPresenters__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_PresenterRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CommandRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(arg0) {
    ModuleConfiguration.m_registerRequests__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_CommandRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCaseUIModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCaseUIModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseUIModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration.$1$impl');
    ComponentCasePresenter = goog.module.get('org.dominokit.domino.componentcase.client.presenters.ComponentCasePresenter$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ComponentCaseUIModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration'));


ModuleConfiguration.$markImplementor(ComponentCaseUIModuleConfiguration);


exports = ComponentCaseUIModuleConfiguration; 
//# sourceMappingURL=ComponentCaseUIModuleConfiguration.js.map