/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode.$LambdaAdaptor$3');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
exports = LinkToSourceCode;
 