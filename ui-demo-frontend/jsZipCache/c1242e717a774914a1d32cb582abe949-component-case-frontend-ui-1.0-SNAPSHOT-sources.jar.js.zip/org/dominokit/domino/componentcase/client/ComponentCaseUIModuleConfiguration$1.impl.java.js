/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');

let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let ComponentCaseUIModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration$impl');
let ComponentCaseViewImpl = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl$impl');


class $1 extends LazyViewLoader {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ComponentCaseUIModuleConfiguration} */
    this.f_$outer_this__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new LazyViewLoader(ComponentCaseUIModuleConfiguration, String)'.
   * @param {ComponentCaseUIModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration__java_lang_String($outer_this, $_0) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration_1__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new LazyViewLoader(ComponentCaseUIModuleConfiguration, String)'.
   * @param {ComponentCaseUIModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration_1__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_componentcase_client_ComponentCaseUIModuleConfiguration_1 = $outer_this;
    this.$ctor__org_dominokit_domino_api_client_mvp_view_LazyViewLoader__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {View}
   * @public
   */
  m_make__() {
    return ComponentCaseViewImpl.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    ComponentCaseViewImpl = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl$impl');
    LazyViewLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ComponentCaseUIModuleConfiguration$1'));




exports = $1; 
//# sourceMappingURL=ComponentCaseUIModuleConfiguration$1.js.map