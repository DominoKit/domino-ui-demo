/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ComponentCaseUIClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ComponentCaseUIClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ComponentCaseUIClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ComponentCaseUIClientModule()'.
   * @return {!ComponentCaseUIClientModule}
   * @public
   */
  static $create__() {
    ComponentCaseUIClientModule.$clinit();
    let $instance = new ComponentCaseUIClientModule();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ComponentCaseUIClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ComponentCaseUIClientModule.$f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_.m_info__java_lang_String("Initializing ComponentCase frontend UI module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_() {
    return (ComponentCaseUIClientModule.$clinit(), ComponentCaseUIClientModule.$f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_(value) {
    (ComponentCaseUIClientModule.$clinit(), ComponentCaseUIClientModule.$f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ComponentCaseUIClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ComponentCaseUIClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentCaseUIClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ComponentCaseUIClientModule.$f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ComponentCaseUIClientModule));
  }
  
  
};

$Util.$setClassMetadata(ComponentCaseUIClientModule, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ComponentCaseUIClientModule'));


/** @private {Logger} */
ComponentCaseUIClientModule.$f_LOGGER__org_dominokit_domino_componentcase_client_ComponentCaseUIClientModule_;




exports = ComponentCaseUIClientModule; 
//# sourceMappingURL=ComponentCaseUIClientModule.js.map