/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.Constants.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.Constants$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Constants extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Constants()'.
   * @return {!Constants}
   * @public
   */
  static $create__() {
    Constants.$clinit();
    let $instance = new Constants();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ui_views_Constants__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Constants()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ui_views_Constants__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Constants;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Constants);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Constants.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Constants, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ui.views.Constants'));


/** @public {?string} @const */
Constants.f_LARGE_PARAGRAPH__org_dominokit_domino_componentcase_client_ui_views_Constants = "Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget";


/** @public {?string} @const */
Constants.f_SMALL_PARAGRAPH__org_dominokit_domino_componentcase_client_ui_views_Constants = "Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc.";


/** @public {?string} @const */
Constants.f_SMALLER_PARAGRAPH__org_dominokit_domino_componentcase_client_ui_views_Constants = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.";


/** @public {?string} @const */
Constants.f_SAMPLE_TEXT__org_dominokit_domino_componentcase_client_ui_views_Constants = "In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.";




exports = Constants; 
//# sourceMappingURL=Constants.js.map