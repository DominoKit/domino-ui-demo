/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.IsElement$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.IsElement.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


/**
 * @template C_E
 * @implements {IsElement<C_E>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():C_E} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():C_E} */
    this.f_$$fn__org_jboss_gwt_elemento_core_IsElement_$LambdaAdaptor;
    this.$ctor__org_jboss_gwt_elemento_core_IsElement_$LambdaAdaptor__org_jboss_gwt_elemento_core_IsElement_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():C_E} fn
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_IsElement_$LambdaAdaptor__org_jboss_gwt_elemento_core_IsElement_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_jboss_gwt_elemento_core_IsElement_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {C_E}
   * @public
   */
  m_asElement__() {
    let /** ?function():C_E */ $function;
    return ($function = this.f_$$fn__org_jboss_gwt_elemento_core_IsElement_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.jboss.gwt.elemento.core.IsElement$$LambdaAdaptor'));


IsElement.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=IsElement$$LambdaAdaptor.js.map