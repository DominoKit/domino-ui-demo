/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.views.ui.PreloadersViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.preloaders.client.views.ui.PreloadersViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const PreloadersView = goog.require('org.dominokit.domino.preloaders.client.views.PreloadersView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.preloaders.client.views.CodeResource$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Preloader = goog.forwardDeclare('org.dominokit.domino.ui.preloaders.Preloader$impl');
let Size = goog.forwardDeclare('org.dominokit.domino.ui.preloaders.Preloader.Size$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {PreloadersView}
  */
class PreloadersViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'PreloadersViewImpl()'.
   * @return {!PreloadersViewImpl}
   * @public
   */
  static $create__() {
    PreloadersViewImpl.$clinit();
    let $instance = new PreloadersViewImpl();
    $instance.$ctor__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PreloadersViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("PRELOADERS").m_asElement__());
    this.m_sizesSample___$p_org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl();
    this.m_colorsSample___$p_org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_sizesSample___$p_org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl() {
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_.appendChild(Card.m_create__java_lang_String("PRELOADERS - DIFFERENT SIZES").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-preloader"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setSize__org_dominokit_domino_ui_preloaders_Preloader_Size(Size.f_xLarge__org_dominokit_domino_ui_preloaders_Preloader_Size).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setSize__org_dominokit_domino_ui_preloaders_Preloader_Size(Size.f_large__org_dominokit_domino_ui_preloaders_Preloader_Size).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setSize__org_dominokit_domino_ui_preloaders_Preloader_Size(Size.f_medium__org_dominokit_domino_ui_preloaders_Preloader_Size).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setSize__org_dominokit_domino_ui_preloaders_Preloader_Size(Size.f_small__org_dominokit_domino_ui_preloaders_Preloader_Size).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setSize__org_dominokit_domino_ui_preloaders_Preloader_Size(Size.f_xSmall__org_dominokit_domino_ui_preloaders_Preloader_Size).m_asElement__()), HtmlContentBuilder)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_sizesSample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_colorsSample___$p_org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl() {
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("WITH MATERIAL DESIGN COLORS", "You can use the material design colors.").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["demo-preloader"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLACK__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BROWN__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIME__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(Preloader.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_asElement__()), HtmlContentBuilder)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_colorsSample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl() {
    this.f_element__org_dominokit_domino_preloaders_client_views_ui_PreloadersViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PreloadersViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PreloadersViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PreloadersViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeResource = goog.module.get('org.dominokit.domino.preloaders.client.views.CodeResource$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Preloader = goog.module.get('org.dominokit.domino.ui.preloaders.Preloader$impl');
    Size = goog.module.get('org.dominokit.domino.ui.preloaders.Preloader.Size$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PreloadersViewImpl, $Util.$makeClassName('org.dominokit.domino.preloaders.client.views.ui.PreloadersViewImpl'));


PreloadersView.$markImplementor(PreloadersViewImpl);


exports = PreloadersViewImpl; 
//# sourceMappingURL=PreloadersViewImpl.js.map