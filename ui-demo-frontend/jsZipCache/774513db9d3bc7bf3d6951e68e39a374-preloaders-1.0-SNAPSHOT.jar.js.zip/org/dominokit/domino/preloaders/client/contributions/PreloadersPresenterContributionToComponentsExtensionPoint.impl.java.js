/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.contributions.PreloadersPresenterContributionToComponentsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.preloaders.client.contributions.PreloadersPresenterContributionToComponentsExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let PreloadersPresenter = goog.forwardDeclare('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter$impl');
let PreloadersPresenterCommand = goog.forwardDeclare('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentsExtensionPoint>}
  */
class PreloadersPresenterContributionToComponentsExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PreloadersPresenterContributionToComponentsExtensionPoint()'.
   * @return {!PreloadersPresenterContributionToComponentsExtensionPoint}
   * @public
   */
  static $create__() {
    PreloadersPresenterContributionToComponentsExtensionPoint.$clinit();
    let $instance = new PreloadersPresenterContributionToComponentsExtensionPoint();
    $instance.$ctor__org_dominokit_domino_preloaders_client_contributions_PreloadersPresenterContributionToComponentsExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PreloadersPresenterContributionToComponentsExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_preloaders_client_contributions_PreloadersPresenterContributionToComponentsExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(extensionPoint) {
    PreloadersPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** PreloadersPresenter */ presenter) =>{
      presenter.m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_components_shared_extension_ComponentsExtensionPoint(/**@type {ComponentsExtensionPoint} */ ($Casts.$to(arg0, ComponentsExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PreloadersPresenterContributionToComponentsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PreloadersPresenterContributionToComponentsExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PreloadersPresenterContributionToComponentsExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    PreloadersPresenterCommand = goog.module.get('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PreloadersPresenterContributionToComponentsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.preloaders.client.contributions.PreloadersPresenterContributionToComponentsExtensionPoint'));


Contribution.$markImplementor(PreloadersPresenterContributionToComponentsExtensionPoint);


exports = PreloadersPresenterContributionToComponentsExtensionPoint; 
//# sourceMappingURL=PreloadersPresenterContributionToComponentsExtensionPoint.js.map