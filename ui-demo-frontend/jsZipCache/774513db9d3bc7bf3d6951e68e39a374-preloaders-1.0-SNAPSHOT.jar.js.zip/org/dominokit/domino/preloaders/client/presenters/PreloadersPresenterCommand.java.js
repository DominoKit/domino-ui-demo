/**
 * @fileoverview transpiled from org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _PreloadersPresenter = goog.require('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenter');


// Re-exports the implementation.
var PreloadersPresenterCommand = goog.require('org.dominokit.domino.preloaders.client.presenters.PreloadersPresenterCommand$impl');
exports = PreloadersPresenterCommand;
 