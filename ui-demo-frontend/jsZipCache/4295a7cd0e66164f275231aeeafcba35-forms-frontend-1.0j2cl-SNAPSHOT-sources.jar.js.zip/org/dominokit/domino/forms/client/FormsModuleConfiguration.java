package org.dominokit.domino.forms.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint;
import org.dominokit.domino.forms.client.contributions.FormsPresenterContributionToComponentCaseExtensionPoint;
import org.dominokit.domino.forms.client.presenters.FormsPresenter;
import org.dominokit.domino.forms.client.presenters.FormsPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class FormsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(FormsPresenter.class.getCanonicalName(), FormsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new FormsPresenter();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(FormsPresenterCommand.class.getCanonicalName(), FormsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentCaseExtensionPoint.class, new FormsPresenterContributionToComponentCaseExtensionPoint());
  }
}
