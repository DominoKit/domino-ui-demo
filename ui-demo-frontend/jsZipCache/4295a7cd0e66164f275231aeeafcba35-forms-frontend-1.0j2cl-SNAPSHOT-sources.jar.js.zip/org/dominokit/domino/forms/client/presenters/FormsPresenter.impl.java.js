/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.presenters.FormsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.presenters.FormsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.forms.client.presenters.FormsPresenter.$1$impl');
let FormsView = goog.forwardDeclare('org.dominokit.domino.forms.client.views.FormsView$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let FormsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<FormsView>}
  */
class FormsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsPresenter()'.
   * @return {!FormsPresenter}
   * @public
   */
  static $create__() {
    FormsPresenter.$clinit();
    let $instance = new FormsPresenter();
    $instance.$ctor__org_dominokit_domino_forms_client_presenters_FormsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_presenters_FormsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_contributeToMainModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_forms_client_presenters_FormsPresenter(this));
    this.m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(Class.$get(FormsExtensionPoint), FormsExtensionPoint.$adapt((() =>{
      return FormsContext.$adapt((() =>{
        return context;
      }));
    })));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_forms_client_presenters_FormsPresenter_() {
    return (FormsPresenter.$clinit(), FormsPresenter.$f_LOGGER__org_dominokit_domino_forms_client_presenters_FormsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_forms_client_presenters_FormsPresenter_(value) {
    (FormsPresenter.$clinit(), FormsPresenter.$f_LOGGER__org_dominokit_domino_forms_client_presenters_FormsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.forms.client.presenters.FormsPresenter.$1$impl');
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    FormsExtensionPoint = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    FormsPresenter.$f_LOGGER__org_dominokit_domino_forms_client_presenters_FormsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormsPresenter));
  }
  
  
};

$Util.$setClassMetadata(FormsPresenter, $Util.$makeClassName('org.dominokit.domino.forms.client.presenters.FormsPresenter'));


/** @private {Logger} */
FormsPresenter.$f_LOGGER__org_dominokit_domino_forms_client_presenters_FormsPresenter_;




exports = FormsPresenter; 
//# sourceMappingURL=FormsPresenter.js.map