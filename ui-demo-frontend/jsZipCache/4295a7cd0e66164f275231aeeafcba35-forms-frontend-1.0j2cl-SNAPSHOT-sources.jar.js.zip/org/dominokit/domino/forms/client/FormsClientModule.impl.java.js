/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.FormsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.FormsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class FormsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsClientModule()'.
   * @return {!FormsClientModule}
   * @public
   */
  static $create__() {
    FormsClientModule.$clinit();
    let $instance = new FormsClientModule();
    $instance.$ctor__org_dominokit_domino_forms_client_FormsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_FormsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    FormsClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_.m_info__java_lang_String("Initializing Forms frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_() {
    return (FormsClientModule.$clinit(), FormsClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_(value) {
    (FormsClientModule.$clinit(), FormsClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    FormsClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormsClientModule));
  }
  
  
};

$Util.$setClassMetadata(FormsClientModule, $Util.$makeClassName('org.dominokit.domino.forms.client.FormsClientModule'));


/** @private {Logger} */
FormsClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsClientModule_;




exports = FormsClientModule; 
//# sourceMappingURL=FormsClientModule.js.map