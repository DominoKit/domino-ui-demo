/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.presenters.ListsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.lists.client.presenters.ListsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.lists.client.presenters.ListsPresenter.$1$impl');
let ListsView = goog.forwardDeclare('org.dominokit.domino.lists.client.views.ListsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<ListsView>}
  */
class ListsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ListsPresenter()'.
   * @return {!ListsPresenter}
   * @public
   */
  static $create__() {
    ListsPresenter.$clinit();
    let $instance = new ListsPresenter();
    $instance.$ctor__org_dominokit_domino_lists_client_presenters_ListsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_lists_client_presenters_ListsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_lists_client_presenters_ListsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_lists_client_presenters_ListsPresenter_() {
    return (ListsPresenter.$clinit(), ListsPresenter.$f_LOGGER__org_dominokit_domino_lists_client_presenters_ListsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_lists_client_presenters_ListsPresenter_(value) {
    (ListsPresenter.$clinit(), ListsPresenter.$f_LOGGER__org_dominokit_domino_lists_client_presenters_ListsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.lists.client.presenters.ListsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    ListsPresenter.$f_LOGGER__org_dominokit_domino_lists_client_presenters_ListsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ListsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ListsPresenter, $Util.$makeClassName('org.dominokit.domino.lists.client.presenters.ListsPresenter'));


/** @private {Logger} */
ListsPresenter.$f_LOGGER__org_dominokit_domino_lists_client_presenters_ListsPresenter_;




exports = ListsPresenter; 
//# sourceMappingURL=ListsPresenter.js.map