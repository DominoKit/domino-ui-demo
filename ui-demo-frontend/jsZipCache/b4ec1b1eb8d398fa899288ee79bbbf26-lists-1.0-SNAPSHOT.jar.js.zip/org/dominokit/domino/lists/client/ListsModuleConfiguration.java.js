/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.ListsModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.lists.client.ListsModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _ComponentsExtensionPoint = goog.require('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint');
const _$1 = goog.require('org.dominokit.domino.lists.client.ListsModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.lists.client.ListsModuleConfiguration.$2');
const _ListsPresenterContributionToComponentsExtensionPoint = goog.require('org.dominokit.domino.lists.client.contributions.ListsPresenterContributionToComponentsExtensionPoint');
const _ListsPresenter = goog.require('org.dominokit.domino.lists.client.presenters.ListsPresenter');
const _ListsPresenterCommand = goog.require('org.dominokit.domino.lists.client.presenters.ListsPresenterCommand');


// Re-exports the implementation.
var ListsModuleConfiguration = goog.require('org.dominokit.domino.lists.client.ListsModuleConfiguration$impl');
exports = ListsModuleConfiguration;
 