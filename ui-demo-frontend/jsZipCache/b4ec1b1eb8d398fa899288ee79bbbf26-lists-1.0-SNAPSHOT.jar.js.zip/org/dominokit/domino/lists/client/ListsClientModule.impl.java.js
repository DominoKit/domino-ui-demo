/**
 * @fileoverview transpiled from org.dominokit.domino.lists.client.ListsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.lists.client.ListsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ListsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ListsClientModule()'.
   * @return {!ListsClientModule}
   * @public
   */
  static $create__() {
    ListsClientModule.$clinit();
    let $instance = new ListsClientModule();
    $instance.$ctor__org_dominokit_domino_lists_client_ListsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_lists_client_ListsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ListsClientModule.$f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_.m_info__java_lang_String("Initializing Lists frontend module ... ");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_() {
    return (ListsClientModule.$clinit(), ListsClientModule.$f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_(value) {
    (ListsClientModule.$clinit(), ListsClientModule.$f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ListsClientModule.$f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ListsClientModule));
  }
  
  
};

$Util.$setClassMetadata(ListsClientModule, $Util.$makeClassName('org.dominokit.domino.lists.client.ListsClientModule'));


/** @private {Logger} */
ListsClientModule.$f_LOGGER__org_dominokit_domino_lists_client_ListsClientModule_;




exports = ListsClientModule; 
//# sourceMappingURL=ListsClientModule.js.map