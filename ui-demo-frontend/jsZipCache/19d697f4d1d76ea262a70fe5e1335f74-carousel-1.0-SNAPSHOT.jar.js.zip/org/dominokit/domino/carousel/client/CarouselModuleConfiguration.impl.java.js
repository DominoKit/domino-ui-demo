/**
 * @fileoverview transpiled from org.dominokit.domino.carousel.client.CarouselModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.carousel.client.CarouselModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.carousel.client.CarouselModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.carousel.client.CarouselModuleConfiguration.$2$impl');
let CarouselPresenterListenerForComponentsEvent = goog.forwardDeclare('org.dominokit.domino.carousel.client.listeners.CarouselPresenterListenerForComponentsEvent$impl');
let CarouselPresenter = goog.forwardDeclare('org.dominokit.domino.carousel.client.presenters.CarouselPresenter$impl');
let CarouselPresenterCommand = goog.forwardDeclare('org.dominokit.domino.carousel.client.presenters.CarouselPresenterCommand$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');


/**
 * @implements {ModuleConfiguration}
  */
class CarouselModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CarouselModuleConfiguration()'.
   * @return {!CarouselModuleConfiguration}
   * @public
   */
  static $create__() {
    CarouselModuleConfiguration.$clinit();
    let $instance = new CarouselModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_carousel_client_CarouselModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CarouselModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_carousel_client_CarouselModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_carousel_client_CarouselModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(CarouselPresenter).m_getCanonicalName__(), Class.$get(CarouselPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_carousel_client_CarouselModuleConfiguration__java_lang_String(this, Class.$get(CarouselPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(CarouselPresenterCommand).m_getCanonicalName__(), Class.$get(CarouselPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentsEvent), CarouselPresenterListenerForComponentsEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CarouselModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CarouselModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CarouselModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.carousel.client.CarouselModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.carousel.client.CarouselModuleConfiguration.$2$impl');
    CarouselPresenterListenerForComponentsEvent = goog.module.get('org.dominokit.domino.carousel.client.listeners.CarouselPresenterListenerForComponentsEvent$impl');
    CarouselPresenter = goog.module.get('org.dominokit.domino.carousel.client.presenters.CarouselPresenter$impl');
    CarouselPresenterCommand = goog.module.get('org.dominokit.domino.carousel.client.presenters.CarouselPresenterCommand$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CarouselModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.carousel.client.CarouselModuleConfiguration'));


ModuleConfiguration.$markImplementor(CarouselModuleConfiguration);


exports = CarouselModuleConfiguration; 
//# sourceMappingURL=CarouselModuleConfiguration.js.map