/**
 * @fileoverview transpiled from org.dominokit.domino.carousel.client.views.CarouselView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.carousel.client.views.CarouselView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.carousel.client.views.CarouselView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class CarouselView {
  /**
   * @param {?function():Content} fn
   * @return {CarouselView}
   * @public
   */
  static $adapt(fn) {
    CarouselView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_carousel_client_views_CarouselView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_carousel_client_views_CarouselView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_carousel_client_views_CarouselView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CarouselView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.carousel.client.views.CarouselView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CarouselView, $Util.$makeClassName('org.dominokit.domino.carousel.client.views.CarouselView'));


CarouselView.$markImplementor(/** @type {Function} */ (CarouselView));


exports = CarouselView; 
//# sourceMappingURL=CarouselView.js.map