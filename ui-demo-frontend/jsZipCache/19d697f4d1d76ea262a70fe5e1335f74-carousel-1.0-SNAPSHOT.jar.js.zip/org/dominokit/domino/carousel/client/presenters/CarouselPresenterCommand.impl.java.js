/**
 * @fileoverview transpiled from org.dominokit.domino.carousel.client.presenters.CarouselPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.carousel.client.presenters.CarouselPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let CarouselPresenter = goog.forwardDeclare('org.dominokit.domino.carousel.client.presenters.CarouselPresenter$impl');


/**
 * @extends {PresenterCommand<CarouselPresenter>}
  */
class CarouselPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CarouselPresenterCommand()'.
   * @return {!CarouselPresenterCommand}
   * @public
   */
  static $create__() {
    CarouselPresenterCommand.$clinit();
    let $instance = new CarouselPresenterCommand();
    $instance.$ctor__org_dominokit_domino_carousel_client_presenters_CarouselPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CarouselPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_carousel_client_presenters_CarouselPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CarouselPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CarouselPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CarouselPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CarouselPresenterCommand, $Util.$makeClassName('org.dominokit.domino.carousel.client.presenters.CarouselPresenterCommand'));




exports = CarouselPresenterCommand; 
//# sourceMappingURL=CarouselPresenterCommand.js.map