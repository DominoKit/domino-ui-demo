/**
 * @fileoverview transpiled from org.dominokit.domino.carousel.client.views.ui.CarouselViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.carousel.client.views.ui.CarouselViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const CarouselView = goog.require('org.dominokit.domino.carousel.client.views.CarouselView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Carousel = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel$impl');
let Slide = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Slide$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {CarouselView}
  */
class CarouselViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'CarouselViewImpl()'.
   * @return {!CarouselViewImpl}
   * @public
   */
  static $create__() {
    CarouselViewImpl.$clinit();
    let $instance = new CarouselViewImpl();
    $instance.$ctor__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CarouselViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(CarouselViewImpl.f_MODULE_NAME__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("CAROUSEL").m_asElement__());
    this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Carousel.m_create__().m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String("static/images/image-gallery/11.jpg")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String("static/images/image-gallery/12.jpg")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String("static/images/image-gallery/19.jpg")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String("static/images/image-gallery/9.jpg")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String("static/images/image-gallery/6.jpg")))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Carousel.m_create__().m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String__java_lang_String__java_lang_String("static/images/image-gallery/11.jpg", "Slide 1", "First slide description")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String__java_lang_String__java_lang_String("static/images/image-gallery/12.jpg", "Slide 2", "Second slide description")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String__java_lang_String__java_lang_String("static/images/image-gallery/19.jpg", "Slide 3", "Third slide description")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String__java_lang_String__java_lang_String("static/images/image-gallery/9.jpg", "Slide 4", "Fourth slide description")).m_appendChild__org_dominokit_domino_ui_carousel_Slide(Slide.m_create__java_lang_String__java_lang_String__java_lang_String("static/images/image-gallery/6.jpg", "Slide 5", "Fifth slide description")).m_startAutoSlide__int(3000))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(CarouselViewImpl.f_MODULE_NAME__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl, "carousel").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl() {
    this.f_element__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CarouselViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CarouselViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CarouselViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Carousel = goog.module.get('org.dominokit.domino.ui.carousel.Carousel$impl');
    Slide = goog.module.get('org.dominokit.domino.ui.carousel.Slide$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CarouselViewImpl, $Util.$makeClassName('org.dominokit.domino.carousel.client.views.ui.CarouselViewImpl'));


/** @public {?string} @const */
CarouselViewImpl.f_MODULE_NAME__org_dominokit_domino_carousel_client_views_ui_CarouselViewImpl = "carousel";


CarouselView.$markImplementor(CarouselViewImpl);


exports = CarouselViewImpl; 
//# sourceMappingURL=CarouselViewImpl.js.map