/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter.$1$impl');
let BasicFormsView = goog.forwardDeclare('org.dominokit.domino.basicforms.client.views.BasicFormsView$impl');
let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<BasicFormsView>}
  */
class BasicFormsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'BasicFormsPresenter()'.
   * @return {!BasicFormsPresenter}
   * @public
   */
  static $create__() {
    BasicFormsPresenter.$clinit();
    let $instance = new BasicFormsPresenter();
    $instance.$ctor__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BasicFormsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {FormsContext} context
   * @return {void}
   * @public
   */
  m_onMainEvent__org_dominokit_domino_forms_shared_extension_FormsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter_() {
    return (BasicFormsPresenter.$clinit(), BasicFormsPresenter.$f_LOGGER__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter_(value) {
    (BasicFormsPresenter.$clinit(), BasicFormsPresenter.$f_LOGGER__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BasicFormsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BasicFormsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BasicFormsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    BasicFormsPresenter.$f_LOGGER__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(BasicFormsPresenter));
  }
  
  
};

$Util.$setClassMetadata(BasicFormsPresenter, $Util.$makeClassName('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter'));


/** @private {Logger} */
BasicFormsPresenter.$f_LOGGER__org_dominokit_domino_basicforms_client_presenters_BasicFormsPresenter_;




exports = BasicFormsPresenter; 
//# sourceMappingURL=BasicFormsPresenter.js.map