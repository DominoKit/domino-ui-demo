/**
 * @fileoverview transpiled from org.dominokit.domino.basicforms.client.listeners.BasicFormsPresenterListenerForFormsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.basicforms.client.listeners.BasicFormsPresenterListenerForFormsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _BasicFormsPresenter = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenter');
const _BasicFormsPresenterCommand = goog.require('org.dominokit.domino.basicforms.client.presenters.BasicFormsPresenterCommand');
const _FormsContext = goog.require('org.dominokit.domino.forms.shared.extension.FormsContext');
const _FormsEvent = goog.require('org.dominokit.domino.forms.shared.extension.FormsEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BasicFormsPresenterListenerForFormsEvent = goog.require('org.dominokit.domino.basicforms.client.listeners.BasicFormsPresenterListenerForFormsEvent$impl');
exports = BasicFormsPresenterListenerForFormsEvent;
 