/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ModalsPresenter = goog.require('org.dominokit.domino.modals.client.presenters.ModalsPresenter');


// Re-exports the implementation.
var ModalsPresenterCommand = goog.require('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand$impl');
exports = ModalsPresenterCommand;
 