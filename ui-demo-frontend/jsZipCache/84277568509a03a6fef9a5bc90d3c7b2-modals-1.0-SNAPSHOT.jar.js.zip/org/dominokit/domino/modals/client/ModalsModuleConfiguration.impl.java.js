/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.ModalsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.ModalsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.modals.client.ModalsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.modals.client.ModalsModuleConfiguration.$2$impl');
let ModalsPresenterContributionToComponentsExtensionPoint = goog.forwardDeclare('org.dominokit.domino.modals.client.contributions.ModalsPresenterContributionToComponentsExtensionPoint$impl');
let ModalsPresenter = goog.forwardDeclare('org.dominokit.domino.modals.client.presenters.ModalsPresenter$impl');
let ModalsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class ModalsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ModalsModuleConfiguration()'.
   * @return {!ModalsModuleConfiguration}
   * @public
   */
  static $create__() {
    ModalsModuleConfiguration.$clinit();
    let $instance = new ModalsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_modals_client_ModalsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_modals_client_ModalsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_modals_client_ModalsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(ModalsPresenter).m_getCanonicalName__(), Class.$get(ModalsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_modals_client_ModalsModuleConfiguration__java_lang_String(this, Class.$get(ModalsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(ModalsPresenterCommand).m_getCanonicalName__(), Class.$get(ModalsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(ComponentsExtensionPoint), ModalsPresenterContributionToComponentsExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentsExtensionPoint = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint$impl');
    $1 = goog.module.get('org.dominokit.domino.modals.client.ModalsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.modals.client.ModalsModuleConfiguration.$2$impl');
    ModalsPresenterContributionToComponentsExtensionPoint = goog.module.get('org.dominokit.domino.modals.client.contributions.ModalsPresenterContributionToComponentsExtensionPoint$impl');
    ModalsPresenter = goog.module.get('org.dominokit.domino.modals.client.presenters.ModalsPresenter$impl');
    ModalsPresenterCommand = goog.module.get('org.dominokit.domino.modals.client.presenters.ModalsPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ModalsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.modals.client.ModalsModuleConfiguration'));


ModuleConfiguration.$markImplementor(ModalsModuleConfiguration);


exports = ModalsModuleConfiguration; 
//# sourceMappingURL=ModalsModuleConfiguration.js.map