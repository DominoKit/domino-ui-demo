/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.presenters.ModalsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.presenters.ModalsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.modals.client.presenters.ModalsPresenter.$1$impl');
let ModalsView = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ModalsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<ModalsView>}
  */
class ModalsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ModalsPresenter()'.
   * @return {!ModalsPresenter}
   * @public
   */
  static $create__() {
    ModalsPresenter.$clinit();
    let $instance = new ModalsPresenter();
    $instance.$ctor__org_dominokit_domino_modals_client_presenters_ModalsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_modals_client_presenters_ModalsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_modals_client_presenters_ModalsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_modals_client_presenters_ModalsPresenter_() {
    return (ModalsPresenter.$clinit(), ModalsPresenter.$f_LOGGER__org_dominokit_domino_modals_client_presenters_ModalsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_modals_client_presenters_ModalsPresenter_(value) {
    (ModalsPresenter.$clinit(), ModalsPresenter.$f_LOGGER__org_dominokit_domino_modals_client_presenters_ModalsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.modals.client.presenters.ModalsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    ModalsPresenter.$f_LOGGER__org_dominokit_domino_modals_client_presenters_ModalsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ModalsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ModalsPresenter, $Util.$makeClassName('org.dominokit.domino.modals.client.presenters.ModalsPresenter'));


/** @private {Logger} */
ModalsPresenter.$f_LOGGER__org_dominokit_domino_modals_client_presenters_ModalsPresenter_;




exports = ModalsPresenter; 
//# sourceMappingURL=ModalsPresenter.js.map