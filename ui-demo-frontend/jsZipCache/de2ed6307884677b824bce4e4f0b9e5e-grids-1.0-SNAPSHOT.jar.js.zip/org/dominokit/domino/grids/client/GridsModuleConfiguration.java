package org.dominokit.domino.grids.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent;
import org.dominokit.domino.grids.client.presenters.GridsPresenter;
import org.dominokit.domino.grids.client.presenters.GridsPresenterCommand;
import org.dominokit.domino.grids.client.views.ui.GridsViewImpl;
import org.dominokit.domino.layouts.shared.extension.LayoutsEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class GridsModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(GridsPresenter.class.getCanonicalName(), GridsPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new GridsPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(GridsPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new GridsViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(GridsPresenterCommand.class.getCanonicalName(), GridsPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(LayoutsEvent.class, new GridsPresenterListenerForLayoutsEvent());
  }
}
