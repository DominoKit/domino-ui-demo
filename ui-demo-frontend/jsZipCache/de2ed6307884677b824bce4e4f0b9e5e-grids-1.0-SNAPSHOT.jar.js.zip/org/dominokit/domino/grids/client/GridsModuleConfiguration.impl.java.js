/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.GridsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.grids.client.GridsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.grids.client.GridsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.grids.client.GridsModuleConfiguration.$2$impl');
let GridsPresenterListenerForLayoutsEvent = goog.forwardDeclare('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent$impl');
let GridsPresenter = goog.forwardDeclare('org.dominokit.domino.grids.client.presenters.GridsPresenter$impl');
let GridsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand$impl');
let LayoutsEvent = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');


/**
 * @implements {ModuleConfiguration}
  */
class GridsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GridsModuleConfiguration()'.
   * @return {!GridsModuleConfiguration}
   * @public
   */
  static $create__() {
    GridsModuleConfiguration.$clinit();
    let $instance = new GridsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_grids_client_GridsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GridsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_grids_client_GridsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_grids_client_GridsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(GridsPresenter).m_getCanonicalName__(), Class.$get(GridsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_grids_client_GridsModuleConfiguration__java_lang_String(this, Class.$get(GridsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(GridsPresenterCommand).m_getCanonicalName__(), Class.$get(GridsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(LayoutsEvent), GridsPresenterListenerForLayoutsEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GridsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GridsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.grids.client.GridsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.grids.client.GridsModuleConfiguration.$2$impl');
    GridsPresenterListenerForLayoutsEvent = goog.module.get('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent$impl');
    GridsPresenter = goog.module.get('org.dominokit.domino.grids.client.presenters.GridsPresenter$impl');
    GridsPresenterCommand = goog.module.get('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand$impl');
    LayoutsEvent = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GridsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.grids.client.GridsModuleConfiguration'));


ModuleConfiguration.$markImplementor(GridsModuleConfiguration);


exports = GridsModuleConfiguration; 
//# sourceMappingURL=GridsModuleConfiguration.js.map