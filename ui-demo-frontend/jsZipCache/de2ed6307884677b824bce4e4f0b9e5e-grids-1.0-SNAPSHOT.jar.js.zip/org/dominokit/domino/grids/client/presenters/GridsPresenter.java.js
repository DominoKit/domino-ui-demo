/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.presenters.GridsPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.grids.client.presenters.GridsPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _$1 = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenter.$1');
const _GridsView = goog.require('org.dominokit.domino.grids.client.views.GridsView');
const _LayoutsEventContext = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var GridsPresenter = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenter$impl');
exports = GridsPresenter;
 