/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ChipsView = goog.require('org.dominokit.domino.chips.client.views.ChipsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$4$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Chip = goog.forwardDeclare('org.dominokit.domino.ui.chips.Chip$impl');
let ChipsGroup = goog.forwardDeclare('org.dominokit.domino.ui.chips.ChipsGroup$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let DeselectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasDeselectionHandler.DeselectionHandler$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ChipsView}
  */
class ChipsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
    /** @public {Card} */
    this.f_simpleCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
    /** @public {Card} */
    this.f_removableCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
    /** @public {Card} */
    this.f_iconChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
    /** @public {Card} */
    this.f_imagesChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
    /** @public {Card} */
    this.f_lettersChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
    /** @public {Card} */
    this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ChipsViewImpl()'.
   * @return {!ChipsViewImpl}
   * @public
   */
  static $create__() {
    ChipsViewImpl.$clinit();
    let $instance = new ChipsViewImpl();
    $instance.$ctor__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ChipsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("CHIPS").m_asElement__());
    this.f_simpleCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = Card.m_create__java_lang_String("SIMPLE CHIPS");
    this.f_removableCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = Card.m_create__java_lang_String("REMOVABLE CHIPS");
    this.f_iconChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = Card.m_create__java_lang_String("CHIPS WITH ICONS");
    this.f_imagesChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = Card.m_create__java_lang_String("CHIPS WITH IMAGES");
    this.f_lettersChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = Card.m_create__java_lang_String("CHIPS WITH LETTERS");
    this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = Card.m_create__java_lang_String("SELECTABLE CHIPS");
    this.m_initSimpleExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
    this.m_initRemovableExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
    this.m_initChipsWithIconsExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
    this.m_initChipsWithImagesExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
    this.m_initChipsWithLettersExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
    this.m_initSelectableChipsExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl();
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(this.f_simpleCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, "simple").m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(this.f_removableCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, "removable").m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(this.f_iconChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, "chips-with-icons").m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(this.f_imagesChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, "chips-with-images").m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(this.f_lettersChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, "chips-with-letters").m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl, "selectable").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSimpleExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    this.f_simpleCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Sounds good, let's do that!")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Yay! I'll be there").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_RED__org_dominokit_domino_ui_style_ColorScheme)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Hey, how are you?").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_ORANGE__org_dominokit_domino_ui_style_ColorScheme)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("You look handsome today <3").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PURPLE__org_dominokit_domino_ui_style_ColorScheme)), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("I like the weather today!").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme)), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initRemovableExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    this.f_removableCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setRemovable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme).m_setValue__java_lang_String("Restaurants")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setRemovable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme).m_setValue__java_lang_String("Coffee shops")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setRemovable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme).m_setValue__java_lang_String("Libraries")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setRemovable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BROWN__org_dominokit_domino_ui_style_ColorScheme).m_setValue__java_lang_String("Entertainment")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setRemovable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TEAL__org_dominokit_domino_ui_style_ColorScheme).m_setValue__java_lang_String("Universities")), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initChipsWithIconsExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    this.f_iconChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Chip} */ ($Casts.$to(Chip.m_create__().m_setValue__java_lang_String("Add to calendar").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      Notification.m_createSuccess__java_lang_String("Added to your calendar").m_show__();
    }))), Chip)).m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_date_range__())), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Chip} */ ($Casts.$to(Chip.m_create__().m_setValue__java_lang_String("Bookmark").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
      Notification.m_createSuccess__java_lang_String("Bookmark added").m_show__();
    }))), Chip)).m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_bookmark__())), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Chip} */ ($Casts.$to(Chip.m_create__().m_setValue__java_lang_String("Set alarm").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      Notification.m_createSuccess__java_lang_String("Alarm has been set").m_show__();
    }))), Chip)).m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_alarm__())), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Chip} */ ($Casts.$to(Chip.m_create__().m_setValue__java_lang_String("Get directions").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt$3$) =>{
      Notification.m_createSuccess__java_lang_String("Directions has been sent to your email").m_show__();
    }))), Chip)).m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_directions__())), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initChipsWithImagesExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    this.f_imagesChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Schroeder Coleman").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://randomuser.me/api/portraits/med/men/0.jpg"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Renee Mcintyre").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme).m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://randomuser.me/api/portraits/med/men/1.jpg"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Casey Garza").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme).m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://randomuser.me/api/portraits/med/men/2.jpg"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Ferguson Hudson").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BLACK__org_dominokit_domino_ui_style_ColorScheme).m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://randomuser.me/api/portraits/med/men/3.jpg"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Serrano Green").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_CYAN__org_dominokit_domino_ui_style_ColorScheme).m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://randomuser.me/api/portraits/med/men/4.jpg"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Camacho Solis").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BLUE_GREY__org_dominokit_domino_ui_style_ColorScheme).m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("https://randomuser.me/api/portraits/med/men/5.jpg"))), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initChipsWithLettersExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    this.f_lettersChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Schroeder Coleman").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setLeftBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_setLeftLetter__java_lang_String("SC")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Renee Mcintyre").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setLeftBackground__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_GREY__org_dominokit_domino_ui_style_Color).m_setLeftLetter__java_lang_String("RM")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Casey Garza").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setLeftBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setLeftLetter__java_lang_String("CG")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Ferguson Hudson").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setLeftBackground__org_dominokit_domino_ui_style_Color(Color.f_BLACK__org_dominokit_domino_ui_style_Color).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_BLACK__org_dominokit_domino_ui_style_Color).m_setLeftLetter__java_lang_String("FH")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Serrano Green").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setLeftBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_setLeftLetter__java_lang_String("SG")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__().m_setValue__java_lang_String("Camacho Solis").m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TRANSPARENT__org_dominokit_domino_ui_style_ColorScheme).m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_setLeftLetter__java_lang_String("CS").m_setLeftBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color)), Column))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSelectableChipsExample___$p_org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    let tops = Chip.m_create__java_lang_String("Tops").m_setSelectable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme);
    tops.m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value) =>{
      tops.m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check__());
    })));
    tops.m_addDeselectionHandler__org_dominokit_domino_ui_utils_HasDeselectionHandler_DeselectionHandler(DeselectionHandler.$adapt((() =>{
      tops.m_removeLeftAddon__();
    })));
    let bottoms = Chip.m_create__java_lang_String("Bottoms").m_setSelectable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme);
    bottoms.m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$1$) =>{
      bottoms.m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check__());
    })));
    bottoms.m_addDeselectionHandler__org_dominokit_domino_ui_utils_HasDeselectionHandler_DeselectionHandler(DeselectionHandler.$adapt((() =>{
      bottoms.m_removeLeftAddon__();
    })));
    let shoes = Chip.m_create__java_lang_String("Shoes").m_setSelectable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme);
    shoes.m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$2$) =>{
      shoes.m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check__());
    })));
    shoes.m_addDeselectionHandler__org_dominokit_domino_ui_utils_HasDeselectionHandler_DeselectionHandler(DeselectionHandler.$adapt((() =>{
      shoes.m_removeLeftAddon__();
    })));
    let accessories = Chip.m_create__java_lang_String("Accessories").m_setSelectable__boolean(true).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme);
    accessories.m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$3$) =>{
      accessories.m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check__());
    })));
    accessories.m_addDeselectionHandler__org_dominokit_domino_ui_utils_HasDeselectionHandler_DeselectionHandler(DeselectionHandler.$adapt((() =>{
      accessories.m_removeLeftAddon__();
    })));
    this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(tops), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(bottoms), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(shoes), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(accessories), Column))));
    this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__());
    this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Choice chips"));
    let chipsGroup = ChipsGroup.m_create__().m_appendChild__org_dominokit_domino_ui_chips_Chip(Chip.m_create__java_lang_String("Extra small")).m_appendChild__org_dominokit_domino_ui_chips_Chip(Chip.m_create__java_lang_String("Small")).m_appendChild__org_dominokit_domino_ui_chips_Chip(Chip.m_create__java_lang_String("Medium")).m_appendChild__org_dominokit_domino_ui_chips_Chip(Chip.m_create__java_lang_String("Large")).m_appendChild__org_dominokit_domino_ui_chips_Chip(Chip.m_create__java_lang_String("Extra large")).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_TEAL__org_dominokit_domino_ui_style_ColorScheme);
    this.f_selectableChipsCard__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span12__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(chipsGroup.m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** Chip */ value$4$) =>{
      Notification.m_createInfo__java_lang_String("Chip [ " + j_l_String.m_valueOf__java_lang_Object(chipsGroup.m_getSelectedChip__().m_getValue__()) + " ] is selected").m_show__();
    }))).m_selectAt__int(0)), Column))));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl() {
    this.f_element__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ChipsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ChipsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ChipsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$4$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Chip = goog.module.get('org.dominokit.domino.ui.chips.Chip$impl');
    ChipsGroup = goog.module.get('org.dominokit.domino.ui.chips.ChipsGroup$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    DeselectionHandler = goog.module.get('org.dominokit.domino.ui.utils.HasDeselectionHandler.DeselectionHandler$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ChipsViewImpl, $Util.$makeClassName('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl'));


/** @public {?string} @const */
ChipsViewImpl.f_MODULE_NAME__org_dominokit_domino_chips_client_views_ui_ChipsViewImpl = "chips";


ChipsView.$markImplementor(ChipsViewImpl);


exports = ChipsViewImpl; 
//# sourceMappingURL=ChipsViewImpl.js.map