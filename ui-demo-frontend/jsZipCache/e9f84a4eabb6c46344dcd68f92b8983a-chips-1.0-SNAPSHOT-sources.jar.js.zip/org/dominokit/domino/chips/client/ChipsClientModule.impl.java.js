/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.ChipsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.chips.client.ChipsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ChipsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ChipsClientModule()'.
   * @return {!ChipsClientModule}
   * @public
   */
  static $create__() {
    ChipsClientModule.$clinit();
    let $instance = new ChipsClientModule();
    $instance.$ctor__org_dominokit_domino_chips_client_ChipsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ChipsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_chips_client_ChipsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ChipsClientModule.$f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_.m_info__java_lang_String("Initializing Chips frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_() {
    return (ChipsClientModule.$clinit(), ChipsClientModule.$f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_(value) {
    (ChipsClientModule.$clinit(), ChipsClientModule.$f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ChipsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ChipsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ChipsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ChipsClientModule.$f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ChipsClientModule));
  }
  
  
};

$Util.$setClassMetadata(ChipsClientModule, $Util.$makeClassName('org.dominokit.domino.chips.client.ChipsClientModule'));


/** @private {Logger} */
ChipsClientModule.$f_LOGGER__org_dominokit_domino_chips_client_ChipsClientModule_;




exports = ChipsClientModule; 
//# sourceMappingURL=ChipsClientModule.js.map