/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.listeners.ChipsPresenterListenerForComponentCaseEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.chips.client.listeners.ChipsPresenterListenerForComponentCaseEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ChipsPresenter = goog.require('org.dominokit.domino.chips.client.presenters.ChipsPresenter');
const _ChipsPresenterCommand = goog.require('org.dominokit.domino.chips.client.presenters.ChipsPresenterCommand');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ChipsPresenterListenerForComponentCaseEvent = goog.require('org.dominokit.domino.chips.client.listeners.ChipsPresenterListenerForComponentCaseEvent$impl');
exports = ChipsPresenterListenerForComponentCaseEvent;
 