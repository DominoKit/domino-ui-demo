/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.presenters.ChipsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.chips.client.presenters.ChipsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.chips.client.presenters.ChipsPresenter.$1$impl');
let ChipsView = goog.forwardDeclare('org.dominokit.domino.chips.client.views.ChipsView$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<ChipsView>}
  */
class ChipsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ChipsPresenter()'.
   * @return {!ChipsPresenter}
   * @public
   */
  static $create__() {
    ChipsPresenter.$clinit();
    let $instance = new ChipsPresenter();
    $instance.$ctor__org_dominokit_domino_chips_client_presenters_ChipsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ChipsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_chips_client_presenters_ChipsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_listenToCompnentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_chips_client_presenters_ChipsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_chips_client_presenters_ChipsPresenter_() {
    return (ChipsPresenter.$clinit(), ChipsPresenter.$f_LOGGER__org_dominokit_domino_chips_client_presenters_ChipsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_chips_client_presenters_ChipsPresenter_(value) {
    (ChipsPresenter.$clinit(), ChipsPresenter.$f_LOGGER__org_dominokit_domino_chips_client_presenters_ChipsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ChipsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ChipsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ChipsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.chips.client.presenters.ChipsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    ChipsPresenter.$f_LOGGER__org_dominokit_domino_chips_client_presenters_ChipsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ChipsPresenter));
  }
  
  
};

$Util.$setClassMetadata(ChipsPresenter, $Util.$makeClassName('org.dominokit.domino.chips.client.presenters.ChipsPresenter'));


/** @private {Logger} */
ChipsPresenter.$f_LOGGER__org_dominokit_domino_chips_client_presenters_ChipsPresenter_;




exports = ChipsPresenter; 
//# sourceMappingURL=ChipsPresenter.js.map