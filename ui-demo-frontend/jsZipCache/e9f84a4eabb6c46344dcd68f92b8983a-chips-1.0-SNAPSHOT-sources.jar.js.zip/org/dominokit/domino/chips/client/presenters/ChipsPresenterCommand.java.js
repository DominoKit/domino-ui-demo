/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.presenters.ChipsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.chips.client.presenters.ChipsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ChipsPresenter = goog.require('org.dominokit.domino.chips.client.presenters.ChipsPresenter');


// Re-exports the implementation.
var ChipsPresenterCommand = goog.require('org.dominokit.domino.chips.client.presenters.ChipsPresenterCommand$impl');
exports = ChipsPresenterCommand;
 