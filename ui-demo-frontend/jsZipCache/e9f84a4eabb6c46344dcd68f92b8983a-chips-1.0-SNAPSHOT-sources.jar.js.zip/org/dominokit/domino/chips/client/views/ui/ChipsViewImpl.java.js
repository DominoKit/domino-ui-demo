/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ChipsView = goog.require('org.dominokit.domino.chips.client.views.ChipsView');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$3');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl.$LambdaAdaptor$4');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Chip = goog.require('org.dominokit.domino.ui.chips.Chip');
const _ChipsGroup = goog.require('org.dominokit.domino.ui.chips.ChipsGroup');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _DeselectionHandler = goog.require('org.dominokit.domino.ui.utils.HasDeselectionHandler.DeselectionHandler');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ChipsViewImpl = goog.require('org.dominokit.domino.chips.client.views.ui.ChipsViewImpl$impl');
exports = ChipsViewImpl;
 