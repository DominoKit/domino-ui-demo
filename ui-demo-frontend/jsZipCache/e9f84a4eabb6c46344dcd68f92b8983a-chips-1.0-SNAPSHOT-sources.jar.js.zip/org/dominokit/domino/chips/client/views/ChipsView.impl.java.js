/**
 * @fileoverview transpiled from org.dominokit.domino.chips.client.views.ChipsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.chips.client.views.ChipsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.chips.client.views.ChipsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class ChipsView {
  /**
   * @param {?function():Content} fn
   * @return {ChipsView}
   * @public
   */
  static $adapt(fn) {
    ChipsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_chips_client_views_ChipsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_chips_client_views_ChipsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_chips_client_views_ChipsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ChipsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.chips.client.views.ChipsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ChipsView, $Util.$makeClassName('org.dominokit.domino.chips.client.views.ChipsView'));


ChipsView.$markImplementor(/** @type {Function} */ (ChipsView));


exports = ChipsView; 
//# sourceMappingURL=ChipsView.js.map