/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.HomeClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.home.client.HomeClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class HomeClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'HomeClientModule()'.
   * @return {!HomeClientModule}
   * @public
   */
  static $create__() {
    HomeClientModule.$clinit();
    let $instance = new HomeClientModule();
    $instance.$ctor__org_dominokit_domino_home_client_HomeClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HomeClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_home_client_HomeClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    HomeClientModule.$f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_.m_info__java_lang_String("Initializing Home frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_() {
    return (HomeClientModule.$clinit(), HomeClientModule.$f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_(value) {
    (HomeClientModule.$clinit(), HomeClientModule.$f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HomeClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HomeClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HomeClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    HomeClientModule.$f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(HomeClientModule));
  }
  
  
};

$Util.$setClassMetadata(HomeClientModule, $Util.$makeClassName('org.dominokit.domino.home.client.HomeClientModule'));


/** @private {Logger} */
HomeClientModule.$f_LOGGER__org_dominokit_domino_home_client_HomeClientModule_;




exports = HomeClientModule; 
//# sourceMappingURL=HomeClientModule.js.map