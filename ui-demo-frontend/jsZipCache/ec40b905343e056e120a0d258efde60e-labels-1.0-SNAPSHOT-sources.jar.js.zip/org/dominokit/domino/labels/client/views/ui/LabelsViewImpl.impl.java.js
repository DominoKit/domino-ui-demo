/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.views.ui.LabelsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.views.ui.LabelsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const LabelsView = goog.require('org.dominokit.domino.labels.client.views.LabelsView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Label = goog.forwardDeclare('org.dominokit.domino.ui.labels.Label$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {LabelsView}
  */
class LabelsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'LabelsViewImpl()'.
   * @return {!LabelsViewImpl}
   * @public
   */
  static $create__() {
    LabelsViewImpl.$clinit();
    let $instance = new LabelsViewImpl();
    $instance.$ctor__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LabelsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(LabelsViewImpl.f_MODULE_NAME__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("LABELS").m_asElement__());
    this.m_initLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl();
    this.m_initMaterialLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initMaterialLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl() {
    let column = Column.m_span__int__int__int__int(1, 2, 6, 12);
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("LABELS WITH MATERIAL DESIGN COLORS", "You can use material design color with labels").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Red").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Pink").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Purple").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Deep Purple").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Indigo").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Blue").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Light Blue").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Cyan").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Teal").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Green").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Orange").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_create__java_lang_String("Yellow").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_YELLOW__org_dominokit_domino_ui_style_Color).m_style__().m_setMargin__java_lang_String("10px")), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(LabelsViewImpl.f_MODULE_NAME__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl, "initMaterialLabels").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initLabels___$p_org_dominokit_domino_labels_client_views_ui_LabelsViewImpl() {
    let column = Column.m_span__int__int__int__int(1, 2, 6, 12);
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(Card.m_create__java_lang_String("LABELS").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_createDefault__java_lang_String("DEFAULT").m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_createPrimary__java_lang_String("PRIMARY").m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_createSuccess__java_lang_String("SUCCESS").m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_createInfo__java_lang_String("INFO").m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_createWarning__java_lang_String("WARNING").m_style__().m_setMargin__java_lang_String("10px")), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(column.m_copy__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Label.m_createDanger__java_lang_String("DANGER").m_style__().m_setMargin__java_lang_String("10px")), Column)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(1).m_style__java_lang_String("text-align: left;"), HtmlContentBuilder)).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Label.m_createDanger__java_lang_String("New")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(2).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Label.m_createWarning__java_lang_String("New")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Label.m_createInfo__java_lang_String("New")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Label.m_createSuccess__java_lang_String("New")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Label.m_createPrimary__java_lang_String("New")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Example heading "), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Label.m_createDefault__java_lang_String("New")), IsElement))).m_asElement__());
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(LabelsViewImpl.f_MODULE_NAME__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl, "initLabels").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl() {
    this.f_element__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LabelsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LabelsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LabelsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Label = goog.module.get('org.dominokit.domino.ui.labels.Label$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LabelsViewImpl, $Util.$makeClassName('org.dominokit.domino.labels.client.views.ui.LabelsViewImpl'));


/** @public {?string} @const */
LabelsViewImpl.f_MODULE_NAME__org_dominokit_domino_labels_client_views_ui_LabelsViewImpl = "labels";


LabelsView.$markImplementor(LabelsViewImpl);


exports = LabelsViewImpl; 
//# sourceMappingURL=LabelsViewImpl.js.map