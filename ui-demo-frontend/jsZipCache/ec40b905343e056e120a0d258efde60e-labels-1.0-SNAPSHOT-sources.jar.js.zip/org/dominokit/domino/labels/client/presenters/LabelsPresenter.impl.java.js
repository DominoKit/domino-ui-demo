/**
 * @fileoverview transpiled from org.dominokit.domino.labels.client.presenters.LabelsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.labels.client.presenters.LabelsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.labels.client.presenters.LabelsPresenter.$1$impl');
let LabelsView = goog.forwardDeclare('org.dominokit.domino.labels.client.views.LabelsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<LabelsView>}
  */
class LabelsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LabelsPresenter()'.
   * @return {!LabelsPresenter}
   * @public
   */
  static $create__() {
    LabelsPresenter.$clinit();
    let $instance = new LabelsPresenter();
    $instance.$ctor__org_dominokit_domino_labels_client_presenters_LabelsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LabelsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_labels_client_presenters_LabelsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_onComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_labels_client_presenters_LabelsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_labels_client_presenters_LabelsPresenter_() {
    return (LabelsPresenter.$clinit(), LabelsPresenter.$f_LOGGER__org_dominokit_domino_labels_client_presenters_LabelsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_labels_client_presenters_LabelsPresenter_(value) {
    (LabelsPresenter.$clinit(), LabelsPresenter.$f_LOGGER__org_dominokit_domino_labels_client_presenters_LabelsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LabelsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LabelsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LabelsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.labels.client.presenters.LabelsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    LabelsPresenter.$f_LOGGER__org_dominokit_domino_labels_client_presenters_LabelsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(LabelsPresenter));
  }
  
  
};

$Util.$setClassMetadata(LabelsPresenter, $Util.$makeClassName('org.dominokit.domino.labels.client.presenters.LabelsPresenter'));


/** @private {Logger} */
LabelsPresenter.$f_LOGGER__org_dominokit_domino_labels_client_presenters_LabelsPresenter_;




exports = LabelsPresenter; 
//# sourceMappingURL=LabelsPresenter.js.map