/**
 * @fileoverview transpiled from org.dominokit.domino.ui.dialogs.MessageDialog.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.dialogs.MessageDialog$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseModal = goog.require('org.dominokit.domino.ui.modals.BaseModal$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');
let CompleteCallback = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.ui.dialogs.MessageDialog.$LambdaAdaptor$17$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let CloseHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
let ModalSize = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
let OpenHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseModal<MessageDialog>}
  */
class MessageDialog extends BaseModal {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_;
    /** @public {HTMLElement} */
    this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_;
    /** @public {HTMLElement} */
    this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_;
    /** @public {HTMLDivElement} */
    this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_;
    /** @public {Color} */
    this.f_successColor__org_dominokit_domino_ui_dialogs_MessageDialog_;
    /** @public {Color} */
    this.f_errorColor__org_dominokit_domino_ui_dialogs_MessageDialog_;
    /** @public {Color} */
    this.f_warningColor__org_dominokit_domino_ui_dialogs_MessageDialog_;
  }
  
  /**
   * Factory method corresponding to constructor 'MessageDialog()'.
   * @return {!MessageDialog}
   * @public
   */
  static $create__() {
    MessageDialog.$clinit();
    let $instance = new MessageDialog();
    $instance.$ctor__org_dominokit_domino_ui_dialogs_MessageDialog__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MessageDialog()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_dialogs_MessageDialog__() {
    this.$ctor__org_dominokit_domino_ui_modals_BaseModal__();
    this.$init__org_dominokit_domino_ui_dialogs_MessageDialog();
  }
  
  /**
   * @param {HTMLElement} element
   * @return {HTMLElement}
   * @public
   */
  static m_createMessageIcon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_dialogs_MessageDialog(element) {
    MessageDialog.$clinit();
    element.classList.add(Styles.f_m_b_15__org_dominokit_domino_ui_style_Styles);
    element.style.setProperty("font-size", "72px");
    element.style.setProperty("border-radius", "50%");
    return element;
  }
  
  /**
   * @param {Node} content
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__elemental2_dom_Node(content) {
    MessageDialog.$clinit();
    return MessageDialog.m_createMessage__elemental2_dom_Node__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(content, CloseHandler.$adapt((() =>{
    })));
  }
  
  /**
   * @param {?string} title
   * @param {Node} content
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__java_lang_String__elemental2_dom_Node(title, content) {
    MessageDialog.$clinit();
    return MessageDialog.m_createMessage__java_lang_String__elemental2_dom_Node__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(title, content, CloseHandler.$adapt((() =>{
    })));
  }
  
  /**
   * @param {?string} title
   * @param {Node} content
   * @param {CloseHandler} closeHandler
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__java_lang_String__elemental2_dom_Node__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(title, content, closeHandler) {
    MessageDialog.$clinit();
    let modalDialog = MessageDialog.m_createMessage__elemental2_dom_Node__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(content, closeHandler);
    modalDialog.m_setTitle__java_lang_String(title);
    return modalDialog;
  }
  
  /**
   * @param {Node} content
   * @param {CloseHandler} closeHandler
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__elemental2_dom_Node__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(content, closeHandler) {
    MessageDialog.$clinit();
    let messageDialog = MessageDialog.$create__();
    messageDialog.m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_ALERT__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
    messageDialog.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_getModalContent__().style.textAlign = "center";
    messageDialog.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_getModalFooter__().style.textAlign = "center";
    messageDialog.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_getModalHeader__().insertBefore(messageDialog.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_, messageDialog.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_getModalHeader__().firstChild);
    messageDialog.m_hideHeader__();
    messageDialog.m_setAutoClose__boolean(true);
    messageDialog.m_onClose__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(CloseHandler.$adapt((() =>{
      closeHandler.m_onClose__();
    })));
    messageDialog.m_appendContent__elemental2_dom_Node(content);
    let okButton = Button.m_create__java_lang_String("OK").m_linkify__();
    okButton.m_asElement__().style.setProperty("min-width", "120px");
    messageDialog.m_appendFooterContent__elemental2_dom_Node(okButton.m_asElement__());
    okButton.m_getClickableElement__().addEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$17(((/** Event */ evt) =>{
      messageDialog.m_close__();
    })));
    return messageDialog;
  }
  
  /**
   * @param {?string} message
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__java_lang_String(message) {
    MessageDialog.$clinit();
    return MessageDialog.m_createMessage__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(message, CloseHandler.$adapt((() =>{
    })));
  }
  
  /**
   * @param {?string} title
   * @param {?string} message
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__java_lang_String__java_lang_String(title, message) {
    MessageDialog.$clinit();
    return MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(title, message, CloseHandler.$adapt((() =>{
    })));
  }
  
  /**
   * @param {?string} title
   * @param {?string} message
   * @param {CloseHandler} closeHandler
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(title, message, closeHandler) {
    MessageDialog.$clinit();
    let modalDialog = MessageDialog.m_createMessage__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(message, closeHandler);
    modalDialog.m_setTitle__java_lang_String(title);
    return modalDialog;
  }
  
  /**
   * @param {?string} message
   * @param {CloseHandler} closeHandler
   * @return {MessageDialog}
   * @public
   */
  static m_createMessage__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(message, closeHandler) {
    MessageDialog.$clinit();
    return MessageDialog.m_createMessage__elemental2_dom_Node__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(Paragraph.m_create__java_lang_String(message).m_asElement__(), closeHandler);
  }
  
  /**
   * @param {Icon} icon
   * @return {MessageDialog}
   * @public
   */
  m_success__org_dominokit_domino_ui_icons_Icon(icon) {
    this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_ = MessageDialog.m_createMessageIcon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_dialogs_MessageDialog(icon.m_asElement__());
    ElementUtil.m_clear__elemental2_dom_Element(this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_);
    this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_.appendChild(this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_);
    this.m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(OpenHandler.$adapt((() =>{
      this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.classList.remove(this.f_successColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getStyle__());
      this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.classList.add(Color.f_ORANGE__org_dominokit_domino_ui_style_Color.m_getStyle__());
      this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.style.setProperty("border", "3px solid " + j_l_String.m_valueOf__java_lang_Object(Color.f_ORANGE__org_dominokit_domino_ui_style_Color.m_getHex__()));
      Animation.m_create__elemental2_dom_HTMLElement(this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition).m_duration__int(400).m_callback__org_dominokit_domino_ui_animations_Animation_CompleteCallback(CompleteCallback.$adapt(((/** HTMLElement */ element) =>{
        element.classList.remove(Color.f_ORANGE__org_dominokit_domino_ui_style_Color.m_getStyle__());
        element.classList.add(this.f_successColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getStyle__());
        element.style.setProperty("border", "3px solid " + j_l_String.m_valueOf__java_lang_Object(this.f_successColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getHex__()));
        Animation.m_create__elemental2_dom_HTMLElement(this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_PULSE__org_dominokit_domino_ui_animations_Transition).m_animate__();
      }))).m_animate__();
    })));
    return this;
  }
  
  /**
   * @return {MessageDialog}
   * @public
   */
  m_success__() {
    return this.m_success__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_done__());
  }
  
  /**
   * @param {Icon} icon
   * @return {MessageDialog}
   * @public
   */
  m_error__org_dominokit_domino_ui_icons_Icon(icon) {
    this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_ = MessageDialog.m_createMessageIcon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_dialogs_MessageDialog(icon.m_asElement__());
    ElementUtil.m_clear__elemental2_dom_Element(this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_);
    this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_.appendChild(this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_);
    this.m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(OpenHandler.$adapt((() =>{
      this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.classList.remove(this.f_errorColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getStyle__());
      this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.classList.add(Color.f_GREY__org_dominokit_domino_ui_style_Color.m_getStyle__());
      this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.style.setProperty("border", "3px solid " + j_l_String.m_valueOf__java_lang_Object(Color.f_GREY__org_dominokit_domino_ui_style_Color.m_getHex__()));
      Animation.m_create__elemental2_dom_HTMLElement(this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition).m_duration__int(400).m_callback__org_dominokit_domino_ui_animations_Animation_CompleteCallback(CompleteCallback.$adapt(((/** HTMLElement */ element) =>{
        element.classList.remove(Color.f_GREY__org_dominokit_domino_ui_style_Color.m_getStyle__());
        element.classList.add(this.f_errorColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getStyle__());
        element.style.setProperty("border", "3px solid " + j_l_String.m_valueOf__java_lang_Object(this.f_errorColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getHex__()));
        Animation.m_create__elemental2_dom_HTMLElement(this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_TADA__org_dominokit_domino_ui_animations_Transition).m_animate__();
      }))).m_animate__();
    })));
    return this;
  }
  
  /**
   * @return {MessageDialog}
   * @public
   */
  m_error__() {
    return this.m_error__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_error__());
  }
  
  /**
   * @param {Icon} icon
   * @return {MessageDialog}
   * @public
   */
  m_warning__org_dominokit_domino_ui_icons_Icon(icon) {
    this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_ = MessageDialog.m_createMessageIcon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_dialogs_MessageDialog(icon.m_asElement__());
    ElementUtil.m_clear__elemental2_dom_Element(this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_);
    this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_.appendChild(this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_);
    this.m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(OpenHandler.$adapt((() =>{
      this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.classList.remove(this.f_warningColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getStyle__());
      this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.classList.add(Color.f_GREY__org_dominokit_domino_ui_style_Color.m_getStyle__());
      this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.style.setProperty("border", "3px solid " + j_l_String.m_valueOf__java_lang_Object(Color.f_GREY__org_dominokit_domino_ui_style_Color.m_getHex__()));
      Animation.m_create__elemental2_dom_HTMLElement(this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition).m_duration__int(400).m_callback__org_dominokit_domino_ui_animations_Animation_CompleteCallback(CompleteCallback.$adapt(((/** HTMLElement */ element) =>{
        element.classList.remove(Color.f_GREY__org_dominokit_domino_ui_style_Color.m_getStyle__());
        element.classList.add(this.f_warningColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getStyle__());
        element.style.setProperty("border", "3px solid " + j_l_String.m_valueOf__java_lang_Object(this.f_warningColor__org_dominokit_domino_ui_dialogs_MessageDialog_.m_getHex__()));
        Animation.m_create__elemental2_dom_HTMLElement(this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition).m_animate__();
      }))).m_animate__();
    })));
    return this;
  }
  
  /**
   * @return {MessageDialog}
   * @public
   */
  m_warning__() {
    return this.m_warning__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_clear__());
  }
  
  /**
   * @param {Color} color
   * @return {MessageDialog}
   * @public
   */
  m_setIconColor__org_dominokit_domino_ui_style_Color(color) {
    this.f_successColor__org_dominokit_domino_ui_dialogs_MessageDialog_ = color;
    this.f_warningColor__org_dominokit_domino_ui_dialogs_MessageDialog_ = color;
    this.f_errorColor__org_dominokit_domino_ui_dialogs_MessageDialog_ = color;
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {MessageDialog}
   * @public
   */
  m_appendHeaderContent__elemental2_dom_Node(content) {
    if (Objects.m_nonNull__java_lang_Object(this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_)) {
      this.f_successIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.remove();
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_)) {
      this.f_errorIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.remove();
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_)) {
      this.f_warningIcon__org_dominokit_domino_ui_dialogs_MessageDialog_.remove();
    }
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_getModalHeader__().insertBefore(content, this.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_getModalTitle__());
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_dialogs_MessageDialog() {
    this.f_iconContainer__org_dominokit_domino_ui_dialogs_MessageDialog_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_successColor__org_dominokit_domino_ui_dialogs_MessageDialog_ = Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color;
    this.f_errorColor__org_dominokit_domino_ui_dialogs_MessageDialog_ = Color.f_RED__org_dominokit_domino_ui_style_Color;
    this.f_warningColor__org_dominokit_domino_ui_dialogs_MessageDialog_ = Color.f_ORANGE__org_dominokit_domino_ui_style_Color;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MessageDialog;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MessageDialog);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MessageDialog.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Animation = goog.module.get('org.dominokit.domino.ui.animations.Animation$impl');
    CompleteCallback = goog.module.get('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.ui.dialogs.MessageDialog.$LambdaAdaptor$17$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    CloseHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
    ModalSize = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
    OpenHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseModal.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MessageDialog, $Util.$makeClassName('org.dominokit.domino.ui.dialogs.MessageDialog'));




exports = MessageDialog; 
//# sourceMappingURL=MessageDialog.js.map