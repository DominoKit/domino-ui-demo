/**
 * @fileoverview transpiled from org.dominokit.domino.ui.layout.IsLayout.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.layout.IsLayout$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.ui.layout.Content$impl');
let Layout = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout$impl');
let NavigationBar = goog.forwardDeclare('org.dominokit.domino.ui.layout.NavigationBar$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');


/**
 * @interface
 */
class IsLayout {
  /**
   * @abstract
   * @return {Layout}
   * @public
   */
  m_show__() {
  }
  
  /**
   * @abstract
   * @param {ColorScheme} theme
   * @return {Layout}
   * @public
   */
  m_show__org_dominokit_domino_ui_style_ColorScheme(theme) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_toggleRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {Layout}
   * @public
   */
  m_showRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {Layout}
   * @public
   */
  m_hideRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_toggleLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {Layout}
   * @public
   */
  m_showLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {Layout}
   * @public
   */
  m_hideLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_getRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_getLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {HTMLDivElement}
   * @public
   */
  m_getContentPanel__() {
  }
  
  /**
   * @abstract
   * @return {HTMLUListElement}
   * @public
   */
  m_getTopBar__() {
  }
  
  /**
   * @abstract
   * @return {NavigationBar}
   * @public
   */
  m_getNavigationBar__() {
  }
  
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getContentSection__() {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @return {Layout}
   * @public
   */
  m_setTitle__java_lang_String(title) {
  }
  
  /**
   * @abstract
   * @param {Icon} icon
   * @return {HTMLElement}
   * @public
   */
  m_addActionItem__org_dominokit_domino_ui_icons_Icon(icon) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_layout_IsLayout = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_layout_IsLayout;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_layout_IsLayout;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IsLayout.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(IsLayout, $Util.$makeClassName('org.dominokit.domino.ui.layout.IsLayout'));


IsLayout.$markImplementor(/** @type {Function} */ (IsLayout));


exports = IsLayout; 
//# sourceMappingURL=IsLayout.js.map