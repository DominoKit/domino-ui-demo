/**
 * @fileoverview transpiled from org.dominokit.domino.ui.layout.Layout.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.layout.Layout$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsLayout = goog.require('org.dominokit.domino.ui.layout.IsLayout$impl');

let MarginLeftUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginLeftUnionType.$Overlay$impl');
let MarginRightUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginRightUnionType.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.ui.layout.Content$impl');
let $LambdaAdaptor$36 = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$36$impl');
let $LambdaAdaptor$37 = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$37$impl');
let $LambdaAdaptor$38 = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$38$impl');
let NavigationBar = goog.forwardDeclare('org.dominokit.domino.ui.layout.NavigationBar$impl');
let Section = goog.forwardDeclare('org.dominokit.domino.ui.layout.Section$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Theme = goog.forwardDeclare('org.dominokit.domino.ui.themes.Theme$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsLayout}
  */
class Layout extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {NavigationBar} */
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_;
    /** @public {Section} */
    this.f_section__org_dominokit_domino_ui_layout_Layout_;
    /** @public {HTMLDivElement} */
    this.f_overlay__org_dominokit_domino_ui_layout_Layout_;
    /** @public {Content} */
    this.f_content__org_dominokit_domino_ui_layout_Layout_;
    /** @public {Text} */
    this.f_appTitle__org_dominokit_domino_ui_layout_Layout_;
    /** @public {boolean} */
    this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    /** @public {boolean} */
    this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    /** @public {boolean} */
    this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_ = false;
    /** @public {boolean} */
    this.f_overlayVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    /** @public {boolean} */
    this.f_fixedLeftPanel__org_dominokit_domino_ui_layout_Layout_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Layout()'.
   * @return {!Layout}
   * @public
   */
  static $create__() {
    Layout.$clinit();
    let $instance = new Layout();
    $instance.$ctor__org_dominokit_domino_ui_layout_Layout__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Layout()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_layout_Layout__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_layout_Layout();
  }
  
  /**
   * Factory method corresponding to constructor 'Layout(String)'.
   * @param {?string} title
   * @return {!Layout}
   * @public
   */
  static $create__java_lang_String(title) {
    Layout.$clinit();
    let $instance = new Layout();
    $instance.$ctor__org_dominokit_domino_ui_layout_Layout__java_lang_String(title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Layout(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_layout_Layout__java_lang_String(title) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_layout_Layout();
    this.m_setTitle__java_lang_String(title);
  }
  
  /**
   * @return {Layout}
   * @public
   */
  static m_create__() {
    Layout.$clinit();
    return Layout.$create__();
  }
  
  /**
   * @param {?string} title
   * @return {Layout}
   * @public
   */
  static m_create__java_lang_String(title) {
    Layout.$clinit();
    return Layout.$create__java_lang_String(title);
  }
  
  /**
   * @override
   * @return {Layout}
   * @public
   */
  m_show__() {
    return this.m_show__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_INDIGO__org_dominokit_domino_ui_style_ColorScheme);
  }
  
  /**
   * @override
   * @param {ColorScheme} theme
   * @return {Layout}
   * @public
   */
  m_show__org_dominokit_domino_ui_style_ColorScheme(theme) {
    this.m_appendElements___$p_org_dominokit_domino_ui_layout_Layout();
    this.m_initElementsPosition___$p_org_dominokit_domino_ui_layout_Layout();
    this.m_addExpandListeners___$p_org_dominokit_domino_ui_layout_Layout();
    if (!$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.contains("ls-hidden")) {
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.add("ls-closed");
    }
    Theme.$create__org_dominokit_domino_ui_style_ColorScheme(theme).m_apply__();
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_appendElements___$p_org_dominokit_domino_ui_layout_Layout() {
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(this.f_overlay__org_dominokit_domino_ui_layout_Layout_);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(this.f_section__org_dominokit_domino_ui_layout_Layout_.m_asElement__());
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(this.f_content__org_dominokit_domino_ui_layout_Layout_.m_asElement__());
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getTitle__().appendChild(this.f_appTitle__org_dominokit_domino_ui_layout_Layout_);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initElementsPosition___$p_org_dominokit_domino_ui_layout_Layout() {
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getLeftSide__().style.marginLeft = MarginLeftUnionType_$Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(0));
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getRightSide__().style.marginRight = MarginRightUnionType_$Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(0));
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getLeftSide__().style.left = Layout.f_SLIDE_OUT__org_dominokit_domino_ui_layout_Layout_;
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getRightSide__().style.right = Layout.f_SLIDE_OUT__org_dominokit_domino_ui_layout_Layout_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addExpandListeners___$p_org_dominokit_domino_ui_layout_Layout() {
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getMenu__().addEventListener(Layout.f_CLICK__org_dominokit_domino_ui_layout_Layout_, new $LambdaAdaptor$36(((/** Event */ e) =>{
      this.m_toggleLeftPanel__();
    })));
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getNavBarExpand__().addEventListener(Layout.f_CLICK__org_dominokit_domino_ui_layout_Layout_, new $LambdaAdaptor$37(((/** Event */ e$1$) =>{
      this.m_toggleNavigationBar___$p_org_dominokit_domino_ui_layout_Layout();
    })));
    this.f_overlay__org_dominokit_domino_ui_layout_Layout_.addEventListener(Layout.f_CLICK__org_dominokit_domino_ui_layout_Layout_, new $LambdaAdaptor$38(((/** Event */ e$2$) =>{
      this.m_hidePanels___$p_org_dominokit_domino_ui_layout_Layout();
    })));
  }
  
  /**
   * @return {Layout}
   * @public
   */
  m_removeLeftPanel__() {
    return this.m_updateLeftPanel__java_lang_String__java_lang_String__java_lang_String("none", "ls-closed", "ls-hidden");
  }
  
  /**
   * @return {Layout}
   * @public
   */
  m_addLeftPanel__() {
    return this.m_updateLeftPanel__java_lang_String__java_lang_String__java_lang_String("block", "ls-hidden", "ls-closed");
  }
  
  /**
   * @param {?string} none
   * @param {?string} hiddenStyle
   * @param {?string} visibleStyle
   * @return {Layout}
   * @public
   */
  m_updateLeftPanel__java_lang_String__java_lang_String__java_lang_String(none, hiddenStyle, visibleStyle) {
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getMenu__().style.display = none;
    this.m_getLeftPanel__().style.display = none;
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.remove(hiddenStyle);
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.add(visibleStyle);
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_hidePanels___$p_org_dominokit_domino_ui_layout_Layout() {
    this.m_hideRightPanel__();
    this.m_hideLeftPanel__();
    this.m_collapseNavBar___$p_org_dominokit_domino_ui_layout_Layout();
    this.m_hideOverlay___$p_org_dominokit_domino_ui_layout_Layout();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_toggleNavigationBar___$p_org_dominokit_domino_ui_layout_Layout() {
    if (this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_) {
      this.m_collapseNavBar___$p_org_dominokit_domino_ui_layout_Layout();
    } else {
      this.m_expandNavBar___$p_org_dominokit_domino_ui_layout_Layout();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_expandNavBar___$p_org_dominokit_domino_ui_layout_Layout() {
    if (this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.m_hideLeftPanel__();
    }
    if (this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.m_hideRightPanel__();
    }
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getNavigationBar__().classList.remove(Layout.f_COLLAPSE__org_dominokit_domino_ui_layout_Layout_);
    this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_ = true;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_collapseNavBar___$p_org_dominokit_domino_ui_layout_Layout() {
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getNavigationBar__().classList.add(Layout.f_COLLAPSE__org_dominokit_domino_ui_layout_Layout_);
    this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_ = false;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_toggleRightPanel__() {
    if (this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.m_hideRightPanel__();
    } else {
      this.m_showRightPanel__();
    }
  }
  
  /**
   * @override
   * @return {Layout}
   * @public
   */
  m_showRightPanel__() {
    if (this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.m_hideLeftPanel__();
    }
    if (this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_) {
      this.m_collapseNavBar___$p_org_dominokit_domino_ui_layout_Layout();
    }
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getRightSide__().style.right = Layout.f_SLIDE_IN__org_dominokit_domino_ui_layout_Layout_;
    this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_ = true;
    this.m_showOverlay___$p_org_dominokit_domino_ui_layout_Layout();
    return this;
  }
  
  /**
   * @override
   * @return {Layout}
   * @public
   */
  m_hideRightPanel__() {
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getRightSide__().style.right = Layout.f_SLIDE_OUT__org_dominokit_domino_ui_layout_Layout_;
    this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    this.m_hideOverlay___$p_org_dominokit_domino_ui_layout_Layout();
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_hideOverlay___$p_org_dominokit_domino_ui_layout_Layout() {
    if (this.f_overlayVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.f_overlay__org_dominokit_domino_ui_layout_Layout_.style.display = Layout.f_NONE__org_dominokit_domino_ui_layout_Layout_;
      this.f_overlayVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_showOverlay___$p_org_dominokit_domino_ui_layout_Layout() {
    if (!this.f_overlayVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.f_overlay__org_dominokit_domino_ui_layout_Layout_.style.display = Layout.f_BLOCK__org_dominokit_domino_ui_layout_Layout_;
      this.f_overlayVisible__org_dominokit_domino_ui_layout_Layout_ = true;
    }
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_toggleLeftPanel__() {
    if (this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.m_hideLeftPanel__();
    } else {
      this.m_showLeftPanel__();
    }
  }
  
  /**
   * @override
   * @return {Layout}
   * @public
   */
  m_showLeftPanel__() {
    if (this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_) {
      this.m_hideRightPanel__();
    }
    if (this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_) {
      this.m_collapseNavBar___$p_org_dominokit_domino_ui_layout_Layout();
    }
    this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getLeftSide__().style.left = Layout.f_SLIDE_IN__org_dominokit_domino_ui_layout_Layout_;
    this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_ = true;
    this.m_showOverlay___$p_org_dominokit_domino_ui_layout_Layout();
    return this;
  }
  
  /**
   * @override
   * @return {Layout}
   * @public
   */
  m_hideLeftPanel__() {
    if (!this.f_fixedLeftPanel__org_dominokit_domino_ui_layout_Layout_) {
      this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getLeftSide__().style.left = Layout.f_SLIDE_OUT__org_dominokit_domino_ui_layout_Layout_;
      this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_ = false;
      this.m_hideOverlay___$p_org_dominokit_domino_ui_layout_Layout();
    }
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getRightPanel__() {
    return this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getRightSide__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getLeftPanel__() {
    return this.f_section__org_dominokit_domino_ui_layout_Layout_.m_getLeftSide__();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getContentPanel__() {
    return this.f_content__org_dominokit_domino_ui_layout_Layout_.m_getContentContainer__();
  }
  
  /**
   * @override
   * @return {HTMLUListElement}
   * @public
   */
  m_getTopBar__() {
    return this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getTopBar__();
  }
  
  /**
   * @override
   * @return {NavigationBar}
   * @public
   */
  m_getNavigationBar__() {
    return this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_;
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContentSection__() {
    return this.f_content__org_dominokit_domino_ui_layout_Layout_;
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {Layout}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    if (this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getTitle__().hasChildNodes()) {
      this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getTitle__().removeChild(this.f_appTitle__org_dominokit_domino_ui_layout_Layout_);
    }
    this.f_appTitle__org_dominokit_domino_ui_layout_Layout_ = new Text(title);
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_.m_getTitle__().appendChild(this.f_appTitle__org_dominokit_domino_ui_layout_Layout_);
    return this;
  }
  
  /**
   * @override
   * @param {Icon} icon
   * @return {HTMLElement}
   * @public
   */
  m_addActionItem__org_dominokit_domino_ui_icons_Icon(icon) {
    let li = /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["pull-right"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["js-right-sidebar"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(icon.m_asElement__()), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
    this.m_getTopBar__().appendChild(li);
    return li;
  }
  
  /**
   * @return {Layout}
   * @public
   */
  m_fixLeftPanelPosition__() {
    this.m_showLeftPanel__();
    this.m_hideOverlay___$p_org_dominokit_domino_ui_layout_Layout();
    if ($Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.contains("ls-closed")) {
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.remove("ls-closed");
    }
    this.f_fixedLeftPanel__org_dominokit_domino_ui_layout_Layout_ = true;
    return this;
  }
  
  /**
   * @return {Layout}
   * @public
   */
  m_unfixLeftPanelPosition__() {
    if (!$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.contains("ls-closed")) {
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.classList.add("ls-closed");
    }
    this.f_fixedLeftPanel__org_dominokit_domino_ui_layout_Layout_ = false;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_layout_Layout() {
    this.f_navigationBar__org_dominokit_domino_ui_layout_Layout_ = NavigationBar.m_create__();
    this.f_section__org_dominokit_domino_ui_layout_Layout_ = Section.m_create__();
    this.f_overlay__org_dominokit_domino_ui_layout_Layout_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["overlay"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("display: none;"), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_content__org_dominokit_domino_ui_layout_Layout_ = Content.m_create__();
    this.f_appTitle__org_dominokit_domino_ui_layout_Layout_ = new Text("");
    this.f_leftPanelVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    this.f_rightPanelVisible__org_dominokit_domino_ui_layout_Layout_ = false;
    this.f_navigationBarExpanded__org_dominokit_domino_ui_layout_Layout_ = false;
    this.f_overlayVisible__org_dominokit_domino_ui_layout_Layout_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Layout;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Layout);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Layout.$clinit = function() {};
    MarginLeftUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginLeftUnionType.$Overlay$impl');
    MarginRightUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginRightUnionType.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Content = goog.module.get('org.dominokit.domino.ui.layout.Content$impl');
    $LambdaAdaptor$36 = goog.module.get('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$36$impl');
    $LambdaAdaptor$37 = goog.module.get('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$37$impl');
    $LambdaAdaptor$38 = goog.module.get('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$38$impl');
    NavigationBar = goog.module.get('org.dominokit.domino.ui.layout.NavigationBar$impl');
    Section = goog.module.get('org.dominokit.domino.ui.layout.Section$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Theme = goog.module.get('org.dominokit.domino.ui.themes.Theme$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Layout, $Util.$makeClassName('org.dominokit.domino.ui.layout.Layout'));


/** @public {?string} @const */
Layout.f_SLIDE_OUT__org_dominokit_domino_ui_layout_Layout_ = "-300px";


/** @public {?string} @const */
Layout.f_SLIDE_IN__org_dominokit_domino_ui_layout_Layout_ = "0px";


/** @public {?string} @const */
Layout.f_NONE__org_dominokit_domino_ui_layout_Layout_ = "none";


/** @public {?string} @const */
Layout.f_BLOCK__org_dominokit_domino_ui_layout_Layout_ = "block";


/** @public {?string} @const */
Layout.f_COLLAPSE__org_dominokit_domino_ui_layout_Layout_ = "collapse";


/** @public {?string} @const */
Layout.f_CLICK__org_dominokit_domino_ui_layout_Layout_ = "click";


IsLayout.$markImplementor(Layout);


exports = Layout; 
//# sourceMappingURL=Layout.js.map