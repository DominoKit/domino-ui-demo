/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$1 = goog.require('org.dominokit.domino.ui.counter.Counter.$1');
const _CanCountTo = goog.require('org.dominokit.domino.ui.counter.Counter.CanCountTo');
const _CountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.CountHandler');
const _CounterBuilder = goog.require('org.dominokit.domino.ui.counter.Counter.CounterBuilder');
const _Timer = goog.require('org.gwtproject.timer.client.Timer');


// Re-exports the implementation.
var Counter = goog.require('org.dominokit.domino.ui.counter.Counter$impl');
exports = Counter;
 