/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.SocialIcons.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.icons.SocialIcons');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');


// Re-exports the implementation.
var SocialIcons = goog.require('org.dominokit.domino.ui.icons.SocialIcons$impl');
exports = SocialIcons;
 