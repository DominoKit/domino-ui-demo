/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.EditorIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.EditorIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class EditorIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_attach_file__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_attach_money__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_all__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_bottom__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_clear__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_color__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_horizontal__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_inner__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_left__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_outer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_right__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_style__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_top__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_border_vertical__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bubble_chart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_drag_handle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_align_center__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_align_justify__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_align_left__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_align_right__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_bold__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_clear__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_color_fill__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_color_reset__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_color_text__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_indent_decrease__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_indent_increase__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_italic__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_line_spacing__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_list_bulleted__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_list_numbered__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_paint__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_quote__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_shapes__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_size__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_strikethrough__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_textdirection_l_to_r__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_textdirection_r_to_l__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_format_underlined__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_functions__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_highlight__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_chart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_comment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_drive_file__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_emoticon__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_invitation__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_link__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_insert_photo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_linear_scale__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_merge_type__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mode_comment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mode_edit__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_monetization_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_money_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_multiline_chart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pie_chart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pie_chart_outlined__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_publish__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_short_text__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_show_chart__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_space_bar__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_strikethrough_s__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_text_fields__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_title__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vertical_align_bottom__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vertical_align_center__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vertical_align_top__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wrap_text__() {
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_attach_file__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("attach_file");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_attach_money__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("attach_money");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_all__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_all");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_bottom__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_bottom");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_clear__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_clear");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_color__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_color");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_horizontal__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_horizontal");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_inner__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_inner");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_left__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_left");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_outer__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_outer");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_right__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_right");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_style__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_style");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_top__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_top");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_border_vertical__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("border_vertical");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bubble_chart__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("bubble_chart");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_drag_handle__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("drag_handle");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_align_center__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_align_center");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_align_justify__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_align_justify");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_align_left__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_align_left");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_align_right__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_align_right");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_bold__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_bold");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_clear__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_clear");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_color_fill__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_color_fill");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_color_reset__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_color_reset");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_color_text__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_color_text");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_indent_decrease__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_indent_decrease");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_indent_increase__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_indent_increase");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_italic__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_italic");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_line_spacing__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_line_spacing");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_list_bulleted__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_list_bulleted");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_list_numbered__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_list_numbered");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_paint__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_paint");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_quote__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_quote");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_shapes__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_shapes");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_size__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_size");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_strikethrough__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_strikethrough");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_textdirection_l_to_r__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_textdirection_l_to_r");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_textdirection_r_to_l__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_textdirection_r_to_l");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_format_underlined__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("format_underlined");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_functions__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("functions");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_highlight__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("highlight");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_chart__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_chart");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_comment__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_comment");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_drive_file__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_drive_file");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_emoticon__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_emoticon");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_invitation__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_invitation");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_link__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_link");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_insert_photo__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("insert_photo");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_linear_scale__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("linear_scale");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_merge_type__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("merge_type");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mode_comment__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("mode_comment");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mode_edit__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("mode_edit");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_monetization_on__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("monetization_on");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_money_off__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("money_off");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_multiline_chart__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("multiline_chart");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pie_chart__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("pie_chart");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pie_chart_outlined__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("pie_chart_outlined");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_publish__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("publish");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_short_text__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("short_text");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_show_chart__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("show_chart");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_space_bar__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("space_bar");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_strikethrough_s__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("strikethrough_s");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_text_fields__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("text_fields");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_title__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("title");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vertical_align_bottom__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("vertical_align_bottom");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vertical_align_center__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("vertical_align_center");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vertical_align_top__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("vertical_align_top");
  }
  
  /**
   * @param {EditorIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wrap_text__$default__org_dominokit_domino_ui_icons_EditorIcons($thisArg) {
    EditorIcons.$clinit();
    return Icon.m_create__java_lang_String("wrap_text");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_EditorIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_EditorIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_EditorIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    EditorIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(EditorIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.EditorIcons'));


EditorIcons.$markImplementor(/** @type {Function} */ (EditorIcons));


exports = EditorIcons; 
//# sourceMappingURL=EditorIcons.js.map