/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.NavigationIcons.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.icons.NavigationIcons');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');


// Re-exports the implementation.
var NavigationIcons = goog.require('org.dominokit.domino.ui.icons.NavigationIcons$impl');
exports = NavigationIcons;
 