/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.ToggleIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.ToggleIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class ToggleIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_check_box__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_check_box_outline_blank__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_indeterminate_check_box__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_radio_button_checked__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_radio_button_unchecked__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_star__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_star_border__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_star_half__() {
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_check_box__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("check_box");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_check_box_outline_blank__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("check_box_outline_blank");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_indeterminate_check_box__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("indeterminate_check_box");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_radio_button_checked__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("radio_button_checked");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_radio_button_unchecked__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("radio_button_unchecked");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_star__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("star");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_star_border__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("star_border");
  }
  
  /**
   * @param {ToggleIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_star_half__$default__org_dominokit_domino_ui_icons_ToggleIcons($thisArg) {
    ToggleIcons.$clinit();
    return Icon.m_create__java_lang_String("star_half");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ToggleIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_ToggleIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ToggleIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ToggleIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ToggleIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.ToggleIcons'));


ToggleIcons.$markImplementor(/** @type {Function} */ (ToggleIcons));


exports = ToggleIcons; 
//# sourceMappingURL=ToggleIcons.js.map