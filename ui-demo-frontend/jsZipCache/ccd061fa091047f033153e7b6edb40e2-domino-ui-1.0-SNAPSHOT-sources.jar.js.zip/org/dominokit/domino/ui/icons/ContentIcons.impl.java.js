/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.ContentIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.ContentIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class ContentIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_box__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_circle_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_archive__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_backspace__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_block__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_content_copy__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_content_cut__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_content_paste__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_create__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_delete_sweep__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_drafts__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_list__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flag__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_font_download__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_forward__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gesture__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_inbox__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_link__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_low_priority__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mail__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_markunread__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_move_to_inbox__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_next_week__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_redo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_remove__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_remove_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_remove_circle_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_reply__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_reply_all__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_report__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_save__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_select_all__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_send__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sort__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_text_format__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_unarchive__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_undo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_weekend__() {
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("add");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_box__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("add_box");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_circle__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("add_circle");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_circle_outline__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("add_circle_outline");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_archive__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("archive");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_backspace__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("backspace");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_block__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("block");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_clear__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("clear");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_content_copy__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("content_copy");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_content_cut__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("content_cut");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_content_paste__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("content_paste");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_create__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("create");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_delete_sweep__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("delete_sweep");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_drafts__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("drafts");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_list__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_list");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flag__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("flag");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_font_download__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("font_download");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_forward__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("forward");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gesture__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("gesture");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_inbox__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("inbox");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_link__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("link");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_low_priority__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("low_priority");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mail__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("mail");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_markunread__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("markunread");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_move_to_inbox__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("move_to_inbox");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_next_week__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("next_week");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_redo__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("redo");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_remove__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("remove");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_remove_circle__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("remove_circle");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_remove_circle_outline__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("remove_circle_outline");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_reply__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("reply");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_reply_all__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("reply_all");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_report__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("report");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_save__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("save");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_select_all__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("select_all");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_send__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("send");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sort__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("sort");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_text_format__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("text_format");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_unarchive__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("unarchive");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_undo__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("undo");
  }
  
  /**
   * @param {ContentIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_weekend__$default__org_dominokit_domino_ui_icons_ContentIcons($thisArg) {
    ContentIcons.$clinit();
    return Icon.m_create__java_lang_String("weekend");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ContentIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_ContentIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ContentIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContentIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ContentIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.ContentIcons'));


ContentIcons.$markImplementor(/** @type {Function} */ (ContentIcons));


exports = ContentIcons; 
//# sourceMappingURL=ContentIcons.js.map