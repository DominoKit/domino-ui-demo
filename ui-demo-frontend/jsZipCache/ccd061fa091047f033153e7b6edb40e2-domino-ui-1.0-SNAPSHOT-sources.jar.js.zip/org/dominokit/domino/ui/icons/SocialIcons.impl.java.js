/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.SocialIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.SocialIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class SocialIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cake__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_domain__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_group__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_group_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_location_city__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mood__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mood_bad__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_notifications__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_notifications_active__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_notifications_none__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_notifications_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_notifications_paused__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pages__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_party_mode__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_people__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_people_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_person__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_person_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_person_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_plus_one__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_poll__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_publicc__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_school__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sentiment_dissatisfied__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sentiment_neutral__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sentiment_satisfied__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sentiment_very_dissatisfied__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sentiment_very_satisfied__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_share__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_whatshot__() {
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cake__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("cake");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_domain__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("domain");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_group__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("group");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_group_add__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("group_add");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_location_city__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("location_city");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mood__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("mood");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mood_bad__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("mood_bad");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_notifications__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("notifications");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_notifications_active__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("notifications_active");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_notifications_none__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("notifications_none");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_notifications_off__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("notifications_off");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_notifications_paused__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("notifications_paused");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pages__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("pages");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_party_mode__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("party_mode");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_people__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("people");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_people_outline__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("people_outline");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_person__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("person");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_person_add__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("person_add");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_person_outline__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("person_outline");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_plus_one__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("plus_one");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_poll__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("poll");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_publicc__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("public");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_school__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("school");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sentiment_dissatisfied__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("sentiment_dissatisfied");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sentiment_neutral__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("sentiment_neutral");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sentiment_satisfied__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("sentiment_satisfied");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sentiment_very_dissatisfied__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("sentiment_very_dissatisfied");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sentiment_very_satisfied__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("sentiment_very_satisfied");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_share__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("share");
  }
  
  /**
   * @param {SocialIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_whatshot__$default__org_dominokit_domino_ui_icons_SocialIcons($thisArg) {
    SocialIcons.$clinit();
    return Icon.m_create__java_lang_String("whatshot");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_SocialIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_SocialIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_SocialIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SocialIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SocialIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.SocialIcons'));


SocialIcons.$markImplementor(/** @type {Function} */ (SocialIcons));


exports = SocialIcons; 
//# sourceMappingURL=SocialIcons.js.map