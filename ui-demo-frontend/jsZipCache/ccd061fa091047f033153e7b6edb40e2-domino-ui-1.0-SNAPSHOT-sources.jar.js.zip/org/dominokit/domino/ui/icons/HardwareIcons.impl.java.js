/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.HardwareIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.HardwareIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class HardwareIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cast__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cast_connected__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_computer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_desktop_mac__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_desktop_windows__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_developer_board__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_device_hub__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_devices_other__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gamepad__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_headset__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_headset_mic__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_down__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_left__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_right__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_up__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_backspace__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_capslock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_hide__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_return__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_tab__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_keyboard_voice__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_laptop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_laptop_chromebook__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_laptop_mac__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_laptop_windows__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_memory__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mouse__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_android__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_iphone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phonelink__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phonelink_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_power_input__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_router__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_scanner__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_security__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sim_card__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_smartphone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_speaker__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_speaker_group__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tablet__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tablet_android__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tablet_mac__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_toys__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tv__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_videogame_asset__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_watch__() {
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cast__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("cast");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cast_connected__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("cast_connected");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_computer__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("computer");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_desktop_mac__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("desktop_mac");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_desktop_windows__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("desktop_windows");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_developer_board__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("developer_board");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_device_hub__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("device_hub");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_devices_other__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("devices_other");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dock__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("dock");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gamepad__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("gamepad");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_headset__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("headset");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_headset_mic__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("headset_mic");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_arrow_down__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_arrow_down");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_arrow_left__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_arrow_left");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_arrow_right__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_arrow_right");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_arrow_up__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_arrow_up");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_backspace__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_backspace");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_capslock__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_capslock");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_hide__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_hide");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_return__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_return");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_tab__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_tab");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_keyboard_voice__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("keyboard_voice");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_laptop__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("laptop");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_laptop_chromebook__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("laptop_chromebook");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_laptop_mac__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("laptop_mac");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_laptop_windows__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("laptop_windows");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_memory__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("memory");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mouse__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("mouse");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_android__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_android");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_iphone__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_iphone");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phonelink__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("phonelink");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phonelink_off__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("phonelink_off");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_power_input__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("power_input");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_router__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("router");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_scanner__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("scanner");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_security__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("security");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sim_card__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("sim_card");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_smartphone__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("smartphone");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_speaker__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("speaker");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_speaker_group__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("speaker_group");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tablet__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("tablet");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tablet_android__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("tablet_android");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tablet_mac__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("tablet_mac");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_toys__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("toys");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tv__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("tv");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_videogame_asset__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("videogame_asset");
  }
  
  /**
   * @param {HardwareIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_watch__$default__org_dominokit_domino_ui_icons_HardwareIcons($thisArg) {
    HardwareIcons.$clinit();
    return Icon.m_create__java_lang_String("watch");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_HardwareIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_HardwareIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_HardwareIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HardwareIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HardwareIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.HardwareIcons'));


HardwareIcons.$markImplementor(/** @type {Function} */ (HardwareIcons));


exports = HardwareIcons; 
//# sourceMappingURL=HardwareIcons.js.map