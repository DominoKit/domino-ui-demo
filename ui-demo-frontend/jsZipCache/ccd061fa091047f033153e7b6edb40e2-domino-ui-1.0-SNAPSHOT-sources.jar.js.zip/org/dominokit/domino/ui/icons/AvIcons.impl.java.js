/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.AvIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.AvIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class AvIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_to_queue__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airplay__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_album__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_art_track__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_av_timer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_branding_watermark__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_to_action__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_closed_caption__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_equalizer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_explicit__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fast_forward__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fast_rewind__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_featured_play_list__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_featured_video__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fiber_dvr__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fiber_manual_record__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fiber_new__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fiber_pin__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fiber_smart_record__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_forward_10__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_forward_30__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_forward_5__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_games__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hd__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hearing__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_high_quality__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_library_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_library_books__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_library_music__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_loop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mic__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mic_none__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mic_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_movie__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_music_video__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_new_releases__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_not_interested__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_note__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pause__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pause_circle_filled__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pause_circle_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_play_arrow__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_play_circle_filled__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_play_circle_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_playlist_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_playlist_add_check__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_playlist_play__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_queue__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_queue_music__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_queue_play_next__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_radio__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_recent_actors__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_remove_from_queue__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_repeat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_repeat_one__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_replay__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_replay_10__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_replay_30__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_replay_5__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_shuffle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_skip_next__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_skip_previous__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_slow_motion_video__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_snooze__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sort_by_alpha__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_subscriptions__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_subtitles__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_surround_sound__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_video_call__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_video_label__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_video_library__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_videocam__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_videocam_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_volume_down__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_volume_mute__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_volume_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_volume_up__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_web__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_web_asset__() {
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_to_queue__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("add_to_queue");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airplay__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("airplay");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_album__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("album");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_art_track__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("art_track");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_av_timer__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("av_timer");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_branding_watermark__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("branding_watermark");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_to_action__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("call_to_action");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_closed_caption__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("closed_caption");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_equalizer__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("equalizer");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_explicit__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("explicit");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fast_forward__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fast_forward");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fast_rewind__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fast_rewind");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_featured_play_list__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("featured_play_list");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_featured_video__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("featured_video");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fiber_dvr__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fiber_dvr");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fiber_manual_record__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fiber_manual_record");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fiber_new__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fiber_new");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fiber_pin__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fiber_pin");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fiber_smart_record__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("fiber_smart_record");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_forward_10__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("forward_10");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_forward_30__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("forward_30");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_forward_5__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("forward_5");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_games__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("games");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hd__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("hd");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hearing__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("hearing");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_high_quality__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("high_quality");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_library_add__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("library_add");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_library_books__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("library_books");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_library_music__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("library_music");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_loop__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("loop");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mic__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("mic");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mic_none__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("mic_none");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mic_off__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("mic_off");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_movie__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("movie");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_music_video__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("music_video");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_new_releases__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("new_releases");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_not_interested__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("not_interested");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_note__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("note");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pause__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("pause");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pause_circle_filled__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("pause_circle_filled");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pause_circle_outline__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("pause_circle_outline");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_play_arrow__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("play_arrow");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_play_circle_filled__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("play_circle_filled");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_play_circle_outline__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("play_circle_outline");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_playlist_add__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("playlist_add");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_playlist_add_check__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("playlist_add_check");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_playlist_play__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("playlist_play");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_queue__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("queue");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_queue_music__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("queue_music");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_queue_play_next__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("queue_play_next");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_radio__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("radio");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_recent_actors__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("recent_actors");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_remove_from_queue__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("remove_from_queue");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_repeat__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("repeat");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_repeat_one__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("repeat_one");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_replay__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("replay");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_replay_10__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("replay_10");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_replay_30__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("replay_30");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_replay_5__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("replay_5");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_shuffle__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("shuffle");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_skip_next__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("skip_next");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_skip_previous__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("skip_previous");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_slow_motion_video__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("slow_motion_video");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_snooze__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("snooze");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sort_by_alpha__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("sort_by_alpha");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stop__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("stop");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_subscriptions__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("subscriptions");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_subtitles__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("subtitles");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_surround_sound__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("surround_sound");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_video_call__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("video_call");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_video_label__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("video_label");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_video_library__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("video_library");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_videocam__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("videocam");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_videocam_off__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("videocam_off");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_volume_down__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("volume_down");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_volume_mute__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("volume_mute");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_volume_off__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("volume_off");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_volume_up__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("volume_up");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_web__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("web");
  }
  
  /**
   * @param {AvIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_web_asset__$default__org_dominokit_domino_ui_icons_AvIcons($thisArg) {
    AvIcons.$clinit();
    return Icon.m_create__java_lang_String("web_asset");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_AvIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_AvIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_AvIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AvIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(AvIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.AvIcons'));


AvIcons.$markImplementor(/** @type {Function} */ (AvIcons));


exports = AvIcons; 
//# sourceMappingURL=AvIcons.js.map