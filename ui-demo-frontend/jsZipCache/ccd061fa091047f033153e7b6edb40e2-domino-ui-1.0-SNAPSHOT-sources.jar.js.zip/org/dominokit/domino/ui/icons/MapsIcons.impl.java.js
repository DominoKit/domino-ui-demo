/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.MapsIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.MapsIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class MapsIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_location__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_beenhere__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_bike__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_boat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_bus__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_car__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_railway__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_run__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_subway__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_transit__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_directions_walk__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_edit_location__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_ev_station__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flight__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hotel__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_layers__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_layers_clear__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_activity__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_airport__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_atm__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_bar__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_cafe__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_car_wash__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_convenience_store__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_dining__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_drink__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_florist__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_gas_station__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_grocery_store__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_hospital__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_hotel__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_laundry_service__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_library__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_mall__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_movies__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_offer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_parking__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_pharmacy__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_phone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_pizza__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_play__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_post_office__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_printshop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_see__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_shipping__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_local_taxi__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_map__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_my_location__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_navigation__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_near_me__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_person_pin__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_person_pin_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_pin_drop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_place__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rate_review__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_restaurant__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_restaurant_menu__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_satellite__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_store_mall_directory__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_streetview__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_subway__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_terrain__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_traffic__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_train__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tram__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_transfer_within_a_station__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_zoom_out_map__() {
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_location__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("add_location");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_beenhere__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("beenhere");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_bike__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_bike");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_boat__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_boat");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_bus__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_bus");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_car__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_car");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_railway__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_railway");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_run__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_run");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_subway__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_subway");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_transit__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_transit");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_directions_walk__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("directions_walk");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_edit_location__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("edit_location");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_ev_station__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("ev_station");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flight__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("flight");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hotel__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("hotel");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_layers__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("layers");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_layers_clear__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("layers_clear");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_activity__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_activity");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_airport__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_airport");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_atm__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_atm");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_bar__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_bar");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_cafe__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_cafe");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_car_wash__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_car_wash");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_convenience_store__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_convenience_store");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_dining__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_dining");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_drink__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_drink");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_florist__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_florist");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_gas_station__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_gas_station");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_grocery_store__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_grocery_store");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_hospital__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_hospital");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_hotel__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_hotel");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_laundry_service__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_laundry_service");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_library__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_library");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_mall__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_mall");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_movies__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_movies");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_offer__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_offer");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_parking__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_parking");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_pharmacy__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_pharmacy");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_phone__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_phone");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_pizza__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_pizza");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_play__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_play");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_post_office__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_post_office");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_printshop__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_printshop");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_see__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_see");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_shipping__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_shipping");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_local_taxi__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("local_taxi");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_map__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("map");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_my_location__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("my_location");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_navigation__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("navigation");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_near_me__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("near_me");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_person_pin__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("person_pin");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_person_pin_circle__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("person_pin_circle");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_pin_drop__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("pin_drop");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_place__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("place");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rate_review__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("rate_review");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_restaurant__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("restaurant");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_restaurant_menu__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("restaurant_menu");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_satellite__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("satellite");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_store_mall_directory__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("store_mall_directory");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_streetview__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("streetview");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_subway__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("subway");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_terrain__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("terrain");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_traffic__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("traffic");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_train__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("train");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tram__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("tram");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_transfer_within_a_station__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("transfer_within_a_station");
  }
  
  /**
   * @param {MapsIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_zoom_out_map__$default__org_dominokit_domino_ui_icons_MapsIcons($thisArg) {
    MapsIcons.$clinit();
    return Icon.m_create__java_lang_String("zoom_out_map");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_MapsIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_MapsIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_MapsIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MapsIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MapsIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.MapsIcons'));


MapsIcons.$markImplementor(/** @type {Function} */ (MapsIcons));


exports = MapsIcons; 
//# sourceMappingURL=MapsIcons.js.map