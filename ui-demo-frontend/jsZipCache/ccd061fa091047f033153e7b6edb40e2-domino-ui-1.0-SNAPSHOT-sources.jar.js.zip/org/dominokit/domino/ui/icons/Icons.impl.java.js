/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.Icons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.Icons$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ActionIcons = goog.require('org.dominokit.domino.ui.icons.ActionIcons$impl');
const AlertIcons = goog.require('org.dominokit.domino.ui.icons.AlertIcons$impl');
const AvIcons = goog.require('org.dominokit.domino.ui.icons.AvIcons$impl');
const CommunicationIcons = goog.require('org.dominokit.domino.ui.icons.CommunicationIcons$impl');
const ContentIcons = goog.require('org.dominokit.domino.ui.icons.ContentIcons$impl');
const DeviceIcons = goog.require('org.dominokit.domino.ui.icons.DeviceIcons$impl');
const EditorIcons = goog.require('org.dominokit.domino.ui.icons.EditorIcons$impl');
const FileIcons = goog.require('org.dominokit.domino.ui.icons.FileIcons$impl');
const HardwareIcons = goog.require('org.dominokit.domino.ui.icons.HardwareIcons$impl');
const ImageIcons = goog.require('org.dominokit.domino.ui.icons.ImageIcons$impl');
const MapsIcons = goog.require('org.dominokit.domino.ui.icons.MapsIcons$impl');
const NavigationIcons = goog.require('org.dominokit.domino.ui.icons.NavigationIcons$impl');
const NotificationIcons = goog.require('org.dominokit.domino.ui.icons.NotificationIcons$impl');
const PlacesIcons = goog.require('org.dominokit.domino.ui.icons.PlacesIcons$impl');
const SocialIcons = goog.require('org.dominokit.domino.ui.icons.SocialIcons$impl');
const ToggleIcons = goog.require('org.dominokit.domino.ui.icons.ToggleIcons$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @implements {ActionIcons}
 * @implements {AlertIcons}
 * @implements {AvIcons}
 * @implements {CommunicationIcons}
 * @implements {ContentIcons}
 * @implements {DeviceIcons}
 * @implements {EditorIcons}
 * @implements {HardwareIcons}
 * @implements {FileIcons}
 * @implements {ImageIcons}
 * @implements {MapsIcons}
 * @implements {NavigationIcons}
 * @implements {NotificationIcons}
 * @implements {PlacesIcons}
 * @implements {SocialIcons}
 * @implements {ToggleIcons}
  */
class Icons extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Icons()'.
   * @return {!Icons}
   * @public
   */
  static $create__() {
    Icons.$clinit();
    let $instance = new Icons();
    $instance.$ctor__org_dominokit_domino_ui_icons_Icons__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Icons()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_icons_Icons__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m__3d_rotation__() {
    return ActionIcons.m__3d_rotation__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_accessibility__() {
    return ActionIcons.m_accessibility__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_accessible__() {
    return ActionIcons.m_accessible__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_account_balance__() {
    return ActionIcons.m_account_balance__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_account_balance_wallet__() {
    return ActionIcons.m_account_balance_wallet__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_account_box__() {
    return ActionIcons.m_account_box__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_account_circle__() {
    return ActionIcons.m_account_circle__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_shopping_cart__() {
    return ActionIcons.m_add_shopping_cart__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_alarm__() {
    return ActionIcons.m_alarm__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_alarm_add__() {
    return ActionIcons.m_alarm_add__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_alarm_off__() {
    return ActionIcons.m_alarm_off__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_alarm_on__() {
    return ActionIcons.m_alarm_on__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_all_out__() {
    return ActionIcons.m_all_out__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_android__() {
    return ActionIcons.m_android__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_announcement__() {
    return ActionIcons.m_announcement__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_aspect_ratio__() {
    return ActionIcons.m_aspect_ratio__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assessment__() {
    return ActionIcons.m_assessment__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assignment__() {
    return ActionIcons.m_assignment__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assignment_ind__() {
    return ActionIcons.m_assignment_ind__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assignment_late__() {
    return ActionIcons.m_assignment_late__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assignment_return__() {
    return ActionIcons.m_assignment_return__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assignment_returned__() {
    return ActionIcons.m_assignment_returned__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assignment_turned_in__() {
    return ActionIcons.m_assignment_turned_in__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_autorenew__() {
    return ActionIcons.m_autorenew__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_backup__() {
    return ActionIcons.m_backup__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_book__() {
    return ActionIcons.m_book__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bookmark__() {
    return ActionIcons.m_bookmark__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bookmark_border__() {
    return ActionIcons.m_bookmark_border__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bug_report__() {
    return ActionIcons.m_bug_report__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_build__() {
    return ActionIcons.m_build__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cached__() {
    return ActionIcons.m_cached__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_camera_enhance__() {
    return ActionIcons.m_camera_enhance__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_card_giftcard__() {
    return ActionIcons.m_card_giftcard__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_card_membership__() {
    return ActionIcons.m_card_membership__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_card_travel__() {
    return ActionIcons.m_card_travel__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_change_history__() {
    return ActionIcons.m_change_history__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_check_circle__() {
    return ActionIcons.m_check_circle__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_chrome_reader_mode__() {
    return ActionIcons.m_chrome_reader_mode__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_classs__() {
    return ActionIcons.m_classs__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_code__() {
    return ActionIcons.m_code__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_compare_arrows__() {
    return ActionIcons.m_compare_arrows__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_copyright__() {
    return ActionIcons.m_copyright__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_credit_card__() {
    return ActionIcons.m_credit_card__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dashboard__() {
    return ActionIcons.m_dashboard__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_date_range__() {
    return ActionIcons.m_date_range__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_delete__() {
    return ActionIcons.m_delete__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_delete_forever__() {
    return ActionIcons.m_delete_forever__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_description__() {
    return ActionIcons.m_description__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dns__() {
    return ActionIcons.m_dns__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_done__() {
    return ActionIcons.m_done__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_done_all__() {
    return ActionIcons.m_done_all__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_donut_large__() {
    return ActionIcons.m_donut_large__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_donut_small__() {
    return ActionIcons.m_donut_small__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_eject__() {
    return ActionIcons.m_eject__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_euro_symbol__() {
    return ActionIcons.m_euro_symbol__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_event__() {
    return ActionIcons.m_event__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_event_seat__() {
    return ActionIcons.m_event_seat__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exit_to_app__() {
    return ActionIcons.m_exit_to_app__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_explore__() {
    return ActionIcons.m_explore__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_extension__() {
    return ActionIcons.m_extension__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_face__() {
    return ActionIcons.m_face__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_favorite__() {
    return ActionIcons.m_favorite__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_favorite_border__() {
    return ActionIcons.m_favorite_border__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_feedback__() {
    return ActionIcons.m_feedback__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_find_in_page__() {
    return ActionIcons.m_find_in_page__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_find_replace__() {
    return ActionIcons.m_find_replace__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fingerprint__() {
    return ActionIcons.m_fingerprint__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flight_land__() {
    return ActionIcons.m_flight_land__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flight_takeoff__() {
    return ActionIcons.m_flight_takeoff__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flip_to_back__() {
    return ActionIcons.m_flip_to_back__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flip_to_front__() {
    return ActionIcons.m_flip_to_front__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_g_translate__() {
    return ActionIcons.m_g_translate__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gavel__() {
    return ActionIcons.m_gavel__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_get_app__() {
    return ActionIcons.m_get_app__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gif__() {
    return ActionIcons.m_gif__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_grade__() {
    return ActionIcons.m_grade__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_group_work__() {
    return ActionIcons.m_group_work__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_help__() {
    return ActionIcons.m_help__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_help_outline__() {
    return ActionIcons.m_help_outline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_highlight_off__() {
    return ActionIcons.m_highlight_off__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_history__() {
    return ActionIcons.m_history__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_home__() {
    return ActionIcons.m_home__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hourglass_empty__() {
    return ActionIcons.m_hourglass_empty__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hourglass_full__() {
    return ActionIcons.m_hourglass_full__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_http__() {
    return ActionIcons.m_http__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_https__() {
    return ActionIcons.m_https__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_important_devices__() {
    return ActionIcons.m_important_devices__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_info__() {
    return ActionIcons.m_info__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_info_outline__() {
    return ActionIcons.m_info_outline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_input__() {
    return ActionIcons.m_input__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_invert_colors__() {
    return ActionIcons.m_invert_colors__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_label__() {
    return ActionIcons.m_label__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_label_outline__() {
    return ActionIcons.m_label_outline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_language__() {
    return ActionIcons.m_language__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_launch__() {
    return ActionIcons.m_launch__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_lightbulb_outline__() {
    return ActionIcons.m_lightbulb_outline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_line_style__() {
    return ActionIcons.m_line_style__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_line_weight__() {
    return ActionIcons.m_line_weight__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_list__() {
    return ActionIcons.m_list__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_lock__() {
    return ActionIcons.m_lock__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_lock_open__() {
    return ActionIcons.m_lock_open__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_lock_outline__() {
    return ActionIcons.m_lock_outline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_loyalty__() {
    return ActionIcons.m_loyalty__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_markunread_mailbox__() {
    return ActionIcons.m_markunread_mailbox__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_motorcycle__() {
    return ActionIcons.m_motorcycle__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_note_add__() {
    return ActionIcons.m_note_add__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_offline_pin__() {
    return ActionIcons.m_offline_pin__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_opacity__() {
    return ActionIcons.m_opacity__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_open_in_browser__() {
    return ActionIcons.m_open_in_browser__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_open_in_new__() {
    return ActionIcons.m_open_in_new__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_open_with__() {
    return ActionIcons.m_open_with__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pageview__() {
    return ActionIcons.m_pageview__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pan_tool__() {
    return ActionIcons.m_pan_tool__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_payment__() {
    return ActionIcons.m_payment__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_camera_mic__() {
    return ActionIcons.m_perm_camera_mic__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_contact_calendar__() {
    return ActionIcons.m_perm_contact_calendar__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_data_setting__() {
    return ActionIcons.m_perm_data_setting__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_device_information__() {
    return ActionIcons.m_perm_device_information__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_identity__() {
    return ActionIcons.m_perm_identity__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_media__() {
    return ActionIcons.m_perm_media__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_phone_msg__() {
    return ActionIcons.m_perm_phone_msg__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_perm_scan_wifi__() {
    return ActionIcons.m_perm_scan_wifi__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pets__() {
    return ActionIcons.m_pets__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_picture_in_picture__() {
    return ActionIcons.m_picture_in_picture__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_picture_in_picture_alt__() {
    return ActionIcons.m_picture_in_picture_alt__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_play_for_work__() {
    return ActionIcons.m_play_for_work__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_polymer__() {
    return ActionIcons.m_polymer__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_power_settings_new__() {
    return ActionIcons.m_power_settings_new__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pregnant_woman__() {
    return ActionIcons.m_pregnant_woman__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_print__() {
    return ActionIcons.m_print__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_query_builder__() {
    return ActionIcons.m_query_builder__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_question_answer__() {
    return ActionIcons.m_question_answer__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_receipt__() {
    return ActionIcons.m_receipt__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_record_voice_over__() {
    return ActionIcons.m_record_voice_over__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_redeem__() {
    return ActionIcons.m_redeem__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_remove_shopping_cart__() {
    return ActionIcons.m_remove_shopping_cart__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_reorder__() {
    return ActionIcons.m_reorder__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_report_problem__() {
    return ActionIcons.m_report_problem__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_restore__() {
    return ActionIcons.m_restore__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_restore_page__() {
    return ActionIcons.m_restore_page__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_room__() {
    return ActionIcons.m_room__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rounded_corner__() {
    return ActionIcons.m_rounded_corner__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rowing__() {
    return ActionIcons.m_rowing__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_schedule__() {
    return ActionIcons.m_schedule__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_search__() {
    return ActionIcons.m_search__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings__() {
    return ActionIcons.m_settings__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_applications__() {
    return ActionIcons.m_settings_applications__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_backup_restore__() {
    return ActionIcons.m_settings_backup_restore__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_bluetooth__() {
    return ActionIcons.m_settings_bluetooth__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_brightness__() {
    return ActionIcons.m_settings_brightness__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_cell__() {
    return ActionIcons.m_settings_cell__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_ethernet__() {
    return ActionIcons.m_settings_ethernet__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_input_antenna__() {
    return ActionIcons.m_settings_input_antenna__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_input_component__() {
    return ActionIcons.m_settings_input_component__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_input_composite__() {
    return ActionIcons.m_settings_input_composite__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_input_hdmi__() {
    return ActionIcons.m_settings_input_hdmi__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_input_svideo__() {
    return ActionIcons.m_settings_input_svideo__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_overscan__() {
    return ActionIcons.m_settings_overscan__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_phone__() {
    return ActionIcons.m_settings_phone__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_power__() {
    return ActionIcons.m_settings_power__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_remote__() {
    return ActionIcons.m_settings_remote__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_voice__() {
    return ActionIcons.m_settings_voice__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_shop__() {
    return ActionIcons.m_shop__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_shop_two__() {
    return ActionIcons.m_shop_two__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_shopping_basket__() {
    return ActionIcons.m_shopping_basket__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_shopping_cart__() {
    return ActionIcons.m_shopping_cart__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_speaker_notes__() {
    return ActionIcons.m_speaker_notes__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_speaker_notes_off__() {
    return ActionIcons.m_speaker_notes_off__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_spellcheck__() {
    return ActionIcons.m_spellcheck__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_star_rate__() {
    return ActionIcons.m_star_rate__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stars__() {
    return ActionIcons.m_stars__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_store__() {
    return ActionIcons.m_store__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_subject__() {
    return ActionIcons.m_subject__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_supervisor_account__() {
    return ActionIcons.m_supervisor_account__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_swap_horiz__() {
    return ActionIcons.m_swap_horiz__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_swap_vert__() {
    return ActionIcons.m_swap_vert__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_swap_vertical_circle__() {
    return ActionIcons.m_swap_vertical_circle__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_system_update_alt__() {
    return ActionIcons.m_system_update_alt__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tab__() {
    return ActionIcons.m_tab__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tab_unselected__() {
    return ActionIcons.m_tab_unselected__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_theaters__() {
    return ActionIcons.m_theaters__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_thumb_down__() {
    return ActionIcons.m_thumb_down__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_thumb_up__() {
    return ActionIcons.m_thumb_up__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_thumbs_up_down__() {
    return ActionIcons.m_thumbs_up_down__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_timeline__() {
    return ActionIcons.m_timeline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_toc__() {
    return ActionIcons.m_toc__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_today__() {
    return ActionIcons.m_today__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_toll__() {
    return ActionIcons.m_toll__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_touch_app__() {
    return ActionIcons.m_touch_app__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_track_changes__() {
    return ActionIcons.m_track_changes__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_translate__() {
    return ActionIcons.m_translate__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_trending_down__() {
    return ActionIcons.m_trending_down__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_trending_flat__() {
    return ActionIcons.m_trending_flat__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_trending_up__() {
    return ActionIcons.m_trending_up__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_turned_in__() {
    return ActionIcons.m_turned_in__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_turned_in_not__() {
    return ActionIcons.m_turned_in_not__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_update__() {
    return ActionIcons.m_update__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_verified_user__() {
    return ActionIcons.m_verified_user__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_agenda__() {
    return ActionIcons.m_view_agenda__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_array__() {
    return ActionIcons.m_view_array__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_carousel__() {
    return ActionIcons.m_view_carousel__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_column__() {
    return ActionIcons.m_view_column__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_day__() {
    return ActionIcons.m_view_day__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_headline__() {
    return ActionIcons.m_view_headline__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_list__() {
    return ActionIcons.m_view_list__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_module__() {
    return ActionIcons.m_view_module__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_quilt__() {
    return ActionIcons.m_view_quilt__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_stream__() {
    return ActionIcons.m_view_stream__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_week__() {
    return ActionIcons.m_view_week__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_visibility__() {
    return ActionIcons.m_visibility__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_visibility_off__() {
    return ActionIcons.m_visibility_off__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_watch_later__() {
    return ActionIcons.m_watch_later__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_work__() {
    return ActionIcons.m_work__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_youtube_searched_for__() {
    return ActionIcons.m_youtube_searched_for__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_zoom_in__() {
    return ActionIcons.m_zoom_in__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_zoom_out__() {
    return ActionIcons.m_zoom_out__$default__org_dominokit_domino_ui_icons_ActionIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_alert__() {
    return AlertIcons.m_add_alert__$default__org_dominokit_domino_ui_icons_AlertIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_error__() {
    return AlertIcons.m_error__$default__org_dominokit_domino_ui_icons_AlertIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_error_outline__() {
    return AlertIcons.m_error_outline__$default__org_dominokit_domino_ui_icons_AlertIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_warning__() {
    return AlertIcons.m_warning__$default__org_dominokit_domino_ui_icons_AlertIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_to_queue__() {
    return AvIcons.m_add_to_queue__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airplay__() {
    return AvIcons.m_airplay__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_album__() {
    return AvIcons.m_album__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_art_track__() {
    return AvIcons.m_art_track__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_av_timer__() {
    return AvIcons.m_av_timer__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_branding_watermark__() {
    return AvIcons.m_branding_watermark__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_to_action__() {
    return AvIcons.m_call_to_action__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_closed_caption__() {
    return AvIcons.m_closed_caption__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_equalizer__() {
    return AvIcons.m_equalizer__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_explicit__() {
    return AvIcons.m_explicit__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fast_forward__() {
    return AvIcons.m_fast_forward__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fast_rewind__() {
    return AvIcons.m_fast_rewind__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_featured_play_list__() {
    return AvIcons.m_featured_play_list__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_featured_video__() {
    return AvIcons.m_featured_video__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fiber_dvr__() {
    return AvIcons.m_fiber_dvr__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fiber_manual_record__() {
    return AvIcons.m_fiber_manual_record__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fiber_new__() {
    return AvIcons.m_fiber_new__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fiber_pin__() {
    return AvIcons.m_fiber_pin__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fiber_smart_record__() {
    return AvIcons.m_fiber_smart_record__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_forward_10__() {
    return AvIcons.m_forward_10__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_forward_30__() {
    return AvIcons.m_forward_30__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_forward_5__() {
    return AvIcons.m_forward_5__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_games__() {
    return AvIcons.m_games__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hd__() {
    return AvIcons.m_hd__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hearing__() {
    return AvIcons.m_hearing__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_high_quality__() {
    return AvIcons.m_high_quality__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_library_add__() {
    return AvIcons.m_library_add__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_library_books__() {
    return AvIcons.m_library_books__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_library_music__() {
    return AvIcons.m_library_music__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_loop__() {
    return AvIcons.m_loop__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mic__() {
    return AvIcons.m_mic__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mic_none__() {
    return AvIcons.m_mic_none__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mic_off__() {
    return AvIcons.m_mic_off__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_movie__() {
    return AvIcons.m_movie__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_music_video__() {
    return AvIcons.m_music_video__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_new_releases__() {
    return AvIcons.m_new_releases__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_not_interested__() {
    return AvIcons.m_not_interested__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_note__() {
    return AvIcons.m_note__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pause__() {
    return AvIcons.m_pause__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pause_circle_filled__() {
    return AvIcons.m_pause_circle_filled__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pause_circle_outline__() {
    return AvIcons.m_pause_circle_outline__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_play_arrow__() {
    return AvIcons.m_play_arrow__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_play_circle_filled__() {
    return AvIcons.m_play_circle_filled__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_play_circle_outline__() {
    return AvIcons.m_play_circle_outline__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_playlist_add__() {
    return AvIcons.m_playlist_add__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_playlist_add_check__() {
    return AvIcons.m_playlist_add_check__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_playlist_play__() {
    return AvIcons.m_playlist_play__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_queue__() {
    return AvIcons.m_queue__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_queue_music__() {
    return AvIcons.m_queue_music__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_queue_play_next__() {
    return AvIcons.m_queue_play_next__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_radio__() {
    return AvIcons.m_radio__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_recent_actors__() {
    return AvIcons.m_recent_actors__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_remove_from_queue__() {
    return AvIcons.m_remove_from_queue__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_repeat__() {
    return AvIcons.m_repeat__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_repeat_one__() {
    return AvIcons.m_repeat_one__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_replay__() {
    return AvIcons.m_replay__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_replay_10__() {
    return AvIcons.m_replay_10__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_replay_30__() {
    return AvIcons.m_replay_30__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_replay_5__() {
    return AvIcons.m_replay_5__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_shuffle__() {
    return AvIcons.m_shuffle__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_skip_next__() {
    return AvIcons.m_skip_next__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_skip_previous__() {
    return AvIcons.m_skip_previous__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_slow_motion_video__() {
    return AvIcons.m_slow_motion_video__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_snooze__() {
    return AvIcons.m_snooze__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sort_by_alpha__() {
    return AvIcons.m_sort_by_alpha__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stop__() {
    return AvIcons.m_stop__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_subscriptions__() {
    return AvIcons.m_subscriptions__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_subtitles__() {
    return AvIcons.m_subtitles__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_surround_sound__() {
    return AvIcons.m_surround_sound__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_video_call__() {
    return AvIcons.m_video_call__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_video_label__() {
    return AvIcons.m_video_label__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_video_library__() {
    return AvIcons.m_video_library__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_videocam__() {
    return AvIcons.m_videocam__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_videocam_off__() {
    return AvIcons.m_videocam_off__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_volume_down__() {
    return AvIcons.m_volume_down__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_volume_mute__() {
    return AvIcons.m_volume_mute__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_volume_off__() {
    return AvIcons.m_volume_off__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_volume_up__() {
    return AvIcons.m_volume_up__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_web__() {
    return AvIcons.m_web__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_web_asset__() {
    return AvIcons.m_web_asset__$default__org_dominokit_domino_ui_icons_AvIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_business__() {
    return CommunicationIcons.m_business__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call__() {
    return CommunicationIcons.m_call__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_end__() {
    return CommunicationIcons.m_call_end__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_made__() {
    return CommunicationIcons.m_call_made__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_merge__() {
    return CommunicationIcons.m_call_merge__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_missed__() {
    return CommunicationIcons.m_call_missed__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_missed_outgoing__() {
    return CommunicationIcons.m_call_missed_outgoing__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_received__() {
    return CommunicationIcons.m_call_received__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_call_split__() {
    return CommunicationIcons.m_call_split__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_chat__() {
    return CommunicationIcons.m_chat__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_chat_bubble__() {
    return CommunicationIcons.m_chat_bubble__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_chat_bubble_outline__() {
    return CommunicationIcons.m_chat_bubble_outline__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_clear_all__() {
    return CommunicationIcons.m_clear_all__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_comment__() {
    return CommunicationIcons.m_comment__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_contact_mail__() {
    return CommunicationIcons.m_contact_mail__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_contact_phone__() {
    return CommunicationIcons.m_contact_phone__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_contacts__() {
    return CommunicationIcons.m_contacts__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dialer_sip__() {
    return CommunicationIcons.m_dialer_sip__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dialpad__() {
    return CommunicationIcons.m_dialpad__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_email__() {
    return CommunicationIcons.m_email__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_forum__() {
    return CommunicationIcons.m_forum__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_import_contacts__() {
    return CommunicationIcons.m_import_contacts__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_import_export__() {
    return CommunicationIcons.m_import_export__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_invert_colors_off__() {
    return CommunicationIcons.m_invert_colors_off__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_live_help__() {
    return CommunicationIcons.m_live_help__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_location_off__() {
    return CommunicationIcons.m_location_off__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_location_on__() {
    return CommunicationIcons.m_location_on__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mail_outline__() {
    return CommunicationIcons.m_mail_outline__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_message__() {
    return CommunicationIcons.m_message__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_no_sim__() {
    return CommunicationIcons.m_no_sim__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone__() {
    return CommunicationIcons.m_phone__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phonelink_erase__() {
    return CommunicationIcons.m_phonelink_erase__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phonelink_lock__() {
    return CommunicationIcons.m_phonelink_lock__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phonelink_ring__() {
    return CommunicationIcons.m_phonelink_ring__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phonelink_setup__() {
    return CommunicationIcons.m_phonelink_setup__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_portable_wifi_off__() {
    return CommunicationIcons.m_portable_wifi_off__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_present_to_all__() {
    return CommunicationIcons.m_present_to_all__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_ring_volume__() {
    return CommunicationIcons.m_ring_volume__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rss_feed__() {
    return CommunicationIcons.m_rss_feed__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_screen_share__() {
    return CommunicationIcons.m_screen_share__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_speaker_phone__() {
    return CommunicationIcons.m_speaker_phone__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stay_current_landscape__() {
    return CommunicationIcons.m_stay_current_landscape__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stay_current_portrait__() {
    return CommunicationIcons.m_stay_current_portrait__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stay_primary_landscape__() {
    return CommunicationIcons.m_stay_primary_landscape__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stay_primary_portrait__() {
    return CommunicationIcons.m_stay_primary_portrait__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_stop_screen_share__() {
    return CommunicationIcons.m_stop_screen_share__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_swap_calls__() {
    return CommunicationIcons.m_swap_calls__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_textsms__() {
    return CommunicationIcons.m_textsms__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_voicemail__() {
    return CommunicationIcons.m_voicemail__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vpn_key__() {
    return CommunicationIcons.m_vpn_key__$default__org_dominokit_domino_ui_icons_CommunicationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add__() {
    return ContentIcons.m_add__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_box__() {
    return ContentIcons.m_add_box__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_circle__() {
    return ContentIcons.m_add_circle__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_circle_outline__() {
    return ContentIcons.m_add_circle_outline__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_archive__() {
    return ContentIcons.m_archive__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_backspace__() {
    return ContentIcons.m_backspace__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_block__() {
    return ContentIcons.m_block__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_clear__() {
    return ContentIcons.m_clear__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_content_copy__() {
    return ContentIcons.m_content_copy__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_content_cut__() {
    return ContentIcons.m_content_cut__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_content_paste__() {
    return ContentIcons.m_content_paste__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_create__() {
    return ContentIcons.m_create__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_delete_sweep__() {
    return ContentIcons.m_delete_sweep__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_drafts__() {
    return ContentIcons.m_drafts__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_list__() {
    return ContentIcons.m_filter_list__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flag__() {
    return ContentIcons.m_flag__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_font_download__() {
    return ContentIcons.m_font_download__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_forward__() {
    return ContentIcons.m_forward__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gesture__() {
    return ContentIcons.m_gesture__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_inbox__() {
    return ContentIcons.m_inbox__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_link__() {
    return ContentIcons.m_link__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_low_priority__() {
    return ContentIcons.m_low_priority__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mail__() {
    return ContentIcons.m_mail__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_markunread__() {
    return ContentIcons.m_markunread__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_move_to_inbox__() {
    return ContentIcons.m_move_to_inbox__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_next_week__() {
    return ContentIcons.m_next_week__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_redo__() {
    return ContentIcons.m_redo__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_remove__() {
    return ContentIcons.m_remove__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_remove_circle__() {
    return ContentIcons.m_remove_circle__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_remove_circle_outline__() {
    return ContentIcons.m_remove_circle_outline__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_reply__() {
    return ContentIcons.m_reply__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_reply_all__() {
    return ContentIcons.m_reply_all__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_report__() {
    return ContentIcons.m_report__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_save__() {
    return ContentIcons.m_save__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_select_all__() {
    return ContentIcons.m_select_all__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_send__() {
    return ContentIcons.m_send__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sort__() {
    return ContentIcons.m_sort__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_text_format__() {
    return ContentIcons.m_text_format__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_unarchive__() {
    return ContentIcons.m_unarchive__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_undo__() {
    return ContentIcons.m_undo__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_weekend__() {
    return ContentIcons.m_weekend__$default__org_dominokit_domino_ui_icons_ContentIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_access_alarm__() {
    return DeviceIcons.m_access_alarm__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_access_alarms__() {
    return DeviceIcons.m_access_alarms__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_access_time__() {
    return DeviceIcons.m_access_time__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_alarm__() {
    return DeviceIcons.m_add_alarm__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airplanemode_active__() {
    return DeviceIcons.m_airplanemode_active__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airplanemode_inactive__() {
    return DeviceIcons.m_airplanemode_inactive__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_battery_alert__() {
    return DeviceIcons.m_battery_alert__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_battery_charging_full__() {
    return DeviceIcons.m_battery_charging_full__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_battery_full__() {
    return DeviceIcons.m_battery_full__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_battery_std__() {
    return DeviceIcons.m_battery_std__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_battery_unknown__() {
    return DeviceIcons.m_battery_unknown__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bluetooth__() {
    return DeviceIcons.m_bluetooth__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bluetooth_connected__() {
    return DeviceIcons.m_bluetooth_connected__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bluetooth_disabled__() {
    return DeviceIcons.m_bluetooth_disabled__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bluetooth_searching__() {
    return DeviceIcons.m_bluetooth_searching__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_auto__() {
    return DeviceIcons.m_brightness_auto__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_high__() {
    return DeviceIcons.m_brightness_high__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_low__() {
    return DeviceIcons.m_brightness_low__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_medium__() {
    return DeviceIcons.m_brightness_medium__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_data_usage__() {
    return DeviceIcons.m_data_usage__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_developer_mode__() {
    return DeviceIcons.m_developer_mode__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_devices__() {
    return DeviceIcons.m_devices__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dvr__() {
    return DeviceIcons.m_dvr__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gps_fixed__() {
    return DeviceIcons.m_gps_fixed__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gps_not_fixed__() {
    return DeviceIcons.m_gps_not_fixed__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gps_off__() {
    return DeviceIcons.m_gps_off__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_graphic_eq__() {
    return DeviceIcons.m_graphic_eq__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_location_disabled__() {
    return DeviceIcons.m_location_disabled__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_location_searching__() {
    return DeviceIcons.m_location_searching__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_network_cell__() {
    return DeviceIcons.m_network_cell__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_network_wifi__() {
    return DeviceIcons.m_network_wifi__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_nfc__() {
    return DeviceIcons.m_nfc__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_screen_lock_landscape__() {
    return DeviceIcons.m_screen_lock_landscape__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_screen_lock_portrait__() {
    return DeviceIcons.m_screen_lock_portrait__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_screen_lock_rotation__() {
    return DeviceIcons.m_screen_lock_rotation__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_screen_rotation__() {
    return DeviceIcons.m_screen_rotation__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sd_storage__() {
    return DeviceIcons.m_sd_storage__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_settings_system_daydream__() {
    return DeviceIcons.m_settings_system_daydream__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_cellular_4_bar__() {
    return DeviceIcons.m_signal_cellular_4_bar__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_cellular_connected_no_internet_4_bar__() {
    return DeviceIcons.m_signal_cellular_connected_no_internet_4_bar__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_cellular_no_sim__() {
    return DeviceIcons.m_signal_cellular_no_sim__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_cellular_null__() {
    return DeviceIcons.m_signal_cellular_null__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_cellular_off__() {
    return DeviceIcons.m_signal_cellular_off__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_wifi_4_bar__() {
    return DeviceIcons.m_signal_wifi_4_bar__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_wifi_4_bar_lock__() {
    return DeviceIcons.m_signal_wifi_4_bar_lock__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_signal_wifi_off__() {
    return DeviceIcons.m_signal_wifi_off__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_storage__() {
    return DeviceIcons.m_storage__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_usb__() {
    return DeviceIcons.m_usb__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wallpaper__() {
    return DeviceIcons.m_wallpaper__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_widgets__() {
    return DeviceIcons.m_widgets__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wifi_lock__() {
    return DeviceIcons.m_wifi_lock__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wifi_tethering__() {
    return DeviceIcons.m_wifi_tethering__$default__org_dominokit_domino_ui_icons_DeviceIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_attach_file__() {
    return EditorIcons.m_attach_file__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_attach_money__() {
    return EditorIcons.m_attach_money__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_all__() {
    return EditorIcons.m_border_all__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_bottom__() {
    return EditorIcons.m_border_bottom__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_clear__() {
    return EditorIcons.m_border_clear__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_color__() {
    return EditorIcons.m_border_color__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_horizontal__() {
    return EditorIcons.m_border_horizontal__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_inner__() {
    return EditorIcons.m_border_inner__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_left__() {
    return EditorIcons.m_border_left__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_outer__() {
    return EditorIcons.m_border_outer__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_right__() {
    return EditorIcons.m_border_right__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_style__() {
    return EditorIcons.m_border_style__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_top__() {
    return EditorIcons.m_border_top__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_border_vertical__() {
    return EditorIcons.m_border_vertical__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bubble_chart__() {
    return EditorIcons.m_bubble_chart__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_drag_handle__() {
    return EditorIcons.m_drag_handle__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_align_center__() {
    return EditorIcons.m_format_align_center__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_align_justify__() {
    return EditorIcons.m_format_align_justify__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_align_left__() {
    return EditorIcons.m_format_align_left__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_align_right__() {
    return EditorIcons.m_format_align_right__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_bold__() {
    return EditorIcons.m_format_bold__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_clear__() {
    return EditorIcons.m_format_clear__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_color_fill__() {
    return EditorIcons.m_format_color_fill__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_color_reset__() {
    return EditorIcons.m_format_color_reset__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_color_text__() {
    return EditorIcons.m_format_color_text__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_indent_decrease__() {
    return EditorIcons.m_format_indent_decrease__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_indent_increase__() {
    return EditorIcons.m_format_indent_increase__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_italic__() {
    return EditorIcons.m_format_italic__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_line_spacing__() {
    return EditorIcons.m_format_line_spacing__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_list_bulleted__() {
    return EditorIcons.m_format_list_bulleted__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_list_numbered__() {
    return EditorIcons.m_format_list_numbered__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_paint__() {
    return EditorIcons.m_format_paint__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_quote__() {
    return EditorIcons.m_format_quote__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_shapes__() {
    return EditorIcons.m_format_shapes__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_size__() {
    return EditorIcons.m_format_size__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_strikethrough__() {
    return EditorIcons.m_format_strikethrough__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_textdirection_l_to_r__() {
    return EditorIcons.m_format_textdirection_l_to_r__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_textdirection_r_to_l__() {
    return EditorIcons.m_format_textdirection_r_to_l__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_format_underlined__() {
    return EditorIcons.m_format_underlined__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_functions__() {
    return EditorIcons.m_functions__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_highlight__() {
    return EditorIcons.m_highlight__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_chart__() {
    return EditorIcons.m_insert_chart__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_comment__() {
    return EditorIcons.m_insert_comment__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_drive_file__() {
    return EditorIcons.m_insert_drive_file__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_emoticon__() {
    return EditorIcons.m_insert_emoticon__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_invitation__() {
    return EditorIcons.m_insert_invitation__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_link__() {
    return EditorIcons.m_insert_link__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_insert_photo__() {
    return EditorIcons.m_insert_photo__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_linear_scale__() {
    return EditorIcons.m_linear_scale__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_merge_type__() {
    return EditorIcons.m_merge_type__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mode_comment__() {
    return EditorIcons.m_mode_comment__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mode_edit__() {
    return EditorIcons.m_mode_edit__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_monetization_on__() {
    return EditorIcons.m_monetization_on__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_money_off__() {
    return EditorIcons.m_money_off__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_multiline_chart__() {
    return EditorIcons.m_multiline_chart__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pie_chart__() {
    return EditorIcons.m_pie_chart__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pie_chart_outlined__() {
    return EditorIcons.m_pie_chart_outlined__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_publish__() {
    return EditorIcons.m_publish__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_short_text__() {
    return EditorIcons.m_short_text__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_show_chart__() {
    return EditorIcons.m_show_chart__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_space_bar__() {
    return EditorIcons.m_space_bar__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_strikethrough_s__() {
    return EditorIcons.m_strikethrough_s__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_text_fields__() {
    return EditorIcons.m_text_fields__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_title__() {
    return EditorIcons.m_title__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vertical_align_bottom__() {
    return EditorIcons.m_vertical_align_bottom__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vertical_align_center__() {
    return EditorIcons.m_vertical_align_center__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vertical_align_top__() {
    return EditorIcons.m_vertical_align_top__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wrap_text__() {
    return EditorIcons.m_wrap_text__$default__org_dominokit_domino_ui_icons_EditorIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cast__() {
    return HardwareIcons.m_cast__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cast_connected__() {
    return HardwareIcons.m_cast_connected__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_computer__() {
    return HardwareIcons.m_computer__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_desktop_mac__() {
    return HardwareIcons.m_desktop_mac__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_desktop_windows__() {
    return HardwareIcons.m_desktop_windows__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_developer_board__() {
    return HardwareIcons.m_developer_board__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_device_hub__() {
    return HardwareIcons.m_device_hub__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_devices_other__() {
    return HardwareIcons.m_devices_other__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dock__() {
    return HardwareIcons.m_dock__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gamepad__() {
    return HardwareIcons.m_gamepad__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_headset__() {
    return HardwareIcons.m_headset__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_headset_mic__() {
    return HardwareIcons.m_headset_mic__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard__() {
    return HardwareIcons.m_keyboard__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_down__() {
    return HardwareIcons.m_keyboard_arrow_down__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_left__() {
    return HardwareIcons.m_keyboard_arrow_left__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_right__() {
    return HardwareIcons.m_keyboard_arrow_right__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_arrow_up__() {
    return HardwareIcons.m_keyboard_arrow_up__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_backspace__() {
    return HardwareIcons.m_keyboard_backspace__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_capslock__() {
    return HardwareIcons.m_keyboard_capslock__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_hide__() {
    return HardwareIcons.m_keyboard_hide__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_return__() {
    return HardwareIcons.m_keyboard_return__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_tab__() {
    return HardwareIcons.m_keyboard_tab__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_keyboard_voice__() {
    return HardwareIcons.m_keyboard_voice__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_laptop__() {
    return HardwareIcons.m_laptop__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_laptop_chromebook__() {
    return HardwareIcons.m_laptop_chromebook__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_laptop_mac__() {
    return HardwareIcons.m_laptop_mac__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_laptop_windows__() {
    return HardwareIcons.m_laptop_windows__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_memory__() {
    return HardwareIcons.m_memory__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mouse__() {
    return HardwareIcons.m_mouse__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_android__() {
    return HardwareIcons.m_phone_android__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_iphone__() {
    return HardwareIcons.m_phone_iphone__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phonelink__() {
    return HardwareIcons.m_phonelink__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phonelink_off__() {
    return HardwareIcons.m_phonelink_off__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_power_input__() {
    return HardwareIcons.m_power_input__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_router__() {
    return HardwareIcons.m_router__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_scanner__() {
    return HardwareIcons.m_scanner__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_security__() {
    return HardwareIcons.m_security__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sim_card__() {
    return HardwareIcons.m_sim_card__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_smartphone__() {
    return HardwareIcons.m_smartphone__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_speaker__() {
    return HardwareIcons.m_speaker__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_speaker_group__() {
    return HardwareIcons.m_speaker_group__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tablet__() {
    return HardwareIcons.m_tablet__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tablet_android__() {
    return HardwareIcons.m_tablet_android__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tablet_mac__() {
    return HardwareIcons.m_tablet_mac__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_toys__() {
    return HardwareIcons.m_toys__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tv__() {
    return HardwareIcons.m_tv__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_videogame_asset__() {
    return HardwareIcons.m_videogame_asset__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_watch__() {
    return HardwareIcons.m_watch__$default__org_dominokit_domino_ui_icons_HardwareIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_attachment__() {
    return FileIcons.m_attachment__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud__() {
    return FileIcons.m_cloud__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud_circle__() {
    return FileIcons.m_cloud_circle__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud_done__() {
    return FileIcons.m_cloud_done__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud_download__() {
    return FileIcons.m_cloud_download__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud_off__() {
    return FileIcons.m_cloud_off__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud_queue__() {
    return FileIcons.m_cloud_queue__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cloud_upload__() {
    return FileIcons.m_cloud_upload__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_create_new_folder__() {
    return FileIcons.m_create_new_folder__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_file_download__() {
    return FileIcons.m_file_download__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_file_upload__() {
    return FileIcons.m_file_upload__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_folder__() {
    return FileIcons.m_folder__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_folder_open__() {
    return FileIcons.m_folder_open__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_folder_shared__() {
    return FileIcons.m_folder_shared__$default__org_dominokit_domino_ui_icons_FileIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_a_photo__() {
    return ImageIcons.m_add_a_photo__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_to_photos__() {
    return ImageIcons.m_add_to_photos__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_adjust__() {
    return ImageIcons.m_adjust__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assistant__() {
    return ImageIcons.m_assistant__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_assistant_photo__() {
    return ImageIcons.m_assistant_photo__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_audiotrack__() {
    return ImageIcons.m_audiotrack__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_blur_circular__() {
    return ImageIcons.m_blur_circular__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_blur_linear__() {
    return ImageIcons.m_blur_linear__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_blur_off__() {
    return ImageIcons.m_blur_off__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_blur_on__() {
    return ImageIcons.m_blur_on__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_1__() {
    return ImageIcons.m_brightness_1__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_2__() {
    return ImageIcons.m_brightness_2__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_3__() {
    return ImageIcons.m_brightness_3__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_4__() {
    return ImageIcons.m_brightness_4__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_5__() {
    return ImageIcons.m_brightness_5__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_6__() {
    return ImageIcons.m_brightness_6__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brightness_7__() {
    return ImageIcons.m_brightness_7__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_broken_image__() {
    return ImageIcons.m_broken_image__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_brush__() {
    return ImageIcons.m_brush__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_burst_mode__() {
    return ImageIcons.m_burst_mode__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_camera__() {
    return ImageIcons.m_camera__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_camera_alt__() {
    return ImageIcons.m_camera_alt__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_camera_front__() {
    return ImageIcons.m_camera_front__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_camera_rear__() {
    return ImageIcons.m_camera_rear__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_camera_roll__() {
    return ImageIcons.m_camera_roll__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_center_focus_strong__() {
    return ImageIcons.m_center_focus_strong__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_center_focus_weak__() {
    return ImageIcons.m_center_focus_weak__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_collections__() {
    return ImageIcons.m_collections__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_collections_bookmark__() {
    return ImageIcons.m_collections_bookmark__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_color_lens__() {
    return ImageIcons.m_color_lens__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_colorize__() {
    return ImageIcons.m_colorize__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_compare__() {
    return ImageIcons.m_compare__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_control_point__() {
    return ImageIcons.m_control_point__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_control_point_duplicate__() {
    return ImageIcons.m_control_point_duplicate__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop__() {
    return ImageIcons.m_crop__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_16_9__() {
    return ImageIcons.m_crop_16_9__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_3_2__() {
    return ImageIcons.m_crop_3_2__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_5_4__() {
    return ImageIcons.m_crop_5_4__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_7_5__() {
    return ImageIcons.m_crop_7_5__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_din__() {
    return ImageIcons.m_crop_din__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_free__() {
    return ImageIcons.m_crop_free__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_landscape__() {
    return ImageIcons.m_crop_landscape__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_original__() {
    return ImageIcons.m_crop_original__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_portrait__() {
    return ImageIcons.m_crop_portrait__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_rotate__() {
    return ImageIcons.m_crop_rotate__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_crop_square__() {
    return ImageIcons.m_crop_square__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_dehaze__() {
    return ImageIcons.m_dehaze__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_details__() {
    return ImageIcons.m_details__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_edit__() {
    return ImageIcons.m_edit__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exposure__() {
    return ImageIcons.m_exposure__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exposure_neg_1__() {
    return ImageIcons.m_exposure_neg_1__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exposure_neg_2__() {
    return ImageIcons.m_exposure_neg_2__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exposure_plus_1__() {
    return ImageIcons.m_exposure_plus_1__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exposure_plus_2__() {
    return ImageIcons.m_exposure_plus_2__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_exposure_zero__() {
    return ImageIcons.m_exposure_zero__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter__() {
    return ImageIcons.m_filter__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_1__() {
    return ImageIcons.m_filter_1__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_2__() {
    return ImageIcons.m_filter_2__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_3__() {
    return ImageIcons.m_filter_3__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_4__() {
    return ImageIcons.m_filter_4__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_5__() {
    return ImageIcons.m_filter_5__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_6__() {
    return ImageIcons.m_filter_6__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_7__() {
    return ImageIcons.m_filter_7__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_8__() {
    return ImageIcons.m_filter_8__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_9__() {
    return ImageIcons.m_filter_9__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_9_plus__() {
    return ImageIcons.m_filter_9_plus__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_b_and_w__() {
    return ImageIcons.m_filter_b_and_w__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_center_focus__() {
    return ImageIcons.m_filter_center_focus__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_drama__() {
    return ImageIcons.m_filter_drama__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_frames__() {
    return ImageIcons.m_filter_frames__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_hdr__() {
    return ImageIcons.m_filter_hdr__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_none__() {
    return ImageIcons.m_filter_none__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_tilt_shift__() {
    return ImageIcons.m_filter_tilt_shift__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_filter_vintage__() {
    return ImageIcons.m_filter_vintage__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flare__() {
    return ImageIcons.m_flare__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flash_auto__() {
    return ImageIcons.m_flash_auto__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flash_off__() {
    return ImageIcons.m_flash_off__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flash_on__() {
    return ImageIcons.m_flash_on__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flip__() {
    return ImageIcons.m_flip__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_gradient__() {
    return ImageIcons.m_gradient__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_grain__() {
    return ImageIcons.m_grain__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_grid_off__() {
    return ImageIcons.m_grid_off__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_grid_on__() {
    return ImageIcons.m_grid_on__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hdr_off__() {
    return ImageIcons.m_hdr_off__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hdr_on__() {
    return ImageIcons.m_hdr_on__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hdr_strong__() {
    return ImageIcons.m_hdr_strong__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hdr_weak__() {
    return ImageIcons.m_hdr_weak__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_healing__() {
    return ImageIcons.m_healing__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_image__() {
    return ImageIcons.m_image__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_image_aspect_ratio__() {
    return ImageIcons.m_image_aspect_ratio__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_iso__() {
    return ImageIcons.m_iso__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_landscape__() {
    return ImageIcons.m_landscape__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_leak_add__() {
    return ImageIcons.m_leak_add__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_leak_remove__() {
    return ImageIcons.m_leak_remove__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_lens__() {
    return ImageIcons.m_lens__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_linked_camera__() {
    return ImageIcons.m_linked_camera__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks__() {
    return ImageIcons.m_looks__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks_3__() {
    return ImageIcons.m_looks_3__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks_4__() {
    return ImageIcons.m_looks_4__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks_5__() {
    return ImageIcons.m_looks_5__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks_6__() {
    return ImageIcons.m_looks_6__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks_one__() {
    return ImageIcons.m_looks_one__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_looks_two__() {
    return ImageIcons.m_looks_two__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_loupe__() {
    return ImageIcons.m_loupe__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_monochrome_photos__() {
    return ImageIcons.m_monochrome_photos__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_movie_creation__() {
    return ImageIcons.m_movie_creation__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_movie_filter__() {
    return ImageIcons.m_movie_filter__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_music_note__() {
    return ImageIcons.m_music_note__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_nature__() {
    return ImageIcons.m_nature__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_nature_people__() {
    return ImageIcons.m_nature_people__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_navigate_before__() {
    return ImageIcons.m_navigate_before__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_navigate_next__() {
    return ImageIcons.m_navigate_next__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_palette__() {
    return ImageIcons.m_palette__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_panorama__() {
    return ImageIcons.m_panorama__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_panorama_fish_eye__() {
    return ImageIcons.m_panorama_fish_eye__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_panorama_horizontal__() {
    return ImageIcons.m_panorama_horizontal__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_panorama_vertical__() {
    return ImageIcons.m_panorama_vertical__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_panorama_wide_angle__() {
    return ImageIcons.m_panorama_wide_angle__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo__() {
    return ImageIcons.m_photo__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_album__() {
    return ImageIcons.m_photo_album__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_camera__() {
    return ImageIcons.m_photo_camera__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_filter__() {
    return ImageIcons.m_photo_filter__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_library__() {
    return ImageIcons.m_photo_library__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_size_select_actual__() {
    return ImageIcons.m_photo_size_select_actual__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_size_select_large__() {
    return ImageIcons.m_photo_size_select_large__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_photo_size_select_small__() {
    return ImageIcons.m_photo_size_select_small__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_picture_as_pdf__() {
    return ImageIcons.m_picture_as_pdf__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_portrait__() {
    return ImageIcons.m_portrait__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_remove_red_eye__() {
    return ImageIcons.m_remove_red_eye__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rotate_90_degrees_ccw__() {
    return ImageIcons.m_rotate_90_degrees_ccw__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rotate_left__() {
    return ImageIcons.m_rotate_left__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rotate_right__() {
    return ImageIcons.m_rotate_right__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_slideshow__() {
    return ImageIcons.m_slideshow__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_straighten__() {
    return ImageIcons.m_straighten__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_style__() {
    return ImageIcons.m_style__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_switch_camera__() {
    return ImageIcons.m_switch_camera__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_switch_video__() {
    return ImageIcons.m_switch_video__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tag_faces__() {
    return ImageIcons.m_tag_faces__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_texture__() {
    return ImageIcons.m_texture__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_timelapse__() {
    return ImageIcons.m_timelapse__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_timer__() {
    return ImageIcons.m_timer__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_timer_10__() {
    return ImageIcons.m_timer_10__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_timer_3__() {
    return ImageIcons.m_timer_3__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_timer_off__() {
    return ImageIcons.m_timer_off__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tonality__() {
    return ImageIcons.m_tonality__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_transform__() {
    return ImageIcons.m_transform__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tune__() {
    return ImageIcons.m_tune__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_comfy__() {
    return ImageIcons.m_view_comfy__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_view_compact__() {
    return ImageIcons.m_view_compact__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vignette__() {
    return ImageIcons.m_vignette__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wb_auto__() {
    return ImageIcons.m_wb_auto__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wb_cloudy__() {
    return ImageIcons.m_wb_cloudy__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wb_incandescent__() {
    return ImageIcons.m_wb_incandescent__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wb_iridescent__() {
    return ImageIcons.m_wb_iridescent__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wb_sunny__() {
    return ImageIcons.m_wb_sunny__$default__org_dominokit_domino_ui_icons_ImageIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_add_location__() {
    return MapsIcons.m_add_location__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_beenhere__() {
    return MapsIcons.m_beenhere__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions__() {
    return MapsIcons.m_directions__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_bike__() {
    return MapsIcons.m_directions_bike__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_boat__() {
    return MapsIcons.m_directions_boat__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_bus__() {
    return MapsIcons.m_directions_bus__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_car__() {
    return MapsIcons.m_directions_car__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_railway__() {
    return MapsIcons.m_directions_railway__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_run__() {
    return MapsIcons.m_directions_run__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_subway__() {
    return MapsIcons.m_directions_subway__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_transit__() {
    return MapsIcons.m_directions_transit__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_directions_walk__() {
    return MapsIcons.m_directions_walk__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_edit_location__() {
    return MapsIcons.m_edit_location__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_ev_station__() {
    return MapsIcons.m_ev_station__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_flight__() {
    return MapsIcons.m_flight__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hotel__() {
    return MapsIcons.m_hotel__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_layers__() {
    return MapsIcons.m_layers__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_layers_clear__() {
    return MapsIcons.m_layers_clear__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_activity__() {
    return MapsIcons.m_local_activity__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_airport__() {
    return MapsIcons.m_local_airport__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_atm__() {
    return MapsIcons.m_local_atm__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_bar__() {
    return MapsIcons.m_local_bar__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_cafe__() {
    return MapsIcons.m_local_cafe__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_car_wash__() {
    return MapsIcons.m_local_car_wash__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_convenience_store__() {
    return MapsIcons.m_local_convenience_store__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_dining__() {
    return MapsIcons.m_local_dining__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_drink__() {
    return MapsIcons.m_local_drink__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_florist__() {
    return MapsIcons.m_local_florist__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_gas_station__() {
    return MapsIcons.m_local_gas_station__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_grocery_store__() {
    return MapsIcons.m_local_grocery_store__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_hospital__() {
    return MapsIcons.m_local_hospital__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_hotel__() {
    return MapsIcons.m_local_hotel__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_laundry_service__() {
    return MapsIcons.m_local_laundry_service__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_library__() {
    return MapsIcons.m_local_library__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_mall__() {
    return MapsIcons.m_local_mall__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_movies__() {
    return MapsIcons.m_local_movies__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_offer__() {
    return MapsIcons.m_local_offer__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_parking__() {
    return MapsIcons.m_local_parking__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_pharmacy__() {
    return MapsIcons.m_local_pharmacy__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_phone__() {
    return MapsIcons.m_local_phone__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_pizza__() {
    return MapsIcons.m_local_pizza__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_play__() {
    return MapsIcons.m_local_play__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_post_office__() {
    return MapsIcons.m_local_post_office__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_printshop__() {
    return MapsIcons.m_local_printshop__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_see__() {
    return MapsIcons.m_local_see__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_shipping__() {
    return MapsIcons.m_local_shipping__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_local_taxi__() {
    return MapsIcons.m_local_taxi__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_map__() {
    return MapsIcons.m_map__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_my_location__() {
    return MapsIcons.m_my_location__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_navigation__() {
    return MapsIcons.m_navigation__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_near_me__() {
    return MapsIcons.m_near_me__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_person_pin__() {
    return MapsIcons.m_person_pin__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_person_pin_circle__() {
    return MapsIcons.m_person_pin_circle__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pin_drop__() {
    return MapsIcons.m_pin_drop__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_place__() {
    return MapsIcons.m_place__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rate_review__() {
    return MapsIcons.m_rate_review__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_restaurant__() {
    return MapsIcons.m_restaurant__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_restaurant_menu__() {
    return MapsIcons.m_restaurant_menu__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_satellite__() {
    return MapsIcons.m_satellite__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_store_mall_directory__() {
    return MapsIcons.m_store_mall_directory__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_streetview__() {
    return MapsIcons.m_streetview__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_subway__() {
    return MapsIcons.m_subway__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_terrain__() {
    return MapsIcons.m_terrain__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_traffic__() {
    return MapsIcons.m_traffic__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_train__() {
    return MapsIcons.m_train__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tram__() {
    return MapsIcons.m_tram__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_transfer_within_a_station__() {
    return MapsIcons.m_transfer_within_a_station__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_zoom_out_map__() {
    return MapsIcons.m_zoom_out_map__$default__org_dominokit_domino_ui_icons_MapsIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_apps__() {
    return NavigationIcons.m_apps__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_back__() {
    return NavigationIcons.m_arrow_back__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_downward__() {
    return NavigationIcons.m_arrow_downward__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_drop_down__() {
    return NavigationIcons.m_arrow_drop_down__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_drop_down_circle__() {
    return NavigationIcons.m_arrow_drop_down_circle__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_drop_up__() {
    return NavigationIcons.m_arrow_drop_up__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_forward__() {
    return NavigationIcons.m_arrow_forward__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_arrow_upward__() {
    return NavigationIcons.m_arrow_upward__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cancel__() {
    return NavigationIcons.m_cancel__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_check__() {
    return NavigationIcons.m_check__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_chevron_left__() {
    return NavigationIcons.m_chevron_left__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_chevron_right__() {
    return NavigationIcons.m_chevron_right__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_close__() {
    return NavigationIcons.m_close__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_expand_less__() {
    return NavigationIcons.m_expand_less__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_expand_more__() {
    return NavigationIcons.m_expand_more__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_first_page__() {
    return NavigationIcons.m_first_page__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fullscreen__() {
    return NavigationIcons.m_fullscreen__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fullscreen_exit__() {
    return NavigationIcons.m_fullscreen_exit__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_last_page__() {
    return NavigationIcons.m_last_page__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_menu__() {
    return NavigationIcons.m_menu__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_more_horiz__() {
    return NavigationIcons.m_more_horiz__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_more_vert__() {
    return NavigationIcons.m_more_vert__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_refresh__() {
    return NavigationIcons.m_refresh__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_subdirectory_arrow_left__() {
    return NavigationIcons.m_subdirectory_arrow_left__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_subdirectory_arrow_right__() {
    return NavigationIcons.m_subdirectory_arrow_right__$default__org_dominokit_domino_ui_icons_NavigationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_adb__() {
    return NotificationIcons.m_adb__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_flat__() {
    return NotificationIcons.m_airline_seat_flat__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_flat_angled__() {
    return NotificationIcons.m_airline_seat_flat_angled__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_individual_suite__() {
    return NotificationIcons.m_airline_seat_individual_suite__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_legroom_extra__() {
    return NotificationIcons.m_airline_seat_legroom_extra__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_legroom_normal__() {
    return NotificationIcons.m_airline_seat_legroom_normal__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_legroom_reduced__() {
    return NotificationIcons.m_airline_seat_legroom_reduced__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_recline_extra__() {
    return NotificationIcons.m_airline_seat_recline_extra__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airline_seat_recline_normal__() {
    return NotificationIcons.m_airline_seat_recline_normal__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_bluetooth_audio__() {
    return NotificationIcons.m_bluetooth_audio__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_confirmation_number__() {
    return NotificationIcons.m_confirmation_number__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_disc_full__() {
    return NotificationIcons.m_disc_full__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_do_not_disturb__() {
    return NotificationIcons.m_do_not_disturb__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_do_not_disturb_alt__() {
    return NotificationIcons.m_do_not_disturb_alt__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_do_not_disturb_off__() {
    return NotificationIcons.m_do_not_disturb_off__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_do_not_disturb_on__() {
    return NotificationIcons.m_do_not_disturb_on__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_drive_eta__() {
    return NotificationIcons.m_drive_eta__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_enhanced_encryption__() {
    return NotificationIcons.m_enhanced_encryption__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_event_available__() {
    return NotificationIcons.m_event_available__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_event_busy__() {
    return NotificationIcons.m_event_busy__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_event_note__() {
    return NotificationIcons.m_event_note__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_folder_special__() {
    return NotificationIcons.m_folder_special__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_live_tv__() {
    return NotificationIcons.m_live_tv__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mms__() {
    return NotificationIcons.m_mms__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_more__() {
    return NotificationIcons.m_more__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_network_check__() {
    return NotificationIcons.m_network_check__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_network_locked__() {
    return NotificationIcons.m_network_locked__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_no_encryption__() {
    return NotificationIcons.m_no_encryption__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_ondemand_video__() {
    return NotificationIcons.m_ondemand_video__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_personal_video__() {
    return NotificationIcons.m_personal_video__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_bluetooth_speaker__() {
    return NotificationIcons.m_phone_bluetooth_speaker__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_forwarded__() {
    return NotificationIcons.m_phone_forwarded__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_in_talk__() {
    return NotificationIcons.m_phone_in_talk__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_locked__() {
    return NotificationIcons.m_phone_locked__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_missed__() {
    return NotificationIcons.m_phone_missed__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_phone_paused__() {
    return NotificationIcons.m_phone_paused__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_power__() {
    return NotificationIcons.m_power__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_priority_high__() {
    return NotificationIcons.m_priority_high__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sd_card__() {
    return NotificationIcons.m_sd_card__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sim_card_alert__() {
    return NotificationIcons.m_sim_card_alert__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sms__() {
    return NotificationIcons.m_sms__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sms_failed__() {
    return NotificationIcons.m_sms_failed__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sync__() {
    return NotificationIcons.m_sync__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sync_disabled__() {
    return NotificationIcons.m_sync_disabled__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sync_problem__() {
    return NotificationIcons.m_sync_problem__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_system_update__() {
    return NotificationIcons.m_system_update__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_tap_and_play__() {
    return NotificationIcons.m_tap_and_play__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_time_to_leave__() {
    return NotificationIcons.m_time_to_leave__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vibration__() {
    return NotificationIcons.m_vibration__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_voice_chat__() {
    return NotificationIcons.m_voice_chat__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_vpn_lock__() {
    return NotificationIcons.m_vpn_lock__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wc__() {
    return NotificationIcons.m_wc__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_wifi__() {
    return NotificationIcons.m_wifi__$default__org_dominokit_domino_ui_icons_NotificationIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_ac_unit__() {
    return PlacesIcons.m_ac_unit__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_airport_shuttle__() {
    return PlacesIcons.m_airport_shuttle__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_all_inclusive__() {
    return PlacesIcons.m_all_inclusive__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_beach_access__() {
    return PlacesIcons.m_beach_access__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_business_center__() {
    return PlacesIcons.m_business_center__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_casino__() {
    return PlacesIcons.m_casino__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_child_care__() {
    return PlacesIcons.m_child_care__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_child_friendly__() {
    return PlacesIcons.m_child_friendly__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_fitness_center__() {
    return PlacesIcons.m_fitness_center__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_free_breakfast__() {
    return PlacesIcons.m_free_breakfast__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_golf_course__() {
    return PlacesIcons.m_golf_course__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_hot_tub__() {
    return PlacesIcons.m_hot_tub__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_kitchen__() {
    return PlacesIcons.m_kitchen__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pool__() {
    return PlacesIcons.m_pool__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_room_service__() {
    return PlacesIcons.m_room_service__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_rv_hookup__() {
    return PlacesIcons.m_rv_hookup__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_smoke_free__() {
    return PlacesIcons.m_smoke_free__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_smoking_rooms__() {
    return PlacesIcons.m_smoking_rooms__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_spa__() {
    return PlacesIcons.m_spa__$default__org_dominokit_domino_ui_icons_PlacesIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_cake__() {
    return SocialIcons.m_cake__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_domain__() {
    return SocialIcons.m_domain__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_group__() {
    return SocialIcons.m_group__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_group_add__() {
    return SocialIcons.m_group_add__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_location_city__() {
    return SocialIcons.m_location_city__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mood__() {
    return SocialIcons.m_mood__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_mood_bad__() {
    return SocialIcons.m_mood_bad__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_notifications__() {
    return SocialIcons.m_notifications__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_notifications_active__() {
    return SocialIcons.m_notifications_active__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_notifications_none__() {
    return SocialIcons.m_notifications_none__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_notifications_off__() {
    return SocialIcons.m_notifications_off__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_notifications_paused__() {
    return SocialIcons.m_notifications_paused__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_pages__() {
    return SocialIcons.m_pages__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_party_mode__() {
    return SocialIcons.m_party_mode__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_people__() {
    return SocialIcons.m_people__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_people_outline__() {
    return SocialIcons.m_people_outline__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_person__() {
    return SocialIcons.m_person__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_person_add__() {
    return SocialIcons.m_person_add__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_person_outline__() {
    return SocialIcons.m_person_outline__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_plus_one__() {
    return SocialIcons.m_plus_one__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_poll__() {
    return SocialIcons.m_poll__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_publicc__() {
    return SocialIcons.m_publicc__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_school__() {
    return SocialIcons.m_school__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sentiment_dissatisfied__() {
    return SocialIcons.m_sentiment_dissatisfied__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sentiment_neutral__() {
    return SocialIcons.m_sentiment_neutral__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sentiment_satisfied__() {
    return SocialIcons.m_sentiment_satisfied__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sentiment_very_dissatisfied__() {
    return SocialIcons.m_sentiment_very_dissatisfied__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_sentiment_very_satisfied__() {
    return SocialIcons.m_sentiment_very_satisfied__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_share__() {
    return SocialIcons.m_share__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_whatshot__() {
    return SocialIcons.m_whatshot__$default__org_dominokit_domino_ui_icons_SocialIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_check_box__() {
    return ToggleIcons.m_check_box__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_check_box_outline_blank__() {
    return ToggleIcons.m_check_box_outline_blank__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_indeterminate_check_box__() {
    return ToggleIcons.m_indeterminate_check_box__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_radio_button_checked__() {
    return ToggleIcons.m_radio_button_checked__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_radio_button_unchecked__() {
    return ToggleIcons.m_radio_button_unchecked__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_star__() {
    return ToggleIcons.m_star__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_star_border__() {
    return ToggleIcons.m_star_border__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Icon}
   * @public
   */
  m_star_half__() {
    return ToggleIcons.m_star_half__$default__org_dominokit_domino_ui_icons_ToggleIcons(this);
  }
  
  /**
   * @return {Icons}
   * @public
   */
  static get f_ALL__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {Icons} value
   * @return {void}
   * @public
   */
  static set f_ALL__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {ActionIcons}
   * @public
   */
  static get f_ACTION_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_ACTION_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {ActionIcons} value
   * @return {void}
   * @public
   */
  static set f_ACTION_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_ACTION_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {AlertIcons}
   * @public
   */
  static get f_ALERT_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_ALERT_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {AlertIcons} value
   * @return {void}
   * @public
   */
  static set f_ALERT_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_ALERT_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {AvIcons}
   * @public
   */
  static get f_AV_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_AV_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {AvIcons} value
   * @return {void}
   * @public
   */
  static set f_AV_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_AV_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {CommunicationIcons}
   * @public
   */
  static get f_COMMUNICATION_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_COMMUNICATION_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {CommunicationIcons} value
   * @return {void}
   * @public
   */
  static set f_COMMUNICATION_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_COMMUNICATION_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {ContentIcons}
   * @public
   */
  static get f_CONTENT_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_CONTENT_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {ContentIcons} value
   * @return {void}
   * @public
   */
  static set f_CONTENT_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_CONTENT_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {DeviceIcons}
   * @public
   */
  static get f_DEVICE_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_DEVICE_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {DeviceIcons} value
   * @return {void}
   * @public
   */
  static set f_DEVICE_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_DEVICE_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {EditorIcons}
   * @public
   */
  static get f_EDITOR_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_EDITOR_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {EditorIcons} value
   * @return {void}
   * @public
   */
  static set f_EDITOR_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_EDITOR_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {FileIcons}
   * @public
   */
  static get f_FILE_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_FILE_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {FileIcons} value
   * @return {void}
   * @public
   */
  static set f_FILE_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_FILE_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {HardwareIcons}
   * @public
   */
  static get f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {HardwareIcons} value
   * @return {void}
   * @public
   */
  static set f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {ImageIcons}
   * @public
   */
  static get f_IMAGE_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_IMAGE_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {ImageIcons} value
   * @return {void}
   * @public
   */
  static set f_IMAGE_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_IMAGE_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {MapsIcons}
   * @public
   */
  static get f_MAPS_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_MAPS_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {MapsIcons} value
   * @return {void}
   * @public
   */
  static set f_MAPS_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_MAPS_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {NavigationIcons}
   * @public
   */
  static get f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {NavigationIcons} value
   * @return {void}
   * @public
   */
  static set f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {NotificationIcons}
   * @public
   */
  static get f_NOTIFICATION_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_NOTIFICATION_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {NotificationIcons} value
   * @return {void}
   * @public
   */
  static set f_NOTIFICATION_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_NOTIFICATION_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {PlacesIcons}
   * @public
   */
  static get f_PLACES_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_PLACES_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {PlacesIcons} value
   * @return {void}
   * @public
   */
  static set f_PLACES_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_PLACES_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {SocialIcons}
   * @public
   */
  static get f_SOCIAL_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_SOCIAL_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {SocialIcons} value
   * @return {void}
   * @public
   */
  static set f_SOCIAL_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_SOCIAL_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @return {ToggleIcons}
   * @public
   */
  static get f_TOGGLE_ICONS__org_dominokit_domino_ui_icons_Icons() {
    return (Icons.$clinit(), Icons.$f_TOGGLE_ICONS__org_dominokit_domino_ui_icons_Icons);
  }
  
  /**
   * @param {ToggleIcons} value
   * @return {void}
   * @public
   */
  static set f_TOGGLE_ICONS__org_dominokit_domino_ui_icons_Icons(value) {
    (Icons.$clinit(), Icons.$f_TOGGLE_ICONS__org_dominokit_domino_ui_icons_Icons = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Icons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Icons);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Icons.$clinit = function() {};
    j_l_Object.$clinit();
    ActionIcons.$clinit();
    AlertIcons.$clinit();
    AvIcons.$clinit();
    CommunicationIcons.$clinit();
    ContentIcons.$clinit();
    DeviceIcons.$clinit();
    EditorIcons.$clinit();
    HardwareIcons.$clinit();
    FileIcons.$clinit();
    ImageIcons.$clinit();
    MapsIcons.$clinit();
    NavigationIcons.$clinit();
    NotificationIcons.$clinit();
    PlacesIcons.$clinit();
    SocialIcons.$clinit();
    ToggleIcons.$clinit();
    Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons = Icons.$create__();
    Icons.$f_ACTION_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_ALERT_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_AV_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_COMMUNICATION_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_CONTENT_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_DEVICE_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_EDITOR_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_FILE_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_IMAGE_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_MAPS_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_NOTIFICATION_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_PLACES_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_SOCIAL_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
    Icons.$f_TOGGLE_ICONS__org_dominokit_domino_ui_icons_Icons = Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;
  }
  
  
};

$Util.$setClassMetadata(Icons, $Util.$makeClassName('org.dominokit.domino.ui.icons.Icons'));


/** @private {Icons} */
Icons.$f_ALL__org_dominokit_domino_ui_icons_Icons;


/** @private {ActionIcons} */
Icons.$f_ACTION_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {AlertIcons} */
Icons.$f_ALERT_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {AvIcons} */
Icons.$f_AV_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {CommunicationIcons} */
Icons.$f_COMMUNICATION_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {ContentIcons} */
Icons.$f_CONTENT_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {DeviceIcons} */
Icons.$f_DEVICE_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {EditorIcons} */
Icons.$f_EDITOR_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {FileIcons} */
Icons.$f_FILE_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {HardwareIcons} */
Icons.$f_HARDWARE_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {ImageIcons} */
Icons.$f_IMAGE_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {MapsIcons} */
Icons.$f_MAPS_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {NavigationIcons} */
Icons.$f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {NotificationIcons} */
Icons.$f_NOTIFICATION_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {PlacesIcons} */
Icons.$f_PLACES_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {SocialIcons} */
Icons.$f_SOCIAL_ICONS__org_dominokit_domino_ui_icons_Icons;


/** @private {ToggleIcons} */
Icons.$f_TOGGLE_ICONS__org_dominokit_domino_ui_icons_Icons;


ActionIcons.$markImplementor(Icons);
AlertIcons.$markImplementor(Icons);
AvIcons.$markImplementor(Icons);
CommunicationIcons.$markImplementor(Icons);
ContentIcons.$markImplementor(Icons);
DeviceIcons.$markImplementor(Icons);
EditorIcons.$markImplementor(Icons);
HardwareIcons.$markImplementor(Icons);
FileIcons.$markImplementor(Icons);
ImageIcons.$markImplementor(Icons);
MapsIcons.$markImplementor(Icons);
NavigationIcons.$markImplementor(Icons);
NotificationIcons.$markImplementor(Icons);
PlacesIcons.$markImplementor(Icons);
SocialIcons.$markImplementor(Icons);
ToggleIcons.$markImplementor(Icons);


exports = Icons; 
//# sourceMappingURL=Icons.js.map