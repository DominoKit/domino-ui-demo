/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.DeviceIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.DeviceIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class DeviceIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_access_alarm__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_access_alarms__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_access_time__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_alarm__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airplanemode_active__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airplanemode_inactive__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_battery_alert__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_battery_charging_full__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_battery_full__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_battery_std__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_battery_unknown__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bluetooth__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bluetooth_connected__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bluetooth_disabled__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bluetooth_searching__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_auto__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_high__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_low__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_medium__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_data_usage__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_developer_mode__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_devices__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dvr__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gps_fixed__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gps_not_fixed__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gps_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_graphic_eq__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_location_disabled__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_location_searching__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_network_cell__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_network_wifi__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_nfc__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_screen_lock_landscape__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_screen_lock_portrait__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_screen_lock_rotation__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_screen_rotation__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sd_storage__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_settings_system_daydream__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_cellular_4_bar__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_cellular_connected_no_internet_4_bar__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_cellular_no_sim__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_cellular_null__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_cellular_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_wifi_4_bar__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_wifi_4_bar_lock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_signal_wifi_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_storage__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_usb__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wallpaper__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_widgets__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wifi_lock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wifi_tethering__() {
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_access_alarm__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("access_alarm");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_access_alarms__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("access_alarms");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_access_time__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("access_time");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_alarm__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("add_alarm");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airplanemode_active__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("airplanemode_active");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airplanemode_inactive__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("airplanemode_inactive");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_battery_alert__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("battery_alert");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_battery_charging_full__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("battery_charging_full");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_battery_full__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("battery_full");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_battery_std__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("battery_std");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_battery_unknown__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("battery_unknown");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bluetooth__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("bluetooth");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bluetooth_connected__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("bluetooth_connected");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bluetooth_disabled__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("bluetooth_disabled");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bluetooth_searching__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("bluetooth_searching");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_auto__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_auto");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_high__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_high");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_low__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_low");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_medium__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_medium");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_data_usage__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("data_usage");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_developer_mode__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("developer_mode");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_devices__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("devices");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dvr__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("dvr");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gps_fixed__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("gps_fixed");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gps_not_fixed__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("gps_not_fixed");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gps_off__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("gps_off");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_graphic_eq__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("graphic_eq");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_location_disabled__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("location_disabled");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_location_searching__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("location_searching");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_network_cell__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("network_cell");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_network_wifi__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("network_wifi");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_nfc__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("nfc");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_screen_lock_landscape__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("screen_lock_landscape");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_screen_lock_portrait__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("screen_lock_portrait");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_screen_lock_rotation__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("screen_lock_rotation");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_screen_rotation__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("screen_rotation");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sd_storage__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("sd_storage");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_settings_system_daydream__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("settings_system_daydream");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_cellular_4_bar__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_cellular_4_bar");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_cellular_connected_no_internet_4_bar__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_cellular_connected_no_internet_4_bar");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_cellular_no_sim__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_cellular_no_sim");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_cellular_null__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_cellular_null");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_cellular_off__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_cellular_off");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_wifi_4_bar__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_wifi_4_bar");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_wifi_4_bar_lock__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_wifi_4_bar_lock");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_signal_wifi_off__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("signal_wifi_off");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_storage__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("storage");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_usb__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("usb");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wallpaper__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("wallpaper");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_widgets__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("widgets");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wifi_lock__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("wifi_lock");
  }
  
  /**
   * @param {DeviceIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wifi_tethering__$default__org_dominokit_domino_ui_icons_DeviceIcons($thisArg) {
    DeviceIcons.$clinit();
    return Icon.m_create__java_lang_String("wifi_tethering");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_DeviceIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_DeviceIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_DeviceIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DeviceIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DeviceIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.DeviceIcons'));


DeviceIcons.$markImplementor(/** @type {Function} */ (DeviceIcons));


exports = DeviceIcons; 
//# sourceMappingURL=DeviceIcons.js.map