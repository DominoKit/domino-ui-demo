/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.Icons.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.icons.Icons');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ActionIcons = goog.require('org.dominokit.domino.ui.icons.ActionIcons');
const _AlertIcons = goog.require('org.dominokit.domino.ui.icons.AlertIcons');
const _AvIcons = goog.require('org.dominokit.domino.ui.icons.AvIcons');
const _CommunicationIcons = goog.require('org.dominokit.domino.ui.icons.CommunicationIcons');
const _ContentIcons = goog.require('org.dominokit.domino.ui.icons.ContentIcons');
const _DeviceIcons = goog.require('org.dominokit.domino.ui.icons.DeviceIcons');
const _EditorIcons = goog.require('org.dominokit.domino.ui.icons.EditorIcons');
const _FileIcons = goog.require('org.dominokit.domino.ui.icons.FileIcons');
const _HardwareIcons = goog.require('org.dominokit.domino.ui.icons.HardwareIcons');
const _ImageIcons = goog.require('org.dominokit.domino.ui.icons.ImageIcons');
const _MapsIcons = goog.require('org.dominokit.domino.ui.icons.MapsIcons');
const _NavigationIcons = goog.require('org.dominokit.domino.ui.icons.NavigationIcons');
const _NotificationIcons = goog.require('org.dominokit.domino.ui.icons.NotificationIcons');
const _PlacesIcons = goog.require('org.dominokit.domino.ui.icons.PlacesIcons');
const _SocialIcons = goog.require('org.dominokit.domino.ui.icons.SocialIcons');
const _ToggleIcons = goog.require('org.dominokit.domino.ui.icons.ToggleIcons');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');


// Re-exports the implementation.
var Icons = goog.require('org.dominokit.domino.ui.icons.Icons$impl');
exports = Icons;
 