/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.AbstractTextBox.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.AbstractTextBox$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ValueBox = goog.require('org.dominokit.domino.ui.forms.ValueBox$impl');
const HasLength = goog.require('org.dominokit.domino.ui.utils.HasLength$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.ui.forms.AbstractTextBox.$LambdaAdaptor$18$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_T, C_E
 * @extends {ValueBox<C_T, C_E, ?string>}
 * @implements {HasLength<C_T>}
  */
class AbstractTextBox extends ValueBox {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_characterCountContainer__org_dominokit_domino_ui_forms_AbstractTextBox_;
    /** @public {number} */
    this.f_length__org_dominokit_domino_ui_forms_AbstractTextBox_ = 0;
  }
  
  /**
   * Initialization from constructor 'AbstractTextBox(String, String)'.
   * @param {?string} type
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_AbstractTextBox__java_lang_String__java_lang_String(type, label) {
    this.$ctor__org_dominokit_domino_ui_forms_ValueBox__java_lang_String__java_lang_String(type, label);
    this.$init__org_dominokit_domino_ui_forms_AbstractTextBox();
    this.m_addInputEvent___$p_org_dominokit_domino_ui_forms_AbstractTextBox();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addInputEvent___$p_org_dominokit_domino_ui_forms_AbstractTextBox() {
    /**@type {HTMLElement} */ (this.m_getInputElement__()).addEventListener("input", new $LambdaAdaptor$18(((/** Event */ evt) =>{
      this.m_updateCharacterCount___$p_org_dominokit_domino_ui_forms_AbstractTextBox();
    })));
  }
  
  /**
   * @override
   * @param {number} length
   * @return {C_T}
   * @public
   */
  m_setLength__int(length) {
    this.f_length__org_dominokit_domino_ui_forms_AbstractTextBox_ = length;
    if (length < 0 && this.m_getContainer__().contains(this.f_characterCountContainer__org_dominokit_domino_ui_forms_AbstractTextBox_)) {
      this.m_getContainer__().removeChild(this.f_characterCountContainer__org_dominokit_domino_ui_forms_AbstractTextBox_);
      /**@type {HTMLElement} */ (this.m_getInputElement__()).removeAttribute("maxlength");
    } else {
      this.m_getContainer__().appendChild(this.f_characterCountContainer__org_dominokit_domino_ui_forms_AbstractTextBox_);
      $Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__double(this.m_getInputElement__(), "maxlength", length);
      this.m_updateCharacterCount___$p_org_dominokit_domino_ui_forms_AbstractTextBox();
    }
    return /**@type {C_T} */ ($Casts.$to(this, AbstractTextBox));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updateCharacterCount___$p_org_dominokit_domino_ui_forms_AbstractTextBox() {
    this.f_characterCountContainer__org_dominokit_domino_ui_forms_AbstractTextBox_.textContent = j_l_String.m_length__java_lang_String(/**@type {?string} */ ($Casts.$to(this.m_getValue__(), j_l_String))) + "/" + this.f_length__org_dominokit_domino_ui_forms_AbstractTextBox_;
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_getLength__() {
    return this.f_length__org_dominokit_domino_ui_forms_AbstractTextBox_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return j_l_String.m_isEmpty__java_lang_String(/**@type {?string} */ ($Casts.$to(this.m_getValue__(), j_l_String)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_AbstractTextBox() {
    this.f_characterCountContainer__org_dominokit_domino_ui_forms_AbstractTextBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["help-info pull-right"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractTextBox;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractTextBox);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AbstractTextBox.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.ui.forms.AbstractTextBox.$LambdaAdaptor$18$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ValueBox.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AbstractTextBox, $Util.$makeClassName('org.dominokit.domino.ui.forms.AbstractTextBox'));


HasLength.$markImplementor(AbstractTextBox);


exports = AbstractTextBox; 
//# sourceMappingURL=AbstractTextBox.js.map