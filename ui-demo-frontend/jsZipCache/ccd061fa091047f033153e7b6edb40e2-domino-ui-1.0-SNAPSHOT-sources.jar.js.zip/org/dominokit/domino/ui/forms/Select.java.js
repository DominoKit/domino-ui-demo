/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.Select');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement');
const _Focusable = goog.require('org.dominokit.domino.ui.utils.Focusable');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLButtonElement_$Overlay = goog.require('elemental2.dom.HTMLButtonElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLabelElement_$Overlay = goog.require('elemental2.dom.HTMLLabelElement.$Overlay');
const _HTMLOptionElement_$Overlay = goog.require('elemental2.dom.HTMLOptionElement.$Overlay');
const _HTMLSelectElement_$Overlay = goog.require('elemental2.dom.HTMLSelectElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _KeyboardEvent_$Overlay = goog.require('elemental2.dom.KeyboardEvent.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Js = goog.require('jsinterop.base.Js');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$LambdaAdaptor$23 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$23');
const _$LambdaAdaptor$24 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$24');
const _$LambdaAdaptor$25 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$25');
const _$LambdaAdaptor$26 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$26');
const _$LambdaAdaptor$27 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$27');
const _$LambdaAdaptor$28 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$28');
const _$LambdaAdaptor$29 = goog.require('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$29');
const _NavigateOptionsKeyListener = goog.require('org.dominokit.domino.ui.forms.Select.NavigateOptionsKeyListener');
const _SelectElement = goog.require('org.dominokit.domino.ui.forms.Select.SelectElement');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _TextContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TextContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Select = goog.require('org.dominokit.domino.ui.forms.Select$impl');
exports = Select;
 