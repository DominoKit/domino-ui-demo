/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select$SelectionHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Select.SelectionHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');

let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');


/**
 * @implements {SelectionHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(SelectOption):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(SelectOption):void} */
    this.f_$$fn__org_dominokit_domino_ui_forms_Select_SelectionHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_forms_Select_SelectionHandler_$LambdaAdaptor__org_dominokit_domino_ui_forms_Select_SelectionHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(SelectOption):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select_SelectionHandler_$LambdaAdaptor__org_dominokit_domino_ui_forms_Select_SelectionHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_forms_Select_SelectionHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {SelectOption} arg0
   * @return {void}
   * @public
   */
  m_onSelection__org_dominokit_domino_ui_forms_SelectOption(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_forms_Select_SelectionHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.forms.Select$SelectionHandler$$LambdaAdaptor'));


SelectionHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Select$SelectionHandler$$LambdaAdaptor.js.map