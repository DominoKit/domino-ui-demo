/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.TextArea.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.TextArea$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractTextBox = goog.require('org.dominokit.domino.ui.forms.AbstractTextBox$impl');

let HeightUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTextAreaElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $LambdaAdaptor$31 = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea.$LambdaAdaptor$31$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let TextContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {AbstractTextBox<TextArea, HTMLTextAreaElement>}
  */
class TextArea extends AbstractTextBox {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {EventListener} */
    this.f_autosizeListener__org_dominokit_domino_ui_forms_TextArea_;
    /** @public {number} */
    this.f_rows__org_dominokit_domino_ui_forms_TextArea_ = 0;
  }
  
  /**
   * Factory method corresponding to constructor 'TextArea()'.
   * @return {!TextArea}
   * @public
   */
  static $create__() {
    TextArea.$clinit();
    let $instance = new TextArea();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextArea__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TextArea()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextArea__() {
    this.$ctor__org_dominokit_domino_ui_forms_TextArea__java_lang_String("");
  }
  
  /**
   * Factory method corresponding to constructor 'TextArea(String)'.
   * @param {?string} label
   * @return {!TextArea}
   * @public
   */
  static $create__java_lang_String(label) {
    TextArea.$clinit();
    let $instance = new TextArea();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextArea__java_lang_String(label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TextArea(String)'.
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextArea__java_lang_String(label) {
    this.$ctor__org_dominokit_domino_ui_forms_AbstractTextBox__java_lang_String__java_lang_String("", label);
    this.$init__org_dominokit_domino_ui_forms_TextArea();
    this.m_setRows__int(4);
  }
  
  /**
   * @return {TextArea}
   * @public
   */
  static m_create__() {
    TextArea.$clinit();
    return TextArea.$create__();
  }
  
  /**
   * @param {?string} label
   * @return {TextArea}
   * @public
   */
  static m_create__java_lang_String(label) {
    TextArea.$clinit();
    return TextArea.$create__java_lang_String(label);
  }
  
  /**
   * @override
   * @param {?string} type
   * @return {HTMLTextAreaElement}
   * @public
   */
  m_createInputElement__java_lang_String(type) {
    return /**@type {HTMLTextAreaElement} */ ($Casts.$to(/**@type {TextContentBuilder<HTMLTextAreaElement>} */ ($Casts.$to(Elements.m_textarea__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-control no-resize"], j_l_String))), TextContentBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @param {number} rows
   * @return {TextArea}
   * @public
   */
  m_setRows__int(rows) {
    this.f_rows__org_dominokit_domino_ui_forms_TextArea_ = rows;
    this.m_updateRows__int_$p_org_dominokit_domino_ui_forms_TextArea(rows);
    return this;
  }
  
  /**
   * @param {number} rows
   * @return {void}
   * @public
   */
  m_updateRows__int_$p_org_dominokit_domino_ui_forms_TextArea(rows) {
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.m_getInputElement__(), "rows", rows + "");
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_doSetValue__java_lang_String(value) {
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).value = value;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clearValue__() {
    this.m_setValue__java_lang_Object("");
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).value;
  }
  
  /**
   * @return {TextArea}
   * @public
   */
  m_autoSize__() {
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).addEventListener("input", this.f_autosizeListener__org_dominokit_domino_ui_forms_TextArea_);
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).style.overflow = "hidden";
    this.m_updateRows__int_$p_org_dominokit_domino_ui_forms_TextArea(1);
    return this;
  }
  
  /**
   * @return {TextArea}
   * @public
   */
  m_fixedSize__() {
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).removeEventListener("input", this.f_autosizeListener__org_dominokit_domino_ui_forms_TextArea_);
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).style.overflow = "";
    this.m_setRows__int(this.f_rows__org_dominokit_domino_ui_forms_TextArea_);
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_adjustHeight___$p_org_dominokit_domino_ui_forms_TextArea() {
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).style.height = HeightUnionType_$Overlay.m_of__java_lang_Object("auto");
    /**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).style.height = HeightUnionType_$Overlay.m_of__java_lang_Object(/**@type {HTMLTextAreaElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).scrollHeight + "px");
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return j_l_String.m_isEmpty__java_lang_String(this.m_getValue__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_doSetValue__java_lang_Object(arg0) {
    this.m_doSetValue__java_lang_String(/**@type {?string} */ ($Casts.$to(arg0, j_l_String)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_TextArea() {
    this.f_autosizeListener__org_dominokit_domino_ui_forms_TextArea_ = new $LambdaAdaptor$31(((/** Event */ evt) =>{
      this.m_adjustHeight___$p_org_dominokit_domino_ui_forms_TextArea();
    }));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TextArea;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TextArea);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TextArea.$clinit = function() {};
    HeightUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLTextAreaElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$31 = goog.module.get('org.dominokit.domino.ui.forms.TextArea.$LambdaAdaptor$31$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    TextContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    AbstractTextBox.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TextArea, $Util.$makeClassName('org.dominokit.domino.ui.forms.TextArea'));




exports = TextArea; 
//# sourceMappingURL=TextArea.js.map