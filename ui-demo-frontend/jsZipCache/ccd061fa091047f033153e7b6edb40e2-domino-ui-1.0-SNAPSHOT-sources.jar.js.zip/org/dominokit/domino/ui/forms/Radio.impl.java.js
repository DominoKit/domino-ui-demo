/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Radio.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Radio$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Checkable = goog.require('org.dominokit.domino.ui.utils.Checkable$impl');
const HasLabel = goog.require('org.dominokit.domino.ui.utils.HasLabel$impl');
const HasName = goog.require('org.dominokit.domino.ui.utils.HasName$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLInputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Radio.$LambdaAdaptor$22$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let CheckHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasName<Radio>}
 * @implements {HasValue<?string>}
 * @implements {HasLabel<Radio>}
 * @implements {Switchable<Radio>}
 * @implements {Checkable<Radio>}
  */
class Radio extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_container__org_dominokit_domino_ui_forms_Radio_;
    /** @public {HTMLLabelElement} */
    this.f_labelElement__org_dominokit_domino_ui_forms_Radio_;
    /** @public {HTMLInputElement} */
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_;
    /** @public {List<CheckHandler>} */
    this.f_checkHandlers__org_dominokit_domino_ui_forms_Radio_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_forms_Radio_;
  }
  
  /**
   * Factory method corresponding to constructor 'Radio(String, String)'.
   * @param {?string} value
   * @param {?string} label
   * @return {!Radio}
   * @public
   */
  static $create__java_lang_String__java_lang_String(value, label) {
    Radio.$clinit();
    let $instance = new Radio();
    $instance.$ctor__org_dominokit_domino_ui_forms_Radio__java_lang_String__java_lang_String(value, label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Radio(String, String)'.
   * @param {?string} value
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Radio__java_lang_String__java_lang_String(value, label) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_forms_Radio();
    this.f_container__org_dominokit_domino_ui_forms_Radio_.appendChild(this.f_inputElement__org_dominokit_domino_ui_forms_Radio_);
    this.f_container__org_dominokit_domino_ui_forms_Radio_.appendChild(this.f_labelElement__org_dominokit_domino_ui_forms_Radio_);
    this.m_setLabel__java_lang_String(label);
    this.m_setValue__java_lang_String(value);
    this.f_container__org_dominokit_domino_ui_forms_Radio_.addEventListener("click", new $LambdaAdaptor$21(((/** Event */ evt) =>{
      if (this.m_isEnabled__() && !this.m_isChecked__()) {
        this.m_check__();
      }
    })));
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.addEventListener("change", new $LambdaAdaptor$22(((/** Event */ evt$1$) =>{
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_Radio();
    })));
  }
  
  /**
   * Factory method corresponding to constructor 'Radio(String)'.
   * @param {?string} value
   * @return {!Radio}
   * @public
   */
  static $create__java_lang_String(value) {
    Radio.$clinit();
    let $instance = new Radio();
    $instance.$ctor__org_dominokit_domino_ui_forms_Radio__java_lang_String(value);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Radio(String)'.
   * @param {?string} value
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Radio__java_lang_String(value) {
    this.$ctor__org_dominokit_domino_ui_forms_Radio__java_lang_String__java_lang_String(value, value);
  }
  
  /**
   * @param {?string} value
   * @param {?string} label
   * @return {Radio}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(value, label) {
    Radio.$clinit();
    return Radio.$create__java_lang_String__java_lang_String(value, label);
  }
  
  /**
   * @param {?string} value
   * @return {Radio}
   * @public
   */
  static m_create__java_lang_String(value) {
    Radio.$clinit();
    return Radio.$create__java_lang_String(value);
  }
  
  /**
   * @override
   * @return {Radio}
   * @public
   */
  m_check__() {
    return this.m_check__boolean(false);
  }
  
  /**
   * @override
   * @return {Radio}
   * @public
   */
  m_uncheck__() {
    return this.m_uncheck__boolean(false);
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {Radio}
   * @public
   */
  m_check__boolean(silent) {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.checked = true;
    if (!silent) {
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_Radio();
    }
    return this;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {Radio}
   * @public
   */
  m_uncheck__boolean(silent) {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.checked = false;
    if (!silent) {
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_Radio();
    }
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onCheck___$p_org_dominokit_domino_ui_forms_Radio() {
    for (let $iterator = this.f_checkHandlers__org_dominokit_domino_ui_forms_Radio_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let checkHandler = /**@type {CheckHandler} */ ($Casts.$to($iterator.m_next__(), CheckHandler));
      checkHandler.m_onCheck__boolean(this.m_isChecked__());
    }
  }
  
  /**
   * @override
   * @param {CheckHandler} checkHandler
   * @return {Radio}
   * @public
   */
  m_addCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(checkHandler) {
    this.f_checkHandlers__org_dominokit_domino_ui_forms_Radio_.add(checkHandler);
    return this;
  }
  
  /**
   * @override
   * @param {CheckHandler} checkHandler
   * @return {Radio}
   * @public
   */
  m_removeCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(checkHandler) {
    if (!$Equality.$same(checkHandler, null)) {
      this.f_checkHandlers__org_dominokit_domino_ui_forms_Radio_.remove(checkHandler);
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isChecked__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.checked;
  }
  
  /**
   * @return {Radio}
   * @public
   */
  m_withGap__() {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.classList.add("with-gap");
    return this;
  }
  
  /**
   * @return {Radio}
   * @public
   */
  m_withoutGap__() {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.classList.remove("with-gap");
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {Radio}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (!$Equality.$same(this.f_color__org_dominokit_domino_ui_forms_Radio_, null)) {
      this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.classList.remove("radio-" + j_l_String.m_valueOf__java_lang_Object(this.f_color__org_dominokit_domino_ui_forms_Radio_.m_getStyle__()));
    }
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.classList.add("radio-" + j_l_String.m_valueOf__java_lang_Object(color.m_getStyle__()));
    this.f_color__org_dominokit_domino_ui_forms_Radio_ = color;
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_container__org_dominokit_domino_ui_forms_Radio_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.name;
  }
  
  /**
   * @override
   * @param {?string} name
   * @return {Radio}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.name = name;
    return this;
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_String(value) {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.value = value;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.value;
  }
  
  /**
   * @override
   * @param {?string} label
   * @return {Radio}
   * @public
   */
  m_setLabel__java_lang_String(label) {
    this.f_labelElement__org_dominokit_domino_ui_forms_Radio_.textContent = label;
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getLabel__() {
    return this.f_labelElement__org_dominokit_domino_ui_forms_Radio_.textContent;
  }
  
  /**
   * @override
   * @return {Radio}
   * @public
   */
  m_enable__() {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.disabled = true;
    return this;
  }
  
  /**
   * @override
   * @return {Radio}
   * @public
   */
  m_disable__() {
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.disabled = true;
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return !this.f_inputElement__org_dominokit_domino_ui_forms_Radio_.disabled;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_lang_String(/**@type {?string} */ ($Casts.$to(arg0, j_l_String)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_Radio() {
    this.f_container__org_dominokit_domino_ui_forms_Radio_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_labelElement__org_dominokit_domino_ui_forms_Radio_ = /**@type {HTMLLabelElement} */ ($Casts.$to(Elements.m_label__().m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_inputElement__org_dominokit_domino_ui_forms_Radio_ = /**@type {HTMLInputElement} */ ($Casts.$to(Elements.m_input__java_lang_String("radio").m_asElement__(), HTMLInputElement_$Overlay));
    this.f_checkHandlers__org_dominokit_domino_ui_forms_Radio_ = /**@type {!ArrayList<CheckHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Radio;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Radio);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Radio.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLInputElement_$Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.ui.forms.Radio.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.domino.ui.forms.Radio.$LambdaAdaptor$22$impl');
    CheckHandler = goog.module.get('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Radio, $Util.$makeClassName('org.dominokit.domino.ui.forms.Radio'));


IsElement.$markImplementor(Radio);
HasName.$markImplementor(Radio);
HasValue.$markImplementor(Radio);
HasLabel.$markImplementor(Radio);
Switchable.$markImplementor(Radio);
Checkable.$markImplementor(Radio);


exports = Radio; 
//# sourceMappingURL=Radio.js.map