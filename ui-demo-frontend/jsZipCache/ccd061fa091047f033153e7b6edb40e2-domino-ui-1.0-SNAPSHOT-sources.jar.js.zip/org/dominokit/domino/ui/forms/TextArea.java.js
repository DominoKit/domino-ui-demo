/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.TextArea.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.TextArea');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractTextBox = goog.require('org.dominokit.domino.ui.forms.AbstractTextBox');
const _HeightUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.HeightUnionType.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLTextAreaElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _$LambdaAdaptor$31 = goog.require('org.dominokit.domino.ui.forms.TextArea.$LambdaAdaptor$31');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _TextContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TextContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TextArea = goog.require('org.dominokit.domino.ui.forms.TextArea$impl');
exports = TextArea;
 