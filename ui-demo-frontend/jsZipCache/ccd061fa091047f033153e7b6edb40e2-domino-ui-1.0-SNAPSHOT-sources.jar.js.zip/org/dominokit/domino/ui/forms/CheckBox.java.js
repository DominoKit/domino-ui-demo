/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.CheckBox.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.CheckBox');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement');
const _Checkable = goog.require('org.dominokit.domino.ui.utils.Checkable');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLInputElement_$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _HTMLLabelElement_$Overlay = goog.require('elemental2.dom.HTMLLabelElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.domino.ui.forms.CheckBox.$LambdaAdaptor$19');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.domino.ui.forms.CheckBox.$LambdaAdaptor$20');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _CheckHandler = goog.require('org.dominokit.domino.ui.utils.Checkable.CheckHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CheckBox = goog.require('org.dominokit.domino.ui.forms.CheckBox$impl');
exports = CheckBox;
 