/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.CheckBox.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.CheckBox$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement$impl');
const Checkable = goog.require('org.dominokit.domino.ui.utils.Checkable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLInputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox.$LambdaAdaptor$20$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let CheckHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BasicFormElement<CheckBox, ?boolean>}
 * @implements {IsElement<HTMLElement>}
 * @implements {Checkable<CheckBox>}
  */
class CheckBox extends BasicFormElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_container__org_dominokit_domino_ui_forms_CheckBox_;
    /** @public {HTMLInputElement} */
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_;
    /** @public {HTMLLabelElement} */
    this.f_labelElement__org_dominokit_domino_ui_forms_CheckBox_;
    /** @public {List<CheckHandler>} */
    this.f_checkHandlers__org_dominokit_domino_ui_forms_CheckBox_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_forms_CheckBox_;
    /** @public {CheckHandler} */
    this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_;
  }
  
  /**
   * Factory method corresponding to constructor 'CheckBox()'.
   * @return {!CheckBox}
   * @public
   */
  static $create__() {
    CheckBox.$clinit();
    let $instance = new CheckBox();
    $instance.$ctor__org_dominokit_domino_ui_forms_CheckBox__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CheckBox()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_CheckBox__() {
    this.$ctor__org_dominokit_domino_ui_forms_CheckBox__java_lang_String("");
  }
  
  /**
   * Factory method corresponding to constructor 'CheckBox(String)'.
   * @param {?string} label
   * @return {!CheckBox}
   * @public
   */
  static $create__java_lang_String(label) {
    CheckBox.$clinit();
    let $instance = new CheckBox();
    $instance.$ctor__org_dominokit_domino_ui_forms_CheckBox__java_lang_String(label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CheckBox(String)'.
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_CheckBox__java_lang_String(label) {
    this.$ctor__org_dominokit_domino_ui_forms_BasicFormElement__();
    this.$init__org_dominokit_domino_ui_forms_CheckBox();
    this.m_setLabel__java_lang_String(label);
    this.f_container__org_dominokit_domino_ui_forms_CheckBox_.appendChild(this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_);
    this.f_container__org_dominokit_domino_ui_forms_CheckBox_.appendChild(this.f_labelElement__org_dominokit_domino_ui_forms_CheckBox_);
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.addEventListener("change", new $LambdaAdaptor$19(((/** Event */ evt) =>{
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_CheckBox();
    })));
    this.f_labelElement__org_dominokit_domino_ui_forms_CheckBox_.addEventListener("click", new $LambdaAdaptor$20(((/** Event */ evt$1$) =>{
      if (this.m_isEnabled__()) {
        this.m_toggle__();
      }
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onCheck___$p_org_dominokit_domino_ui_forms_CheckBox() {
    this.f_checkHandlers__org_dominokit_domino_ui_forms_CheckBox_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** CheckHandler */ checkHandler) =>{
      checkHandler.m_onCheck__boolean(this.m_isChecked__());
    })));
  }
  
  /**
   * @param {?string} label
   * @return {CheckBox}
   * @public
   */
  static m_create__java_lang_String(label) {
    CheckBox.$clinit();
    return CheckBox.$create__java_lang_String(label);
  }
  
  /**
   * @return {CheckBox}
   * @public
   */
  static m_create__() {
    CheckBox.$clinit();
    return CheckBox.$create__();
  }
  
  /**
   * @return {CheckBox}
   * @public
   */
  m_toggle__() {
    if (this.m_isChecked__()) {
      this.m_uncheck__();
    } else {
      this.m_check__();
    }
    return this;
  }
  
  /**
   * @override
   * @return {CheckBox}
   * @public
   */
  m_check__() {
    return this.m_check__boolean(false);
  }
  
  /**
   * @override
   * @return {CheckBox}
   * @public
   */
  m_uncheck__() {
    return this.m_uncheck__boolean(false);
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {CheckBox}
   * @public
   */
  m_check__boolean(silent) {
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.checked = true;
    if (!silent) {
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_CheckBox();
    }
    return this;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {CheckBox}
   * @public
   */
  m_uncheck__boolean(silent) {
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.checked = false;
    if (!silent) {
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_CheckBox();
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isChecked__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.checked;
  }
  
  /**
   * @override
   * @param {CheckHandler} handler
   * @return {CheckBox}
   * @public
   */
  m_addCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(handler) {
    this.f_checkHandlers__org_dominokit_domino_ui_forms_CheckBox_.add(handler);
    return this;
  }
  
  /**
   * @return {CheckBox}
   * @public
   */
  m_filledIn__() {
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.classList.add("filled-in");
    return this;
  }
  
  /**
   * @return {CheckBox}
   * @public
   */
  m_filledOut__() {
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.classList.remove("filled-in");
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {CheckBox}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (!$Equality.$same(this.f_color__org_dominokit_domino_ui_forms_CheckBox_, null)) {
      this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.classList.remove("chk-" + j_l_String.m_valueOf__java_lang_Object(this.f_color__org_dominokit_domino_ui_forms_CheckBox_.m_getStyle__()));
    }
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_.classList.add("chk-" + j_l_String.m_valueOf__java_lang_Object(color.m_getStyle__()));
    this.f_color__org_dominokit_domino_ui_forms_CheckBox_ = color;
    return this;
  }
  
  /**
   * @param {?boolean} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Boolean(value) {
    if (!$Equality.$same(value, null) && Boolean.m_booleanValue__java_lang_Boolean(value)) {
      this.m_check__();
    } else {
      this.m_uncheck__();
    }
  }
  
  /**
   * @override
   * @return {?boolean}
   * @public
   */
  m_getValue__() {
    return this.m_isChecked__();
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return !this.m_isChecked__();
  }
  
  /**
   * @override
   * @return {CheckBox}
   * @public
   */
  m_clear__() {
    this.m_setValue__java_lang_Boolean(false);
    return this;
  }
  
  /**
   * @override
   * @param {CheckHandler} checkHandler
   * @return {CheckBox}
   * @public
   */
  m_removeCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(checkHandler) {
    if (!$Equality.$same(checkHandler, null)) {
      this.f_checkHandlers__org_dominokit_domino_ui_forms_CheckBox_.remove(checkHandler);
    }
    return this;
  }
  
  /**
   * @override
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getContainer__() {
    return this.f_container__org_dominokit_domino_ui_forms_CheckBox_;
  }
  
  /**
   * @override
   * @return {HTMLLabelElement}
   * @public
   */
  m_getLabelElement__() {
    return this.f_labelElement__org_dominokit_domino_ui_forms_CheckBox_;
  }
  
  /**
   * @override
   * @param {boolean} autoValidation
   * @return {CheckBox}
   * @public
   */
  m_setAutoValidation__boolean(autoValidation) {
    if (autoValidation) {
      if (Objects.m_isNull__java_lang_Object(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_)) {
        this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_ = CheckHandler.$adapt(((/** boolean */ checked) =>{
          this.m_validate__();
        }));
        this.m_addCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_);
      }
    } else {
      this.m_removeCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_);
      this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_ = null;
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isAutoValidation__() {
    return Objects.m_nonNull__java_lang_Object(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_CheckBox_);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_lang_Boolean(/**@type {?boolean} */ ($Casts.$to(arg0, Boolean)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_CheckBox() {
    this.f_container__org_dominokit_domino_ui_forms_CheckBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_inputElement__org_dominokit_domino_ui_forms_CheckBox_ = /**@type {HTMLInputElement} */ ($Casts.$to(Elements.m_input__java_lang_String("checkbox").m_asElement__(), HTMLInputElement_$Overlay));
    this.f_labelElement__org_dominokit_domino_ui_forms_CheckBox_ = /**@type {HTMLLabelElement} */ ($Casts.$to(Elements.m_label__().m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_checkHandlers__org_dominokit_domino_ui_forms_CheckBox_ = /**@type {!ArrayList<CheckHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CheckBox;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CheckBox);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CheckBox.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLInputElement_$Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.ui.forms.CheckBox.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.ui.forms.CheckBox.$LambdaAdaptor$20$impl');
    CheckHandler = goog.module.get('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BasicFormElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CheckBox, $Util.$makeClassName('org.dominokit.domino.ui.forms.CheckBox'));


IsElement.$markImplementor(CheckBox);
Checkable.$markImplementor(CheckBox);


exports = CheckBox; 
//# sourceMappingURL=CheckBox.js.map