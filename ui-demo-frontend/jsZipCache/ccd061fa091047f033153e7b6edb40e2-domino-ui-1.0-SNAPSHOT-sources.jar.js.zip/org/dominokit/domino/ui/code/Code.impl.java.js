/**
 * @fileoverview transpiled from org.dominokit.domino.ui.code.Code.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.code.Code$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLPreElement.$Overlay$impl');
let Block = goog.forwardDeclare('org.dominokit.domino.ui.code.Code.Block$impl');
let Statement = goog.forwardDeclare('org.dominokit.domino.ui.code.Code.Statement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Code extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Code()'.
   * @return {!Code}
   * @public
   */
  static $create__() {
    Code.$clinit();
    let $instance = new Code();
    $instance.$ctor__org_dominokit_domino_ui_code_Code__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Code()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_code_Code__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} code
   * @return {Block}
   * @public
   */
  static m_block__java_lang_String(code) {
    Code.$clinit();
    return Block.$create__elemental2_dom_HTMLPreElement(/**@type {HTMLPreElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLPreElement>} */ ($Casts.$to(Elements.m_pre__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_code__().m_style__java_lang_String(Code.f_CODE_STYLE__org_dominokit_domino_ui_code_Code_), HtmlContentBuilder)).m_textContent__java_lang_String(code), IsElement))), HtmlContentBuilder)).m_asElement__(), $Overlay)));
  }
  
  /**
   * @return {Block}
   * @public
   */
  static m_block__() {
    Code.$clinit();
    return Block.$create__elemental2_dom_HTMLPreElement(/**@type {HTMLPreElement} */ ($Casts.$to(Elements.m_pre__().m_asElement__(), $Overlay)));
  }
  
  /**
   * @param {?string} code
   * @return {Statement}
   * @public
   */
  static m_statement__java_lang_String(code) {
    Code.$clinit();
    return Statement.$create__elemental2_dom_HTMLElement(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_code__().m_style__java_lang_String(Code.f_CODE_STYLE__org_dominokit_domino_ui_code_Code_), HtmlContentBuilder)).m_textContent__java_lang_String(code), HtmlContentBuilder)).m_asElement__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Code;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Code);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Code.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLPreElement.$Overlay$impl');
    Block = goog.module.get('org.dominokit.domino.ui.code.Code.Block$impl');
    Statement = goog.module.get('org.dominokit.domino.ui.code.Code.Statement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Code, $Util.$makeClassName('org.dominokit.domino.ui.code.Code'));


/** @public {?string} @const */
Code.f_CODE_STYLE__org_dominokit_domino_ui_code_Code_ = "overflow-x: scroll; white-space: pre;";




exports = Code; 
//# sourceMappingURL=Code.js.map