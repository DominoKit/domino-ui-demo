/**
 * @fileoverview transpiled from org.dominokit.domino.ui.Typography.Paragraph.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.Typography.Paragraph');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph$impl');
exports = Paragraph;
 