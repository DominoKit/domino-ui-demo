/**
 * @fileoverview transpiled from org.dominokit.domino.ui.Typography.Paragraph.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.Typography.Paragraph$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLParagraphElement>}
  */
class Paragraph extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLParagraphElement} */
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_;
    /** @public {Color} */
    this.f_colorStyle__org_dominokit_domino_ui_Typography_Paragraph_;
    /** @public {?string} */
    this.f_alignment__org_dominokit_domino_ui_Typography_Paragraph_;
  }
  
  /**
   * Factory method corresponding to constructor 'Paragraph()'.
   * @return {!Paragraph}
   * @public
   */
  static $create__() {
    Paragraph.$clinit();
    let $instance = new Paragraph();
    $instance.$ctor__org_dominokit_domino_ui_Typography_Paragraph__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Paragraph()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_Typography_Paragraph__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_Typography_Paragraph();
  }
  
  /**
   * Factory method corresponding to constructor 'Paragraph(String)'.
   * @param {?string} text
   * @return {!Paragraph}
   * @public
   */
  static $create__java_lang_String(text) {
    Paragraph.$clinit();
    let $instance = new Paragraph();
    $instance.$ctor__org_dominokit_domino_ui_Typography_Paragraph__java_lang_String(text);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Paragraph(String)'.
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_Typography_Paragraph__java_lang_String(text) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_Typography_Paragraph();
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.textContent = text;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  static m_create__() {
    Paragraph.$clinit();
    return Paragraph.$create__();
  }
  
  /**
   * @param {?string} text
   * @return {Paragraph}
   * @public
   */
  static m_create__java_lang_String(text) {
    Paragraph.$clinit();
    return Paragraph.$create__java_lang_String(text);
  }
  
  /**
   * @param {?string} text
   * @return {Paragraph}
   * @public
   */
  m_setText__java_lang_String(text) {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.textContent = text;
    return this;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_lead__() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(Styles.f_LEAD__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {Paragraph}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_colorStyle__org_dominokit_domino_ui_Typography_Paragraph_)) {
      this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(color.m_getStyle__());
    }
    this.f_colorStyle__org_dominokit_domino_ui_Typography_Paragraph_ = color;
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(this.f_colorStyle__org_dominokit_domino_ui_Typography_Paragraph_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {Paragraph}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.appendChild(content);
    return this;
  }
  
  /**
   * @override
   * @return {HTMLParagraphElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_Typography_Paragraph_;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_bold__() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(Styles.f_font_bold__org_dominokit_domino_ui_style_Styles);
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(Styles.f_font_bold__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_italic__() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(Styles.f_font_italic__org_dominokit_domino_ui_style_Styles);
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(Styles.f_font_italic__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_underLine__() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(Styles.f_font_under_line__org_dominokit_domino_ui_style_Styles);
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(Styles.f_font_under_line__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_overLine__() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(Styles.f_font_over_line__org_dominokit_domino_ui_style_Styles);
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(Styles.f_font_over_line__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_lineThrough__() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(Styles.f_font_line_through__org_dominokit_domino_ui_style_Styles);
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(Styles.f_font_line_through__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_alignLeft__() {
    return this.m_align__java_lang_String_$p_org_dominokit_domino_ui_Typography_Paragraph(Styles.f_align_left__org_dominokit_domino_ui_style_Styles);
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_alignRight__() {
    return this.m_align__java_lang_String_$p_org_dominokit_domino_ui_Typography_Paragraph(Styles.f_align_right__org_dominokit_domino_ui_style_Styles);
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_alignCenter__() {
    return this.m_align__java_lang_String_$p_org_dominokit_domino_ui_Typography_Paragraph(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
  }
  
  /**
   * @return {Paragraph}
   * @public
   */
  m_alignJustify__() {
    return this.m_align__java_lang_String_$p_org_dominokit_domino_ui_Typography_Paragraph(Styles.f_align_justify__org_dominokit_domino_ui_style_Styles);
  }
  
  /**
   * @param {?string} alignment
   * @return {Paragraph}
   * @public
   */
  m_align__java_lang_String_$p_org_dominokit_domino_ui_Typography_Paragraph(alignment) {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.remove(this.f_alignment__org_dominokit_domino_ui_Typography_Paragraph_);
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_.classList.add(alignment);
    this.f_alignment__org_dominokit_domino_ui_Typography_Paragraph_ = alignment;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_Typography_Paragraph() {
    this.f_element__org_dominokit_domino_ui_Typography_Paragraph_ = /**@type {HTMLParagraphElement} */ ($Casts.$to(Elements.m_p__().m_asElement__(), $Overlay));
    this.f_alignment__org_dominokit_domino_ui_Typography_Paragraph_ = Styles.f_align_left__org_dominokit_domino_ui_style_Styles;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Paragraph;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Paragraph);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Paragraph.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Paragraph, $Util.$makeClassName('org.dominokit.domino.ui.Typography.Paragraph'));


IsElement.$markImplementor(Paragraph);


exports = Paragraph; 
//# sourceMappingURL=Paragraph.js.map