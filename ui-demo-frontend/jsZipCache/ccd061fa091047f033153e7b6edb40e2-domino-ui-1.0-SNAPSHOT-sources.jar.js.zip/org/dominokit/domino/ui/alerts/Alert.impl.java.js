/**
 * @fileoverview transpiled from org.dominokit.domino.ui.alerts.Alert.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.alerts.Alert$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLButtonElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.ui.alerts.Alert.$LambdaAdaptor$1$impl');
let AlertType = goog.forwardDeclare('org.dominokit.domino.ui.alerts.Alert.AlertType$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasBackground<Alert>}
  */
class Alert extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_alerts_Alert_;
    /** @public {boolean} */
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = false;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_alerts_Alert_;
    /** @public {HTMLButtonElement} */
    this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_;
  }
  
  /**
   * Factory method corresponding to constructor 'Alert()'.
   * @return {!Alert}
   * @public
   */
  static $create__() {
    Alert.$clinit();
    let $instance = new Alert();
    $instance.$ctor__org_dominokit_domino_ui_alerts_Alert__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Alert()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_alerts_Alert__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_alerts_Alert();
  }
  
  /**
   * @param {?string} style
   * @return {Alert}
   * @public
   */
  static m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(style) {
    Alert.$clinit();
    let alert = Alert.m_create__();
    alert.f_element__org_dominokit_domino_ui_alerts_Alert_.classList.add(style);
    alert.f_style__org_dominokit_domino_ui_alerts_Alert_ = style;
    return alert;
  }
  
  /**
   * @param {Color} background
   * @return {Alert}
   * @public
   */
  static m_create__org_dominokit_domino_ui_style_Color(background) {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(background.m_getBackground__());
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_create__() {
    Alert.$clinit();
    let alert = Alert.$create__();
    alert.f_closeButton__org_dominokit_domino_ui_alerts_Alert_.addEventListener("click", new $LambdaAdaptor$1(((/** Event */ e) =>{
      alert.m_asElement__().remove();
    })));
    return alert;
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_success__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_info__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_warning__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_error__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Alert}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_style__org_dominokit_domino_ui_alerts_Alert_)) {
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.classList.remove(this.f_style__org_dominokit_domino_ui_alerts_Alert_);
    }
    this.f_style__org_dominokit_domino_ui_alerts_Alert_ = background.m_getBackground__();
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.classList.add(this.f_style__org_dominokit_domino_ui_alerts_Alert_);
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Alert}
   * @public
   */
  m_appendStrong__java_lang_String(text) {
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_strong__().m_textContent__java_lang_String(text), HtmlContentBuilder)).m_asElement__());
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Alert}
   * @public
   */
  m_appendText__java_lang_String(text) {
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.appendChild(new Text(text));
    return this;
  }
  
  /**
   * @param {HTMLAnchorElement} anchorElement
   * @return {Alert}
   * @public
   */
  m_appendLink__elemental2_dom_HTMLAnchorElement(anchorElement) {
    if (Objects.m_nonNull__java_lang_Object(anchorElement)) {
      anchorElement.classList.add("alert-link");
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.appendChild(anchorElement);
    }
    return this;
  }
  
  /**
   * @return {Alert}
   * @public
   */
  m_dismissible__() {
    if (!this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_) {
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.classList.add("alert-dismissible");
      if (this.f_element__org_dominokit_domino_ui_alerts_Alert_.childElementCount > 0) {
        this.f_element__org_dominokit_domino_ui_alerts_Alert_.insertBefore(this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_, this.f_element__org_dominokit_domino_ui_alerts_Alert_.firstChild);
      } else {
        this.f_element__org_dominokit_domino_ui_alerts_Alert_.appendChild(this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_);
      }
    }
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = true;
    return this;
  }
  
  /**
   * @return {Alert}
   * @public
   */
  m_unDismissible__() {
    if (this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_) {
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.classList.remove("alert-dismissible");
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.removeChild(this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_);
    }
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = false;
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isDismissible__() {
    return this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_alerts_Alert_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_alerts_Alert() {
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = false;
    this.f_element__org_dominokit_domino_ui_alerts_Alert_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["alert"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_ = /**@type {HTMLButtonElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(Elements.m_button__().m_attr__java_lang_String__java_lang_String("type", "button"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["close"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("aria-label", "Close"), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_attr__java_lang_String__java_lang_String("aria-hidden", "true"), HtmlContentBuilder)).m_textContent__java_lang_String("\u00D7"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_asElement__(), HTMLButtonElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Alert;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Alert);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Alert.$clinit = function() {};
    HTMLButtonElement_$Overlay = goog.module.get('elemental2.dom.HTMLButtonElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.ui.alerts.Alert.$LambdaAdaptor$1$impl');
    AlertType = goog.module.get('org.dominokit.domino.ui.alerts.Alert.AlertType$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Alert, $Util.$makeClassName('org.dominokit.domino.ui.alerts.Alert'));


IsElement.$markImplementor(Alert);
HasBackground.$markImplementor(Alert);


exports = Alert; 
//# sourceMappingURL=Alert.js.map