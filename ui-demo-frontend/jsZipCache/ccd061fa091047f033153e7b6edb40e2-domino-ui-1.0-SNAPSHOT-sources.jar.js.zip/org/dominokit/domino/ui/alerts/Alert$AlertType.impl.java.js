/**
 * @fileoverview transpiled from org.dominokit.domino.ui.alerts.Alert$AlertType.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.alerts.Alert.AlertType$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<AlertType>}
  */
class AlertType extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_;
  }
  
  /**
   * Factory method corresponding to constructor 'AlertType(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} typeStyle
   * @return {!AlertType}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, typeStyle) {
    let $instance = new AlertType();
    $instance.$ctor__org_dominokit_domino_ui_alerts_Alert_AlertType__java_lang_String__int__java_lang_String($name, $ordinal, typeStyle);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AlertType(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} typeStyle
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_alerts_Alert_AlertType__java_lang_String__int__java_lang_String($name, $ordinal, typeStyle) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_ = typeStyle;
  }
  
  /**
   * @param {string} name
   * @return {!AlertType}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    AlertType.$clinit();
    if ($Equality.$same(AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_, null)) {
      AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_ = $Enums.createMapFromValues(AlertType.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {!Array<!AlertType>}
   * @public
   */
  static m_values__() {
    AlertType.$clinit();
    return /**@type {!Array<AlertType>} */ ($Arrays.$init([AlertType.$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType, AlertType.$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType, AlertType.$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType, AlertType.$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType], AlertType));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {AlertType} */ ($Casts.$to(arg0, AlertType)));
  }
  
  /**
   * @return {!AlertType}
   * @public
   */
  static get f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType() {
    return (AlertType.$clinit(), AlertType.$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType);
  }
  
  /**
   * @param {!AlertType} value
   * @return {void}
   * @public
   */
  static set f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType(value) {
    (AlertType.$clinit(), AlertType.$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType = value);
  }
  
  /**
   * @return {!AlertType}
   * @public
   */
  static get f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType() {
    return (AlertType.$clinit(), AlertType.$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType);
  }
  
  /**
   * @param {!AlertType} value
   * @return {void}
   * @public
   */
  static set f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType(value) {
    (AlertType.$clinit(), AlertType.$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType = value);
  }
  
  /**
   * @return {!AlertType}
   * @public
   */
  static get f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType() {
    return (AlertType.$clinit(), AlertType.$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType);
  }
  
  /**
   * @param {!AlertType} value
   * @return {void}
   * @public
   */
  static set f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType(value) {
    (AlertType.$clinit(), AlertType.$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType = value);
  }
  
  /**
   * @return {!AlertType}
   * @public
   */
  static get f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType() {
    return (AlertType.$clinit(), AlertType.$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType);
  }
  
  /**
   * @param {!AlertType} value
   * @return {void}
   * @public
   */
  static set f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType(value) {
    (AlertType.$clinit(), AlertType.$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType = value);
  }
  
  /**
   * @return {Map<?string, !AlertType>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_() {
    return (AlertType.$clinit(), AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @param {Map<?string, !AlertType>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_(value) {
    (AlertType.$clinit(), AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AlertType;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AlertType);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertType.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    AlertType.$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType = AlertType.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("SUCCESS"), AlertType.$ordinal$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType, "alert-success");
    AlertType.$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType = AlertType.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("INFO"), AlertType.$ordinal$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType, "alert-info");
    AlertType.$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType = AlertType.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("WARNING"), AlertType.$ordinal$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType, "alert-warning");
    AlertType.$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType = AlertType.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ERROR"), AlertType.$ordinal$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType, "alert-danger");
    AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(AlertType, $Util.$makeClassName('org.dominokit.domino.ui.alerts.Alert$AlertType'));


/** @private {!AlertType} */
AlertType.$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType;


/** @private {!AlertType} */
AlertType.$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType;


/** @private {!AlertType} */
AlertType.$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType;


/** @private {!AlertType} */
AlertType.$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType;


/** @private {Map<?string, !AlertType>} */
AlertType.$f_namesToValuesMap__org_dominokit_domino_ui_alerts_Alert_AlertType_;


/** @public {number} @const */
AlertType.$ordinal$f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType = 0;


/** @public {number} @const */
AlertType.$ordinal$f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType = 1;


/** @public {number} @const */
AlertType.$ordinal$f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType = 2;


/** @public {number} @const */
AlertType.$ordinal$f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType = 3;




exports = AlertType; 
//# sourceMappingURL=Alert$AlertType.js.map