/**
 * @fileoverview transpiled from org.dominokit.domino.ui.badges.Badge.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.badges.Badge$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
 * @implements {HasBackground<Badge>}
  */
class Badge extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_;
    /** @public {boolean} */
    this.f_pulledRight__org_dominokit_domino_ui_badges_Badge_ = false;
    /** @public {Color} */
    this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_;
  }
  
  /**
   * Factory method corresponding to constructor 'Badge()'.
   * @return {!Badge}
   * @public
   */
  static $create__() {
    Badge.$clinit();
    let $instance = new Badge();
    $instance.$ctor__org_dominokit_domino_ui_badges_Badge__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Badge()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_badges_Badge__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_badges_Badge();
  }
  
  /**
   * @param {?string} content
   * @return {Badge}
   * @public
   */
  static m_create__java_lang_String(content) {
    Badge.$clinit();
    let badge = Badge.$create__();
    badge.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.textContent = content;
    return badge;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_;
  }
  
  /**
   * @param {?string} text
   * @return {Badge}
   * @public
   */
  m_setText__java_lang_String(text) {
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.textContent = text;
    return this;
  }
  
  /**
   * @return {Badge}
   * @public
   */
  m_pullRight__() {
    if (!this.f_pulledRight__org_dominokit_domino_ui_badges_Badge_) {
      this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.classList.add("pull-right");
    }
    return this;
  }
  
  /**
   * @override
   * @param {Color} badgeBackground
   * @return {Badge}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(badgeBackground) {
    if (Objects.m_nonNull__java_lang_Object(this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_)) {
      this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.classList.remove(this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_.m_getBackground__());
    }
    this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_ = badgeBackground;
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.classList.add(this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_.m_getBackground__());
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_badges_Badge() {
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["badge"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_pulledRight__org_dominokit_domino_ui_badges_Badge_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Badge;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Badge);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Badge.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Badge, $Util.$makeClassName('org.dominokit.domino.ui.badges.Badge'));


IsElement.$markImplementor(Badge);
HasBackground.$markImplementor(Badge);


exports = Badge; 
//# sourceMappingURL=Badge.js.map