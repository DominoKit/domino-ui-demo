/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.MonthContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.MonthContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');


class MonthContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_year__org_dominokit_domino_ui_datepicker_MonthContext_ = 0;
    /** @public {number} */
    this.f_month__org_dominokit_domino_ui_datepicker_MonthContext_ = 0;
    /** @public {number} */
    this.f_date__org_dominokit_domino_ui_datepicker_MonthContext_ = 0;
    /** @public {number} */
    this.f_day__org_dominokit_domino_ui_datepicker_MonthContext_ = 0;
    /** @public {number} */
    this.f_days__org_dominokit_domino_ui_datepicker_MonthContext_ = 0;
    /** @public {number} */
    this.f_firstDay__org_dominokit_domino_ui_datepicker_MonthContext_ = 0;
  }
  
  /**
   * Factory method corresponding to constructor 'MonthContext(int, int)'.
   * @param {number} year
   * @param {number} month
   * @return {!MonthContext}
   * @public
   */
  static $create__int__int(year, month) {
    MonthContext.$clinit();
    let $instance = new MonthContext();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_MonthContext__int__int(year, month);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MonthContext(int, int)'.
   * @param {number} year
   * @param {number} month
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_MonthContext__int__int(year, month) {
    this.$ctor__java_lang_Object__();
    let jsDate = new Date(Integer.m_valueOf__int(year), Integer.m_valueOf__int(month));
    this.f_year__org_dominokit_domino_ui_datepicker_MonthContext_ = jsDate.getFullYear();
    this.f_month__org_dominokit_domino_ui_datepicker_MonthContext_ = jsDate.getMonth();
    this.f_date__org_dominokit_domino_ui_datepicker_MonthContext_ = jsDate.getDate();
    this.f_day__org_dominokit_domino_ui_datepicker_MonthContext_ = jsDate.getDay();
    let jsDateCalc = new Date(Integer.m_valueOf__int(year), Integer.m_valueOf__int(month), Integer.m_valueOf__int(32));
    this.f_days__org_dominokit_domino_ui_datepicker_MonthContext_ = (32 - jsDateCalc.getDate());
    this.f_firstDay__org_dominokit_domino_ui_datepicker_MonthContext_ = new Date(Integer.m_valueOf__int(year), Integer.m_valueOf__int(month), Integer.m_valueOf__int(1)).getDay();
  }
  
  /**
   * @return {MonthContext}
   * @public
   */
  static m_current__() {
    MonthContext.$clinit();
    let date = new Date();
    return MonthContext.$create__int__int(date.getFullYear(), date.getMonth());
  }
  
  /**
   * @param {number} offset
   * @return {MonthContext}
   * @public
   */
  static m_offset__int(offset) {
    MonthContext.$clinit();
    let date = new Date();
    return MonthContext.$create__int__int(date.getFullYear(), date.getMonth());
  }
  
  /**
   * @return {MonthContext}
   * @public
   */
  m_getMonthBefore__() {
    return MonthContext.$create__int__int(this.f_month__org_dominokit_domino_ui_datepicker_MonthContext_ == 0 ? this.f_year__org_dominokit_domino_ui_datepicker_MonthContext_ - 1 : this.f_year__org_dominokit_domino_ui_datepicker_MonthContext_, this.f_month__org_dominokit_domino_ui_datepicker_MonthContext_ == 0 ? 11 : (this.f_month__org_dominokit_domino_ui_datepicker_MonthContext_ - 1));
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getYear__() {
    return this.f_year__org_dominokit_domino_ui_datepicker_MonthContext_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getMonth__() {
    return this.f_month__org_dominokit_domino_ui_datepicker_MonthContext_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getDate__() {
    return this.f_date__org_dominokit_domino_ui_datepicker_MonthContext_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getDay__() {
    return this.f_day__org_dominokit_domino_ui_datepicker_MonthContext_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getDays__() {
    return this.f_days__org_dominokit_domino_ui_datepicker_MonthContext_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getFirstDay__() {
    return this.f_firstDay__org_dominokit_domino_ui_datepicker_MonthContext_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MonthContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MonthContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MonthContext.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MonthContext, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.MonthContext'));




exports = MonthContext; 
//# sourceMappingURL=MonthContext.js.map