/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DaySelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let JsDate_$Overlay = goog.forwardDeclare('elemental2.core.JsDate.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let j_u_Date = goog.forwardDeclare('java.util.Date$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$15$impl');
let BackgroundHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let DatePickerElement = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
let DatePickerMonth = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerMonth$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let WavesSupport = goog.forwardDeclare('org.dominokit.domino.ui.style.WavesSupport$impl');
let DateTimeFormatInfo__factory = goog.forwardDeclare('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfo_factory$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasValue<j_u_Date>}
 * @implements {DaySelectionHandler}
  */
class DatePicker extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Date} */
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLDivElement} */
    this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLAnchorElement} */
    this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {HTMLAnchorElement} */
    this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Select} */
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Select} */
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Button} */
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Button} */
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Button} */
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {ColorScheme} */
    this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DatePickerMonth} */
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DatePickerElement} */
    this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<PickerHandler>} */
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<PickerHandler>} */
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {BackgroundHandler} */
    this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Date} */
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Date} */
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<DateSelectionHandler>} */
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * Factory method corresponding to constructor 'DatePicker(Date, DateTimeFormatInfo)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {!DatePicker}
   * @public
   */
  static $create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
    DatePicker.$clinit();
    let $instance = new DatePicker();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePicker(Date, DateTimeFormatInfo)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_.setFullYear(this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear() - 50);
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_.setFullYear(this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear() + 50);
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_ = DatePickerMonth.m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_, dateTimeFormatInfo, this);
    this.m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePicker(Date, DateTimeFormatInfo, Date, Date)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {j_u_Date} minDate
   * @param {j_u_Date} maxDate
   * @return {!DatePicker}
   * @public
   */
  static $create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate) {
    DatePicker.$clinit();
    let $instance = new DatePicker();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePicker(Date, DateTimeFormatInfo, Date, Date)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {j_u_Date} minDate
   * @param {j_u_Date} maxDate
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(minDate.m_getTime__()));
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(maxDate.m_getTime__()));
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_ = DatePickerMonth.m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_, dateTimeFormatInfo, this);
    this.m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePicker(JsDate, DateTimeFormatInfo, JsDate, JsDate)'.
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {Date} minDate
   * @param {Date} maxDate
   * @return {!DatePicker}
   * @public
   */
  static $create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__elemental2_core_JsDate__elemental2_core_JsDate(date, dateTimeFormatInfo, minDate, maxDate) {
    DatePicker.$clinit();
    let $instance = new DatePicker();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__elemental2_core_JsDate__elemental2_core_JsDate(date, dateTimeFormatInfo, minDate, maxDate);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePicker(JsDate, DateTimeFormatInfo, JsDate, JsDate)'.
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {Date} minDate
   * @param {Date} maxDate
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__elemental2_core_JsDate__elemental2_core_JsDate(date, dateTimeFormatInfo, minDate, maxDate) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_ = date;
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_ = minDate;
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_ = maxDate;
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_ = DatePickerMonth.m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_, dateTimeFormatInfo, this);
    this.m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.classList.add(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getBackground__());
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.classList.add(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_darker_2__().m_getBackground__());
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.m_initSelectors___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__());
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.m_initFooter___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_init__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFooter___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_ = Button.m_create__java_lang_String("CLEAR").m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__());
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().classList.add("clear-button");
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$11(((/** Event */ evt) =>{
      this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** PickerHandler */ arg0) =>{
        arg0.m_handle__();
      })));
    })));
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_ = Button.m_create__java_lang_String("TODAY").m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__());
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$12(((/** Event */ evt$1$) =>{
      this.m_setDate__java_util_Date(j_u_Date.$create__());
    })));
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_ = Button.m_create__java_lang_String("CLOSE").m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__());
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().classList.add("close-button");
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$13(((/** Event */ evt$2$) =>{
      this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** PickerHandler */ arg0$1$) =>{
        arg0$1$.m_handle__();
      })));
    })));
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_linkify__().m_asElement__());
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_linkify__().m_asElement__());
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_linkify__().m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSelectors___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    let year = this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear();
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_ = Select.m_create__();
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.setProperty("margin-bottom", "0px", "important");
    for (let i = this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear(); i <= this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear(); i++) {
      let yearOption = SelectOption.m_create__java_lang_String__java_lang_String(i + "", i + "");
      this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_addOption__org_dominokit_domino_ui_forms_SelectOption(yearOption);
      if (i == year) {
        this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_select__org_dominokit_domino_ui_forms_SelectOption(yearOption);
      }
    }
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption */ option) =>{
      let selectedYear = Integer.m_parseInt__java_lang_String(option.m_getValue__());
      this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.setYear(selectedYear);
      this.m_setDate__elemental2_core_JsDate(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_);
    })));
    let month = this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.getMonth();
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_ = Select.m_create__();
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.setProperty("margin-bottom", "0px", "important");
    let months = this.m_getDateTimeFormatInfo__().m_monthsShort__();
    for (let i$1$ = 0; i$1$ < months.length; i$1$++) {
      let monthOption = SelectOption.m_create__java_lang_String__java_lang_String(i$1$ + "", months[i$1$]);
      this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_addOption__org_dominokit_domino_ui_forms_SelectOption(monthOption);
      if (i$1$ == month) {
        this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_select__org_dominokit_domino_ui_forms_SelectOption(monthOption);
      }
    }
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption */ option$1$) =>{
      let selectedMonth = Integer.m_parseInt__java_lang_String(option$1$.m_getValue__());
      this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.setMonth(selectedMonth);
      this.m_setDate__elemental2_core_JsDate(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_);
    })));
    let yearColumn = this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_.m_copy__().m_addElement__elemental2_dom_Node(this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__());
    yearColumn.m_asElement__().style.setProperty("padding-left", "0px", "important");
    yearColumn.m_asElement__().style.setProperty("padding-right", "3px", "important");
    yearColumn.m_asElement__().style.setProperty("margin-bottom", "5px", "important");
    let monthColumn = this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_.m_copy__().m_addElement__elemental2_dom_Node(this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__());
    monthColumn.m_asElement__().style.setProperty("padding-left", "3px", "important");
    monthColumn.m_asElement__().style.setProperty("padding-right", "0px", "important");
    monthColumn.m_asElement__().style.setProperty("margin-bottom", "5px", "important");
    let backColumn = this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_.m_copy__().m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_two__org_dominokit_domino_ui_column_Column_OnXSmall).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_two__org_dominokit_domino_ui_column_Column_OnSmall).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_two__org_dominokit_domino_ui_column_Column_OnMedium).m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_two__org_dominokit_domino_ui_column_Column_OnLarge);
    backColumn.m_asElement__().style.setProperty("padding", "0px", "important");
    backColumn.m_asElement__().style.setProperty("margin-bottom", "5px", "important");
    let forwardColumn = backColumn.m_copy__();
    forwardColumn.m_asElement__().style.setProperty("padding", "0px", "important");
    forwardColumn.m_asElement__().style.setProperty("text-align", "right", "important");
    forwardColumn.m_asElement__().style.setProperty("margin-bottom", "5px", "important");
    let row = Row.m_create__();
    row.m_asElement__().style.setProperty("margin-left", "0px", "important");
    row.m_asElement__().style.setProperty("margin-right", "0px", "important");
    this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navigate"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_navigate_before__().m_asElement__()), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navigate"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_navigate_next__().m_asElement__()), HtmlContentBuilder)).m_asElement__(), $Overlay));
    /**@type {WavesSupport<HTMLAnchorElement>} */ (WavesSupport.m_addFor__elemental2_dom_HTMLElement(this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_));
    /**@type {WavesSupport<HTMLAnchorElement>} */ (WavesSupport.m_addFor__elemental2_dom_HTMLElement(this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_));
    this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_.addEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$14(((/** Event */ evt) =>{
      let jsDate = this.m_getJsDate__();
      let currentMonth = jsDate.getMonth();
      if (currentMonth == 0) {
        jsDate.setYear(jsDate.getFullYear() - 1);
        jsDate.setMonth(11);
      } else {
        jsDate.setMonth(currentMonth - 1);
      }
      this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_lang_String__boolean(jsDate.getFullYear() + "", true);
      this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_selectAt__int__boolean(jsDate.getMonth(), true);
      this.m_setDate__elemental2_core_JsDate(jsDate);
    })));
    this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_.addEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$15(((/** Event */ evt$1$) =>{
      let jsDate$1$ = this.m_getJsDate__();
      let currentMonth$1$ = jsDate$1$.getMonth();
      if (currentMonth$1$ == 11) {
        jsDate$1$.setYear(jsDate$1$.getFullYear() + 1);
        jsDate$1$.setMonth(0);
      } else {
        jsDate$1$.setMonth(currentMonth$1$ + 1);
      }
      this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_lang_String__boolean(jsDate$1$.getFullYear() + "", true);
      this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_selectAt__int__boolean(jsDate$1$.getMonth(), true);
      this.m_setDate__elemental2_core_JsDate(jsDate$1$);
    })));
    this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_.appendChild(row.m_addColumn__org_dominokit_domino_ui_column_Column(backColumn.m_addElement__elemental2_dom_Node(this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_)).m_addColumn__org_dominokit_domino_ui_column_Column(yearColumn).m_addColumn__org_dominokit_domino_ui_column_Column(monthColumn).m_addColumn__org_dominokit_domino_ui_column_Column(forwardColumn.m_addElement__elemental2_dom_Node(this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_)).m_asElement__());
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  static m_create__() {
    DatePicker.$clinit();
    let dateTimeFormatInfo = DateTimeFormatInfo__factory.m_create__();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(j_u_Date.$create__(), dateTimeFormatInfo);
  }
  
  /**
   * @param {j_u_Date} date
   * @return {DatePicker}
   * @public
   */
  static m_create__java_util_Date(date) {
    DatePicker.$clinit();
    let dateTimeFormatInfo = DateTimeFormatInfo__factory.m_create__();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
  }
  
  /**
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {DatePicker}
   * @public
   */
  static m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
    DatePicker.$clinit();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
  }
  
  /**
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {j_u_Date} minDate
   * @param {j_u_Date} maxDate
   * @return {DatePicker}
   * @public
   */
  static m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate) {
    DatePicker.$clinit();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate);
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @param {j_u_Date} value
   * @return {void}
   * @public
   */
  m_setValue__java_util_Date(value) {
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_util_Date(value);
  }
  
  /**
   * @override
   * @return {j_u_Date}
   * @public
   */
  m_getValue__() {
    return this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_getValue__();
  }
  
  /**
   * @param {j_u_Date} date
   * @return {DatePicker}
   * @public
   */
  m_setDate__java_util_Date(date) {
    this.m_setValue__java_util_Date(date);
    return this;
  }
  
  /**
   * @return {j_u_Date}
   * @public
   */
  m_getDate__() {
    return this.m_getValue__();
  }
  
  /**
   * @param {Date} jsDate
   * @return {DatePicker}
   * @public
   */
  m_setDate__elemental2_core_JsDate(jsDate) {
    this.m_setValue__java_util_Date(j_u_Date.$create__long(Double.m_longValue__java_lang_Double(Double.$create__double(jsDate.getTime()))));
    return this;
  }
  
  /**
   * @return {Date}
   * @public
   */
  m_getJsDate__() {
    return new Date($Primitives.$widenLongToDouble(this.m_getValue__().m_getTime__()));
  }
  
  /**
   * @param {DateSelectionHandler} dateSelectionHandler
   * @return {DatePicker}
   * @public
   */
  m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(dateSelectionHandler) {
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(dateSelectionHandler);
    return this;
  }
  
  /**
   * @param {DateSelectionHandler} dateSelectionHandler
   * @return {DatePicker}
   * @public
   */
  m_removeDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(dateSelectionHandler) {
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(dateSelectionHandler);
    return this;
  }
  
  /**
   * @return {List<DateSelectionHandler>}
   * @public
   */
  m_getDateSelectionHandlers__() {
    return this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_clearDaySelectionHandlers__() {
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.clear();
    return this;
  }
  
  /**
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {DatePicker}
   * @public
   */
  m_setDateTimeFormatInfo__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo) {
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_setDateTimeFormatInfo__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo);
    this.m_updatePicker___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    return this;
  }
  
  /**
   * @return {DateTimeFormatInfo}
   * @public
   */
  m_getDateTimeFormatInfo__() {
    return this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_getDateTimeFormatInfo__();
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showBorder__() {
    this.m_asElement__().style.setProperty("border", "1px solid " + j_l_String.m_valueOf__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getHex__()));
    return this;
  }
  
  /**
   * @param {ColorScheme} colorScheme
   * @return {DatePicker}
   * @public
   */
  m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(colorScheme) {
    this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_.m_onBackgroundChanged__org_dominokit_domino_ui_style_ColorScheme__org_dominokit_domino_ui_style_ColorScheme(this.m_getColorScheme__(), colorScheme);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.classList.remove(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getBackground__());
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.classList.remove(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_darker_2__().m_getBackground__());
    this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_ = colorScheme;
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.classList.add(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getBackground__());
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.classList.add(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_darker_2__().m_getBackground__());
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_setBackground__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setColor__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setColor__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setColor__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    return this;
  }
  
  /**
   * @return {ColorScheme}
   * @public
   */
  m_getColorScheme__() {
    return this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @override
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_onDaySelected__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement) {
    this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_ = datePickerElement;
    this.m_updatePicker___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    this.m_publish___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_publish___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    for (let i = 0; i < this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.size(); i++) {
      /**@type {DateSelectionHandler} */ ($Casts.$to(this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.getAtIndex(i), DateSelectionHandler)).m_onDateSelected__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.m_getDate__(), this.m_getDateTimeFormatInfo__());
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updatePicker___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    let dayNameIndex = this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getWeekDay__() + this.m_getDateTimeFormatInfo__().m_firstDayOfTheWeek__();
    if (dayNameIndex > 6) {
      dayNameIndex = this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getWeekDay__() + this.m_getDateTimeFormatInfo__().m_firstDayOfTheWeek__() - 7;
    }
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.textContent = this.m_getDateTimeFormatInfo__().m_weekdaysFull__()[dayNameIndex];
    this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_.textContent = this.m_getDateTimeFormatInfo__().m_monthsFull__()[this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getMonth__()];
    this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_.textContent = this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getDay__() + "";
    this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_.textContent = this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getYear__() + "";
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_selectAt__int__boolean(this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getMonth__(), true);
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_lang_String__boolean(this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getYear__() + "", true);
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showHeaderPanel__() {
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.style.display = "block";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideHeaderPanel__() {
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.style.display = "none";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showTodayButton__() {
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.display = "block";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideTodayButton__() {
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.display = "none";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showClearButton__() {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.display = "block";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideClearButton__() {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.display = "none";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showCloseButton__() {
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.display = "block";
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideCloseButton__() {
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().style.display = "none";
    return this;
  }
  
  /**
   * @param {PickerHandler} closeHandler
   * @return {DatePicker}
   * @public
   */
  m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(closeHandler) {
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(closeHandler);
    return this;
  }
  
  /**
   * @param {PickerHandler} closeHandler
   * @return {DatePicker}
   * @public
   */
  m_removeCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(closeHandler) {
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(closeHandler);
    return this;
  }
  
  /**
   * @return {List<PickerHandler>}
   * @public
   */
  m_getCloseHandlers__() {
    return this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @param {PickerHandler} clearHandler
   * @return {DatePicker}
   * @public
   */
  m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(clearHandler) {
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(clearHandler);
    return this;
  }
  
  /**
   * @param {PickerHandler} clearHandler
   * @return {DatePicker}
   * @public
   */
  m_removeClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(clearHandler) {
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(clearHandler);
    return this;
  }
  
  /**
   * @return {List<PickerHandler>}
   * @public
   */
  m_getClearHandlers__() {
    return this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @param {?string} text
   * @return {DatePicker}
   * @public
   */
  m_todayButtonText__java_lang_String(text) {
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setContent__java_lang_String(text);
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().title = text;
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {DatePicker}
   * @public
   */
  m_clearButtonText__java_lang_String(text) {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setContent__java_lang_String(text);
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().title = text;
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {DatePicker}
   * @public
   */
  m_closeButtonText__java_lang_String(text) {
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setContent__java_lang_String(text);
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().title = text;
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_fixedWidth__() {
    this.m_asElement__().style.setProperty("width", "300px", "important");
    return this;
  }
  
  /**
   * @param {?string} width
   * @return {DatePicker}
   * @public
   */
  m_fixedWidth__java_lang_String(width) {
    this.m_asElement__().style.setProperty("width", width, "important");
    return this;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getHeaderPanel__() {
    return this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getSelectorsPanel__() {
    return this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getFooterPanel__() {
    return this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getDayNamePanel__() {
    return this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getMonthNamePanel__() {
    return this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getDateNumberPanel__() {
    return this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getYearNumberPanel__() {
    return this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getNavigateBefore__() {
    return this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getNavigateNext__() {
    return this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @param {BackgroundHandler} backgroundHandler
   * @return {DatePicker}
   * @public
   */
  m_setBackgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$pp_org_dominokit_domino_ui_datepicker(backgroundHandler) {
    if (Objects.m_nonNull__java_lang_Object(backgroundHandler)) {
      this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_ = backgroundHandler;
    }
    return this;
  }
  
  /**
   * @param {?string} title
   * @return {ModalDialog}
   * @public
   */
  m_createModal__java_lang_String(title) {
    return ModalDialog.m_createPickerModal__java_lang_String__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_Node(title, this.m_getColorScheme__(), this.m_asElement__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_util_Date(/**@type {j_u_Date} */ ($Casts.$to(arg0, j_u_Date)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datepicker_DatePicker() {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["calendar"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["date-panel"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["selector-container"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["footer"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["day-name"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["month-name"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["day-number"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["year-number"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_ = ColorScheme.f_LIGHT_BLUE__org_dominokit_domino_ui_style_ColorScheme;
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<PickerHandler>} */ (ArrayList.$create__());
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<PickerHandler>} */ (ArrayList.$create__());
    this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_ = BackgroundHandler.$adapt(((/** ColorScheme */ oldBackground, /** ColorScheme */ newBackground) =>{
    }));
    this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_ = Column.m_create__().m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_four__org_dominokit_domino_ui_column_Column_OnXSmall).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_four__org_dominokit_domino_ui_column_Column_OnSmall).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge);
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<DateSelectionHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePicker;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePicker);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DatePicker.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    j_u_Date = goog.module.get('java.util.Date$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$15$impl');
    BackgroundHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    DatePickerMonth = goog.module.get('org.dominokit.domino.ui.datepicker.DatePickerMonth$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    WavesSupport = goog.module.get('org.dominokit.domino.ui.style.WavesSupport$impl');
    DateTimeFormatInfo__factory = goog.module.get('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfo_factory$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DatePicker, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker'));


IsElement.$markImplementor(DatePicker);
HasValue.$markImplementor(DatePicker);
DaySelectionHandler.$markImplementor(DatePicker);


exports = DatePicker; 
//# sourceMappingURL=DatePicker.js.map