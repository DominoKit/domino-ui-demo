/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerMonth$DaySelectionHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DatePickerElement = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class DaySelectionHandler {
  /**
   * @abstract
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_onDaySelected__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement) {
  }
  
  /**
   * @param {?function(DatePickerElement):void} fn
   * @return {DaySelectionHandler}
   * @public
   */
  static $adapt(fn) {
    DaySelectionHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePickerMonth_DaySelectionHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DaySelectionHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DaySelectionHandler, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePickerMonth$DaySelectionHandler'));


DaySelectionHandler.$markImplementor(/** @type {Function} */ (DaySelectionHandler));


exports = DaySelectionHandler; 
//# sourceMappingURL=DatePickerMonth$DaySelectionHandler.js.map