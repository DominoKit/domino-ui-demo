/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$$LambdaAdaptor$11.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$11$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$11 extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor$11($JsFunction)'.
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$11.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$11;
    this.$ctor__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$11__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor$11($JsFunction)'.
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$11__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$11 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$11;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$11;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$11);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$11.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$11, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$$LambdaAdaptor$11'));




exports = $LambdaAdaptor$11; 
//# sourceMappingURL=DatePicker$$LambdaAdaptor$11.js.map