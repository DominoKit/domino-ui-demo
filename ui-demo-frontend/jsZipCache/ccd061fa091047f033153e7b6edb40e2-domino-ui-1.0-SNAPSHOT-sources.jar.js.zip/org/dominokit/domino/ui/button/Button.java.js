/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.Button.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.Button');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _WavesElement = goog.require('org.dominokit.domino.ui.style.WavesElement');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement');
const _HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent');
const _HasStyleProperty = goog.require('org.dominokit.domino.ui.utils.HasStyleProperty');
const _IsHtmlComponent = goog.require('org.dominokit.domino.ui.utils.IsHtmlComponent');
const _Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable');
const _Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLButtonElement_$Overlay = goog.require('elemental2.dom.HTMLButtonElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _ButtonSize = goog.require('org.dominokit.domino.ui.button.ButtonSize');
const _CircleSize = goog.require('org.dominokit.domino.ui.button.CircleSize');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _WaveStyle = goog.require('org.dominokit.domino.ui.style.WaveStyle');
const _HtmlComponentBuilder = goog.require('org.dominokit.domino.ui.utils.HtmlComponentBuilder');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Button = goog.require('org.dominokit.domino.ui.button.Button$impl');
exports = Button;
 