/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownAction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.DropdownAction$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');
const Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Justifiable}
 * @implements {HasClickableElement}
  */
class DropdownAction extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLLIElement} */
    this.f_iElement__org_dominokit_domino_ui_button_DropdownAction_;
    /** @public {HTMLAnchorElement} */
    this.f_aElement__org_dominokit_domino_ui_button_DropdownAction_;
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownAction(String)'.
   * @param {?string} content
   * @return {!DropdownAction}
   * @public
   */
  static $create__java_lang_String(content) {
    DropdownAction.$clinit();
    let $instance = new DropdownAction();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownAction__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownAction(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownAction__java_lang_String(content) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_button_DropdownAction();
    this.f_aElement__org_dominokit_domino_ui_button_DropdownAction_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_textContent__java_lang_String(content), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_iElement__org_dominokit_domino_ui_button_DropdownAction_.appendChild(this.f_aElement__org_dominokit_domino_ui_button_DropdownAction_);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownAction}
   * @public
   */
  static m_create__java_lang_String(content) {
    DropdownAction.$clinit();
    return DropdownAction.$create__java_lang_String(content);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_iElement__org_dominokit_domino_ui_button_DropdownAction_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_justify__() {
    return /**@type {HTMLLIElement} */ ($Casts.$to(this.m_asElement__().cloneNode(true), HTMLLIElement_$Overlay));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.f_aElement__org_dominokit_domino_ui_button_DropdownAction_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_DropdownAction() {
    this.f_iElement__org_dominokit_domino_ui_button_DropdownAction_ = /**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DropdownAction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DropdownAction);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DropdownAction.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DropdownAction, $Util.$makeClassName('org.dominokit.domino.ui.button.DropdownAction'));


Justifiable.$markImplementor(DropdownAction);
HasClickableElement.$markImplementor(DropdownAction);


exports = DropdownAction; 
//# sourceMappingURL=DropdownAction.js.map