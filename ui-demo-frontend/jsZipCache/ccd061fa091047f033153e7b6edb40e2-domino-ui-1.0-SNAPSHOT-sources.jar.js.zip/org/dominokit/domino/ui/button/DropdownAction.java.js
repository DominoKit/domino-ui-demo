/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownAction.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.DropdownAction');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement');
const _Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DropdownAction = goog.require('org.dominokit.domino.ui.button.DropdownAction$impl');
exports = DropdownAction;
 