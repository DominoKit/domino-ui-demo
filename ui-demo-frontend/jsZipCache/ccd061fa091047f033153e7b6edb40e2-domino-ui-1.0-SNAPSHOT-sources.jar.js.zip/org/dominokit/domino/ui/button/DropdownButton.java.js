/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownButton.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.DropdownButton');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent');
const _Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _DropdownAction = goog.require('org.dominokit.domino.ui.button.DropdownAction');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$4');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$5');
const _JustifiableSeparator = goog.require('org.dominokit.domino.ui.button.DropdownButton.JustifiableSeparator');
const _IconButton = goog.require('org.dominokit.domino.ui.button.IconButton');
const _ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton$impl');
exports = DropdownButton;
 