/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownButton.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.DropdownButton$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent$impl');
const Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let DropdownAction = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownAction$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$5$impl');
let JustifiableSeparator = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton.JustifiableSeparator$impl');
let IconButton = goog.forwardDeclare('org.dominokit.domino.ui.button.IconButton$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Justifiable}
 * @implements {HasContent<DropdownButton>}
 * @implements {HasBackground<DropdownButton>}
  */
class DropdownButton extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_caret__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {HTMLElement} */
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {HTMLUListElement} */
    this.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {List<Justifiable>} */
    this.f_items__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {Button} */
    this.f_button__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {Color} */
    this.f_background__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {!DropdownButton}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String(content).m_setButtonType__org_dominokit_domino_ui_style_StyleType(type));
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {!DropdownButton}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    this.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String(content).m_setBackground__org_dominokit_domino_ui_style_Color(background));
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(String)'.
   * @param {?string} content
   * @return {!DropdownButton}
   * @public
   */
  static $create__java_lang_String(content) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String(content) {
    this.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(Button.m_create__java_lang_String(content));
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(Icon, StyleType)'.
   * @param {Icon} icon
   * @param {StyleType} type
   * @return {!DropdownButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(Icon, StyleType)'.
   * @param {Icon} icon
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    this.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(IconButton.m_create__org_dominokit_domino_ui_icons_Icon(icon).m_setButtonType__org_dominokit_domino_ui_style_StyleType(type));
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(Icon)'.
   * @param {Icon} icon
   * @return {!DropdownButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_Icon(icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(Icon)'.
   * @param {Icon} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_Icon(icon) {
    this.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(IconButton.m_create__org_dominokit_domino_ui_icons_Icon(icon));
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(Button)'.
   * @param {Button} button
   * @return {!DropdownButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_button_Button(button) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(button);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(Button)'.
   * @param {Button} button
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_button_Button(button) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_button_DropdownButton();
    this.f_button__org_dominokit_domino_ui_button_DropdownButton_ = button;
    this.m_addHideListener___$p_org_dominokit_domino_ui_button_DropdownButton();
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.appendChild(this.m_asDropDown__elemental2_dom_HTMLElement__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_button_DropdownButton(this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__(), this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_));
    this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().appendChild(this.f_caret__org_dominokit_domino_ui_button_DropdownButton_);
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.appendChild(this.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addHideListener___$p_org_dominokit_domino_ui_button_DropdownButton() {
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.style.cursor = "default";
    if (Objects.m_nonNull__java_lang_Object(DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_)) {
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.addEventListener("click", DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_);
    } else {
      DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_ = new $LambdaAdaptor$4(((/** Event */ event) =>{
        window.console.info("[ ON CLICK ]");
        this.m_close__elemental2_dom_Event_$p_org_dominokit_domino_ui_button_DropdownButton(event);
      }));
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.addEventListener("click", DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_);
    }
  }
  
  /**
   * @param {Event} evt
   * @return {void}
   * @public
   */
  m_close__elemental2_dom_Event_$p_org_dominokit_domino_ui_button_DropdownButton(evt) {
    this.m_closeAllGroups___$p_org_dominokit_domino_ui_button_DropdownButton();
  }
  
  /**
   * @param {HTMLElement} buttonElement
   * @param {HTMLElement} groupElement
   * @return {HTMLElement}
   * @public
   */
  m_asDropDown__elemental2_dom_HTMLElement__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_button_DropdownButton(buttonElement, groupElement) {
    buttonElement.classList.add("dropdown-toggle");
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(buttonElement, "data-toggle", "dropdown");
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__boolean(buttonElement, "aria-haspopup", true);
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__boolean(buttonElement, "aria-expanded", true);
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(buttonElement, "type", "button");
    buttonElement.addEventListener("click", new $LambdaAdaptor$5(((/** Event */ event) =>{
      this.m_closeAllGroups___$p_org_dominokit_domino_ui_button_DropdownButton();
      this.m_open__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_button_DropdownButton(groupElement);
      event.stopPropagation();
    })));
    return buttonElement;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_closeAllGroups___$p_org_dominokit_domino_ui_button_DropdownButton() {
    let elementsByName = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.querySelectorAll(".btn-group.open");
    for (let i = 0; i < elementsByName.length; i++) {
      let item = /**@type {Element} */ ($Casts.$to(elementsByName.item(i), Element_$Overlay));
      if (this.m_isOpened__elemental2_dom_Element_$p_org_dominokit_domino_ui_button_DropdownButton(item)) {
        this.m_close__elemental2_dom_Element_$p_org_dominokit_domino_ui_button_DropdownButton(item);
      }
    }
  }
  
  /**
   * @param {Element} item
   * @return {boolean}
   * @public
   */
  m_isOpened__elemental2_dom_Element_$p_org_dominokit_domino_ui_button_DropdownButton(item) {
    return item.classList.contains("open");
  }
  
  /**
   * @param {HTMLElement} groupElement
   * @return {void}
   * @public
   */
  m_open__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_button_DropdownButton(groupElement) {
    groupElement.classList.add("open");
  }
  
  /**
   * @param {Element} item
   * @return {void}
   * @public
   */
  m_close__elemental2_dom_Element_$p_org_dominokit_domino_ui_button_DropdownButton(item) {
    item.classList.remove("open");
  }
  
  /**
   * @param {DropdownAction} action
   * @return {DropdownButton}
   * @public
   */
  m_addAction__org_dominokit_domino_ui_button_DropdownAction(action) {
    this.f_items__org_dominokit_domino_ui_button_DropdownButton_.add(action);
    this.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_.appendChild(action.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_separator__() {
    let justifiableSeparator = JustifiableSeparator.$create__org_dominokit_domino_ui_button_DropdownButton(this);
    this.f_items__org_dominokit_domino_ui_button_DropdownButton_.add(justifiableSeparator);
    this.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_.appendChild(justifiableSeparator.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_justify__() {
    let button = Button.m_create__java_lang_String(this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().textContent);
    for (let $iterator = /**@type {List<?string>} */ (JsArrayLike_$Overlay.m_asList__jsinterop_base_JsArrayLike(this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().classList)).m_iterator__(); $iterator.m_hasNext__(); ) {
      let style = /**@type {?string} */ ($Casts.$to($iterator.m_next__(), j_l_String));
      button.m_asElement__().classList.add(style);
    }
    let cloneDropdownButton = DropdownButton.$create__org_dominokit_domino_ui_button_Button(button);
    for (let $iterator$1$ = this.f_items__org_dominokit_domino_ui_button_DropdownButton_.m_iterator__(); $iterator$1$.m_hasNext__(); ) {
      let item = /**@type {Justifiable} */ ($Casts.$to($iterator$1$.m_next__(), Justifiable));
      cloneDropdownButton.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_.appendChild(item.m_justify__());
    }
    return cloneDropdownButton.m_asElement__();
  }
  
  /**
   * @override
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  m_setContent__java_lang_String(content) {
    this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_setContent__java_lang_String(content);
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_dropup__() {
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.classList.add("dropup");
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_dropdown__() {
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.classList.remove("dropup");
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_hideCaret__() {
    if (this.m_isCaretAdded___$p_org_dominokit_domino_ui_button_DropdownButton()) {
      this.f_caret__org_dominokit_domino_ui_button_DropdownButton_.remove();
    }
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_showCaret__() {
    if (!this.m_isCaretAdded___$p_org_dominokit_domino_ui_button_DropdownButton()) {
      this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().appendChild(this.f_caret__org_dominokit_domino_ui_button_DropdownButton_);
    }
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isCaretAdded___$p_org_dominokit_domino_ui_button_DropdownButton() {
    return this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().contains(this.f_caret__org_dominokit_domino_ui_button_DropdownButton_);
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {DropdownButton}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_background__org_dominokit_domino_ui_button_DropdownButton_)) {
      this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().classList.remove(this.f_background__org_dominokit_domino_ui_button_DropdownButton_.m_getBackground__());
    }
    this.f_button__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__().classList.add(background.m_getBackground__());
    this.f_background__org_dominokit_domino_ui_button_DropdownButton_ = background;
    return this;
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_create__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.$create__java_lang_String(content);
  }
  
  /**
   * @param {?string} content
   * @param {Color} background
   * @return {DropdownButton}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    DropdownButton.$clinit();
    return DropdownButton.$create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
  }
  
  /**
   * @param {?string} content
   * @param {StyleType} type
   * @return {DropdownButton}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    DropdownButton.$clinit();
    return DropdownButton.$create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createDefault__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createPrimary__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createSuccess__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createInfo__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createWarning__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createDanger__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @param {StyleType} type
   * @return {DropdownButton}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    DropdownButton.$clinit();
    return DropdownButton.$create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, type);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.$create__org_dominokit_domino_ui_icons_Icon(icon);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createDefault__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createPrimary__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createSuccess__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createInfo__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createWarning__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {Icon} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createDanger__org_dominokit_domino_ui_icons_Icon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getCaret__() {
    return this.f_caret__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * @return {HTMLUListElement}
   * @public
   */
  m_getActionsElement__() {
    return this.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * @return {Button}
   * @public
   */
  m_getButton__() {
    return this.f_button__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_DropdownButton() {
    this.f_caret__org_dominokit_domino_ui_button_DropdownButton_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["caret"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_ = ButtonsGroup.m_create__().m_asElement__();
    this.f_actionsElement__org_dominokit_domino_ui_button_DropdownButton_ = /**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["dropdown-menu"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLUListElement_$Overlay));
    this.f_items__org_dominokit_domino_ui_button_DropdownButton_ = /**@type {!LinkedList<Justifiable>} */ (LinkedList.$create__());
  }
  
  /**
   * @return {EventListener}
   * @public
   */
  static get f_listener__org_dominokit_domino_ui_button_DropdownButton_() {
    return (DropdownButton.$clinit(), DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_);
  }
  
  /**
   * @param {EventListener} value
   * @return {void}
   * @public
   */
  static set f_listener__org_dominokit_domino_ui_button_DropdownButton_(value) {
    (DropdownButton.$clinit(), DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DropdownButton;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DropdownButton);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DropdownButton.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    JsArrayLike_$Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$5$impl');
    JustifiableSeparator = goog.module.get('org.dominokit.domino.ui.button.DropdownButton.JustifiableSeparator$impl');
    IconButton = goog.module.get('org.dominokit.domino.ui.button.IconButton$impl');
    ButtonsGroup = goog.module.get('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DropdownButton, $Util.$makeClassName('org.dominokit.domino.ui.button.DropdownButton'));


/** @private {EventListener} */
DropdownButton.$f_listener__org_dominokit_domino_ui_button_DropdownButton_;


Justifiable.$markImplementor(DropdownButton);
HasContent.$markImplementor(DropdownButton);
HasBackground.$markImplementor(DropdownButton);


exports = DropdownButton; 
//# sourceMappingURL=DropdownButton.js.map