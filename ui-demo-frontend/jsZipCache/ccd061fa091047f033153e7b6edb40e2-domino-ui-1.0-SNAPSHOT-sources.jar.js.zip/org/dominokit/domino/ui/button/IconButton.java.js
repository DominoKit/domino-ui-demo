/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.IconButton.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.IconButton');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _CircleSize = goog.require('org.dominokit.domino.ui.button.CircleSize');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _WaveStyle = goog.require('org.dominokit.domino.ui.style.WaveStyle');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var IconButton = goog.require('org.dominokit.domino.ui.button.IconButton$impl');
exports = IconButton;
 