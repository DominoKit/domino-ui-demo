/**
 * @fileoverview transpiled from org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _Text_$Overlay = goog.require('elemental2.dom.Text.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BreadcrumbItem = goog.require('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem$impl');
exports = BreadcrumbItem;
 