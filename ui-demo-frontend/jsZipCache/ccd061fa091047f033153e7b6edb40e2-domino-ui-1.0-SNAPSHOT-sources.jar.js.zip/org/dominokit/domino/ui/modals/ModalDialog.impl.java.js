/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.ModalDialog.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.ModalDialog$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseModal = goog.require('org.dominokit.domino.ui.modals.BaseModal$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseModal<ModalDialog>}
  */
class ModalDialog extends BaseModal {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ModalDialog(String)'.
   * @param {?string} title
   * @return {!ModalDialog}
   * @public
   */
  static $create__java_lang_String(title) {
    ModalDialog.$clinit();
    let $instance = new ModalDialog();
    $instance.$ctor__org_dominokit_domino_ui_modals_ModalDialog__java_lang_String(title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalDialog(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_ModalDialog__java_lang_String(title) {
    this.$ctor__org_dominokit_domino_ui_modals_BaseModal__java_lang_String(title);
  }
  
  /**
   * Factory method corresponding to constructor 'ModalDialog()'.
   * @return {!ModalDialog}
   * @public
   */
  static $create__() {
    ModalDialog.$clinit();
    let $instance = new ModalDialog();
    $instance.$ctor__org_dominokit_domino_ui_modals_ModalDialog__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalDialog()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_ModalDialog__() {
    this.$ctor__org_dominokit_domino_ui_modals_BaseModal__();
  }
  
  /**
   * @param {?string} title
   * @return {ModalDialog}
   * @public
   */
  static m_create__java_lang_String(title) {
    ModalDialog.$clinit();
    return ModalDialog.$create__java_lang_String(title);
  }
  
  /**
   * @return {ModalDialog}
   * @public
   */
  static m_create__() {
    ModalDialog.$clinit();
    return ModalDialog.$create__();
  }
  
  /**
   * @param {?string} title
   * @param {ColorScheme} colorScheme
   * @param {Node} content
   * @return {ModalDialog}
   * @public
   */
  static m_createPickerModal__java_lang_String__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_Node(title, colorScheme, content) {
    ModalDialog.$clinit();
    let modal = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String(title).m_small__(), ModalDialog)).m_setAutoClose__boolean(true), ModalDialog)).m_appendContent__elemental2_dom_Node(content), ModalDialog));
    modal.m_getHeaderContainerElement__().style.display = "none";
    modal.m_getBodyElement__().style.setProperty("padding", "0px", "important");
    modal.m_getContentElement__().style.setProperty("width", "275px");
    modal.m_getDialogElement__().style.setProperty("width", "275px");
    modal.m_getFooterElement__().style.setProperty("padding", "0px", "important");
    return modal;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalDialog;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalDialog);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalDialog.$clinit = function() {};
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseModal.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ModalDialog, $Util.$makeClassName('org.dominokit.domino.ui.modals.ModalDialog'));




exports = ModalDialog; 
//# sourceMappingURL=ModalDialog.js.map