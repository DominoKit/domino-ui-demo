/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.BaseModal$$LambdaAdaptor$47.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$47$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$47 extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor$47($JsFunction)'.
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$47.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_ui_modals_BaseModal_$LambdaAdaptor$47;
    this.$ctor__org_dominokit_domino_ui_modals_BaseModal_$LambdaAdaptor$47__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor$47($JsFunction)'.
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_BaseModal_$LambdaAdaptor$47__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_modals_BaseModal_$LambdaAdaptor$47 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_modals_BaseModal_$LambdaAdaptor$47;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$47;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$47);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$47.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$47, $Util.$makeClassName('org.dominokit.domino.ui.modals.BaseModal$$LambdaAdaptor$47'));




exports = $LambdaAdaptor$47; 
//# sourceMappingURL=BaseModal$$LambdaAdaptor$47.js.map