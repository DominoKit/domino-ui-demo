/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog$OpenHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class OpenHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onOpen__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {OpenHandler}
   * @public
   */
  static $adapt(fn) {
    OpenHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    OpenHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(OpenHandler, $Util.$makeClassName('org.dominokit.domino.ui.modals.IsModalDialog$OpenHandler'));


OpenHandler.$markImplementor(/** @type {Function} */ (OpenHandler));


exports = OpenHandler; 
//# sourceMappingURL=IsModalDialog$OpenHandler.js.map