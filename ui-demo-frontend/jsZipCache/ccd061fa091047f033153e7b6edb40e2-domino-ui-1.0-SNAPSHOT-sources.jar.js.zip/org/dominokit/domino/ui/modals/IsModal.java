package org.dominokit.domino.ui.modals;

public class IsModal {
}
