/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListGroup.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.lists.ListGroup');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasMultiSelectSupport = goog.require('org.dominokit.domino.ui.utils.HasMultiSelectSupport');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Stream = goog.require('java.util.stream.Stream');
const _SelectionChangeHandler = goog.require('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler');
const _ListItem = goog.require('org.dominokit.domino.ui.lists.ListItem');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ListGroup = goog.require('org.dominokit.domino.ui.lists.ListGroup$impl');
exports = ListGroup;
 