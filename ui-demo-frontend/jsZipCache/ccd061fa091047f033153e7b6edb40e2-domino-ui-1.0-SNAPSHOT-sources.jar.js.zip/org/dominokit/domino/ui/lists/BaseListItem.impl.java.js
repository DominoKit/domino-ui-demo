/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.BaseListItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.BaseListItem$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
  */
class BaseListItem extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {C_T} */
    this.f_element__org_dominokit_domino_ui_lists_BaseListItem_;
    /** @public {HTMLHeadingElement} */
    this.f_header__org_dominokit_domino_ui_lists_BaseListItem_;
    /** @public {HTMLParagraphElement} */
    this.f_body__org_dominokit_domino_ui_lists_BaseListItem_;
  }
  
  /**
   * Factory method corresponding to constructor 'BaseListItem(Element)'.
   * @template C_T
   * @param {C_T} element
   * @return {!BaseListItem<C_T>}
   * @public
   */
  static $create__elemental2_dom_Element(element) {
    BaseListItem.$clinit();
    let $instance = new BaseListItem();
    $instance.$ctor__org_dominokit_domino_ui_lists_BaseListItem__elemental2_dom_Element(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BaseListItem(Element)'.
   * @param {C_T} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_BaseListItem__elemental2_dom_Element(element) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_dominokit_domino_ui_lists_BaseListItem_ = element;
  }
  
  /**
   * @param {?string} heading
   * @return {void}
   * @public
   */
  m_setHeaderText__java_lang_String_$pp_org_dominokit_domino_ui_lists(heading) {
    if (Objects.m_isNull__java_lang_Object(this.f_header__org_dominokit_domino_ui_lists_BaseListItem_)) {
      this.f_body__org_dominokit_domino_ui_lists_BaseListItem_ = /**@type {HTMLParagraphElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(Elements.m_p__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list-group-item-text"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
      this.f_body__org_dominokit_domino_ui_lists_BaseListItem_.innerHTML = /**@type {Element} */ (this.f_element__org_dominokit_domino_ui_lists_BaseListItem_).innerHTML;
      ElementUtil.m_clear__elemental2_dom_Element(this.f_element__org_dominokit_domino_ui_lists_BaseListItem_);
      this.f_header__org_dominokit_domino_ui_lists_BaseListItem_ = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list-group-item-heading"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLHeadingElement_$Overlay));
      this.f_header__org_dominokit_domino_ui_lists_BaseListItem_.textContent = heading;
      /**@type {Element} */ (this.f_element__org_dominokit_domino_ui_lists_BaseListItem_).appendChild(this.f_header__org_dominokit_domino_ui_lists_BaseListItem_);
      /**@type {Element} */ (this.f_element__org_dominokit_domino_ui_lists_BaseListItem_).appendChild(this.f_body__org_dominokit_domino_ui_lists_BaseListItem_);
    } else {
      this.f_header__org_dominokit_domino_ui_lists_BaseListItem_.textContent = heading;
    }
  }
  
  /**
   * @param {?string} content
   * @return {void}
   * @public
   */
  m_setBodyText__java_lang_String_$pp_org_dominokit_domino_ui_lists(content) {
    if (Objects.m_isNull__java_lang_Object(this.f_body__org_dominokit_domino_ui_lists_BaseListItem_)) {
      /**@type {Element} */ (this.f_element__org_dominokit_domino_ui_lists_BaseListItem_).textContent = content;
    } else {
      this.f_body__org_dominokit_domino_ui_lists_BaseListItem_.textContent = content;
    }
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_ui_lists_BaseListItem_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseListItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseListItem);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseListItem.$clinit = function() {};
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseListItem, $Util.$makeClassName('org.dominokit.domino.ui.lists.BaseListItem'));




exports = BaseListItem; 
//# sourceMappingURL=BaseListItem.js.map