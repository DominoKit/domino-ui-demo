/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.ListGroup$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasMultiSelectSupport = goog.require('org.dominokit.domino.ui.utils.HasMultiSelectSupport$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let SelectionChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler$impl');
let ListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListItem$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasMultiSelectSupport<ListItem<C_T>>}
  */
class ListGroup extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_lists_ListGroup_;
    /** @public {List<ListItem<C_T>>} */
    this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_;
    /** @public {boolean} */
    this.f_multiSelect__org_dominokit_domino_ui_lists_ListGroup_ = false;
    /** @public {List<SelectionChangeHandler<C_T>>} */
    this.f_selectionHandlers__org_dominokit_domino_ui_lists_ListGroup_;
    /** @public {boolean} */
    this.f_selectable__org_dominokit_domino_ui_lists_ListGroup_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'ListGroup(HTMLDivElement)'.
   * @template C_T
   * @param {HTMLDivElement} element
   * @return {!ListGroup<C_T>}
   * @public
   */
  static $create__elemental2_dom_HTMLDivElement(element) {
    ListGroup.$clinit();
    let $instance = new ListGroup();
    $instance.$ctor__org_dominokit_domino_ui_lists_ListGroup__elemental2_dom_HTMLDivElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListGroup(HTMLDivElement)'.
   * @param {HTMLDivElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_ListGroup__elemental2_dom_HTMLDivElement(element) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_lists_ListGroup();
    this.f_element__org_dominokit_domino_ui_lists_ListGroup_ = element;
  }
  
  /**
   * @template M_T
   * @return {ListGroup<M_T>}
   * @public
   */
  static m_create__() {
    ListGroup.$clinit();
    return /**@type {!ListGroup<*>} */ (ListGroup.$create__elemental2_dom_HTMLDivElement(/**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay))));
  }
  
  /**
   * @param {C_T} value
   * @return {ListItem<C_T>}
   * @public
   */
  m_addItem__java_lang_Object(value) {
    let listItem = /**@type {ListItem<C_T>} */ (ListItem.m_create__org_dominokit_domino_ui_utils_HasMultiSelectSupport__java_lang_Object(this, value));
    this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.add(listItem);
    this.m_asElement__().appendChild(listItem.m_asElement__());
    return listItem;
  }
  
  /**
   * @param {C_T} value
   * @param {?string} text
   * @return {ListItem<C_T>}
   * @public
   */
  m_addItem__java_lang_Object__java_lang_String(value, text) {
    let listItem = /**@type {ListItem<C_T>} */ (ListItem.m_create__org_dominokit_domino_ui_utils_HasMultiSelectSupport__java_lang_Object(this, value));
    listItem.m_setText__java_lang_String(text);
    this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.add(listItem);
    this.m_asElement__().appendChild(listItem.m_asElement__());
    return listItem;
  }
  
  /**
   * @param {ListItem<C_T>} listItem
   * @return {ListGroup<C_T>}
   * @public
   */
  m_appendItem__org_dominokit_domino_ui_lists_ListItem(listItem) {
    this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.add(listItem);
    this.m_asElement__().appendChild(listItem.m_asElement__());
    listItem.m_setParent__org_dominokit_domino_ui_utils_HasMultiSelectSupport_$pp_org_dominokit_domino_ui_lists(this);
    return this;
  }
  
  /**
   * @param {C_T} value
   * @param {?string} text
   * @return {ListItem<C_T>}
   * @public
   */
  m_createItem__java_lang_Object__java_lang_String(value, text) {
    let listItem = /**@type {ListItem<C_T>} */ (ListItem.m_create__org_dominokit_domino_ui_utils_HasMultiSelectSupport__java_lang_Object(this, value));
    listItem.m_setText__java_lang_String(text);
    return listItem;
  }
  
  /**
   * @return {ListGroup<C_T>}
   * @public
   */
  m_multiSelect__() {
    this.m_setMultiSelect__boolean(true);
    return this;
  }
  
  /**
   * @override
   * @return {List<ListItem<C_T>>}
   * @public
   */
  m_getSelectedItems__() {
    return /**@type {List<ListItem<C_T>>} */ ($Casts.$to(this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** ListItem<*> */ arg0) =>{
      return arg0.m_isSelected__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<ListItem<C_T>, ?, List<ListItem<C_T>>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getSelectedValues__() {
    let selectedItems = this.m_getSelectedItems__();
    if (selectedItems.isEmpty()) {
      return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
    } else {
      return /**@type {List<C_T>} */ ($Casts.$to(/**@type {Stream<C_T>} */ (selectedItems.m_stream__().m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** ListItem<*> */ i) =>{
        return i.m_getValue__();
      })))).m_collect__java_util_stream_Collector(/**@type {Collector<C_T, ?, List<C_T>>} */ (Collectors.m_toList__())), List));
    }
  }
  
  /**
   * @return {ListGroup<C_T>}
   * @public
   */
  m_removeSelected__() {
    this.m_getSelectedItems__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ListItem<*> */ item) =>{
      this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.remove(item);
      item.m_asElement__().remove();
    })));
    return this;
  }
  
  /**
   * @param {ListItem<C_T>} listItem
   * @return {ListGroup<C_T>}
   * @public
   */
  m_removeItem__org_dominokit_domino_ui_lists_ListItem(listItem) {
    if (this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.contains(listItem)) {
      this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_.remove(listItem);
      listItem.m_asElement__().remove();
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSelectable__() {
    return this.f_selectable__org_dominokit_domino_ui_lists_ListGroup_;
  }
  
  /**
   * @param {boolean} selectable
   * @return {void}
   * @public
   */
  m_setSelectable__boolean(selectable) {
    this.f_selectable__org_dominokit_domino_ui_lists_ListGroup_ = selectable;
    for (let $iterator = this.m_getSelectedItems__().m_iterator__(); $iterator.m_hasNext__(); ) {
      let listItem = /**@type {ListItem<C_T>} */ ($Casts.$to($iterator.m_next__(), ListItem));
      if (!selectable) {
        listItem.m_deselect__boolean(true);
      }
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isMultiSelect__() {
    return this.f_multiSelect__org_dominokit_domino_ui_lists_ListGroup_;
  }
  
  /**
   * @override
   * @param {boolean} multiSelect
   * @return {void}
   * @public
   */
  m_setMultiSelect__boolean(multiSelect) {
    this.f_multiSelect__org_dominokit_domino_ui_lists_ListGroup_ = multiSelect;
  }
  
  /**
   * @override
   * @return {List<ListItem<C_T>>}
   * @public
   */
  m_getItems__() {
    return this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_lists_ListGroup_;
  }
  
  /**
   * @param {ListItem<C_T>} source
   * @return {void}
   * @public
   */
  m_onSelectionChange__org_dominokit_domino_ui_lists_ListItem(source) {
    if (this.f_selectable__org_dominokit_domino_ui_lists_ListGroup_) {
      for (let i = 0; i < this.f_selectionHandlers__org_dominokit_domino_ui_lists_ListGroup_.size(); i++) {
        /**@type {SelectionChangeHandler<C_T>} */ ($Casts.$to(this.f_selectionHandlers__org_dominokit_domino_ui_lists_ListGroup_.getAtIndex(i), SelectionChangeHandler)).m_onSelectionChanged__org_dominokit_domino_ui_lists_ListItem(source);
      }
    }
  }
  
  /**
   * @param {SelectionChangeHandler<C_T>} selectionChangeHandler
   * @return {ListGroup<C_T>}
   * @public
   */
  m_addSelectionChangeHandler__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler(selectionChangeHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_lists_ListGroup_.add(selectionChangeHandler);
    return this;
  }
  
  /**
   * @param {SelectionChangeHandler<C_T>} selectionChangeHandler
   * @return {ListGroup<C_T>}
   * @public
   */
  m_removeSelectionChangeHandler__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler(selectionChangeHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_lists_ListGroup_.remove(selectionChangeHandler);
    return this;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {void}
   * @public
   */
  m_deselectAll__() {
    HasMultiSelectSupport.m_deselectAll__$default__org_dominokit_domino_ui_utils_HasMultiSelectSupport(this);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {void}
   * @public
   */
  m_selectAll__() {
    HasMultiSelectSupport.m_selectAll__$default__org_dominokit_domino_ui_utils_HasMultiSelectSupport(this);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_onSelectionChange__java_lang_Object(arg0) {
    this.m_onSelectionChange__org_dominokit_domino_ui_lists_ListItem(/**@type {ListItem<C_T>} */ ($Casts.$to(arg0, ListItem)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_lists_ListGroup() {
    this.f_allItems__org_dominokit_domino_ui_lists_ListGroup_ = /**@type {!LinkedList<ListItem<C_T>>} */ (LinkedList.$create__());
    this.f_multiSelect__org_dominokit_domino_ui_lists_ListGroup_ = false;
    this.f_selectionHandlers__org_dominokit_domino_ui_lists_ListGroup_ = /**@type {!ArrayList<SelectionChangeHandler<C_T>>} */ (ArrayList.$create__());
    this.f_selectable__org_dominokit_domino_ui_lists_ListGroup_ = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListGroup);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListGroup.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    List = goog.module.get('java.util.List$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    SelectionChangeHandler = goog.module.get('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler$impl');
    ListItem = goog.module.get('org.dominokit.domino.ui.lists.ListItem$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    HasMultiSelectSupport.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ListGroup, $Util.$makeClassName('org.dominokit.domino.ui.lists.ListGroup'));


IsElement.$markImplementor(ListGroup);
HasMultiSelectSupport.$markImplementor(ListGroup);


exports = ListGroup; 
//# sourceMappingURL=ListGroup.js.map