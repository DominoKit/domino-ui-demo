/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.ListItem$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseListItem = goog.require('org.dominokit.domino.ui.lists.BaseListItem$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let HTMLParagraphElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let ListGroupStyle = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroupStyle$impl');
let $LambdaAdaptor$39 = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListItem.$LambdaAdaptor$39$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let HasMultiSelectSupport = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasMultiSelectSupport$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Selectable.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseListItem<HTMLAnchorElement>}
 * @implements {IsElement<HTMLAnchorElement>}
 * @implements {HasValue<C_T>}
 * @implements {Selectable<ListItem<C_T>>}
 * @implements {HasBackground<ListItem<C_T>>}
 * @implements {Switchable<ListItem<C_T>>}
  */
class ListItem extends BaseListItem {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {C_T} */
    this.f_value__org_dominokit_domino_ui_lists_ListItem_;
    /** @public {HasMultiSelectSupport<ListItem<C_T>>} */
    this.f_parent__org_dominokit_domino_ui_lists_ListItem_;
    /** @public {boolean} */
    this.f_selected__org_dominokit_domino_ui_lists_ListItem_ = false;
    /** @public {boolean} */
    this.f_disabled__org_dominokit_domino_ui_lists_ListItem_ = false;
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_lists_ListItem_;
    /** @public {HTMLHeadingElement} */
    this.f_header__org_dominokit_domino_ui_lists_ListItem_;
    /** @public {HTMLParagraphElement} */
    this.f_body__org_dominokit_domino_ui_lists_ListItem_;
  }
  
  /**
   * Factory method corresponding to constructor 'ListItem(Object, HasMultiSelectSupport)'.
   * @template C_T
   * @param {C_T} value
   * @param {HasMultiSelectSupport<ListItem<C_T>>} parent
   * @return {!ListItem<C_T>}
   * @public
   */
  static $create__java_lang_Object__org_dominokit_domino_ui_utils_HasMultiSelectSupport(value, parent) {
    ListItem.$clinit();
    let $instance = new ListItem();
    $instance.$ctor__org_dominokit_domino_ui_lists_ListItem__java_lang_Object__org_dominokit_domino_ui_utils_HasMultiSelectSupport(value, parent);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ListItem(Object, HasMultiSelectSupport)'.
   * @param {C_T} value
   * @param {HasMultiSelectSupport<ListItem<C_T>>} parent
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_lists_ListItem__java_lang_Object__org_dominokit_domino_ui_utils_HasMultiSelectSupport(value, parent) {
    this.$ctor__org_dominokit_domino_ui_lists_BaseListItem__elemental2_dom_Element(/**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list-group-item"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay)));
    this.$init__org_dominokit_domino_ui_lists_ListItem();
    this.f_value__org_dominokit_domino_ui_lists_ListItem_ = value;
    this.f_parent__org_dominokit_domino_ui_lists_ListItem_ = parent;
    /**@type {HTMLAnchorElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).addEventListener("click", new $LambdaAdaptor$39(((/** Event */ e) =>{
      if (!this.f_disabled__org_dominokit_domino_ui_lists_ListItem_) {
        if (this.m_isSelected__()) {
          this.m_deselect__();
        } else {
          this.m_select__();
        }
      }
    })));
  }
  
  /**
   * @template M_T
   * @param {HasMultiSelectSupport<ListItem<M_T>>} parent
   * @param {M_T} value
   * @return {ListItem<M_T>}
   * @public
   */
  static m_create__org_dominokit_domino_ui_utils_HasMultiSelectSupport__java_lang_Object(parent, value) {
    ListItem.$clinit();
    return /**@type {!ListItem<*>} */ (ListItem.$create__java_lang_Object__org_dominokit_domino_ui_utils_HasMultiSelectSupport(value, parent));
  }
  
  /**
   * @override
   * @return {HTMLAnchorElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLAnchorElement} */ ($Casts.$to(this.m_getElement__(), $Overlay));
  }
  
  /**
   * @override
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
    this.f_value__org_dominokit_domino_ui_lists_ListItem_ = value;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_getValue__() {
    return this.f_value__org_dominokit_domino_ui_lists_ListItem_;
  }
  
  /**
   * @override
   * @return {ListItem<C_T>}
   * @public
   */
  m_select__() {
    return this.m_select__boolean(false);
  }
  
  /**
   * @override
   * @return {ListItem<C_T>}
   * @public
   */
  m_deselect__() {
    return this.m_deselect__boolean(false);
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {ListItem<C_T>}
   * @public
   */
  m_select__boolean(silent) {
    if (this.f_parent__org_dominokit_domino_ui_lists_ListItem_.m_isSelectable__()) {
      if (!this.f_parent__org_dominokit_domino_ui_lists_ListItem_.m_isMultiSelect__()) {
        this.f_parent__org_dominokit_domino_ui_lists_ListItem_.m_getItems__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ListItem<*> */ tListItem) =>{
          tListItem.m_deselect__boolean(true);
        })));
      }
      if (!this.f_selected__org_dominokit_domino_ui_lists_ListItem_) {
        this.m_asElement__().classList.add("active");
        this.f_selected__org_dominokit_domino_ui_lists_ListItem_ = true;
        if (!silent) {
          this.f_parent__org_dominokit_domino_ui_lists_ListItem_.m_onSelectionChange__java_lang_Object(this);
        }
      }
    }
    return this;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {ListItem<C_T>}
   * @public
   */
  m_deselect__boolean(silent) {
    if (this.f_selected__org_dominokit_domino_ui_lists_ListItem_) {
      this.m_asElement__().classList.remove("active");
      this.f_selected__org_dominokit_domino_ui_lists_ListItem_ = false;
      if (!silent) {
        this.f_parent__org_dominokit_domino_ui_lists_ListItem_.m_onSelectionChange__java_lang_Object(this);
      }
    }
    return this;
  }
  
  /**
   * @override
   * @return {ListItem<C_T>}
   * @public
   */
  m_disable__() {
    if (!this.f_disabled__org_dominokit_domino_ui_lists_ListItem_) {
      this.m_deselect__();
      /**@type {HTMLAnchorElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).classList.add("disabled");
      this.f_disabled__org_dominokit_domino_ui_lists_ListItem_ = true;
    }
    return this;
  }
  
  /**
   * @override
   * @return {ListItem<C_T>}
   * @public
   */
  m_enable__() {
    if (this.f_disabled__org_dominokit_domino_ui_lists_ListItem_) {
      /**@type {HTMLAnchorElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).classList.remove("disabled");
      this.f_disabled__org_dominokit_domino_ui_lists_ListItem_ = false;
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return !this.f_disabled__org_dominokit_domino_ui_lists_ListItem_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isDisabled__() {
    return this.f_disabled__org_dominokit_domino_ui_lists_ListItem_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSelected__() {
    return this.f_selected__org_dominokit_domino_ui_lists_ListItem_;
  }
  
  /**
   * @param {ListGroupStyle} itemStyle
   * @return {ListItem<C_T>}
   * @public
   */
  m_setStyle__org_dominokit_domino_ui_lists_ListGroupStyle(itemStyle) {
    return this.m_setStyle__java_lang_String_$p_org_dominokit_domino_ui_lists_ListItem(itemStyle.m_getStyle__());
  }
  
  /**
   * @param {?string} itemStyle
   * @return {ListItem<C_T>}
   * @public
   */
  m_setStyle__java_lang_String_$p_org_dominokit_domino_ui_lists_ListItem(itemStyle) {
    if (Objects.m_nonNull__java_lang_Object(this.f_style__org_dominokit_domino_ui_lists_ListItem_)) {
      /**@type {HTMLAnchorElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).classList.remove(this.f_style__org_dominokit_domino_ui_lists_ListItem_);
    }
    /**@type {HTMLAnchorElement} */ ($Casts.$to(this.m_getElement__(), $Overlay)).classList.add(itemStyle);
    this.f_style__org_dominokit_domino_ui_lists_ListItem_ = itemStyle;
    return this;
  }
  
  /**
   * @return {ListItem<C_T>}
   * @public
   */
  m_success__() {
    this.m_setStyle__org_dominokit_domino_ui_lists_ListGroupStyle(ListGroupStyle.f_SUCCESS__org_dominokit_domino_ui_lists_ListGroupStyle);
    return this;
  }
  
  /**
   * @return {ListItem<C_T>}
   * @public
   */
  m_warning__() {
    this.m_setStyle__org_dominokit_domino_ui_lists_ListGroupStyle(ListGroupStyle.f_WARNING__org_dominokit_domino_ui_lists_ListGroupStyle);
    return this;
  }
  
  /**
   * @return {ListItem<C_T>}
   * @public
   */
  m_info__() {
    this.m_setStyle__org_dominokit_domino_ui_lists_ListGroupStyle(ListGroupStyle.f_INFO__org_dominokit_domino_ui_lists_ListGroupStyle);
    return this;
  }
  
  /**
   * @return {ListItem<C_T>}
   * @public
   */
  m_error__() {
    this.m_setStyle__org_dominokit_domino_ui_lists_ListGroupStyle(ListGroupStyle.f_ERROR__org_dominokit_domino_ui_lists_ListGroupStyle);
    return this;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {ListItem<C_T>}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    this.m_setStyle__java_lang_String_$p_org_dominokit_domino_ui_lists_ListItem("list-group-" + j_l_String.m_valueOf__java_lang_Object(background.m_getBackground__()));
    return this;
  }
  
  /**
   * @param {?string} heading
   * @return {ListItem<C_T>}
   * @public
   */
  m_setHeading__java_lang_String(heading) {
    this.m_setHeaderText__java_lang_String_$pp_org_dominokit_domino_ui_lists(heading);
    return this;
  }
  
  /**
   * @param {?string} content
   * @return {ListItem<C_T>}
   * @public
   */
  m_setText__java_lang_String(content) {
    this.m_setBodyText__java_lang_String_$pp_org_dominokit_domino_ui_lists(content);
    return this;
  }
  
  /**
   * @param {Node} node
   * @return {ListItem<C_T>}
   * @public
   */
  m_appendContent__elemental2_dom_Node(node) {
    this.m_asElement__().appendChild(node);
    return this;
  }
  
  /**
   * @param {HasMultiSelectSupport<ListItem<C_T>>} parent
   * @return {void}
   * @public
   */
  m_setParent__org_dominokit_domino_ui_utils_HasMultiSelectSupport_$pp_org_dominokit_domino_ui_lists(parent) {
    this.f_parent__org_dominokit_domino_ui_lists_ListItem_ = parent;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {SelectionHandler<ListItem<C_T>>} arg0
   * @return {void}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(arg0) {
    Selectable.m_addSelectionHandler__$default__org_dominokit_domino_ui_utils_Selectable__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(this, arg0);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_lists_ListItem() {
    this.f_selected__org_dominokit_domino_ui_lists_ListItem_ = false;
    this.f_disabled__org_dominokit_domino_ui_lists_ListItem_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListItem);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ListItem.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    ListGroupStyle = goog.module.get('org.dominokit.domino.ui.lists.ListGroupStyle$impl');
    $LambdaAdaptor$39 = goog.module.get('org.dominokit.domino.ui.lists.ListItem.$LambdaAdaptor$39$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseListItem.$clinit();
    Selectable.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ListItem, $Util.$makeClassName('org.dominokit.domino.ui.lists.ListItem'));


IsElement.$markImplementor(ListItem);
HasValue.$markImplementor(ListItem);
Selectable.$markImplementor(ListItem);
HasBackground.$markImplementor(ListItem);
Switchable.$markImplementor(ListItem);


exports = ListItem; 
//# sourceMappingURL=ListItem.js.map