/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.LoaderEffect.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.LoaderEffect$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<LoaderEffect>}
  */
class LoaderEffect extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LoaderEffect(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!LoaderEffect}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new LoaderEffect();
    $instance.$ctor__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoaderEffect(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_loaders_LoaderEffect__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!LoaderEffect}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    LoaderEffect.$clinit();
    if ($Equality.$same(LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_, null)) {
      LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_ = $Enums.createMapFromValues(LoaderEffect.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_);
  }
  
  /**
   * @return {!Array<!LoaderEffect>}
   * @public
   */
  static m_values__() {
    LoaderEffect.$clinit();
    return /**@type {!Array<LoaderEffect>} */ ($Arrays.$init([LoaderEffect.$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect, LoaderEffect.$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect], LoaderEffect));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {LoaderEffect} */ ($Casts.$to(arg0, LoaderEffect)));
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {!LoaderEffect}
   * @public
   */
  static get f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect);
  }
  
  /**
   * @param {!LoaderEffect} value
   * @return {void}
   * @public
   */
  static set f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect = value);
  }
  
  /**
   * @return {Map<?string, !LoaderEffect>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_() {
    return (LoaderEffect.$clinit(), LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_);
  }
  
  /**
   * @param {Map<?string, !LoaderEffect>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_(value) {
    (LoaderEffect.$clinit(), LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoaderEffect;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoaderEffect);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoaderEffect.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    LoaderEffect.$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("BOUNCE"), LoaderEffect.$ordinal$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("ROTATE_PLANE"), LoaderEffect.$ordinal$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("STRETCH"), LoaderEffect.$ordinal$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("ORBIT"), LoaderEffect.$ordinal$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("ROUND_BOUNCE"), LoaderEffect.$ordinal$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("WIN8"), LoaderEffect.$ordinal$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("WIN8_LINEAR"), LoaderEffect.$ordinal$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("IOS"), LoaderEffect.$ordinal$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("FACEBOOK"), LoaderEffect.$ordinal$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("ROTATION"), LoaderEffect.$ordinal$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("TIMER"), LoaderEffect.$ordinal$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect = LoaderEffect.$create__java_lang_String__int($Util.$makeEnumName("NONE"), LoaderEffect.$ordinal$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect);
    LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(LoaderEffect, $Util.$makeClassName('org.dominokit.domino.ui.loaders.LoaderEffect'));


/** @private {!LoaderEffect} */
LoaderEffect.$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {!LoaderEffect} */
LoaderEffect.$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect;


/** @private {Map<?string, !LoaderEffect>} */
LoaderEffect.$f_namesToValuesMap__org_dominokit_domino_ui_loaders_LoaderEffect_;


/** @public {number} @const */
LoaderEffect.$ordinal$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect = 0;


/** @public {number} @const */
LoaderEffect.$ordinal$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect = 1;


/** @public {number} @const */
LoaderEffect.$ordinal$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect = 2;


/** @public {number} @const */
LoaderEffect.$ordinal$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect = 3;


/** @public {number} @const */
LoaderEffect.$ordinal$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect = 4;


/** @public {number} @const */
LoaderEffect.$ordinal$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect = 5;


/** @public {number} @const */
LoaderEffect.$ordinal$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect = 6;


/** @public {number} @const */
LoaderEffect.$ordinal$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect = 7;


/** @public {number} @const */
LoaderEffect.$ordinal$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect = 8;


/** @public {number} @const */
LoaderEffect.$ordinal$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect = 9;


/** @public {number} @const */
LoaderEffect.$ordinal$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect = 10;


/** @public {number} @const */
LoaderEffect.$ordinal$f_NONE__org_dominokit_domino_ui_loaders_LoaderEffect = 11;




exports = LoaderEffect; 
//# sourceMappingURL=LoaderEffect.js.map