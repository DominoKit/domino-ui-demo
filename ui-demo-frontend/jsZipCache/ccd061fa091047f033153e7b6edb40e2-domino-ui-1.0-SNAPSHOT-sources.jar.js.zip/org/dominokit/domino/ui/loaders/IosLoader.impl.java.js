/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.IosLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.IosLoader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsLoader = goog.require('org.dominokit.domino.ui.loaders.IsLoader$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsLoader}
  */
class IosLoader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_loadingText__org_dominokit_domino_ui_loaders_IosLoader_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_loaders_IosLoader_;
  }
  
  /**
   * Factory method corresponding to constructor 'IosLoader()'.
   * @return {!IosLoader}
   * @public
   */
  static $create__() {
    IosLoader.$clinit();
    let $instance = new IosLoader();
    $instance.$ctor__org_dominokit_domino_ui_loaders_IosLoader__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IosLoader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_loaders_IosLoader__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_loaders_IosLoader();
  }
  
  /**
   * @return {IosLoader}
   * @public
   */
  static m_create__() {
    IosLoader.$clinit();
    return IosLoader.$create__();
  }
  
  /**
   * @override
   * @param {?string} text
   * @return {void}
   * @public
   */
  m_setLoadingText__java_lang_String(text) {
    this.f_loadingText__org_dominokit_domino_ui_loaders_IosLoader_.textContent = text;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_loaders_IosLoader_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_loaders_IosLoader() {
    this.f_loadingText__org_dominokit_domino_ui_loaders_IosLoader_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_text"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("color:#555"), HtmlContentBuilder)).m_textContent__java_lang_String("Loading..."), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_element__org_dominokit_domino_ui_loaders_IosLoader_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background: rgba(255, 255, 255, 0.9);"), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_content"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("margin-top: -38px;"), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress", "ios"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String(""), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem1"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem2"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem3"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem4"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem5"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem6"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem7"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem8"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem9"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem10"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem11"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_progress_elem12"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background-color:#555;"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_loadingText__org_dominokit_domino_ui_loaders_IosLoader_), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IosLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IosLoader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IosLoader.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    IsLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata(IosLoader, $Util.$makeClassName('org.dominokit.domino.ui.loaders.IosLoader'));


IsLoader.$markImplementor(IosLoader);


exports = IosLoader; 
//# sourceMappingURL=IosLoader.js.map