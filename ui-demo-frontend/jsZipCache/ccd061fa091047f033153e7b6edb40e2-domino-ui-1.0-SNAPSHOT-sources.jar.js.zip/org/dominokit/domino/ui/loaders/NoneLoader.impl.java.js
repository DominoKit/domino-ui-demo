/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.NoneLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.NoneLoader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsLoader = goog.require('org.dominokit.domino.ui.loaders.IsLoader$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsLoader}
  */
class NoneLoader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_loadingText__org_dominokit_domino_ui_loaders_NoneLoader_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_loaders_NoneLoader_;
  }
  
  /**
   * Factory method corresponding to constructor 'NoneLoader()'.
   * @return {!NoneLoader}
   * @public
   */
  static $create__() {
    NoneLoader.$clinit();
    let $instance = new NoneLoader();
    $instance.$ctor__org_dominokit_domino_ui_loaders_NoneLoader__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NoneLoader()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_loaders_NoneLoader__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_loaders_NoneLoader();
  }
  
  /**
   * @return {NoneLoader}
   * @public
   */
  static m_create__() {
    NoneLoader.$clinit();
    return NoneLoader.$create__();
  }
  
  /**
   * @override
   * @param {?string} text
   * @return {void}
   * @public
   */
  m_setLoadingText__java_lang_String(text) {
    this.f_loadingText__org_dominokit_domino_ui_loaders_NoneLoader_.textContent = text;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_loaders_NoneLoader_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_loaders_NoneLoader() {
    this.f_loadingText__org_dominokit_domino_ui_loaders_NoneLoader_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_text"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("color:#555;"), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_element__org_dominokit_domino_ui_loaders_NoneLoader_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("background: rgba(255, 255, 255, 0.9);"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["waitMe_content"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("margin-top: -18px;"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_loadingText__org_dominokit_domino_ui_loaders_NoneLoader_), IsElement))), HtmlContentBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NoneLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NoneLoader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NoneLoader.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    IsLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NoneLoader, $Util.$makeClassName('org.dominokit.domino.ui.loaders.NoneLoader'));


IsLoader.$markImplementor(NoneLoader);


exports = NoneLoader; 
//# sourceMappingURL=NoneLoader.js.map