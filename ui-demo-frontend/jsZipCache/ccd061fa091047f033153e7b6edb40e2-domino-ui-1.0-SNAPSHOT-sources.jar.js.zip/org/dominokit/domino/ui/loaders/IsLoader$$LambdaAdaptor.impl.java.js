/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.IsLoader$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.IsLoader.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsLoader = goog.require('org.dominokit.domino.ui.loaders.IsLoader$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsLoader}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():HTMLDivElement} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():HTMLDivElement} */
    this.f_$$fn__org_dominokit_domino_ui_loaders_IsLoader_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_loaders_IsLoader_$LambdaAdaptor__org_dominokit_domino_ui_loaders_IsLoader_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():HTMLDivElement} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_loaders_IsLoader_$LambdaAdaptor__org_dominokit_domino_ui_loaders_IsLoader_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_loaders_IsLoader_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    let /** ?function():HTMLDivElement */ $function;
    return /**@type {HTMLDivElement} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_ui_loaders_IsLoader_$LambdaAdaptor, $function()), $Overlay));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {?string} arg0
   * @return {void}
   * @public
   */
  m_setLoadingText__java_lang_String(arg0) {
    IsLoader.m_setLoadingText__$default__org_dominokit_domino_ui_loaders_IsLoader__java_lang_String(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    IsLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.loaders.IsLoader$$LambdaAdaptor'));


IsLoader.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=IsLoader$$LambdaAdaptor.js.map