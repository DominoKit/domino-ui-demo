/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.presenters.HomePresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.home.client.presenters.HomePresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let HomePresenter = goog.forwardDeclare('org.dominokit.domino.home.client.presenters.HomePresenter$impl');


/**
 * @extends {PresenterCommand<HomePresenter>}
  */
class HomePresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'HomePresenterCommand()'.
   * @return {!HomePresenterCommand}
   * @public
   */
  static $create__() {
    HomePresenterCommand.$clinit();
    let $instance = new HomePresenterCommand();
    $instance.$ctor__org_dominokit_domino_home_client_presenters_HomePresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HomePresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_home_client_presenters_HomePresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HomePresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HomePresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HomePresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HomePresenterCommand, $Util.$makeClassName('org.dominokit.domino.home.client.presenters.HomePresenterCommand'));




exports = HomePresenterCommand; 
//# sourceMappingURL=HomePresenterCommand.js.map