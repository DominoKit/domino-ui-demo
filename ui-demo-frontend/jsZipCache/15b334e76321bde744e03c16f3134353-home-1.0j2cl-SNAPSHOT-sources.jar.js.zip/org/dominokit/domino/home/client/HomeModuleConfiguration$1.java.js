/**
 * @fileoverview transpiled from org.dominokit.domino.home.client.HomeModuleConfiguration$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.home.client.HomeModuleConfiguration.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');
const _HomeModuleConfiguration = goog.require('org.dominokit.domino.home.client.HomeModuleConfiguration');
const _HomePresenter = goog.require('org.dominokit.domino.home.client.presenters.HomePresenter');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.home.client.HomeModuleConfiguration.$1$impl');
exports = $1;
 