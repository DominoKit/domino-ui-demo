package org.dominokit.domino.forms.client.views;

import org.dominokit.domino.api.client.mvp.view.ContentView;

public interface FormsView extends ContentView {
}