/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.views.FormsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.views.FormsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.forms.client.views.FormsView.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ContentView}
 */
class FormsView {
  /**
   * @param {?function():Content} fn
   * @return {FormsView}
   * @public
   */
  static $adapt(fn) {
    FormsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ContentView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_forms_client_views_FormsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_forms_client_views_FormsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_forms_client_views_FormsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsView.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.forms.client.views.FormsView.$LambdaAdaptor$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(FormsView, $Util.$makeClassName('org.dominokit.domino.forms.client.views.FormsView'));


FormsView.$markImplementor(/** @type {Function} */ (FormsView));


exports = FormsView; 
//# sourceMappingURL=FormsView.js.map