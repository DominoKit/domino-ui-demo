/**
 * @fileoverview transpiled from org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LayoutView = goog.require('org.dominokit.domino.layout.client.views.LayoutView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$1$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Layout = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {LayoutView}
  */
class LayoutViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Layout} */
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_;
    /** @public {Content} */
    this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'LayoutViewImpl()'.
   * @return {!LayoutViewImpl}
   * @public
   */
  static $create__() {
    LayoutViewImpl.$clinit();
    let $instance = new LayoutViewImpl();
    $instance.$ctor__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LayoutViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl();
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.style.background = "#e9e9e9";
  }
  
  /**
   * @override
   * @param {?string} iconName
   * @param {SelectionHandler} selectionHandler
   * @return {void}
   * @public
   */
  m_addActionItem__java_lang_String__org_dominokit_domino_layout_shared_extension_LayoutContext_SelectionHandler(iconName, selectionHandler) {
    let actionItem = this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_addActionItem__org_dominokit_domino_ui_icons_Icon(Icon.m_create__java_lang_String(iconName));
    actionItem.addEventListener("click", new $LambdaAdaptor$1(((/** Event */ evt) =>{
      selectionHandler.m_onSelected__();
    })));
  }
  
  /**
   * @override
   * @param {Content} content
   * @return {void}
   * @public
   */
  m_setRightPanelContent__org_dominokit_domino_api_shared_extension_Content(content) {
    if (Objects.m_nonNull__java_lang_Object(this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_) && !$Objects.m_equals__java_lang_Object__java_lang_Object(this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_, content)) {
      this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getRightPanel__().removeChild(/**@type {Node} */ ($Casts.$to(Js.m_cast__java_lang_Object(this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_get__()), Node_$Overlay)));
    }
    this.f_rightPanelContent__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_ = content;
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getRightPanel__().appendChild(/**@type {Node} */ ($Casts.$to(Js.m_cast__java_lang_Object(content.m_get__()), Node_$Overlay)));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_toggleRightPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_toggleRightPanel__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_toggleLeftPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_toggleLeftPanel__();
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_showLeftPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_showLeftPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_hideLeftPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_hideLeftPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getRightPanel__() {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getRightPanel__();
    })), Content));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getLeftPanel__() {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getLeftPanel__();
    })), Content));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContentPanel__() {
    return /**@type {Content<HTMLDivElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getContentPanel__();
    })), Content));
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getTopBar__() {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_getTopBar__();
    })), Content));
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {IsLayout}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_setTitle__java_lang_String(title);
    return this;
  }
  
  /**
   * @override
   * @param {?string} icon
   * @return {Content}
   * @public
   */
  m_addActionItem__java_lang_String(icon) {
    return /**@type {Content<HTMLElement>} */ ($Casts.$to(Content.$adapt((() =>{
      return this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_addActionItem__org_dominokit_domino_ui_icons_Icon(Icon.m_create__java_lang_String(icon));
    })), Content));
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_show__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_show__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_showRightPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_showRightPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_hideRightPanel__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_hideRightPanel__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_fixLeftPanelPosition__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_fixLeftPanelPosition__();
    return this;
  }
  
  /**
   * @override
   * @return {IsLayout}
   * @public
   */
  m_unfixLeftPanelPosition__() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_.m_unfixLeftPanelPosition__();
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl() {
    this.f_layout__org_dominokit_domino_layout_client_ui_views_LayoutViewImpl_ = Layout.$create__().m_setTitle__java_lang_String("Domino UI demo");
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LayoutViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LayoutViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Node_$Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    Content = goog.module.get('org.dominokit.domino.api.shared.extension.Content$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl.$LambdaAdaptor$1$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Layout = goog.module.get('org.dominokit.domino.ui.layout.Layout$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LayoutViewImpl, $Util.$makeClassName('org.dominokit.domino.layout.client.ui.views.LayoutViewImpl'));


LayoutView.$markImplementor(LayoutViewImpl);


exports = LayoutViewImpl; 
//# sourceMappingURL=LayoutViewImpl.js.map