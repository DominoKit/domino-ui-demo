package org.dominokit.domino.layout.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.layout.client.presenters.LayoutPresenter;
import org.dominokit.domino.layout.client.ui.views.LayoutViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class LayoutUIModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(LayoutPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new LayoutViewImpl();
      }
    });
  }
}
