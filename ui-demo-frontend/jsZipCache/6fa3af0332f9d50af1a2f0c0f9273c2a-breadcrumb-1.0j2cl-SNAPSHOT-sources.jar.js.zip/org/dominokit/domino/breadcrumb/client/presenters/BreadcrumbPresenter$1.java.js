/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _BreadcrumbPresenter = goog.require('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter');
const _BreadcrumbView = goog.require('org.dominokit.domino.breadcrumb.client.views.BreadcrumbView');
const _ComponentRemoveHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler');
const _ComponentRevealedHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.breadcrumb.client.presenters.BreadcrumbPresenter.$1$impl');
exports = $1;
 