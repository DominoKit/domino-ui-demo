/**
 * @fileoverview transpiled from org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl$$LambdaAdaptor$18.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl.$LambdaAdaptor$18$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$18 extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor$18($JsFunction)'.
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$18.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_$LambdaAdaptor$18;
    this.$ctor__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_$LambdaAdaptor$18__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor$18($JsFunction)'.
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_$LambdaAdaptor$18__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_$LambdaAdaptor$18 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_breadcrumb_client_views_ui_BreadcrumbViewImpl_$LambdaAdaptor$18;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$18;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$18);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$18.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$18, $Util.$makeClassName('org.dominokit.domino.breadcrumb.client.views.ui.BreadcrumbViewImpl$$LambdaAdaptor$18'));




exports = $LambdaAdaptor$18; 
//# sourceMappingURL=BreadcrumbViewImpl$$LambdaAdaptor$18.js.map