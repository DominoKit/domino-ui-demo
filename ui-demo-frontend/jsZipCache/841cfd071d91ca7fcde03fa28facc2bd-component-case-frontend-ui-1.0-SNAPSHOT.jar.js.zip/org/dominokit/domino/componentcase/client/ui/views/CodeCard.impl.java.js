/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.CodeCard.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let ClipboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.ClipboardEvent.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLInputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard.$LambdaAdaptor$2$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Code = goog.forwardDeclare('org.dominokit.domino.ui.code.Code$impl');
let Block = goog.forwardDeclare('org.dominokit.domino.ui.code.Code.Block$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Response = goog.forwardDeclare('org.dominokit.rest.shared.Response$impl');
let RestfulRequest = goog.forwardDeclare('org.dominokit.rest.shared.RestfulRequest$impl');
let SuccessHandler = goog.forwardDeclare('org.dominokit.rest.shared.RestfulRequest.SuccessHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let InputType = goog.forwardDeclare('org.jboss.gwt.elemento.core.InputType$impl');
let InputBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, CodeCard>}
  */
class CodeCard extends BaseDominoElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLInputElement} */
    this.f_copyInput__org_dominokit_domino_componentcase_client_ui_views_CodeCard_;
    /** @public {?string} */
    this.f_code__org_dominokit_domino_componentcase_client_ui_views_CodeCard_;
    /** @public {Block} */
    this.f_codeBlock__org_dominokit_domino_componentcase_client_ui_views_CodeCard_;
    /** @public {Card} */
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_;
  }
  
  /**
   * Factory method corresponding to constructor 'CodeCard()'.
   * @return {!CodeCard}
   * @public
   */
  static $create__() {
    CodeCard.$clinit();
    let $instance = new CodeCard();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ui_views_CodeCard__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeCard()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ui_views_CodeCard__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_componentcase_client_ui_views_CodeCard();
    this.f_copyInput__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.value = this.f_code__org_dominokit_domino_componentcase_client_ui_views_CodeCard_;
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_addHeaderAction__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(/**@type {BaseIcon<BaseIcon>} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_content_copy__().m_setTooltip__java_lang_String("Copy code"), BaseIcon)), new $LambdaAdaptor$2(((/** Event */ evt) =>{
      this.f_copyInput__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.select();
      let copyListener = new $LambdaAdaptor$1(((/** Event */ e) =>{
        let clipboardEvent = /**@type {ClipboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(e));
        clipboardEvent.clipboardData.setData("text/plain", this.f_code__org_dominokit_domino_componentcase_client_ui_views_CodeCard_);
        e.preventDefault();
      }));
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.addEventListener("copy", copyListener);
      window.document.execCommand("copy");
      $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.removeEventListener("copy", copyListener);
      Notification.m_createInfo__java_lang_String("Code copied to clipboard").m_show__();
    })));
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_appendChild__elemental2_dom_Node(this.f_copyInput__org_dominokit_domino_componentcase_client_ui_views_CodeCard_);
  }
  
  /**
   * @param {?string} code
   * @return {CodeCard}
   * @public
   */
  static m_createCodeCard__java_lang_String(code) {
    CodeCard.$clinit();
    let codeCard = CodeCard.$create__();
    codeCard.f_codeBlock__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_setCode__java_lang_String(code);
    codeCard.f_code__org_dominokit_domino_componentcase_client_ui_views_CodeCard_ = code;
    return codeCard;
  }
  
  /**
   * @param {?string} moduleName
   * @param {?string} fileName
   * @return {CodeCard}
   * @public
   */
  static m_createCodeCard__java_lang_String__java_lang_String(moduleName, fileName) {
    CodeCard.$clinit();
    let codeCard = CodeCard.$create__();
    RestfulRequest.m_get__java_lang_String("https://raw.githubusercontent.com/DominoKit/domino-ui-demo/master/" + j_l_String.m_valueOf__java_lang_Object(moduleName) + "/src/main/java/org/dominokit/domino/" + j_l_String.m_valueOf__java_lang_Object(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(moduleName, "-", "")) + "/client/views/" + j_l_String.m_valueOf__java_lang_Object(fileName) + ".txt").m_onSuccess__org_dominokit_rest_shared_RestfulRequest_SuccessHandler(SuccessHandler.$adapt(((/** Response */ response) =>{
      codeCard.f_codeBlock__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_setCode__java_lang_String(response.m_getBodyAsString__());
      codeCard.f_code__org_dominokit_domino_componentcase_client_ui_views_CodeCard_ = response.m_getBodyAsString__();
    }))).m_send__();
    return codeCard;
  }
  
  /**
   * @param {?string} title
   * @return {CodeCard}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_setTitle__java_lang_String(title);
    return this;
  }
  
  /**
   * @param {?string} description
   * @return {CodeCard}
   * @public
   */
  m_setDescription__java_lang_String(description) {
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_setDescription__java_lang_String(description);
    return this;
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_getCard__() {
    return this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_;
  }
  
  /**
   * @override
   * @return {CodeCard}
   * @public
   */
  m_expand__() {
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_expand__();
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_.m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_componentcase_client_ui_views_CodeCard() {
    this.f_copyInput__org_dominokit_domino_componentcase_client_ui_views_CodeCard_ = /**@type {HTMLInputElement} */ ($Casts.$to(/**@type {InputBuilder<HTMLInputElement>} */ ($Casts.$to(Elements.m_input__org_jboss_gwt_elemento_core_InputType(InputType.f_textarea__org_jboss_gwt_elemento_core_InputType).m_style__java_lang_String("visibility:hidden; width: 0px; height: 0px;"), InputBuilder)).m_asElement__(), HTMLInputElement_$Overlay));
    this.f_codeBlock__org_dominokit_domino_componentcase_client_ui_views_CodeCard_ = Code.m_block__();
    this.f_card__org_dominokit_domino_componentcase_client_ui_views_CodeCard_ = Card.m_create__java_lang_String("Source Code").m_setCollapsible__().m_collapse__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_codeBlock__org_dominokit_domino_componentcase_client_ui_views_CodeCard_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeCard;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeCard);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeCard.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLInputElement_$Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard.$LambdaAdaptor$2$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Code = goog.module.get('org.dominokit.domino.ui.code.Code$impl');
    BaseIcon = goog.module.get('org.dominokit.domino.ui.icons.BaseIcon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    RestfulRequest = goog.module.get('org.dominokit.rest.shared.RestfulRequest$impl');
    SuccessHandler = goog.module.get('org.dominokit.rest.shared.RestfulRequest.SuccessHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    InputType = goog.module.get('org.jboss.gwt.elemento.core.InputType$impl');
    InputBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseDominoElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeCard, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ui.views.CodeCard'));




exports = CodeCard; 
//# sourceMappingURL=CodeCard.js.map