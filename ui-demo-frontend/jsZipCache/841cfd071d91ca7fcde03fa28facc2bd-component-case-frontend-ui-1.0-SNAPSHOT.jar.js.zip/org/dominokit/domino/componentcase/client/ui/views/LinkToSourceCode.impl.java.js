/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode.$LambdaAdaptor$3$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, LinkToSourceCode>}
  */
class LinkToSourceCode extends BaseDominoElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode_;
  }
  
  /**
   * @param {?string} moduleName
   * @param {Class} impl
   * @return {LinkToSourceCode}
   * @public
   */
  static m_create__java_lang_String__java_lang_Class(moduleName, impl) {
    LinkToSourceCode.$clinit();
    return LinkToSourceCode.$create__java_lang_String__java_lang_Class(moduleName, impl);
  }
  
  /**
   * Factory method corresponding to constructor 'LinkToSourceCode(String, Class)'.
   * @param {?string} moduleName
   * @param {Class} impl
   * @return {!LinkToSourceCode}
   * @public
   */
  static $create__java_lang_String__java_lang_Class(moduleName, impl) {
    LinkToSourceCode.$clinit();
    let $instance = new LinkToSourceCode();
    $instance.$ctor__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode__java_lang_String__java_lang_Class(moduleName, impl);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LinkToSourceCode(String, Class)'.
   * @param {?string} moduleName
   * @param {Class} impl
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode__java_lang_String__java_lang_Class(moduleName, impl) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode();
    let fullClassName = j_l_String.m_valueOf__java_lang_Object(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(impl.m_getCanonicalName__(), ".", "/")) + ".java";
    this.f_element__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode_.addEventListener("click", new $LambdaAdaptor$3(((/** Event */ evt) =>{
      window.window.open("https://github.com/DominoKit/domino-ui-demo/blob/master/" + j_l_String.m_valueOf__java_lang_Object(moduleName) + "/src/main/java/" + j_l_String.m_valueOf__java_lang_Object(fullClassName));
    })));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode() {
    this.f_element__org_dominokit_domino_componentcase_client_ui_views_LinkToSourceCode_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["open-source", "bg-theme", Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_code__()), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String("Source code"), IsElement))), HtmlContentBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LinkToSourceCode;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LinkToSourceCode);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LinkToSourceCode.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode.$LambdaAdaptor$3$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BaseDominoElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LinkToSourceCode, $Util.$makeClassName('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode'));




exports = LinkToSourceCode; 
//# sourceMappingURL=LinkToSourceCode.js.map