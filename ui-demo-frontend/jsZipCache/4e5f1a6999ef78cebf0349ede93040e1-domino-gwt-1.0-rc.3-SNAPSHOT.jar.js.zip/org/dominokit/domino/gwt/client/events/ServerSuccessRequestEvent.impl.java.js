/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Event = goog.require('org.dominokit.domino.api.client.events.Event$impl');
const ServerSuccessRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let EventProcessor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventProcessor$impl');
let ServerResponseReceivedStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext$impl');
let ServerSuccessRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');
let GWTRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.GWTRequestEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Event}
  */
class ServerSuccessRequestEvent extends ServerSuccessRequestGwtEvent {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ServerRequest} */
    this.f_request__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent;
    /** @public {ResponseBean} */
    this.f_responseBean__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_;
    /** @public {ClientApp} */
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_;
  }
  
  /**
   * Factory method corresponding to constructor 'ServerSuccessRequestEvent(ServerRequest, ResponseBean)'.
   * @param {ServerRequest} request
   * @param {ResponseBean} responseBean
   * @return {!ServerSuccessRequestEvent}
   * @public
   */
  static $create__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(request, responseBean) {
    ServerSuccessRequestEvent.$clinit();
    let $instance = new ServerSuccessRequestEvent();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(request, responseBean);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerSuccessRequestEvent(ServerRequest, ResponseBean)'.
   * @param {ServerRequest} request
   * @param {ResponseBean} responseBean
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(request, responseBean) {
    this.$ctor__org_dominokit_domino_gwt_client_events_ServerSuccessRequestGwtEvent__();
    this.$init__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent();
    this.f_request__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent = request;
    this.f_responseBean__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_ = responseBean;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_fire__() {
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_.m_getEventsBus__().m_publishEvent__org_dominokit_domino_api_client_events_EventsBus_RequestEvent(GWTRequestEvent.$create__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent__org_dominokit_domino_gwt_client_events_ServerSuccessRequestGwtEvent(this, this));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_process__() {
    this.f_request__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent.m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(ServerResponseReceivedStateContext.$create__org_dominokit_domino_api_client_request_RequestStateContext(this.m_makeSuccessContext___$p_org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent()));
  }
  
  /**
   * @return {ServerSuccessRequestStateContext}
   * @public
   */
  m_makeSuccessContext___$p_org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent() {
    return ServerSuccessRequestStateContext.$create__org_dominokit_domino_api_shared_request_ResponseBean(this.f_responseBean__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_);
  }
  
  /**
   * @param {EventProcessor} eventProcessor
   * @return {void}
   * @public
   */
  m_dispatch__org_dominokit_domino_api_client_events_EventProcessor(eventProcessor) {
    eventProcessor.m_process__org_dominokit_domino_api_client_events_Event(this);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_dispatch__java_lang_Object(arg0) {
    this.m_dispatch__org_dominokit_domino_api_client_events_EventProcessor(/**@type {EventProcessor} */ ($Casts.$to(arg0, EventProcessor)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent() {
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ServerSuccessRequestEvent_ = ClientApp.m_make__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerSuccessRequestEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerSuccessRequestEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerSuccessRequestEvent.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    EventProcessor = goog.module.get('org.dominokit.domino.api.client.events.EventProcessor$impl');
    ServerResponseReceivedStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext$impl');
    ServerSuccessRequestStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext$impl');
    GWTRequestEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.GWTRequestEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ServerSuccessRequestGwtEvent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerSuccessRequestEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent'));


Event.$markImplementor(ServerSuccessRequestEvent);


exports = ServerSuccessRequestEvent; 
//# sourceMappingURL=ServerSuccessRequestEvent.js.map