/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.options.DefaultDominoOptions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.options.DefaultDominoOptions$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoOptions = goog.require('org.dominokit.domino.api.client.DominoOptions$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let CanSetDominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.CanSetDominoOptions$impl');
let DynamicServiceRoot = goog.forwardDeclare('org.dominokit.domino.api.client.DynamicServiceRoot$impl');


/**
 * @implements {DominoOptions}
  */
class DefaultDominoOptions extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_defaultServiceRoot__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_;
    /** @public {?string} */
    this.f_defaultJsonDateFormat__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_;
    /** @public {List<DynamicServiceRoot>} */
    this.f_dynamicServiceRoots__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_;
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultDominoOptions()'.
   * @return {!DefaultDominoOptions}
   * @public
   */
  static $create__() {
    DefaultDominoOptions.$clinit();
    let $instance = new DefaultDominoOptions();
    $instance.$ctor__org_dominokit_domino_gwt_client_options_DefaultDominoOptions__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultDominoOptions()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_options_DefaultDominoOptions__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_gwt_client_options_DefaultDominoOptions();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_applyOptions__() {
  }
  
  /**
   * @override
   * @param {?string} defaultServiceRoot
   * @return {CanSetDominoOptions}
   * @public
   */
  m_setDefaultServiceRoot__java_lang_String(defaultServiceRoot) {
    this.f_defaultServiceRoot__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_ = defaultServiceRoot;
    return this;
  }
  
  /**
   * @override
   * @param {?string} defaultJsonDateFormat
   * @return {CanSetDominoOptions}
   * @public
   */
  m_setDefaultJsonDateFormat__java_lang_String(defaultJsonDateFormat) {
    this.f_defaultJsonDateFormat__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_ = defaultJsonDateFormat;
    return this;
  }
  
  /**
   * @override
   * @param {DynamicServiceRoot} dynamicServiceRoot
   * @return {CanSetDominoOptions}
   * @public
   */
  m_addDynamicServiceRoot__org_dominokit_domino_api_client_DynamicServiceRoot(dynamicServiceRoot) {
    this.f_dynamicServiceRoots__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_.add(dynamicServiceRoot);
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getDefaultServiceRoot__() {
    return this.f_defaultServiceRoot__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getDefaultJsonDateFormat__() {
    return this.f_defaultJsonDateFormat__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_;
  }
  
  /**
   * @override
   * @return {List<DynamicServiceRoot>}
   * @public
   */
  m_getServiceRoots__() {
    return this.f_dynamicServiceRoots__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_gwt_client_options_DefaultDominoOptions() {
    this.f_defaultServiceRoot__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_ = "http://localhost:8080/service";
    this.f_defaultJsonDateFormat__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_ = null;
    this.f_dynamicServiceRoots__org_dominokit_domino_gwt_client_options_DefaultDominoOptions_ = /**@type {!ArrayList<DynamicServiceRoot>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultDominoOptions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultDominoOptions);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultDominoOptions.$clinit = function() {};
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DefaultDominoOptions, $Util.$makeClassName('org.dominokit.domino.gwt.client.options.DefaultDominoOptions'));


DominoOptions.$markImplementor(DefaultDominoOptions);


exports = DefaultDominoOptions; 
//# sourceMappingURL=DefaultDominoOptions.js.map