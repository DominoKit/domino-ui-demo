/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.SimpleEventsBus.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.SimpleEventsBus$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const EventsBus = goog.require('org.dominokit.domino.api.client.events.EventsBus$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Exception = goog.forwardDeclare('java.lang.Exception$impl');
let RequestEvent = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus.RequestEvent$impl');
let ClientRequestGwtEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent$impl');
let GwtEventProcessor = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.GwtEventProcessor$impl');
let ServerFailedRequestGwtEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent$impl');
let ServerSuccessRequestGwtEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent$impl');
let Event = goog.forwardDeclare('org.gwtproject.event.shared.Event$impl');
let EventBus = goog.forwardDeclare('org.gwtproject.event.shared.EventBus$impl');
let SimpleEventBus = goog.forwardDeclare('org.gwtproject.event.shared.SimpleEventBus$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


/**
 * @implements {EventsBus<Event<GwtEventProcessor>>}
  */
class SimpleEventsBus extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SimpleEventsBus(GwtEventProcessor)'.
   * @param {GwtEventProcessor} eventProcessor
   * @return {!SimpleEventsBus}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_events_GwtEventProcessor(eventProcessor) {
    SimpleEventsBus.$clinit();
    let $instance = new SimpleEventsBus();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_SimpleEventsBus__org_dominokit_domino_gwt_client_events_GwtEventProcessor(eventProcessor);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SimpleEventsBus(GwtEventProcessor)'.
   * @param {GwtEventProcessor} eventProcessor
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_SimpleEventsBus__org_dominokit_domino_gwt_client_events_GwtEventProcessor(eventProcessor) {
    this.$ctor__java_lang_Object__();
    SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_.m_addHandler__org_gwtproject_event_shared_Event_Type__java_lang_Object(ClientRequestGwtEvent.f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent, eventProcessor);
    SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_.m_addHandler__org_gwtproject_event_shared_Event_Type__java_lang_Object(ServerSuccessRequestGwtEvent.f_SERVER_SUCCESS_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerSuccessRequestGwtEvent, eventProcessor);
    SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_.m_addHandler__org_gwtproject_event_shared_Event_Type__java_lang_Object(ServerFailedRequestGwtEvent.f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent, eventProcessor);
  }
  
  /**
   * @override
   * @param {RequestEvent<Event<GwtEventProcessor>>} event
   * @return {void}
   * @public
   */
  m_publishEvent__org_dominokit_domino_api_client_events_EventsBus_RequestEvent(event) {
    try {
      SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_.m_fireEvent__org_gwtproject_event_shared_Event(/**@type {Event<*>} */ ($Casts.$to(event.m_asEvent__(), Event)));
    } catch (__$exc) {
      __$exc = $Exceptions.toJava(__$exc);
      if (Exception.$isInstance(__$exc)) {
        let ex = /**@type {Exception} */ (__$exc);
        SimpleEventsBus.$f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_.m_error__java_lang_String__java_lang_Throwable("could not publish event", ex);
      } else {
        throw $Exceptions.toJs(__$exc);
      }
    }
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_() {
    return (SimpleEventsBus.$clinit(), SimpleEventsBus.$f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_(value) {
    (SimpleEventsBus.$clinit(), SimpleEventsBus.$f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_ = value);
  }
  
  /**
   * @return {EventBus}
   * @public
   */
  static get f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_() {
    return (SimpleEventsBus.$clinit(), SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_);
  }
  
  /**
   * @param {EventBus} value
   * @return {void}
   * @public
   */
  static set f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_(value) {
    (SimpleEventsBus.$clinit(), SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SimpleEventsBus;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SimpleEventsBus);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SimpleEventsBus.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Exception = goog.module.get('java.lang.Exception$impl');
    ClientRequestGwtEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent$impl');
    ServerFailedRequestGwtEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent$impl');
    ServerSuccessRequestGwtEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent$impl');
    Event = goog.module.get('org.gwtproject.event.shared.Event$impl');
    SimpleEventBus = goog.module.get('org.gwtproject.event.shared.SimpleEventBus$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    j_l_Object.$clinit();
    SimpleEventsBus.$f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SimpleEventsBus));
    SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_ = SimpleEventBus.$create__();
  }
  
  
};

$Util.$setClassMetadata(SimpleEventsBus, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.SimpleEventsBus'));


/** @private {Logger} */
SimpleEventsBus.$f_LOGGER__org_dominokit_domino_gwt_client_events_SimpleEventsBus_;


/** @private {EventBus} */
SimpleEventsBus.$f_simpleGwtEventsBus__org_dominokit_domino_gwt_client_events_SimpleEventsBus_;


EventsBus.$markImplementor(SimpleEventsBus);


exports = SimpleEventsBus; 
//# sourceMappingURL=SimpleEventsBus.js.map