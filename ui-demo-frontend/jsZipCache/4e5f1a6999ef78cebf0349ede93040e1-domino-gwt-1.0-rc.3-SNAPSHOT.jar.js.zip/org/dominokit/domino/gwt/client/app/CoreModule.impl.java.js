/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.app.CoreModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.app.CoreModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ClientAppBuilder = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.ClientAppBuilder$impl');
let CoreMainExtensionPoint = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint$impl');
let InMemoryDominoEventsListenerRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$impl');
let InMemoryPresentersRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository$impl');
let InMemoryViewRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository$impl');
let ClientRouter = goog.forwardDeclare('org.dominokit.domino.client.commons.request.ClientRouter$impl');
let InMemoryCommandsRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository$impl');
let InMemoryRequestRestSendersRepository = goog.forwardDeclare('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository$impl');
let ServerRouter = goog.forwardDeclare('org.dominokit.domino.client.commons.request.ServerRouter$impl');
let GwtAsyncRunner = goog.forwardDeclare('org.dominokit.domino.gwt.client.async.GwtAsyncRunner$impl');
let ClientEventFactory = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ClientEventFactory$impl');
let RequestEventProcessor = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.RequestEventProcessor$impl');
let ServerEventFactory = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerEventFactory$impl');
let SimpleEventsBus = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.SimpleEventsBus$impl');
let StateHistory = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory$impl');
let DefaultDominoOptions = goog.forwardDeclare('org.dominokit.domino.gwt.client.options.DefaultDominoOptions$impl');
let GwtRequestAsyncSender = goog.forwardDeclare('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$impl');


class CoreModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CoreModule()'.
   * @return {!CoreModule}
   * @public
   */
  static $create__() {
    CoreModule.$clinit();
    let $instance = new CoreModule();
    $instance.$ctor__org_dominokit_domino_gwt_client_app_CoreModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CoreModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_app_CoreModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static m_init__() {
    CoreModule.$clinit();
    let clientRouter = ClientRouter.$create__org_dominokit_domino_api_client_events_ClientRequestEventFactory(ClientEventFactory.$create__());
    let serverRouter = ServerRouter.$create__org_dominokit_domino_client_commons_request_RequestAsyncSender(GwtRequestAsyncSender.$create__org_dominokit_domino_api_client_events_ServerRequestEventFactory(ServerEventFactory.$create__()));
    let requestEventProcessor = RequestEventProcessor.$create__();
    let eventBus = SimpleEventsBus.$create__org_dominokit_domino_gwt_client_events_GwtEventProcessor(requestEventProcessor);
    ClientAppBuilder.m_clientRouter__org_dominokit_domino_api_client_request_RequestRouter(clientRouter).m_serverRouter__org_dominokit_domino_api_client_request_RequestRouter(serverRouter).m_eventsBus__org_dominokit_domino_api_client_events_EventsBus(eventBus).m_requestRepository__org_dominokit_domino_api_client_request_CommandsRepository(InMemoryCommandsRepository.$create__()).m_presentersRepository__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository(InMemoryPresentersRepository.$create__()).m_viewsRepository__org_dominokit_domino_api_client_mvp_view_ViewsRepository(InMemoryViewRepository.$create__()).m_eventsListenersRepository__org_dominokit_domino_api_client_extension_DominoEventsListenersRepository(InMemoryDominoEventsListenerRepository.$create__()).m_requestSendersRepository__org_dominokit_domino_api_client_request_RequestRestSendersRepository(InMemoryRequestRestSendersRepository.$create__()).m_history__org_dominokit_domino_api_shared_history_AppHistory(StateHistory.$create__()).m_asyncRunner__org_dominokit_domino_api_client_async_AsyncRunner(GwtAsyncRunner.$create__()).m_mainExtensionPoint__org_dominokit_domino_api_shared_extension_MainDominoEvent(CoreMainExtensionPoint.$create__()).m_dominoOptions__org_dominokit_domino_api_client_DominoOptions(DefaultDominoOptions.$create__()).m_build__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CoreModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CoreModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CoreModule.$clinit = function() {};
    ClientAppBuilder = goog.module.get('org.dominokit.domino.api.client.ClientApp.ClientAppBuilder$impl');
    CoreMainExtensionPoint = goog.module.get('org.dominokit.domino.client.commons.extensions.CoreMainExtensionPoint$impl');
    InMemoryDominoEventsListenerRepository = goog.module.get('org.dominokit.domino.client.commons.extensions.InMemoryDominoEventsListenerRepository$impl');
    InMemoryPresentersRepository = goog.module.get('org.dominokit.domino.client.commons.mvp.presenter.InMemoryPresentersRepository$impl');
    InMemoryViewRepository = goog.module.get('org.dominokit.domino.client.commons.mvp.view.InMemoryViewRepository$impl');
    ClientRouter = goog.module.get('org.dominokit.domino.client.commons.request.ClientRouter$impl');
    InMemoryCommandsRepository = goog.module.get('org.dominokit.domino.client.commons.request.InMemoryCommandsRepository$impl');
    InMemoryRequestRestSendersRepository = goog.module.get('org.dominokit.domino.client.commons.request.InMemoryRequestRestSendersRepository$impl');
    ServerRouter = goog.module.get('org.dominokit.domino.client.commons.request.ServerRouter$impl');
    GwtAsyncRunner = goog.module.get('org.dominokit.domino.gwt.client.async.GwtAsyncRunner$impl');
    ClientEventFactory = goog.module.get('org.dominokit.domino.gwt.client.events.ClientEventFactory$impl');
    RequestEventProcessor = goog.module.get('org.dominokit.domino.gwt.client.events.RequestEventProcessor$impl');
    ServerEventFactory = goog.module.get('org.dominokit.domino.gwt.client.events.ServerEventFactory$impl');
    SimpleEventsBus = goog.module.get('org.dominokit.domino.gwt.client.events.SimpleEventsBus$impl');
    StateHistory = goog.module.get('org.dominokit.domino.gwt.client.history.StateHistory$impl');
    DefaultDominoOptions = goog.module.get('org.dominokit.domino.gwt.client.options.DefaultDominoOptions$impl');
    GwtRequestAsyncSender = goog.module.get('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CoreModule, $Util.$makeClassName('org.dominokit.domino.gwt.client.app.CoreModule'));




exports = CoreModule; 
//# sourceMappingURL=CoreModule.js.map