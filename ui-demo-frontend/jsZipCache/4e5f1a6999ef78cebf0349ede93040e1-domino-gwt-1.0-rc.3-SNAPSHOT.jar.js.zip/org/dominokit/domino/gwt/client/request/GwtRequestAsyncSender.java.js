/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractRequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _ServerRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ServerRequestEventFactory');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _Cookies = goog.require('org.dominokit.domino.gwt.client.request.Cookies');
const _$1 = goog.require('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.$1');


// Re-exports the implementation.
var GwtRequestAsyncSender = goog.require('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$impl');
exports = GwtRequestAsyncSender;
 