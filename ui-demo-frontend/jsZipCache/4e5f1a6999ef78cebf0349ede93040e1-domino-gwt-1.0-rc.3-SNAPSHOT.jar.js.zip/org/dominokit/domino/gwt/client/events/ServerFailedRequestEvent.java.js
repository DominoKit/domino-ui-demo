/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _ServerFailedRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent');
const _Throwable = goog.require('java.lang.Throwable');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor');
const _ServerFailedRequestStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerFailedRequestStateContext');
const _ServerResponseReceivedStateContext = goog.require('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');
const _FailedResponseBean = goog.require('org.dominokit.domino.api.shared.request.FailedResponseBean');
const _GWTRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.GWTRequestEvent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ServerFailedRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$impl');
exports = ServerFailedRequestEvent;
 