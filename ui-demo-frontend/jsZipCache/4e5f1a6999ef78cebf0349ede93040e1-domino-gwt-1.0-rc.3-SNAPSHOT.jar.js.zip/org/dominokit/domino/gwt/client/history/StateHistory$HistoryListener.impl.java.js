/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory$HistoryListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory.HistoryListener$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let StateListener = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
let TokenFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter$impl');
let StateHistory = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory$impl');


class HistoryListener extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {StateHistory} */
    this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener;
    /** @public {StateListener} */
    this.f_listener__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener_;
    /** @public {TokenFilter} */
    this.f_tokenFilter__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener_;
  }
  
  /**
   * Factory method corresponding to constructor 'HistoryListener(StateHistory, StateListener, TokenFilter)'.
   * @param {StateHistory} $outer_this
   * @param {StateListener} listener
   * @param {TokenFilter} tokenFilter
   * @return {!HistoryListener}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_history_StateHistory__org_dominokit_domino_api_shared_history_DominoHistory_StateListener__org_dominokit_domino_api_shared_history_TokenFilter($outer_this, listener, tokenFilter) {
    HistoryListener.$clinit();
    let $instance = new HistoryListener();
    $instance.$ctor__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener__org_dominokit_domino_gwt_client_history_StateHistory__org_dominokit_domino_api_shared_history_DominoHistory_StateListener__org_dominokit_domino_api_shared_history_TokenFilter($outer_this, listener, tokenFilter);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HistoryListener(StateHistory, StateListener, TokenFilter)'.
   * @param {StateHistory} $outer_this
   * @param {StateListener} listener
   * @param {TokenFilter} tokenFilter
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener__org_dominokit_domino_gwt_client_history_StateHistory__org_dominokit_domino_api_shared_history_DominoHistory_StateListener__org_dominokit_domino_api_shared_history_TokenFilter($outer_this, listener, tokenFilter) {
    this.f_$outer_this__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_listener__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener_ = listener;
    this.f_tokenFilter__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener_ = tokenFilter;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HistoryListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HistoryListener);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HistoryListener.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HistoryListener, $Util.$makeClassName('org.dominokit.domino.gwt.client.history.StateHistory$HistoryListener'));




exports = HistoryListener; 
//# sourceMappingURL=StateHistory$HistoryListener.js.map