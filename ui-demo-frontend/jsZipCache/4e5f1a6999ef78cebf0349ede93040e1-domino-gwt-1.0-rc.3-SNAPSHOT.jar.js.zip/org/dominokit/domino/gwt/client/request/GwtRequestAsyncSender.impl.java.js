/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractRequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let ServerRequestEventFactory = goog.forwardDeclare('org.dominokit.domino.api.client.events.ServerRequestEventFactory$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let Cookies = goog.forwardDeclare('org.dominokit.domino.gwt.client.request.Cookies$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.$1$impl');


class GwtRequestAsyncSender extends AbstractRequestAsyncSender {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GwtRequestAsyncSender(ServerRequestEventFactory)'.
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {!GwtRequestAsyncSender}
   * @public
   */
  static $create__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory) {
    GwtRequestAsyncSender.$clinit();
    let $instance = new GwtRequestAsyncSender();
    $instance.$ctor__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GwtRequestAsyncSender(ServerRequestEventFactory)'.
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory) {
    this.$ctor__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory);
  }
  
  /**
   * @override
   * @param {ServerRequest} request
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  m_sendRequest__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_client_events_ServerRequestEventFactory(request, requestEventFactory) {
    request.m_headers__().put("X-XSRF-TOKEN", Cookies.m_getCookie__java_lang_String("XSRF-TOKEN"));
    ClientApp.m_make__().m_getRequestRestSendersRepository__().m_get__java_lang_String(request.m_getKey__()).m_send__org_dominokit_domino_api_shared_request_RequestBean__java_util_Map__org_dominokit_domino_api_client_request_ServerRequestCallBack(request.m_requestBean__(), request.m_headers__(), $1.$create__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory__org_dominokit_domino_api_client_request_ServerRequest(this, requestEventFactory, request));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GwtRequestAsyncSender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GwtRequestAsyncSender);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GwtRequestAsyncSender.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    Cookies = goog.module.get('org.dominokit.domino.gwt.client.request.Cookies$impl');
    $1 = goog.module.get('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.$1$impl');
    AbstractRequestAsyncSender.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GwtRequestAsyncSender, $Util.$makeClassName('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender'));




exports = GwtRequestAsyncSender; 
//# sourceMappingURL=GwtRequestAsyncSender.js.map