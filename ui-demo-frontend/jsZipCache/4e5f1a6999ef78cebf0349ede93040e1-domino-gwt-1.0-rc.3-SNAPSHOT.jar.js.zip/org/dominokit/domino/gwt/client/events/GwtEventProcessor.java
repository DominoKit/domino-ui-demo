package org.dominokit.domino.gwt.client.events;

import org.dominokit.domino.api.client.events.EventProcessor;

public interface GwtEventProcessor extends EventProcessor {
}
