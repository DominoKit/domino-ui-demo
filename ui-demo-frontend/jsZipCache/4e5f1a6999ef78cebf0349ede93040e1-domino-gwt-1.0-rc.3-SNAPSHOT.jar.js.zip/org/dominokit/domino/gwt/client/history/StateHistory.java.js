/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _AppHistory = goog.require('org.dominokit.domino.api.shared.history.AppHistory');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _PopStateEvent_$Overlay = goog.require('elemental2.dom.PopStateEvent.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _HashSet = goog.require('java.util.HashSet');
const _Objects = goog.require('java.util.Objects');
const _Set = goog.require('java.util.Set');
const _Consumer = goog.require('java.util.function.Consumer');
const _Predicate = goog.require('java.util.function.Predicate');
const _Js = goog.require('jsinterop.base.Js');
const _ClientApp = goog.require('org.dominokit.domino.api.client.ClientApp');
const _AsyncTask = goog.require('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask');
const _DirectState = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.DirectState');
const _State = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.State');
const _StateListener = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');
const _DominoDirectState = goog.require('org.dominokit.domino.client.commons.history.DominoDirectState');
const _StateHistoryToken = goog.require('org.dominokit.domino.client.commons.history.StateHistoryToken');
const _History_$Overlay = goog.require('org.dominokit.domino.gwt.client.history.History.$Overlay');
const _JsState_$Overlay = goog.require('org.dominokit.domino.gwt.client.history.JsState.$Overlay');
const _Location_$Overlay = goog.require('org.dominokit.domino.gwt.client.history.Location.$Overlay');
const _$1 = goog.require('org.dominokit.domino.gwt.client.history.StateHistory.$1');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.gwt.client.history.StateHistory.$LambdaAdaptor$1');
const _DominoHistoryState = goog.require('org.dominokit.domino.gwt.client.history.StateHistory.DominoHistoryState');
const _HistoryListener = goog.require('org.dominokit.domino.gwt.client.history.StateHistory.HistoryListener');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var StateHistory = goog.require('org.dominokit.domino.gwt.client.history.StateHistory$impl');
exports = StateHistory;
 