/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerEventFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerEventFactory$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ServerRequestEventFactory = goog.require('org.dominokit.domino.api.client.events.ServerRequestEventFactory$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');
let ServerFailedRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$impl');
let ServerSuccessRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$impl');


/**
 * @implements {ServerRequestEventFactory}
  */
class ServerEventFactory extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ServerEventFactory()'.
   * @return {!ServerEventFactory}
   * @public
   */
  static $create__() {
    ServerEventFactory.$clinit();
    let $instance = new ServerEventFactory();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ServerEventFactory__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerEventFactory()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ServerEventFactory__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {ServerRequest} request
   * @param {ResponseBean} responseBean
   * @return {Event}
   * @public
   */
  m_makeSuccess__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(request, responseBean) {
    return ServerSuccessRequestEvent.$create__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(request, responseBean);
  }
  
  /**
   * @override
   * @param {ServerRequest} request
   * @param {Throwable} error
   * @return {Event}
   * @public
   */
  m_makeFailed__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(request, error) {
    return ServerFailedRequestEvent.$create__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(request, error);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerEventFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerEventFactory);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerEventFactory.$clinit = function() {};
    ServerFailedRequestEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$impl');
    ServerSuccessRequestEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerEventFactory, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ServerEventFactory'));


ServerRequestEventFactory.$markImplementor(ServerEventFactory);


exports = ServerEventFactory; 
//# sourceMappingURL=ServerEventFactory.js.map