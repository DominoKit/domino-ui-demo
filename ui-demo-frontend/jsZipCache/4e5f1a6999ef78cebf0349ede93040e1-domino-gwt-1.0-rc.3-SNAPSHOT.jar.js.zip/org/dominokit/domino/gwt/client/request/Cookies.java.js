/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.Cookies.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.request.Cookies');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Exception = goog.require('java.lang.Exception');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _j_l_String = goog.require('java.lang.String');
const _Collection = goog.require('java.util.Collection');
const _Date = goog.require('java.util.Date');
const _HashMap = goog.require('java.util.HashMap');
const _Objects = goog.require('java.util.Objects');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Long = goog.require('nativebootstrap.Long');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$LongUtils = goog.require('vmbootstrap.LongUtils');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var Cookies = goog.require('org.dominokit.domino.gwt.client.request.Cookies$impl');
exports = Cookies;
 