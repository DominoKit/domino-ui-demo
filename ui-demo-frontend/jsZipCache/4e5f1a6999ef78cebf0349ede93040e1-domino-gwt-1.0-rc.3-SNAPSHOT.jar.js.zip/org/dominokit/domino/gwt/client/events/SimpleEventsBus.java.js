/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.SimpleEventsBus.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.SimpleEventsBus');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EventsBus = goog.require('org.dominokit.domino.api.client.events.EventsBus');
const _Class = goog.require('java.lang.Class');
const _Exception = goog.require('java.lang.Exception');
const _RequestEvent = goog.require('org.dominokit.domino.api.client.events.EventsBus.RequestEvent');
const _ClientRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent');
const _GwtEventProcessor = goog.require('org.dominokit.domino.gwt.client.events.GwtEventProcessor');
const _ServerFailedRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent');
const _ServerSuccessRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent');
const _Event = goog.require('org.gwtproject.event.shared.Event');
const _EventBus = goog.require('org.gwtproject.event.shared.EventBus');
const _SimpleEventBus = goog.require('org.gwtproject.event.shared.SimpleEventBus');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var SimpleEventsBus = goog.require('org.dominokit.domino.gwt.client.events.SimpleEventsBus$impl');
exports = SimpleEventsBus;
 