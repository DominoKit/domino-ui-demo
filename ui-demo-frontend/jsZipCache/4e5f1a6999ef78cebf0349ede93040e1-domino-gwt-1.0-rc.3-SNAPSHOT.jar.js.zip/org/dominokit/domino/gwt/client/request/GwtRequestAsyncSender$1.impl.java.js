/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender.$1$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ServerRequestCallBack = goog.require('org.dominokit.domino.api.client.request.ServerRequestCallBack$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let ServerRequestEventFactory = goog.forwardDeclare('org.dominokit.domino.api.client.events.ServerRequestEventFactory$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');
let GwtRequestAsyncSender = goog.forwardDeclare('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$impl');


/**
 * @implements {ServerRequestCallBack}
  */
class $1 extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {GwtRequestAsyncSender} */
    this.f_$outer_this__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender_1;
    /** @public {ServerRequestEventFactory} */
    this.$c_requestEventFactory;
    /** @public {ServerRequest} */
    this.$c_request;
  }
  
  /**
   * Factory method corresponding to constructor 'new ServerRequestCallBack(GwtRequestAsyncSender, ServerRequestEventFactory, ServerRequest)'.
   * @param {GwtRequestAsyncSender} $outer_this
   * @param {ServerRequestEventFactory} $c_requestEventFactory
   * @param {ServerRequest} $c_request
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory__org_dominokit_domino_api_client_request_ServerRequest($outer_this, $c_requestEventFactory, $c_request) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender_1__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory__org_dominokit_domino_api_client_request_ServerRequest($outer_this, $c_requestEventFactory, $c_request);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new ServerRequestCallBack(GwtRequestAsyncSender, ServerRequestEventFactory, ServerRequest)'.
   * @param {GwtRequestAsyncSender} $outer_this
   * @param {ServerRequestEventFactory} $c_requestEventFactory
   * @param {ServerRequest} $c_request
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender_1__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory__org_dominokit_domino_api_client_request_ServerRequest($outer_this, $c_requestEventFactory, $c_request) {
    this.f_$outer_this__org_dominokit_domino_gwt_client_request_GwtRequestAsyncSender_1 = $outer_this;
    this.$c_requestEventFactory = $c_requestEventFactory;
    this.$c_request = $c_request;
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {ResponseBean} response
   * @return {void}
   * @public
   */
  m_onSuccess__org_dominokit_domino_api_shared_request_ResponseBean(response) {
    this.$c_requestEventFactory.m_makeSuccess__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(this.$c_request, response).m_fire__();
  }
  
  /**
   * @override
   * @param {Throwable} throwable
   * @return {void}
   * @public
   */
  m_onFailure__java_lang_Throwable(throwable) {
    this.$c_requestEventFactory.m_makeFailed__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(this.$c_request, throwable).m_fire__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.gwt.client.request.GwtRequestAsyncSender$1'));


ServerRequestCallBack.$markImplementor($1);


exports = $1; 
//# sourceMappingURL=GwtRequestAsyncSender$1.js.map