/**
 * @fileoverview transpiled from org.dominokit.domino.steppers.client.presenters.SteppersPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.steppers.client.presenters.SteppersPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let SteppersPresenter = goog.forwardDeclare('org.dominokit.domino.steppers.client.presenters.SteppersPresenter$impl');


/**
 * @extends {PresenterCommand<SteppersPresenter>}
  */
class SteppersPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SteppersPresenterCommand()'.
   * @return {!SteppersPresenterCommand}
   * @public
   */
  static $create__() {
    SteppersPresenterCommand.$clinit();
    let $instance = new SteppersPresenterCommand();
    $instance.$ctor__org_dominokit_domino_steppers_client_presenters_SteppersPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SteppersPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_steppers_client_presenters_SteppersPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SteppersPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SteppersPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SteppersPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SteppersPresenterCommand, $Util.$makeClassName('org.dominokit.domino.steppers.client.presenters.SteppersPresenterCommand'));




exports = SteppersPresenterCommand; 
//# sourceMappingURL=SteppersPresenterCommand.js.map