package org.dominokit.domino.typography.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface TypographyView extends View, DemoView{
}