/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.views.ui.TypographyViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.views.ui.TypographyViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const TypographyView = goog.require('org.dominokit.domino.typography.client.views.TypographyView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLOListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOListElement.$Overlay$impl');
let HTMLParagraphElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.typography.client.views.CodeResource$impl');
let Blockquote = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Blockquote$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {TypographyView}
  */
class TypographyViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyViewImpl()'.
   * @return {!TypographyViewImpl}
   * @public
   */
  static $create__() {
    TypographyViewImpl.$clinit();
    let $instance = new TypographyViewImpl();
    $instance.$ctor__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("TYPOGRAPHY").m_asElement__());
    this.m_bodyCopy___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl();
    this.m_heading___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl();
    this.m_textStyles___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl();
    this.m_blockqoute___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl();
    this.m_lists___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_lists___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl() {
    let row = Row.m_create__();
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String("UNORDERED LIST").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Lorem ipsum dolor sit amet"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Consectetur adipiscing elit"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Integer molestie lorem at massa"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Facilisis in pretium nisl aliquet"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Nulla volutpat aliquam velit"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Phasellus iaculis neque"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Purus sodales ultricies"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Vestibulum laoreet porttitor sem"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Ac tristique libero volutpat at"), IsElement))), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Faucibus porta lacus fringilla vel"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Aenean sit amet erat nunc"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Eget porttitor lorem"), IsElement))), HtmlContentBuilder)).m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String("ORDERED LIST").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(Elements.m_ol__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Lorem ipsum dolor sit amet"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Consectetur adipiscing elit"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Integer molestie lorem at massa"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Facilisis in pretium nisl aliquet"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Nulla volutpat aliquam velit"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(Elements.m_ol__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Phasellus iaculis neque"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Purus sodales ultricies"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Vestibulum laoreet porttitor sem"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Ac tristique libero volutpat at"), IsElement))), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Faucibus porta lacus fringilla vel"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Aenean sit amet erat nunc"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Eget porttitor lorem"), IsElement))), HtmlContentBuilder)).m_asElement__()).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String("UNSTYLED LIST").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_LIST_UNSTYLED__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Lorem ipsum dolor sit amet"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Consectetur adipiscing elit"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Integer molestie lorem at massa"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Facilisis in pretium nisl aliquet"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Nulla volutpat aliquam velit"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Phasellus iaculis neque"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Purus sodales ultricies"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Vestibulum laoreet porttitor sem"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Ac tristique libero volutpat at"), IsElement))), IsElement))), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Faucibus porta lacus fringilla vel"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Aenean sit amet erat nunc"), IsElement))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_li__().m_textContent__java_lang_String("Eget porttitor lorem"), IsElement))), HtmlContentBuilder)).m_asElement__()).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_lists__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_bodyCopy___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl() {
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("BODY COPY", "Use LEAD style make a paragraph with larger fonts on big screens.").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(Elements.m_p__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_LEAD__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String(TypographyViewImpl.f_SMALLER_PARAGRAPH__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(Elements.m_p__().m_textContent__java_lang_String(TypographyViewImpl.f_LARGE_PARAGRAPH__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLParagraphElement>} */ ($Casts.$to(Elements.m_p__().m_textContent__java_lang_String(TypographyViewImpl.f_SMALL_PARAGRAPH__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_), HtmlContentBuilder)).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_bodyCopy__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_heading___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl() {
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(Card.m_create__java_lang_String("HEADINGS").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(1).m_textContent__java_lang_String("h1. Text Heading."), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Paragraph.m_create__java_lang_String(TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(2).m_textContent__java_lang_String("h2. Text Heading."), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Paragraph.m_create__java_lang_String(TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("h3. Text Heading."), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Paragraph.m_create__java_lang_String(TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("h4. Text Heading."), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Paragraph.m_create__java_lang_String(TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("h5. Text Heading."), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Paragraph.m_create__java_lang_String(TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_).m_asElement__()).m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("h6. Text Heading."), HtmlContentBuilder)).m_asElement__()).m_appendContent__elemental2_dom_Node(Paragraph.m_create__java_lang_String(TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_heading__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_textStyles___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl() {
    let row = Row.m_create__();
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_two__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_two__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("TEXT STYLES", "Use ready classes to style your paragraphs.").m_appendContent__elemental2_dom_Node(row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Paragraph.m_create__().m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Normal"), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Default text").m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text pink color").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text cyan color").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text teal color").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text orange color").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text blue grey color").m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Paragraph.m_create__().m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Bold"), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Default text").m_bold__().m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text pink color").m_bold__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text cyan color").m_bold__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text teal color").m_bold__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text orange color").m_bold__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text blue grey color").m_bold__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Paragraph.m_create__().m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Italic"), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Default text").m_italic__().m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text pink color").m_italic__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text cyan color").m_italic__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text teal color").m_italic__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text orange color").m_italic__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text blue grey color").m_italic__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Paragraph.m_create__().m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Under line"), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Default text").m_underLine__().m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text pink color").m_underLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text cyan color").m_underLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text teal color").m_underLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text orange color").m_underLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text blue grey color").m_underLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Paragraph.m_create__().m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Line through"), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Default text").m_lineThrough__().m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text pink color").m_lineThrough__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text cyan color").m_lineThrough__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text teal color").m_lineThrough__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text orange color").m_lineThrough__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text blue grey color").m_lineThrough__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Paragraph.m_create__().m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Over line"), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Default text").m_overLine__().m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text pink color").m_overLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text cyan color").m_overLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text teal color").m_overLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text orange color").m_overLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Text blue grey color").m_overLine__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_textStyles__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_blockqoute___$p_org_dominokit_domino_typography_client_views_ui_TypographyViewImpl() {
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(Card.m_create__java_lang_String("BLOCKQUOTES").m_appendContent__elemental2_dom_Node(Blockquote.m_create__java_lang_String("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.").m_asElement__()).m_appendContent__elemental2_dom_Node(Blockquote.m_create__java_lang_String("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.").m_appendFooterContent__elemental2_dom_Node(new Text("Someone famous in ")).m_appendFooterContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_cite__().m_textContent__java_lang_String("source title."), HtmlContentBuilder)).m_asElement__()).m_asElement__()).m_appendContent__elemental2_dom_Node(Blockquote.m_create__java_lang_String("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.").m_appendFooterContent__elemental2_dom_Node(new Text("Someone famous in ")).m_appendFooterContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_cite__().m_textContent__java_lang_String("source title."), HtmlContentBuilder)).m_asElement__()).m_reverse__().m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_blockqoute__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl() {
    this.f_element__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeResource = goog.module.get('org.dominokit.domino.typography.client.views.CodeResource$impl');
    Blockquote = goog.module.get('org.dominokit.domino.ui.Typography.Blockquote$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TypographyViewImpl, $Util.$makeClassName('org.dominokit.domino.typography.client.views.ui.TypographyViewImpl'));


/** @public {?string} @const */
TypographyViewImpl.f_LARGE_PARAGRAPH__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_ = "Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget";


/** @public {?string} @const */
TypographyViewImpl.f_SMALL_PARAGRAPH__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_ = "Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc.";


/** @public {?string} @const */
TypographyViewImpl.f_SMALLER_PARAGRAPH__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_ = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.";


/** @public {?string} @const */
TypographyViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_typography_client_views_ui_TypographyViewImpl_ = "In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.";


TypographyView.$markImplementor(TypographyViewImpl);


exports = TypographyViewImpl; 
//# sourceMappingURL=TypographyViewImpl.js.map