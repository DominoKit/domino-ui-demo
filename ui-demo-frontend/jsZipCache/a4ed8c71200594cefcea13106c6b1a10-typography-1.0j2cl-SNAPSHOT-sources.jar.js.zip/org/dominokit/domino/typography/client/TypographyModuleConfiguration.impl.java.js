/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.TypographyModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.TypographyModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.typography.client.TypographyModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.typography.client.TypographyModuleConfiguration.$2$impl');
let TypographyPresenterContributionToComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint$impl');
let TypographyPresenter = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenter$impl');
let TypographyPresenterCommand = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class TypographyModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyModuleConfiguration()'.
   * @return {!TypographyModuleConfiguration}
   * @public
   */
  static $create__() {
    TypographyModuleConfiguration.$clinit();
    let $instance = new TypographyModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_typography_client_TypographyModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_TypographyModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_typography_client_TypographyModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(TypographyPresenter).m_getCanonicalName__(), Class.$get(TypographyPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_typography_client_TypographyModuleConfiguration__java_lang_String(this, Class.$get(TypographyPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(TypographyPresenterCommand).m_getCanonicalName__(), Class.$get(TypographyPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {ContributionsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(registry) {
    registry.m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(Class.$get(ComponentCaseExtensionPoint), TypographyPresenterContributionToComponentCaseExtensionPoint.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    $1 = goog.module.get('org.dominokit.domino.typography.client.TypographyModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.typography.client.TypographyModuleConfiguration.$2$impl');
    TypographyPresenterContributionToComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.typography.client.contributions.TypographyPresenterContributionToComponentCaseExtensionPoint$impl');
    TypographyPresenter = goog.module.get('org.dominokit.domino.typography.client.presenters.TypographyPresenter$impl');
    TypographyPresenterCommand = goog.module.get('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TypographyModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.typography.client.TypographyModuleConfiguration'));


ModuleConfiguration.$markImplementor(TypographyModuleConfiguration);


exports = TypographyModuleConfiguration; 
//# sourceMappingURL=TypographyModuleConfiguration.js.map