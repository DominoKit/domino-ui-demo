/**
 * @fileoverview transpiled from .Test.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('.Test');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _System = goog.require('java.lang.System');


// Re-exports the implementation.
var Test = goog.require('.Test$impl');
exports = Test;
 