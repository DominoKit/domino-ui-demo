/**
 * @fileoverview transpiled from .Test.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('.Test$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let System = goog.forwardDeclare('java.lang.System$impl');


class Test extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Test()'.
   * @return {!Test}
   * @public
   */
  static $create__() {
    Test.$clinit();
    let $instance = new Test();
    $instance.$ctor___Test__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Test()'.
   * @return {void}
   * @public
   */
  $ctor___Test__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {Array<?string>} args
   * @return {void}
   * @public
   */
  static m_main__arrayOf_java_lang_String(args) {
    Test.$clinit();
    System.f_out__java_lang_System.m_println__java_lang_String("test");
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Test;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Test);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Test.$clinit = function() {};
    System = goog.module.get('java.lang.System$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Test, $Util.$makeClassName('.Test'));




exports = Test; 
//# sourceMappingURL=Test.js.map