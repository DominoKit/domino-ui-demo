/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.LayoutContext$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.LayoutContext.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LayoutContext = goog.require('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');

let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');


/**
 * @implements {LayoutContext}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():IsLayout} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():IsLayout} */
    this.f_$$fn__org_dominokit_domino_layout_shared_extension_LayoutContext_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_layout_shared_extension_LayoutContext_$LambdaAdaptor__org_dominokit_domino_layout_shared_extension_LayoutContext_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():IsLayout} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_shared_extension_LayoutContext_$LambdaAdaptor__org_dominokit_domino_layout_shared_extension_LayoutContext_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_layout_shared_extension_LayoutContext_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {IsLayout}
   * @public
   */
  m_getLayout__() {
    let /** ?function():IsLayout */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_layout_shared_extension_LayoutContext_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.LayoutContext$$LambdaAdaptor'));


LayoutContext.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=LayoutContext$$LambdaAdaptor.js.map