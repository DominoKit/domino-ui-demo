package org.dominokit.domino.layout.shared.extension;

import org.dominokit.domino.api.shared.extension.DominoEvent;

public interface LayoutEvent extends DominoEvent<LayoutContext> {
}
