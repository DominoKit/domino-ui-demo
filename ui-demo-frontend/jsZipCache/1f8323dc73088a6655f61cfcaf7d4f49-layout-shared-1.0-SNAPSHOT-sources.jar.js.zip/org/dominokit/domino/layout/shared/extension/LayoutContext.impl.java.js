/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.LayoutContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext$impl');

let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {EventContext}
 */
class LayoutContext {
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_getLayout__() {
  }
  
  /**
   * @param {?function():IsLayout} fn
   * @return {LayoutContext}
   * @public
   */
  static $adapt(fn) {
    LayoutContext.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layout_shared_extension_LayoutContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutContext.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(LayoutContext, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.LayoutContext'));


LayoutContext.$markImplementor(/** @type {Function} */ (LayoutContext));


exports = LayoutContext; 
//# sourceMappingURL=LayoutContext.js.map