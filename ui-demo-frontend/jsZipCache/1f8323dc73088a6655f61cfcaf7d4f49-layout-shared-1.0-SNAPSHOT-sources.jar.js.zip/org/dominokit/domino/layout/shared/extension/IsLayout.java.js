/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.IsLayout.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.layout.shared.extension.IsLayout');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');


// Re-exports the implementation.
var IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout$impl');
exports = IsLayout;
 