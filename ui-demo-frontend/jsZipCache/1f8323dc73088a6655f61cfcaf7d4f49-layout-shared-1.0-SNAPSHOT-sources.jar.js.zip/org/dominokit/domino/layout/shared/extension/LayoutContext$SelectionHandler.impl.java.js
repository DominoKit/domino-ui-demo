/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.LayoutContext$SelectionHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class SelectionHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onSelected__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {SelectionHandler}
   * @public
   */
  static $adapt(fn) {
    SelectionHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutContext_SelectionHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layout_shared_extension_LayoutContext_SelectionHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutContext_SelectionHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SelectionHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext.SelectionHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SelectionHandler, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.LayoutContext$SelectionHandler'));


SelectionHandler.$markImplementor(/** @type {Function} */ (SelectionHandler));


exports = SelectionHandler; 
//# sourceMappingURL=LayoutContext$SelectionHandler.js.map