/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.LayoutEvent$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.LayoutEvent.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LayoutEvent = goog.require('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');

let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {LayoutEvent}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():LayoutContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():LayoutContext} */
    this.f_$$fn__org_dominokit_domino_layout_shared_extension_LayoutEvent_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_layout_shared_extension_LayoutEvent_$LambdaAdaptor__org_dominokit_domino_layout_shared_extension_LayoutEvent_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():LayoutContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_layout_shared_extension_LayoutEvent_$LambdaAdaptor__org_dominokit_domino_layout_shared_extension_LayoutEvent_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_layout_shared_extension_LayoutEvent_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {LayoutContext}
   * @public
   */
  m_context__() {
    let /** ?function():LayoutContext */ $function;
    return /**@type {LayoutContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_layout_shared_extension_LayoutEvent_$LambdaAdaptor, $function()), LayoutContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.LayoutEvent$$LambdaAdaptor'));


LayoutEvent.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=LayoutEvent$$LambdaAdaptor.js.map