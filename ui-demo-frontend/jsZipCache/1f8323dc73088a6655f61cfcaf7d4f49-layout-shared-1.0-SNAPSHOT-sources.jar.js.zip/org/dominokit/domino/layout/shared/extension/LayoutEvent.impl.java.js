/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.LayoutEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.LayoutEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutEvent.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {DominoEvent<LayoutContext>}
 */
class LayoutEvent {
  /**
   * @param {?function():LayoutContext} fn
   * @return {LayoutEvent}
   * @public
   */
  static $adapt(fn) {
    LayoutEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layout_shared_extension_LayoutEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_LayoutEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    LayoutEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(LayoutEvent, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.LayoutEvent'));


LayoutEvent.$markImplementor(/** @type {Function} */ (LayoutEvent));


exports = LayoutEvent; 
//# sourceMappingURL=LayoutEvent.js.map