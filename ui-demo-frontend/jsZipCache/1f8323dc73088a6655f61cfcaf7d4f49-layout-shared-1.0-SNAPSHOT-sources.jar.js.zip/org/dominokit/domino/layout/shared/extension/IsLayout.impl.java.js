/**
 * @fileoverview transpiled from org.dominokit.domino.layout.shared.extension.IsLayout.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.layout.shared.extension.IsLayout$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @interface
 */
class IsLayout {
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_show__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_toggleRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_showRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_hideRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_toggleLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_showLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_hideLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getRightPanel__() {
  }
  
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getLeftPanel__() {
  }
  
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getContentPanel__() {
  }
  
  /**
   * @abstract
   * @return {Content}
   * @public
   */
  m_getTopBar__() {
  }
  
  /**
   * @abstract
   * @param {?string} title
   * @return {IsLayout}
   * @public
   */
  m_setTitle__java_lang_String(title) {
  }
  
  /**
   * @abstract
   * @param {?string} icon
   * @return {Content}
   * @public
   */
  m_addActionItem__java_lang_String(icon) {
  }
  
  /**
   * @abstract
   * @param {Content} content
   * @return {void}
   * @public
   */
  m_setRightPanelContent__org_dominokit_domino_api_shared_extension_Content(content) {
  }
  
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_fixLeftPanelPosition__() {
  }
  
  /**
   * @abstract
   * @return {IsLayout}
   * @public
   */
  m_unfixLeftPanelPosition__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_IsLayout = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_layout_shared_extension_IsLayout;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_layout_shared_extension_IsLayout;
  }
  
  /**
   * @public
   */
  static $clinit() {
    IsLayout.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(IsLayout, $Util.$makeClassName('org.dominokit.domino.layout.shared.extension.IsLayout'));


IsLayout.$markImplementor(/** @type {Function} */ (IsLayout));


exports = IsLayout; 
//# sourceMappingURL=IsLayout.js.map