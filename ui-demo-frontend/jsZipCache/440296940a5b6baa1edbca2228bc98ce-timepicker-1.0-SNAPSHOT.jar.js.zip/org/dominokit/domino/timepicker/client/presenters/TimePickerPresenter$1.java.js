/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentCase = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _ComponentRemoveHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler');
const _ComponentRevealedHandler = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRevealedHandler');
const _TimePickerPresenter = goog.require('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter');
const _TimePickerView = goog.require('org.dominokit.domino.timepicker.client.views.TimePickerView');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter.$1$impl');
exports = $1;
 