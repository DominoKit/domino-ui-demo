/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.presenters.TimePickerPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let TimePickerPresenter = goog.forwardDeclare('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenter$impl');


/**
 * @extends {PresenterCommand<TimePickerPresenter>}
  */
class TimePickerPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TimePickerPresenterCommand()'.
   * @return {!TimePickerPresenterCommand}
   * @public
   */
  static $create__() {
    TimePickerPresenterCommand.$clinit();
    let $instance = new TimePickerPresenterCommand();
    $instance.$ctor__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TimePickerPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_timepicker_client_presenters_TimePickerPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TimePickerPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TimePickerPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TimePickerPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TimePickerPresenterCommand, $Util.$makeClassName('org.dominokit.domino.timepicker.client.presenters.TimePickerPresenterCommand'));




exports = TimePickerPresenterCommand; 
//# sourceMappingURL=TimePickerPresenterCommand.js.map