/**
 * @fileoverview transpiled from org.dominokit.domino.tabs.client.views.ui.TabsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _TabsView = goog.require('org.dominokit.domino.tabs.client.views.TabsView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _CodeResource = goog.require('org.dominokit.domino.tabs.client.views.CodeResource');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Tab = goog.require('org.dominokit.domino.ui.tabs.Tab');
const _TabsPanel = goog.require('org.dominokit.domino.ui.tabs.TabsPanel');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TabsViewImpl = goog.require('org.dominokit.domino.tabs.client.views.ui.TabsViewImpl$impl');
exports = TabsViewImpl;
 