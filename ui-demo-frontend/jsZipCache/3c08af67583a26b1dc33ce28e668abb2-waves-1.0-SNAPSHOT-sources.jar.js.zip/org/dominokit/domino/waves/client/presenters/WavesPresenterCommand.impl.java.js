/**
 * @fileoverview transpiled from org.dominokit.domino.waves.client.presenters.WavesPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.waves.client.presenters.WavesPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let WavesPresenter = goog.forwardDeclare('org.dominokit.domino.waves.client.presenters.WavesPresenter$impl');


/**
 * @extends {PresenterCommand<WavesPresenter>}
  */
class WavesPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'WavesPresenterCommand()'.
   * @return {!WavesPresenterCommand}
   * @public
   */
  static $create__() {
    WavesPresenterCommand.$clinit();
    let $instance = new WavesPresenterCommand();
    $instance.$ctor__org_dominokit_domino_waves_client_presenters_WavesPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'WavesPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_waves_client_presenters_WavesPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof WavesPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, WavesPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    WavesPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(WavesPresenterCommand, $Util.$makeClassName('org.dominokit.domino.waves.client.presenters.WavesPresenterCommand'));




exports = WavesPresenterCommand; 
//# sourceMappingURL=WavesPresenterCommand.js.map