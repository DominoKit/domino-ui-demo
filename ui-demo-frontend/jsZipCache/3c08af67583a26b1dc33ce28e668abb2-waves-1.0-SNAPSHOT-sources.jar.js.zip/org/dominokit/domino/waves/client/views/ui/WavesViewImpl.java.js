/**
 * @fileoverview transpiled from org.dominokit.domino.waves.client.views.ui.WavesViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.waves.client.views.ui.WavesViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _WavesView = goog.require('org.dominokit.domino.waves.client.views.WavesView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _CircleSize = goog.require('org.dominokit.domino.ui.button.CircleSize');
const _IconButton = goog.require('org.dominokit.domino.ui.button.IconButton');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _SimpleListGroup = goog.require('org.dominokit.domino.ui.lists.SimpleListGroup');
const _SimpleListItem = goog.require('org.dominokit.domino.ui.lists.SimpleListItem');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _WaveColor = goog.require('org.dominokit.domino.ui.style.WaveColor');
const _CodeResource = goog.require('org.dominokit.domino.waves.client.views.CodeResource');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var WavesViewImpl = goog.require('org.dominokit.domino.waves.client.views.ui.WavesViewImpl$impl');
exports = WavesViewImpl;
 