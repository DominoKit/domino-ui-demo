/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AdvancedFormsView = goog.require('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let File_$Overlay = goog.forwardDeclare('elemental2.dom.File.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let XMLHttpRequest_$Overlay = goog.forwardDeclare('elemental2.dom.XMLHttpRequest.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.views.CodeResource$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let FileItem = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem$impl');
let ErrorHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.ErrorHandler$impl');
let RemoveFileHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler$impl');
let SuccessUploadHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.SuccessUploadHandler$impl');
let FileUpload = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileUpload$impl');
let OnAddFileHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {AdvancedFormsView}
  */
class AdvancedFormsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
    /** @public {Card} */
    this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedFormsViewImpl()'.
   * @return {!AdvancedFormsViewImpl}
   * @public
   */
  static $create__() {
    AdvancedFormsViewImpl.$clinit();
    let $instance = new AdvancedFormsViewImpl();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedFormsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("ADVANCED FORM ELEMENTS").m_asElement__());
    this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = Card.m_create__java_lang_String("FILE UPLOAD - DRAG & DROP OR WITH CLICK & CHOOSE");
    this.m_initFileUploadExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl();
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_asElement__());
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_uploadExample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFileUploadExample___$p_org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl() {
    let fileUpload = FileUpload.m_create__().m_setIcon__org_dominokit_domino_ui_icons_Icon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_touch_app__()).m_setUrl__java_lang_String("http://localhost:8080/form").m_multipleFiles__().m_accept__java_lang_String("image/*").m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Drop files here or click to upload."), HtmlContentBuilder)).m_asElement__()).m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_em__().m_textContent__java_lang_String("(This is just a demo upload. Selected files are not actually uploaded)"), HtmlContentBuilder)).m_asElement__()).m_onAddFile__org_dominokit_domino_ui_upload_FileUpload_OnAddFileHandler(OnAddFileHandler.$adapt(((/** FileItem */ fileItem) =>{
      fileItem.m_addErrorHandler__org_dominokit_domino_ui_upload_FileItem_ErrorHandler(ErrorHandler.$adapt(((/** XMLHttpRequest */ request) =>{
        Notification.m_createDanger__java_lang_String("Error while uploading " + j_l_String.m_valueOf__java_lang_Object(request.responseText)).m_show__();
      })));
      fileItem.m_addSuccessUploadHandler__org_dominokit_domino_ui_upload_FileItem_SuccessUploadHandler(SuccessUploadHandler.$adapt(((/** XMLHttpRequest */ request$1$) =>{
        Notification.m_createSuccess__java_lang_String("File uploaded successfully").m_show__();
      })));
      fileItem.m_addRemoveHandler__org_dominokit_domino_ui_upload_FileItem_RemoveFileHandler(RemoveFileHandler.$adapt(((/** File */ file) =>{
        Notification.m_createInfo__java_lang_String("File has been removed " + j_l_String.m_valueOf__java_lang_Object(file.name)).m_show__();
      })));
    })));
    this.f_uploadCard__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_.m_appendContent__elemental2_dom_Node(fileUpload.m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl() {
    this.f_element__org_dominokit_domino_advancedforms_client_views_ui_AdvancedFormsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedFormsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedFormsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeResource = goog.module.get('org.dominokit.domino.advancedforms.client.views.CodeResource$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    ErrorHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.ErrorHandler$impl');
    RemoveFileHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler$impl');
    SuccessUploadHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.SuccessUploadHandler$impl');
    FileUpload = goog.module.get('org.dominokit.domino.ui.upload.FileUpload$impl');
    OnAddFileHandler = goog.module.get('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AdvancedFormsViewImpl, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.views.ui.AdvancedFormsViewImpl'));


AdvancedFormsView.$markImplementor(AdvancedFormsViewImpl);


exports = AdvancedFormsViewImpl; 
//# sourceMappingURL=AdvancedFormsViewImpl.js.map