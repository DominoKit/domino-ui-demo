/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.views.AdvancedFormsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView.$LambdaAdaptor$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class AdvancedFormsView {
  /**
   * @param {?function():Content} fn
   * @return {AdvancedFormsView}
   * @public
   */
  static $adapt(fn) {
    AdvancedFormsView.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_advancedforms_client_views_AdvancedFormsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_advancedforms_client_views_AdvancedFormsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_advancedforms_client_views_AdvancedFormsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsView.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(AdvancedFormsView, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.views.AdvancedFormsView'));


AdvancedFormsView.$markImplementor(/** @type {Function} */ (AdvancedFormsView));


exports = AdvancedFormsView; 
//# sourceMappingURL=AdvancedFormsView.js.map