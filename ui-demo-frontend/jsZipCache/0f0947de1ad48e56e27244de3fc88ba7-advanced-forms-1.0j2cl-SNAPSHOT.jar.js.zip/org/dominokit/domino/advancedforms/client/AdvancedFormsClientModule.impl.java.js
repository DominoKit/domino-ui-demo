/**
 * @fileoverview transpiled from org.dominokit.domino.advancedforms.client.AdvancedFormsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.advancedforms.client.AdvancedFormsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class AdvancedFormsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedFormsClientModule()'.
   * @return {!AdvancedFormsClientModule}
   * @public
   */
  static $create__() {
    AdvancedFormsClientModule.$clinit();
    let $instance = new AdvancedFormsClientModule();
    $instance.$ctor__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedFormsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    AdvancedFormsClientModule.$f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_.m_info__java_lang_String("Initializing AdvancedForms frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_() {
    return (AdvancedFormsClientModule.$clinit(), AdvancedFormsClientModule.$f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_(value) {
    (AdvancedFormsClientModule.$clinit(), AdvancedFormsClientModule.$f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedFormsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedFormsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AdvancedFormsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    AdvancedFormsClientModule.$f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AdvancedFormsClientModule));
  }
  
  
};

$Util.$setClassMetadata(AdvancedFormsClientModule, $Util.$makeClassName('org.dominokit.domino.advancedforms.client.AdvancedFormsClientModule'));


/** @private {Logger} */
AdvancedFormsClientModule.$f_LOGGER__org_dominokit_domino_advancedforms_client_AdvancedFormsClientModule_;




exports = AdvancedFormsClientModule; 
//# sourceMappingURL=AdvancedFormsClientModule.js.map