/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.JsState$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.history.JsState.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');


class JsState_$Overlay {
  /**
   * @param {?string} token
   * @return {Object}
   * @public
   */
  static m_state__java_lang_String(token) {
    JsState_$Overlay.$clinit();
    let state = new Object();
    state.historyToken = token;
    state.data = "";
    state.title = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.title;
    return state;
  }
  
  /**
   * @param {?string} token
   * @param {?string} data
   * @return {Object}
   * @public
   */
  static m_state__java_lang_String__java_lang_String(token, data) {
    JsState_$Overlay.$clinit();
    let state = new Object();
    state.historyToken = token;
    state.data = data;
    state.title = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.title;
    return state;
  }
  
  /**
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {Object}
   * @public
   */
  static m_state__java_lang_String__java_lang_String__java_lang_String(token, title, data) {
    JsState_$Overlay.$clinit();
    let state = new Object();
    state.historyToken = token;
    state.data = data;
    state.title = title;
    return state;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Object;
  }
  
  /**
   * @public
   */
  static $clinit() {
    JsState_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
  }
  
  
};

$Util.$setClassMetadata(JsState_$Overlay, $Util.$makeClassName('Object'));


exports = JsState_$Overlay; 
//# sourceMappingURL=JsState$$Overlay.js.map