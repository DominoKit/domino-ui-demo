/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.GwtEventProcessor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.GwtEventProcessor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EventProcessor = goog.require('org.dominokit.domino.api.client.events.EventProcessor');
const _Event = goog.require('org.dominokit.domino.api.client.events.Event');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.gwt.client.events.GwtEventProcessor.$LambdaAdaptor');


// Re-exports the implementation.
var GwtEventProcessor = goog.require('org.dominokit.domino.gwt.client.events.GwtEventProcessor$impl');
exports = GwtEventProcessor;
 