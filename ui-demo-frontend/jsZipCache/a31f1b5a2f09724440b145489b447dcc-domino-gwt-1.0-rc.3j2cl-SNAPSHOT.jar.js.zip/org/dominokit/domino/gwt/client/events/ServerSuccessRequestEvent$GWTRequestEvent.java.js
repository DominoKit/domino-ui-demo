/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent$GWTRequestEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.GWTRequestEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RequestEvent = goog.require('org.dominokit.domino.api.client.events.EventsBus.RequestEvent');
const _ServerSuccessRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent');
const _ServerSuccessRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestGwtEvent');


// Re-exports the implementation.
var GWTRequestEvent = goog.require('org.dominokit.domino.gwt.client.events.ServerSuccessRequestEvent.GWTRequestEvent$impl');
exports = GWTRequestEvent;
 