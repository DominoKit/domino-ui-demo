/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const AppHistory = goog.require('org.dominokit.domino.api.shared.history.AppHistory$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let PopStateEvent_$Overlay = goog.forwardDeclare('elemental2.dom.PopStateEvent.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashSet = goog.forwardDeclare('java.util.HashSet$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let AsyncTask = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
let DirectState = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.DirectState$impl');
let State = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.State$impl');
let StateListener = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory.StateListener$impl');
let TokenFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter$impl');
let DominoDirectState = goog.forwardDeclare('org.dominokit.domino.client.commons.history.DominoDirectState$impl');
let StateHistoryToken = goog.forwardDeclare('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
let History_$Overlay = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.History.$Overlay$impl');
let JsState_$Overlay = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.JsState.$Overlay$impl');
let Location_$Overlay = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.Location.$Overlay$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory.$1$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory.$LambdaAdaptor$1$impl');
let DominoHistoryState = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory.DominoHistoryState$impl');
let HistoryListener = goog.forwardDeclare('org.dominokit.domino.gwt.client.history.StateHistory.HistoryListener$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {AppHistory}
  */
class StateHistory extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Set<HistoryListener>} */
    this.f_listeners__org_dominokit_domino_gwt_client_history_StateHistory_;
    /** @public {History} */
    this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_;
  }
  
  /**
   * Factory method corresponding to constructor 'StateHistory()'.
   * @return {!StateHistory}
   * @public
   */
  static $create__() {
    StateHistory.$clinit();
    let $instance = new StateHistory();
    $instance.$ctor__org_dominokit_domino_gwt_client_history_StateHistory__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StateHistory()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_history_StateHistory__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_gwt_client_history_StateHistory();
    $Overlay.f_self__elemental2_dom_DomGlobal_$Overlay.addEventListener("popstate", new $LambdaAdaptor$1(((/** Event */ event) =>{
      let popStateEvent = /**@type {PopStateEvent} */ ($Casts.$to(Js.m_cast__java_lang_Object(event), PopStateEvent_$Overlay));
      let state = /**@type {Object} */ ($Casts.$to(Js.m_cast__java_lang_Object(popStateEvent.state), JsState_$Overlay));
      if (Objects.m_nonNull__java_lang_Object(state)) {
        this.m_inform__java_lang_String__java_lang_String__java_lang_String_$p_org_dominokit_domino_gwt_client_history_StateHistory(state.historyToken, state.title, state.data);
      }
    })));
  }
  
  /**
   * @param {?string} token
   * @param {?string} title
   * @param {?string} stateJson
   * @return {void}
   * @public
   */
  m_inform__java_lang_String__java_lang_String__java_lang_String_$p_org_dominokit_domino_gwt_client_history_StateHistory(token, title, stateJson) {
    this.f_listeners__org_dominokit_domino_gwt_client_history_StateHistory_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** HistoryListener */ l) =>{
      return l.f_tokenFilter__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener_.m_filter__org_dominokit_domino_api_shared_history_HistoryToken(DominoHistoryState.$create__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String(this, token, title, stateJson).f_token__org_dominokit_domino_gwt_client_history_StateHistory_DominoHistoryState_);
    }))).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** HistoryListener */ l$1$) =>{
      ClientApp.m_make__().m_getAsyncRunner__().m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(AsyncTask.$adapt((() =>{
        l$1$.f_listener__org_dominokit_domino_gwt_client_history_StateHistory_HistoryListener_.m_onPopState__org_dominokit_domino_api_shared_history_DominoHistory_State(DominoHistoryState.$create__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String(this, token, title, stateJson));
      })));
    })));
  }
  
  /**
   * @override
   * @param {StateListener} listener
   * @return {DirectState}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(listener) {
    return this.m_listen__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(TokenFilter.m_any__(), listener);
  }
  
  /**
   * @override
   * @param {TokenFilter} tokenFilter
   * @param {StateListener} listener
   * @return {DirectState}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_StateListener(tokenFilter, listener) {
    this.f_listeners__org_dominokit_domino_gwt_client_history_StateHistory_.add(HistoryListener.$create__org_dominokit_domino_gwt_client_history_StateHistory__org_dominokit_domino_api_shared_history_DominoHistory_StateListener__org_dominokit_domino_api_shared_history_TokenFilter(this, listener, tokenFilter));
    return DominoDirectState.$create__org_dominokit_domino_api_shared_history_TokenFilter__org_dominokit_domino_api_shared_history_DominoHistory_State(tokenFilter, this.m_currentState___$p_org_dominokit_domino_gwt_client_history_StateHistory());
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_back__() {
    this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_.back();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_forward__() {
    this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_.forward();
  }
  
  /**
   * @override
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {void}
   * @public
   */
  m_pushState__java_lang_String__java_lang_String__java_lang_String(token, title, data) {
    if (Objects.m_nonNull__java_lang_Object(this.m_currentToken__().m_value__()) && !j_l_String.m_equals__java_lang_String__java_lang_Object(this.m_currentToken__().m_value__(), token)) {
      this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_.pushState(JsState_$Overlay.m_state__java_lang_String__java_lang_String__java_lang_String(token, title, data), title, "/" + j_l_String.m_valueOf__java_lang_Object(token));
    }
  }
  
  /**
   * @override
   * @param {?string} token
   * @return {void}
   * @public
   */
  m_pushState__java_lang_String(token) {
    if (Objects.m_nonNull__java_lang_Object(this.m_currentToken__().m_value__()) && !j_l_String.m_equals__java_lang_String__java_lang_Object(this.m_currentToken__().m_value__(), token)) {
      this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_.pushState(JsState_$Overlay.m_state__java_lang_String__java_lang_String__java_lang_String(token, this.m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory(), ""), this.m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory(), "/" + j_l_String.m_valueOf__java_lang_Object(token));
    }
  }
  
  /**
   * @override
   * @param {?string} token
   * @param {?string} title
   * @param {?string} data
   * @return {void}
   * @public
   */
  m_replaceState__java_lang_String__java_lang_String__java_lang_String(token, title, data) {
    this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_.replaceState(JsState_$Overlay.m_state__java_lang_String__java_lang_String(token, data), title, "/" + j_l_String.m_valueOf__java_lang_Object(token));
  }
  
  /**
   * @override
   * @return {StateHistoryToken}
   * @public
   */
  m_currentToken__() {
    return StateHistoryToken.$create__java_lang_String(this.m_windowToken___$p_org_dominokit_domino_gwt_client_history_StateHistory());
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_fireCurrentStateHistory__() {
    this.m_fireState__java_lang_String__java_lang_String_$p_org_dominokit_domino_gwt_client_history_StateHistory(this.m_windowToken___$p_org_dominokit_domino_gwt_client_history_StateHistory(), this.m_stateData__org_dominokit_domino_api_shared_history_DominoHistory_State_$p_org_dominokit_domino_gwt_client_history_StateHistory(this.m_windowState___$p_org_dominokit_domino_gwt_client_history_StateHistory()));
  }
  
  /**
   * @param {?string} token
   * @param {?string} state
   * @return {void}
   * @public
   */
  m_fireState__java_lang_String__java_lang_String_$p_org_dominokit_domino_gwt_client_history_StateHistory(token, state) {
    this.m_replaceState__java_lang_String__java_lang_String__java_lang_String(token, this.m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory(), state);
    this.m_inform__java_lang_String__java_lang_String__java_lang_String_$p_org_dominokit_domino_gwt_client_history_StateHistory(token, this.m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory(), state);
  }
  
  /**
   * @return {State}
   * @public
   */
  m_windowState___$p_org_dominokit_domino_gwt_client_history_StateHistory() {
    if (Objects.m_isNull__java_lang_Object($Overlay.f_self__elemental2_dom_DomGlobal_$Overlay.history.state)) {
      return this.m_nullState___$p_org_dominokit_domino_gwt_client_history_StateHistory();
    }
    let jsState = /**@type {Object} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.f_self__elemental2_dom_DomGlobal_$Overlay.history.state), JsState_$Overlay));
    return DominoHistoryState.$create__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String(this, jsState.historyToken, jsState.title, jsState.data);
  }
  
  /**
   * @return {State}
   * @public
   */
  m_nullState___$p_org_dominokit_domino_gwt_client_history_StateHistory() {
    return $1.$create__org_dominokit_domino_gwt_client_history_StateHistory(this);
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory() {
    return $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.title;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_windowToken___$p_org_dominokit_domino_gwt_client_history_StateHistory() {
    let location = /**@type {Location} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.f_location__elemental2_dom_DomGlobal_$Overlay), Location_$Overlay));
    return j_l_String.m_valueOf__java_lang_Object(j_l_String.m_substring__java_lang_String__int(location.pathname, 1)) + j_l_String.m_valueOf__java_lang_Object(location.search) + j_l_String.m_valueOf__java_lang_Object(location.hash);
  }
  
  /**
   * @return {State}
   * @public
   */
  m_currentState___$p_org_dominokit_domino_gwt_client_history_StateHistory() {
    return DominoHistoryState.$create__org_dominokit_domino_gwt_client_history_StateHistory__java_lang_String__java_lang_String__java_lang_String(this, this.m_windowToken___$p_org_dominokit_domino_gwt_client_history_StateHistory(), this.m_windowTitle___$p_org_dominokit_domino_gwt_client_history_StateHistory(), this.m_stateData__org_dominokit_domino_api_shared_history_DominoHistory_State_$p_org_dominokit_domino_gwt_client_history_StateHistory(this.m_windowState___$p_org_dominokit_domino_gwt_client_history_StateHistory()));
  }
  
  /**
   * @param {State} state
   * @return {?string}
   * @public
   */
  m_stateData__org_dominokit_domino_api_shared_history_DominoHistory_State_$p_org_dominokit_domino_gwt_client_history_StateHistory(state) {
    return Objects.m_isNull__java_lang_Object(state) ? "" : state.m_data__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_gwt_client_history_StateHistory() {
    this.f_listeners__org_dominokit_domino_gwt_client_history_StateHistory_ = /**@type {!HashSet<HistoryListener>} */ (HashSet.$create__());
    this.f_history__org_dominokit_domino_gwt_client_history_StateHistory_ = /**@type {History} */ ($Casts.$to(Js.m_cast__java_lang_Object($Overlay.f_self__elemental2_dom_DomGlobal_$Overlay.history), History_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StateHistory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StateHistory);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StateHistory.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    PopStateEvent_$Overlay = goog.module.get('elemental2.dom.PopStateEvent.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    HashSet = goog.module.get('java.util.HashSet$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    AsyncTask = goog.module.get('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
    TokenFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter$impl');
    DominoDirectState = goog.module.get('org.dominokit.domino.client.commons.history.DominoDirectState$impl');
    StateHistoryToken = goog.module.get('org.dominokit.domino.client.commons.history.StateHistoryToken$impl');
    History_$Overlay = goog.module.get('org.dominokit.domino.gwt.client.history.History.$Overlay$impl');
    JsState_$Overlay = goog.module.get('org.dominokit.domino.gwt.client.history.JsState.$Overlay$impl');
    Location_$Overlay = goog.module.get('org.dominokit.domino.gwt.client.history.Location.$Overlay$impl');
    $1 = goog.module.get('org.dominokit.domino.gwt.client.history.StateHistory.$1$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.gwt.client.history.StateHistory.$LambdaAdaptor$1$impl');
    DominoHistoryState = goog.module.get('org.dominokit.domino.gwt.client.history.StateHistory.DominoHistoryState$impl');
    HistoryListener = goog.module.get('org.dominokit.domino.gwt.client.history.StateHistory.HistoryListener$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(StateHistory, $Util.$makeClassName('org.dominokit.domino.gwt.client.history.StateHistory'));


AppHistory.$markImplementor(StateHistory);


exports = StateHistory; 
//# sourceMappingURL=StateHistory.js.map