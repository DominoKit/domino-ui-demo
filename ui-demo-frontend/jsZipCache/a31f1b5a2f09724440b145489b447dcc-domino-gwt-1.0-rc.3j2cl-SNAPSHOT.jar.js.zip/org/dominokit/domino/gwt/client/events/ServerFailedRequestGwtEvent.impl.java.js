/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Event = goog.require('org.gwtproject.event.shared.Event$impl');

let EventProcessor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventProcessor$impl');
let Type = goog.forwardDeclare('org.gwtproject.event.shared.Event.Type$impl');


/**
 * @abstract
 * @extends {Event<EventProcessor>}
  */
class ServerFailedRequestGwtEvent extends Event {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'ServerFailedRequestGwtEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent__() {
    this.$ctor__org_gwtproject_event_shared_Event__();
  }
  
  /**
   * @override
   * @return {Type<EventProcessor>}
   * @public
   */
  m_getAssociatedType__() {
    return ServerFailedRequestGwtEvent.$f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent;
  }
  
  /**
   * @return {Type<EventProcessor>}
   * @public
   */
  static get f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent() {
    return (ServerFailedRequestGwtEvent.$clinit(), ServerFailedRequestGwtEvent.$f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent);
  }
  
  /**
   * @param {Type<EventProcessor>} value
   * @return {void}
   * @public
   */
  static set f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent(value) {
    (ServerFailedRequestGwtEvent.$clinit(), ServerFailedRequestGwtEvent.$f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerFailedRequestGwtEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerFailedRequestGwtEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerFailedRequestGwtEvent.$clinit = function() {};
    Type = goog.module.get('org.gwtproject.event.shared.Event.Type$impl');
    Event.$clinit();
    ServerFailedRequestGwtEvent.$f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent = /**@type {!Type<EventProcessor>} */ (Type.$create__());
  }
  
  
};

$Util.$setClassMetadata(ServerFailedRequestGwtEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent'));


/** @private {Type<EventProcessor>} */
ServerFailedRequestGwtEvent.$f_SERVER_FAILED_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent;




exports = ServerFailedRequestGwtEvent; 
//# sourceMappingURL=ServerFailedRequestGwtEvent.js.map