/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Event = goog.require('org.gwtproject.event.shared.Event$impl');

let EventProcessor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventProcessor$impl');
let Type = goog.forwardDeclare('org.gwtproject.event.shared.Event.Type$impl');


/**
 * @abstract
 * @extends {Event<EventProcessor>}
  */
class ClientRequestGwtEvent extends Event {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Initialization from constructor 'ClientRequestGwtEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent__() {
    this.$ctor__org_gwtproject_event_shared_Event__();
  }
  
  /**
   * @override
   * @return {Type<EventProcessor>}
   * @public
   */
  m_getAssociatedType__() {
    return ClientRequestGwtEvent.$f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent;
  }
  
  /**
   * @return {Type<EventProcessor>}
   * @public
   */
  static get f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent() {
    return (ClientRequestGwtEvent.$clinit(), ClientRequestGwtEvent.$f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent);
  }
  
  /**
   * @param {Type<EventProcessor>} value
   * @return {void}
   * @public
   */
  static set f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent(value) {
    (ClientRequestGwtEvent.$clinit(), ClientRequestGwtEvent.$f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientRequestGwtEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientRequestGwtEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientRequestGwtEvent.$clinit = function() {};
    Type = goog.module.get('org.gwtproject.event.shared.Event.Type$impl');
    Event.$clinit();
    ClientRequestGwtEvent.$f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent = /**@type {!Type<EventProcessor>} */ (Type.$create__());
  }
  
  
};

$Util.$setClassMetadata(ClientRequestGwtEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent'));


/** @private {Type<EventProcessor>} */
ClientRequestGwtEvent.$f_CLIENT_REQUEST_EVENT_TYPE__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent;




exports = ClientRequestGwtEvent; 
//# sourceMappingURL=ClientRequestGwtEvent.js.map