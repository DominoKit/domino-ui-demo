/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractRequestAsyncSender = goog.require('org.dominokit.domino.client.commons.request.AbstractRequestAsyncSender$impl');

let ServerRequestEventFactory = goog.forwardDeclare('org.dominokit.domino.api.client.events.ServerRequestEventFactory$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let NotImplementedException = goog.forwardDeclare('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender.NotImplementedException$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


class DefaultRequestAsyncSender extends AbstractRequestAsyncSender {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DefaultRequestAsyncSender(ServerRequestEventFactory)'.
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {!DefaultRequestAsyncSender}
   * @public
   */
  static $create__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory) {
    DefaultRequestAsyncSender.$clinit();
    let $instance = new DefaultRequestAsyncSender();
    $instance.$ctor__org_dominokit_domino_gwt_client_request_DefaultRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DefaultRequestAsyncSender(ServerRequestEventFactory)'.
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_request_DefaultRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory) {
    this.$ctor__org_dominokit_domino_client_commons_request_AbstractRequestAsyncSender__org_dominokit_domino_api_client_events_ServerRequestEventFactory(requestEventFactory);
  }
  
  /**
   * @override
   * @param {ServerRequest} request
   * @param {ServerRequestEventFactory} requestEventFactory
   * @return {void}
   * @public
   */
  m_sendRequest__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_client_events_ServerRequestEventFactory(request, requestEventFactory) {
    throw $Exceptions.toJs(NotImplementedException.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DefaultRequestAsyncSender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DefaultRequestAsyncSender);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DefaultRequestAsyncSender.$clinit = function() {};
    NotImplementedException = goog.module.get('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender.NotImplementedException$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    AbstractRequestAsyncSender.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DefaultRequestAsyncSender, $Util.$makeClassName('org.dominokit.domino.gwt.client.request.DefaultRequestAsyncSender'));




exports = DefaultRequestAsyncSender; 
//# sourceMappingURL=DefaultRequestAsyncSender.js.map