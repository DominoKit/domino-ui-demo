/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.StateHistory$HistoryListener.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.history.StateHistory.HistoryListener');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _StateListener = goog.require('org.dominokit.domino.api.shared.history.DominoHistory.StateListener');
const _TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter');
const _StateHistory = goog.require('org.dominokit.domino.gwt.client.history.StateHistory');


// Re-exports the implementation.
var HistoryListener = goog.require('org.dominokit.domino.gwt.client.history.StateHistory.HistoryListener$impl');
exports = HistoryListener;
 