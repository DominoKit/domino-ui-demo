/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.history.JsState$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.gwt.client.history.JsState.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');


// Re-exports the implementation.
var JsState_$Overlay = goog.require('org.dominokit.domino.gwt.client.history.JsState.$Overlay$impl');
exports = JsState_$Overlay;
 