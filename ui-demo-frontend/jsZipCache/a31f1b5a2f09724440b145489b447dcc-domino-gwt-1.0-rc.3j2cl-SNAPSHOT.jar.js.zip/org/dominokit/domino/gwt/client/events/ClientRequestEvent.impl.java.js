/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ClientRequestEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ClientRequestEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Event = goog.require('org.dominokit.domino.api.client.events.Event$impl');
const ClientRequestGwtEvent = goog.require('org.dominokit.domino.gwt.client.events.ClientRequestGwtEvent$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let EventProcessor = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventProcessor$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');
let DefaultRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext$impl');
let GWTRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ClientRequestEvent.GWTRequestEvent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Event}
  */
class ClientRequestEvent extends ClientRequestGwtEvent {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {PresenterCommand} */
    this.f_request__org_dominokit_domino_gwt_client_events_ClientRequestEvent;
    /** @public {ClientApp} */
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ClientRequestEvent_;
  }
  
  /**
   * Factory method corresponding to constructor 'ClientRequestEvent(PresenterCommand)'.
   * @param {PresenterCommand} request
   * @return {!ClientRequestEvent}
   * @public
   */
  static $create__org_dominokit_domino_api_client_request_PresenterCommand(request) {
    ClientRequestEvent.$clinit();
    let $instance = new ClientRequestEvent();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ClientRequestEvent__org_dominokit_domino_api_client_request_PresenterCommand(request);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ClientRequestEvent(PresenterCommand)'.
   * @param {PresenterCommand} request
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ClientRequestEvent__org_dominokit_domino_api_client_request_PresenterCommand(request) {
    this.$ctor__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent__();
    this.$init__org_dominokit_domino_gwt_client_events_ClientRequestEvent();
    this.f_request__org_dominokit_domino_gwt_client_events_ClientRequestEvent = request;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_fire__() {
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ClientRequestEvent_.m_getEventsBus__().m_publishEvent__org_dominokit_domino_api_client_events_EventsBus_RequestEvent(GWTRequestEvent.$create__org_dominokit_domino_gwt_client_events_ClientRequestEvent__org_dominokit_domino_gwt_client_events_ClientRequestGwtEvent(this, this));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_process__() {
    this.f_request__org_dominokit_domino_gwt_client_events_ClientRequestEvent.m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(DefaultRequestStateContext.$create__());
  }
  
  /**
   * @param {EventProcessor} eventProcessor
   * @return {void}
   * @public
   */
  m_dispatch__org_dominokit_domino_api_client_events_EventProcessor(eventProcessor) {
    eventProcessor.m_process__org_dominokit_domino_api_client_events_Event(this);
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_dispatch__java_lang_Object(arg0) {
    this.m_dispatch__org_dominokit_domino_api_client_events_EventProcessor(/**@type {EventProcessor} */ ($Casts.$to(arg0, EventProcessor)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_gwt_client_events_ClientRequestEvent() {
    this.f_clientApp__org_dominokit_domino_gwt_client_events_ClientRequestEvent_ = ClientApp.m_make__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientRequestEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientRequestEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientRequestEvent.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    EventProcessor = goog.module.get('org.dominokit.domino.api.client.events.EventProcessor$impl');
    DefaultRequestStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext$impl');
    GWTRequestEvent = goog.module.get('org.dominokit.domino.gwt.client.events.ClientRequestEvent.GWTRequestEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ClientRequestGwtEvent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ClientRequestEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ClientRequestEvent'));


Event.$markImplementor(ClientRequestEvent);


exports = ClientRequestEvent; 
//# sourceMappingURL=ClientRequestEvent.js.map