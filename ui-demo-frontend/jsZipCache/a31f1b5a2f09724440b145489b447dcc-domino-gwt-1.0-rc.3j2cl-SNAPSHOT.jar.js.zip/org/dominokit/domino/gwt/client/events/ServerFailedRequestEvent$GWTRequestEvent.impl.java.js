/**
 * @fileoverview transpiled from org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$GWTRequestEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent.GWTRequestEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestEvent = goog.require('org.dominokit.domino.api.client.events.EventsBus.RequestEvent$impl');

let ServerFailedRequestEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$impl');
let ServerFailedRequestGwtEvent = goog.forwardDeclare('org.dominokit.domino.gwt.client.events.ServerFailedRequestGwtEvent$impl');


/**
 * @implements {RequestEvent<ServerFailedRequestGwtEvent>}
  */
class GWTRequestEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ServerFailedRequestEvent} */
    this.f_$outer_this__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent;
    /** @public {ServerFailedRequestGwtEvent} */
    this.f_event__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent_;
  }
  
  /**
   * Factory method corresponding to constructor 'GWTRequestEvent(ServerFailedRequestEvent, ServerFailedRequestGwtEvent)'.
   * @param {ServerFailedRequestEvent} $outer_this
   * @param {ServerFailedRequestGwtEvent} event
   * @return {!GWTRequestEvent}
   * @public
   */
  static $create__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent($outer_this, event) {
    GWTRequestEvent.$clinit();
    let $instance = new GWTRequestEvent();
    $instance.$ctor__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent($outer_this, event);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GWTRequestEvent(ServerFailedRequestEvent, ServerFailedRequestGwtEvent)'.
   * @param {ServerFailedRequestEvent} $outer_this
   * @param {ServerFailedRequestGwtEvent} event
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent__org_dominokit_domino_gwt_client_events_ServerFailedRequestGwtEvent($outer_this, event) {
    this.f_$outer_this__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent = $outer_this;
    this.$ctor__java_lang_Object__();
    this.f_event__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent_ = event;
  }
  
  /**
   * @override
   * @return {ServerFailedRequestGwtEvent}
   * @public
   */
  m_asEvent__() {
    return this.f_event__org_dominokit_domino_gwt_client_events_ServerFailedRequestEvent_GWTRequestEvent_;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GWTRequestEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GWTRequestEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GWTRequestEvent.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GWTRequestEvent, $Util.$makeClassName('org.dominokit.domino.gwt.client.events.ServerFailedRequestEvent$GWTRequestEvent'));


RequestEvent.$markImplementor(GWTRequestEvent);


exports = GWTRequestEvent; 
//# sourceMappingURL=ServerFailedRequestEvent$GWTRequestEvent.js.map