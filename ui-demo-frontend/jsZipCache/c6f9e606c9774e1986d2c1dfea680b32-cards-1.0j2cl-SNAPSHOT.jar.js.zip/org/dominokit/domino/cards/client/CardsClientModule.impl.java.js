/**
 * @fileoverview transpiled from org.dominokit.domino.cards.client.CardsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.cards.client.CardsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class CardsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CardsClientModule()'.
   * @return {!CardsClientModule}
   * @public
   */
  static $create__() {
    CardsClientModule.$clinit();
    let $instance = new CardsClientModule();
    $instance.$ctor__org_dominokit_domino_cards_client_CardsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CardsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_cards_client_CardsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    CardsClientModule.$f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_.m_info__java_lang_String("Initializing Cards frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_() {
    return (CardsClientModule.$clinit(), CardsClientModule.$f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_(value) {
    (CardsClientModule.$clinit(), CardsClientModule.$f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CardsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CardsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CardsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    CardsClientModule.$f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(CardsClientModule));
  }
  
  
};

$Util.$setClassMetadata(CardsClientModule, $Util.$makeClassName('org.dominokit.domino.cards.client.CardsClientModule'));


/** @private {Logger} */
CardsClientModule.$f_LOGGER__org_dominokit_domino_cards_client_CardsClientModule_;




exports = CardsClientModule; 
//# sourceMappingURL=CardsClientModule.js.map