/**
 * @fileoverview transpiled from org.dominokit.domino.cards.client.views.ui.CardsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.cards.client.views.ui.CardsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const CardsView = goog.require('org.dominokit.domino.cards.client.views.CardsView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.cards.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$17$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$18$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$20$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$9$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {CardsView}
  */
class CardsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'CardsViewImpl()'.
   * @return {!CardsViewImpl}
   * @public
   */
  static $create__() {
    CardsViewImpl.$clinit();
    let $instance = new CardsViewImpl();
    $instance.$ctor__org_dominokit_domino_cards_client_views_ui_CardsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CardsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_cards_client_views_ui_CardsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_cards_client_views_ui_CardsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.m_cardsWithHeaders___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl();
    this.m_coloredCards___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl();
    this.m_collapsibleCards___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl();
    this.m_noHeaderCards___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_cardsWithHeaders___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl() {
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("CARDS WITH HEADERS", "cards can have a header that has a Title and an optional description.").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Card Title", "Description text here...").m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$1(((/** Event */ event) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Card Title", "Description text here...").m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$2(((/** Event */ event$1$) =>{
      window.console.info("Play sound");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Card Title", "Description text here...").m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$3(((/** Event */ event$2$) =>{
      window.console.info("Play sound");
    }))).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$4(((/** Event */ event$3$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_cardsWithHeaders__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_coloredCards___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl() {
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("COLORED CARDS", "You can control the background color of card, card header and card body.").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Light Blue Card", "Description text here...").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$5(((/** Event */ event) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Light Green Card", "Description text here...").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$6(((/** Event */ event$1$) =>{
      window.console.info("Play sound");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Amber card", "Description text here...").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$7(((/** Event */ event$2$) =>{
      window.console.info("Play sound");
    }))).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$8(((/** Event */ event$3$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Pink Card", "Description text here...").m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$9(((/** Event */ event$4$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Blue Grey Card", "Description text here...").m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$10(((/** Event */ event$5$) =>{
      window.console.info("Play sound");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Deep Orange card", "Description text here...").m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_ORANGE__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$11(((/** Event */ event$6$) =>{
      window.console.info("Play sound");
    }))).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$12(((/** Event */ event$7$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Light Blue Card", "Description text here...").m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setBodyBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$13(((/** Event */ event$8$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Light Green Card", "Description text here...").m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setBodyBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$14(((/** Event */ event$9$) =>{
      window.console.info("Play sound");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Amber card", "Description text here...").m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_setBodyBackground__org_dominokit_domino_ui_style_Color(Color.f_AMBER__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$15(((/** Event */ event$10$) =>{
      window.console.info("Play sound");
    }))).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$16(((/** Event */ event$11$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_coloredCards__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_collapsibleCards___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl() {
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("COLLAPSIBLE CARDS", "cards can be collapsible.").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Card Title", "Description text here...").m_setCollapsible__().m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_THEME__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$17(((/** Event */ event) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Card Title", "Description text here...").m_setCollapsible__().m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_BROWN__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$18(((/** Event */ event$1$) =>{
      window.console.info("Play sound");
    }))).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__java_lang_String__java_lang_String("Card Title", "Description text here...").m_setCollapsible__().m_collapse__().m_setHeaderBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_AV_ICONS__org_dominokit_domino_ui_icons_Icons.m_mic__(), new $LambdaAdaptor$19(((/** Event */ event$2$) =>{
      window.console.info("Play sound");
    }))).m_addHeaderAction__org_dominokit_domino_ui_icons_Icon__elemental2_dom_EventListener(Icons.f_NAVIGATION_ICONS__org_dominokit_domino_ui_icons_Icons.m_more_vert__(), new $LambdaAdaptor$20(((/** Event */ event$3$) =>{
      window.console.info("More action selected");
    }))).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_collapsibleCards__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_noHeaderCards___$p_org_dominokit_domino_cards_client_views_ui_CardsViewImpl() {
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("NO HEADER CARDS", "You can also create cards without headers.").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(Card.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_BLUE__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(Card.m_create__().m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_appendContent__elemental2_dom_Node(new Text(CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_)).m_asElement__())).m_asElement__());
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_noHeaderCards__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_cards_client_views_ui_CardsViewImpl() {
    this.f_element__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CardsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CardsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CardsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.cards.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$17$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$18$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$20$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.cards.client.views.ui.CardsViewImpl.$LambdaAdaptor$9$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CardsViewImpl, $Util.$makeClassName('org.dominokit.domino.cards.client.views.ui.CardsViewImpl'));


/** @public {?string} @const */
CardsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_cards_client_views_ui_CardsViewImpl_ = "Quis pharetra a pharetra fames blandit. Risus faucibus velit Risus imperdiet mattis neque volutpat, etiam lacinia netus dictum magnis per facilisi sociosqu. Volutpat. Ridiculus nostra.";


CardsView.$markImplementor(CardsViewImpl);


exports = CardsViewImpl; 
//# sourceMappingURL=CardsViewImpl.js.map