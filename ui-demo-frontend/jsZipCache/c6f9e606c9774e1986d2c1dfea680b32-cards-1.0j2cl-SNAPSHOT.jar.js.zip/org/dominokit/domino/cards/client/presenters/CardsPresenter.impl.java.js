/**
 * @fileoverview transpiled from org.dominokit.domino.cards.client.presenters.CardsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.cards.client.presenters.CardsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.cards.client.presenters.CardsPresenter.$1$impl');
let CardsView = goog.forwardDeclare('org.dominokit.domino.cards.client.views.CardsView$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<CardsView>}
  */
class CardsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CardsPresenter()'.
   * @return {!CardsPresenter}
   * @public
   */
  static $create__() {
    CardsPresenter.$clinit();
    let $instance = new CardsPresenter();
    $instance.$ctor__org_dominokit_domino_cards_client_presenters_CardsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CardsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_cards_client_presenters_CardsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_cards_client_presenters_CardsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_cards_client_presenters_CardsPresenter_() {
    return (CardsPresenter.$clinit(), CardsPresenter.$f_LOGGER__org_dominokit_domino_cards_client_presenters_CardsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_cards_client_presenters_CardsPresenter_(value) {
    (CardsPresenter.$clinit(), CardsPresenter.$f_LOGGER__org_dominokit_domino_cards_client_presenters_CardsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CardsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CardsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CardsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.cards.client.presenters.CardsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    CardsPresenter.$f_LOGGER__org_dominokit_domino_cards_client_presenters_CardsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(CardsPresenter));
  }
  
  
};

$Util.$setClassMetadata(CardsPresenter, $Util.$makeClassName('org.dominokit.domino.cards.client.presenters.CardsPresenter'));


/** @private {Logger} */
CardsPresenter.$f_LOGGER__org_dominokit_domino_cards_client_presenters_CardsPresenter_;




exports = CardsPresenter; 
//# sourceMappingURL=CardsPresenter.js.map