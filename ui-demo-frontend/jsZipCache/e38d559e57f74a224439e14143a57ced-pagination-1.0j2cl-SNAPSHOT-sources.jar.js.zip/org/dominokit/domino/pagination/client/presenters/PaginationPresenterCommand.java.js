/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _PaginationPresenter = goog.require('org.dominokit.domino.pagination.client.presenters.PaginationPresenter');


// Re-exports the implementation.
var PaginationPresenterCommand = goog.require('org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand$impl');
exports = PaginationPresenterCommand;
 