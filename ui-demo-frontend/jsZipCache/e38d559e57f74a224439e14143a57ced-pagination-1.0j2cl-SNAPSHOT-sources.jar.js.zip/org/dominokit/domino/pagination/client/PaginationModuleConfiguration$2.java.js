/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.PaginationModuleConfiguration$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.pagination.client.PaginationModuleConfiguration.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _PaginationModuleConfiguration = goog.require('org.dominokit.domino.pagination.client.PaginationModuleConfiguration');
const _PaginationViewImpl = goog.require('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.pagination.client.PaginationModuleConfiguration.$2$impl');
exports = $2;
 