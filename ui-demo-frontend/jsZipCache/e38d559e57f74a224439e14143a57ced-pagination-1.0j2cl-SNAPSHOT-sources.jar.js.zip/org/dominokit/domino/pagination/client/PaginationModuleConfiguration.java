package org.dominokit.domino.pagination.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.ContributionsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.pagination.client.contributions.PaginationPresenterContributionToComponentsExtensionPoint;
import org.dominokit.domino.pagination.client.presenters.PaginationPresenter;
import org.dominokit.domino.pagination.client.presenters.PaginationPresenterCommand;
import org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class PaginationModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(PaginationPresenter.class.getCanonicalName(), PaginationPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new PaginationPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(PaginationPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new PaginationViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(PaginationPresenterCommand.class.getCanonicalName(), PaginationPresenter.class.getCanonicalName());
  }

  @Override
  public void registerContributions(ContributionsRegistry registry) {
    registry.registerContribution(ComponentsExtensionPoint.class, new PaginationPresenterContributionToComponentsExtensionPoint());
  }
}
