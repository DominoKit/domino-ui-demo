/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.contributions.AnimationPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.animation.client.contributions.AnimationPresenterContributionToComponentCaseExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let AnimationPresenter = goog.forwardDeclare('org.dominokit.domino.animation.client.presenters.AnimationPresenter$impl');
let AnimationPresenterCommand = goog.forwardDeclare('org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand$impl');
let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentCaseExtensionPoint>}
  */
class AnimationPresenterContributionToComponentCaseExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AnimationPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {!AnimationPresenterContributionToComponentCaseExtensionPoint}
   * @public
   */
  static $create__() {
    AnimationPresenterContributionToComponentCaseExtensionPoint.$clinit();
    let $instance = new AnimationPresenterContributionToComponentCaseExtensionPoint();
    $instance.$ctor__org_dominokit_domino_animation_client_contributions_AnimationPresenterContributionToComponentCaseExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnimationPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_animation_client_contributions_AnimationPresenterContributionToComponentCaseExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(extensionPoint) {
    AnimationPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** AnimationPresenter */ presenter) =>{
      presenter.m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(/**@type {ComponentCaseExtensionPoint} */ ($Casts.$to(arg0, ComponentCaseExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnimationPresenterContributionToComponentCaseExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnimationPresenterContributionToComponentCaseExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnimationPresenterContributionToComponentCaseExtensionPoint.$clinit = function() {};
    AnimationPresenterCommand = goog.module.get('org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand$impl');
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnimationPresenterContributionToComponentCaseExtensionPoint, $Util.$makeClassName('org.dominokit.domino.animation.client.contributions.AnimationPresenterContributionToComponentCaseExtensionPoint'));


Contribution.$markImplementor(AnimationPresenterContributionToComponentCaseExtensionPoint);


exports = AnimationPresenterContributionToComponentCaseExtensionPoint; 
//# sourceMappingURL=AnimationPresenterContributionToComponentCaseExtensionPoint.js.map