/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.animation.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_animation_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_animation_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_animation__() {
    CodeResource.$clinit();
    return "// Create an animation for the element and pass the transition type and other parameters \n" + "Animation.create(element)\n" + "        .transition(Transition.BOUNCE)\n" + "        .duration(1000)\n" + "        .animate();\n" + "\n" + "// Delay animation start\n" + "Animation.create(element)\n" + "        .transition(Transition.FLASH)\n" + "        .duration(1000)\n" + "        .delay(1000)\n" + "        .animate();\n" + "\n" + "// Make the animation infinite\n" + "Animation.create(element)\n" + "        .transition(Transition.FLIP)\n" + "        .duration(1000)\n" + "        .infinite()\n" + "        .animate();\n" + "\n" + "// Stop the infinite animation\n" + "Animation animation = Animation.create(element)\n" + "        .transition(Transition.TADA)\n" + "        .duration(1000)\n" + "        .infinite()\n" + "        .animate();\n" + "\n" + "animation.stop();";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.animation.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map