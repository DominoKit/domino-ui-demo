package org.dominokit.domino.animation.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface AnimationView extends View, DemoView{
}