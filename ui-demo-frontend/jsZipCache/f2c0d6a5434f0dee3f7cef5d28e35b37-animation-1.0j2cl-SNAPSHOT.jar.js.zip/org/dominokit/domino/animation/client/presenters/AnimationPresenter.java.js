/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.presenters.AnimationPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.animation.client.presenters.AnimationPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _$1 = goog.require('org.dominokit.domino.animation.client.presenters.AnimationPresenter.$1');
const _AnimationView = goog.require('org.dominokit.domino.animation.client.views.AnimationView');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var AnimationPresenter = goog.require('org.dominokit.domino.animation.client.presenters.AnimationPresenter$impl');
exports = AnimationPresenter;
 