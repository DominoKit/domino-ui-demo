package org.dominokit.domino.animation.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class AnimationPresenterContributionToComponentCaseExtensionPoint implements Contribution<ComponentCaseExtensionPoint> {
  @Override
  public void contribute(ComponentCaseExtensionPoint extensionPoint) {
    new AnimationPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentCaseModule(extensionPoint.context())).send();
  }
}
