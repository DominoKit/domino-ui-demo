/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.contributions.AnimationPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.animation.client.contributions.AnimationPresenterContributionToComponentCaseExtensionPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution');
const _AnimationPresenter = goog.require('org.dominokit.domino.animation.client.presenters.AnimationPresenter');
const _AnimationPresenterCommand = goog.require('org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseExtensionPoint = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AnimationPresenterContributionToComponentCaseExtensionPoint = goog.require('org.dominokit.domino.animation.client.contributions.AnimationPresenterContributionToComponentCaseExtensionPoint$impl');
exports = AnimationPresenterContributionToComponentCaseExtensionPoint;
 