/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Collapsible.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Collapsible$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


/**
 * @implements {IsElement<HTMLElement>}
 * @implements {IsCollapsible<Collapsible>}
  */
class Collapsible extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_;
    /** @public {boolean} */
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Collapsible(HTMLElement)'.
   * @param {HTMLElement} element
   * @return {!Collapsible}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(element) {
    Collapsible.$clinit();
    let $instance = new Collapsible();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_Collapsible__elemental2_dom_HTMLElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Collapsible(HTMLElement)'.
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_Collapsible__elemental2_dom_HTMLElement(element) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_collapsible_Collapsible();
    this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_ = element;
    if (!element.classList.contains("collapse")) {
      this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_.classList.add("collapse");
    }
  }
  
  /**
   * @param {HTMLElement} element
   * @return {Collapsible}
   * @public
   */
  static m_create__elemental2_dom_HTMLElement(element) {
    Collapsible.$clinit();
    return Collapsible.$create__elemental2_dom_HTMLElement(element);
  }
  
  /**
   * @override
   * @return {Collapsible}
   * @public
   */
  m_collapse__() {
    this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_.classList.remove("in");
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = true;
    return this;
  }
  
  /**
   * @override
   * @return {Collapsible}
   * @public
   */
  m_expand__() {
    this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_.classList.add("in");
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = false;
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isCollapsed__() {
    return this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_;
  }
  
  /**
   * @override
   * @return {Collapsible}
   * @public
   */
  m_toggle__() {
    if (this.m_isCollapsed__()) {
      this.m_expand__();
    } else {
      this.m_collapse__();
    }
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_collapsible_Collapsible() {
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Collapsible;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Collapsible);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Collapsible.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Collapsible, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Collapsible'));


IsElement.$markImplementor(Collapsible);
IsCollapsible.$markImplementor(Collapsible);


exports = Collapsible; 
//# sourceMappingURL=Collapsible.js.map