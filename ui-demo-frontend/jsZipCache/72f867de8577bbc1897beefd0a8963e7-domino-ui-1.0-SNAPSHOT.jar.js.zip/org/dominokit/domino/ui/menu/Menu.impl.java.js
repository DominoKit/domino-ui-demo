/**
 * @fileoverview transpiled from org.dominokit.domino.ui.menu.Menu.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.menu.Menu$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasActiveItem = goog.require('org.dominokit.domino.ui.utils.HasActiveItem$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let MenuItem = goog.forwardDeclare('org.dominokit.domino.ui.menu.MenuItem$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLDivElement>}
 * @implements {HasActiveItem<MenuItem>}
  */
class Menu extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_title__org_dominokit_domino_ui_menu_Menu_;
    /** @public {HTMLLIElement} */
    this.f_header__org_dominokit_domino_ui_menu_Menu_;
    /** @public {HTMLUListElement} */
    this.f_root__org_dominokit_domino_ui_menu_Menu_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_menu_Menu_;
    /** @public {MenuItem} */
    this.f_activeMenuItem__org_dominokit_domino_ui_menu_Menu_;
  }
  
  /**
   * Factory method corresponding to constructor 'Menu()'.
   * @return {!Menu}
   * @public
   */
  static $create__() {
    Menu.$clinit();
    let $instance = new Menu();
    $instance.$ctor__org_dominokit_domino_ui_menu_Menu__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Menu()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_menu_Menu__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_menu_Menu();
  }
  
  /**
   * @param {?string} title
   * @return {Menu}
   * @public
   */
  static m_create__java_lang_String(title) {
    Menu.$clinit();
    let menu = Menu.$create__();
    menu.f_title__org_dominokit_domino_ui_menu_Menu_.textContent = title;
    menu.f_root__org_dominokit_domino_ui_menu_Menu_.style.height = $Overlay.m_of__java_lang_Object("calc(100vh - 83px)");
    menu.m_asElement__().style.height = $Overlay.m_of__java_lang_Object("calc(100vh - 70px)");
    return menu;
  }
  
  /**
   * @param {?string} title
   * @param {Icon} icon
   * @return {MenuItem}
   * @public
   */
  m_addMenuItem__java_lang_String__org_dominokit_domino_ui_icons_Icon(title, icon) {
    let menuItem = MenuItem.m_createRootItem__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_utils_HasActiveItem_$pp_org_dominokit_domino_ui_menu(title, icon, this);
    this.f_root__org_dominokit_domino_ui_menu_Menu_.appendChild(menuItem.m_asElement__());
    return menuItem;
  }
  
  /**
   * @override
   * @return {MenuItem}
   * @public
   */
  m_getActiveItem__() {
    return this.f_activeMenuItem__org_dominokit_domino_ui_menu_Menu_;
  }
  
  /**
   * @param {MenuItem} activeItem
   * @return {void}
   * @public
   */
  m_setActiveItem__org_dominokit_domino_ui_menu_MenuItem(activeItem) {
    this.f_activeMenuItem__org_dominokit_domino_ui_menu_Menu_ = activeItem;
  }
  
  /**
   * @return {HTMLLIElement}
   * @public
   */
  m_getHeader__() {
    return this.f_header__org_dominokit_domino_ui_menu_Menu_;
  }
  
  /**
   * @return {HTMLUListElement}
   * @public
   */
  m_getRoot__() {
    return this.f_root__org_dominokit_domino_ui_menu_Menu_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getTitle__() {
    return this.f_title__org_dominokit_domino_ui_menu_Menu_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_menu_Menu_;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setActiveItem__java_lang_Object(arg0) {
    this.m_setActiveItem__org_dominokit_domino_ui_menu_MenuItem(/**@type {MenuItem} */ ($Casts.$to(arg0, MenuItem)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_menu_Menu() {
    this.f_title__org_dominokit_domino_ui_menu_Menu_ = Elements.m_span__().m_asElement__();
    this.f_header__org_dominokit_domino_ui_menu_Menu_ = /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["header", "menu-header"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_title__org_dominokit_domino_ui_menu_Menu_), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
    this.f_root__org_dominokit_domino_ui_menu_Menu_ = /**@type {HTMLUListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLUListElement>} */ ($Casts.$to(Elements.m_ul__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["list"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("height: calc(100vh - 70px)"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_header__org_dominokit_domino_ui_menu_Menu_), HtmlContentBuilder)).m_asElement__(), HTMLUListElement_$Overlay));
    this.f_element__org_dominokit_domino_ui_menu_Menu_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["menu"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("overflow-x: hidden"), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_root__org_dominokit_domino_ui_menu_Menu_), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Menu;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Menu);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Menu.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.CSSProperties.HeightUnionType.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    MenuItem = goog.module.get('org.dominokit.domino.ui.menu.MenuItem$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Menu, $Util.$makeClassName('org.dominokit.domino.ui.menu.Menu'));


IsElement.$markImplementor(Menu);
HasActiveItem.$markImplementor(Menu);


exports = Menu; 
//# sourceMappingURL=Menu.js.map