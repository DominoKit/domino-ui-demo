/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerElement$SelectionHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DatePickerElement = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class SelectionHandler {
  /**
   * @abstract
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_selectElement__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement) {
  }
  
  /**
   * @param {?function(DatePickerElement):void} fn
   * @return {SelectionHandler}
   * @public
   */
  static $adapt(fn) {
    SelectionHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePickerElement_SelectionHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SelectionHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SelectionHandler, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePickerElement$SelectionHandler'));


SelectionHandler.$markImplementor(/** @type {Function} */ (SelectionHandler));


exports = SelectionHandler; 
//# sourceMappingURL=DatePickerElement$SelectionHandler.js.map