/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DaySelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _JsDate_$Overlay = goog.require('elemental2.core.JsDate.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Double = goog.require('java.lang.Double');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _j_u_Date = goog.require('java.util.Date');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Column = goog.require('org.dominokit.domino.ui.column.Column');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$11');
const _$LambdaAdaptor$12 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$12');
const _$LambdaAdaptor$13 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$13');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$15');
const _BackgroundHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler');
const _DateSelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler');
const _DatePickerElement = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement');
const _DatePickerMonth = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ModalDialog = goog.require('org.dominokit.domino.ui.modals.ModalDialog');
const _PickerHandler = goog.require('org.dominokit.domino.ui.pickers.PickerHandler');
const _Row = goog.require('org.dominokit.domino.ui.row.Row');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _WavesSupport = goog.require('org.dominokit.domino.ui.style.WavesSupport');
const _DateTimeFormatInfo__factory = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfo_factory');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var DatePicker = goog.require('org.dominokit.domino.ui.datepicker.DatePicker$impl');
exports = DatePicker;
 