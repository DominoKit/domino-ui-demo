/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePickerMonth.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePickerMonth');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement.SelectionHandler');
const _HasSelectSupport = goog.require('org.dominokit.domino.ui.utils.HasSelectSupport');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _JsDate_$Overlay = goog.require('elemental2.core.JsDate.$Overlay');
const _$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLTableElement_$Overlay = goog.require('elemental2.dom.HTMLTableElement.$Overlay');
const _HTMLTableRowElement_$Overlay = goog.require('elemental2.dom.HTMLTableRowElement.$Overlay');
const _HTMLTableSectionElement_$Overlay = goog.require('elemental2.dom.HTMLTableSectionElement.$Overlay');
const _Double = goog.require('java.lang.Double');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _j_u_Date = goog.require('java.util.Date');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _DatePickerElement = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement');
const _DaySelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth.DaySelectionHandler');
const _MonthContext = goog.require('org.dominokit.domino.ui.datepicker.MonthContext');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _TextUtil = goog.require('org.dominokit.domino.ui.utils.TextUtil');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var DatePickerMonth = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth$impl');
exports = DatePickerMonth;
 