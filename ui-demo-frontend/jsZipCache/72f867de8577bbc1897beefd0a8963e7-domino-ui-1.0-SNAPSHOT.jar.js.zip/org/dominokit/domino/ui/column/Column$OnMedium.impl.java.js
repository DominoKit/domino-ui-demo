/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column$OnMedium.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.column.Column.OnMedium$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<OnMedium>}
  */
class OnMedium extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_column_Column_OnMedium_;
  }
  
  /**
   * Factory method corresponding to constructor 'OnMedium(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!OnMedium}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new OnMedium();
    $instance.$ctor__org_dominokit_domino_ui_column_Column_OnMedium__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'OnMedium(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_column_Column_OnMedium__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_column_Column_OnMedium_ = style;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_column_Column_OnMedium_;
  }
  
  /**
   * @param {string} name
   * @return {!OnMedium}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    OnMedium.$clinit();
    if ($Equality.$same(OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_, null)) {
      OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_ = $Enums.createMapFromValues(OnMedium.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_);
  }
  
  /**
   * @return {!Array<!OnMedium>}
   * @public
   */
  static m_values__() {
    OnMedium.$clinit();
    return /**@type {!Array<OnMedium>} */ ($Arrays.$init([OnMedium.$f_one__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_two__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_three__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_four__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_five__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_six__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_seven__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_eight__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_nine__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_ten__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium, OnMedium.$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium], OnMedium));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {OnMedium} */ ($Casts.$to(arg0, OnMedium)));
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_one__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_one__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_one__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_one__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_two__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_two__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_two__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_two__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_three__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_three__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_three__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_three__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_four__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_four__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_four__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_four__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_five__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_five__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_five__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_five__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_six__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_six__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_six__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_six__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_seven__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_seven__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_seven__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_seven__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_eight__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_eight__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_eight__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_eight__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_nine__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_nine__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_nine__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_nine__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_ten__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_ten__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_ten__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_ten__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_eleven__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_eleven__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {!OnMedium}
   * @public
   */
  static get f_twelve__org_dominokit_domino_ui_column_Column_OnMedium() {
    return (OnMedium.$clinit(), OnMedium.$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium);
  }
  
  /**
   * @param {!OnMedium} value
   * @return {void}
   * @public
   */
  static set f_twelve__org_dominokit_domino_ui_column_Column_OnMedium(value) {
    (OnMedium.$clinit(), OnMedium.$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium = value);
  }
  
  /**
   * @return {Map<?string, !OnMedium>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_() {
    return (OnMedium.$clinit(), OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_);
  }
  
  /**
   * @param {Map<?string, !OnMedium>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_(value) {
    (OnMedium.$clinit(), OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof OnMedium;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, OnMedium);
  }
  
  /**
   * @public
   */
  static $clinit() {
    OnMedium.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    OnMedium.$f_one__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("one"), OnMedium.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-1");
    OnMedium.$f_two__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("two"), OnMedium.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-2");
    OnMedium.$f_three__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("three"), OnMedium.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-3");
    OnMedium.$f_four__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("four"), OnMedium.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-4");
    OnMedium.$f_five__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("five"), OnMedium.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-5");
    OnMedium.$f_six__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("six"), OnMedium.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-6");
    OnMedium.$f_seven__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("seven"), OnMedium.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-7");
    OnMedium.$f_eight__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eight"), OnMedium.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-8");
    OnMedium.$f_nine__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("nine"), OnMedium.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-9");
    OnMedium.$f_ten__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ten"), OnMedium.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-10");
    OnMedium.$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eleven"), OnMedium.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-11");
    OnMedium.$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium = OnMedium.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("twelve"), OnMedium.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium, "col-md-12");
    OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(OnMedium, $Util.$makeClassName('org.dominokit.domino.ui.column.Column$OnMedium'));


/** @private {!OnMedium} */
OnMedium.$f_one__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_two__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_three__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_four__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_five__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_six__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_seven__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_eight__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_nine__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_ten__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {!OnMedium} */
OnMedium.$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium;


/** @private {Map<?string, !OnMedium>} */
OnMedium.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnMedium_;


/** @public {number} @const */
OnMedium.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnMedium = 0;


/** @public {number} @const */
OnMedium.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnMedium = 1;


/** @public {number} @const */
OnMedium.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnMedium = 2;


/** @public {number} @const */
OnMedium.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnMedium = 3;


/** @public {number} @const */
OnMedium.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnMedium = 4;


/** @public {number} @const */
OnMedium.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnMedium = 5;


/** @public {number} @const */
OnMedium.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnMedium = 6;


/** @public {number} @const */
OnMedium.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnMedium = 7;


/** @public {number} @const */
OnMedium.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnMedium = 8;


/** @public {number} @const */
OnMedium.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnMedium = 9;


/** @public {number} @const */
OnMedium.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnMedium = 10;


/** @public {number} @const */
OnMedium.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnMedium = 11;




exports = OnMedium; 
//# sourceMappingURL=Column$OnMedium.js.map