/**
 * @fileoverview transpiled from org.dominokit.domino.ui.layout.Section.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.layout.Section$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class Section extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_leftSide__org_dominokit_domino_ui_layout_Section_;
    /** @public {HTMLElement} */
    this.f_rightSide__org_dominokit_domino_ui_layout_Section_;
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_layout_Section_;
  }
  
  /**
   * Factory method corresponding to constructor 'Section()'.
   * @return {!Section}
   * @public
   */
  static $create__() {
    Section.$clinit();
    let $instance = new Section();
    $instance.$ctor__org_dominokit_domino_ui_layout_Section__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Section()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_layout_Section__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_layout_Section();
  }
  
  /**
   * @return {Section}
   * @public
   */
  static m_create__() {
    Section.$clinit();
    return Section.$create__();
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getLeftSide__() {
    return this.f_leftSide__org_dominokit_domino_ui_layout_Section_;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getRightSide__() {
    return this.f_rightSide__org_dominokit_domino_ui_layout_Section_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_layout_Section_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_layout_Section() {
    this.f_leftSide__org_dominokit_domino_ui_layout_Section_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_aside__().m_attr__java_lang_String__java_lang_String("id", "leftsidebar"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["sidebar"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_rightSide__org_dominokit_domino_ui_layout_Section_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_aside__().m_attr__java_lang_String__java_lang_String("id", "rightsidebar"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["right-sidebar", "overlay-open"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("right: 0px !important; height: calc(vh - 70px); overflow-y: scroll;"), HtmlContentBuilder)).m_asElement__();
    this.f_element__org_dominokit_domino_ui_layout_Section_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_section__().m_add__elemental2_dom_Node(this.f_leftSide__org_dominokit_domino_ui_layout_Section_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_rightSide__org_dominokit_domino_ui_layout_Section_), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Section;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Section);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Section.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Section, $Util.$makeClassName('org.dominokit.domino.ui.layout.Section'));


IsElement.$markImplementor(Section);


exports = Section; 
//# sourceMappingURL=Section.js.map