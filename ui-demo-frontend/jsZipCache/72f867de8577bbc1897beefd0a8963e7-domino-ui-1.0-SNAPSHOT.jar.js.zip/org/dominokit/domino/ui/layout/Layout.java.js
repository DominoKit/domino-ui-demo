/**
 * @fileoverview transpiled from org.dominokit.domino.ui.layout.Layout.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.layout.Layout');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsLayout = goog.require('org.dominokit.domino.ui.layout.IsLayout');
const _MarginLeftUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.MarginLeftUnionType.$Overlay');
const _MarginRightUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.MarginRightUnionType.$Overlay');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _Text_$Overlay = goog.require('elemental2.dom.Text.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Content = goog.require('org.dominokit.domino.ui.layout.Content');
const _$LambdaAdaptor$36 = goog.require('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$36');
const _$LambdaAdaptor$37 = goog.require('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$37');
const _$LambdaAdaptor$38 = goog.require('org.dominokit.domino.ui.layout.Layout.$LambdaAdaptor$38');
const _NavigationBar = goog.require('org.dominokit.domino.ui.layout.NavigationBar');
const _Section = goog.require('org.dominokit.domino.ui.layout.Section');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Theme = goog.require('org.dominokit.domino.ui.themes.Theme');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Layout = goog.require('org.dominokit.domino.ui.layout.Layout$impl');
exports = Layout;
 