/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.FormElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.FormElement$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasAutoValidation = goog.require('org.dominokit.domino.ui.utils.HasAutoValidation$impl');
const HasHelperText = goog.require('org.dominokit.domino.ui.utils.HasHelperText$impl');
const HasLabel = goog.require('org.dominokit.domino.ui.utils.HasLabel$impl');
const HasName = goog.require('org.dominokit.domino.ui.utils.HasName$impl');
const HasValidation = goog.require('org.dominokit.domino.ui.utils.HasValidation$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const IsRequired = goog.require('org.dominokit.domino.ui.utils.IsRequired$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');


/**
 * @interface
 * @template C_T, C_V
 * @extends {HasName<C_T>}
 * @extends {HasValue<C_V>}
 * @extends {Switchable<C_T>}
 * @extends {HasHelperText<C_T>}
 * @extends {HasLabel<C_T>}
 * @extends {HasValidation<C_T>}
 * @extends {HasAutoValidation<C_T>}
 * @extends {IsRequired<C_T>}
 */
class FormElement {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    HasName.$markImplementor(classConstructor);
    HasValue.$markImplementor(classConstructor);
    Switchable.$markImplementor(classConstructor);
    HasHelperText.$markImplementor(classConstructor);
    HasLabel.$markImplementor(classConstructor);
    HasValidation.$markImplementor(classConstructor);
    HasAutoValidation.$markImplementor(classConstructor);
    IsRequired.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_forms_FormElement = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_forms_FormElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_forms_FormElement;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormElement.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(FormElement, $Util.$makeClassName('org.dominokit.domino.ui.forms.FormElement'));


FormElement.$markImplementor(/** @type {Function} */ (FormElement));


exports = FormElement; 
//# sourceMappingURL=FormElement.js.map