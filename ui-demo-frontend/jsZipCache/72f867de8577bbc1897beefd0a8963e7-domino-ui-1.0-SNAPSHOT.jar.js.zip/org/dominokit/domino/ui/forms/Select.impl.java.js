/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Select$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement$impl');
const Focusable = goog.require('org.dominokit.domino.ui.utils.Focusable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLButtonElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let HTMLOptionElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOptionElement.$Overlay$impl');
let HTMLSelectElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLSelectElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let KeyboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $LambdaAdaptor$23 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$23$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$24$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$25$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$26$impl');
let $LambdaAdaptor$27 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$27$impl');
let $LambdaAdaptor$28 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$28$impl');
let $LambdaAdaptor$29 = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$29$impl');
let NavigateOptionsKeyListener = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.NavigateOptionsKeyListener$impl');
let SelectElement = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectElement$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let TextContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BasicFormElement<Select, ?string>}
 * @implements {Focusable<Select>}
  */
class Select extends BasicFormElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_container__org_dominokit_domino_ui_forms_Select_;
    /** @public {SelectElement} */
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_;
    /** @public {HTMLLabelElement} */
    this.f_labelElement__org_dominokit_domino_ui_forms_Select_;
    /** @public {List<SelectOption>} */
    this.f_options__org_dominokit_domino_ui_forms_Select_;
    /** @public {SelectOption} */
    this.f_selectedOption__org_dominokit_domino_ui_forms_Select_;
    /** @public {List<SelectionHandler>} */
    this.f_selectionHandlers__org_dominokit_domino_ui_forms_Select_;
    /** @public {SelectionHandler} */
    this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_;
    /** @public {Color} */
    this.f_focusColor__org_dominokit_domino_ui_forms_Select_;
  }
  
  /**
   * Factory method corresponding to constructor 'Select()'.
   * @return {!Select}
   * @public
   */
  static $create__() {
    Select.$clinit();
    let $instance = new Select();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Select()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select__() {
    this.$ctor__org_dominokit_domino_ui_forms_BasicFormElement__();
    this.$init__org_dominokit_domino_ui_forms_Select();
    this.m_initListeners___$p_org_dominokit_domino_ui_forms_Select();
    this.f_container__org_dominokit_domino_ui_forms_Select_.appendChild(this.f_labelElement__org_dominokit_domino_ui_forms_Select_);
    this.f_container__org_dominokit_domino_ui_forms_Select_.appendChild(this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initListeners___$p_org_dominokit_domino_ui_forms_Select() {
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.addEventListener(Select.f_CLICK__org_dominokit_domino_ui_forms_Select_, new $LambdaAdaptor$23(((/** Event */ evt) =>{
      let element = /**@type {HTMLElement} */ (Js.m_uncheckedCast__java_lang_Object(evt.target));
      if (!element.isEqualNode(this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__())) {
        this.m_hideAllMenus__();
      }
    })));
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.addEventListener(Select.f_KEYDOWN__org_dominokit_domino_ui_forms_Select_, NavigateOptionsKeyListener.$create__org_dominokit_domino_ui_forms_Select(this));
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectButton__().addEventListener(Select.f_CLICK__org_dominokit_domino_ui_forms_Select_, new $LambdaAdaptor$24(((/** Event */ evt$1$) =>{
      this.m_doOpen___$p_org_dominokit_domino_ui_forms_Select();
      this.m_focus__();
      evt$1$.stopPropagation();
    })));
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().addEventListener("focusin", new $LambdaAdaptor$25(((/** Event */ evt$2$) =>{
      this.m_focus__();
    })));
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().addEventListener("focusout", new $LambdaAdaptor$26(((/** Event */ evt$3$) =>{
      this.m_unfocus__();
    })));
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectButton__().addEventListener("focus", new $LambdaAdaptor$27(((/** Event */ evt$4$) =>{
      this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectButton__().blur();
    })));
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().addEventListener(Select.f_KEYDOWN__org_dominokit_domino_ui_forms_Select_, new $LambdaAdaptor$28(((/** Event */ evt$5$) =>{
      let keyboardEvent = /**@type {KeyboardEvent} */ ($Casts.$to(evt$5$, KeyboardEvent_$Overlay));
      if (ElementUtil.m_isSpaceKey__elemental2_dom_KeyboardEvent(keyboardEvent) || ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(keyboardEvent)) {
        this.m_doOpen___$p_org_dominokit_domino_ui_forms_Select();
        evt$5$.preventDefault();
      }
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_doOpen___$p_org_dominokit_domino_ui_forms_Select() {
    if (this.m_isEnabled__()) {
      this.m_hideAllMenus__();
      this.m_open__();
      if (Objects.m_nonNull__java_lang_Object(this.m_getSelectedOption__())) {
        this.m_getSelectedOption__().m_focus__();
      } else if (!this.f_options__org_dominokit_domino_ui_forms_Select_.isEmpty()) {
        /**@type {SelectOption} */ ($Casts.$to(this.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(0), SelectOption)).m_focus__();
      }
    }
  }
  
  /**
   * Factory method corresponding to constructor 'Select(String)'.
   * @param {?string} label
   * @return {!Select}
   * @public
   */
  static $create__java_lang_String(label) {
    Select.$clinit();
    let $instance = new Select();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select__java_lang_String(label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Select(String)'.
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select__java_lang_String(label) {
    this.$ctor__org_dominokit_domino_ui_forms_Select__();
    this.m_setLabel__java_lang_String(label);
  }
  
  /**
   * Factory method corresponding to constructor 'Select(List)'.
   * @param {List<SelectOption>} options
   * @return {!Select}
   * @public
   */
  static $create__java_util_List(options) {
    Select.$clinit();
    let $instance = new Select();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select__java_util_List(options);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Select(List)'.
   * @param {List<SelectOption>} options
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select__java_util_List(options) {
    this.$ctor__org_dominokit_domino_ui_forms_Select__java_lang_String__java_util_List("", options);
  }
  
  /**
   * Factory method corresponding to constructor 'Select(String, List)'.
   * @param {?string} label
   * @param {List<SelectOption>} options
   * @return {!Select}
   * @public
   */
  static $create__java_lang_String__java_util_List(label, options) {
    Select.$clinit();
    let $instance = new Select();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select__java_lang_String__java_util_List(label, options);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Select(String, List)'.
   * @param {?string} label
   * @param {List<SelectOption>} options
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select__java_lang_String__java_util_List(label, options) {
    this.$ctor__org_dominokit_domino_ui_forms_Select__java_lang_String(label);
    options.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectOption */ arg0) =>{
      this.m_addOption__org_dominokit_domino_ui_forms_SelectOption(arg0);
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_open__() {
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__().classList.add(Select.f_OPEN__org_dominokit_domino_ui_forms_Select_);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_hideAllMenus__() {
    let elementsByName = $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.getElementsByClassName("bootstrap-select");
    for (let i = 0; i < elementsByName.length; i++) {
      let item = /**@type {Element} */ ($Casts.$to(elementsByName.item(i), Element_$Overlay));
      if (item.classList.contains(Select.f_OPEN__org_dominokit_domino_ui_forms_Select_)) {
        this.m_close__elemental2_dom_Element_$p_org_dominokit_domino_ui_forms_Select(item);
      }
    }
  }
  
  /**
   * @param {Element} item
   * @return {void}
   * @public
   */
  m_close__elemental2_dom_Element_$p_org_dominokit_domino_ui_forms_Select(item) {
    item.classList.remove(Select.f_OPEN__org_dominokit_domino_ui_forms_Select_);
    this.m_unfocus__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_close__() {
    this.m_close__elemental2_dom_Element_$p_org_dominokit_domino_ui_forms_Select(this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__());
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isOpened___$p_org_dominokit_domino_ui_forms_Select() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__().classList.contains(Select.f_OPEN__org_dominokit_domino_ui_forms_Select_);
  }
  
  /**
   * @return {Select}
   * @public
   */
  static m_create__() {
    Select.$clinit();
    return Select.$create__();
  }
  
  /**
   * @param {?string} label
   * @return {Select}
   * @public
   */
  static m_create__java_lang_String(label) {
    Select.$clinit();
    return Select.$create__java_lang_String(label);
  }
  
  /**
   * @param {?string} label
   * @param {List<SelectOption>} options
   * @return {Select}
   * @public
   */
  static m_create__java_lang_String__java_util_List(label, options) {
    Select.$clinit();
    return Select.$create__java_lang_String__java_util_List(label, options);
  }
  
  /**
   * @param {List<SelectOption>} options
   * @return {Select}
   * @public
   */
  static m_create__java_util_List(options) {
    Select.$clinit();
    return Select.$create__java_util_List(options);
  }
  
  /**
   * @param {SelectOption} option
   * @return {Select}
   * @public
   */
  m_addOption__org_dominokit_domino_ui_forms_SelectOption(option) {
    this.f_options__org_dominokit_domino_ui_forms_Select_.add(option);
    option.m_asElement__().addEventListener(Select.f_CLICK__org_dominokit_domino_ui_forms_Select_, new $LambdaAdaptor$29(((/** Event */ evt) =>{
      this.m_doSelectOption__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option);
      evt.stopPropagation();
    })));
    this.m_appendOptionValue__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option);
    return this;
  }
  
  /**
   * @param {SelectOption} option
   * @return {void}
   * @public
   */
  m_doSelectOption__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option) {
    if (this.m_isEnabled__()) {
      this.m_select__org_dominokit_domino_ui_forms_SelectOption(option);
      this.m_close__();
    }
  }
  
  /**
   * @param {SelectOption} option
   * @return {void}
   * @public
   */
  m_appendOptionValue__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option) {
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getOptionsList__().appendChild(option.m_asElement__());
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().appendChild(/**@type {TextContentBuilder<HTMLOptionElement>} */ ($Casts.$to(/**@type {TextContentBuilder<HTMLOptionElement>} */ ($Casts.$to(Elements.m_option__().m_attr__java_lang_String__java_lang_String("value", option.m_getValue__()), TextContentBuilder)).m_textContent__java_lang_String(option.m_getDisplayValue__()), TextContentBuilder)).m_asElement__());
  }
  
  /**
   * @param {number} index
   * @return {Select}
   * @public
   */
  m_selectAt__int(index) {
    return this.m_selectAt__int__boolean(index, false);
  }
  
  /**
   * @param {number} index
   * @param {boolean} silent
   * @return {Select}
   * @public
   */
  m_selectAt__int__boolean(index, silent) {
    if (index < this.f_options__org_dominokit_domino_ui_forms_Select_.size() && index >= 0) {
      this.m_select__org_dominokit_domino_ui_forms_SelectOption__boolean(/**@type {SelectOption} */ ($Casts.$to(this.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(index), SelectOption)), silent);
    }
    return this;
  }
  
  /**
   * @param {number} index
   * @return {SelectOption}
   * @public
   */
  m_getOptionAt__int(index) {
    if (index < this.f_options__org_dominokit_domino_ui_forms_Select_.size() && index >= 0) {
      return /**@type {SelectOption} */ ($Casts.$to(this.f_options__org_dominokit_domino_ui_forms_Select_.getAtIndex(index), SelectOption));
    }
    return null;
  }
  
  /**
   * @return {List<SelectOption>}
   * @public
   */
  m_getOptions__() {
    return this.f_options__org_dominokit_domino_ui_forms_Select_;
  }
  
  /**
   * @param {SelectOption} option
   * @return {Select}
   * @public
   */
  m_select__org_dominokit_domino_ui_forms_SelectOption(option) {
    return this.m_select__org_dominokit_domino_ui_forms_SelectOption__boolean(option, false);
  }
  
  /**
   * @param {SelectOption} option
   * @param {boolean} silent
   * @return {Select}
   * @public
   */
  m_select__org_dominokit_domino_ui_forms_SelectOption__boolean(option, silent) {
    if (!$Equality.$same(this.f_selectedOption__org_dominokit_domino_ui_forms_Select_, null)) {
      if (!option.m_asElement__().isEqualNode(this.f_selectedOption__org_dominokit_domino_ui_forms_Select_.m_asElement__())) {
        this.f_selectedOption__org_dominokit_domino_ui_forms_Select_.m_deselect__();
      }
    }
    this.f_selectedOption__org_dominokit_domino_ui_forms_Select_ = option;
    option.m_select__();
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectedValueContainer__().textContent = option.m_getDisplayValue__();
    if (!silent) {
      this.m_onSelection__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option);
    }
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isSelected__() {
    return !this.m_isEmpty__();
  }
  
  /**
   * @param {SelectOption} option
   * @return {void}
   * @public
   */
  m_onSelection__org_dominokit_domino_ui_forms_SelectOption_$p_org_dominokit_domino_ui_forms_Select(option) {
    for (let $iterator = this.f_selectionHandlers__org_dominokit_domino_ui_forms_Select_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let handler = /**@type {SelectionHandler} */ ($Casts.$to($iterator.m_next__(), SelectionHandler));
      handler.m_onSelection__org_dominokit_domino_ui_forms_SelectOption(option);
    }
  }
  
  /**
   * @param {SelectionHandler} selectionHandler
   * @return {Select}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(selectionHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_forms_Select_.add(selectionHandler);
    return this;
  }
  
  /**
   * @return {SelectOption}
   * @public
   */
  m_getSelectedOption__() {
    return this.f_selectedOption__org_dominokit_domino_ui_forms_Select_;
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_enable__() {
    super.m_enable__();
    this.m_asElement__().classList.remove("disabled");
    this.m_getSelectButton__().classList.remove("disabled");
    return this;
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_disable__() {
    super.m_disable__();
    this.m_asElement__().classList.add("disabled");
    this.m_getSelectButton__().classList.add("disabled");
    return this;
  }
  
  /**
   * @return {Select}
   * @public
   */
  m_dropup__() {
    this.m_asElement__().classList.remove("dropup");
    this.m_asElement__().classList.add("dropup");
    return this;
  }
  
  /**
   * @return {Select}
   * @public
   */
  m_dropdown__() {
    this.m_asElement__().classList.remove("dropup");
    return this;
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_String(value) {
    for (let $iterator = this.m_getOptions__().m_iterator__(); $iterator.m_hasNext__(); ) {
      let option = /**@type {SelectOption} */ ($Casts.$to($iterator.m_next__(), SelectOption));
      if (Objects.m_equals__java_lang_String__java_lang_String(option.m_getValue__(), value)) {
        this.m_select__org_dominokit_domino_ui_forms_SelectOption(option);
      }
    }
  }
  
  /**
   * @param {?string} value
   * @param {boolean} silent
   * @return {void}
   * @public
   */
  m_setValue__java_lang_String__boolean(value, silent) {
    for (let $iterator = this.m_getOptions__().m_iterator__(); $iterator.m_hasNext__(); ) {
      let option = /**@type {SelectOption} */ ($Casts.$to($iterator.m_next__(), SelectOption));
      if (Objects.m_equals__java_lang_String__java_lang_String(option.m_getValue__(), value)) {
        this.m_select__org_dominokit_domino_ui_forms_SelectOption__boolean(option, silent);
      }
    }
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return this.m_isSelected__() ? this.m_getSelectedOption__().m_getValue__() : "";
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return Objects.m_isNull__java_lang_Object(this.f_selectedOption__org_dominokit_domino_ui_forms_Select_);
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_clear__() {
    this.m_getOptions__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectOption */ selectOption) =>{
      selectOption.m_deselect__boolean(true);
    })));
    this.f_selectedOption__org_dominokit_domino_ui_forms_Select_ = null;
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectedValueContainer__().textContent = "";
    if (this.m_isAutoValidation__()) {
      this.m_validate__();
    }
    return this;
  }
  
  /**
   * @param {?string} formId
   * @return {Select}
   * @public
   */
  m_setFormId__java_lang_String(formId) {
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.m_getSelectMenu__(), "form", formId);
    return this;
  }
  
  /**
   * @override
   * @param {?string} errorMessage
   * @return {Select}
   * @public
   */
  m_invalidate__java_lang_String(errorMessage) {
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__().classList.add("fc-" + j_l_String.m_valueOf__java_lang_Object(Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()));
    this.f_labelElement__org_dominokit_domino_ui_forms_Select_.classList.add(Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__());
    return /**@type {Select} */ ($Casts.$to(super.m_invalidate__java_lang_String(errorMessage), Select));
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_clearInvalid__() {
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__().classList.remove("fc-" + j_l_String.m_valueOf__java_lang_Object(Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()));
    this.f_labelElement__org_dominokit_domino_ui_forms_Select_.classList.remove(Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__());
    return /**@type {Select} */ ($Casts.$to(super.m_clearInvalid__(), Select));
  }
  
  /**
   * @param {SelectionHandler} selectionHandler
   * @return {Select}
   * @public
   */
  m_removeSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(selectionHandler) {
    if (Objects.m_nonNull__java_lang_Object(selectionHandler)) {
      this.f_selectionHandlers__org_dominokit_domino_ui_forms_Select_.remove(selectionHandler);
    }
    return this;
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_focus__() {
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().classList.add(Select.f_FOCUSED__org_dominokit_domino_ui_forms_Select_);
    this.f_labelElement__org_dominokit_domino_ui_forms_Select_.classList.add(this.f_focusColor__org_dominokit_domino_ui_forms_Select_.m_getStyle__());
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__().classList.add("fc-" + j_l_String.m_valueOf__java_lang_Object(this.f_focusColor__org_dominokit_domino_ui_forms_Select_.m_getStyle__()));
    return this;
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_unfocus__() {
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().classList.remove(Select.f_FOCUSED__org_dominokit_domino_ui_forms_Select_);
    this.f_labelElement__org_dominokit_domino_ui_forms_Select_.classList.remove(this.f_focusColor__org_dominokit_domino_ui_forms_Select_.m_getStyle__());
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_asElement__().classList.remove("fc-" + j_l_String.m_valueOf__java_lang_Object(this.f_focusColor__org_dominokit_domino_ui_forms_Select_.m_getStyle__()));
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isFocused__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__().classList.contains(Select.f_FOCUSED__org_dominokit_domino_ui_forms_Select_);
  }
  
  /**
   * @override
   * @param {Color} focusColor
   * @return {Select}
   * @public
   */
  m_setFocusColor__org_dominokit_domino_ui_style_Color(focusColor) {
    this.m_unfocus__();
    this.f_focusColor__org_dominokit_domino_ui_forms_Select_ = focusColor;
    if (this.m_isFocused__()) {
      this.m_focus__();
    }
    return this;
  }
  
  /**
   * @param {SelectOption} option
   * @return {Select}
   * @public
   */
  m_removeOption__org_dominokit_domino_ui_forms_SelectOption(option) {
    if (Objects.m_nonNull__java_lang_Object(option) && this.m_getOptions__().contains(option)) {
      option.m_deselect__boolean(true);
      this.f_options__org_dominokit_domino_ui_forms_Select_.remove(option);
      option.m_asElement__().remove();
    }
    return this;
  }
  
  /**
   * @param {Collection<SelectOption>} options
   * @return {Select}
   * @public
   */
  m_removeOptions__java_util_Collection(options) {
    if (Objects.m_nonNull__java_lang_Object(options) && !options.isEmpty() && !this.f_options__org_dominokit_domino_ui_forms_Select_.isEmpty()) {
      options.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectOption */ arg0) =>{
        this.m_removeOption__org_dominokit_domino_ui_forms_SelectOption(arg0);
      })));
    }
    return this;
  }
  
  /**
   * @return {Select}
   * @public
   */
  m_removeAllOptions__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_options__org_dominokit_domino_ui_forms_Select_) && !this.f_options__org_dominokit_domino_ui_forms_Select_.isEmpty()) {
      this.f_options__org_dominokit_domino_ui_forms_Select_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectOption */ arg0) =>{
        this.m_removeOption__org_dominokit_domino_ui_forms_SelectOption(arg0);
      })));
    }
    return this;
  }
  
  /**
   * @return {HTMLButtonElement}
   * @public
   */
  m_getSelectButton__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectButton__();
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getDropDownMenu__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getDropDownMenu__();
  }
  
  /**
   * @return {HTMLUListElement}
   * @public
   */
  m_getOptionsList__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getOptionsList__();
  }
  
  /**
   * @return {HTMLSelectElement}
   * @public
   */
  m_getSelectMenu__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectMenu__();
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getSelectedValueContainer__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.m_getSelectedValueContainer__();
  }
  
  /**
   * @override
   * @param {boolean} autoValidation
   * @return {Select}
   * @public
   */
  m_setAutoValidation__boolean(autoValidation) {
    if (autoValidation) {
      if (Objects.m_isNull__java_lang_Object(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_)) {
        this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_ = SelectionHandler.$adapt(((/** SelectOption */ option) =>{
          this.m_validate__();
        }));
        this.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_);
      }
    } else {
      this.m_removeSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_);
      this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_ = null;
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isAutoValidation__() {
    return Objects.m_nonNull__java_lang_Object(this.f_autoValidationHandler__org_dominokit_domino_ui_forms_Select_);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getInputElement__() {
    return this.f_selectElement__org_dominokit_domino_ui_forms_Select_.f_selectMenu__org_dominokit_domino_ui_forms_Select_SelectElement_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getLabelElement__() {
    return this.f_labelElement__org_dominokit_domino_ui_forms_Select_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getContainer__() {
    return this.f_container__org_dominokit_domino_ui_forms_Select_;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_lang_String(/**@type {?string} */ ($Casts.$to(arg0, j_l_String)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_Select() {
    this.f_container__org_dominokit_domino_ui_forms_Select_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_selectElement__org_dominokit_domino_ui_forms_Select_ = SelectElement.m_create__();
    this.f_labelElement__org_dominokit_domino_ui_forms_Select_ = /**@type {HTMLLabelElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-label"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_options__org_dominokit_domino_ui_forms_Select_ = /**@type {!LinkedList<SelectOption>} */ (LinkedList.$create__());
    this.f_selectionHandlers__org_dominokit_domino_ui_forms_Select_ = /**@type {!ArrayList<SelectionHandler>} */ (ArrayList.$create__());
    this.f_focusColor__org_dominokit_domino_ui_forms_Select_ = Color.f_BLUE__org_dominokit_domino_ui_style_Color;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Select;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Select);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Select.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    KeyboardEvent_$Overlay = goog.module.get('elemental2.dom.KeyboardEvent.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $LambdaAdaptor$23 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$23$impl');
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$24$impl');
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$25$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$26$impl');
    $LambdaAdaptor$27 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$27$impl');
    $LambdaAdaptor$28 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$28$impl');
    $LambdaAdaptor$29 = goog.module.get('org.dominokit.domino.ui.forms.Select.$LambdaAdaptor$29$impl');
    NavigateOptionsKeyListener = goog.module.get('org.dominokit.domino.ui.forms.Select.NavigateOptionsKeyListener$impl');
    SelectElement = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectElement$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    TextContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BasicFormElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Select, $Util.$makeClassName('org.dominokit.domino.ui.forms.Select'));


/** @public {?string} @const */
Select.f_OPEN__org_dominokit_domino_ui_forms_Select_ = "open";


/** @public {?string} @const */
Select.f_CLICK__org_dominokit_domino_ui_forms_Select_ = "click";


/** @public {?string} @const */
Select.f_KEYDOWN__org_dominokit_domino_ui_forms_Select_ = "keydown";


/** @public {?string} @const */
Select.f_FOCUSED__org_dominokit_domino_ui_forms_Select_ = "focused";


Focusable.$markImplementor(Select);


exports = Select; 
//# sourceMappingURL=Select.js.map