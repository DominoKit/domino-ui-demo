/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.ValueBox.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.ValueBox$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement$impl');
const Focusable = goog.require('org.dominokit.domino.ui.utils.Focusable$impl');
const HasPlaceHolder = goog.require('org.dominokit.domino.ui.utils.HasPlaceHolder$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $LambdaAdaptor$32 = goog.forwardDeclare('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$32$impl');
let $LambdaAdaptor$33 = goog.forwardDeclare('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$33$impl');
let $LambdaAdaptor$34 = goog.forwardDeclare('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$34$impl');
let $LambdaAdaptor$35 = goog.forwardDeclare('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$35$impl');
let ValueBoxSize = goog.forwardDeclare('org.dominokit.domino.ui.forms.ValueBox.ValueBoxSize$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_T, C_E, C_V
 * @extends {BasicFormElement<C_T, C_V>}
 * @implements {Focusable<C_T>}
 * @implements {HasPlaceHolder<C_T>}
  */
class ValueBox extends BasicFormElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_container__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {C_E} */
    this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {HTMLDivElement} */
    this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {HTMLLabelElement} */
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {HTMLElement} */
    this.f_leftAddonContainer__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {HTMLElement} */
    this.f_rightAddonContainer__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {ValueBoxSize} */
    this.f_size__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {boolean} */
    this.f_floating__org_dominokit_domino_ui_forms_ValueBox_ = false;
    /** @public {?string} */
    this.f_placeholder__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {Color} */
    this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {Element} */
    this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {Element} */
    this.f_rightAddon__org_dominokit_domino_ui_forms_ValueBox_;
    /** @public {boolean} */
    this.f_valid__org_dominokit_domino_ui_forms_ValueBox_ = false;
    /** @public {EventListener} */
    this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_;
  }
  
  /**
   * Initialization from constructor 'ValueBox(String, String)'.
   * @param {?string} type
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_ValueBox__java_lang_String__java_lang_String(type, label) {
    this.$ctor__org_dominokit_domino_ui_forms_BasicFormElement__();
    this.$init__org_dominokit_domino_ui_forms_ValueBox();
    this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_ = this.m_createInputElement__java_lang_String(type);
    this.f_container__org_dominokit_domino_ui_forms_ValueBox_.appendChild(this.f_leftAddonContainer__org_dominokit_domino_ui_forms_ValueBox_);
    this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_.appendChild(this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_);
    this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_.appendChild(this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_);
    this.f_container__org_dominokit_domino_ui_forms_ValueBox_.appendChild(this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_);
    this.f_container__org_dominokit_domino_ui_forms_ValueBox_.appendChild(this.f_rightAddonContainer__org_dominokit_domino_ui_forms_ValueBox_);
    this.m_setFocusColor__org_dominokit_domino_ui_style_Color(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    this.m_addFocusListeners___$p_org_dominokit_domino_ui_forms_ValueBox();
    this.m_setLabel__java_lang_String(label);
  }
  
  /**
   * @abstract
   * @param {?string} type
   * @return {C_E}
   * @public
   */
  m_createInputElement__java_lang_String(type) {
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addFocusListeners___$p_org_dominokit_domino_ui_forms_ValueBox() {
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).addEventListener("focusin", new $LambdaAdaptor$32(((/** Event */ evt) =>{
      this.m_focus__();
    })));
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).addEventListener("focusout", new $LambdaAdaptor$33(((/** Event */ evt$1$) =>{
      this.m_unfocus__();
    })));
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.addEventListener("click", new $LambdaAdaptor$34(((/** Event */ evt$2$) =>{
      /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).focus();
    })));
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_large__() {
    return this.m_setSize__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize(ValueBoxSize.f_LARGE__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize);
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_small__() {
    return this.m_setSize__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize(ValueBoxSize.f_SMALL__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize);
  }
  
  /**
   * @param {ValueBoxSize} size
   * @return {C_T}
   * @public
   */
  m_setSize__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize(size) {
    if (!$Equality.$same(this.f_size__org_dominokit_domino_ui_forms_ValueBox_, null)) {
      this.f_container__org_dominokit_domino_ui_forms_ValueBox_.classList.remove(size.m_getStyle__());
    }
    this.f_container__org_dominokit_domino_ui_forms_ValueBox_.classList.add(size.m_getStyle__());
    this.m_setAddonsSize__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_$p_org_dominokit_domino_ui_forms_ValueBox(size);
    this.f_size__org_dominokit_domino_ui_forms_ValueBox_ = size;
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @param {ValueBoxSize} size
   * @return {void}
   * @public
   */
  m_setAddonsSize__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_$p_org_dominokit_domino_ui_forms_ValueBox(size) {
    this.m_setAddonSize__elemental2_dom_Element__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_, size);
    this.m_setAddonSize__elemental2_dom_Element__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_rightAddon__org_dominokit_domino_ui_forms_ValueBox_, size);
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_floating__() {
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.add(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
    this.m_showPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox();
    this.f_floating__org_dominokit_domino_ui_forms_ValueBox_ = true;
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_nonfloating__() {
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.remove(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
    this.m_hidePlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox();
    this.f_floating__org_dominokit_domino_ui_forms_ValueBox_ = false;
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isFloating__() {
    return this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.contains(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_focus__() {
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.add(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
    this.m_floatLabel__();
    if (this.f_valid__org_dominokit_domino_ui_forms_ValueBox_) {
      /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.add("fc-" + j_l_String.m_valueOf__java_lang_Object(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_.m_getStyle__()));
      this.m_setLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
      this.m_setLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    }
    this.m_showPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox();
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_unfocus__() {
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.remove("fc-" + j_l_String.m_valueOf__java_lang_Object(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_.m_getStyle__()));
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.remove(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
    this.m_unfloatLabel__();
    this.m_removeLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    this.m_removeLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    this.m_hidePlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox();
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @param {Color} focusColor
   * @return {void}
   * @public
   */
  m_setLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(focusColor) {
    if (!$Equality.$same(this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_, null)) {
      this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_.classList.add(focusColor.m_getStyle__());
    }
  }
  
  /**
   * @param {Color} focusColor
   * @return {void}
   * @public
   */
  m_removeLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(focusColor) {
    if (!$Equality.$same(this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_, null)) {
      this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_.classList.remove(focusColor.m_getStyle__());
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isFocused__() {
    return /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.contains(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
  }
  
  /**
   * @param {Color} color
   * @return {void}
   * @public
   */
  m_setLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(color) {
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.add(color.m_getStyle__());
  }
  
  /**
   * @param {Color} color
   * @return {void}
   * @public
   */
  m_removeLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(color) {
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.remove(color.m_getStyle__());
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_enable__() {
    super.m_enable__();
    this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_.classList.remove("disabled");
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_disable__() {
    super.m_disable__();
    this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_.classList.add("disabled");
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @param {?string} label
   * @return {C_T}
   * @public
   */
  m_setLabel__java_lang_String(label) {
    super.m_setLabel__java_lang_String(label);
    this.m_hidePlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox();
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @param {?string} placeholder
   * @return {C_T}
   * @public
   */
  m_setPlaceholder__java_lang_String(placeholder) {
    this.f_placeholder__org_dominokit_domino_ui_forms_ValueBox_ = placeholder;
    this.m_showPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox();
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_showPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox() {
    if (!$Equality.$same(this.f_placeholder__org_dominokit_domino_ui_forms_ValueBox_, null) && this.m_shouldShowPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox()) {
      $Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_, "placeholder", this.f_placeholder__org_dominokit_domino_ui_forms_ValueBox_);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_hidePlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox() {
    if (!$Equality.$same(this.f_placeholder__org_dominokit_domino_ui_forms_ValueBox_, null) && !this.m_shouldShowPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox()) {
      /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).removeAttribute("placeholder");
    }
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_shouldShowPlaceholder___$p_org_dominokit_domino_ui_forms_ValueBox() {
    return j_l_String.m_isEmpty__java_lang_String(this.m_getLabel__()) || this.m_isFloating__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getPlaceholder__() {
    return this.f_placeholder__org_dominokit_domino_ui_forms_ValueBox_;
  }
  
  /**
   * @override
   * @param {Color} focusColor
   * @return {C_T}
   * @public
   */
  m_setFocusColor__org_dominokit_domino_ui_style_Color(focusColor) {
    this.m_removeLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    if (this.m_isFocused__()) {
      this.m_setLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(focusColor);
      this.m_setLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(focusColor);
    }
    this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_ = focusColor;
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getContainer__() {
    return this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_;
  }
  
  /**
   * @param {Icon} icon
   * @return {C_T}
   * @public
   */
  m_setIcon__org_dominokit_domino_ui_icons_Icon(icon) {
    return this.m_setLeftAddon__elemental2_dom_Element(icon.m_asElement__());
  }
  
  /**
   * @param {Element} leftAddon
   * @return {C_T}
   * @public
   */
  m_setLeftAddon__elemental2_dom_Element(leftAddon) {
    this.m_setAddon__elemental2_dom_HTMLElement__elemental2_dom_Element__elemental2_dom_Element_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_leftAddonContainer__org_dominokit_domino_ui_forms_ValueBox_, this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_, leftAddon);
    this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_ = leftAddon;
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @param {Element} rightAddon
   * @return {C_T}
   * @public
   */
  m_setRightAddon__elemental2_dom_Element(rightAddon) {
    this.m_setAddon__elemental2_dom_HTMLElement__elemental2_dom_Element__elemental2_dom_Element_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_rightAddonContainer__org_dominokit_domino_ui_forms_ValueBox_, this.f_rightAddon__org_dominokit_domino_ui_forms_ValueBox_, rightAddon);
    this.f_rightAddon__org_dominokit_domino_ui_forms_ValueBox_ = rightAddon;
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_removeRightAddon__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_rightAddon__org_dominokit_domino_ui_forms_ValueBox_)) {
      this.f_rightAddonContainer__org_dominokit_domino_ui_forms_ValueBox_.removeChild(this.f_rightAddon__org_dominokit_domino_ui_forms_ValueBox_);
    }
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_removeLeftAddon__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_)) {
      this.f_leftAddonContainer__org_dominokit_domino_ui_forms_ValueBox_.removeChild(this.f_leftAddon__org_dominokit_domino_ui_forms_ValueBox_);
    }
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @param {HTMLElement} container
   * @param {Element} oldAddon
   * @param {Element} addon
   * @return {void}
   * @public
   */
  m_setAddon__elemental2_dom_HTMLElement__elemental2_dom_Element__elemental2_dom_Element_$p_org_dominokit_domino_ui_forms_ValueBox(container, oldAddon, addon) {
    if (Objects.m_nonNull__java_lang_Object(oldAddon)) {
      container.removeChild(oldAddon);
    }
    if (Objects.m_nonNull__java_lang_Object(addon)) {
      addon.classList.add("input-addon");
      container.appendChild(addon);
      this.m_setAddonSize__elemental2_dom_Element__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_$p_org_dominokit_domino_ui_forms_ValueBox(addon, this.f_size__org_dominokit_domino_ui_forms_ValueBox_);
    }
  }
  
  /**
   * @param {Element} addon
   * @param {ValueBoxSize} size
   * @return {void}
   * @public
   */
  m_setAddonSize__elemental2_dom_Element__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_$p_org_dominokit_domino_ui_forms_ValueBox(addon, size) {
    if (Objects.m_nonNull__java_lang_Object(addon) && !j_l_String.m_isEmpty__java_lang_String(size.f_sizeValue__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_)) {
      addon.classList.remove(this.f_size__org_dominokit_domino_ui_forms_ValueBox_.m_getStyle__());
      addon.classList.add(size.f_sizeValue__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize_);
    }
  }
  
  /**
   * @override
   * @return {C_E}
   * @public
   */
  m_getInputElement__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_;
  }
  
  /**
   * @override
   * @return {HTMLLabelElement}
   * @public
   */
  m_getLabelElement__() {
    return this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_container__org_dominokit_domino_ui_forms_ValueBox_;
  }
  
  /**
   * @override
   * @param {?string} errorMessage
   * @return {C_T}
   * @public
   */
  m_invalidate__java_lang_String(errorMessage) {
    this.f_valid__org_dominokit_domino_ui_forms_ValueBox_ = false;
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.remove("fc-" + j_l_String.m_valueOf__java_lang_Object(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_.m_getStyle__()));
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.add("fc-" + j_l_String.m_valueOf__java_lang_Object(Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()));
    this.m_removeLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    this.m_setLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(Color.f_RED__org_dominokit_domino_ui_style_Color);
    this.m_removeLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_);
    this.m_setLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(Color.f_RED__org_dominokit_domino_ui_style_Color);
    return /**@type {C_T} */ ($Casts.$to(super.m_invalidate__java_lang_String(errorMessage), ValueBox));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_clearInvalid__() {
    this.f_valid__org_dominokit_domino_ui_forms_ValueBox_ = true;
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.add("fc-" + j_l_String.m_valueOf__java_lang_Object(this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_.m_getStyle__()));
    /**@type {HTMLElement} */ (this.f_inputElement__org_dominokit_domino_ui_forms_ValueBox_).classList.remove("fc-" + j_l_String.m_valueOf__java_lang_Object(Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__()));
    this.m_removeLabelColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(Color.f_RED__org_dominokit_domino_ui_style_Color);
    this.m_removeLeftAddonColor__org_dominokit_domino_ui_style_Color_$p_org_dominokit_domino_ui_forms_ValueBox(Color.f_RED__org_dominokit_domino_ui_style_Color);
    if (this.m_isFocused__()) {
      this.m_focus__();
    } else {
      this.m_unfocus__();
    }
    return /**@type {C_T} */ ($Casts.$to(super.m_clearInvalid__(), ValueBox));
  }
  
  /**
   * @override
   * @param {boolean} autoValidation
   * @return {C_T}
   * @public
   */
  m_setAutoValidation__boolean(autoValidation) {
    if (autoValidation) {
      if ($Equality.$same(this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_, null)) {
        this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_ = new $LambdaAdaptor$35(((/** Event */ evt) =>{
          this.m_validate__();
        }));
        /**@type {HTMLElement} */ (this.m_getInputElement__()).addEventListener("input", this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_);
      }
    } else {
      if (Objects.m_nonNull__java_lang_Object(this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_)) {
        /**@type {HTMLElement} */ (this.m_getInputElement__()).removeEventListener("input", this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_);
      }
      this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_ = null;
    }
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isAutoValidation__() {
    return Objects.m_nonNull__java_lang_Object(this.f_changeEventListener__org_dominokit_domino_ui_forms_ValueBox_);
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_clear__() {
    this.m_clearValue__();
    this.m_autoValidate__();
    return /**@type {C_T} */ ($Casts.$to(this, ValueBox));
  }
  
  /**
   * @override
   * @param {C_V} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
    this.m_doSetValue__java_lang_Object(value);
    this.m_changeLabelFloating__();
    this.m_autoValidate__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_changeLabelFloating__() {
    if (!this.m_isEmpty__()) {
      this.m_floatLabel__();
    } else {
      this.m_unfloatLabel__();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_floatLabel__() {
    if (!this.f_floating__org_dominokit_domino_ui_forms_ValueBox_) {
      this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.add(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_unfloatLabel__() {
    if (!this.f_floating__org_dominokit_domino_ui_forms_ValueBox_ && this.m_isEmpty__()) {
      this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_.classList.remove(ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_autoValidate__() {
    if (this.m_isAutoValidation__()) {
      this.m_validate__();
    }
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clearValue__() {
  }
  
  /**
   * @abstract
   * @param {C_V} value
   * @return {void}
   * @public
   */
  m_doSetValue__java_lang_Object(value) {
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_ValueBox() {
    this.f_container__org_dominokit_domino_ui_forms_ValueBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_inputContainer__org_dominokit_domino_ui_forms_ValueBox_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-line"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_labelElement__org_dominokit_domino_ui_forms_ValueBox_ = /**@type {HTMLLabelElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLabelElement>} */ ($Casts.$to(Elements.m_label__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-label"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_leftAddonContainer__org_dominokit_domino_ui_forms_ValueBox_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["input-addon-container"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_rightAddonContainer__org_dominokit_domino_ui_forms_ValueBox_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["input-addon-container"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_size__org_dominokit_domino_ui_forms_ValueBox_ = ValueBoxSize.f_DEFAULT__org_dominokit_domino_ui_forms_ValueBox_ValueBoxSize;
    this.f_focusColor__org_dominokit_domino_ui_forms_ValueBox_ = Color.f_BLUE__org_dominokit_domino_ui_style_Color;
    this.f_valid__org_dominokit_domino_ui_forms_ValueBox_ = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ValueBox;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ValueBox);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ValueBox.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $LambdaAdaptor$32 = goog.module.get('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$32$impl');
    $LambdaAdaptor$33 = goog.module.get('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$33$impl');
    $LambdaAdaptor$34 = goog.module.get('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$34$impl');
    $LambdaAdaptor$35 = goog.module.get('org.dominokit.domino.ui.forms.ValueBox.$LambdaAdaptor$35$impl');
    ValueBoxSize = goog.module.get('org.dominokit.domino.ui.forms.ValueBox.ValueBoxSize$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BasicFormElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ValueBox, $Util.$makeClassName('org.dominokit.domino.ui.forms.ValueBox'));


/** @public {?string} @const */
ValueBox.f_FOCUSED__org_dominokit_domino_ui_forms_ValueBox = "focused";


Focusable.$markImplementor(ValueBox);
HasPlaceHolder.$markImplementor(ValueBox);


exports = ValueBox; 
//# sourceMappingURL=ValueBox.js.map