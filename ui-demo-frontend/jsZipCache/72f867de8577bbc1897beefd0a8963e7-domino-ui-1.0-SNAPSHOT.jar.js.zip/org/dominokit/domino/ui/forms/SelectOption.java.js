/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.SelectOption.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.forms.SelectOption');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.Selectable.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption$impl');
exports = SelectOption;
 