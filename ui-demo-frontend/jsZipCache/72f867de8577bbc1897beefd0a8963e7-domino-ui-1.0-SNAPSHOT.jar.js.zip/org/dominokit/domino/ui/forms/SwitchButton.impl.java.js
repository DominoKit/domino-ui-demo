/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.SwitchButton.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.SwitchButton$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BasicFormElement = goog.require('org.dominokit.domino.ui.forms.BasicFormElement$impl');
const Checkable = goog.require('org.dominokit.domino.ui.utils.Checkable$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLInputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let HTMLLabelElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLabelElement.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $LambdaAdaptor$30 = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton.$LambdaAdaptor$30$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let CheckHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BasicFormElement<SwitchButton, ?boolean>}
 * @implements {Checkable<SwitchButton>}
  */
class SwitchButton extends BasicFormElement {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_container__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {HTMLLabelElement} */
    this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {HTMLInputElement} */
    this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {HTMLElement} */
    this.f_lever__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {List<CheckHandler>} */
    this.f_checkHandlers__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {?string} */
    this.f_label__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {Text} */
    this.f_labelText__org_dominokit_domino_ui_forms_SwitchButton_;
    /** @public {boolean} */
    this.f_autoValidation__org_dominokit_domino_ui_forms_SwitchButton_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'SwitchButton(String, String)'.
   * @param {?string} title
   * @param {?string} onTitle
   * @return {!SwitchButton}
   * @public
   */
  static $create__java_lang_String__java_lang_String(title, onTitle) {
    SwitchButton.$clinit();
    let $instance = new SwitchButton();
    $instance.$ctor__org_dominokit_domino_ui_forms_SwitchButton__java_lang_String__java_lang_String(title, onTitle);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SwitchButton(String, String)'.
   * @param {?string} title
   * @param {?string} onTitle
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_SwitchButton__java_lang_String__java_lang_String(title, onTitle) {
    this.$ctor__org_dominokit_domino_ui_forms_SwitchButton__java_lang_String(title);
    this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_.appendChild(new Text(onTitle));
  }
  
  /**
   * Factory method corresponding to constructor 'SwitchButton(String)'.
   * @param {?string} title
   * @return {!SwitchButton}
   * @public
   */
  static $create__java_lang_String(title) {
    SwitchButton.$clinit();
    let $instance = new SwitchButton();
    $instance.$ctor__org_dominokit_domino_ui_forms_SwitchButton__java_lang_String(title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SwitchButton(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_SwitchButton__java_lang_String(title) {
    this.$ctor__org_dominokit_domino_ui_forms_SwitchButton__();
    this.m_setLabel__java_lang_String(title);
  }
  
  /**
   * Factory method corresponding to constructor 'SwitchButton()'.
   * @return {!SwitchButton}
   * @public
   */
  static $create__() {
    SwitchButton.$clinit();
    let $instance = new SwitchButton();
    $instance.$ctor__org_dominokit_domino_ui_forms_SwitchButton__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SwitchButton()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_SwitchButton__() {
    this.$ctor__org_dominokit_domino_ui_forms_BasicFormElement__();
    this.$init__org_dominokit_domino_ui_forms_SwitchButton();
    this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_.appendChild(this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_);
    this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_.appendChild(this.f_lever__org_dominokit_domino_ui_forms_SwitchButton_);
    this.f_container__org_dominokit_domino_ui_forms_SwitchButton_.appendChild(this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_);
    this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_.addEventListener("change", new $LambdaAdaptor$30(((/** Event */ evt) =>{
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_SwitchButton();
      if (this.f_autoValidation__org_dominokit_domino_ui_forms_SwitchButton_) {
        this.m_validate__();
      }
    })));
  }
  
  /**
   * @param {?string} offTitle
   * @param {?string} onTitle
   * @return {SwitchButton}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(offTitle, onTitle) {
    SwitchButton.$clinit();
    return SwitchButton.$create__java_lang_String__java_lang_String(offTitle, onTitle);
  }
  
  /**
   * @param {?string} label
   * @return {SwitchButton}
   * @public
   */
  static m_create__java_lang_String(label) {
    SwitchButton.$clinit();
    return SwitchButton.$create__java_lang_String(label);
  }
  
  /**
   * @return {SwitchButton}
   * @public
   */
  static m_create__() {
    SwitchButton.$clinit();
    return SwitchButton.$create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onCheck___$p_org_dominokit_domino_ui_forms_SwitchButton() {
    for (let $iterator = this.f_checkHandlers__org_dominokit_domino_ui_forms_SwitchButton_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let checkHandler = /**@type {CheckHandler} */ ($Casts.$to($iterator.m_next__(), CheckHandler));
      checkHandler.m_onCheck__boolean(this.m_isChecked__());
    }
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getLever__() {
    return this.f_lever__org_dominokit_domino_ui_forms_SwitchButton_;
  }
  
  /**
   * @param {?boolean} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Boolean(value) {
    if (!$Equality.$same(value, null) && Boolean.m_booleanValue__java_lang_Boolean(value)) {
      this.m_check__();
    } else {
      this.m_uncheck__();
    }
  }
  
  /**
   * @override
   * @return {?boolean}
   * @public
   */
  m_getValue__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_.checked;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return !this.m_isChecked__();
  }
  
  /**
   * @override
   * @return {SwitchButton}
   * @public
   */
  m_clear__() {
    this.m_setValue__java_lang_Boolean(false);
    return this;
  }
  
  /**
   * @override
   * @return {SwitchButton}
   * @public
   */
  m_check__() {
    return this.m_check__boolean(false);
  }
  
  /**
   * @override
   * @return {SwitchButton}
   * @public
   */
  m_uncheck__() {
    return this.m_uncheck__boolean(false);
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {SwitchButton}
   * @public
   */
  m_check__boolean(silent) {
    this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_.checked = true;
    if (!silent) {
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_SwitchButton();
      this.m_validate__();
    }
    return this;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {SwitchButton}
   * @public
   */
  m_uncheck__boolean(silent) {
    this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_.checked = false;
    if (!silent) {
      this.m_onCheck___$p_org_dominokit_domino_ui_forms_SwitchButton();
      this.m_validate__();
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isChecked__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_.checked;
  }
  
  /**
   * @override
   * @param {CheckHandler} checkHandler
   * @return {SwitchButton}
   * @public
   */
  m_addCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(checkHandler) {
    this.f_checkHandlers__org_dominokit_domino_ui_forms_SwitchButton_.add(checkHandler);
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {SwitchButton}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (!$Equality.$same(this.f_color__org_dominokit_domino_ui_forms_SwitchButton_, null)) {
      this.f_lever__org_dominokit_domino_ui_forms_SwitchButton_.classList.remove("switch-" + j_l_String.m_valueOf__java_lang_Object(this.f_color__org_dominokit_domino_ui_forms_SwitchButton_.m_getStyle__()));
    }
    this.f_lever__org_dominokit_domino_ui_forms_SwitchButton_.classList.add("switch-" + j_l_String.m_valueOf__java_lang_Object(color.m_getStyle__()));
    this.f_color__org_dominokit_domino_ui_forms_SwitchButton_ = color;
    return this;
  }
  
  /**
   * @override
   * @param {?string} label
   * @return {SwitchButton}
   * @public
   */
  m_setLabel__java_lang_String(label) {
    this.f_label__org_dominokit_domino_ui_forms_SwitchButton_ = label;
    if (!$Equality.$same(this.f_labelText__org_dominokit_domino_ui_forms_SwitchButton_, null)) {
      this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_.removeChild(this.f_labelText__org_dominokit_domino_ui_forms_SwitchButton_);
    }
    this.f_labelText__org_dominokit_domino_ui_forms_SwitchButton_ = new Text(label);
    this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_.insertBefore(this.f_labelText__org_dominokit_domino_ui_forms_SwitchButton_, this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_);
    return this;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getLabel__() {
    return this.f_label__org_dominokit_domino_ui_forms_SwitchButton_;
  }
  
  /**
   * @override
   * @return {HTMLLabelElement}
   * @public
   */
  m_getLabelElement__() {
    return this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_;
  }
  
  /**
   * @override
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
    return this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getContainer__() {
    return this.f_container__org_dominokit_domino_ui_forms_SwitchButton_;
  }
  
  /**
   * @override
   * @param {CheckHandler} handler
   * @return {SwitchButton}
   * @public
   */
  m_removeCheckHandler__org_dominokit_domino_ui_utils_Checkable_CheckHandler(handler) {
    if (!$Equality.$same(handler, null)) {
      this.f_checkHandlers__org_dominokit_domino_ui_forms_SwitchButton_.remove(handler);
    }
    return this;
  }
  
  /**
   * @override
   * @param {boolean} autoValidation
   * @return {SwitchButton}
   * @public
   */
  m_setAutoValidation__boolean(autoValidation) {
    this.f_autoValidation__org_dominokit_domino_ui_forms_SwitchButton_ = autoValidation;
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isAutoValidation__() {
    return this.f_autoValidation__org_dominokit_domino_ui_forms_SwitchButton_;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_lang_Boolean(/**@type {?boolean} */ ($Casts.$to(arg0, Boolean)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_forms_SwitchButton() {
    this.f_container__org_dominokit_domino_ui_forms_SwitchButton_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["switch form-group"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_labelElement__org_dominokit_domino_ui_forms_SwitchButton_ = /**@type {HTMLLabelElement} */ ($Casts.$to(Elements.m_label__().m_asElement__(), HTMLLabelElement_$Overlay));
    this.f_inputElement__org_dominokit_domino_ui_forms_SwitchButton_ = /**@type {HTMLInputElement} */ ($Casts.$to(Elements.m_input__java_lang_String("checkbox").m_asElement__(), HTMLInputElement_$Overlay));
    this.f_lever__org_dominokit_domino_ui_forms_SwitchButton_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["lever"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_checkHandlers__org_dominokit_domino_ui_forms_SwitchButton_ = /**@type {!ArrayList<CheckHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SwitchButton;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SwitchButton);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SwitchButton.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLInputElement_$Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    HTMLLabelElement_$Overlay = goog.module.get('elemental2.dom.HTMLLabelElement.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $LambdaAdaptor$30 = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton.$LambdaAdaptor$30$impl');
    CheckHandler = goog.module.get('org.dominokit.domino.ui.utils.Checkable.CheckHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BasicFormElement.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SwitchButton, $Util.$makeClassName('org.dominokit.domino.ui.forms.SwitchButton'));


Checkable.$markImplementor(SwitchButton);


exports = SwitchButton; 
//# sourceMappingURL=SwitchButton.js.map