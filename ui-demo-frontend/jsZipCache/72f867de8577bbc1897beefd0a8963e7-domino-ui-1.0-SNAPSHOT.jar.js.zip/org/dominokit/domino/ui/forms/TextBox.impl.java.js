/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.TextBox.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.TextBox$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractTextBox = goog.require('org.dominokit.domino.ui.forms.AbstractTextBox$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let InputBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {AbstractTextBox<TextBox, HTMLInputElement>}
  */
class TextBox extends AbstractTextBox {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TextBox()'.
   * @return {!TextBox}
   * @public
   */
  static $create__() {
    TextBox.$clinit();
    let $instance = new TextBox();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextBox__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TextBox()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextBox__() {
    this.$ctor__org_dominokit_domino_ui_forms_TextBox__java_lang_String__java_lang_String(TextBox.f_TEXT__org_dominokit_domino_ui_forms_TextBox_, "");
  }
  
  /**
   * Factory method corresponding to constructor 'TextBox(String)'.
   * @param {?string} label
   * @return {!TextBox}
   * @public
   */
  static $create__java_lang_String(label) {
    TextBox.$clinit();
    let $instance = new TextBox();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextBox__java_lang_String(label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TextBox(String)'.
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextBox__java_lang_String(label) {
    this.$ctor__org_dominokit_domino_ui_forms_TextBox__java_lang_String__java_lang_String(TextBox.f_TEXT__org_dominokit_domino_ui_forms_TextBox_, label);
  }
  
  /**
   * Factory method corresponding to constructor 'TextBox(String, String)'.
   * @param {?string} type
   * @param {?string} label
   * @return {!TextBox}
   * @public
   */
  static $create__java_lang_String__java_lang_String(type, label) {
    TextBox.$clinit();
    let $instance = new TextBox();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextBox__java_lang_String__java_lang_String(type, label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TextBox(String, String)'.
   * @param {?string} type
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextBox__java_lang_String__java_lang_String(type, label) {
    this.$ctor__org_dominokit_domino_ui_forms_AbstractTextBox__java_lang_String__java_lang_String(type, label);
  }
  
  /**
   * @return {TextBox}
   * @public
   */
  static m_create__() {
    TextBox.$clinit();
    return TextBox.$create__();
  }
  
  /**
   * @param {?string} label
   * @return {TextBox}
   * @public
   */
  static m_create__java_lang_String(label) {
    TextBox.$clinit();
    return TextBox.$create__java_lang_String(label);
  }
  
  /**
   * @param {?string} label
   * @return {TextBox}
   * @public
   */
  static m_password__java_lang_String(label) {
    TextBox.$clinit();
    return TextBox.$create__java_lang_String__java_lang_String("password", label);
  }
  
  /**
   * @return {TextBox}
   * @public
   */
  static m_password__() {
    TextBox.$clinit();
    return TextBox.$create__java_lang_String__java_lang_String("password", "");
  }
  
  /**
   * @override
   * @param {?string} type
   * @return {HTMLInputElement}
   * @public
   */
  m_createInputElement__java_lang_String(type) {
    return /**@type {HTMLInputElement} */ ($Casts.$to(/**@type {InputBuilder<HTMLInputElement>} */ ($Casts.$to(Elements.m_input__java_lang_String(type).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-control"], j_l_String))), InputBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return j_l_String.m_isEmpty__java_lang_String(this.m_getValue__());
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clearValue__() {
    this.m_setValue__java_lang_Object("");
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_doSetValue__java_lang_String(value) {
    /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).value = value;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).value;
  }
  
  /**
   * @param {?string} type
   * @return {TextBox}
   * @public
   */
  m_setType__java_lang_String(type) {
    /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__(), $Overlay)).type = type;
    return this;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_doSetValue__java_lang_Object(arg0) {
    this.m_doSetValue__java_lang_String(/**@type {?string} */ ($Casts.$to(arg0, j_l_String)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TextBox;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TextBox);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TextBox.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    InputBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    AbstractTextBox.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TextBox, $Util.$makeClassName('org.dominokit.domino.ui.forms.TextBox'));


/** @public {?string} @const */
TextBox.f_TEXT__org_dominokit_domino_ui_forms_TextBox_ = "text";




exports = TextBox; 
//# sourceMappingURL=TextBox.js.map