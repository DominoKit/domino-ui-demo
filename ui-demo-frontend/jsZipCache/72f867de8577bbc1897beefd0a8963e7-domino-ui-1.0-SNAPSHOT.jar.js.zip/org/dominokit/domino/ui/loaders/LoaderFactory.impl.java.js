/**
 * @fileoverview transpiled from org.dominokit.domino.ui.loaders.LoaderFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.loaders.LoaderFactory$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let BounceLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.BounceLoader$impl');
let FacebookLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.FacebookLoader$impl');
let IosLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.IosLoader$impl');
let IsLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.IsLoader$impl');
let LoaderEffect = goog.forwardDeclare('org.dominokit.domino.ui.loaders.LoaderEffect$impl');
let NoneLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.NoneLoader$impl');
let OrbitLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.OrbitLoader$impl');
let RotatePlaneLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.RotatePlaneLoader$impl');
let RotationLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.RotationLoader$impl');
let RoundBounceLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.RoundBounceLoader$impl');
let StretchLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.StretchLoader$impl');
let TimerLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.TimerLoader$impl');
let Win8LinearLoader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.Win8LinearLoader$impl');
let Win8Loader = goog.forwardDeclare('org.dominokit.domino.ui.loaders.Win8Loader$impl');


class LoaderFactory extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'LoaderFactory()'.
   * @return {!LoaderFactory}
   * @public
   */
  static $create__() {
    LoaderFactory.$clinit();
    let $instance = new LoaderFactory();
    $instance.$ctor__org_dominokit_domino_ui_loaders_LoaderFactory__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LoaderFactory()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_loaders_LoaderFactory__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LoaderEffect} type
   * @return {IsLoader}
   * @public
   */
  static m_make__org_dominokit_domino_ui_loaders_LoaderEffect(type) {
    LoaderFactory.$clinit();
    switch (type.ordinal()) {
      case LoaderEffect.$ordinal$f_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return BounceLoader.m_create__();
      case LoaderEffect.$ordinal$f_ROTATE_PLANE__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return RotatePlaneLoader.m_create__();
      case LoaderEffect.$ordinal$f_STRETCH__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return StretchLoader.m_create__();
      case LoaderEffect.$ordinal$f_ORBIT__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return OrbitLoader.m_create__();
      case LoaderEffect.$ordinal$f_ROUND_BOUNCE__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return RoundBounceLoader.m_create__();
      case LoaderEffect.$ordinal$f_WIN8__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return Win8Loader.m_create__();
      case LoaderEffect.$ordinal$f_WIN8_LINEAR__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return Win8LinearLoader.m_create__();
      case LoaderEffect.$ordinal$f_IOS__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return IosLoader.m_create__();
      case LoaderEffect.$ordinal$f_FACEBOOK__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return FacebookLoader.m_create__();
      case LoaderEffect.$ordinal$f_ROTATION__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return RotationLoader.m_create__();
      case LoaderEffect.$ordinal$f_TIMER__org_dominokit_domino_ui_loaders_LoaderEffect: 
        return TimerLoader.m_create__();
      default: 
        return NoneLoader.m_create__();
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LoaderFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LoaderFactory);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LoaderFactory.$clinit = function() {};
    BounceLoader = goog.module.get('org.dominokit.domino.ui.loaders.BounceLoader$impl');
    FacebookLoader = goog.module.get('org.dominokit.domino.ui.loaders.FacebookLoader$impl');
    IosLoader = goog.module.get('org.dominokit.domino.ui.loaders.IosLoader$impl');
    LoaderEffect = goog.module.get('org.dominokit.domino.ui.loaders.LoaderEffect$impl');
    NoneLoader = goog.module.get('org.dominokit.domino.ui.loaders.NoneLoader$impl');
    OrbitLoader = goog.module.get('org.dominokit.domino.ui.loaders.OrbitLoader$impl');
    RotatePlaneLoader = goog.module.get('org.dominokit.domino.ui.loaders.RotatePlaneLoader$impl');
    RotationLoader = goog.module.get('org.dominokit.domino.ui.loaders.RotationLoader$impl');
    RoundBounceLoader = goog.module.get('org.dominokit.domino.ui.loaders.RoundBounceLoader$impl');
    StretchLoader = goog.module.get('org.dominokit.domino.ui.loaders.StretchLoader$impl');
    TimerLoader = goog.module.get('org.dominokit.domino.ui.loaders.TimerLoader$impl');
    Win8LinearLoader = goog.module.get('org.dominokit.domino.ui.loaders.Win8LinearLoader$impl');
    Win8Loader = goog.module.get('org.dominokit.domino.ui.loaders.Win8Loader$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LoaderFactory, $Util.$makeClassName('org.dominokit.domino.ui.loaders.LoaderFactory'));




exports = LoaderFactory; 
//# sourceMappingURL=LoaderFactory.js.map