/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.FileIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.FileIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class FileIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_attachment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud_done__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud_download__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud_queue__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cloud_upload__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_create_new_folder__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_file_download__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_file_upload__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_folder__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_folder_open__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_folder_shared__() {
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_attachment__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("attachment");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud_circle__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud_circle");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud_done__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud_done");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud_download__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud_download");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud_off__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud_off");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud_queue__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud_queue");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cloud_upload__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("cloud_upload");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_create_new_folder__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("create_new_folder");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_file_download__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("file_download");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_file_upload__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("file_upload");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_folder__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("folder");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_folder_open__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("folder_open");
  }
  
  /**
   * @param {FileIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_folder_shared__$default__org_dominokit_domino_ui_icons_FileIcons($thisArg) {
    FileIcons.$clinit();
    return Icon.m_create__java_lang_String("folder_shared");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_FileIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_FileIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_FileIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FileIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(FileIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.FileIcons'));


FileIcons.$markImplementor(/** @type {Function} */ (FileIcons));


exports = FileIcons; 
//# sourceMappingURL=FileIcons.js.map