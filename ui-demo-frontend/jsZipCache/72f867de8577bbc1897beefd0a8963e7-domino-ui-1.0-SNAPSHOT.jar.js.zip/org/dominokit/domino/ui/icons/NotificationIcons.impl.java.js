/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.NotificationIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.NotificationIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class NotificationIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_adb__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_flat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_flat_angled__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_individual_suite__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_legroom_extra__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_legroom_normal__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_legroom_reduced__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_recline_extra__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_airline_seat_recline_normal__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_bluetooth_audio__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_confirmation_number__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_disc_full__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_do_not_disturb__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_do_not_disturb_alt__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_do_not_disturb_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_do_not_disturb_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_drive_eta__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_enhanced_encryption__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_event_available__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_event_busy__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_event_note__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_folder_special__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_live_tv__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mms__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_more__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_network_check__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_network_locked__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_no_encryption__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_ondemand_video__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_personal_video__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_bluetooth_speaker__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_forwarded__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_in_talk__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_locked__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_missed__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone_paused__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_power__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_priority_high__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sd_card__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sim_card_alert__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sms__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sms_failed__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sync__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sync_disabled__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_sync_problem__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_system_update__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tap_and_play__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_time_to_leave__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vibration__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_voice_chat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vpn_lock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wc__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wifi__() {
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_adb__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("adb");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_flat__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_flat");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_flat_angled__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_flat_angled");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_individual_suite__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_individual_suite");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_legroom_extra__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_legroom_extra");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_legroom_normal__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_legroom_normal");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_legroom_reduced__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_legroom_reduced");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_recline_extra__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_recline_extra");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_airline_seat_recline_normal__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("airline_seat_recline_normal");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_bluetooth_audio__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("bluetooth_audio");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_confirmation_number__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("confirmation_number");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_disc_full__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("disc_full");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_do_not_disturb__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("do_not_disturb");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_do_not_disturb_alt__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("do_not_disturb_alt");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_do_not_disturb_off__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("do_not_disturb_off");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_do_not_disturb_on__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("do_not_disturb_on");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_drive_eta__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("drive_eta");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_enhanced_encryption__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("enhanced_encryption");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_event_available__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("event_available");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_event_busy__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("event_busy");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_event_note__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("event_note");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_folder_special__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("folder_special");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_live_tv__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("live_tv");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mms__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("mms");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_more__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("more");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_network_check__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("network_check");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_network_locked__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("network_locked");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_no_encryption__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("no_encryption");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_ondemand_video__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("ondemand_video");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_personal_video__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("personal_video");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_bluetooth_speaker__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_bluetooth_speaker");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_forwarded__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_forwarded");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_in_talk__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_in_talk");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_locked__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_locked");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_missed__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_missed");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone_paused__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone_paused");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_power__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("power");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_priority_high__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("priority_high");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sd_card__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sd_card");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sim_card_alert__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sim_card_alert");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sms__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sms");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sms_failed__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sms_failed");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sync__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sync");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sync_disabled__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sync_disabled");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_sync_problem__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("sync_problem");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_system_update__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("system_update");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tap_and_play__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("tap_and_play");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_time_to_leave__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("time_to_leave");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vibration__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("vibration");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_voice_chat__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("voice_chat");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vpn_lock__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("vpn_lock");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wc__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("wc");
  }
  
  /**
   * @param {NotificationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wifi__$default__org_dominokit_domino_ui_icons_NotificationIcons($thisArg) {
    NotificationIcons.$clinit();
    return Icon.m_create__java_lang_String("wifi");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_NotificationIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_NotificationIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_NotificationIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    NotificationIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(NotificationIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.NotificationIcons'));


NotificationIcons.$markImplementor(/** @type {Function} */ (NotificationIcons));


exports = NotificationIcons; 
//# sourceMappingURL=NotificationIcons.js.map