/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.CommunicationIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.CommunicationIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class CommunicationIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_business__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_end__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_made__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_merge__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_missed__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_missed_outgoing__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_received__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_call_split__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_chat__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_chat_bubble__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_chat_bubble_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_clear_all__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_comment__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_contact_mail__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_contact_phone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_contacts__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dialer_sip__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dialpad__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_email__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_forum__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_import_contacts__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_import_export__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_invert_colors_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_live_help__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_location_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_location_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_mail_outline__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_message__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_no_sim__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phonelink_erase__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phonelink_lock__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phonelink_ring__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_phonelink_setup__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_portable_wifi_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_present_to_all__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_ring_volume__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rss_feed__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_screen_share__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_speaker_phone__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stay_current_landscape__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stay_current_portrait__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stay_primary_landscape__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stay_primary_portrait__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_stop_screen_share__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_swap_calls__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_textsms__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_voicemail__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vpn_key__() {
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_business__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("business");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_end__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_end");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_made__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_made");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_merge__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_merge");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_missed__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_missed");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_missed_outgoing__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_missed_outgoing");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_received__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_received");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_call_split__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("call_split");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_chat__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("chat");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_chat_bubble__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("chat_bubble");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_chat_bubble_outline__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("chat_bubble_outline");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_clear_all__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("clear_all");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_comment__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("comment");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_contact_mail__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("contact_mail");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_contact_phone__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("contact_phone");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_contacts__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("contacts");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dialer_sip__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("dialer_sip");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dialpad__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("dialpad");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_email__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("email");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_forum__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("forum");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_import_contacts__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("import_contacts");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_import_export__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("import_export");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_invert_colors_off__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("invert_colors_off");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_live_help__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("live_help");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_location_off__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("location_off");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_location_on__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("location_on");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_mail_outline__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("mail_outline");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_message__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("message");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_no_sim__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("no_sim");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phone__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("phone");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phonelink_erase__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("phonelink_erase");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phonelink_lock__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("phonelink_lock");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phonelink_ring__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("phonelink_ring");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_phonelink_setup__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("phonelink_setup");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_portable_wifi_off__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("portable_wifi_off");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_present_to_all__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("present_to_all");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_ring_volume__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("ring_volume");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rss_feed__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("rss_feed");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_screen_share__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("screen_share");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_speaker_phone__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("speaker_phone");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stay_current_landscape__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("stay_current_landscape");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stay_current_portrait__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("stay_current_portrait");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stay_primary_landscape__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("stay_primary_landscape");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stay_primary_portrait__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("stay_primary_portrait");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_stop_screen_share__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("stop_screen_share");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_swap_calls__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("swap_calls");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_textsms__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("textsms");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_voicemail__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("voicemail");
  }
  
  /**
   * @param {CommunicationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vpn_key__$default__org_dominokit_domino_ui_icons_CommunicationIcons($thisArg) {
    CommunicationIcons.$clinit();
    return Icon.m_create__java_lang_String("vpn_key");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_CommunicationIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_CommunicationIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_CommunicationIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CommunicationIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CommunicationIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.CommunicationIcons'));


CommunicationIcons.$markImplementor(/** @type {Function} */ (CommunicationIcons));


exports = CommunicationIcons; 
//# sourceMappingURL=CommunicationIcons.js.map