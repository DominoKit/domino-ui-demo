/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.ImageIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.ImageIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class ImageIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_a_photo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_add_to_photos__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_adjust__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assistant__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_assistant_photo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_audiotrack__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_blur_circular__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_blur_linear__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_blur_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_blur_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_1__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_2__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_3__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_4__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_5__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_6__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brightness_7__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_broken_image__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_brush__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_burst_mode__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_camera__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_camera_alt__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_camera_front__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_camera_rear__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_camera_roll__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_center_focus_strong__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_center_focus_weak__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_collections__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_collections_bookmark__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_color_lens__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_colorize__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_compare__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_control_point__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_control_point_duplicate__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_16_9__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_3_2__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_5_4__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_7_5__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_din__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_free__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_landscape__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_original__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_portrait__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_rotate__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_crop_square__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_dehaze__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_details__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_edit__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exposure__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exposure_neg_1__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exposure_neg_2__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exposure_plus_1__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exposure_plus_2__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_exposure_zero__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_1__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_2__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_3__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_4__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_5__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_6__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_7__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_8__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_9__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_9_plus__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_b_and_w__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_center_focus__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_drama__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_frames__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_hdr__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_none__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_tilt_shift__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_filter_vintage__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flare__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flash_auto__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flash_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flash_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_flip__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_gradient__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_grain__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_grid_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_grid_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hdr_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hdr_on__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hdr_strong__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_hdr_weak__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_healing__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_image__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_image_aspect_ratio__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_iso__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_landscape__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_leak_add__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_leak_remove__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_lens__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_linked_camera__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks_3__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks_4__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks_5__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks_6__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks_one__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_looks_two__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_loupe__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_monochrome_photos__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_movie_creation__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_movie_filter__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_music_note__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_nature__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_nature_people__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_navigate_before__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_navigate_next__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_palette__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_panorama__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_panorama_fish_eye__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_panorama_horizontal__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_panorama_vertical__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_panorama_wide_angle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_album__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_camera__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_filter__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_library__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_size_select_actual__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_size_select_large__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_photo_size_select_small__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_picture_as_pdf__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_portrait__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_remove_red_eye__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rotate_90_degrees_ccw__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rotate_left__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_rotate_right__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_slideshow__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_straighten__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_style__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_switch_camera__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_switch_video__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tag_faces__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_texture__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_timelapse__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_timer__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_timer_10__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_timer_3__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_timer_off__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tonality__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_transform__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_tune__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_comfy__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_view_compact__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_vignette__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wb_auto__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wb_cloudy__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wb_incandescent__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wb_iridescent__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_wb_sunny__() {
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_a_photo__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("add_a_photo");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_add_to_photos__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("add_to_photos");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_adjust__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("adjust");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assistant__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("assistant");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_assistant_photo__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("assistant_photo");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_audiotrack__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("audiotrack");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_blur_circular__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("blur_circular");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_blur_linear__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("blur_linear");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_blur_off__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("blur_off");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_blur_on__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("blur_on");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_1__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_1");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_2__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_2");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_3__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_3");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_4__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_4");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_5__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_5");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_6__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_6");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brightness_7__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brightness_7");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_broken_image__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("broken_image");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_brush__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("brush");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_burst_mode__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("burst_mode");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_camera__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("camera");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_camera_alt__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("camera_alt");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_camera_front__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("camera_front");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_camera_rear__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("camera_rear");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_camera_roll__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("camera_roll");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_center_focus_strong__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("center_focus_strong");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_center_focus_weak__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("center_focus_weak");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_collections__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("collections");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_collections_bookmark__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("collections_bookmark");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_color_lens__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("color_lens");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_colorize__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("colorize");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_compare__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("compare");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_control_point__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("control_point");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_control_point_duplicate__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("control_point_duplicate");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_16_9__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_16_9");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_3_2__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_3_2");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_5_4__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_5_4");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_7_5__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_7_5");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_din__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_din");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_free__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_free");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_landscape__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_landscape");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_original__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_original");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_portrait__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_portrait");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_rotate__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_rotate");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_crop_square__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("crop_square");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_dehaze__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("dehaze");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_details__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("details");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_edit__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("edit");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exposure__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("exposure");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exposure_neg_1__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("exposure_neg_1");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exposure_neg_2__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("exposure_neg_2");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exposure_plus_1__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("exposure_plus_1");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exposure_plus_2__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("exposure_plus_2");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_exposure_zero__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("exposure_zero");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_1__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_1");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_2__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_2");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_3__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_3");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_4__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_4");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_5__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_5");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_6__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_6");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_7__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_7");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_8__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_8");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_9__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_9");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_9_plus__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_9_plus");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_b_and_w__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_b_and_w");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_center_focus__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_center_focus");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_drama__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_drama");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_frames__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_frames");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_hdr__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_hdr");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_none__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_none");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_tilt_shift__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_tilt_shift");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_filter_vintage__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("filter_vintage");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flare__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("flare");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flash_auto__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("flash_auto");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flash_off__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("flash_off");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flash_on__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("flash_on");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_flip__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("flip");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_gradient__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("gradient");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_grain__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("grain");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_grid_off__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("grid_off");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_grid_on__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("grid_on");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hdr_off__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("hdr_off");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hdr_on__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("hdr_on");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hdr_strong__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("hdr_strong");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_hdr_weak__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("hdr_weak");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_healing__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("healing");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_image__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("image");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_image_aspect_ratio__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("image_aspect_ratio");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_iso__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("iso");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_landscape__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("landscape");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_leak_add__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("leak_add");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_leak_remove__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("leak_remove");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_lens__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("lens");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_linked_camera__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("linked_camera");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks_3__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks_3");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks_4__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks_4");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks_5__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks_5");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks_6__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks_6");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks_one__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks_one");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_looks_two__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("looks_two");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_loupe__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("loupe");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_monochrome_photos__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("monochrome_photos");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_movie_creation__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("movie_creation");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_movie_filter__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("movie_filter");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_music_note__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("music_note");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_nature__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("nature");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_nature_people__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("nature_people");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_navigate_before__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("navigate_before");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_navigate_next__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("navigate_next");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_palette__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("palette");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_panorama__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("panorama");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_panorama_fish_eye__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("panorama_fish_eye");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_panorama_horizontal__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("panorama_horizontal");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_panorama_vertical__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("panorama_vertical");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_panorama_wide_angle__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("panorama_wide_angle");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_album__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_album");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_camera__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_camera");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_filter__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_filter");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_library__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_library");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_size_select_actual__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_size_select_actual");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_size_select_large__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_size_select_large");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_photo_size_select_small__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("photo_size_select_small");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_picture_as_pdf__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("picture_as_pdf");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_portrait__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("portrait");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_remove_red_eye__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("remove_red_eye");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rotate_90_degrees_ccw__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("rotate_90_degrees_ccw");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rotate_left__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("rotate_left");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_rotate_right__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("rotate_right");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_slideshow__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("slideshow");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_straighten__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("straighten");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_style__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("style");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_switch_camera__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("switch_camera");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_switch_video__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("switch_video");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tag_faces__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("tag_faces");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_texture__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("texture");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_timelapse__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("timelapse");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_timer__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("timer");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_timer_10__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("timer_10");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_timer_3__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("timer_3");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_timer_off__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("timer_off");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tonality__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("tonality");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_transform__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("transform");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_tune__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("tune");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_comfy__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("view_comfy");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_view_compact__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("view_compact");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_vignette__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("vignette");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wb_auto__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("wb_auto");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wb_cloudy__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("wb_cloudy");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wb_incandescent__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("wb_incandescent");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wb_iridescent__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("wb_iridescent");
  }
  
  /**
   * @param {ImageIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_wb_sunny__$default__org_dominokit_domino_ui_icons_ImageIcons($thisArg) {
    ImageIcons.$clinit();
    return Icon.m_create__java_lang_String("wb_sunny");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ImageIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_ImageIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_ImageIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ImageIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ImageIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.ImageIcons'));


ImageIcons.$markImplementor(/** @type {Function} */ (ImageIcons));


exports = ImageIcons; 
//# sourceMappingURL=ImageIcons.js.map