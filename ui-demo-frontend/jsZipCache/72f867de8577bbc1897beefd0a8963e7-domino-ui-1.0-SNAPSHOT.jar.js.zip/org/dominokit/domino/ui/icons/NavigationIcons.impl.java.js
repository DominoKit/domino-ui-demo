/**
 * @fileoverview transpiled from org.dominokit.domino.ui.icons.NavigationIcons.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.icons.NavigationIcons$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');


/**
 * @interface
 */
class NavigationIcons {
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_apps__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_back__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_downward__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_drop_down__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_drop_down_circle__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_drop_up__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_forward__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_arrow_upward__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_cancel__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_check__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_chevron_left__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_chevron_right__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_close__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_expand_less__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_expand_more__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_first_page__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fullscreen__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_fullscreen_exit__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_last_page__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_menu__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_more_horiz__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_more_vert__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_refresh__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_subdirectory_arrow_left__() {
  }
  
  /**
   * @abstract
   * @return {Icon}
   * @public
   */
  m_subdirectory_arrow_right__() {
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_apps__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("apps");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_back__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_back");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_downward__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_downward");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_drop_down__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_drop_down");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_drop_down_circle__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_drop_down_circle");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_drop_up__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_drop_up");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_forward__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_forward");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_arrow_upward__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("arrow_upward");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_cancel__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("cancel");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_check__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("check");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_chevron_left__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("chevron_left");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_chevron_right__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("chevron_right");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_close__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("close");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_expand_less__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("expand_less");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_expand_more__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("expand_more");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_first_page__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("first_page");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fullscreen__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("fullscreen");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_fullscreen_exit__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("fullscreen_exit");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_last_page__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("last_page");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_menu__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("menu");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_more_horiz__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("more_horiz");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_more_vert__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("more_vert");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_refresh__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("refresh");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_subdirectory_arrow_left__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("subdirectory_arrow_left");
  }
  
  /**
   * @param {NavigationIcons} $thisArg
   * @return {Icon}
   * @public
   */
  static m_subdirectory_arrow_right__$default__org_dominokit_domino_ui_icons_NavigationIcons($thisArg) {
    NavigationIcons.$clinit();
    return Icon.m_create__java_lang_String("subdirectory_arrow_right");
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_NavigationIcons = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_icons_NavigationIcons;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_icons_NavigationIcons;
  }
  
  /**
   * @public
   */
  static $clinit() {
    NavigationIcons.$clinit = function() {};
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(NavigationIcons, $Util.$makeClassName('org.dominokit.domino.ui.icons.NavigationIcons'));


NavigationIcons.$markImplementor(/** @type {Function} */ (NavigationIcons));


exports = NavigationIcons; 
//# sourceMappingURL=NavigationIcons.js.map