/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.IsModalDialog$CloseHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CloseHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onClose__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {CloseHandler}
   * @public
   */
  static $adapt(fn) {
    CloseHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CloseHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CloseHandler, $Util.$makeClassName('org.dominokit.domino.ui.modals.IsModalDialog$CloseHandler'));


CloseHandler.$markImplementor(/** @type {Function} */ (CloseHandler));


exports = CloseHandler; 
//# sourceMappingURL=IsModalDialog$CloseHandler.js.map