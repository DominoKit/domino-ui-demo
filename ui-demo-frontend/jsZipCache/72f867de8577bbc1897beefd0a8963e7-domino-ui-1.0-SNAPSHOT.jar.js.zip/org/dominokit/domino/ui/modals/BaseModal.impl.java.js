/**
 * @fileoverview transpiled from org.dominokit.domino.ui.modals.BaseModal.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.modals.BaseModal$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsModalDialog = goog.require('org.dominokit.domino.ui.modals.IsModalDialog$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let KeyboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let $LambdaAdaptor$41 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$41$impl');
let $LambdaAdaptor$42 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$42$impl');
let $LambdaAdaptor$43 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$43$impl');
let $LambdaAdaptor$44 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$44$impl');
let $LambdaAdaptor$45 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$45$impl');
let $LambdaAdaptor$46 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$46$impl');
let $LambdaAdaptor$47 = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$47$impl');
let Modal = goog.forwardDeclare('org.dominokit.domino.ui.modals.BaseModal.Modal$impl');
let CloseHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
let ModalSize = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
let OpenHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @abstract
 * @template C_T
 * @implements {IsElement<HTMLDivElement>}
 * @implements {IsModalDialog<C_T>}
 * @implements {Switchable<C_T>}
  */
class BaseModal extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {List<OpenHandler>} */
    this.f_openHandlers__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {List<CloseHandler>} */
    this.f_closeHandlers__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {Modal} */
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal;
    /** @public {boolean} */
    this.f_autoClose__org_dominokit_domino_ui_modals_BaseModal_ = false;
    /** @public {ModalSize} */
    this.f_modalSize__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {Element} */
    this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {Element} */
    this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {Element} */
    this.f_activeElementBeforeOpen__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {List<Element>} */
    this.f_focusElements__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {Text} */
    this.f_headerText__org_dominokit_domino_ui_modals_BaseModal_;
    /** @public {boolean} */
    this.f_open__org_dominokit_domino_ui_modals_BaseModal_ = false;
    /** @public {boolean} */
    this.f_disabled__org_dominokit_domino_ui_modals_BaseModal_ = false;
    /** @public {boolean} */
    this.f_autoAppendAndRemove__org_dominokit_domino_ui_modals_BaseModal_ = false;
  }
  
  /**
   * Initialization from constructor 'BaseModal()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_BaseModal__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_modals_BaseModal();
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal = Modal.m_create__();
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_.style.display = "none";
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_.appendChild(this.f_headerText__org_dominokit_domino_ui_modals_BaseModal_);
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_.addEventListener("click", new $LambdaAdaptor$41(((/** Event */ arg0) =>{
      arg0.stopPropagation();
    })));
    this.m_addCloseHandler___$pp_org_dominokit_domino_ui_modals();
    this.m_addTabIndexHandler___$pp_org_dominokit_domino_ui_modals();
  }
  
  /**
   * Initialization from constructor 'BaseModal(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_modals_BaseModal__java_lang_String(title) {
    this.$ctor__org_dominokit_domino_ui_modals_BaseModal__();
    this.m_showHeader__();
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_.textContent = title;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addCloseHandler___$pp_org_dominokit_domino_ui_modals() {
    this.m_asElement__().addEventListener("click", new $LambdaAdaptor$42(((/** Event */ event) =>{
      if (this.f_autoClose__org_dominokit_domino_ui_modals_BaseModal_) {
        this.m_close__();
      }
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addTabIndexHandler___$pp_org_dominokit_domino_ui_modals() {
    this.m_asElement__().addEventListener(EventType.f_keydown__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$43(((/** Event */ evt) =>{
      let keyboardEvent = /**@type {KeyboardEvent} */ ($Casts.$to(Js.m_cast__java_lang_Object(evt), KeyboardEvent_$Overlay));
      switch ($InternalPreconditions.m_checkNotNull__java_lang_Object(keyboardEvent.code)) {
        case "Tab": 
          if (this.f_focusElements__org_dominokit_domino_ui_modals_BaseModal_.size() <= 1) {
            evt.preventDefault();
            break;
          }
          if (keyboardEvent.shiftKey) {
            this.m_handleBackwardTab__elemental2_dom_Event_$p_org_dominokit_domino_ui_modals_BaseModal(evt);
          } else {
            this.m_handleForwardTab__elemental2_dom_Event_$p_org_dominokit_domino_ui_modals_BaseModal(evt);
          }
          break;
        case "Escape": 
          this.m_close__();
          break;
        default: 
          break;
      }
      if (!this.f_focusElements__org_dominokit_domino_ui_modals_BaseModal_.contains(window.document.activeElement)) {
        this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_.focus();
      }
    })));
  }
  
  /**
   * @param {Event} evt
   * @return {void}
   * @public
   */
  m_handleBackwardTab__elemental2_dom_Event_$p_org_dominokit_domino_ui_modals_BaseModal(evt) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(window.document.activeElement, this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_)) {
      evt.preventDefault();
      this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_.focus();
    }
  }
  
  /**
   * @param {Event} evt
   * @return {void}
   * @public
   */
  m_handleForwardTab__elemental2_dom_Event_$p_org_dominokit_domino_ui_modals_BaseModal(evt) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(window.document.activeElement, this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_)) {
      evt.preventDefault();
      this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_.focus();
    }
  }
  
  /**
   * @override
   * @param {Node} content
   * @return {C_T}
   * @public
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalBody__org_dominokit_domino_ui_modals_BaseModal_Modal_.appendChild(content);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {Node} content
   * @return {C_T}
   * @public
   */
  m_appendFooterContent__elemental2_dom_Node(content) {
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_.appendChild(content);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_large__() {
    return this.m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_small__() {
    return this.m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_SMALL__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
  }
  
  /**
   * @param {ModalSize} size
   * @return {C_T}
   * @public
   */
  m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(size) {
    if (Objects.m_nonNull__java_lang_Object(this.f_modalSize__org_dominokit_domino_ui_modals_BaseModal_)) {
      this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_.classList.remove(this.f_modalSize__org_dominokit_domino_ui_modals_BaseModal_.f_style__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
    }
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_.classList.add(size.f_style__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
    this.f_modalSize__org_dominokit_domino_ui_modals_BaseModal_ = size;
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {Color} color
   * @return {C_T}
   * @public
   */
  m_setModalColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_color__org_dominokit_domino_ui_modals_BaseModal_)) {
      this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_.classList.remove("modal-" + j_l_String.m_valueOf__java_lang_Object(this.f_color__org_dominokit_domino_ui_modals_BaseModal_.m_getStyle__()));
    }
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_.classList.add("modal-" + j_l_String.m_valueOf__java_lang_Object(color.m_getStyle__()));
    this.f_color__org_dominokit_domino_ui_modals_BaseModal_ = color;
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {boolean} autoClose
   * @return {C_T}
   * @public
   */
  m_setAutoClose__boolean(autoClose) {
    this.f_autoClose__org_dominokit_domino_ui_modals_BaseModal_ = autoClose;
    if (autoClose) {
      BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.addEventListener(EventType.f_keypress__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$44(((/** Event */ evt) =>{
        evt.stopPropagation();
        evt.preventDefault();
        this.m_close__();
      })));
      BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.addEventListener(EventType.f_mousedown__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$45(((/** Event */ evt$1$) =>{
        evt$1$.stopPropagation();
        evt$1$.preventDefault();
        this.m_close__();
      })));
    } else {
      BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.addEventListener(EventType.f_keypress__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$46(((/** Event */ evt$2$) =>{
        evt$2$.stopPropagation();
        evt$2$.preventDefault();
      })));
      BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.addEventListener(EventType.f_mousedown__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$47(((/** Event */ evt$3$) =>{
        evt$3$.stopPropagation();
        evt$3$.preventDefault();
      })));
    }
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_open__() {
    if (this.m_isEnabled__()) {
      if (this.f_autoAppendAndRemove__org_dominokit_domino_ui_modals_BaseModal_) {
        this.m_asElement__().remove();
        DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(this.m_asElement__());
      }
      this.m_initFocusElements___$p_org_dominokit_domino_ui_modals_BaseModal();
      this.f_activeElementBeforeOpen__org_dominokit_domino_ui_modals_BaseModal_ = window.document.activeElement;
      BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.remove();
      DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_);
      this.m_asElement__().classList.add("in");
      this.m_asElement__().style.display = "block";
      if (Objects.m_nonNull__java_lang_Object(this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_)) {
        this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_.focus();
        if (!Objects.m_equals__java_lang_Object__java_lang_Object(window.document.activeElement, this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_)) {
          if (Objects.m_nonNull__java_lang_Object(this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_)) {
            this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_.focus();
          }
        }
      }
      for (let i = 0; i < this.f_openHandlers__org_dominokit_domino_ui_modals_BaseModal_.size(); i++) {
        /**@type {OpenHandler} */ ($Casts.$to(this.f_openHandlers__org_dominokit_domino_ui_modals_BaseModal_.getAtIndex(i), OpenHandler)).m_onOpen__();
      }
      this.f_open__org_dominokit_domino_ui_modals_BaseModal_ = true;
    }
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFocusElements___$p_org_dominokit_domino_ui_modals_BaseModal() {
    let elementNodeList = this.m_asElement__().querySelectorAll("a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex=\"0\"]");
    let elements = /**@type {List<Element>} */ (JsArrayLike_$Overlay.m_asList__jsinterop_base_JsArrayLike(elementNodeList));
    if (elements.size() > 0) {
      this.f_focusElements__org_dominokit_domino_ui_modals_BaseModal_ = elements;
      this.f_firstFocusElement__org_dominokit_domino_ui_modals_BaseModal_ = /**@type {Element} */ ($Casts.$to(this.f_focusElements__org_dominokit_domino_ui_modals_BaseModal_.getAtIndex(0), Element_$Overlay));
      this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_ = /**@type {Element} */ ($Casts.$to(elements.getAtIndex(elements.size() - 1), Element_$Overlay));
    } else {
      this.f_lastFocusElement__org_dominokit_domino_ui_modals_BaseModal_ = this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_;
    }
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_close__() {
    BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.remove();
    this.m_asElement__().classList.remove("in");
    this.m_asElement__().style.display = "none";
    if (Objects.m_nonNull__java_lang_Object(this.f_activeElementBeforeOpen__org_dominokit_domino_ui_modals_BaseModal_)) {
      this.f_activeElementBeforeOpen__org_dominokit_domino_ui_modals_BaseModal_.focus();
    }
    for (let i = 0; i < this.f_closeHandlers__org_dominokit_domino_ui_modals_BaseModal_.size(); i++) {
      /**@type {CloseHandler} */ ($Casts.$to(this.f_closeHandlers__org_dominokit_domino_ui_modals_BaseModal_.getAtIndex(i), CloseHandler)).m_onClose__();
    }
    if (this.f_autoAppendAndRemove__org_dominokit_domino_ui_modals_BaseModal_) {
      this.m_asElement__().remove();
      BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_.remove();
    }
    this.f_open__org_dominokit_domino_ui_modals_BaseModal_ = false;
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_hideFooter__() {
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_.style.display = "none";
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_showFooter__() {
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_.style.display = "block";
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_hideHeader__() {
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_.style.display = "none";
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_showHeader__() {
    this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_.style.display = "block";
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {?string} title
   * @return {C_T}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.m_showHeader__();
    this.f_headerText__org_dominokit_domino_ui_modals_BaseModal_.textContent = title;
    ElementUtil.m_clear__elemental2_dom_Element(this.m_getHeaderElement__());
    this.m_getHeaderElement__().appendChild(this.f_headerText__org_dominokit_domino_ui_modals_BaseModal_);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getDialogElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalDialog__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getContentElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalContent__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLHeadingElement}
   * @public
   */
  m_getHeaderElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalTitle__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getHeaderContainerElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalHeader__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getBodyElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalBody__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getFooterElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.f_modalFooter__org_dominokit_domino_ui_modals_BaseModal_Modal_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_modal__org_dominokit_domino_ui_modals_BaseModal.m_asElement__();
  }
  
  /**
   * @override
   * @param {OpenHandler} openHandler
   * @return {C_T}
   * @public
   */
  m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(openHandler) {
    this.f_openHandlers__org_dominokit_domino_ui_modals_BaseModal_.add(openHandler);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {CloseHandler} closeHandler
   * @return {C_T}
   * @public
   */
  m_onClose__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(closeHandler) {
    this.f_closeHandlers__org_dominokit_domino_ui_modals_BaseModal_.add(closeHandler);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {OpenHandler} openHandler
   * @return {C_T}
   * @public
   */
  m_removeOpenHandler__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(openHandler) {
    this.f_openHandlers__org_dominokit_domino_ui_modals_BaseModal_.remove(openHandler);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @param {CloseHandler} closeHandler
   * @return {C_T}
   * @public
   */
  m_removeCloseHandler__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(closeHandler) {
    this.f_closeHandlers__org_dominokit_domino_ui_modals_BaseModal_.remove(closeHandler);
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isOpen__() {
    return this.f_open__org_dominokit_domino_ui_modals_BaseModal_;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_enable__() {
    this.f_disabled__org_dominokit_domino_ui_modals_BaseModal_ = false;
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_disable__() {
    this.f_disabled__org_dominokit_domino_ui_modals_BaseModal_ = true;
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return !this.f_disabled__org_dominokit_domino_ui_modals_BaseModal_;
  }
  
  /**
   * @override
   * @param {boolean} autoAppendAndRemove
   * @return {C_T}
   * @public
   */
  m_setAutoAppendAndRemove__boolean(autoAppendAndRemove) {
    this.f_autoAppendAndRemove__org_dominokit_domino_ui_modals_BaseModal_ = autoAppendAndRemove;
    return /**@type {C_T} */ ($Casts.$to(this, j_l_Object));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_getAutoAppendAndRemove__() {
    return this.f_autoAppendAndRemove__org_dominokit_domino_ui_modals_BaseModal_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_modals_BaseModal() {
    this.f_openHandlers__org_dominokit_domino_ui_modals_BaseModal_ = /**@type {!ArrayList<OpenHandler>} */ (ArrayList.$create__());
    this.f_closeHandlers__org_dominokit_domino_ui_modals_BaseModal_ = /**@type {!ArrayList<CloseHandler>} */ (ArrayList.$create__());
    this.f_autoClose__org_dominokit_domino_ui_modals_BaseModal_ = true;
    this.f_focusElements__org_dominokit_domino_ui_modals_BaseModal_ = /**@type {!ArrayList<Element>} */ (ArrayList.$create__());
    this.f_headerText__org_dominokit_domino_ui_modals_BaseModal_ = new Text();
    this.f_open__org_dominokit_domino_ui_modals_BaseModal_ = false;
    this.f_disabled__org_dominokit_domino_ui_modals_BaseModal_ = false;
    this.f_autoAppendAndRemove__org_dominokit_domino_ui_modals_BaseModal_ = true;
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  static get f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_() {
    return (BaseModal.$clinit(), BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_);
  }
  
  /**
   * @param {HTMLDivElement} value
   * @return {void}
   * @public
   */
  static set f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_(value) {
    (BaseModal.$clinit(), BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseModal;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseModal);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseModal.$clinit = function() {};
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    KeyboardEvent_$Overlay = goog.module.get('elemental2.dom.KeyboardEvent.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    JsArrayLike_$Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    $LambdaAdaptor$41 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$41$impl');
    $LambdaAdaptor$42 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$42$impl');
    $LambdaAdaptor$43 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$43$impl');
    $LambdaAdaptor$44 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$44$impl');
    $LambdaAdaptor$45 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$45$impl');
    $LambdaAdaptor$46 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$46$impl');
    $LambdaAdaptor$47 = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.$LambdaAdaptor$47$impl');
    Modal = goog.module.get('org.dominokit.domino.ui.modals.BaseModal.Modal$impl');
    CloseHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
    ModalSize = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
    OpenHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
    BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["modal-backdrop fade in"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
  }
  
  
};

$Util.$setClassMetadata(BaseModal, $Util.$makeClassName('org.dominokit.domino.ui.modals.BaseModal'));


/** @private {HTMLDivElement} */
BaseModal.$f_MODAL_BACKDROP__org_dominokit_domino_ui_modals_BaseModal_;


IsElement.$markImplementor(BaseModal);
IsModalDialog.$markImplementor(BaseModal);
Switchable.$markImplementor(BaseModal);


exports = BaseModal; 
//# sourceMappingURL=BaseModal.js.map