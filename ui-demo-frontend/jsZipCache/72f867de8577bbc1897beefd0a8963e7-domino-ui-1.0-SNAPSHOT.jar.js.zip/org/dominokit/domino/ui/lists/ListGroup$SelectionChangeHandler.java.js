/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListGroup$SelectionChangeHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler.$LambdaAdaptor');
const _ListItem = goog.require('org.dominokit.domino.ui.lists.ListItem');


// Re-exports the implementation.
var SelectionChangeHandler = goog.require('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler$impl');
exports = SelectionChangeHandler;
 