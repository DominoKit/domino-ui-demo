/**
 * @fileoverview transpiled from org.dominokit.domino.ui.lists.ListGroup$SelectionChangeHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler.$LambdaAdaptor$impl');
let ListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.ListItem$impl');


/**
 * @interface
 * @template C_SelectionChangeHandler_T
 */
class SelectionChangeHandler {
  /**
   * @abstract
   * @param {ListItem<C_SelectionChangeHandler_T>} item
   * @return {void}
   * @public
   */
  m_onSelectionChanged__org_dominokit_domino_ui_lists_ListItem(item) {
  }
  
  /**
   * @template C_SelectionChangeHandler_T
   * @param {?function(ListItem<C_SelectionChangeHandler_T>):void} fn
   * @return {SelectionChangeHandler<C_SelectionChangeHandler_T>}
   * @public
   */
  static $adapt(fn) {
    SelectionChangeHandler.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_lists_ListGroup_SelectionChangeHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    SelectionChangeHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.lists.ListGroup.SelectionChangeHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SelectionChangeHandler, $Util.$makeClassName('org.dominokit.domino.ui.lists.ListGroup$SelectionChangeHandler'));


SelectionChangeHandler.$markImplementor(/** @type {Function} */ (SelectionChangeHandler));


exports = SelectionChangeHandler; 
//# sourceMappingURL=ListGroup$SelectionChangeHandler.js.map