/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownButton$JustifiableSeparator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.DropdownButton.JustifiableSeparator$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Justifiable = goog.require('org.dominokit.domino.ui.utils.Justifiable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Justifiable}
  */
class JustifiableSeparator extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DropdownButton} */
    this.f_$outer_this__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator;
    /** @public {HTMLLIElement} */
    this.f_separator__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator_;
  }
  
  /**
   * Factory method corresponding to constructor 'JustifiableSeparator(DropdownButton)'.
   * @param {DropdownButton} $outer_this
   * @return {!JustifiableSeparator}
   * @public
   */
  static $create__org_dominokit_domino_ui_button_DropdownButton($outer_this) {
    JustifiableSeparator.$clinit();
    let $instance = new JustifiableSeparator();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator__org_dominokit_domino_ui_button_DropdownButton($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'JustifiableSeparator(DropdownButton)'.
   * @param {DropdownButton} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator__org_dominokit_domino_ui_button_DropdownButton($outer_this) {
    this.f_$outer_this__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator = $outer_this;
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_justify__() {
    return /**@type {HTMLElement} */ ($Casts.$to(this.f_separator__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator_.cloneNode(true), $Overlay));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_separator__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator() {
    this.f_separator__org_dominokit_domino_ui_button_DropdownButton_JustifiableSeparator_ = /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_attr__java_lang_String__java_lang_String("role", "separator"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["divider"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JustifiableSeparator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JustifiableSeparator);
  }
  
  /**
   * @public
   */
  static $clinit() {
    JustifiableSeparator.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(JustifiableSeparator, $Util.$makeClassName('org.dominokit.domino.ui.button.DropdownButton$JustifiableSeparator'));


Justifiable.$markImplementor(JustifiableSeparator);


exports = JustifiableSeparator; 
//# sourceMappingURL=DropdownButton$JustifiableSeparator.js.map