/**
 * @fileoverview transpiled from org.dominokit.domino.ui.labels.Label.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.labels.Label$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
 * @implements {HasContent<Label>}
 * @implements {HasBackground<Label>}
  */
class Label extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_span__org_dominokit_domino_ui_labels_Label_;
    /** @public {Color} */
    this.f_background__org_dominokit_domino_ui_labels_Label_;
  }
  
  /**
   * Factory method corresponding to constructor 'Label(String)'.
   * @param {?string} content
   * @return {!Label}
   * @public
   */
  static $create__java_lang_String(content) {
    Label.$clinit();
    let $instance = new Label();
    $instance.$ctor__org_dominokit_domino_ui_labels_Label__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Label(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_labels_Label__java_lang_String(content) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_labels_Label();
    this.m_setContent__java_lang_String(content);
  }
  
  /**
   * Factory method corresponding to constructor 'Label(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {!Label}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    Label.$clinit();
    let $instance = new Label();
    $instance.$ctor__org_dominokit_domino_ui_labels_Label__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Label(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_labels_Label__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_labels_Label__java_lang_String(content);
    this.m_setType__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_labels_Label(type);
  }
  
  /**
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  m_setType__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_labels_Label(type) {
    this.f_span__org_dominokit_domino_ui_labels_Label_.classList.add("label-" + j_l_String.m_valueOf__java_lang_Object(type.m_getStyle__()));
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_create__java_lang_String(content) {
    Label.$clinit();
    return Label.$create__java_lang_String(content);
  }
  
  /**
   * @param {?string} content
   * @param {StyleType} type
   * @return {Label}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    Label.$clinit();
    return Label.$create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_createDefault__java_lang_String(content) {
    Label.$clinit();
    return Label.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_createPrimary__java_lang_String(content) {
    Label.$clinit();
    return Label.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_createSuccess__java_lang_String(content) {
    Label.$clinit();
    return Label.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_createInfo__java_lang_String(content) {
    Label.$clinit();
    return Label.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_createWarning__java_lang_String(content) {
    Label.$clinit();
    return Label.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Label}
   * @public
   */
  static m_createDanger__java_lang_String(content) {
    Label.$clinit();
    return Label.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_span__org_dominokit_domino_ui_labels_Label_;
  }
  
  /**
   * @override
   * @param {?string} content
   * @return {Label}
   * @public
   */
  m_setContent__java_lang_String(content) {
    this.f_span__org_dominokit_domino_ui_labels_Label_.textContent = content;
    return this;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Label}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_background__org_dominokit_domino_ui_labels_Label_)) {
      this.f_span__org_dominokit_domino_ui_labels_Label_.classList.remove(this.f_background__org_dominokit_domino_ui_labels_Label_.m_getBackground__());
    }
    this.f_span__org_dominokit_domino_ui_labels_Label_.classList.add(background.m_getBackground__());
    this.f_background__org_dominokit_domino_ui_labels_Label_ = background;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_labels_Label() {
    this.f_span__org_dominokit_domino_ui_labels_Label_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["label"], j_l_String))), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Label;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Label);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Label.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Label, $Util.$makeClassName('org.dominokit.domino.ui.labels.Label'));


IsElement.$markImplementor(Label);
HasContent.$markImplementor(Label);
HasBackground.$markImplementor(Label);


exports = Label; 
//# sourceMappingURL=Label.js.map