/**
 * @fileoverview transpiled from org.gwtproject.xhr.client.XMLHttpRequest$ResponseType.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.xhr.client.XMLHttpRequest.ResponseType$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<ResponseType>}
  */
class ResponseType extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_responseTypeString__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_;
  }
  
  /**
   * Factory method corresponding to constructor 'ResponseType(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} responseTypeString
   * @return {!ResponseType}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, responseTypeString) {
    let $instance = new ResponseType();
    $instance.$ctor__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType__java_lang_String__int__java_lang_String($name, $ordinal, responseTypeString);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ResponseType(String, int, String)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} responseTypeString
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType__java_lang_String__int__java_lang_String($name, $ordinal, responseTypeString) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_responseTypeString__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_ = responseTypeString;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getResponseTypeString__() {
    return this.f_responseTypeString__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_;
  }
  
  /**
   * @param {string} name
   * @return {!ResponseType}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    ResponseType.$clinit();
    if ($Equality.$same(ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_, null)) {
      ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_ = $Enums.createMapFromValues(ResponseType.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_);
  }
  
  /**
   * @return {!Array<!ResponseType>}
   * @public
   */
  static m_values__() {
    ResponseType.$clinit();
    return /**@type {!Array<ResponseType>} */ ($Arrays.$init([ResponseType.$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType, ResponseType.$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType], ResponseType));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {ResponseType} */ ($Casts.$to(arg0, ResponseType)));
  }
  
  /**
   * @return {!ResponseType}
   * @public
   */
  static get f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType() {
    return (ResponseType.$clinit(), ResponseType.$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType);
  }
  
  /**
   * @param {!ResponseType} value
   * @return {void}
   * @public
   */
  static set f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType(value) {
    (ResponseType.$clinit(), ResponseType.$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType = value);
  }
  
  /**
   * @return {!ResponseType}
   * @public
   */
  static get f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType() {
    return (ResponseType.$clinit(), ResponseType.$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType);
  }
  
  /**
   * @param {!ResponseType} value
   * @return {void}
   * @public
   */
  static set f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType(value) {
    (ResponseType.$clinit(), ResponseType.$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType = value);
  }
  
  /**
   * @return {Map<?string, !ResponseType>}
   * @public
   */
  static get f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_() {
    return (ResponseType.$clinit(), ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_);
  }
  
  /**
   * @param {Map<?string, !ResponseType>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_(value) {
    (ResponseType.$clinit(), ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ResponseType;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ResponseType);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ResponseType.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    ResponseType.$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType = ResponseType.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("Default"), ResponseType.$ordinal$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType, "");
    ResponseType.$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType = ResponseType.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ArrayBuffer"), ResponseType.$ordinal$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType, "arraybuffer");
    ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(ResponseType, $Util.$makeClassName('org.gwtproject.xhr.client.XMLHttpRequest$ResponseType'));


/** @private {!ResponseType} */
ResponseType.$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType;


/** @private {!ResponseType} */
ResponseType.$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType;


/** @private {Map<?string, !ResponseType>} */
ResponseType.$f_namesToValuesMap__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType_;


/** @public {number} @const */
ResponseType.$ordinal$f_Default__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType = 0;


/** @public {number} @const */
ResponseType.$ordinal$f_ArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType = 1;




exports = ResponseType; 
//# sourceMappingURL=XMLHttpRequest$ResponseType.js.map