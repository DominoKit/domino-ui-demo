/**
 * @fileoverview transpiled from org.gwtproject.xhr.client.XMLHttpRequest$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.xhr.client.XMLHttpRequest.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.ArrayBuffer.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let ResponseType = goog.forwardDeclare('org.gwtproject.xhr.client.XMLHttpRequest.ResponseType$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class XMLHttpRequest_$Overlay {
  /**
   * @return {XMLHttpRequest}
   * @public
   */
  static m_create__() {
    XMLHttpRequest_$Overlay.$clinit();
    return new XMLHttpRequest();
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @return {void}
   * @public
   */
  static m_clearOnReadyStateChange__org_gwtproject_xhr_client_XMLHttpRequest($thisArg) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.onreadystatechange = (() =>{
    });
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @return {ArrayBuffer}
   * @public
   */
  static m_getResponseArrayBuffer__org_gwtproject_xhr_client_XMLHttpRequest($thisArg) {
    XMLHttpRequest_$Overlay.$clinit();
    return /**@type {ArrayBuffer} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg.response), $Overlay));
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @param {?string} httpMethod
   * @param {?string} url
   * @return {void}
   * @public
   */
  static m_open__org_gwtproject_xhr_client_XMLHttpRequest__java_lang_String__java_lang_String($thisArg, httpMethod, url) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.open(httpMethod, url, true);
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @param {?string} httpMethod
   * @param {?string} url
   * @param {?string} user
   * @return {void}
   * @public
   */
  static m_open__org_gwtproject_xhr_client_XMLHttpRequest__java_lang_String__java_lang_String__java_lang_String($thisArg, httpMethod, url, user) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.open(httpMethod, url, true, user);
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @param {?string} httpMethod
   * @param {?string} url
   * @param {?string} user
   * @param {?string} password
   * @return {void}
   * @public
   */
  static m_open__org_gwtproject_xhr_client_XMLHttpRequest__java_lang_String__java_lang_String__java_lang_String__java_lang_String($thisArg, httpMethod, url, user, password) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.open(httpMethod, url, true, user, password);
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @return {void}
   * @public
   */
  static m_send__org_gwtproject_xhr_client_XMLHttpRequest($thisArg) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.send(null);
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @param {?function(XMLHttpRequest):void} handler
   * @return {void}
   * @public
   */
  static m_setOnReadyStateChange__org_gwtproject_xhr_client_XMLHttpRequest__org_gwtproject_xhr_client_ReadyStateChangeHandler($thisArg, handler) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.onreadystatechange = (() =>{
      handler($thisArg);
    });
  }
  
  /**
   * @param {XMLHttpRequest} $thisArg
   * @param {ResponseType} responseType
   * @return {void}
   * @public
   */
  static m_setResponseType__org_gwtproject_xhr_client_XMLHttpRequest__org_gwtproject_xhr_client_XMLHttpRequest_ResponseType($thisArg, responseType) {
    XMLHttpRequest_$Overlay.$clinit();
    $thisArg.responseType = responseType.m_getResponseTypeString__();
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_UNSENT__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay() {
    return (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_UNSENT__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_UNSENT__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay(value) {
    (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_UNSENT__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_OPENED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay() {
    return (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_OPENED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_OPENED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay(value) {
    (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_OPENED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_HEADERS_RECEIVED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay() {
    return (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_HEADERS_RECEIVED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_HEADERS_RECEIVED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay(value) {
    (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_HEADERS_RECEIVED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_LOADING__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay() {
    return (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_LOADING__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_LOADING__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay(value) {
    (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_LOADING__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_DONE__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay() {
    return (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_DONE__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_DONE__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay(value) {
    (XMLHttpRequest_$Overlay.$clinit(), XMLHttpRequest_$Overlay.$f_DONE__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof XMLHttpRequest;
  }
  
  /**
   * @public
   */
  static $clinit() {
    XMLHttpRequest_$Overlay.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.core.ArrayBuffer.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    XMLHttpRequest_$Overlay.$f_UNSENT__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 0;
    XMLHttpRequest_$Overlay.$f_OPENED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 1;
    XMLHttpRequest_$Overlay.$f_HEADERS_RECEIVED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 2;
    XMLHttpRequest_$Overlay.$f_LOADING__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 3;
    XMLHttpRequest_$Overlay.$f_DONE__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 4;
  }
  
  
};

$Util.$setClassMetadata(XMLHttpRequest_$Overlay, $Util.$makeClassName('XMLHttpRequest'));


/** @private {number} */
XMLHttpRequest_$Overlay.$f_UNSENT__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 0;


/** @private {number} */
XMLHttpRequest_$Overlay.$f_OPENED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 0;


/** @private {number} */
XMLHttpRequest_$Overlay.$f_HEADERS_RECEIVED__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 0;


/** @private {number} */
XMLHttpRequest_$Overlay.$f_LOADING__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 0;


/** @private {number} */
XMLHttpRequest_$Overlay.$f_DONE__org_gwtproject_xhr_client_XMLHttpRequest_$Overlay = 0;


exports = XMLHttpRequest_$Overlay; 
//# sourceMappingURL=XMLHttpRequest$$Overlay.js.map