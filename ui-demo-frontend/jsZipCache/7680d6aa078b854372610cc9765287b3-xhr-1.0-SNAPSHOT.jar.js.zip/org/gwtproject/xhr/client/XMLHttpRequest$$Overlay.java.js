/**
 * @fileoverview transpiled from org.gwtproject.xhr.client.XMLHttpRequest$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.xhr.client.XMLHttpRequest.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.ArrayBuffer.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _ResponseType = goog.require('org.gwtproject.xhr.client.XMLHttpRequest.ResponseType');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var XMLHttpRequest_$Overlay = goog.require('org.gwtproject.xhr.client.XMLHttpRequest.$Overlay$impl');
exports = XMLHttpRequest_$Overlay;
 