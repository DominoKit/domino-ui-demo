/**
 * @fileoverview transpiled from org.gwtproject.xhr.client.XMLHttpRequest$ResponseType.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.xhr.client.XMLHttpRequest.ResponseType');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Enum = goog.require('java.lang.Enum');
const _$Util = goog.require('nativebootstrap.Util');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Enums = goog.require('vmbootstrap.Enums');


// Re-exports the implementation.
var ResponseType = goog.require('org.gwtproject.xhr.client.XMLHttpRequest.ResponseType$impl');
exports = ResponseType;
 