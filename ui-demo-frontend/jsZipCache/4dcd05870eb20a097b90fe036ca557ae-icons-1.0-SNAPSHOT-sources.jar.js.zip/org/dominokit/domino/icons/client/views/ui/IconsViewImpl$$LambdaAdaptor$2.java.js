/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.views.ui.IconsViewImpl$$LambdaAdaptor$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.icons.client.views.ui.IconsViewImpl.$LambdaAdaptor$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');


// Re-exports the implementation.
var $LambdaAdaptor$2 = goog.require('org.dominokit.domino.icons.client.views.ui.IconsViewImpl.$LambdaAdaptor$2$impl');
exports = $LambdaAdaptor$2;
 