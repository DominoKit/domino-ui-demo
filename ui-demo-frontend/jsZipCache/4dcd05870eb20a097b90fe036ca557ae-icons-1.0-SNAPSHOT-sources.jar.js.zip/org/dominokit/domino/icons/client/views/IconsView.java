package org.dominokit.domino.icons.client.views;

import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.componentcase.shared.extension.DemoView;

public interface IconsView extends View, DemoView{
}