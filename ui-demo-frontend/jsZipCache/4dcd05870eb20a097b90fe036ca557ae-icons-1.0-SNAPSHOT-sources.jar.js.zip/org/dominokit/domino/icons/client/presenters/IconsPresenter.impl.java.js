/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.presenters.IconsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.icons.client.presenters.IconsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.icons.client.presenters.IconsPresenter.$1$impl');
let IconsView = goog.forwardDeclare('org.dominokit.domino.icons.client.views.IconsView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<IconsView>}
  */
class IconsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'IconsPresenter()'.
   * @return {!IconsPresenter}
   * @public
   */
  static $create__() {
    IconsPresenter.$clinit();
    let $instance = new IconsPresenter();
    $instance.$ctor__org_dominokit_domino_icons_client_presenters_IconsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_icons_client_presenters_IconsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_onComponentsEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_icons_client_presenters_IconsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_icons_client_presenters_IconsPresenter_() {
    return (IconsPresenter.$clinit(), IconsPresenter.$f_LOGGER__org_dominokit_domino_icons_client_presenters_IconsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_icons_client_presenters_IconsPresenter_(value) {
    (IconsPresenter.$clinit(), IconsPresenter.$f_LOGGER__org_dominokit_domino_icons_client_presenters_IconsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IconsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IconsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IconsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.icons.client.presenters.IconsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    IconsPresenter.$f_LOGGER__org_dominokit_domino_icons_client_presenters_IconsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(IconsPresenter));
  }
  
  
};

$Util.$setClassMetadata(IconsPresenter, $Util.$makeClassName('org.dominokit.domino.icons.client.presenters.IconsPresenter'));


/** @private {Logger} */
IconsPresenter.$f_LOGGER__org_dominokit_domino_icons_client_presenters_IconsPresenter_;




exports = IconsPresenter; 
//# sourceMappingURL=IconsPresenter.js.map