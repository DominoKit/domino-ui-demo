/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.views.ModalsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.views.ModalsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');
const DemoView = goog.require('org.dominokit.domino.componentcase.shared.extension.DemoView$impl');

let ComponentRemoveHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');


/**
 * @interface
 * @extends {View}
 * @extends {DemoView}
 */
class ModalsView {
  /**
   * @abstract
   * @return {ComponentRemoveHandler}
   * @public
   */
  m_cleanup__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    DemoView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_modals_client_views_ModalsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_modals_client_views_ModalsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_modals_client_views_ModalsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ModalsView, $Util.$makeClassName('org.dominokit.domino.modals.client.views.ModalsView'));


ModalsView.$markImplementor(/** @type {Function} */ (ModalsView));


exports = ModalsView; 
//# sourceMappingURL=ModalsView.js.map