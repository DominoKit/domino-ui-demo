/**
 * @fileoverview transpiled from org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const ModalsView = goog.require('org.dominokit.domino.modals.client.views.ModalsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ComponentRemoveHandler = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.modals.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$9$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ModalsView}
  */
class ModalsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
    /** @public {ModalDialog} */
    this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
    /** @public {ComponentRemoveHandler} */
    this.f_closeHandler__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ModalsViewImpl()'.
   * @return {!ModalsViewImpl}
   * @public
   */
  static $create__() {
    ModalsViewImpl.$clinit();
    let $instance = new ModalsViewImpl();
    $instance.$ctor__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ModalsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("MODALS").m_asElement__());
    this.m_initModalsSize___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
    this.m_initModalColor___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
  }
  
  /**
   * @param {ModalDialog} dialog
   * @return {void}
   * @public
   */
  m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(dialog) {
    dialog.m_open__();
    this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = dialog;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initModalsSize___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    let row = Row.m_create__();
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let defaultSizeModal = this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl();
    let defaultSizeButton = Button.m_createDefault__java_lang_String("MODAL - DEFAULT SIZE");
    defaultSizeButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$1(((/** Event */ e) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(defaultSizeModal);
    })));
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_addElement__elemental2_dom_Node(defaultSizeButton.m_asElement__()));
    let largeSizeModal = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_large__(), ModalDialog));
    let largeSizeButton = Button.m_createDefault__java_lang_String("MODAL - LARGE SIZE");
    largeSizeButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$2(((/** Event */ e$1$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(largeSizeModal);
    })));
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(largeSizeButton.m_asElement__()));
    let smallSizeModal = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_small__(), ModalDialog));
    let smallSizeButton = Button.m_createDefault__java_lang_String("MODAL - LARGE SIZE");
    smallSizeButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$3(((/** Event */ e$2$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(smallSizeModal);
    })));
    row.m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(smallSizeButton.m_asElement__()));
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("MODAL SIZE EXAMPLE", "Modals are streamlined, but flexible, dialog prompts with the minimum required functionality and smart defaults.").m_appendContent__elemental2_dom_Node(row.m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initModalsSize__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initModalColor___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    let card = Card.m_create__java_lang_String__java_lang_String("WITH MATERIAL DESIGN COLORS", "You can use material design colors.");
    let buttonsContainer = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["button-demo"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    card.m_appendContent__elemental2_dom_Node(buttonsContainer);
    let modalDialogRed = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), ModalDialog));
    let redButton = Button.m_create__java_lang_String("RED").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color);
    redButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$4(((/** Event */ e) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogRed);
    })));
    buttonsContainer.appendChild(redButton.m_asElement__());
    let modalDialogPink = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color), ModalDialog));
    let pinkButton = Button.m_create__java_lang_String("PINK").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color);
    pinkButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$5(((/** Event */ e$1$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogPink);
    })));
    buttonsContainer.appendChild(pinkButton.m_asElement__());
    let modalDialogPurple = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let purpleButton = Button.m_create__java_lang_String("PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color);
    purpleButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$6(((/** Event */ e$2$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogPurple);
    })));
    buttonsContainer.appendChild(purpleButton.m_asElement__());
    let modalDialogDeepPurple = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let deepPurpleButton = Button.m_create__java_lang_String("DEEP PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_PURPLE__org_dominokit_domino_ui_style_Color);
    deepPurpleButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$7(((/** Event */ e$3$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogDeepPurple);
    })));
    buttonsContainer.appendChild(deepPurpleButton.m_asElement__());
    let modalDialogIndigo = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color), ModalDialog));
    let indigoButton = Button.m_create__java_lang_String("INDIGO").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color);
    indigoButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$8(((/** Event */ e$4$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogIndigo);
    })));
    buttonsContainer.appendChild(indigoButton.m_asElement__());
    let modalDialogBlue = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let blueButton = Button.m_create__java_lang_String("BLUE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color);
    blueButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$9(((/** Event */ e$5$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogBlue);
    })));
    buttonsContainer.appendChild(blueButton.m_asElement__());
    let modalDialogOrange = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color), ModalDialog));
    let orangeButton = Button.m_create__java_lang_String("ORANGE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color);
    orangeButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$10(((/** Event */ e$6$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogOrange);
    })));
    buttonsContainer.appendChild(orangeButton.m_asElement__());
    let modalDialogGreen = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color), ModalDialog));
    let greenButton = Button.m_create__java_lang_String("GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color);
    greenButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$11(((/** Event */ e$7$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogGreen);
    })));
    buttonsContainer.appendChild(greenButton.m_asElement__());
    let modalDialogTeal = /**@type {ModalDialog} */ ($Casts.$to(this.m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color), ModalDialog));
    let tealButton = Button.m_create__java_lang_String("TEAL").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color);
    tealButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$12(((/** Event */ e$8$) =>{
      this.m_openDialog__org_dominokit_domino_ui_modals_ModalDialog_$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl(modalDialogTeal);
    })));
    buttonsContainer.appendChild(tealButton.m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(card.m_asElement__());
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_initModalColor__()).m_asElement__());
  }
  
  /**
   * @return {ModalDialog}
   * @public
   */
  m_createModalDialog___$p_org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    let modal = ModalDialog.m_create__java_lang_String("Modal title");
    modal.m_appendContent__elemental2_dom_Node(new Text(ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_));
    let closeButton = Button.m_create__java_lang_String("CLOSE").m_linkify__();
    let saveButton = Button.m_create__java_lang_String("SAVE CHANGES").m_linkify__();
    let closeModalListener = new $LambdaAdaptor$13(((/** Event */ evt) =>{
      modal.m_close__();
    }));
    closeButton.m_getClickableElement__().addEventListener("click", closeModalListener);
    saveButton.m_getClickableElement__().addEventListener("click", closeModalListener);
    modal.m_appendFooterContent__elemental2_dom_Node(saveButton.m_asElement__());
    modal.m_appendFooterContent__elemental2_dom_Node(closeButton.m_asElement__());
    return modal;
  }
  
  /**
   * @override
   * @return {ComponentRemoveHandler}
   * @public
   */
  m_cleanup__() {
    return this.f_closeHandler__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl() {
    this.f_element__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_closeHandler__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = ComponentRemoveHandler.$adapt((() =>{
      if (Objects.m_nonNull__java_lang_Object(this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_)) {
        this.f_openedDialog__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_.m_close__();
      }
    }));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ModalsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ModalsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ModalsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    ComponentRemoveHandler = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCase.ComponentRemoveHandler$impl');
    CodeResource = goog.module.get('org.dominokit.domino.modals.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl.$LambdaAdaptor$9$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ModalsViewImpl, $Util.$makeClassName('org.dominokit.domino.modals.client.views.ui.ModalsViewImpl'));


/** @public {?string} @const */
ModalsViewImpl.f_SAMPLE_CONTENT__org_dominokit_domino_modals_client_views_ui_ModalsViewImpl_ = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales orci ante, sed ornare eros vestibulum ut. Ut accumsan vitae eros sit amet tristique. Nullam scelerisque nunc enim, non dignissim nibh faucibus ullamcorper. Fusce pulvinar libero vel ligula iaculis ullamcorper. Integer dapibus, mi ac tempor varius, purus nibh mattis erat, vitae porta nunc nisi non tellus. Vivamus mollis ante non massa egestas fringilla. Vestibulum egestas consectetur nunc at ultricies. Morbi quis consectetur nunc.";


ModalsView.$markImplementor(ModalsViewImpl);


exports = ModalsViewImpl; 
//# sourceMappingURL=ModalsViewImpl.js.map