/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.FormsUIModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.FormsUIModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let ContributionsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.forms.client.FormsUIModuleConfiguration.$1$impl');
let FormsPresenter = goog.forwardDeclare('org.dominokit.domino.forms.client.presenters.FormsPresenter$impl');


/**
 * @implements {ModuleConfiguration}
  */
class FormsUIModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsUIModuleConfiguration()'.
   * @return {!FormsUIModuleConfiguration}
   * @public
   */
  static $create__() {
    FormsUIModuleConfiguration.$clinit();
    let $instance = new FormsUIModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_forms_client_FormsUIModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsUIModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_FormsUIModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($1.$create__org_dominokit_domino_forms_client_FormsUIModuleConfiguration__java_lang_String(this, Class.$get(FormsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {ContributionsRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(arg0) {
    ModuleConfiguration.m_registerContributions__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_extension_ContributionsRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {PresenterRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(arg0) {
    ModuleConfiguration.m_registerPresenters__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_mvp_PresenterRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CommandRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(arg0) {
    ModuleConfiguration.m_registerRequests__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_CommandRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsUIModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsUIModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsUIModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.forms.client.FormsUIModuleConfiguration.$1$impl');
    FormsPresenter = goog.module.get('org.dominokit.domino.forms.client.presenters.FormsPresenter$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsUIModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.forms.client.FormsUIModuleConfiguration'));


ModuleConfiguration.$markImplementor(FormsUIModuleConfiguration);


exports = FormsUIModuleConfiguration; 
//# sourceMappingURL=FormsUIModuleConfiguration.js.map