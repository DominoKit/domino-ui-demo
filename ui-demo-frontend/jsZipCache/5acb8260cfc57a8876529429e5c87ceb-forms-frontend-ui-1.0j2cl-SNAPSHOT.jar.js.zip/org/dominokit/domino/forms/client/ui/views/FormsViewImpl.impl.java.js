/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.ui.views.FormsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.ui.views.FormsViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormsView = goog.require('org.dominokit.domino.forms.client.views.FormsView$impl');


/**
 * @implements {FormsView}
  */
class FormsViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsViewImpl()'.
   * @return {!FormsViewImpl}
   * @public
   */
  static $create__() {
    FormsViewImpl.$clinit();
    let $instance = new FormsViewImpl();
    $instance.$ctor__org_dominokit_domino_forms_client_ui_views_FormsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_ui_views_FormsViewImpl__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsViewImpl.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsViewImpl, $Util.$makeClassName('org.dominokit.domino.forms.client.ui.views.FormsViewImpl'));


FormsView.$markImplementor(FormsViewImpl);


exports = FormsViewImpl; 
//# sourceMappingURL=FormsViewImpl.js.map