package org.dominokit.domino.animation.client;

import javax.annotation.Generated;
import org.dominokit.domino.animation.client.listeners.AnimationPresenterListenerForComponentCaseEvent;
import org.dominokit.domino.animation.client.presenters.AnimationPresenter;
import org.dominokit.domino.animation.client.presenters.AnimationPresenterCommand;
import org.dominokit.domino.animation.client.views.ui.AnimationViewImpl;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class AnimationModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(AnimationPresenter.class.getCanonicalName(), AnimationPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new AnimationPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(AnimationPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new AnimationViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(AnimationPresenterCommand.class.getCanonicalName(), AnimationPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentCaseEvent.class, new AnimationPresenterListenerForComponentCaseEvent());
  }
}
