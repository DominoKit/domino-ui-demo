/**
 * @fileoverview transpiled from org.dominokit.domino.animation.client.AnimationModuleConfiguration$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.animation.client.AnimationModuleConfiguration.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyPresenterLoader = goog.require('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader');
const _AnimationModuleConfiguration = goog.require('org.dominokit.domino.animation.client.AnimationModuleConfiguration');
const _AnimationPresenter = goog.require('org.dominokit.domino.animation.client.presenters.AnimationPresenter');
const _Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.animation.client.AnimationModuleConfiguration.$1$impl');
exports = $1;
 