package org.dominokit.domino.colors.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.colors.client.presenters.ColorsPresenterCommand;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class ColorsPresenterListenerForComponentCaseEvent implements DominoEventListener<ComponentCaseEvent> {
  @Override
  public void listen(ComponentCaseEvent event) {
    new ColorsPresenterCommand().onPresenterReady(presenter -> presenter.onComponentCaseEvent(event.context())).send();
  }
}
