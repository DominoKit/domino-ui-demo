/**
 * @fileoverview transpiled from org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let HelpersPresenter = goog.forwardDeclare('org.dominokit.domino.helpers.client.presenters.HelpersPresenter$impl');


/**
 * @extends {PresenterCommand<HelpersPresenter>}
  */
class HelpersPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'HelpersPresenterCommand()'.
   * @return {!HelpersPresenterCommand}
   * @public
   */
  static $create__() {
    HelpersPresenterCommand.$clinit();
    let $instance = new HelpersPresenterCommand();
    $instance.$ctor__org_dominokit_domino_helpers_client_presenters_HelpersPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HelpersPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_helpers_client_presenters_HelpersPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HelpersPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HelpersPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HelpersPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HelpersPresenterCommand, $Util.$makeClassName('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand'));




exports = HelpersPresenterCommand; 
//# sourceMappingURL=HelpersPresenterCommand.js.map