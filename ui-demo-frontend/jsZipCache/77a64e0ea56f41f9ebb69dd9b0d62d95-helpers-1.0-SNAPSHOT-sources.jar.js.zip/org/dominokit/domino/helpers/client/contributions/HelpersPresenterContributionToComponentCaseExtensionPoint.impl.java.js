/**
 * @fileoverview transpiled from org.dominokit.domino.helpers.client.contributions.HelpersPresenterContributionToComponentCaseExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.helpers.client.contributions.HelpersPresenterContributionToComponentCaseExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseExtensionPoint = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
let HelpersPresenter = goog.forwardDeclare('org.dominokit.domino.helpers.client.presenters.HelpersPresenter$impl');
let HelpersPresenterCommand = goog.forwardDeclare('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<ComponentCaseExtensionPoint>}
  */
class HelpersPresenterContributionToComponentCaseExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'HelpersPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {!HelpersPresenterContributionToComponentCaseExtensionPoint}
   * @public
   */
  static $create__() {
    HelpersPresenterContributionToComponentCaseExtensionPoint.$clinit();
    let $instance = new HelpersPresenterContributionToComponentCaseExtensionPoint();
    $instance.$ctor__org_dominokit_domino_helpers_client_contributions_HelpersPresenterContributionToComponentCaseExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HelpersPresenterContributionToComponentCaseExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_helpers_client_contributions_HelpersPresenterContributionToComponentCaseExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(extensionPoint) {
    HelpersPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** HelpersPresenter */ presenter) =>{
      presenter.m_contributeToComponentCaseModule__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(extensionPoint.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_componentcase_shared_extension_ComponentCaseExtensionPoint(/**@type {ComponentCaseExtensionPoint} */ ($Casts.$to(arg0, ComponentCaseExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HelpersPresenterContributionToComponentCaseExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HelpersPresenterContributionToComponentCaseExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HelpersPresenterContributionToComponentCaseExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseExtensionPoint = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseExtensionPoint$impl');
    HelpersPresenterCommand = goog.module.get('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HelpersPresenterContributionToComponentCaseExtensionPoint, $Util.$makeClassName('org.dominokit.domino.helpers.client.contributions.HelpersPresenterContributionToComponentCaseExtensionPoint'));


Contribution.$markImplementor(HelpersPresenterContributionToComponentCaseExtensionPoint);


exports = HelpersPresenterContributionToComponentCaseExtensionPoint; 
//# sourceMappingURL=HelpersPresenterContributionToComponentCaseExtensionPoint.js.map