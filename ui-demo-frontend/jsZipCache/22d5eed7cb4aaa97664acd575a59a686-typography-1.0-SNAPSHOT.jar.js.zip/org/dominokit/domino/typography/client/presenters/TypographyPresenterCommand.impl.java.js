/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let TypographyPresenter = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenter$impl');


/**
 * @extends {PresenterCommand<TypographyPresenter>}
  */
class TypographyPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyPresenterCommand()'.
   * @return {!TypographyPresenterCommand}
   * @public
   */
  static $create__() {
    TypographyPresenterCommand.$clinit();
    let $instance = new TypographyPresenterCommand();
    $instance.$ctor__org_dominokit_domino_typography_client_presenters_TypographyPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_presenters_TypographyPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TypographyPresenterCommand, $Util.$makeClassName('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand'));




exports = TypographyPresenterCommand; 
//# sourceMappingURL=TypographyPresenterCommand.js.map