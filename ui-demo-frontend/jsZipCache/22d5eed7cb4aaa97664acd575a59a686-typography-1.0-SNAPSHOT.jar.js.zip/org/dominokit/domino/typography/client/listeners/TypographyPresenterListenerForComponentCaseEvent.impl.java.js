/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let TypographyPresenter = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenter$impl');
let TypographyPresenterCommand = goog.forwardDeclare('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentCaseEvent>}
  */
class TypographyPresenterListenerForComponentCaseEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TypographyPresenterListenerForComponentCaseEvent()'.
   * @return {!TypographyPresenterListenerForComponentCaseEvent}
   * @public
   */
  static $create__() {
    TypographyPresenterListenerForComponentCaseEvent.$clinit();
    let $instance = new TypographyPresenterListenerForComponentCaseEvent();
    $instance.$ctor__org_dominokit_domino_typography_client_listeners_TypographyPresenterListenerForComponentCaseEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TypographyPresenterListenerForComponentCaseEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_typography_client_listeners_TypographyPresenterListenerForComponentCaseEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentCaseEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(event) {
    TypographyPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** TypographyPresenter */ presenter) =>{
      presenter.m_onComponentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(/**@type {ComponentCaseContext} */ ($Casts.$to(event.m_context__(), ComponentCaseContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_componentcase_shared_extension_ComponentCaseEvent(/**@type {ComponentCaseEvent} */ ($Casts.$to(arg0, ComponentCaseEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TypographyPresenterListenerForComponentCaseEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TypographyPresenterListenerForComponentCaseEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypographyPresenterListenerForComponentCaseEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentCaseContext = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    TypographyPresenterCommand = goog.module.get('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TypographyPresenterListenerForComponentCaseEvent, $Util.$makeClassName('org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent'));


DominoEventListener.$markImplementor(TypographyPresenterListenerForComponentCaseEvent);


exports = TypographyPresenterListenerForComponentCaseEvent; 
//# sourceMappingURL=TypographyPresenterListenerForComponentCaseEvent.js.map