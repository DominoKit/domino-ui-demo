/**
 * @fileoverview transpiled from org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _ComponentCaseEvent = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent');
const _TypographyPresenter = goog.require('org.dominokit.domino.typography.client.presenters.TypographyPresenter');
const _TypographyPresenterCommand = goog.require('org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TypographyPresenterListenerForComponentCaseEvent = goog.require('org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent$impl');
exports = TypographyPresenterListenerForComponentCaseEvent;
 