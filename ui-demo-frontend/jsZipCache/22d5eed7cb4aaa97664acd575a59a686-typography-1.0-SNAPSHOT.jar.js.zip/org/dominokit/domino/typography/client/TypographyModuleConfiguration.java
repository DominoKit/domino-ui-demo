package org.dominokit.domino.typography.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;
import org.dominokit.domino.typography.client.listeners.TypographyPresenterListenerForComponentCaseEvent;
import org.dominokit.domino.typography.client.presenters.TypographyPresenter;
import org.dominokit.domino.typography.client.presenters.TypographyPresenterCommand;
import org.dominokit.domino.typography.client.views.ui.TypographyViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class TypographyModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(TypographyPresenter.class.getCanonicalName(), TypographyPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new TypographyPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(TypographyPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new TypographyViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(TypographyPresenterCommand.class.getCanonicalName(), TypographyPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentCaseEvent.class, new TypographyPresenterListenerForComponentCaseEvent());
  }
}
