/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.listeners.MediaPresenterListenerForComponentsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.media.client.listeners.MediaPresenterListenerForComponentsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
let MediaPresenter = goog.forwardDeclare('org.dominokit.domino.media.client.presenters.MediaPresenter$impl');
let MediaPresenterCommand = goog.forwardDeclare('org.dominokit.domino.media.client.presenters.MediaPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<ComponentsEvent>}
  */
class MediaPresenterListenerForComponentsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'MediaPresenterListenerForComponentsEvent()'.
   * @return {!MediaPresenterListenerForComponentsEvent}
   * @public
   */
  static $create__() {
    MediaPresenterListenerForComponentsEvent.$clinit();
    let $instance = new MediaPresenterListenerForComponentsEvent();
    $instance.$ctor__org_dominokit_domino_media_client_listeners_MediaPresenterListenerForComponentsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaPresenterListenerForComponentsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_media_client_listeners_MediaPresenterListenerForComponentsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {ComponentsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_components_shared_extension_ComponentsEvent(event) {
    MediaPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** MediaPresenter */ presenter) =>{
      presenter.m_onComponentsEvent__org_dominokit_domino_components_shared_extension_ComponentsContext(/**@type {ComponentsContext} */ ($Casts.$to(event.m_context__(), ComponentsContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_components_shared_extension_ComponentsEvent(/**@type {ComponentsEvent} */ ($Casts.$to(arg0, ComponentsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaPresenterListenerForComponentsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaPresenterListenerForComponentsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaPresenterListenerForComponentsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    ComponentsContext = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    MediaPresenterCommand = goog.module.get('org.dominokit.domino.media.client.presenters.MediaPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MediaPresenterListenerForComponentsEvent, $Util.$makeClassName('org.dominokit.domino.media.client.listeners.MediaPresenterListenerForComponentsEvent'));


DominoEventListener.$markImplementor(MediaPresenterListenerForComponentsEvent);


exports = MediaPresenterListenerForComponentsEvent; 
//# sourceMappingURL=MediaPresenterListenerForComponentsEvent.js.map