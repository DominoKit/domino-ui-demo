/**
 * @fileoverview transpiled from org.dominokit.domino.media.client.views.ui.MediaViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.media.client.views.ui.MediaViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const MediaView = goog.require('org.dominokit.domino.media.client.views.MediaView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let MediaObject = goog.forwardDeclare('org.dominokit.domino.ui.media.MediaObject$impl');
let MediaAlign = goog.forwardDeclare('org.dominokit.domino.ui.media.MediaObject.MediaAlign$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {MediaView}
  */
class MediaViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'MediaViewImpl()'.
   * @return {!MediaViewImpl}
   * @public
   */
  static $create__() {
    MediaViewImpl.$clinit();
    let $instance = new MediaViewImpl();
    $instance.$ctor__org_dominokit_domino_media_client_views_ui_MediaViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'MediaViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_media_client_views_ui_MediaViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_media_client_views_ui_MediaViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(MediaViewImpl.f_MODULE_NAME__org_dominokit_domino_media_client_views_ui_MediaViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("MEDIA OBJECT").m_asElement__());
    this.m_defaultMedia___$p_org_dominokit_domino_media_client_views_ui_MediaViewImpl();
    this.m_mediaAlignment___$p_org_dominokit_domino_media_client_views_ui_MediaViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_defaultMedia___$p_org_dominokit_domino_media_client_views_ui_MediaViewImpl() {
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DEFAULT MEDIA", "The default media displays a media object (images, video, audio) to the left or right of a content block.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setRightMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setRightMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_))).m_asElement__());
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(MediaViewImpl.f_MODULE_NAME__org_dominokit_domino_media_client_views_ui_MediaViewImpl, "defaultMedia").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_mediaAlignment___$p_org_dominokit_domino_media_client_views_ui_MediaViewImpl() {
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("MEDIA ALIGNMENT", "The images or other media can be aligned top, middle, or bottom. The default is top aligned.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_alignLeftMedia__org_dominokit_domino_ui_media_MediaObject_MediaAlign(MediaAlign.f_MIDDLE__org_dominokit_domino_ui_media_MediaObject_MediaAlign).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String("Media heading").m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("http://placehold.it/64x64").m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_alignLeftMedia__org_dominokit_domino_ui_media_MediaObject_MediaAlign(MediaAlign.f_BOTTOM__org_dominokit_domino_ui_media_MediaObject_MediaAlign).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_))).m_asElement__());
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(MediaViewImpl.f_MODULE_NAME__org_dominokit_domino_media_client_views_ui_MediaViewImpl, "mediaAlignment").m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_media_client_views_ui_MediaViewImpl() {
    this.f_element__org_dominokit_domino_media_client_views_ui_MediaViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MediaViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MediaViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    MediaViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    MediaObject = goog.module.get('org.dominokit.domino.ui.media.MediaObject$impl');
    MediaAlign = goog.module.get('org.dominokit.domino.ui.media.MediaObject.MediaAlign$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(MediaViewImpl, $Util.$makeClassName('org.dominokit.domino.media.client.views.ui.MediaViewImpl'));


/** @public {?string} @const */
MediaViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_media_client_views_ui_MediaViewImpl_ = "Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.";


/** @public {?string} @const */
MediaViewImpl.f_MODULE_NAME__org_dominokit_domino_media_client_views_ui_MediaViewImpl = "media";


MediaView.$markImplementor(MediaViewImpl);


exports = MediaViewImpl; 
//# sourceMappingURL=MediaViewImpl.js.map