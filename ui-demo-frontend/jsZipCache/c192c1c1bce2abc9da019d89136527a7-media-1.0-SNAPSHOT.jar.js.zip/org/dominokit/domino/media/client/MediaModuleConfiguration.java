package org.dominokit.domino.media.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.components.shared.extension.ComponentsEvent;
import org.dominokit.domino.media.client.listeners.MediaPresenterListenerForComponentsEvent;
import org.dominokit.domino.media.client.presenters.MediaPresenter;
import org.dominokit.domino.media.client.presenters.MediaPresenterCommand;
import org.dominokit.domino.media.client.views.ui.MediaViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class MediaModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(MediaPresenter.class.getCanonicalName(), MediaPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new MediaPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(MediaPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new MediaViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(MediaPresenterCommand.class.getCanonicalName(), MediaPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentsEvent.class, new MediaPresenterListenerForComponentsEvent());
  }
}
