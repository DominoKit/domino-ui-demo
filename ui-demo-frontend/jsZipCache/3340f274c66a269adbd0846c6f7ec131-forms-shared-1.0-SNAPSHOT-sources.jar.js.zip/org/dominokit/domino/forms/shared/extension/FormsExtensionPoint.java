package org.dominokit.domino.forms.shared.extension;

import org.dominokit.domino.api.shared.extension.ExtensionPoint;

public interface FormsExtensionPoint extends ExtensionPoint<FormsContext>{
}
