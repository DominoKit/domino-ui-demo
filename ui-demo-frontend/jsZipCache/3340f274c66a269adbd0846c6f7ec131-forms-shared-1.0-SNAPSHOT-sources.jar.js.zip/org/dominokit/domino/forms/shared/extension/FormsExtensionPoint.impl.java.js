/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ExtensionPoint = goog.require('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');

let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint.$LambdaAdaptor$impl');


/**
 * @interface
 * @extends {ExtensionPoint<FormsContext>}
 */
class FormsExtensionPoint {
  /**
   * @param {?function():FormsContext} fn
   * @return {FormsExtensionPoint}
   * @public
   */
  static $adapt(fn) {
    FormsExtensionPoint.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ExtensionPoint.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint;
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsExtensionPoint.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(FormsExtensionPoint, $Util.$makeClassName('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint'));


FormsExtensionPoint.$markImplementor(/** @type {Function} */ (FormsExtensionPoint));


exports = FormsExtensionPoint; 
//# sourceMappingURL=FormsExtensionPoint.js.map