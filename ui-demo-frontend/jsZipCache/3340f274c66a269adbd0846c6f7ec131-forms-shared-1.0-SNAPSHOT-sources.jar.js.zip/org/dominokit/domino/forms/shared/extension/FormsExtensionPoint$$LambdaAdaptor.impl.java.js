/**
 * @fileoverview transpiled from org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormsExtensionPoint = goog.require('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$impl');

let FormsContext = goog.forwardDeclare('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {FormsExtensionPoint}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():FormsContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():FormsContext} */
    this.f_$$fn__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$LambdaAdaptor__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():FormsContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$LambdaAdaptor__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {FormsContext}
   * @public
   */
  m_context__() {
    let /** ?function():FormsContext */ $function;
    return /**@type {FormsContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_forms_shared_extension_FormsExtensionPoint_$LambdaAdaptor, $function()), FormsContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    FormsContext = goog.module.get('org.dominokit.domino.forms.shared.extension.FormsContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.forms.shared.extension.FormsExtensionPoint$$LambdaAdaptor'));


FormsExtensionPoint.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=FormsExtensionPoint$$LambdaAdaptor.js.map