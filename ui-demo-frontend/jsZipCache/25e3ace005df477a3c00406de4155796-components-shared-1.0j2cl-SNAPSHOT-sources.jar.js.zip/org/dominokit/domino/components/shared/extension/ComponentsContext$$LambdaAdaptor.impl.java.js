/**
 * @fileoverview transpiled from org.dominokit.domino.components.shared.extension.ComponentsContext$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.shared.extension.ComponentsContext.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentsContext = goog.require('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');

let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');


/**
 * @implements {ComponentsContext}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentCaseContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():ComponentCaseContext} */
    this.f_$$fn__org_dominokit_domino_components_shared_extension_ComponentsContext_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_components_shared_extension_ComponentsContext_$LambdaAdaptor__org_dominokit_domino_components_shared_extension_ComponentsContext_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():ComponentCaseContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_components_shared_extension_ComponentsContext_$LambdaAdaptor__org_dominokit_domino_components_shared_extension_ComponentsContext_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_components_shared_extension_ComponentsContext_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {ComponentCaseContext}
   * @public
   */
  m_getComponentCaseContext__() {
    let /** ?function():ComponentCaseContext */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_components_shared_extension_ComponentsContext_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.components.shared.extension.ComponentsContext$$LambdaAdaptor'));


ComponentsContext.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ComponentsContext$$LambdaAdaptor.js.map