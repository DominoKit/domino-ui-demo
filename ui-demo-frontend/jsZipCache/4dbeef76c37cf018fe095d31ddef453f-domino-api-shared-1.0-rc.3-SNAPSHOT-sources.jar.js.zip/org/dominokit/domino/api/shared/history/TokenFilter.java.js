/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _HistoryToken = goog.require('org.dominokit.domino.api.shared.history.HistoryToken');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.$LambdaAdaptor');
const _AnyFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.AnyFilter');
const _AnyFragmentFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.AnyFragmentFilter');
const _AnyPathFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.AnyPathFilter');
const _ContainsFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFilter');
const _ContainsFragmentFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFragmentFilter');
const _EndsWithFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFilter');
const _EndsWithFragmentFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFragmentFilter');
const _EndsWithPathFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithPathFilter');
const _ExactFragmentFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.ExactFragmentFilter');
const _ExactMatchFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.ExactMatchFilter');
const _ExactPathFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.ExactPathFilter');
const _HasPathFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.HasPathFilter');
const _HasPathsFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.HasPathsFilter');
const _StartsWithFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFilter');
const _StartsWithFragmentFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFragmentFilter');
const _StartsWithPathFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithPathFilter');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');
exports = TokenFilter;
 