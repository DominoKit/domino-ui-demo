package org.dominokit.domino.api.shared.history;

@FunctionalInterface
public interface CurrentStateHistory {
    void fireCurrentStateHistory();
}
