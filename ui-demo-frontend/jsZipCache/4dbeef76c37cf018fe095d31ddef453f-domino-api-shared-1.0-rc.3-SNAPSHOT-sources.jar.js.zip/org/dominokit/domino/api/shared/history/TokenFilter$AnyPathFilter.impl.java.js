/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$AnyPathFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.AnyPathFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let Objects = goog.forwardDeclare('java.util.Objects$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class AnyPathFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AnyPathFilter()'.
   * @return {!AnyPathFilter}
   * @public
   */
  static $create__() {
    AnyPathFilter.$clinit();
    let $instance = new AnyPathFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_AnyPathFilter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnyPathFilter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_AnyPathFilter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return Objects.m_nonNull__java_lang_Object(token.m_path__()) && !token.m_paths__().isEmpty();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnyPathFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnyPathFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnyPathFilter.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnyPathFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$AnyPathFilter'));


TokenFilter.$markImplementor(AnyPathFilter);


exports = AnyPathFilter; 
//# sourceMappingURL=TokenFilter$AnyPathFilter.js.map