/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.ArrayResponse.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.request.ArrayResponse');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean');
const _ArrayList = goog.require('java.util.ArrayList');
const _Arrays = goog.require('java.util.Arrays');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');


// Re-exports the implementation.
var ArrayResponse = goog.require('org.dominokit.domino.api.shared.request.ArrayResponse$impl');
exports = ArrayResponse;
 