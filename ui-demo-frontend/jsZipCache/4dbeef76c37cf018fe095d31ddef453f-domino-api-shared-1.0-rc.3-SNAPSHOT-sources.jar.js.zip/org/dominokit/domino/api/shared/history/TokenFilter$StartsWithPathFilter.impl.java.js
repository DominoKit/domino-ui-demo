/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$StartsWithPathFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithPathFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class StartsWithPathFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithPathFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'StartsWithPathFilter(String)'.
   * @param {?string} path
   * @return {!StartsWithPathFilter}
   * @public
   */
  static $create__java_lang_String(path) {
    StartsWithPathFilter.$clinit();
    let $instance = new StartsWithPathFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithPathFilter__java_lang_String(path);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'StartsWithPathFilter(String)'.
   * @param {?string} path
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithPathFilter__java_lang_String(path) {
    this.$ctor__java_lang_Object__();
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithPathFilter_ = path;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_startsWith__java_lang_String__java_lang_String(token.m_path__(), this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_StartsWithPathFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StartsWithPathFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StartsWithPathFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    StartsWithPathFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(StartsWithPathFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$StartsWithPathFilter'));


TokenFilter.$markImplementor(StartsWithPathFilter);


exports = StartsWithPathFilter; 
//# sourceMappingURL=TokenFilter$StartsWithPathFilter.js.map