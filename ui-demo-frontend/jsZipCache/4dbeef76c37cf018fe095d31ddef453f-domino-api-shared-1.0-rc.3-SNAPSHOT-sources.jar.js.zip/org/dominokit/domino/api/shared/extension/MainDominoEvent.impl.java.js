/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.MainDominoEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainDominoEvent.$LambdaAdaptor$impl');
let MainEventContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainEventContext$impl');


/**
 * @interface
 * @extends {DominoEvent<MainEventContext>}
 */
class MainDominoEvent {
  /**
   * @param {?function():MainEventContext} fn
   * @return {MainDominoEvent}
   * @public
   */
  static $adapt(fn) {
    MainDominoEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    DominoEvent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainDominoEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_MainDominoEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainDominoEvent;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MainDominoEvent.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.extension.MainDominoEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MainDominoEvent, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.MainDominoEvent'));


MainDominoEvent.$markImplementor(/** @type {Function} */ (MainDominoEvent));


exports = MainDominoEvent; 
//# sourceMappingURL=MainDominoEvent.js.map