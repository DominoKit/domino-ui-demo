/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.HistoryToken.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.HistoryToken$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');


/**
 * @interface
 */
class HistoryToken {
  /**
   * @abstract
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_startsWithPath__java_lang_String(path) {
  }
  
  /**
   * @abstract
   * @param {?string} fragment
   * @return {boolean}
   * @public
   */
  m_fragmentsStartsWith__java_lang_String(fragment) {
  }
  
  /**
   * @abstract
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_endsWithPath__java_lang_String(path) {
  }
  
  /**
   * @abstract
   * @param {?string} fragment
   * @return {boolean}
   * @public
   */
  m_endsWithFragment__java_lang_String(fragment) {
  }
  
  /**
   * @abstract
   * @param {?string} path
   * @return {boolean}
   * @public
   */
  m_containsPath__java_lang_String(path) {
  }
  
  /**
   * @abstract
   * @param {?string} fragment
   * @return {boolean}
   * @public
   */
  m_containsFragment__java_lang_String(fragment) {
  }
  
  /**
   * @abstract
   * @return {List<?string>}
   * @public
   */
  m_paths__() {
  }
  
  /**
   * @abstract
   * @return {List<?string>}
   * @public
   */
  m_fragments__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_path__() {
  }
  
  /**
   * @abstract
   * @param {?string} path
   * @return {HistoryToken}
   * @public
   */
  m_appendPath__java_lang_String(path) {
  }
  
  /**
   * @abstract
   * @param {?string} path
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replacePath__java_lang_String__java_lang_String(path, replacement) {
  }
  
  /**
   * @abstract
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replaceLastPath__java_lang_String(replacement) {
  }
  
  /**
   * @abstract
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replaceLastFragment__java_lang_String(replacement) {
  }
  
  /**
   * @abstract
   * @param {?string} newPath
   * @return {HistoryToken}
   * @public
   */
  m_replaceAllPaths__java_lang_String(newPath) {
  }
  
  /**
   * @abstract
   * @return {HistoryToken}
   * @public
   */
  m_clearPaths__() {
  }
  
  /**
   * @abstract
   * @return {HistoryToken}
   * @public
   */
  m_clearFragments__() {
  }
  
  /**
   * @abstract
   * @param {?string} path
   * @return {HistoryToken}
   * @public
   */
  m_removePath__java_lang_String(path) {
  }
  
  /**
   * @abstract
   * @return {Map<?string, ?string>}
   * @public
   */
  m_queryParameters__() {
  }
  
  /**
   * @abstract
   * @param {?string} name
   * @return {boolean}
   * @public
   */
  m_hasQueryParameter__java_lang_String(name) {
  }
  
  /**
   * @abstract
   * @param {?string} name
   * @return {?string}
   * @public
   */
  m_parameterValue__java_lang_String(name) {
  }
  
  /**
   * @abstract
   * @param {?string} fragment
   * @return {HistoryToken}
   * @public
   */
  m_appendFragment__java_lang_String(fragment) {
  }
  
  /**
   * @abstract
   * @param {?string} name
   * @param {?string} value
   * @return {HistoryToken}
   * @public
   */
  m_appendParameter__java_lang_String__java_lang_String(name, value) {
  }
  
  /**
   * @abstract
   * @param {?string} fragment
   * @param {?string} replacement
   * @return {HistoryToken}
   * @public
   */
  m_replaceFragment__java_lang_String__java_lang_String(fragment, replacement) {
  }
  
  /**
   * @abstract
   * @param {?string} name
   * @param {?string} replacementName
   * @param {?string} replacementValue
   * @return {HistoryToken}
   * @public
   */
  m_replaceParameter__java_lang_String__java_lang_String__java_lang_String(name, replacementName, replacementValue) {
  }
  
  /**
   * @abstract
   * @param {?string} name
   * @return {HistoryToken}
   * @public
   */
  m_removeParameter__java_lang_String(name) {
  }
  
  /**
   * @abstract
   * @param {?string} newFragment
   * @return {HistoryToken}
   * @public
   */
  m_replaceAllFragments__java_lang_String(newFragment) {
  }
  
  /**
   * @abstract
   * @param {?string} newQuery
   * @return {HistoryToken}
   * @public
   */
  m_replaceQuery__java_lang_String(newQuery) {
  }
  
  /**
   * @abstract
   * @return {HistoryToken}
   * @public
   */
  m_clearQuery__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_query__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_fragment__() {
  }
  
  /**
   * @abstract
   * @param {?string} fragment
   * @return {HistoryToken}
   * @public
   */
  m_removeFragment__java_lang_String(fragment) {
  }
  
  /**
   * @abstract
   * @return {HistoryToken}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_HistoryToken = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_HistoryToken;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_HistoryToken;
  }
  
  /**
   * @public
   */
  static $clinit() {
    HistoryToken.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(HistoryToken, $Util.$makeClassName('org.dominokit.domino.api.shared.history.HistoryToken'));


HistoryToken.$markImplementor(/** @type {Function} */ (HistoryToken));


exports = HistoryToken; 
//# sourceMappingURL=HistoryToken.js.map