package org.dominokit.domino.api.shared.request;

public final class VoidResponse implements ResponseBean {
}
