/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.RequestBean.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.request.RequestBean$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let VoidRequest = goog.forwardDeclare('org.dominokit.domino.api.shared.request.VoidRequest$impl');


/**
 * @interface
 * @extends {Serializable}
 */
class RequestBean {
  /**
   * @return {VoidRequest}
   * @public
   */
  static get f_VOID_REQUEST__org_dominokit_domino_api_shared_request_RequestBean() {
    return (RequestBean.$clinit(), RequestBean.$f_VOID_REQUEST__org_dominokit_domino_api_shared_request_RequestBean);
  }
  
  /**
   * @param {VoidRequest} value
   * @return {void}
   * @public
   */
  static set f_VOID_REQUEST__org_dominokit_domino_api_shared_request_RequestBean(value) {
    (RequestBean.$clinit(), RequestBean.$f_VOID_REQUEST__org_dominokit_domino_api_shared_request_RequestBean = value);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Serializable.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_request_RequestBean = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_request_RequestBean;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_request_RequestBean;
  }
  
  /**
   * @public
   */
  static $clinit() {
    RequestBean.$clinit = function() {};
    VoidRequest = goog.module.get('org.dominokit.domino.api.shared.request.VoidRequest$impl');
    RequestBean.$f_VOID_REQUEST__org_dominokit_domino_api_shared_request_RequestBean = VoidRequest.$create__();
  }
  
  
};

$Util.$setClassMetadataForInterface(RequestBean, $Util.$makeClassName('org.dominokit.domino.api.shared.request.RequestBean'));


/** @private {VoidRequest} */
RequestBean.$f_VOID_REQUEST__org_dominokit_domino_api_shared_request_RequestBean;


RequestBean.$markImplementor(/** @type {Function} */ (RequestBean));


exports = RequestBean; 
//# sourceMappingURL=RequestBean.js.map