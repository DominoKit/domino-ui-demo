/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.HistoryToken$TokenCannotBeNullException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.HistoryToken.TokenCannotBeNullException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class TokenCannotBeNullException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'TokenCannotBeNullException()'.
   * @return {!TokenCannotBeNullException}
   * @public
   */
  static $create__() {
    TokenCannotBeNullException.$clinit();
    let $instance = new TokenCannotBeNullException();
    $instance.$ctor__org_dominokit_domino_api_shared_history_HistoryToken_TokenCannotBeNullException__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TokenCannotBeNullException()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_HistoryToken_TokenCannotBeNullException__() {
    this.$ctor__java_lang_RuntimeException__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TokenCannotBeNullException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TokenCannotBeNullException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TokenCannotBeNullException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TokenCannotBeNullException, $Util.$makeClassName('org.dominokit.domino.api.shared.history.HistoryToken$TokenCannotBeNullException'));




exports = TokenCannotBeNullException; 
//# sourceMappingURL=HistoryToken$TokenCannotBeNullException.js.map