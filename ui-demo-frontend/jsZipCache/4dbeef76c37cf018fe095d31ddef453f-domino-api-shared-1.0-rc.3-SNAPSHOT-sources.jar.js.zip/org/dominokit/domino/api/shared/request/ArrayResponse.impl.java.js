/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.ArrayResponse.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.request.ArrayResponse$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');


/**
 * @template C_T
 * @implements {ResponseBean}
  */
class ArrayResponse extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Array<C_T>} */
    this.f_items__org_dominokit_domino_api_shared_request_ArrayResponse_;
  }
  
  /**
   * Factory method corresponding to constructor 'ArrayResponse()'.
   * @template C_T
   * @return {!ArrayResponse<C_T>}
   * @public
   */
  static $create__() {
    ArrayResponse.$clinit();
    let $instance = new ArrayResponse();
    $instance.$ctor__org_dominokit_domino_api_shared_request_ArrayResponse__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ArrayResponse()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_request_ArrayResponse__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * Factory method corresponding to constructor 'ArrayResponse(Object[])'.
   * @template C_T
   * @param {Array<C_T>} items
   * @return {!ArrayResponse<C_T>}
   * @public
   */
  static $create__arrayOf_java_lang_Object(items) {
    ArrayResponse.$clinit();
    let $instance = new ArrayResponse();
    $instance.$ctor__org_dominokit_domino_api_shared_request_ArrayResponse__arrayOf_java_lang_Object(items);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ArrayResponse(Object[])'.
   * @param {Array<C_T>} items
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_request_ArrayResponse__arrayOf_java_lang_Object(items) {
    this.$ctor__java_lang_Object__();
    this.f_items__org_dominokit_domino_api_shared_request_ArrayResponse_ = items;
  }
  
  /**
   * @return {Array<C_T>}
   * @public
   */
  m_getItems__() {
    return this.f_items__org_dominokit_domino_api_shared_request_ArrayResponse_;
  }
  
  /**
   * @param {Array<C_T>} items
   * @return {void}
   * @public
   */
  m_setItems__arrayOf_java_lang_Object(items) {
    this.f_items__org_dominokit_domino_api_shared_request_ArrayResponse_ = items;
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_asList__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_items__org_dominokit_domino_api_shared_request_ArrayResponse_)) {
      return /**@type {List<C_T>} */ (Arrays.m_asList__arrayOf_java_lang_Object(this.f_items__org_dominokit_domino_api_shared_request_ArrayResponse_));
    } else {
      return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ArrayResponse;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ArrayResponse);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ArrayResponse.$clinit = function() {};
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ArrayResponse, $Util.$makeClassName('org.dominokit.domino.api.shared.request.ArrayResponse'));


ResponseBean.$markImplementor(ArrayResponse);


exports = ArrayResponse; 
//# sourceMappingURL=ArrayResponse.js.map