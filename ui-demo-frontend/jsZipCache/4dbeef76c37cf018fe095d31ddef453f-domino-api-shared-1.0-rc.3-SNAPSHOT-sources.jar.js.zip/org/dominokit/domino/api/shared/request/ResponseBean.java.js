/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.ResponseBean.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.shared.request.ResponseBean');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _$Util = goog.require('nativebootstrap.Util');
const _VoidResponse = goog.require('org.dominokit.domino.api.shared.request.VoidResponse');


// Re-exports the implementation.
var ResponseBean = goog.require('org.dominokit.domino.api.shared.request.ResponseBean$impl');
exports = ResponseBean;
 