/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.$LambdaAdaptor$impl');
let AnyFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.AnyFilter$impl');
let AnyFragmentFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.AnyFragmentFilter$impl');
let AnyPathFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.AnyPathFilter$impl');
let ContainsFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFilter$impl');
let ContainsFragmentFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFragmentFilter$impl');
let EndsWithFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFilter$impl');
let EndsWithFragmentFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFragmentFilter$impl');
let EndsWithPathFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithPathFilter$impl');
let ExactFragmentFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.ExactFragmentFilter$impl');
let ExactMatchFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.ExactMatchFilter$impl');
let ExactPathFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.ExactPathFilter$impl');
let HasPathFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.HasPathFilter$impl');
let HasPathsFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.HasPathsFilter$impl');
let StartsWithFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFilter$impl');
let StartsWithFragmentFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFragmentFilter$impl');
let StartsWithPathFilter = goog.forwardDeclare('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithPathFilter$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @interface
 */
class TokenFilter {
  /**
   * @abstract
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
  }
  
  /**
   * @param {?string} matchingToken
   * @return {TokenFilter}
   * @public
   */
  static m_exactMatch__java_lang_String(matchingToken) {
    TokenFilter.$clinit();
    return ExactMatchFilter.$create__java_lang_String(matchingToken);
  }
  
  /**
   * @param {?string} prefix
   * @return {TokenFilter}
   * @public
   */
  static m_startsWith__java_lang_String(prefix) {
    TokenFilter.$clinit();
    return StartsWithFilter.$create__java_lang_String(prefix);
  }
  
  /**
   * @param {?string} postfix
   * @return {TokenFilter}
   * @public
   */
  static m_endsWith__java_lang_String(postfix) {
    TokenFilter.$clinit();
    return EndsWithFilter.$create__java_lang_String(postfix);
  }
  
  /**
   * @param {?string} part
   * @return {TokenFilter}
   * @public
   */
  static m_contains__java_lang_String(part) {
    TokenFilter.$clinit();
    return ContainsFilter.$create__java_lang_String(part);
  }
  
  /**
   * @return {TokenFilter}
   * @public
   */
  static m_any__() {
    TokenFilter.$clinit();
    return AnyFilter.$create__();
  }
  
  /**
   * @param {?string} matchingToken
   * @return {TokenFilter}
   * @public
   */
  static m_exactFragmentMatch__java_lang_String(matchingToken) {
    TokenFilter.$clinit();
    return ExactFragmentFilter.$create__java_lang_String(matchingToken);
  }
  
  /**
   * @param {?string} prefix
   * @return {TokenFilter}
   * @public
   */
  static m_startsWithFragment__java_lang_String(prefix) {
    TokenFilter.$clinit();
    return StartsWithFragmentFilter.$create__java_lang_String(prefix);
  }
  
  /**
   * @param {?string} postfix
   * @return {TokenFilter}
   * @public
   */
  static m_endsWithFragment__java_lang_String(postfix) {
    TokenFilter.$clinit();
    return EndsWithFragmentFilter.$create__java_lang_String(postfix);
  }
  
  /**
   * @param {?string} part
   * @return {TokenFilter}
   * @public
   */
  static m_containsFragment__java_lang_String(part) {
    TokenFilter.$clinit();
    return ContainsFragmentFilter.$create__java_lang_String(part);
  }
  
  /**
   * @return {TokenFilter}
   * @public
   */
  static m_anyFragment__() {
    TokenFilter.$clinit();
    return AnyFragmentFilter.$create__();
  }
  
  /**
   * @param {?string} path
   * @return {TokenFilter}
   * @public
   */
  static m_hasPathFilter__java_lang_String(path) {
    TokenFilter.$clinit();
    return HasPathFilter.$create__java_lang_String(path);
  }
  
  /**
   * @param {Array<?string>} paths
   * @return {TokenFilter}
   * @public
   */
  static m_hasPathsFilter__arrayOf_java_lang_String(paths) {
    TokenFilter.$clinit();
    return HasPathsFilter.$create__arrayOf_java_lang_String(paths);
  }
  
  /**
   * @param {?string} path
   * @return {TokenFilter}
   * @public
   */
  static m_exactPathFilter__java_lang_String(path) {
    TokenFilter.$clinit();
    return ExactPathFilter.$create__java_lang_String(path);
  }
  
  /**
   * @param {?string} path
   * @return {TokenFilter}
   * @public
   */
  static m_startsWithPathFilter__java_lang_String(path) {
    TokenFilter.$clinit();
    return StartsWithPathFilter.$create__java_lang_String(path);
  }
  
  /**
   * @param {?string} path
   * @return {TokenFilter}
   * @public
   */
  static m_endsWithPathFilter__java_lang_String(path) {
    TokenFilter.$clinit();
    return EndsWithPathFilter.$create__java_lang_String(path);
  }
  
  /**
   * @return {TokenFilter}
   * @public
   */
  static m_anyPathFilter__() {
    TokenFilter.$clinit();
    return AnyPathFilter.$create__();
  }
  
  /**
   * @param {?function(HistoryToken):boolean} fn
   * @return {TokenFilter}
   * @public
   */
  static $adapt(fn) {
    TokenFilter.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_api_shared_history_TokenFilter() {
    return (TokenFilter.$clinit(), TokenFilter.$f_LOGGER__org_dominokit_domino_api_shared_history_TokenFilter);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_api_shared_history_TokenFilter(value) {
    (TokenFilter.$clinit(), TokenFilter.$f_LOGGER__org_dominokit_domino_api_shared_history_TokenFilter = value);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_TokenFilter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_TokenFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_TokenFilter;
  }
  
  /**
   * @public
   */
  static $clinit() {
    TokenFilter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.$LambdaAdaptor$impl');
    AnyFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.AnyFilter$impl');
    AnyFragmentFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.AnyFragmentFilter$impl');
    AnyPathFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.AnyPathFilter$impl');
    ContainsFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFilter$impl');
    ContainsFragmentFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.ContainsFragmentFilter$impl');
    EndsWithFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFilter$impl');
    EndsWithFragmentFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithFragmentFilter$impl');
    EndsWithPathFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.EndsWithPathFilter$impl');
    ExactFragmentFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.ExactFragmentFilter$impl');
    ExactMatchFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.ExactMatchFilter$impl');
    ExactPathFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.ExactPathFilter$impl');
    HasPathFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.HasPathFilter$impl');
    HasPathsFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.HasPathsFilter$impl');
    StartsWithFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFilter$impl');
    StartsWithFragmentFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithFragmentFilter$impl');
    StartsWithPathFilter = goog.module.get('org.dominokit.domino.api.shared.history.TokenFilter.StartsWithPathFilter$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    TokenFilter.$f_LOGGER__org_dominokit_domino_api_shared_history_TokenFilter = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(TokenFilter));
  }
  
  
};

$Util.$setClassMetadataForInterface(TokenFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter'));


/** @private {Logger} */
TokenFilter.$f_LOGGER__org_dominokit_domino_api_shared_history_TokenFilter;


TokenFilter.$markImplementor(/** @type {Function} */ (TokenFilter));


exports = TokenFilter; 
//# sourceMappingURL=TokenFilter.js.map