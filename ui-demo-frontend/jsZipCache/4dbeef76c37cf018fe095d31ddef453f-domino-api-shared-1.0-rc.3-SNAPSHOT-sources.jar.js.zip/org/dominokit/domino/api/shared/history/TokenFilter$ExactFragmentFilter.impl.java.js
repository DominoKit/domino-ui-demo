/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$ExactFragmentFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.ExactFragmentFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class ExactFragmentFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_matchingPart__org_dominokit_domino_api_shared_history_TokenFilter_ExactFragmentFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'ExactFragmentFilter(String)'.
   * @param {?string} matchingPart
   * @return {!ExactFragmentFilter}
   * @public
   */
  static $create__java_lang_String(matchingPart) {
    ExactFragmentFilter.$clinit();
    let $instance = new ExactFragmentFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_ExactFragmentFilter__java_lang_String(matchingPart);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ExactFragmentFilter(String)'.
   * @param {?string} matchingPart
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_ExactFragmentFilter__java_lang_String(matchingPart) {
    this.$ctor__java_lang_Object__();
    this.f_matchingPart__org_dominokit_domino_api_shared_history_TokenFilter_ExactFragmentFilter_ = matchingPart;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_equals__java_lang_String__java_lang_Object(token.m_fragment__(), this.f_matchingPart__org_dominokit_domino_api_shared_history_TokenFilter_ExactFragmentFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ExactFragmentFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ExactFragmentFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ExactFragmentFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ExactFragmentFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$ExactFragmentFilter'));


TokenFilter.$markImplementor(ExactFragmentFilter);


exports = ExactFragmentFilter; 
//# sourceMappingURL=TokenFilter$ExactFragmentFilter.js.map