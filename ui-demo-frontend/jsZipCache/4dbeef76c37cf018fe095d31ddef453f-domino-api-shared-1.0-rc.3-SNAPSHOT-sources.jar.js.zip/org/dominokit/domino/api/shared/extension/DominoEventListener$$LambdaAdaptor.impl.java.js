/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.DominoEventListener$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.DominoEventListener.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');


/**
 * @template C_E
 * @implements {DominoEventListener<C_E>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_E):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(C_E):void} */
    this.f_$$fn__org_dominokit_domino_api_shared_extension_DominoEventListener_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_shared_extension_DominoEventListener_$LambdaAdaptor__org_dominokit_domino_api_shared_extension_DominoEventListener_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(C_E):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_extension_DominoEventListener_$LambdaAdaptor__org_dominokit_domino_api_shared_extension_DominoEventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_shared_extension_DominoEventListener_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {C_E} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_api_shared_extension_DominoEventListener_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.DominoEventListener$$LambdaAdaptor'));


DominoEventListener.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DominoEventListener$$LambdaAdaptor.js.map