/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.DominoEventListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEventListener.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_E
 */
class DominoEventListener {
  /**
   * @abstract
   * @param {C_E} dominoEvent
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(dominoEvent) {
  }
  
  /**
   * @template C_E
   * @param {?function(C_E):void} fn
   * @return {DominoEventListener<C_E>}
   * @public
   */
  static $adapt(fn) {
    DominoEventListener.$clinit();
    return /**@type {!$LambdaAdaptor<DominoEvent>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_DominoEventListener = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_DominoEventListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_DominoEventListener;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoEventListener.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.extension.DominoEventListener.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DominoEventListener, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.DominoEventListener'));


DominoEventListener.$markImplementor(/** @type {Function} */ (DominoEventListener));


exports = DominoEventListener; 
//# sourceMappingURL=DominoEventListener.js.map