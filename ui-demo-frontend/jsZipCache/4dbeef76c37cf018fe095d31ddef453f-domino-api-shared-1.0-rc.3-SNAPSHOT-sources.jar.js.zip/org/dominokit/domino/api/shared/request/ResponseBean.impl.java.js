/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.request.ResponseBean.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.request.ResponseBean$impl');


const Serializable = goog.require('java.io.Serializable$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let VoidResponse = goog.forwardDeclare('org.dominokit.domino.api.shared.request.VoidResponse$impl');


/**
 * @interface
 * @extends {Serializable}
 */
class ResponseBean {
  /**
   * @return {VoidResponse}
   * @public
   */
  static get f_VOID_RESPONSE__org_dominokit_domino_api_shared_request_ResponseBean() {
    return (ResponseBean.$clinit(), ResponseBean.$f_VOID_RESPONSE__org_dominokit_domino_api_shared_request_ResponseBean);
  }
  
  /**
   * @param {VoidResponse} value
   * @return {void}
   * @public
   */
  static set f_VOID_RESPONSE__org_dominokit_domino_api_shared_request_ResponseBean(value) {
    (ResponseBean.$clinit(), ResponseBean.$f_VOID_RESPONSE__org_dominokit_domino_api_shared_request_ResponseBean = value);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Serializable.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_request_ResponseBean = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_request_ResponseBean;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_request_ResponseBean;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ResponseBean.$clinit = function() {};
    VoidResponse = goog.module.get('org.dominokit.domino.api.shared.request.VoidResponse$impl');
    ResponseBean.$f_VOID_RESPONSE__org_dominokit_domino_api_shared_request_ResponseBean = VoidResponse.$create__();
  }
  
  
};

$Util.$setClassMetadataForInterface(ResponseBean, $Util.$makeClassName('org.dominokit.domino.api.shared.request.ResponseBean'));


/** @private {VoidResponse} */
ResponseBean.$f_VOID_RESPONSE__org_dominokit_domino_api_shared_request_ResponseBean;


ResponseBean.$markImplementor(/** @type {Function} */ (ResponseBean));


exports = ResponseBean; 
//# sourceMappingURL=ResponseBean.js.map