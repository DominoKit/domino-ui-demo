/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$HasPathsFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.HasPathsFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class HasPathsFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Array<?string>} */
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_HasPathsFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'HasPathsFilter(String...)'.
   * @param {Array<?string>} path
   * @return {!HasPathsFilter}
   * @public
   */
  static $create__arrayOf_java_lang_String(path) {
    HasPathsFilter.$clinit();
    let $instance = new HasPathsFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_HasPathsFilter__arrayOf_java_lang_String(path);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HasPathsFilter(String...)'.
   * @param {Array<?string>} path
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_HasPathsFilter__arrayOf_java_lang_String(path) {
    this.$ctor__java_lang_Object__();
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_HasPathsFilter_ = path;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return token.m_paths__().containsAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_HasPathsFilter_)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HasPathsFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HasPathsFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasPathsFilter.$clinit = function() {};
    Arrays = goog.module.get('java.util.Arrays$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HasPathsFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$HasPathsFilter'));


TokenFilter.$markImplementor(HasPathsFilter);


exports = HasPathsFilter; 
//# sourceMappingURL=TokenFilter$HasPathsFilter.js.map