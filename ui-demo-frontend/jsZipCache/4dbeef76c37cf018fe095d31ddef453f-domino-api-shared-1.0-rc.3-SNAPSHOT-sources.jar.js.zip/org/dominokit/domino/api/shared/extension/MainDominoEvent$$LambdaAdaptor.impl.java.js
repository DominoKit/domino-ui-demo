/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.MainDominoEvent$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.MainDominoEvent.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MainDominoEvent = goog.require('org.dominokit.domino.api.shared.extension.MainDominoEvent$impl');

let MainEventContext = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainEventContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {MainDominoEvent}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():MainEventContext} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():MainEventContext} */
    this.f_$$fn__org_dominokit_domino_api_shared_extension_MainDominoEvent_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_api_shared_extension_MainDominoEvent_$LambdaAdaptor__org_dominokit_domino_api_shared_extension_MainDominoEvent_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():MainEventContext} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_extension_MainDominoEvent_$LambdaAdaptor__org_dominokit_domino_api_shared_extension_MainDominoEvent_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_api_shared_extension_MainDominoEvent_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {MainEventContext}
   * @public
   */
  m_context__() {
    let /** ?function():MainEventContext */ $function;
    return /**@type {MainEventContext} */ ($Casts.$to(($function = this.f_$$fn__org_dominokit_domino_api_shared_extension_MainDominoEvent_$LambdaAdaptor, $function()), MainEventContext));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    MainEventContext = goog.module.get('org.dominokit.domino.api.shared.extension.MainEventContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.MainDominoEvent$$LambdaAdaptor'));


MainDominoEvent.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=MainDominoEvent$$LambdaAdaptor.js.map