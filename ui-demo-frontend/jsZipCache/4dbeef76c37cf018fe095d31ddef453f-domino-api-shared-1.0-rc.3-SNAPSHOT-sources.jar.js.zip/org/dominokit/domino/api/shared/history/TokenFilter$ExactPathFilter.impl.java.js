/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$ExactPathFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.ExactPathFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class ExactPathFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_ExactPathFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'ExactPathFilter(String)'.
   * @param {?string} path
   * @return {!ExactPathFilter}
   * @public
   */
  static $create__java_lang_String(path) {
    ExactPathFilter.$clinit();
    let $instance = new ExactPathFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_ExactPathFilter__java_lang_String(path);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ExactPathFilter(String)'.
   * @param {?string} path
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_ExactPathFilter__java_lang_String(path) {
    this.$ctor__java_lang_Object__();
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_ExactPathFilter_ = path;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return j_l_String.m_equals__java_lang_String__java_lang_Object(token.m_path__(), this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_ExactPathFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ExactPathFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ExactPathFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ExactPathFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ExactPathFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$ExactPathFilter'));


TokenFilter.$markImplementor(ExactPathFilter);


exports = ExactPathFilter; 
//# sourceMappingURL=TokenFilter$ExactPathFilter.js.map