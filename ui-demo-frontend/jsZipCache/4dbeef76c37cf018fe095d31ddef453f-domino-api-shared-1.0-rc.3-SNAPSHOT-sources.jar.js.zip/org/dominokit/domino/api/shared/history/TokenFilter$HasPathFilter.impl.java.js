/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$HasPathFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.HasPathFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class HasPathFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_HasPathFilter_;
  }
  
  /**
   * Factory method corresponding to constructor 'HasPathFilter(String)'.
   * @param {?string} path
   * @return {!HasPathFilter}
   * @public
   */
  static $create__java_lang_String(path) {
    HasPathFilter.$clinit();
    let $instance = new HasPathFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_HasPathFilter__java_lang_String(path);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HasPathFilter(String)'.
   * @param {?string} path
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_HasPathFilter__java_lang_String(path) {
    this.$ctor__java_lang_Object__();
    this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_HasPathFilter_ = path;
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return token.m_paths__().contains(this.f_path__org_dominokit_domino_api_shared_history_TokenFilter_HasPathFilter_);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HasPathFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HasPathFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HasPathFilter.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HasPathFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$HasPathFilter'));


TokenFilter.$markImplementor(HasPathFilter);


exports = HasPathFilter; 
//# sourceMappingURL=TokenFilter$HasPathFilter.js.map