/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.CurrentStateHistory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.CurrentStateHistory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.shared.history.CurrentStateHistory.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CurrentStateHistory {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_fireCurrentStateHistory__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {CurrentStateHistory}
   * @public
   */
  static $adapt(fn) {
    CurrentStateHistory.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_CurrentStateHistory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_history_CurrentStateHistory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_history_CurrentStateHistory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CurrentStateHistory.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.shared.history.CurrentStateHistory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CurrentStateHistory, $Util.$makeClassName('org.dominokit.domino.api.shared.history.CurrentStateHistory'));


CurrentStateHistory.$markImplementor(/** @type {Function} */ (CurrentStateHistory));


exports = CurrentStateHistory; 
//# sourceMappingURL=CurrentStateHistory.js.map