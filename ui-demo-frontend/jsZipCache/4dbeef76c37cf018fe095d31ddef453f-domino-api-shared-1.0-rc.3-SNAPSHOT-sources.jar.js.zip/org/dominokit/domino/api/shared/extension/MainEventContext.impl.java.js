/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.MainEventContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.MainEventContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EventContext = goog.require('org.dominokit.domino.api.shared.extension.EventContext$impl');


/**
 * @interface
 * @extends {EventContext}
 */
class MainEventContext {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EventContext.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainEventContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_MainEventContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_MainEventContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    MainEventContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(MainEventContext, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.MainEventContext'));


MainEventContext.$markImplementor(/** @type {Function} */ (MainEventContext));


exports = MainEventContext; 
//# sourceMappingURL=MainEventContext.js.map