package org.dominokit.domino.api.shared.request;

public class VoidRequest implements RequestBean {
}
