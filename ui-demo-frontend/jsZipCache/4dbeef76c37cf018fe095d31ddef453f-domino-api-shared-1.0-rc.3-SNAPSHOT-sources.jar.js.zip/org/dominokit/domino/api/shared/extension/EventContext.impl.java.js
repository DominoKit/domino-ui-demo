/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.extension.EventContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.extension.EventContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class EventContext {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_EventContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_shared_extension_EventContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_shared_extension_EventContext;
  }
  
  /**
   * @public
   */
  static $clinit() {
    EventContext.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(EventContext, $Util.$makeClassName('org.dominokit.domino.api.shared.extension.EventContext'));


EventContext.$markImplementor(/** @type {Function} */ (EventContext));


exports = EventContext; 
//# sourceMappingURL=EventContext.js.map