/**
 * @fileoverview transpiled from org.dominokit.domino.api.shared.history.TokenFilter$AnyFragmentFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.shared.history.TokenFilter.AnyFragmentFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TokenFilter = goog.require('org.dominokit.domino.api.shared.history.TokenFilter$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let HistoryToken = goog.forwardDeclare('org.dominokit.domino.api.shared.history.HistoryToken$impl');


/**
 * @implements {TokenFilter}
  */
class AnyFragmentFilter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AnyFragmentFilter()'.
   * @return {!AnyFragmentFilter}
   * @public
   */
  static $create__() {
    AnyFragmentFilter.$clinit();
    let $instance = new AnyFragmentFilter();
    $instance.$ctor__org_dominokit_domino_api_shared_history_TokenFilter_AnyFragmentFilter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AnyFragmentFilter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_shared_history_TokenFilter_AnyFragmentFilter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {HistoryToken} token
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_api_shared_history_HistoryToken(token) {
    return Objects.m_nonNull__java_lang_Object(token.m_fragment__()) && !j_l_String.m_isEmpty__java_lang_String(token.m_fragment__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AnyFragmentFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AnyFragmentFilter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AnyFragmentFilter.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AnyFragmentFilter, $Util.$makeClassName('org.dominokit.domino.api.shared.history.TokenFilter$AnyFragmentFilter'));


TokenFilter.$markImplementor(AnyFragmentFilter);


exports = AnyFragmentFilter; 
//# sourceMappingURL=TokenFilter$AnyFragmentFilter.js.map