/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.TypedBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.TypedBuilder$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @template C_T, C_B
 */
class TypedBuilder {
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_get__() {
  }
  
  /**
   * @abstract
   * @return {C_B}
   * @public
   */
  m_that__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_TypedBuilder = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_builder_TypedBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_TypedBuilder;
  }
  
  /**
   * @public
   */
  static $clinit() {
    TypedBuilder.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(TypedBuilder, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.TypedBuilder'));


TypedBuilder.$markImplementor(/** @type {Function} */ (TypedBuilder));


exports = TypedBuilder; 
//# sourceMappingURL=TypedBuilder.js.map