/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.LazyElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.LazyElement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');


/**
 * @abstract
 * @implements {IsElement}
  */
class LazyElement extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_jboss_gwt_elemento_core_LazyElement_;
  }
  
  /**
   * Initialization from constructor 'LazyElement()'.
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_LazyElement__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    if ($Equality.$same(this.f_element__org_jboss_gwt_elemento_core_LazyElement_, null)) {
      this.f_element__org_jboss_gwt_elemento_core_LazyElement_ = this.m_createElement__();
    }
    return this.f_element__org_jboss_gwt_elemento_core_LazyElement_;
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_createElement__() {
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_initialized__() {
    return !$Equality.$same(this.f_element__org_jboss_gwt_elemento_core_LazyElement_, null);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LazyElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LazyElement);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LazyElement.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LazyElement, $Util.$makeClassName('org.jboss.gwt.elemento.core.LazyElement'));


IsElement.$markImplementor(LazyElement);


exports = LazyElement; 
//# sourceMappingURL=LazyElement.js.map