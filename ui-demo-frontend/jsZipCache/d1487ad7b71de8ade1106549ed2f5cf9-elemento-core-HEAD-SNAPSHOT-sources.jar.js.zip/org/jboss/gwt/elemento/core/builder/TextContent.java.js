/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.TextContent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.TextContent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TypedBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TypedBuilder');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TextContent = goog.require('org.jboss.gwt.elemento.core.builder.TextContent$impl');
exports = TextContent;
 