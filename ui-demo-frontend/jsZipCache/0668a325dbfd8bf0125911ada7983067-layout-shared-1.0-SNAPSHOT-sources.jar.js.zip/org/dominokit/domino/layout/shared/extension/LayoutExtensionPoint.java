package org.dominokit.domino.layout.shared.extension;

import org.dominokit.domino.api.shared.extension.ExtensionPoint;

public interface LayoutExtensionPoint extends ExtensionPoint<LayoutContext>{
}
