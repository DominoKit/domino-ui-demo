/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements$AsHTMLElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.Elements.AsHTMLElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AsHTMLElement = goog.require('org.jboss.gwt.elemento.core.Elements.AsHTMLElement$impl');
exports = AsHTMLElement;
 