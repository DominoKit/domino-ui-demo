/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements$JsArrayLikeIterator.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.Elements.JsArrayLikeIterator');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Iterator = goog.require('java.util.Iterator');
const _$Util = goog.require('nativebootstrap.Util');
const _NoSuchElementException = goog.require('java.util.NoSuchElementException');
const _Consumer = goog.require('java.util.function.Consumer');
const _$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var JsArrayLikeIterator = goog.require('org.jboss.gwt.elemento.core.Elements.JsArrayLikeIterator$impl');
exports = JsArrayLikeIterator;
 