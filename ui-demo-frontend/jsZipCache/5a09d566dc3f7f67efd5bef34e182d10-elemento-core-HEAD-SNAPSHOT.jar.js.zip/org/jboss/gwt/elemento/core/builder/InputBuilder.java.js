/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.InputBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.InputBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ElementBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementBuilder');
const _$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var InputBuilder = goog.require('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
exports = InputBuilder;
 