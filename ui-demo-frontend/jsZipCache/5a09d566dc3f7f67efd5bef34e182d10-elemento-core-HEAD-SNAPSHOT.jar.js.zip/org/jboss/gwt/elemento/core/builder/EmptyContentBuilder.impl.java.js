/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.EmptyContentBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ElementBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementBuilder$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


/**
 * @template C_E
 * @extends {ElementBuilder<C_E, EmptyContentBuilder<C_E>>}
  */
class EmptyContentBuilder extends ElementBuilder {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'EmptyContentBuilder(HTMLElement)'.
   * @template C_E
   * @param {C_E} element
   * @return {!EmptyContentBuilder<C_E>}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(element) {
    EmptyContentBuilder.$clinit();
    let $instance = new EmptyContentBuilder();
    $instance.$ctor__org_jboss_gwt_elemento_core_builder_EmptyContentBuilder__elemental2_dom_HTMLElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'EmptyContentBuilder(HTMLElement)'.
   * @param {C_E} element
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_builder_EmptyContentBuilder__elemental2_dom_HTMLElement(element) {
    this.$ctor__org_jboss_gwt_elemento_core_builder_ElementBuilder__elemental2_dom_HTMLElement(element);
  }
  
  /**
   * @override
   * @return {EmptyContentBuilder<C_E>}
   * @public
   */
  m_that__() {
    return this;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EmptyContentBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EmptyContentBuilder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    EmptyContentBuilder.$clinit = function() {};
    ElementBuilder.$clinit();
  }
  
  
};

$Util.$setClassMetadata(EmptyContentBuilder, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder'));




exports = EmptyContentBuilder; 
//# sourceMappingURL=EmptyContentBuilder.js.map