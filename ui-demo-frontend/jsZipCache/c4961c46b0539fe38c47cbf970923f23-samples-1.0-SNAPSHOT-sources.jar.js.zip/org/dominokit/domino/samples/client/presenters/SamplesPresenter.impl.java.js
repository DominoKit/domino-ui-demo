/**
 * @fileoverview transpiled from org.dominokit.domino.samples.client.presenters.SamplesPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.samples.client.presenters.SamplesPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ComponentCaseContext = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.samples.client.presenters.SamplesPresenter.$1$impl');
let SamplesView = goog.forwardDeclare('org.dominokit.domino.samples.client.views.SamplesView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<SamplesView>}
  */
class SamplesPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SamplesPresenter()'.
   * @return {!SamplesPresenter}
   * @public
   */
  static $create__() {
    SamplesPresenter.$clinit();
    let $instance = new SamplesPresenter();
    $instance.$ctor__org_dominokit_domino_samples_client_presenters_SamplesPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SamplesPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_samples_client_presenters_SamplesPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {ComponentCaseContext} context
   * @return {void}
   * @public
   */
  m_listenToComponentCaseEvent__org_dominokit_domino_componentcase_shared_extension_ComponentCaseContext(context) {
    context.m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_samples_client_presenters_SamplesPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_samples_client_presenters_SamplesPresenter_() {
    return (SamplesPresenter.$clinit(), SamplesPresenter.$f_LOGGER__org_dominokit_domino_samples_client_presenters_SamplesPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_samples_client_presenters_SamplesPresenter_(value) {
    (SamplesPresenter.$clinit(), SamplesPresenter.$f_LOGGER__org_dominokit_domino_samples_client_presenters_SamplesPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SamplesPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SamplesPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SamplesPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.samples.client.presenters.SamplesPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    SamplesPresenter.$f_LOGGER__org_dominokit_domino_samples_client_presenters_SamplesPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SamplesPresenter));
  }
  
  
};

$Util.$setClassMetadata(SamplesPresenter, $Util.$makeClassName('org.dominokit.domino.samples.client.presenters.SamplesPresenter'));


/** @private {Logger} */
SamplesPresenter.$f_LOGGER__org_dominokit_domino_samples_client_presenters_SamplesPresenter_;




exports = SamplesPresenter; 
//# sourceMappingURL=SamplesPresenter.js.map