/**
 * @fileoverview transpiled from org.dominokit.domino.samples.client.views.ui.SamplesViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.samples.client.views.ui.SamplesViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const SamplesView = goog.require('org.dominokit.domino.samples.client.views.SamplesView$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {SamplesView}
  */
class SamplesViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'SamplesViewImpl()'.
   * @return {!SamplesViewImpl}
   * @public
   */
  static $create__() {
    SamplesViewImpl.$clinit();
    let $instance = new SamplesViewImpl();
    $instance.$ctor__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SamplesViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("SAMPLES", " A set of apps and samples built with domino-ui").m_asElement__());
    this.f_element__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style) =>{
      style.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style$1$) =>{
      style$1$.m_add__java_lang_String("classy-card");
    }))), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/samples/dominodo.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("DominoDo"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Simple todo app introducing good number of domino-ui components")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Author"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("DominoKit Team"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://dominokit.github.io/dominodo/index.html"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Visit"), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/DominoKit/dominodo"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Source code"), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String))))), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Column> */ style$2$) =>{
      style$2$.m_add__java_lang_String(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    }))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Card} */ ($Casts.$to(Card.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style$3$) =>{
      style$3$.m_add__java_lang_String("classy-card");
    }))), Card)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("./images/samples/nalu-initializer.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String)))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Nalu Initializer"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Project initializer for Nalu MVP framework")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Author"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/FrankHossfeld"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Frank Hossfeld"), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "http://www.mvp4g.org/gwt-boot-starter-nalu/GwtBootStarterNalu.html#setUp"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Visit"), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/NaluKit/gwt-boot-starter-nalu"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Source code"), IsElement))), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["bg-classy"], j_l_String))))), Column))), Row__12)).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl() {
    this.f_element__org_dominokit_domino_samples_client_views_ui_SamplesViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SamplesViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SamplesViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SamplesViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SamplesViewImpl, $Util.$makeClassName('org.dominokit.domino.samples.client.views.ui.SamplesViewImpl'));


SamplesView.$markImplementor(SamplesViewImpl);


exports = SamplesViewImpl; 
//# sourceMappingURL=SamplesViewImpl.js.map