/**
 * @fileoverview transpiled from org.dominokit.domino.samples.client.presenters.SamplesPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.samples.client.presenters.SamplesPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let SamplesPresenter = goog.forwardDeclare('org.dominokit.domino.samples.client.presenters.SamplesPresenter$impl');


/**
 * @extends {PresenterCommand<SamplesPresenter>}
  */
class SamplesPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SamplesPresenterCommand()'.
   * @return {!SamplesPresenterCommand}
   * @public
   */
  static $create__() {
    SamplesPresenterCommand.$clinit();
    let $instance = new SamplesPresenterCommand();
    $instance.$ctor__org_dominokit_domino_samples_client_presenters_SamplesPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SamplesPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_samples_client_presenters_SamplesPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SamplesPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SamplesPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SamplesPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(SamplesPresenterCommand, $Util.$makeClassName('org.dominokit.domino.samples.client.presenters.SamplesPresenterCommand'));




exports = SamplesPresenterCommand; 
//# sourceMappingURL=SamplesPresenterCommand.js.map