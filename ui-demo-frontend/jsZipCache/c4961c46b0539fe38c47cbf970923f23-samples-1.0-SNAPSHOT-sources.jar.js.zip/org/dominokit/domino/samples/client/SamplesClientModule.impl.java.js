/**
 * @fileoverview transpiled from org.dominokit.domino.samples.client.SamplesClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.samples.client.SamplesClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class SamplesClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'SamplesClientModule()'.
   * @return {!SamplesClientModule}
   * @public
   */
  static $create__() {
    SamplesClientModule.$clinit();
    let $instance = new SamplesClientModule();
    $instance.$ctor__org_dominokit_domino_samples_client_SamplesClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SamplesClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_samples_client_SamplesClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    SamplesClientModule.$f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_.m_info__java_lang_String("Initializing Samples frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_() {
    return (SamplesClientModule.$clinit(), SamplesClientModule.$f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_(value) {
    (SamplesClientModule.$clinit(), SamplesClientModule.$f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SamplesClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SamplesClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    SamplesClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    SamplesClientModule.$f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(SamplesClientModule));
  }
  
  
};

$Util.$setClassMetadata(SamplesClientModule, $Util.$makeClassName('org.dominokit.domino.samples.client.SamplesClientModule'));


/** @private {Logger} */
SamplesClientModule.$f_LOGGER__org_dominokit_domino_samples_client_SamplesClientModule_;




exports = SamplesClientModule; 
//# sourceMappingURL=SamplesClientModule.js.map