/**
 * @fileoverview transpiled from org.dominokit.domino.samples.client.presenters.SamplesPresenter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.samples.client.presenters.SamplesPresenter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter');
const _Class = goog.require('java.lang.Class');
const _ComponentCaseContext = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentCaseContext');
const _$1 = goog.require('org.dominokit.domino.samples.client.presenters.SamplesPresenter.$1');
const _SamplesView = goog.require('org.dominokit.domino.samples.client.views.SamplesView');
const _Logger = goog.require('org.slf4j.Logger');
const _LoggerFactory = goog.require('org.slf4j.LoggerFactory');


// Re-exports the implementation.
var SamplesPresenter = goog.require('org.dominokit.domino.samples.client.presenters.SamplesPresenter$impl');
exports = SamplesPresenter;
 