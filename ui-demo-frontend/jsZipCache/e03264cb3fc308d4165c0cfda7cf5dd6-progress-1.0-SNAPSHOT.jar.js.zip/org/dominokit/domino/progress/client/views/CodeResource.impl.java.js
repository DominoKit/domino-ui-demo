/**
 * @fileoverview transpiled from org.dominokit.domino.progress.client.views.CodeResource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.progress.client.views.CodeResource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class CodeResource extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'CodeResource()'.
   * @return {!CodeResource}
   * @public
   */
  static $create__() {
    CodeResource.$clinit();
    let $instance = new CodeResource();
    $instance.$ctor__org_dominokit_domino_progress_client_views_CodeResource__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'CodeResource()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_progress_client_views_CodeResource__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_basicSample__() {
    CodeResource.$clinit();
    return "movingBar = ProgressBar.create(1000);\n" + "//we are doing this since we want to move the progress for the demo,\n" + "// in real use cases progress bar value increases by some data feedback.\n" + "movingBar.asElement().style.setProperty(\"transition\", \"width 500ms linear\", \"important\");\n" + "\n" + "element.appendChild(Card.create(\"BASIC EXAMPLES\")\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .setValue(90))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .setValue(60))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .textExpression(\"{value} out of {maxValue} completed\")\n" + "                        .setValue(75))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .textExpression(\"{value} out of {maxValue} completed\")\n" + "                        .setValue(40))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(movingBar)\n" + "                .asElement())\n" + "        .asElement());\n" + "\n" + "animationFrameCallback = p0 -> {\n" + "    if (movingBar.getValue() >= movingBar.getMaxValue()) {\n" + "        movingBar.textExpression(\"Done\");\n" + "    } else\n" + "        movingBar.setValue(movingBar.getValue() + 1);\n" + "\n" + "    animationFrame = DomGlobal.requestAnimationFrame(animationFrameCallback);\n" + "};";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_contextualAlternatives__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"CONTEXTUAL ALTERNATIVES\", \"Progress bars use some of the same button and alert classes for consistent styles.\")\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .success()\n" + "                        .setValue(80))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .warning()\n" + "                        .setValue(60))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .info()\n" + "                        .setValue(70))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .danger()\n" + "                        .setValue(30))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_stripedSample__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"STRIPED\", \"Uses a gradient to create a striped effect.\")\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .striped()\n" + "                        .success()\n" + "                        .setValue(80))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .striped()\n" + "                        .warning()\n" + "                        .setValue(60))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .striped()\n" + "                        .info()\n" + "                        .setValue(70))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .striped()\n" + "                        .danger()\n" + "                        .setValue(30))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_animatedSample__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"ANIMATED\", \"Animating the bar will add stripes by default.\")\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .animate()\n" + "                        .success()\n" + "                        .setValue(80))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .animate()\n" + "                        .warning()\n" + "                        .setValue(60))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .animate()\n" + "                        .info()\n" + "                        .setValue(70))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .animate()\n" + "                        .danger()\n" + "                        .setValue(30))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_stackedSample__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"STACKED\", \"You can stack more than one progress bar in a progress element.\")\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .animate()\n" + "                        .success()\n" + "                        .setValue(40))\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .warning()\n" + "                        .setValue(30))\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .striped()\n" + "                        .danger()\n" + "                        .setValue(20))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @return {?string}
   * @public
   */
  static m_materialDesignColors__() {
    CodeResource.$clinit();
    return "element.appendChild(Card.create(\"WITH MATERIAL DESIGN COLORS\", \"You use material design colors to style the progress bar.\")\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .setBackground(Background.PINK)\n" + "                        .striped()\n" + "                        .setValue(90))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .showText()\n" + "                        .setBackground(Background.PURPLE)\n" + "                        .striped()\n" + "                        .setValue(60))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .setBackground(Background.TEAL)\n" + "                        .striped()\n" + "                        .setValue(75))\n" + "                .asElement())\n" + "        .appendContent(Progress.create()\n" + "                .addBar(ProgressBar.create(100)\n" + "                        .setBackground(Background.BROWN)\n" + "                        .striped()\n" + "                        .setValue(40))\n" + "                .asElement())\n" + "        .asElement());";
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CodeResource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CodeResource);
  }
  
  /**
   * @public
   */
  static $clinit() {
    CodeResource.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(CodeResource, $Util.$makeClassName('org.dominokit.domino.progress.client.views.CodeResource'));




exports = CodeResource; 
//# sourceMappingURL=CodeResource.js.map