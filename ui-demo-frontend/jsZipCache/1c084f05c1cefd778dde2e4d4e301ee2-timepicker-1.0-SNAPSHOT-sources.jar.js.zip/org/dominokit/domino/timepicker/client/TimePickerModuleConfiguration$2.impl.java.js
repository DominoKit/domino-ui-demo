/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');

let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let TimePickerModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration$impl');
let TimePickerViewImpl = goog.forwardDeclare('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl$impl');


class $2 extends LazyViewLoader {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {TimePickerModuleConfiguration} */
    this.f_$outer_this__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new LazyViewLoader(TimePickerModuleConfiguration, String)'.
   * @param {TimePickerModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration__java_lang_String($outer_this, $_0) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration_2__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new LazyViewLoader(TimePickerModuleConfiguration, String)'.
   * @param {TimePickerModuleConfiguration} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration_2__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_timepicker_client_TimePickerModuleConfiguration_2 = $outer_this;
    this.$ctor__org_dominokit_domino_api_client_mvp_view_LazyViewLoader__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {View}
   * @public
   */
  m_make__() {
    return TimePickerViewImpl.$create__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    TimePickerViewImpl = goog.module.get('org.dominokit.domino.timepicker.client.views.ui.TimePickerViewImpl$impl');
    LazyViewLoader.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.timepicker.client.TimePickerModuleConfiguration$2'));




exports = $2; 
//# sourceMappingURL=TimePickerModuleConfiguration$2.js.map