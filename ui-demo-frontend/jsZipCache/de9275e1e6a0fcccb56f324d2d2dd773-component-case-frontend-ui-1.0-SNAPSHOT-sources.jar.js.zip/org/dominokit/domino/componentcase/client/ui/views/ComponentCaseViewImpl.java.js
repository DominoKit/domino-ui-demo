/**
 * @fileoverview transpiled from org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentCaseView = goog.require('org.dominokit.domino.componentcase.client.views.ComponentCaseView');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _Js = goog.require('jsinterop.base.Js');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ComponentCaseViewImpl = goog.require('org.dominokit.domino.componentcase.client.ui.views.ComponentCaseViewImpl$impl');
exports = ComponentCaseViewImpl;
 