/**
 * @fileoverview transpiled from org.dominokit.domino.applayout.client.AppLayoutClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.applayout.client.AppLayoutClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class AppLayoutClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AppLayoutClientModule()'.
   * @return {!AppLayoutClientModule}
   * @public
   */
  static $create__() {
    AppLayoutClientModule.$clinit();
    let $instance = new AppLayoutClientModule();
    $instance.$ctor__org_dominokit_domino_applayout_client_AppLayoutClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AppLayoutClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_applayout_client_AppLayoutClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    AppLayoutClientModule.$f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_.m_info__java_lang_String("Initializing LayoutSample frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_() {
    return (AppLayoutClientModule.$clinit(), AppLayoutClientModule.$f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_(value) {
    (AppLayoutClientModule.$clinit(), AppLayoutClientModule.$f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AppLayoutClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AppLayoutClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AppLayoutClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    AppLayoutClientModule.$f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AppLayoutClientModule));
  }
  
  
};

$Util.$setClassMetadata(AppLayoutClientModule, $Util.$makeClassName('org.dominokit.domino.applayout.client.AppLayoutClientModule'));


/** @private {Logger} */
AppLayoutClientModule.$f_LOGGER__org_dominokit_domino_applayout_client_AppLayoutClientModule_;




exports = AppLayoutClientModule; 
//# sourceMappingURL=AppLayoutClientModule.js.map