/**
 * @fileoverview transpiled from org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter.$1$impl');
let AppLayoutView = goog.forwardDeclare('org.dominokit.domino.applayout.client.views.AppLayoutView$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<AppLayoutView>}
  */
class AppLayoutPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AppLayoutPresenter()'.
   * @return {!AppLayoutPresenter}
   * @public
   */
  static $create__() {
    AppLayoutPresenter.$clinit();
    let $instance = new AppLayoutPresenter();
    $instance.$ctor__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AppLayoutPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {LayoutsEventContext} context
   * @return {void}
   * @public
   */
  m_listenToLayoutsEvent__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter_() {
    return (AppLayoutPresenter.$clinit(), AppLayoutPresenter.$f_LOGGER__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter_(value) {
    (AppLayoutPresenter.$clinit(), AppLayoutPresenter.$f_LOGGER__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AppLayoutPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AppLayoutPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AppLayoutPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    AppLayoutPresenter.$f_LOGGER__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AppLayoutPresenter));
  }
  
  
};

$Util.$setClassMetadata(AppLayoutPresenter, $Util.$makeClassName('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter'));


/** @private {Logger} */
AppLayoutPresenter.$f_LOGGER__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenter_;




exports = AppLayoutPresenter; 
//# sourceMappingURL=AppLayoutPresenter.js.map