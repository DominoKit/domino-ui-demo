/**
 * @fileoverview transpiled from org.dominokit.domino.applayout.client.presenters.AppLayoutPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let AppLayoutPresenter = goog.forwardDeclare('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter$impl');


/**
 * @extends {PresenterCommand<AppLayoutPresenter>}
  */
class AppLayoutPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AppLayoutPresenterCommand()'.
   * @return {!AppLayoutPresenterCommand}
   * @public
   */
  static $create__() {
    AppLayoutPresenterCommand.$clinit();
    let $instance = new AppLayoutPresenterCommand();
    $instance.$ctor__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AppLayoutPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_applayout_client_presenters_AppLayoutPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AppLayoutPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AppLayoutPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AppLayoutPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AppLayoutPresenterCommand, $Util.$makeClassName('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenterCommand'));




exports = AppLayoutPresenterCommand; 
//# sourceMappingURL=AppLayoutPresenterCommand.js.map