/**
 * @fileoverview transpiled from org.dominokit.domino.applayout.client.views.ui.AppLayoutViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.applayout.client.views.ui.AppLayoutViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AppLayoutView = goog.require('org.dominokit.domino.applayout.client.views.AppLayoutView$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Code = goog.forwardDeclare('org.dominokit.domino.ui.code.Code$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Thumbnail = goog.forwardDeclare('org.dominokit.domino.ui.thumbnails.Thumbnail$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {AppLayoutView}
  */
class AppLayoutViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'AppLayoutViewImpl()'.
   * @return {!AppLayoutViewImpl}
   * @public
   */
  static $create__() {
    AppLayoutViewImpl.$clinit();
    let $instance = new AppLayoutViewImpl();
    $instance.$ctor__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AppLayoutViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.m_initAppLayoutSample___$p_org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initAppLayoutSample___$p_org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl() {
    this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class("appLayout", this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("LAYOUT", "Default domino-ui layout has, Navigation bar - 1,2,3 -, left panel - 4 -, center panel - 5 -, hidden footer - 6 - and hidden right panel - 7 -").m_asElement__());
    this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_.appendChild(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__elemental2_dom_Node(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("static/images/layout/layout-1.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_asElement__()))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span6__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Card.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__elemental2_dom_Node(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String("static/images/layout/layout-2.png").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))), EmptyContentBuilder)).m_asElement__()))), Column))), Row__12)).m_asElement__());
    this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_.appendChild(Card.m_create__java_lang_String("USAGE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Basic"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Add default layout to the document body and pass the app title"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("Layout.create(\"App title\").show();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will add a layout with a navigation bar, left panel, left panel toggle, and a center panel using the default Indigo color."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Changing the default theme"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("Layout.create(\"App title\").show(ColorScheme.PINK);")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will add the layout with pink theme."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Adding elements to navigation bar right side"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.getTopBar().appendChild(li().add(a().add(Icons.ALL.style())).asElement());")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will add an icon to the right of the navigation bar."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Left panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("By default the left panel is closed and the navigation bar has a toggle button - 2 - to open/close it."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("You can show/hide the left panel programmatically"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.showLeftPanel();\n" + "layout.hideLeftPanel();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("By default left appear over the content and when open an overlay appears to block the center contents."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Fix the left panel position"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.fixLeftPanelPosition();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Fixing the left panel position will make it always visible, hide the navigation bar toggle button, push and narrow the center content and wont block the center content with an overlay."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Disable left panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.disableLeftPanel();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Disabling the left panel will completely hide it and will also hide the navigation bar toggle button."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("UnFix the left panel position"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.unfixLeftPanelPosition();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will revert the left panel to its default behavior."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Use the media queries to fix/unfix the left panel for different devices."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Add content to the left panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.getLeftPanel()\n" + "                .appendChild(Tree.create(\"Menu\")\n" + "                        .addTreeItem(TreeItem.create(\"Item1\", Icons.ALL.folder()))\n" + "                        .addTreeItem(TreeItem.create(\"Item 2\", Icons.ALL.description()))\n" + "                        .asElement());")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will append a tree to the left panel, you can append any element of any kind."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Center panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Add content to the center panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.getContentPanel()\n" + "                .appendChild(BlockHeader.create(\"Title\", \"Some description\")\n" + "                        .asElement());")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This wil add a block header to the center panel."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Clear the center panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("ElementUtil.clear(layout.getContentPanel());")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will remove all added content from the center panel."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Right panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Right panel is hidden by default and there is no button to show/hide it, but can be controlled programmatically"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Show/Hide right panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.showRightPanel();\n" + "        layout.hideRightPanel();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Showing the right panel will automatically hide the left panel unless it is fixed."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Showing the left panel will automatically hide the right panel unless the left panel is fixed."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Right panel position can not be fixed."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Show Right panel will always cover the center content and block it with an overlay."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Adding content the right panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.getRightPanel()\n" + "                .appendChild(BlockHeader.create(\"Settings\", \"System configurations\")\n" + "                        .asElement());")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Right panel allows adding any element of any kind."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Clear the right panel"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("ElementUtil.clear(layout.getRightPanel());")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("This will remove all added content from the right panel."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(4).m_textContent__java_lang_String("Footer"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Footer is hidden by default."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Show/Hide footer"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.showFooter();\n" + "        layout.hideFooter();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("by default adding content to the center panel will push the footer down."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("when there is little content in the center panel the footer will stick to the bottom of the window."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Fix the footer position"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.fixFooter();")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("Fixing the footer will make it always visible at the bottom of the window and the content of the center panel will scroll beyond it"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_br__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Adding content to the footer"), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Code.m_block__java_lang_String("layout.getFooter()\n" + "                .appendChild(p().textContent(\"\u00A9 2018 Copyright DominoKit\"));")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(6).m_textContent__java_lang_String("The footer allows adding any element of any kind"), IsElement))).m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl() {
    this.f_element__org_dominokit_domino_applayout_client_views_ui_AppLayoutViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AppLayoutViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AppLayoutViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AppLayoutViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Code = goog.module.get('org.dominokit.domino.ui.code.Code$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Thumbnail = goog.module.get('org.dominokit.domino.ui.thumbnails.Thumbnail$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AppLayoutViewImpl, $Util.$makeClassName('org.dominokit.domino.applayout.client.views.ui.AppLayoutViewImpl'));


AppLayoutView.$markImplementor(AppLayoutViewImpl);


exports = AppLayoutViewImpl; 
//# sourceMappingURL=AppLayoutViewImpl.js.map