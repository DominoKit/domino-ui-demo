package org.dominokit.domino.applayout.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.applayout.client.listeners.AppLayoutPresenterListenerForLayoutsEvent;
import org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter;
import org.dominokit.domino.applayout.client.presenters.AppLayoutPresenterCommand;
import org.dominokit.domino.applayout.client.views.ui.AppLayoutViewImpl;
import org.dominokit.domino.layouts.shared.extension.LayoutsEvent;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class AppLayoutModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(AppLayoutPresenter.class.getCanonicalName(), AppLayoutPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new AppLayoutPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(AppLayoutPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new AppLayoutViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(AppLayoutPresenterCommand.class.getCanonicalName(), AppLayoutPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(LayoutsEvent.class, new AppLayoutPresenterListenerForLayoutsEvent());
  }
}
