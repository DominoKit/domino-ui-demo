/**
 * @fileoverview transpiled from org.dominokit.domino.applayout.client.listeners.AppLayoutPresenterListenerForLayoutsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.applayout.client.listeners.AppLayoutPresenterListenerForLayoutsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _AppLayoutPresenter = goog.require('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenter');
const _AppLayoutPresenterCommand = goog.require('org.dominokit.domino.applayout.client.presenters.AppLayoutPresenterCommand');
const _LayoutsEvent = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent');
const _LayoutsEventContext = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AppLayoutPresenterListenerForLayoutsEvent = goog.require('org.dominokit.domino.applayout.client.listeners.AppLayoutPresenterListenerForLayoutsEvent$impl');
exports = AppLayoutPresenterListenerForLayoutsEvent;
 