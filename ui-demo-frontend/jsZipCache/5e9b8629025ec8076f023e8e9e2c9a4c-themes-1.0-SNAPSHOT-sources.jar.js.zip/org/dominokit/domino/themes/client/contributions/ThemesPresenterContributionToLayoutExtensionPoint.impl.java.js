/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Contribution = goog.require('org.dominokit.domino.api.shared.extension.Contribution$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let LayoutExtensionPoint = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
let ThemesPresenter = goog.forwardDeclare('org.dominokit.domino.themes.client.presenters.ThemesPresenter$impl');
let ThemesPresenterCommand = goog.forwardDeclare('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Contribution<LayoutExtensionPoint>}
  */
class ThemesPresenterContributionToLayoutExtensionPoint extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThemesPresenterContributionToLayoutExtensionPoint()'.
   * @return {!ThemesPresenterContributionToLayoutExtensionPoint}
   * @public
   */
  static $create__() {
    ThemesPresenterContributionToLayoutExtensionPoint.$clinit();
    let $instance = new ThemesPresenterContributionToLayoutExtensionPoint();
    $instance.$ctor__org_dominokit_domino_themes_client_contributions_ThemesPresenterContributionToLayoutExtensionPoint__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThemesPresenterContributionToLayoutExtensionPoint()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_themes_client_contributions_ThemesPresenterContributionToLayoutExtensionPoint__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(extensionPoint) {
    ThemesPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** ThemesPresenter */ presenter) =>{
      presenter.m_contributeToLayoutModule__org_dominokit_domino_layout_shared_extension_LayoutContext(/**@type {LayoutContext} */ ($Casts.$to(extensionPoint.m_context__(), LayoutContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {ExtensionPoint} arg0
   * @return {void}
   * @public
   */
  m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(arg0) {
    this.m_contribute__org_dominokit_domino_layout_shared_extension_LayoutExtensionPoint(/**@type {LayoutExtensionPoint} */ ($Casts.$to(arg0, LayoutExtensionPoint)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThemesPresenterContributionToLayoutExtensionPoint;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThemesPresenterContributionToLayoutExtensionPoint);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThemesPresenterContributionToLayoutExtensionPoint.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    LayoutContext = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
    LayoutExtensionPoint = goog.module.get('org.dominokit.domino.layout.shared.extension.LayoutExtensionPoint$impl');
    ThemesPresenterCommand = goog.module.get('org.dominokit.domino.themes.client.presenters.ThemesPresenterCommand$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThemesPresenterContributionToLayoutExtensionPoint, $Util.$makeClassName('org.dominokit.domino.themes.client.contributions.ThemesPresenterContributionToLayoutExtensionPoint'));


Contribution.$markImplementor(ThemesPresenterContributionToLayoutExtensionPoint);


exports = ThemesPresenterContributionToLayoutExtensionPoint; 
//# sourceMappingURL=ThemesPresenterContributionToLayoutExtensionPoint.js.map