/**
 * @fileoverview transpiled from org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ThemesPanel = goog.require('org.dominokit.domino.themes.client.views.ui.ThemesPanel');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _TemplateUtil = goog.require('org.jboss.gwt.elemento.template.TemplateUtil');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Templated__ThemesPanel = goog.require('org.dominokit.domino.themes.client.views.ui.Templated_ThemesPanel$impl');
exports = Templated__ThemesPanel;
 