/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const DialogsView = goog.require('org.dominokit.domino.dialogs.client.views.DialogsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.dialogs.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.$LambdaAdaptor$1$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let MessageDialog = goog.forwardDeclare('org.dominokit.domino.ui.dialogs.MessageDialog$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let SimpleListGroup = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListGroup$impl');
let SimpleListItem = goog.forwardDeclare('org.dominokit.domino.ui.lists.SimpleListItem$impl');
let CloseHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
let OpenHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {DialogsView}
  */
class DialogsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'DialogsViewImpl()'.
   * @return {!DialogsViewImpl}
   * @public
   */
  static $create__() {
    DialogsViewImpl.$clinit();
    let $instance = new DialogsViewImpl();
    $instance.$ctor__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DialogsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("DIALOGS").m_asElement__());
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_six__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_six__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    let basicMessage = MessageDialog.m_createMessage__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Here's a message!", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    })));
    let headerAndMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Message header", "Here's a message body!", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    })));
    let successMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Success Operation", "Well done! You successfully read this important alert message.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_success__();
    let errorMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Failed operation", "Oh snap! Change a few things up and try submitting again.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_error__();
    let customColors = /**@type {MessageDialog} */ ($Casts.$to(MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Failed operation", "Oh snap! Change a few things up and try submitting again.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_error__().m_setModalColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), MessageDialog)).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color);
    let warningMessage = MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Warning", "Warning! Better check yourself, you're not looking too good.", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_warning__();
    let heart = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_favorite__().m_asElement__();
    heart.classList.add(Styles.f_font_72__org_dominokit_domino_ui_style_Styles, Styles.f_m_b_15__org_dominokit_domino_ui_style_Styles, Color.f_RED__org_dominokit_domino_ui_style_Color.m_getStyle__());
    let customHeaderContent = /**@type {MessageDialog} */ ($Casts.$to(MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Custom header", "You can customize the header content", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_onOpen__org_dominokit_domino_ui_modals_IsModalDialog_OpenHandler(OpenHandler.$adapt((() =>{
      Animation.m_create__elemental2_dom_HTMLElement(heart).m_duration__int(400).m_infinite__().m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_PULSE__org_dominokit_domino_ui_animations_Transition).m_animate__();
    }))), MessageDialog)).m_appendHeaderContent__elemental2_dom_Node(heart);
    let listGroup = SimpleListGroup.m_create__().m_appendItem__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Cras justo odio").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("14 new").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_asElement__())).m_appendItem__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Dapibus ac facilisis in").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("99 unread").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_asElement__())).m_appendItem__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Morbi leo risus").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("99+").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_asElement__())).m_appendItem__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Porta ac consectetur ac").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("21").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_asElement__())).m_appendItem__org_dominokit_domino_ui_lists_SimpleListItem(SimpleListItem.m_create__java_lang_String("Vestibulum at eros").m_appendContent__elemental2_dom_Node(Badge.m_create__java_lang_String("Pending").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_asElement__())).m_asElement__();
    listGroup.style.setProperty("text-align", "left");
    let customContent = /**@type {MessageDialog} */ ($Casts.$to(MessageDialog.m_createMessage__java_lang_String__java_lang_String__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler("Custom content", "You can customize the dialog content", CloseHandler.$adapt((() =>{
      Notification.m_create__java_lang_String("Dialog closed").m_show__();
    }))).m_appendContent__elemental2_dom_Node(listGroup), MessageDialog));
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(Card.m_create__java_lang_String("EXAMPLES").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(basicMessage.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("A basic message").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(basicMessage))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(headerAndMessage.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Message with header").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(headerAndMessage))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(successMessage.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Success message").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(successMessage))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(errorMessage.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Error message").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(errorMessage))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(warningMessage.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Warning message").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(warningMessage))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(customColors.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Custom colors").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(customColors))).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(customHeaderContent.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Custom header content").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(customHeaderContent))).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(customContent.m_asElement__()).m_addElement__elemental2_dom_Node(Paragraph.m_create__java_lang_String("Custom content").m_asElement__()).m_addElement__elemental2_dom_Node(this.m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(customContent))).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_dialogs__()).m_asElement__());
  }
  
  /**
   * @param {MessageDialog} dialog
   * @return {HTMLElement}
   * @public
   */
  m_createDemoButton__org_dominokit_domino_ui_dialogs_MessageDialog_$p_org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl(dialog) {
    return Button.m_createPrimary__java_lang_String("CLICK ME").m_setStyleProperty__java_lang_String__java_lang_String("min-width", "120px").m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
      dialog.m_open__();
    }))).m_asElement__();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl() {
    this.f_element__org_dominokit_domino_dialogs_client_views_ui_DialogsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DialogsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DialogsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DialogsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.dialogs.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl.$LambdaAdaptor$1$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Animation = goog.module.get('org.dominokit.domino.ui.animations.Animation$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    MessageDialog = goog.module.get('org.dominokit.domino.ui.dialogs.MessageDialog$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    SimpleListGroup = goog.module.get('org.dominokit.domino.ui.lists.SimpleListGroup$impl');
    SimpleListItem = goog.module.get('org.dominokit.domino.ui.lists.SimpleListItem$impl');
    CloseHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
    OpenHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.OpenHandler$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DialogsViewImpl, $Util.$makeClassName('org.dominokit.domino.dialogs.client.views.ui.DialogsViewImpl'));


DialogsView.$markImplementor(DialogsViewImpl);


exports = DialogsViewImpl; 
//# sourceMappingURL=DialogsViewImpl.js.map