/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _DialogsPresenter = goog.require('org.dominokit.domino.dialogs.client.presenters.DialogsPresenter');


// Re-exports the implementation.
var DialogsPresenterCommand = goog.require('org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand$impl');
exports = DialogsPresenterCommand;
 