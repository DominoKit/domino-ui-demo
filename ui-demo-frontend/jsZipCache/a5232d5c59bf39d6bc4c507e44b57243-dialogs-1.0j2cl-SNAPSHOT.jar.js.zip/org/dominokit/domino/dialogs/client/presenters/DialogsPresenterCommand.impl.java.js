/**
 * @fileoverview transpiled from org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let DialogsPresenter = goog.forwardDeclare('org.dominokit.domino.dialogs.client.presenters.DialogsPresenter$impl');


/**
 * @extends {PresenterCommand<DialogsPresenter>}
  */
class DialogsPresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'DialogsPresenterCommand()'.
   * @return {!DialogsPresenterCommand}
   * @public
   */
  static $create__() {
    DialogsPresenterCommand.$clinit();
    let $instance = new DialogsPresenterCommand();
    $instance.$ctor__org_dominokit_domino_dialogs_client_presenters_DialogsPresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DialogsPresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_dialogs_client_presenters_DialogsPresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DialogsPresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DialogsPresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    DialogsPresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(DialogsPresenterCommand, $Util.$makeClassName('org.dominokit.domino.dialogs.client.presenters.DialogsPresenterCommand'));




exports = DialogsPresenterCommand; 
//# sourceMappingURL=DialogsPresenterCommand.js.map