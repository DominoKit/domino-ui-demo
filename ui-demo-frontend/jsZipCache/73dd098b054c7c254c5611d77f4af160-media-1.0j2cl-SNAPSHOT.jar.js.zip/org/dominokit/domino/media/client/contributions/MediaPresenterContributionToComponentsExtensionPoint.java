package org.dominokit.domino.media.client.contributions;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Contribute;
import org.dominokit.domino.api.shared.extension.Contribution;
import org.dominokit.domino.components.shared.extension.ComponentsExtensionPoint;
import org.dominokit.domino.media.client.presenters.MediaPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.InjectContextProcessor")
@Contribute
public class MediaPresenterContributionToComponentsExtensionPoint implements Contribution<ComponentsExtensionPoint> {
  @Override
  public void contribute(ComponentsExtensionPoint extensionPoint) {
    new MediaPresenterCommand().onPresenterReady(presenter -> presenter.contributeToComponentsModule(extensionPoint.context())).send();
  }
}
