/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.NotificationsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.notifications.client.NotificationsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class NotificationsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'NotificationsClientModule()'.
   * @return {!NotificationsClientModule}
   * @public
   */
  static $create__() {
    NotificationsClientModule.$clinit();
    let $instance = new NotificationsClientModule();
    $instance.$ctor__org_dominokit_domino_notifications_client_NotificationsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NotificationsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_notifications_client_NotificationsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    NotificationsClientModule.$f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_.m_info__java_lang_String("Initializing Notifications frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_() {
    return (NotificationsClientModule.$clinit(), NotificationsClientModule.$f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_(value) {
    (NotificationsClientModule.$clinit(), NotificationsClientModule.$f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NotificationsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NotificationsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NotificationsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    NotificationsClientModule.$f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(NotificationsClientModule));
  }
  
  
};

$Util.$setClassMetadata(NotificationsClientModule, $Util.$makeClassName('org.dominokit.domino.notifications.client.NotificationsClientModule'));


/** @private {Logger} */
NotificationsClientModule.$f_LOGGER__org_dominokit_domino_notifications_client_NotificationsClientModule_;




exports = NotificationsClientModule; 
//# sourceMappingURL=NotificationsClientModule.js.map