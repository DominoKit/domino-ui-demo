/**
 * @fileoverview transpiled from org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const NotificationsView = goog.require('org.dominokit.domino.notifications.client.views.NotificationsView$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.CodeResource$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$17$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$18$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$20$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$22$impl');
let $LambdaAdaptor$23 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$23$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$24$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$25$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$26$impl');
let $LambdaAdaptor$27 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$27$impl');
let $LambdaAdaptor$28 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$28$impl');
let $LambdaAdaptor$29 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$29$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$3$impl');
let $LambdaAdaptor$30 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$30$impl');
let $LambdaAdaptor$31 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$31$impl');
let $LambdaAdaptor$32 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$32$impl');
let $LambdaAdaptor$33 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$33$impl');
let $LambdaAdaptor$34 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$34$impl');
let $LambdaAdaptor$35 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$35$impl');
let $LambdaAdaptor$36 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$36$impl');
let $LambdaAdaptor$37 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$37$impl');
let $LambdaAdaptor$38 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$38$impl');
let $LambdaAdaptor$39 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$39$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$4$impl');
let $LambdaAdaptor$40 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$40$impl');
let $LambdaAdaptor$41 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$41$impl');
let $LambdaAdaptor$42 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$42$impl');
let $LambdaAdaptor$43 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$43$impl');
let $LambdaAdaptor$44 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$44$impl');
let $LambdaAdaptor$45 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$45$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$5$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$9$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {NotificationsView}
  */
class NotificationsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'NotificationsViewImpl()'.
   * @return {!NotificationsViewImpl}
   * @public
   */
  static $create__() {
    NotificationsViewImpl.$clinit();
    let $instance = new NotificationsViewImpl();
    $instance.$ctor__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'NotificationsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String__java_lang_String("NOTIFICATIONS", "Taken by Bootstrap Notification ").m_appendContent__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_attr__java_lang_String__java_lang_String("href", "https://github.com/mouse0270/bootstrap-notify"), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("target", "_blank"), HtmlContentBuilder)).m_textContent__java_lang_String("github.com/mouse0270/bootstrap-notify"), HtmlContentBuilder)).m_asElement__()).m_asElement__());
    this.m_notificationsPosition___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl();
    this.m_notificationsTypes___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl();
    this.m_withMaterialColors___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl();
    this.m_withAnimation___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_notificationsPosition___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl() {
    let topLeft = Button.m_createPrimary__java_lang_String("TOP LEFT").m_large__();
    topLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$1(((/** Event */ e) =>{
      Notification.m_create__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let topCenter = Button.m_createPrimary__java_lang_String("TOP CENTER").m_large__();
    topCenter.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$2(((/** Event */ e$1$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let topRight = Button.m_createPrimary__java_lang_String("TOP RIGHT").m_large__();
    topRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$3(((/** Event */ e$2$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bottomLeft = Button.m_createPrimary__java_lang_String("BOTTOM LEFT").m_large__();
    bottomLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$4(((/** Event */ e$3$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_BOTTOM_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bottomCenter = Button.m_createPrimary__java_lang_String("BOTTOM CENTER").m_large__();
    bottomCenter.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$5(((/** Event */ e$4$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_BOTTOM_CENTER__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bottomRight = Button.m_createPrimary__java_lang_String("BOTTOM RIGHT").m_large__();
    bottomRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$6(((/** Event */ e$5$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_BOTTOM_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(Card.m_create__java_lang_String("NOTIFICATION POSITIONS").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(topLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(topCenter.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(topRight.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bottomLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bottomCenter.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bottomRight.m_block__().m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_notificationsPosition__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_notificationsTypes___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl() {
    let danger = Button.m_createDanger__java_lang_String("DANGER").m_large__();
    danger.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$7(((/** Event */ e) =>{
      Notification.m_createDanger__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let success = Button.m_createSuccess__java_lang_String("SUCCESS").m_large__();
    success.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$8(((/** Event */ e$1$) =>{
      Notification.m_createSuccess__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let warning = Button.m_createWarning__java_lang_String("WARNING").m_large__();
    warning.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$9(((/** Event */ e$2$) =>{
      Notification.m_createWarning__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let info = Button.m_createInfo__java_lang_String("INFO").m_large__();
    info.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$10(((/** Event */ e$3$) =>{
      Notification.m_createInfo__java_lang_String("You received a message").m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("NOTIFICATION TYPES", "Use predefined notification styles.").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(danger.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(success.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(warning.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(info.m_block__().m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_notificationsTypes__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_withMaterialColors___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl() {
    let redButton = Button.m_create__java_lang_String("RED").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_large__();
    redButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$11(((/** Event */ e) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let greenButton = Button.m_create__java_lang_String("GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    greenButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$12(((/** Event */ e$1$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let orangeButton = Button.m_create__java_lang_String("ORANGE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_large__();
    orangeButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$13(((/** Event */ e$2$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let blueButton = Button.m_create__java_lang_String("BLUE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_large__();
    blueButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$14(((/** Event */ e$3$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let tealButton = Button.m_create__java_lang_String("TEAL").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__();
    tealButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$15(((/** Event */ e$4$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let cyanButton = Button.m_create__java_lang_String("CYAN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__();
    cyanButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$16(((/** Event */ e$5$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let pinkButton = Button.m_create__java_lang_String("PINK").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__();
    pinkButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$17(((/** Event */ e$6$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let purpleButton = Button.m_create__java_lang_String("PURPLE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_large__();
    purpleButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$18(((/** Event */ e$7$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let blueGreyButton = Button.m_create__java_lang_String("BLUE GREY").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_large__();
    blueGreyButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$19(((/** Event */ e$8$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let deepOrangeButton = Button.m_create__java_lang_String("DEEP ORANGE").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_ORANGE__org_dominokit_domino_ui_style_Color).m_large__();
    deepOrangeButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$20(((/** Event */ e$9$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_DEEP_ORANGE__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let lightGreenButton = Button.m_create__java_lang_String("LIGHT GREEN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    lightGreenButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$21(((/** Event */ e$10$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let blackButton = Button.m_create__java_lang_String("BLACK").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLACK__org_dominokit_domino_ui_style_Color).m_large__();
    blackButton.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$22(((/** Event */ e$11$) =>{
      Notification.m_create__java_lang_String("You received a message").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_BLACK__org_dominokit_domino_ui_style_Color).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(Card.m_create__java_lang_String("WITH MATERIAL DESIGN COLORS").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(redButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(greenButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(orangeButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(blueButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(tealButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(cyanButton.m_block__().m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(pinkButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(purpleButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(blueGreyButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(deepOrangeButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(lightGreenButton.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(blackButton.m_block__().m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_withMaterialColors__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_withAnimation___$p_org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl() {
    let fadeInOut = Button.m_create__java_lang_String("FADE IN OUT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__();
    fadeInOut.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$23(((/** Event */ e) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_IN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_OUT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let fadeInOutLeft = Button.m_create__java_lang_String("FADE IN OU LEFT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__();
    fadeInOutLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$24(((/** Event */ e$1$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let fadeInOutRight = Button.m_create__java_lang_String("FADE IN OUT RIGHT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__();
    fadeInOutRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$25(((/** Event */ e$2$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let fadeInOutUp = Button.m_create__java_lang_String("FADE IN OUT UP").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__();
    fadeInOutUp.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$26(((/** Event */ e$3$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let fadeInOutDown = Button.m_create__java_lang_String("FADE IN OUT DOWN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_large__();
    fadeInOutDown.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$27(((/** Event */ e$4$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bouneInOut = Button.m_create__java_lang_String("BOUNCE IN OUT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__();
    bouneInOut.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$28(((/** Event */ e$5$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bounceInOutLeft = Button.m_create__java_lang_String("BOUNCE IN OUT LEFT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__();
    bounceInOutLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$29(((/** Event */ e$6$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bounceInOutRight = Button.m_create__java_lang_String("BOUNCE IN OUT RIGHT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__();
    bounceInOutRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$30(((/** Event */ e$7$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bounceInOutUp = Button.m_create__java_lang_String("BOUNCE IN OUT UP").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__();
    bounceInOutUp.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$31(((/** Event */ e$8$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let bounceInOutDown = Button.m_create__java_lang_String("BOUNCE IN OUT DOWN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_CYAN__org_dominokit_domino_ui_style_Color).m_large__();
    bounceInOutDown.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$32(((/** Event */ e$9$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let rotateInOut = Button.m_create__java_lang_String("ROTATE IN OUT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    rotateInOut.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$33(((/** Event */ e$10$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let rotateInOutUpLeft = Button.m_create__java_lang_String("ROTATE IN OUT UP LEFT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    rotateInOutUpLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$34(((/** Event */ e$11$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let rotateInOutUpRight = Button.m_create__java_lang_String("ROTATE IN OUT UP RIGHT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    rotateInOutUpRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$35(((/** Event */ e$12$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let rotateInOutDownLeft = Button.m_create__java_lang_String("ROTATE IN OUT DOWN LEFT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    rotateInOutDownLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$36(((/** Event */ e$13$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let rotateInOutDownRight = Button.m_create__java_lang_String("ROTATE IN OUT DOWN RIGHT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_LIGHT_GREEN__org_dominokit_domino_ui_style_Color).m_large__();
    rotateInOutDownRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$37(((/** Event */ e$14$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let zoomInOut = Button.m_create__java_lang_String("ZOOM IN OUT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__();
    zoomInOut.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$38(((/** Event */ e$15$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let zoomInOutLeft = Button.m_create__java_lang_String("ZOOM IN OUT LEFT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__();
    zoomInOutLeft.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$39(((/** Event */ e$16$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let zoomInOutRight = Button.m_create__java_lang_String("ZOOM IN OUT RIGHT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__();
    zoomInOutRight.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$40(((/** Event */ e$17$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let zoomInOutUp = Button.m_create__java_lang_String("ZOOM IN OUT UP").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__();
    zoomInOutUp.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$41(((/** Event */ e$18$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let zoomInOutDown = Button.m_create__java_lang_String("ZOOM IN OUT DOWN").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color).m_large__();
    zoomInOutDown.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$42(((/** Event */ e$19$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let flipInOutX = Button.m_create__java_lang_String("FLIP IN OUT X").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_large__();
    flipInOutX.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$43(((/** Event */ e$20$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_BOTTOM_LEFT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let flipInOutY = Button.m_create__java_lang_String("FLIP IN OUT Y").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_PURPLE__org_dominokit_domino_ui_style_Color).m_large__();
    flipInOutY.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$44(((/** Event */ e$21$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_BOTTOM_RIGHT__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    let lightSpeedInOut = Button.m_create__java_lang_String("LIGHT SPEED IN OUT").m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_large__();
    lightSpeedInOut.m_getClickableElement__().addEventListener("click", new $LambdaAdaptor$45(((/** Event */ e$22$) =>{
      Notification.m_create__java_lang_String("You received a message").m_inTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition).m_outTransition__org_dominokit_domino_ui_animations_Transition(Transition.f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition).m_setPosition__org_dominokit_domino_ui_notifications_Notification_Position(Notification.f_TOP_CENTER__org_dominokit_domino_ui_notifications_Notification).m_show__();
    })));
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(Card.m_create__java_lang_String("NOTIFICATION ANIMATIONS").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(fadeInOut.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(fadeInOutLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(fadeInOutRight.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(fadeInOutUp.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(fadeInOutDown.m_block__().m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bouneInOut.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bounceInOutLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bounceInOutRight.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bounceInOutUp.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(bounceInOutDown.m_block__().m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(rotateInOut.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(rotateInOutUpLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(rotateInOutUpRight.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(rotateInOutDownLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(rotateInOutDownRight.m_block__().m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(zoomInOut.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(zoomInOutLeft.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(zoomInOutRight.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(zoomInOutUp.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(zoomInOutDown.m_block__().m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(flipInOutX.m_block__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(flipInOutY.m_block__().m_asElement__())).m_asElement__()).m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.m_copy__().m_addElement__elemental2_dom_Node(lightSpeedInOut.m_block__().m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_withAnimation__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl() {
    this.f_element__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_column__org_dominokit_domino_notifications_client_views_ui_NotificationsViewImpl_ = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_two__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_two__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof NotificationsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, NotificationsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    NotificationsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    CodeResource = goog.module.get('org.dominokit.domino.notifications.client.views.CodeResource$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$17$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$18$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$20$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$22$impl');
    $LambdaAdaptor$23 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$23$impl');
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$24$impl');
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$25$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$26$impl');
    $LambdaAdaptor$27 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$27$impl');
    $LambdaAdaptor$28 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$28$impl');
    $LambdaAdaptor$29 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$29$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$3$impl');
    $LambdaAdaptor$30 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$30$impl');
    $LambdaAdaptor$31 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$31$impl');
    $LambdaAdaptor$32 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$32$impl');
    $LambdaAdaptor$33 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$33$impl');
    $LambdaAdaptor$34 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$34$impl');
    $LambdaAdaptor$35 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$35$impl');
    $LambdaAdaptor$36 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$36$impl');
    $LambdaAdaptor$37 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$37$impl');
    $LambdaAdaptor$38 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$38$impl');
    $LambdaAdaptor$39 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$39$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$4$impl');
    $LambdaAdaptor$40 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$40$impl');
    $LambdaAdaptor$41 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$41$impl');
    $LambdaAdaptor$42 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$42$impl');
    $LambdaAdaptor$43 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$43$impl');
    $LambdaAdaptor$44 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$44$impl');
    $LambdaAdaptor$45 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$45$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$5$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl.$LambdaAdaptor$9$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(NotificationsViewImpl, $Util.$makeClassName('org.dominokit.domino.notifications.client.views.ui.NotificationsViewImpl'));


NotificationsView.$markImplementor(NotificationsViewImpl);


exports = NotificationsViewImpl; 
//# sourceMappingURL=NotificationsViewImpl.js.map