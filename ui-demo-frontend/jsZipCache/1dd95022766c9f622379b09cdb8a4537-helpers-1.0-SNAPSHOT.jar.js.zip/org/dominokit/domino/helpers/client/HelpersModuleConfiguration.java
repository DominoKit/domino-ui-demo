package org.dominokit.domino.helpers.client;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.ModuleConfiguration;
import org.dominokit.domino.api.client.extension.DominoEventsRegistry;
import org.dominokit.domino.api.client.mvp.PresenterRegistry;
import org.dominokit.domino.api.client.mvp.ViewRegistry;
import org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader;
import org.dominokit.domino.api.client.mvp.presenter.Presentable;
import org.dominokit.domino.api.client.mvp.view.LazyViewLoader;
import org.dominokit.domino.api.client.mvp.view.View;
import org.dominokit.domino.api.client.request.CommandRegistry;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;
import org.dominokit.domino.helpers.client.listeners.HelpersPresenterListenerForComponentCaseEvent;
import org.dominokit.domino.helpers.client.presenters.HelpersPresenter;
import org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand;
import org.dominokit.domino.helpers.client.views.ui.HelpersViewImpl;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.module.client.ClientModuleAnnotationProcessor")
public class HelpersModuleConfiguration implements ModuleConfiguration {
  @Override
  public void registerPresenters(PresenterRegistry registry) {
    registry.registerPresenter(new LazyPresenterLoader(HelpersPresenter.class.getCanonicalName(), HelpersPresenter.class.getCanonicalName()) {
      @Override
      protected Presentable make() {
        return new HelpersPresenter();
      }
    });
  }

  @Override
  public void registerViews(ViewRegistry registry) {
    registry.registerView(new LazyViewLoader(HelpersPresenter.class.getCanonicalName()) {
      @Override
      protected View make() {
        return new HelpersViewImpl();
      }
    });
  }

  @Override
  public void registerRequests(CommandRegistry registry) {
    registry.registerCommand(HelpersPresenterCommand.class.getCanonicalName(), HelpersPresenter.class.getCanonicalName());
  }

  @Override
  public void registerListeners(DominoEventsRegistry registry) {
    registry.addListener(ComponentCaseEvent.class, new HelpersPresenterListenerForComponentCaseEvent());
  }
}
