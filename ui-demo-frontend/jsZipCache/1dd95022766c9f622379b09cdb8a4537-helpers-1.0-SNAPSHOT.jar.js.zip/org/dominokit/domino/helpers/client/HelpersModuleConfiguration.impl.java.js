/**
 * @fileoverview transpiled from org.dominokit.domino.helpers.client.HelpersModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.helpers.client.HelpersModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let ComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.helpers.client.HelpersModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.helpers.client.HelpersModuleConfiguration.$2$impl');
let HelpersPresenterListenerForComponentCaseEvent = goog.forwardDeclare('org.dominokit.domino.helpers.client.listeners.HelpersPresenterListenerForComponentCaseEvent$impl');
let HelpersPresenter = goog.forwardDeclare('org.dominokit.domino.helpers.client.presenters.HelpersPresenter$impl');
let HelpersPresenterCommand = goog.forwardDeclare('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand$impl');


/**
 * @implements {ModuleConfiguration}
  */
class HelpersModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'HelpersModuleConfiguration()'.
   * @return {!HelpersModuleConfiguration}
   * @public
   */
  static $create__() {
    HelpersModuleConfiguration.$clinit();
    let $instance = new HelpersModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_helpers_client_HelpersModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HelpersModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_helpers_client_HelpersModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_helpers_client_HelpersModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(HelpersPresenter).m_getCanonicalName__(), Class.$get(HelpersPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_helpers_client_HelpersModuleConfiguration__java_lang_String(this, Class.$get(HelpersPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(HelpersPresenterCommand).m_getCanonicalName__(), Class.$get(HelpersPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentCaseEvent), HelpersPresenterListenerForComponentCaseEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HelpersModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HelpersModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    HelpersModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ComponentCaseEvent = goog.module.get('org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent$impl');
    $1 = goog.module.get('org.dominokit.domino.helpers.client.HelpersModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.helpers.client.HelpersModuleConfiguration.$2$impl');
    HelpersPresenterListenerForComponentCaseEvent = goog.module.get('org.dominokit.domino.helpers.client.listeners.HelpersPresenterListenerForComponentCaseEvent$impl');
    HelpersPresenter = goog.module.get('org.dominokit.domino.helpers.client.presenters.HelpersPresenter$impl');
    HelpersPresenterCommand = goog.module.get('org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(HelpersModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.helpers.client.HelpersModuleConfiguration'));


ModuleConfiguration.$markImplementor(HelpersModuleConfiguration);


exports = HelpersModuleConfiguration; 
//# sourceMappingURL=HelpersModuleConfiguration.js.map