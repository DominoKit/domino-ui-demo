package org.dominokit.domino.helpers.client.listeners;

import javax.annotation.Generated;
import org.dominokit.domino.api.client.annotations.Listener;
import org.dominokit.domino.api.shared.extension.DominoEventListener;
import org.dominokit.domino.componentcase.shared.extension.ComponentCaseEvent;
import org.dominokit.domino.helpers.client.presenters.HelpersPresenterCommand;

/**
 * This is generated class, please don't modify
 */
@Generated("org.dominokit.domino.apt.client.processors.inject.ListenToDominoEventProcessor")
@Listener
public class HelpersPresenterListenerForComponentCaseEvent implements DominoEventListener<ComponentCaseEvent> {
  @Override
  public void listen(ComponentCaseEvent event) {
    new HelpersPresenterCommand().onPresenterReady(presenter -> presenter.onComponentCaseModule(event.context())).send();
  }
}
