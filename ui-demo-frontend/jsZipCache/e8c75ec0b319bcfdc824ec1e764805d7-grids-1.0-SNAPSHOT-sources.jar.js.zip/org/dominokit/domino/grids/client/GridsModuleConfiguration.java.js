/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.GridsModuleConfiguration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.grids.client.GridsModuleConfiguration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration');
const _Class = goog.require('java.lang.Class');
const _InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry');
const _DominoEventsRegistry = goog.require('org.dominokit.domino.api.client.extension.DominoEventsRegistry');
const _PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry');
const _ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry');
const _CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry');
const _RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry');
const _$1 = goog.require('org.dominokit.domino.grids.client.GridsModuleConfiguration.$1');
const _$2 = goog.require('org.dominokit.domino.grids.client.GridsModuleConfiguration.$2');
const _GridsPresenterListenerForLayoutsEvent = goog.require('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent');
const _GridsPresenter = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenter');
const _GridsPresenterCommand = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand');
const _LayoutsEvent = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent');


// Re-exports the implementation.
var GridsModuleConfiguration = goog.require('org.dominokit.domino.grids.client.GridsModuleConfiguration$impl');
exports = GridsModuleConfiguration;
 