/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener');
const _PresenterHandler = goog.require('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler');
const _DominoEvent = goog.require('org.dominokit.domino.api.shared.extension.DominoEvent');
const _GridsPresenter = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenter');
const _GridsPresenterCommand = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand');
const _LayoutsEvent = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEvent');
const _LayoutsEventContext = goog.require('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var GridsPresenterListenerForLayoutsEvent = goog.require('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent$impl');
exports = GridsPresenterListenerForLayoutsEvent;
 