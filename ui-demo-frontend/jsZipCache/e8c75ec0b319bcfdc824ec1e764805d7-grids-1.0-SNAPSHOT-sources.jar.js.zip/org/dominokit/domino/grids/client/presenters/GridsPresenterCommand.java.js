/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.presenters.GridsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _GridsPresenter = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenter');


// Re-exports the implementation.
var GridsPresenterCommand = goog.require('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand$impl');
exports = GridsPresenterCommand;
 