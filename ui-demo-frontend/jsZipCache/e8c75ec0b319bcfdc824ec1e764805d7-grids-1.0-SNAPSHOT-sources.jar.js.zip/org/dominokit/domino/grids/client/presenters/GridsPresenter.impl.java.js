/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.presenters.GridsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.grids.client.presenters.GridsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.grids.client.presenters.GridsPresenter.$1$impl');
let GridsView = goog.forwardDeclare('org.dominokit.domino.grids.client.views.GridsView$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {ViewBaseClientPresenter<GridsView>}
  */
class GridsPresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GridsPresenter()'.
   * @return {!GridsPresenter}
   * @public
   */
  static $create__() {
    GridsPresenter.$clinit();
    let $instance = new GridsPresenter();
    $instance.$ctor__org_dominokit_domino_grids_client_presenters_GridsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GridsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_grids_client_presenters_GridsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {LayoutsEventContext} context
   * @return {void}
   * @public
   */
  m_listenToLayoutsEvent__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_grids_client_presenters_GridsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_grids_client_presenters_GridsPresenter_() {
    return (GridsPresenter.$clinit(), GridsPresenter.$f_LOGGER__org_dominokit_domino_grids_client_presenters_GridsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_grids_client_presenters_GridsPresenter_(value) {
    (GridsPresenter.$clinit(), GridsPresenter.$f_LOGGER__org_dominokit_domino_grids_client_presenters_GridsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GridsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GridsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.grids.client.presenters.GridsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    ViewBaseClientPresenter.$clinit();
    GridsPresenter.$f_LOGGER__org_dominokit_domino_grids_client_presenters_GridsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(GridsPresenter));
  }
  
  
};

$Util.$setClassMetadata(GridsPresenter, $Util.$makeClassName('org.dominokit.domino.grids.client.presenters.GridsPresenter'));


/** @private {Logger} */
GridsPresenter.$f_LOGGER__org_dominokit_domino_grids_client_presenters_GridsPresenter_;




exports = GridsPresenter; 
//# sourceMappingURL=GridsPresenter.js.map