/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DominoEventListener = goog.require('org.dominokit.domino.api.shared.extension.DominoEventListener$impl');

let PresenterHandler = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
let DominoEvent = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.DominoEvent$impl');
let GridsPresenter = goog.forwardDeclare('org.dominokit.domino.grids.client.presenters.GridsPresenter$impl');
let GridsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand$impl');
let LayoutsEvent = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
let LayoutsEventContext = goog.forwardDeclare('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {DominoEventListener<LayoutsEvent>}
  */
class GridsPresenterListenerForLayoutsEvent extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'GridsPresenterListenerForLayoutsEvent()'.
   * @return {!GridsPresenterListenerForLayoutsEvent}
   * @public
   */
  static $create__() {
    GridsPresenterListenerForLayoutsEvent.$clinit();
    let $instance = new GridsPresenterListenerForLayoutsEvent();
    $instance.$ctor__org_dominokit_domino_grids_client_listeners_GridsPresenterListenerForLayoutsEvent__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'GridsPresenterListenerForLayoutsEvent()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_grids_client_listeners_GridsPresenterListenerForLayoutsEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {LayoutsEvent} event
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_layouts_shared_extension_LayoutsEvent(event) {
    GridsPresenterCommand.$create__().m_onPresenterReady__org_dominokit_domino_api_client_request_PresenterCommand_PresenterHandler(PresenterHandler.$adapt(((/** GridsPresenter */ presenter) =>{
      presenter.m_listenToLayoutsEvent__org_dominokit_domino_layouts_shared_extension_LayoutsEventContext(/**@type {LayoutsEventContext} */ ($Casts.$to(event.m_context__(), LayoutsEventContext)));
    }))).m_send__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {DominoEvent} arg0
   * @return {void}
   * @public
   */
  m_listen__org_dominokit_domino_api_shared_extension_DominoEvent(arg0) {
    this.m_listen__org_dominokit_domino_layouts_shared_extension_LayoutsEvent(/**@type {LayoutsEvent} */ ($Casts.$to(arg0, LayoutsEvent)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof GridsPresenterListenerForLayoutsEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, GridsPresenterListenerForLayoutsEvent);
  }
  
  /**
   * @public
   */
  static $clinit() {
    GridsPresenterListenerForLayoutsEvent.$clinit = function() {};
    PresenterHandler = goog.module.get('org.dominokit.domino.api.client.request.PresenterCommand.PresenterHandler$impl');
    GridsPresenterCommand = goog.module.get('org.dominokit.domino.grids.client.presenters.GridsPresenterCommand$impl');
    LayoutsEvent = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEvent$impl');
    LayoutsEventContext = goog.module.get('org.dominokit.domino.layouts.shared.extension.LayoutsEventContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(GridsPresenterListenerForLayoutsEvent, $Util.$makeClassName('org.dominokit.domino.grids.client.listeners.GridsPresenterListenerForLayoutsEvent'));


DominoEventListener.$markImplementor(GridsPresenterListenerForLayoutsEvent);


exports = GridsPresenterListenerForLayoutsEvent; 
//# sourceMappingURL=GridsPresenterListenerForLayoutsEvent.js.map