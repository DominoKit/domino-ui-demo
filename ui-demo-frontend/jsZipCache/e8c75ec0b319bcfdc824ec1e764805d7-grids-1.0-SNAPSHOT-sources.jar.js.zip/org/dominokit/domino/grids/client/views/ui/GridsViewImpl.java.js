/**
 * @fileoverview transpiled from org.dominokit.domino.grids.client.views.ui.GridsViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.grids.client.views.ui.GridsViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _GridsView = goog.require('org.dominokit.domino.grids.client.views.GridsView');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Row__16 = goog.require('org.dominokit.domino.ui.grid.Row_16');
const _Row__18 = goog.require('org.dominokit.domino.ui.grid.Row_18');
const _Row__24 = goog.require('org.dominokit.domino.ui.grid.Row_24');
const _Row__32 = goog.require('org.dominokit.domino.ui.grid.Row_32');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var GridsViewImpl = goog.require('org.dominokit.domino.grids.client.views.ui.GridsViewImpl$impl');
exports = GridsViewImpl;
 