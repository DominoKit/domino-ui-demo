/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _ButtonsPresenter = goog.require('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter');


// Re-exports the implementation.
var ButtonsPresenterCommand = goog.require('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand$impl');
exports = ButtonsPresenterCommand;
 