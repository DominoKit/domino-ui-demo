/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.ButtonsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.buttons.client.ButtonsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ButtonsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ButtonsClientModule()'.
   * @return {!ButtonsClientModule}
   * @public
   */
  static $create__() {
    ButtonsClientModule.$clinit();
    let $instance = new ButtonsClientModule();
    $instance.$ctor__org_dominokit_domino_buttons_client_ButtonsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ButtonsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_buttons_client_ButtonsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ButtonsClientModule.$f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_.m_info__java_lang_String("Initializing Buttons frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_() {
    return (ButtonsClientModule.$clinit(), ButtonsClientModule.$f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_(value) {
    (ButtonsClientModule.$clinit(), ButtonsClientModule.$f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ButtonsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ButtonsClientModule.$f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ButtonsClientModule));
  }
  
  
};

$Util.$setClassMetadata(ButtonsClientModule, $Util.$makeClassName('org.dominokit.domino.buttons.client.ButtonsClientModule'));


/** @private {Logger} */
ButtonsClientModule.$f_LOGGER__org_dominokit_domino_buttons_client_ButtonsClientModule_;




exports = ButtonsClientModule; 
//# sourceMappingURL=ButtonsClientModule.js.map