/**
 * @fileoverview transpiled from org.dominokit.domino.buttons.client.ButtonsModuleConfiguration.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.buttons.client.ButtonsModuleConfiguration$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ModuleConfiguration = goog.require('org.dominokit.domino.api.client.ModuleConfiguration$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let InitialTaskRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
let DominoEventsRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.extension.DominoEventsRegistry$impl');
let PresenterRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
let ViewRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
let CommandRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandRegistry$impl');
let RequestRestSendersRegistry = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.buttons.client.ButtonsModuleConfiguration.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.buttons.client.ButtonsModuleConfiguration.$2$impl');
let ButtonsPresenterListenerForComponentsEvent = goog.forwardDeclare('org.dominokit.domino.buttons.client.listeners.ButtonsPresenterListenerForComponentsEvent$impl');
let ButtonsPresenter = goog.forwardDeclare('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter$impl');
let ButtonsPresenterCommand = goog.forwardDeclare('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand$impl');
let ComponentsEvent = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');


/**
 * @implements {ModuleConfiguration}
  */
class ButtonsModuleConfiguration extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ButtonsModuleConfiguration()'.
   * @return {!ButtonsModuleConfiguration}
   * @public
   */
  static $create__() {
    ButtonsModuleConfiguration.$clinit();
    let $instance = new ButtonsModuleConfiguration();
    $instance.$ctor__org_dominokit_domino_buttons_client_ButtonsModuleConfiguration__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ButtonsModuleConfiguration()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_buttons_client_ButtonsModuleConfiguration__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {PresenterRegistry} registry
   * @return {void}
   * @public
   */
  m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(registry) {
    registry.m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader($1.$create__org_dominokit_domino_buttons_client_ButtonsModuleConfiguration__java_lang_String__java_lang_String(this, Class.$get(ButtonsPresenter).m_getCanonicalName__(), Class.$get(ButtonsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {ViewRegistry} registry
   * @return {void}
   * @public
   */
  m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(registry) {
    registry.m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader($2.$create__org_dominokit_domino_buttons_client_ButtonsModuleConfiguration__java_lang_String(this, Class.$get(ButtonsPresenter).m_getCanonicalName__()));
  }
  
  /**
   * @override
   * @param {CommandRegistry} registry
   * @return {void}
   * @public
   */
  m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(registry) {
    registry.m_registerCommand__java_lang_String__java_lang_String(Class.$get(ButtonsPresenterCommand).m_getCanonicalName__(), Class.$get(ButtonsPresenter).m_getCanonicalName__());
  }
  
  /**
   * @override
   * @param {DominoEventsRegistry} registry
   * @return {void}
   * @public
   */
  m_registerListeners__org_dominokit_domino_api_client_extension_DominoEventsRegistry(registry) {
    registry.m_addListener__java_lang_Class__org_dominokit_domino_api_shared_extension_DominoEventListener(Class.$get(ComponentsEvent), ButtonsPresenterListenerForComponentsEvent.$create__());
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {InitialTaskRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(arg0) {
    ModuleConfiguration.m_registerInitialTasks__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_InitialTaskRegistry(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {RequestRestSendersRegistry} arg0
   * @return {void}
   * @public
   */
  m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(arg0) {
    ModuleConfiguration.m_registerRequestRestSenders__$default__org_dominokit_domino_api_client_ModuleConfiguration__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsModuleConfiguration;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsModuleConfiguration);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ButtonsModuleConfiguration.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.buttons.client.ButtonsModuleConfiguration.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.buttons.client.ButtonsModuleConfiguration.$2$impl');
    ButtonsPresenterListenerForComponentsEvent = goog.module.get('org.dominokit.domino.buttons.client.listeners.ButtonsPresenterListenerForComponentsEvent$impl');
    ButtonsPresenter = goog.module.get('org.dominokit.domino.buttons.client.presenters.ButtonsPresenter$impl');
    ButtonsPresenterCommand = goog.module.get('org.dominokit.domino.buttons.client.presenters.ButtonsPresenterCommand$impl');
    ComponentsEvent = goog.module.get('org.dominokit.domino.components.shared.extension.ComponentsEvent$impl');
    j_l_Object.$clinit();
    ModuleConfiguration.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ButtonsModuleConfiguration, $Util.$makeClassName('org.dominokit.domino.buttons.client.ButtonsModuleConfiguration'));


ModuleConfiguration.$markImplementor(ButtonsModuleConfiguration);


exports = ButtonsModuleConfiguration; 
//# sourceMappingURL=ButtonsModuleConfiguration.js.map