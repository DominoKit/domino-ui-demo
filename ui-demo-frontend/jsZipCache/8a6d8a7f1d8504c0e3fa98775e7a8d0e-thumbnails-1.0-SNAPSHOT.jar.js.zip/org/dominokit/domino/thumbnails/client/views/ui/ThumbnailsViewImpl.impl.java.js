/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.views.ui.ThumbnailsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.thumbnails.client.views.ui.ThumbnailsViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const ThumbnailsView = goog.require('org.dominokit.domino.thumbnails.client.views.ThumbnailsView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let CodeCard = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
let LinkToSourceCode = goog.forwardDeclare('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Thumbnail = goog.forwardDeclare('org.dominokit.domino.ui.thumbnails.Thumbnail$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {ThumbnailsView}
  */
class ThumbnailsViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'ThumbnailsViewImpl()'.
   * @return {!ThumbnailsViewImpl}
   * @public
   */
  static $create__() {
    ThumbnailsViewImpl.$clinit();
    let $instance = new ThumbnailsViewImpl();
    $instance.$ctor__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThumbnailsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_.appendChild(LinkToSourceCode.m_create__java_lang_String__java_lang_Class(ThumbnailsViewImpl.f_MODULE_NAME__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl, this.m_getClass__()).m_asElement__());
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("THUMBNAILS").m_asElement__());
    this.m_basicSample___$p_org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl();
    this.m_withExtraContentSample___$p_org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_basicSample___$p_org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl() {
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DEFAULT EXAMPLE", "By default, thumbnails are designed to showcase linked images with minimal required markup").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/5.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/6.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/7.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/8.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String))))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ThumbnailsViewImpl.f_MODULE_NAME__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl, "basicSample").m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_withExtraContentSample___$p_org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl() {
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("CUSTOM CONTENT", "With a bit of extra markup, it's possible to add any kind of HTML content like headings, paragraphs, or buttons into thumbnails.").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/1.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Thumbnail label"), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(ThumbnailsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_)).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("BUTTON"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/2.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Thumbnail label"), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(ThumbnailsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_)).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("BUTTON"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/3.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Thumbnail label"), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(ThumbnailsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_)).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("BUTTON"))), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span3__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(Thumbnail.m_create__().m_setContent__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("static/images/image-gallery/4.jpg").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_img_responsive__org_dominokit_domino_ui_style_Styles], j_l_String)))), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Thumbnail label"), IsElement))).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(ThumbnailsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_)).m_appendCaptionChild__org_jboss_gwt_elemento_core_IsElement(Button.m_createPrimary__java_lang_String("BUTTON"))), Column)))).m_asElement__());
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_.appendChild(CodeCard.m_createCodeCard__java_lang_String__java_lang_String(ThumbnailsViewImpl.f_MODULE_NAME__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl, "withExtraContentSample").m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl() {
    this.f_element__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThumbnailsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThumbnailsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThumbnailsViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    CodeCard = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.CodeCard$impl');
    LinkToSourceCode = goog.module.get('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Thumbnail = goog.module.get('org.dominokit.domino.ui.thumbnails.Thumbnail$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ThumbnailsViewImpl, $Util.$makeClassName('org.dominokit.domino.thumbnails.client.views.ui.ThumbnailsViewImpl'));


/** @public {?string} @const */
ThumbnailsViewImpl.f_SAMPLE_TEXT__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl_ = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s";


/** @public {?string} @const */
ThumbnailsViewImpl.f_MODULE_NAME__org_dominokit_domino_thumbnails_client_views_ui_ThumbnailsViewImpl = "thumbnails";


ThumbnailsView.$markImplementor(ThumbnailsViewImpl);


exports = ThumbnailsViewImpl; 
//# sourceMappingURL=ThumbnailsViewImpl.js.map