/**
 * @fileoverview transpiled from org.dominokit.domino.thumbnails.client.ThumbnailsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.thumbnails.client.ThumbnailsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class ThumbnailsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ThumbnailsClientModule()'.
   * @return {!ThumbnailsClientModule}
   * @public
   */
  static $create__() {
    ThumbnailsClientModule.$clinit();
    let $instance = new ThumbnailsClientModule();
    $instance.$ctor__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ThumbnailsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    ThumbnailsClientModule.$f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_.m_info__java_lang_String("Initializing Thumbnails frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_() {
    return (ThumbnailsClientModule.$clinit(), ThumbnailsClientModule.$f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_(value) {
    (ThumbnailsClientModule.$clinit(), ThumbnailsClientModule.$f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ThumbnailsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ThumbnailsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ThumbnailsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    ThumbnailsClientModule.$f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ThumbnailsClientModule));
  }
  
  
};

$Util.$setClassMetadata(ThumbnailsClientModule, $Util.$makeClassName('org.dominokit.domino.thumbnails.client.ThumbnailsClientModule'));


/** @private {Logger} */
ThumbnailsClientModule.$f_LOGGER__org_dominokit_domino_thumbnails_client_ThumbnailsClientModule_;




exports = ThumbnailsClientModule; 
//# sourceMappingURL=ThumbnailsClientModule.js.map