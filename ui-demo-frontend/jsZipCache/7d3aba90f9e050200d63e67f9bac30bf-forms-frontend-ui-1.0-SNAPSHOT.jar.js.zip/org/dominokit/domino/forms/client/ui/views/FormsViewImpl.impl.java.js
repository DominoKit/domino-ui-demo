/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.ui.views.FormsViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.ui.views.FormsViewImpl$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const FormsView = goog.require('org.dominokit.domino.forms.client.views.FormsView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let CreateHandler = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent.CreateHandler$impl');
let Content = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Content$impl');


/**
 * @implements {FormsView}
  */
class FormsViewImpl extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsViewImpl()'.
   * @return {!FormsViewImpl}
   * @public
   */
  static $create__() {
    FormsViewImpl.$clinit();
    let $instance = new FormsViewImpl();
    $instance.$ctor__org_dominokit_domino_forms_client_ui_views_FormsViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_ui_views_FormsViewImpl__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {Content}
   * @public
   */
  m_getContent__() {
    return null;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {CreateHandler} arg0
   * @return {Content}
   * @public
   */
  m_getContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(arg0) {
    return HasContent.m_getContent__$default__org_dominokit_domino_api_client_mvp_view_HasContent__org_dominokit_domino_api_client_mvp_view_HasContent_CreateHandler(this, arg0);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsViewImpl.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    j_l_Object.$clinit();
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadata(FormsViewImpl, $Util.$makeClassName('org.dominokit.domino.forms.client.ui.views.FormsViewImpl'));


FormsView.$markImplementor(FormsViewImpl);


exports = FormsViewImpl; 
//# sourceMappingURL=FormsViewImpl.js.map