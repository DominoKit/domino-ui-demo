/**
 * @fileoverview transpiled from org.dominokit.domino.forms.client.FormsUIClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.forms.client.FormsUIClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class FormsUIClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'FormsUIClientModule()'.
   * @return {!FormsUIClientModule}
   * @public
   */
  static $create__() {
    FormsUIClientModule.$clinit();
    let $instance = new FormsUIClientModule();
    $instance.$ctor__org_dominokit_domino_forms_client_FormsUIClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'FormsUIClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_forms_client_FormsUIClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    FormsUIClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_.m_info__java_lang_String("Initializing Forms frontend UI module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_() {
    return (FormsUIClientModule.$clinit(), FormsUIClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_(value) {
    (FormsUIClientModule.$clinit(), FormsUIClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FormsUIClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FormsUIClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    FormsUIClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    FormsUIClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(FormsUIClientModule));
  }
  
  
};

$Util.$setClassMetadata(FormsUIClientModule, $Util.$makeClassName('org.dominokit.domino.forms.client.FormsUIClientModule'));


/** @private {Logger} */
FormsUIClientModule.$f_LOGGER__org_dominokit_domino_forms_client_FormsUIClientModule_;




exports = FormsUIClientModule; 
//# sourceMappingURL=FormsUIClientModule.js.map