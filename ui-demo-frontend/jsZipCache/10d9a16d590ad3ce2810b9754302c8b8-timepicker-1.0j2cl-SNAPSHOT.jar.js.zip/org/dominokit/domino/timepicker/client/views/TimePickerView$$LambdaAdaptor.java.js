/**
 * @fileoverview transpiled from org.dominokit.domino.timepicker.client.views.TimePickerView$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.timepicker.client.views.TimePickerView.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _TimePickerView = goog.require('org.dominokit.domino.timepicker.client.views.TimePickerView');
const _Content = goog.require('org.dominokit.domino.api.shared.extension.Content');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.timepicker.client.views.TimePickerView.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 