/**
 * @fileoverview transpiled from org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView$impl');
const PaginationView = goog.require('org.dominokit.domino.pagination.client.views.PaginationView$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let CodeResource = goog.forwardDeclare('org.dominokit.domino.pagination.client.views.CodeResource$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Pager = goog.forwardDeclare('org.dominokit.domino.ui.pagination.Pager$impl');
let PagerChangeCallback = goog.forwardDeclare('org.dominokit.domino.ui.pagination.Pager.PagerChangeCallback$impl');
let Pagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.Pagination$impl');
let PageChangedCallBack = goog.forwardDeclare('org.dominokit.domino.ui.pagination.Pagination.PageChangedCallBack$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.row.Row$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ComponentView<HTMLDivElement>}
 * @implements {PaginationView}
  */
class PaginationViewImpl extends ComponentView {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_;
  }
  
  /**
   * Factory method corresponding to constructor 'PaginationViewImpl()'.
   * @return {!PaginationViewImpl}
   * @public
   */
  static $create__() {
    PaginationViewImpl.$clinit();
    let $instance = new PaginationViewImpl();
    $instance.$ctor__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PaginationViewImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl__() {
    this.$ctor__org_dominokit_domino_componentcase_shared_extension_ComponentView__();
    this.$init__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_init__() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("PAGINATION").m_asElement__());
    this.m_defaultPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.m_activePageSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.m_sizesSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(BlockHeader.m_create__java_lang_String("PAGER").m_asElement__());
    this.m_pagerNexPrevSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_defaultPagination___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DEFAULT PAGINATION", "Simple pagination inspired by Rdio, great for apps and search results. The large block is hard to miss, easily scalable, and provides large click areas.").m_appendContent__elemental2_dom_Node(Pagination.m_create__int(5).m_onPageChanged__org_dominokit_domino_ui_pagination_Pagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(Integer.m_valueOf__int(pageNumber));
    }))).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_defaultPagination__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_activePageSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ACTIVE PAGE", "You can mark the current active page.").m_appendContent__elemental2_dom_Node(Pagination.m_create__int(5).m_markActivePage__().m_onPageChanged__org_dominokit_domino_ui_pagination_Pagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(Integer.m_valueOf__int(pageNumber));
    }))).m_setActivePage__int(3).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_activePageSample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_sizesSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    let column = Column.m_create__().m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.f_four__org_dominokit_domino_ui_column_Column_OnLarge).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.f_four__org_dominokit_domino_ui_column_Column_OnMedium).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnSmall).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("ACTIVE PAGE", "You can mark the current active page.").m_appendContent__elemental2_dom_Node(Row.m_create__().m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Large"), HtmlContentBuilder)).m_asElement__()).m_addElement__elemental2_dom_Node(Pagination.m_create__int(5).m_markActivePage__().m_onPageChanged__org_dominokit_domino_ui_pagination_Pagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      window.console.info(Integer.m_valueOf__int(pageNumber));
    }))).m_setActivePage__int(3).m_large__().m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Default"), HtmlContentBuilder)).m_asElement__()).m_addElement__elemental2_dom_Node(Pagination.m_create__int(5).m_markActivePage__().m_onPageChanged__org_dominokit_domino_ui_pagination_Pagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber$1$) =>{
      window.console.info(Integer.m_valueOf__int(pageNumber$1$));
    }))).m_setActivePage__int(3).m_asElement__())).m_addColumn__org_dominokit_domino_ui_column_Column(column.m_copy__().m_addElement__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_b__().m_textContent__java_lang_String("Small"), HtmlContentBuilder)).m_asElement__()).m_addElement__elemental2_dom_Node(Pagination.m_create__int(5).m_markActivePage__().m_onPageChanged__org_dominokit_domino_ui_pagination_Pagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber$2$) =>{
      window.console.info(Integer.m_valueOf__int(pageNumber$2$));
    }))).m_setActivePage__int(3).m_small__().m_asElement__())).m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_sizesSample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_pagerNexPrevSample___$p_org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("DEFAULT PAGER", "By default, the pager centers links.").m_appendContent__elemental2_dom_Node(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_asElement__()).m_appendContent__elemental2_dom_Node(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_nextText__java_lang_String("Newer").m_previousText__java_lang_String("Older").m_showArrows__().m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("PAGER ALIGNED TO EDGES", "Use expand to align the pager to the edges.").m_appendContent__elemental2_dom_Node(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_nextText__java_lang_String("Newer").m_previousText__java_lang_String("Older").m_showArrows__().m_expand__().m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(Card.m_create__java_lang_String__java_lang_String("PAGER WITH DISABLED LINK", "You can Disable/Enable pager links.").m_appendContent__elemental2_dom_Node(Pager.m_create__().m_onNext__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to next page.");
    }))).m_onPrevious__org_dominokit_domino_ui_pagination_Pager_PagerChangeCallback(PagerChangeCallback.$adapt((() =>{
      window.console.info("Going to previous page.");
    }))).m_nextText__java_lang_String("Newer").m_previousText__java_lang_String("Older").m_showArrows__().m_expand__().m_disablePrevious__().m_asElement__()).m_asElement__());
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_.appendChild(this.m_createCodeCard__java_lang_String(CodeResource.m_pagerSample__()).m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl() {
    this.f_element__org_dominokit_domino_pagination_client_views_ui_PaginationViewImpl_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PaginationViewImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PaginationViewImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PaginationViewImpl.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    CodeResource = goog.module.get('org.dominokit.domino.pagination.client.views.CodeResource$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Pager = goog.module.get('org.dominokit.domino.ui.pagination.Pager$impl');
    PagerChangeCallback = goog.module.get('org.dominokit.domino.ui.pagination.Pager.PagerChangeCallback$impl');
    Pagination = goog.module.get('org.dominokit.domino.ui.pagination.Pagination$impl');
    PageChangedCallBack = goog.module.get('org.dominokit.domino.ui.pagination.Pagination.PageChangedCallBack$impl');
    Row = goog.module.get('org.dominokit.domino.ui.row.Row$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ComponentView.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PaginationViewImpl, $Util.$makeClassName('org.dominokit.domino.pagination.client.views.ui.PaginationViewImpl'));


PaginationView.$markImplementor(PaginationViewImpl);


exports = PaginationViewImpl; 
//# sourceMappingURL=PaginationViewImpl.js.map