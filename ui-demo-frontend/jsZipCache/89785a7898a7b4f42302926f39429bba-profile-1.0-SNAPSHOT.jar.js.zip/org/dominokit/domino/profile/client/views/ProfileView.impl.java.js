/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ProfileView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.views.ProfileView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView$impl');

let HasContent = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
let IsLayout = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.IsLayout$impl');


/**
 * @interface
 * @extends {ContentView}
 */
class ProfileView {
  /**
   * @abstract
   * @param {IsLayout} layout
   * @return {void}
   * @public
   */
  m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(layout) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    ContentView.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_profile_client_views_ProfileView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_profile_client_views_ProfileView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_profile_client_views_ProfileView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfileView.$clinit = function() {};
    HasContent = goog.module.get('org.dominokit.domino.api.client.mvp.view.HasContent$impl');
    HasContent.$clinit();
  }
  
  
};

$Util.$setClassMetadataForInterface(ProfileView, $Util.$makeClassName('org.dominokit.domino.profile.client.views.ProfileView'));


ProfileView.$markImplementor(/** @type {Function} */ (ProfileView));


exports = ProfileView; 
//# sourceMappingURL=ProfileView.js.map