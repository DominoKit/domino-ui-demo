/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.views.ProfileView.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.profile.client.views.ProfileView');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ContentView = goog.require('org.dominokit.domino.api.client.mvp.view.ContentView');
const _HasContent = goog.require('org.dominokit.domino.api.client.mvp.view.HasContent');
const _IsLayout = goog.require('org.dominokit.domino.layout.shared.extension.IsLayout');


// Re-exports the implementation.
var ProfileView = goog.require('org.dominokit.domino.profile.client.views.ProfileView$impl');
exports = ProfileView;
 