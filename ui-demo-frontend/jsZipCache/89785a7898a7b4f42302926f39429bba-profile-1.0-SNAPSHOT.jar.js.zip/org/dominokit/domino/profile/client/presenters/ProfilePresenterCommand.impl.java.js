/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand$impl');

let ProfilePresenter = goog.forwardDeclare('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');


/**
 * @extends {PresenterCommand<ProfilePresenter>}
  */
class ProfilePresenterCommand extends PresenterCommand {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProfilePresenterCommand()'.
   * @return {!ProfilePresenterCommand}
   * @public
   */
  static $create__() {
    ProfilePresenterCommand.$clinit();
    let $instance = new ProfilePresenterCommand();
    $instance.$ctor__org_dominokit_domino_profile_client_presenters_ProfilePresenterCommand__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfilePresenterCommand()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_presenters_ProfilePresenterCommand__() {
    this.$ctor__org_dominokit_domino_api_client_request_PresenterCommand__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfilePresenterCommand;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfilePresenterCommand);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfilePresenterCommand.$clinit = function() {};
    PresenterCommand.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ProfilePresenterCommand, $Util.$makeClassName('org.dominokit.domino.profile.client.presenters.ProfilePresenterCommand'));




exports = ProfilePresenterCommand; 
//# sourceMappingURL=ProfilePresenterCommand.js.map