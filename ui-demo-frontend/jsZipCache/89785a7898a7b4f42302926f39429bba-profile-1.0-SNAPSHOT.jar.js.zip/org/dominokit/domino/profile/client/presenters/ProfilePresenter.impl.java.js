/**
 * @fileoverview transpiled from org.dominokit.domino.profile.client.presenters.ProfilePresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.profile.client.presenters.ProfilePresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ViewBaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ViewBaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let LayoutContext = goog.forwardDeclare('org.dominokit.domino.layout.shared.extension.LayoutContext$impl');
let ProfileView = goog.forwardDeclare('org.dominokit.domino.profile.client.views.ProfileView$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {ViewBaseClientPresenter<ProfileView>}
  */
class ProfilePresenter extends ViewBaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ProfilePresenter()'.
   * @return {!ProfilePresenter}
   * @public
   */
  static $create__() {
    ProfilePresenter.$clinit();
    let $instance = new ProfilePresenter();
    $instance.$ctor__org_dominokit_domino_profile_client_presenters_ProfilePresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ProfilePresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_profile_client_presenters_ProfilePresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter__();
  }
  
  /**
   * @param {LayoutContext} context
   * @return {void}
   * @public
   */
  m_onLayoutEvent__org_dominokit_domino_layout_shared_extension_LayoutContext(context) {
    /**@type {ProfileView} */ ($Casts.$to(this.f_view__org_dominokit_domino_api_client_mvp_presenter_ViewBaseClientPresenter, ProfileView)).m_setLayout__org_dominokit_domino_layout_shared_extension_IsLayout(context.m_getLayout__());
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_profile_client_presenters_ProfilePresenter_() {
    return (ProfilePresenter.$clinit(), ProfilePresenter.$f_LOGGER__org_dominokit_domino_profile_client_presenters_ProfilePresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_profile_client_presenters_ProfilePresenter_(value) {
    (ProfilePresenter.$clinit(), ProfilePresenter.$f_LOGGER__org_dominokit_domino_profile_client_presenters_ProfilePresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ProfilePresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ProfilePresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ProfilePresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ProfileView = goog.module.get('org.dominokit.domino.profile.client.views.ProfileView$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ViewBaseClientPresenter.$clinit();
    ProfilePresenter.$f_LOGGER__org_dominokit_domino_profile_client_presenters_ProfilePresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(ProfilePresenter));
  }
  
  
};

$Util.$setClassMetadata(ProfilePresenter, $Util.$makeClassName('org.dominokit.domino.profile.client.presenters.ProfilePresenter'));


/** @private {Logger} */
ProfilePresenter.$f_LOGGER__org_dominokit_domino_profile_client_presenters_ProfilePresenter_;




exports = ProfilePresenter; 
//# sourceMappingURL=ProfilePresenter.js.map