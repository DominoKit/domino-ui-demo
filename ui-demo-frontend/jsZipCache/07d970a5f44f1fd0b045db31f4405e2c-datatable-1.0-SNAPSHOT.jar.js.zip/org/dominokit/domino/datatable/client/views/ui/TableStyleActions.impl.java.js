/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.$LambdaAdaptor$5$impl');
let Action = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action$impl');
let Condition = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class TableStyleActions extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {DataTable<?>} */
    this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_;
  }
  
  /**
   * Factory method corresponding to constructor 'TableStyleActions(DataTable)'.
   * @param {DataTable<?>} dataTable
   * @return {!TableStyleActions}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    TableStyleActions.$clinit();
    let $instance = new TableStyleActions();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions__org_dominokit_domino_ui_datatable_DataTable(dataTable);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'TableStyleActions(DataTable)'.
   * @param {DataTable<?>} dataTable
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_datatable_client_views_ui_TableStyleActions();
    this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_ = dataTable;
    this.m_init___$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_init___$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions() {
    let /** DataTable<?> */ $$qualifier0, /** DataTable<?> */ $$qualifier1, /** DataTable<?> */ $$qualifier2, /** DataTable<?> */ $$qualifier3, /** DataTable<?> */ $$qualifier4, /** DataTable<?> */ $$qualifier5, /** DataTable<?> */ $$qualifier6, /** DataTable<?> */ $$qualifier7, /** DataTable<?> */ $$qualifier8, /** DataTable<?> */ $$qualifier9, /** DataTable<?> */ $$qualifier10;
    let condenseAnchor = this.m_createButton__java_lang_String__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions("Condense", "Expand", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_line_weight__(), Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_format_line_spacing__(), ($$qualifier0 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier0.m_condense__();
    }))), ($$qualifier1 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier1.m_expand__();
    }))), ($$qualifier2 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Condition.$adapt((() =>{
      return $$qualifier2.m_isCondensed__();
    }))));
    let strippedAnchor = this.m_createButton__java_lang_String__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions("No Stripes", "Stripped", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_power_input__(), Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_drag_handle__(), ($$qualifier3 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier3.m_striped__();
    }))), ($$qualifier4 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier4.m_noStripes__();
    }))), ($$qualifier5 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Condition.$adapt((() =>{
      return $$qualifier5.m_isStriped__();
    }))));
    let borderedAnchor = this.m_createButton__java_lang_String__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions("No Borders", "Borders", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_border_vertical__(), Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_border_clear__(), ($$qualifier6 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier6.m_bordered__();
    }))), ($$qualifier7 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier7.m_noBorder__();
    }))), ($$qualifier8 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Condition.$adapt((() =>{
      return $$qualifier8.m_isBordered__();
    }))));
    let hoveredAnchor = this.m_createButton__java_lang_String__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions("No Hover", "Hovered", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_blur_off__(), Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_blur_on__(), ($$qualifier9 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier9.m_noHover__();
    }))), ($$qualifier10 = this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_, Action.$adapt((() =>{
      $$qualifier10.m_hovered__();
    }))), Condition.$adapt((() =>{
      return !this.f_dataTable__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_.m_isHoverable__();
    })));
    this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_.m_appendChild__elemental2_dom_Node(condenseAnchor);
    this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_.m_appendChild__elemental2_dom_Node(strippedAnchor);
    this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_.m_appendChild__elemental2_dom_Node(borderedAnchor);
    this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_.m_appendChild__elemental2_dom_Node(hoveredAnchor);
  }
  
  /**
   * @param {?string} initialTooltip
   * @param {?string} toggeledTooltip
   * @param {Icon} initialIcon
   * @param {Icon} toggeledIcon
   * @param {Action} initialAction
   * @param {Action} toggeledAction
   * @param {Condition} condition
   * @return {HTMLAnchorElement}
   * @public
   */
  m_createButton__java_lang_String__java_lang_String__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_ui_icons_Icon__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$p_org_dominokit_domino_datatable_client_views_ui_TableStyleActions(initialTooltip, toggeledTooltip, initialIcon, toggeledIcon, initialAction, toggeledAction, condition) {
    /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(initialIcon.m_clickable__(), Icon)).m_setToggleIcon__org_dominokit_domino_ui_icons_BaseIcon(toggeledIcon), Icon)).m_setTooltip__java_lang_String(initialTooltip), Icon)).m_toggleOnClick__boolean(true), Icon)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Icon> */ arg0) =>{
      arg0.m_pullRight__();
    }))), Icon)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Icon */ icon) =>{
      icon.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$5(((/** Event */ evt) =>{
        if (condition.m_check__()) {
          toggeledAction.m_execute__();
          icon.m_setTooltip__java_lang_String(initialTooltip);
        } else {
          initialAction.m_execute__();
          icon.m_setTooltip__java_lang_String(toggeledTooltip);
        }
      })));
    })));
    return /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(initialIcon), HtmlContentBuilder)).m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return /**@type {Row__12} */ ($Casts.$to(/**@type {Style<HTMLDivElement, Row__12>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_addColumn__org_dominokit_domino_ui_grid_Column(this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_), Row__12)))).m_get__(), Row__12)).m_asElement__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_datatable_client_views_ui_TableStyleActions() {
    this.f_column__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_ = Column.m_span12__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TableStyleActions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TableStyleActions);
  }
  
  /**
   * @public
   */
  static $clinit() {
    TableStyleActions.$clinit = function() {};
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.$LambdaAdaptor$5$impl');
    Action = goog.module.get('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action$impl');
    Condition = goog.module.get('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(TableStyleActions, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.TableStyleActions'));


IsElement.$markImplementor(TableStyleActions);


exports = TableStyleActions; 
//# sourceMappingURL=TableStyleActions.js.map