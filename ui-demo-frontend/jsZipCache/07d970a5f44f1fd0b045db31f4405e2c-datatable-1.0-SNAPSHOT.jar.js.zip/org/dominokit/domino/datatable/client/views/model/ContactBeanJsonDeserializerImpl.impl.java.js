/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$13$impl');
let $14 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$14$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$9$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<Contact>}
  */
class ContactBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactBeanJsonDeserializerImpl()'.
   * @return {!ContactBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    ContactBeanJsonDeserializerImpl.$clinit();
    let $instance = new ContactBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(Contact);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<Contact>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<Contact, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<Contact, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("index", $2.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("active", $3.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("balance", $4.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("picture", $5.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("age", $6.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("eyeColor", $7.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("name", $8.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("gender", $9.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("company", $10.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("email", $11.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("phone", $12.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("address", $13.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    map.m_put__java_lang_String__java_lang_Object("about", $14.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    $1 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$13$impl');
    $14 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$14$impl');
    $2 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$9$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl'));




exports = ContactBeanJsonDeserializerImpl; 
//# sourceMappingURL=ContactBeanJsonDeserializerImpl.js.map