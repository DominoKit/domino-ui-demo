/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$1.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.$1$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');

let Collection = goog.forwardDeclare('java.util.Collection$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$impl');
let ContactList = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
let ContactListBeanJsonSerializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$impl');
let JsonSerializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializationContext$impl');
let JsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonSerializer$impl');
let CollectionJsonSerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.CollectionJsonSerializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertySerializer<ContactList, List<Contact>>}
  */
class $1 extends BeanPropertySerializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactListBeanJsonSerializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl_1;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertySerializer(ContactListBeanJsonSerializerImpl, String)'.
   * @param {ContactListBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {!$1}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    $1.$clinit();
    let $instance = new $1();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl_1__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl__java_lang_String($outer_this, $_0);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertySerializer(ContactListBeanJsonSerializerImpl, String)'.
   * @param {ContactListBeanJsonSerializerImpl} $outer_this
   * @param {?string} $_0
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl_1__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl__java_lang_String($outer_this, $_0) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl_1 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_ser_bean_BeanPropertySerializer__java_lang_String($_0);
  }
  
  /**
   * @override
   * @return {JsonSerializer<?>}
   * @public
   */
  m_newSerializer__() {
    return /**@type {CollectionJsonSerializer<Collection<*>, ?>} */ (CollectionJsonSerializer.m_newInstance__org_dominokit_jacksonapt_JsonSerializer(ContactBeanJsonSerializerImpl.$create__()));
  }
  
  /**
   * @param {ContactList} bean
   * @param {JsonSerializationContext} ctx
   * @return {List<Contact>}
   * @public
   */
  m_getValue__org_dominokit_domino_datatable_client_views_model_ContactList__org_dominokit_jacksonapt_JsonSerializationContext(bean, ctx) {
    return bean.m_getContacts__();
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {JsonSerializationContext} arg1
   * @return {List<Contact>}
   * @public
   */
  m_getValue__java_lang_Object__org_dominokit_jacksonapt_JsonSerializationContext(arg0, arg1) {
    return this.m_getValue__org_dominokit_domino_datatable_client_views_model_ContactList__org_dominokit_jacksonapt_JsonSerializationContext(/**@type {ContactList} */ ($Casts.$to(arg0, ContactList)), arg1);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $1;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $1);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $1.$clinit = function() {};
    ContactBeanJsonSerializerImpl = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$impl');
    ContactList = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
    CollectionJsonSerializer = goog.module.get('org.dominokit.jacksonapt.ser.CollectionJsonSerializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertySerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($1, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$1'));




exports = $1; 
//# sourceMappingURL=ContactListBeanJsonSerializerImpl$1.js.map