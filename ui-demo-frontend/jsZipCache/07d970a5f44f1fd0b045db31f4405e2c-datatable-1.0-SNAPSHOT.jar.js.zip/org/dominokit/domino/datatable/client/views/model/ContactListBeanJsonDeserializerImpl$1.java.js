/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _InstanceBuilder = goog.require('org.dominokit.jacksonapt.deser.bean.InstanceBuilder');
const _Map = goog.require('java.util.Map');
const _ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList');
const _ContactListBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl');
const _JsonDeserializationContext = goog.require('org.dominokit.jacksonapt.JsonDeserializationContext');
const _JsonDeserializerParameters = goog.require('org.dominokit.jacksonapt.JsonDeserializerParameters');
const _HasDeserializerAndParameters = goog.require('org.dominokit.jacksonapt.deser.bean.HasDeserializerAndParameters');
const _Instance = goog.require('org.dominokit.jacksonapt.deser.bean.Instance');
const _MapLike = goog.require('org.dominokit.jacksonapt.deser.bean.MapLike');
const _JsonReader = goog.require('org.dominokit.jacksonapt.stream.JsonReader');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$1$impl');
exports = $1;
 