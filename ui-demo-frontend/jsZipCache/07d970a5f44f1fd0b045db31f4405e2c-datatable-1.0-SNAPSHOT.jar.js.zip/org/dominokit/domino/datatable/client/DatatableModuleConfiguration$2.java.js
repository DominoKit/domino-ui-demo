/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.DatatableModuleConfiguration$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.DatatableModuleConfiguration.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _LazyViewLoader = goog.require('org.dominokit.domino.api.client.mvp.view.LazyViewLoader');
const _View = goog.require('org.dominokit.domino.api.client.mvp.view.View');
const _DatatableModuleConfiguration = goog.require('org.dominokit.domino.datatable.client.DatatableModuleConfiguration');
const _DataTableViewImpl = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.datatable.client.DatatableModuleConfiguration.$2$impl');
exports = $2;
 