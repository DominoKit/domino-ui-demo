/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ContactList = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.$1$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<ContactList>}
  */
class ContactListBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactListBeanJsonSerializerImpl()'.
   * @return {!ContactListBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    ContactListBeanJsonSerializerImpl.$clinit();
    let $instance = new ContactListBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactListBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(ContactList);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([1], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonSerializerImpl__java_lang_String(this, "contacts"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactListBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactListBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactListBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ContactList = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
    $1 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.$1$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactListBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl'));




exports = ContactListBeanJsonSerializerImpl; 
//# sourceMappingURL=ContactListBeanJsonSerializerImpl.js.map