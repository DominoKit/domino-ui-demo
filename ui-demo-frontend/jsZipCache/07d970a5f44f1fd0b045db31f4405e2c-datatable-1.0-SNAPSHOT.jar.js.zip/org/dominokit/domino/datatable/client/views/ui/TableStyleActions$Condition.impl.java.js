/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Condition.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition.$LambdaAdaptor$impl');


/**
 * @interface
 */
class Condition {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_check__() {
  }
  
  /**
   * @param {?function():boolean} fn
   * @return {Condition}
   * @public
   */
  static $adapt(fn) {
    Condition.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Condition.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Condition, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Condition'));


Condition.$markImplementor(/** @type {Function} */ (Condition));


exports = Condition; 
//# sourceMappingURL=TableStyleActions$Condition.js.map