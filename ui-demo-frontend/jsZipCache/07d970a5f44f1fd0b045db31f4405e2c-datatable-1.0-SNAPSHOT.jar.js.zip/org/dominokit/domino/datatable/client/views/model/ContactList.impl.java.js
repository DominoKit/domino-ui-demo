/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactList.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactList$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactList__MapperImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl$impl');


class ContactList extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {List<Contact>} */
    this.f_contacts__org_dominokit_domino_datatable_client_views_model_ContactList_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContactList()'.
   * @return {!ContactList}
   * @public
   */
  static $create__() {
    ContactList.$clinit();
    let $instance = new ContactList();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactList__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactList()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactList__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {List<Contact>}
   * @public
   */
  m_getContacts__() {
    return this.f_contacts__org_dominokit_domino_datatable_client_views_model_ContactList_;
  }
  
  /**
   * @param {List<Contact>} contacts
   * @return {void}
   * @public
   */
  m_setContacts__java_util_List(contacts) {
    this.f_contacts__org_dominokit_domino_datatable_client_views_model_ContactList_ = contacts;
  }
  
  /**
   * @return {ContactList__MapperImpl}
   * @public
   */
  static get f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList() {
    return (ContactList.$clinit(), ContactList.$f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList);
  }
  
  /**
   * @param {ContactList__MapperImpl} value
   * @return {void}
   * @public
   */
  static set f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList(value) {
    (ContactList.$clinit(), ContactList.$f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactList;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactList);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactList.$clinit = function() {};
    ContactList__MapperImpl = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl$impl');
    j_l_Object.$clinit();
    ContactList.$f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList = ContactList__MapperImpl.$create__();
  }
  
  
};

$Util.$setClassMetadata(ContactList, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactList'));


/** @private {ContactList__MapperImpl} */
ContactList.$f_MAPPER__org_dominokit_domino_datatable_client_views_model_ContactList;




exports = ContactList; 
//# sourceMappingURL=ContactList.js.map