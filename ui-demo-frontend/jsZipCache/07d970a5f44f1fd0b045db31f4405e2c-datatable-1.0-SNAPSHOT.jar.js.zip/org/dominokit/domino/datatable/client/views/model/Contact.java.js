/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.Contact.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.Contact');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Double = goog.require('java.lang.Double');
const _j_l_String = goog.require('java.lang.String');
const _EyeColor = goog.require('org.dominokit.domino.datatable.client.views.model.EyeColor');
const _Gender = goog.require('org.dominokit.domino.datatable.client.views.model.Gender');


// Re-exports the implementation.
var Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact$impl');
exports = Contact;
 