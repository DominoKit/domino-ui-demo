/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _PresenterCommand = goog.require('org.dominokit.domino.api.client.request.PresenterCommand');
const _DatatablePresenter = goog.require('org.dominokit.domino.datatable.client.presenters.DatatablePresenter');


// Re-exports the implementation.
var DatatablePresenterCommand = goog.require('org.dominokit.domino.datatable.client.presenters.DatatablePresenterCommand$impl');
exports = DatatablePresenterCommand;
 