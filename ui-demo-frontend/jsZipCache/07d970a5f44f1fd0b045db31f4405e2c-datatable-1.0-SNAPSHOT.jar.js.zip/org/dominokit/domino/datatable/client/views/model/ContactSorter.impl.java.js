/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactSorter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactSorter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RecordsSorter = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter$impl');

let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Comparator = goog.forwardDeclare('java.util.Comparator$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let ToDoubleFunction = goog.forwardDeclare('java.util.function.ToDoubleFunction$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let SortDirection = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {RecordsSorter<Contact>}
  */
class ContactSorter extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactSorter()'.
   * @return {!ContactSorter}
   * @public
   */
  static $create__() {
    ContactSorter.$clinit();
    let $instance = new ContactSorter();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactSorter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactSorter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactSorter__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {?string} sortBy
   * @param {SortDirection} sortDirection
   * @return {Comparator<Contact>}
   * @public
   */
  m_onSortChange__java_lang_String__org_dominokit_domino_ui_datatable_plugins_SortDirection(sortBy, sortDirection) {
    if (j_l_String.m_equals__java_lang_String__java_lang_Object("firstName", sortBy) || j_l_String.m_equals__java_lang_String__java_lang_Object("*", sortBy)) {
      if ($Objects.m_equals__java_lang_Object__java_lang_Object(SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection, sortDirection)) {
        return /**@type {Comparator<Contact>} */ (Comparator.m_comparing__java_util_function_Function(j_u_function_Function.$adapt(((/** Contact */ arg0) =>{
          return arg0.m_getName__();
        }))));
      } else {
        return Comparator.$adapt(((/** Contact */ o1, /** Contact */ o2) =>{
          return j_l_String.m_compareTo__java_lang_String__java_lang_String(o2.m_getName__(), o1.m_getName__());
        }));
      }
    }
    if (j_l_String.m_equals__java_lang_String__java_lang_Object("balance", sortBy)) {
      if ($Objects.m_equals__java_lang_Object__java_lang_Object(SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection, sortDirection)) {
        return /**@type {Comparator<Contact>} */ (Comparator.m_comparingDouble__java_util_function_ToDoubleFunction(ToDoubleFunction.$adapt(((/** Contact */ arg0$1$) =>{
          return arg0$1$.m_getDoubleBalance__();
        }))));
      } else {
        return Comparator.$adapt(((/** Contact */ o1$1$, /** Contact */ o2$1$) =>{
          return Double.m_compare__double__double(o2$1$.m_getDoubleBalance__(), o1$1$.m_getDoubleBalance__());
        }));
      }
    }
    if (j_l_String.m_equals__java_lang_String__java_lang_Object("id", sortBy)) {
      if ($Objects.m_equals__java_lang_Object__java_lang_Object(SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection, sortDirection)) {
        return /**@type {Comparator<Contact>} */ (Comparator.m_comparingDouble__java_util_function_ToDoubleFunction(ToDoubleFunction.$adapt(((/** Contact */ arg0$2$) =>{
          return arg0$2$.m_getIndex__();
        }))));
      } else {
        return Comparator.$adapt(((/** Contact */ o1$2$, /** Contact */ o2$2$) =>{
          return Double.m_compare__double__double(o2$2$.m_getIndex__(), o1$2$.m_getIndex__());
        }));
      }
    }
    return Comparator.$adapt(((/** Contact */ o1$3$, /** Contact */ o2$3$) =>{
      return 0;
    }));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactSorter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactSorter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactSorter.$clinit = function() {};
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Comparator = goog.module.get('java.util.Comparator$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    ToDoubleFunction = goog.module.get('java.util.function.ToDoubleFunction$impl');
    SortDirection = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactSorter, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactSorter'));


RecordsSorter.$markImplementor(ContactSorter);


exports = ContactSorter; 
//# sourceMappingURL=ContactSorter.js.map