/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.AbstractBeanJsonDeserializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let ContactList = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$1$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$2$impl');
let JacksonContextProvider = goog.forwardDeclare('org.dominokit.jacksonapt.JacksonContextProvider$impl');
let BeanPropertyDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');
let InstanceBuilder = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.InstanceBuilder$impl');
let MapLike = goog.forwardDeclare('org.dominokit.jacksonapt.deser.bean.MapLike$impl');


/**
 * @extends {AbstractBeanJsonDeserializer<ContactList>}
  */
class ContactListBeanJsonDeserializerImpl extends AbstractBeanJsonDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactListBeanJsonDeserializerImpl()'.
   * @return {!ContactListBeanJsonDeserializerImpl}
   * @public
   */
  static $create__() {
    ContactListBeanJsonDeserializerImpl.$clinit();
    let $instance = new ContactListBeanJsonDeserializerImpl();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonDeserializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactListBeanJsonDeserializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonDeserializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_deser_bean_AbstractBeanJsonDeserializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getDeserializedType__() {
    return Class.$get(ContactList);
  }
  
  /**
   * @override
   * @return {InstanceBuilder<ContactList>}
   * @public
   */
  m_initInstanceBuilder__() {
    let deserializers = null;
    return $1.$create__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonDeserializerImpl__org_dominokit_jacksonapt_deser_bean_MapLike(this, deserializers);
  }
  
  /**
   * @override
   * @return {MapLike<BeanPropertyDeserializer<ContactList, ?>>}
   * @public
   */
  m_initDeserializers__() {
    let map = /**@type {MapLike<BeanPropertyDeserializer<ContactList, ?>>} */ (JacksonContextProvider.m_get__().m_mapLikeFactory__().m_make__());
    map.m_put__java_lang_String__java_lang_Object("contacts", $2.$create__org_dominokit_domino_datatable_client_views_model_ContactListBeanJsonDeserializerImpl(this));
    return map;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactListBeanJsonDeserializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactListBeanJsonDeserializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactListBeanJsonDeserializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    ContactList = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactList$impl');
    $1 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$1$impl');
    $2 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl.$2$impl');
    JacksonContextProvider = goog.module.get('org.dominokit.jacksonapt.JacksonContextProvider$impl');
    AbstractBeanJsonDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactListBeanJsonDeserializerImpl, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl'));




exports = ContactListBeanJsonDeserializerImpl; 
//# sourceMappingURL=ContactListBeanJsonDeserializerImpl.js.map