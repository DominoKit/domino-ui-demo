/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.Contact.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.Contact$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let EyeColor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.EyeColor$impl');
let Gender = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Gender$impl');


class Contact extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_index__org_dominokit_domino_datatable_client_views_model_Contact_ = 0;
    /** @public {boolean} */
    this.f_active__org_dominokit_domino_datatable_client_views_model_Contact_ = false;
    /** @public {?string} */
    this.f_balance__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_picture__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {number} */
    this.f_age__org_dominokit_domino_datatable_client_views_model_Contact_ = 0;
    /** @public {EyeColor} */
    this.f_eyeColor__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {Gender} */
    this.f_gender__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_company__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_email__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_phone__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_address__org_dominokit_domino_datatable_client_views_model_Contact_;
    /** @public {?string} */
    this.f_about__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * Factory method corresponding to constructor 'Contact()'.
   * @return {!Contact}
   * @public
   */
  static $create__() {
    Contact.$clinit();
    let $instance = new Contact();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_Contact__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Contact()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_Contact__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * Factory method corresponding to constructor 'Contact(Contact)'.
   * @param {Contact} other
   * @return {!Contact}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_Contact(other) {
    Contact.$clinit();
    let $instance = new Contact();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_datatable_client_views_model_Contact(other);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Contact(Contact)'.
   * @param {Contact} other
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_Contact__org_dominokit_domino_datatable_client_views_model_Contact(other) {
    this.$ctor__java_lang_Object__();
    this.f_index__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_index__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_active__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_active__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_balance__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_balance__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_picture__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_picture__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_age__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_age__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_eyeColor__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_eyeColor__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_name__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_name__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_gender__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_gender__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_company__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_company__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_email__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_email__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_phone__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_phone__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_address__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_address__org_dominokit_domino_datatable_client_views_model_Contact_;
    this.f_about__org_dominokit_domino_datatable_client_views_model_Contact_ = other.f_about__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getIndex__() {
    return this.f_index__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {number} index
   * @return {void}
   * @public
   */
  m_setIndex__int(index) {
    this.f_index__org_dominokit_domino_datatable_client_views_model_Contact_ = index;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isActive__() {
    return this.f_active__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {boolean} active
   * @return {void}
   * @public
   */
  m_setActive__boolean(active) {
    this.f_active__org_dominokit_domino_datatable_client_views_model_Contact_ = active;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getBalance__() {
    return this.f_balance__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} balance
   * @return {void}
   * @public
   */
  m_setBalance__java_lang_String(balance) {
    this.f_balance__org_dominokit_domino_datatable_client_views_model_Contact_ = balance;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPicture__() {
    return this.f_picture__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} picture
   * @return {void}
   * @public
   */
  m_setPicture__java_lang_String(picture) {
    this.f_picture__org_dominokit_domino_datatable_client_views_model_Contact_ = picture;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getAge__() {
    return this.f_age__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {number} age
   * @return {void}
   * @public
   */
  m_setAge__short(age) {
    this.f_age__org_dominokit_domino_datatable_client_views_model_Contact_ = age;
  }
  
  /**
   * @return {EyeColor}
   * @public
   */
  m_getEyeColor__() {
    return this.f_eyeColor__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {EyeColor} eyeColor
   * @return {void}
   * @public
   */
  m_setEyeColor__org_dominokit_domino_datatable_client_views_model_EyeColor(eyeColor) {
    this.f_eyeColor__org_dominokit_domino_datatable_client_views_model_Contact_ = eyeColor;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_domino_datatable_client_views_model_Contact_ = name;
  }
  
  /**
   * @return {Gender}
   * @public
   */
  m_getGender__() {
    return this.f_gender__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {Gender} gender
   * @return {void}
   * @public
   */
  m_setGender__org_dominokit_domino_datatable_client_views_model_Gender(gender) {
    this.f_gender__org_dominokit_domino_datatable_client_views_model_Contact_ = gender;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getCompany__() {
    return this.f_company__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} company
   * @return {void}
   * @public
   */
  m_setCompany__java_lang_String(company) {
    this.f_company__org_dominokit_domino_datatable_client_views_model_Contact_ = company;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getEmail__() {
    return this.f_email__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} email
   * @return {void}
   * @public
   */
  m_setEmail__java_lang_String(email) {
    this.f_email__org_dominokit_domino_datatable_client_views_model_Contact_ = email;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPhone__() {
    return this.f_phone__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} phone
   * @return {void}
   * @public
   */
  m_setPhone__java_lang_String(phone) {
    this.f_phone__org_dominokit_domino_datatable_client_views_model_Contact_ = phone;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getAddress__() {
    return this.f_address__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} address
   * @return {void}
   * @public
   */
  m_setAddress__java_lang_String(address) {
    this.f_address__org_dominokit_domino_datatable_client_views_model_Contact_ = address;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getAbout__() {
    return this.f_about__org_dominokit_domino_datatable_client_views_model_Contact_;
  }
  
  /**
   * @param {?string} about
   * @return {void}
   * @public
   */
  m_setAbout__java_lang_String(about) {
    this.f_about__org_dominokit_domino_datatable_client_views_model_Contact_ = about;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getDoubleBalance__() {
    return Double.m_parseDouble__java_lang_String(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(this.m_getBalance__(), ",", ""), "$", ""));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "Contact{" + "index=" + this.f_index__org_dominokit_domino_datatable_client_views_model_Contact_ + ", name='" + j_l_String.m_valueOf__java_lang_Object(this.f_name__org_dominokit_domino_datatable_client_views_model_Contact_) + j_l_String.m_valueOf__char(39 /* '\'' */) + j_l_String.m_valueOf__char(125 /* '}' */);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Contact;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Contact);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Contact.$clinit = function() {};
    Double = goog.module.get('java.lang.Double$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(Contact, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.Contact'));




exports = Contact; 
//# sourceMappingURL=Contact.js.map