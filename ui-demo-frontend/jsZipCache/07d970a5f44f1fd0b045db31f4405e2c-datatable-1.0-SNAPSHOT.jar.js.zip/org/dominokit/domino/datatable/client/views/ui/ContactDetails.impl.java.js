/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.ContactDetails.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.ContactDetails$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactUiUtils = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let MediaObject = goog.forwardDeclare('org.dominokit.domino.ui.media.MediaObject$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EmptyContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class ContactDetails extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Row} */
    this.f_rowElement__org_dominokit_domino_datatable_client_views_ui_ContactDetails_;
    /** @public {CellInfo<Contact>} */
    this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContactDetails(CellInfo)'.
   * @param {CellInfo<Contact>} cell
   * @return {!ContactDetails}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell) {
    ContactDetails.$clinit();
    let $instance = new ContactDetails();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_ui_ContactDetails__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactDetails(CellInfo)'.
   * @param {CellInfo<Contact>} cell
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_ContactDetails__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_datatable_client_views_ui_ContactDetails();
    this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_ = cell;
    this.m_initDetails___$p_org_dominokit_domino_datatable_client_views_ui_ContactDetails();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDetails___$p_org_dominokit_domino_datatable_client_views_ui_ContactDetails() {
    let row = this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getTableRow__();
    let activeButton = SwitchButton.m_create__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color);
    activeButton.m_setValue__java_lang_Object(/**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_isActive__());
    activeButton.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ value) =>{
      /**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_setActive__boolean(Boolean.m_booleanValue__java_lang_Boolean(value));
      row.m_getCell__java_lang_String("status").m_updateCell__();
    })));
    this.f_rowElement__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(MediaObject.m_create__().m_setHeader__java_lang_String(/**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_getName__()).m_setLeftMedia__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {EmptyContentBuilder<HTMLImageElement>} */ ($Casts.$to(Elements.m_img__java_lang_String(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact)).m_getPicture__(), "gender", ContactUiUtils.m_getGenderIconName__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact)))), "index", ContactUiUtils.m_getAvatarIndex__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact))))).m_attr__java_lang_String__java_lang_String("width", "64"), EmptyContentBuilder)).m_attr__java_lang_String__java_lang_String("height", "64")), IsElement))).m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact)).m_getAbout__()))), Column))).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(ContactUiUtils.m_getEyeColorElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact))))).m_setPadding__java_lang_String("5px")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(ContactUiUtils.m_getGenderElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact))))).m_setPadding__java_lang_String("5px")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLDivElement, BlockHeader>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String(j_l_String.m_valueOf__java_lang_Object(/**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_getBalance__()) + "", "BALANCE").m_invert__())).m_setMarginTop__java_lang_String("30px")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(ContactUiUtils.m_getBalanceElement__org_dominokit_domino_datatable_client_views_model_Contact(/**@type {Contact} */ ($Casts.$to(this.f_cell__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_getRecord__(), Contact))))).m_setMarginTop__java_lang_String("5px")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLDivElement, BlockHeader>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("ACTIVE").m_appendChild__org_jboss_gwt_elemento_core_IsElement(activeButton))).m_setMarginTop__java_lang_String("30px")), Column))).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(/**@type {Column} */ ($Casts.$to(Column.m_span4__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLDivElement, BlockHeader>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String(j_l_String.m_valueOf__java_lang_Object(/**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_getCompany__()) + "", "COMPANY").m_invert__())).m_setMarginTop__java_lang_String("5px")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLDivElement, BlockHeader>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String(j_l_String.m_valueOf__java_lang_Object(/**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_getAddress__()) + "", "ADDRESS").m_invert__())).m_setMarginTop__java_lang_String("10px")), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Style<HTMLDivElement, BlockHeader>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String__java_lang_String(/**@type {Contact} */ ($Casts.$to(row.m_getRecord__(), Contact)).m_getAge__() + "", "AGE").m_invert__())).m_setMargin__java_lang_String("5px").m_setMarginTop__java_lang_String("30px")), Column)));
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_rowElement__org_dominokit_domino_datatable_client_views_ui_ContactDetails_.m_asElement__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_datatable_client_views_ui_ContactDetails() {
    this.f_rowElement__org_dominokit_domino_datatable_client_views_ui_ContactDetails_ = /**@type {Row} */ ($Casts.$to(Row.m_create__().m_style__().m_add__java_lang_String(Styles.f_margin_0__org_dominokit_domino_ui_style_Styles).m_get__(), Row));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactDetails;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactDetails);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactDetails.$clinit = function() {};
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    ContactUiUtils = goog.module.get('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    MediaObject = goog.module.get('org.dominokit.domino.ui.media.MediaObject$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EmptyContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactDetails, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.ContactDetails'));


IsElement.$markImplementor(ContactDetails);


exports = ContactDetails; 
//# sourceMappingURL=ContactDetails.js.map