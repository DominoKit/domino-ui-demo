/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Action.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action.$LambdaAdaptor$impl');


/**
 * @interface
 */
class Action {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_execute__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {Action}
   * @public
   */
  static $adapt(fn) {
    Action.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Action;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Action.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Action.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Action, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Action'));


Action.$markImplementor(/** @type {Function} */ (Action));


exports = Action; 
//# sourceMappingURL=TableStyleActions$Action.js.map