/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$2.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$2');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TopPanelPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _ContactsTopPanel = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel');
const _DataTableViewImpl = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableDataUpdatedEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $2 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$2$impl');
exports = $2;
 