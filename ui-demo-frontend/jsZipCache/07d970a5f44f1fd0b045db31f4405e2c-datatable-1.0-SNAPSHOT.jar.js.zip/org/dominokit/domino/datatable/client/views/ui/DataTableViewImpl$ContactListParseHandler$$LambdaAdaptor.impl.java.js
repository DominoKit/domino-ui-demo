/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$ContactListParseHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ContactListParseHandler = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');


/**
 * @implements {ContactListParseHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(List<Contact>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(List<Contact>):void} */
    this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$LambdaAdaptor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function(List<Contact>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$LambdaAdaptor__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {List<Contact>} arg0
   * @return {void}
   * @public
   */
  m_onContactsParsed__java_util_List(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_DataTableViewImpl_ContactListParseHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$ContactListParseHandler$$LambdaAdaptor'));


ContactListParseHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DataTableViewImpl$ContactListParseHandler$$LambdaAdaptor.js.map