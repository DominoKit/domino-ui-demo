/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractBeanJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$1$impl');
let $10 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$10$impl');
let $11 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$11$impl');
let $12 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$12$impl');
let $13 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$13$impl');
let $2 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$2$impl');
let $3 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$3$impl');
let $4 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$4$impl');
let $5 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$5$impl');
let $6 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$6$impl');
let $7 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$7$impl');
let $8 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$8$impl');
let $9 = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$9$impl');
let BeanPropertySerializer = goog.forwardDeclare('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {AbstractBeanJsonSerializer<Contact>}
  */
class ContactBeanJsonSerializerImpl extends AbstractBeanJsonSerializer {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ContactBeanJsonSerializerImpl()'.
   * @return {!ContactBeanJsonSerializerImpl}
   * @public
   */
  static $create__() {
    ContactBeanJsonSerializerImpl.$clinit();
    let $instance = new ContactBeanJsonSerializerImpl();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactBeanJsonSerializerImpl()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__() {
    this.$ctor__org_dominokit_jacksonapt_ser_bean_AbstractBeanJsonSerializer__();
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getSerializedType__() {
    return Class.$get(Contact);
  }
  
  /**
   * @override
   * @return {Array<BeanPropertySerializer>}
   * @public
   */
  m_initSerializers__() {
    let result = /**@type {!Array<BeanPropertySerializer>} */ ($Arrays.$create([13], BeanPropertySerializer));
    $Arrays.$set(result, 0, $1.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "index"));
    $Arrays.$set(result, 1, $2.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "active"));
    $Arrays.$set(result, 2, $3.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "balance"));
    $Arrays.$set(result, 3, $4.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "picture"));
    $Arrays.$set(result, 4, $5.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "age"));
    $Arrays.$set(result, 5, $6.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "eyeColor"));
    $Arrays.$set(result, 6, $7.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "name"));
    $Arrays.$set(result, 7, $8.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "gender"));
    $Arrays.$set(result, 8, $9.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "company"));
    $Arrays.$set(result, 9, $10.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "email"));
    $Arrays.$set(result, 10, $11.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "phone"));
    $Arrays.$set(result, 11, $12.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "address"));
    $Arrays.$set(result, 12, $13.$create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonSerializerImpl__java_lang_String(this, "about"));
    return result;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactBeanJsonSerializerImpl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactBeanJsonSerializerImpl);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactBeanJsonSerializerImpl.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    $1 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$1$impl');
    $10 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$10$impl');
    $11 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$11$impl');
    $12 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$12$impl');
    $13 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$13$impl');
    $2 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$2$impl');
    $3 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$3$impl');
    $4 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$4$impl');
    $5 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$5$impl');
    $6 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$6$impl');
    $7 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$7$impl');
    $8 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$8$impl');
    $9 = goog.module.get('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl.$9$impl');
    BeanPropertySerializer = goog.module.get('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    AbstractBeanJsonSerializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactBeanJsonSerializerImpl, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl'));




exports = ContactBeanJsonSerializerImpl; 
//# sourceMappingURL=ContactBeanJsonSerializerImpl.js.map