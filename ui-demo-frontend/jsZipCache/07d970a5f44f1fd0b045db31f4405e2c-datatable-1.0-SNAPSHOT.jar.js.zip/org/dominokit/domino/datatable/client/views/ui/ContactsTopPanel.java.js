/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _List = goog.require('java.util.List');
const _Predicate = goog.require('java.util.function.Predicate');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _Gender = goog.require('org.dominokit.domino.datatable.client.views.model.Gender');
const _TableDataUpdatedEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _InfoBox = goog.require('org.dominokit.domino.ui.infoboxes.InfoBox');
const _HoverEffect = goog.require('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var ContactsTopPanel = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel$impl');
exports = ContactsTopPanel;
 