/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.ContactDetails.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.ContactDetails');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _j_l_String = goog.require('java.lang.String');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _ContactUiUtils = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _MediaObject = goog.require('org.dominokit.domino.ui.media.MediaObject');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EmptyContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.EmptyContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ContactDetails = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactDetails$impl');
exports = ContactDetails;
 