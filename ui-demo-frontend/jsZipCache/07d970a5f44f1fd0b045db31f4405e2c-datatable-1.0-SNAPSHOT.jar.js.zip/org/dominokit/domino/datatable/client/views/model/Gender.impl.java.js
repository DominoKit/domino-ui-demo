/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.Gender.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.Gender$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Gender>}
  */
class Gender extends Enum {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Gender(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Gender}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Gender();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_Gender__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Gender(String, int)'.
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_Gender__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Gender}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Gender.$clinit();
    if ($Equality.$same(Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_, null)) {
      Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_ = $Enums.createMapFromValues(Gender.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_);
  }
  
  /**
   * @return {!Array<!Gender>}
   * @public
   */
  static m_values__() {
    Gender.$clinit();
    return /**@type {!Array<Gender>} */ ($Arrays.$init([Gender.$f_female__org_dominokit_domino_datatable_client_views_model_Gender, Gender.$f_male__org_dominokit_domino_datatable_client_views_model_Gender], Gender));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Gender} */ ($Casts.$to(arg0, Gender)));
  }
  
  /**
   * @return {!Gender}
   * @public
   */
  static get f_female__org_dominokit_domino_datatable_client_views_model_Gender() {
    return (Gender.$clinit(), Gender.$f_female__org_dominokit_domino_datatable_client_views_model_Gender);
  }
  
  /**
   * @param {!Gender} value
   * @return {void}
   * @public
   */
  static set f_female__org_dominokit_domino_datatable_client_views_model_Gender(value) {
    (Gender.$clinit(), Gender.$f_female__org_dominokit_domino_datatable_client_views_model_Gender = value);
  }
  
  /**
   * @return {!Gender}
   * @public
   */
  static get f_male__org_dominokit_domino_datatable_client_views_model_Gender() {
    return (Gender.$clinit(), Gender.$f_male__org_dominokit_domino_datatable_client_views_model_Gender);
  }
  
  /**
   * @param {!Gender} value
   * @return {void}
   * @public
   */
  static set f_male__org_dominokit_domino_datatable_client_views_model_Gender(value) {
    (Gender.$clinit(), Gender.$f_male__org_dominokit_domino_datatable_client_views_model_Gender = value);
  }
  
  /**
   * @return {Map<?string, !Gender>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_() {
    return (Gender.$clinit(), Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_);
  }
  
  /**
   * @param {Map<?string, !Gender>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_(value) {
    (Gender.$clinit(), Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Gender;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Gender);
  }
  
  /**
   * @public
   */
  static $clinit() {
    Gender.$clinit = function() {};
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
    Enum.$clinit();
    Gender.$f_female__org_dominokit_domino_datatable_client_views_model_Gender = Gender.$create__java_lang_String__int($Util.$makeEnumName("female"), Gender.$ordinal$f_female__org_dominokit_domino_datatable_client_views_model_Gender);
    Gender.$f_male__org_dominokit_domino_datatable_client_views_model_Gender = Gender.$create__java_lang_String__int($Util.$makeEnumName("male"), Gender.$ordinal$f_male__org_dominokit_domino_datatable_client_views_model_Gender);
    Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_ = null;
  }
  
  
};

$Util.$setClassMetadataForEnum(Gender, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.Gender'));


/** @private {!Gender} */
Gender.$f_female__org_dominokit_domino_datatable_client_views_model_Gender;


/** @private {!Gender} */
Gender.$f_male__org_dominokit_domino_datatable_client_views_model_Gender;


/** @private {Map<?string, !Gender>} */
Gender.$f_namesToValuesMap__org_dominokit_domino_datatable_client_views_model_Gender_;


/** @public {number} @const */
Gender.$ordinal$f_female__org_dominokit_domino_datatable_client_views_model_Gender = 0;


/** @public {number} @const */
Gender.$ordinal$f_male__org_dominokit_domino_datatable_client_views_model_Gender = 1;




exports = Gender; 
//# sourceMappingURL=Gender.js.map