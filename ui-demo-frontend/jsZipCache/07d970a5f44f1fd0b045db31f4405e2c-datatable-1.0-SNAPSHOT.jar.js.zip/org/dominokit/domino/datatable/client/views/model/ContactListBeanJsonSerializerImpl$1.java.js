/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BeanPropertySerializer = goog.require('org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer');
const _Collection = goog.require('java.util.Collection');
const _List = goog.require('java.util.List');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _ContactBeanJsonSerializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonSerializerImpl');
const _ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList');
const _ContactListBeanJsonSerializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl');
const _JsonSerializationContext = goog.require('org.dominokit.jacksonapt.JsonSerializationContext');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');
const _CollectionJsonSerializer = goog.require('org.dominokit.jacksonapt.ser.CollectionJsonSerializer');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl.$1$impl');
exports = $1;
 