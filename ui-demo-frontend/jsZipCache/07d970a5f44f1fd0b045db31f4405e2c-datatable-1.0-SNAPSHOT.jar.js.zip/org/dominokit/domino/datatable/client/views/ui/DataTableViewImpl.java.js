/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ComponentView = goog.require('org.dominokit.domino.componentcase.shared.extension.ComponentView');
const _DatatableView = goog.require('org.dominokit.domino.datatable.client.views.DatatableView');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLTableCellElement_$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Stream = goog.require('java.util.stream.Stream');
const _CodeCard = goog.require('org.dominokit.domino.componentcase.client.ui.views.CodeCard');
const _LinkToSourceCode = goog.require('org.dominokit.domino.componentcase.client.ui.views.LinkToSourceCode');
const _Contact = goog.require('org.dominokit.domino.datatable.client.views.model.Contact');
const _ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList');
const _ContactSearchFilter = goog.require('org.dominokit.domino.datatable.client.views.model.ContactSearchFilter');
const _ContactSorter = goog.require('org.dominokit.domino.datatable.client.views.model.ContactSorter');
const _Gender = goog.require('org.dominokit.domino.datatable.client.views.model.Gender');
const _ContactDetails = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactDetails');
const _ContactUiUtils = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactUiUtils');
const _ContactsTopPanel = goog.require('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel');
const _$1 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$1');
const _$2 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$2');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$3');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.$LambdaAdaptor$4');
const _ContactListParseHandler = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl.ContactListParseHandler');
const _TableStyleActions = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _CellStyler = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _SelectionChangeListener = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener');
const _TableConfig = goog.require('org.dominokit.domino.ui.datatable.TableConfig');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _SimplePaginationPlugin = goog.require('org.dominokit.domino.ui.datatable.events.SimplePaginationPlugin');
const _AdvancedPaginationPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.AdvancedPaginationPlugin');
const _BodyScrollPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin');
const _ColumnHeaderFilterPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin');
const _HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement');
const _HeaderBarPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin');
const _ClearSearch = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.ClearSearch');
const _SearchTableAction = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction');
const _RecordDetailsPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin');
const _RowMarkerPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin');
const _MarkerColor = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor');
const _ScrollingPaginationPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin');
const _SelectionPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin');
const _SortPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.SortPlugin');
const _BooleanHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.BooleanHeaderFilter');
const _DoubleHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DoubleHeaderFilter');
const _EnumHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter');
const _SelectHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.SelectHeaderFilter');
const _TextHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.TextHeaderFilter');
const _LocalListDataStore = goog.require('org.dominokit.domino.ui.datatable.store.LocalListDataStore');
const _LocalListScrollingDataSource = goog.require('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');
const _Response = goog.require('org.dominokit.rest.shared.Response');
const _RestfulRequest = goog.require('org.dominokit.rest.shared.RestfulRequest');
const _SuccessHandler = goog.require('org.dominokit.rest.shared.RestfulRequest.SuccessHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DataTableViewImpl = goog.require('org.dominokit.domino.datatable.client.views.ui.DataTableViewImpl$impl');
exports = DataTableViewImpl;
 