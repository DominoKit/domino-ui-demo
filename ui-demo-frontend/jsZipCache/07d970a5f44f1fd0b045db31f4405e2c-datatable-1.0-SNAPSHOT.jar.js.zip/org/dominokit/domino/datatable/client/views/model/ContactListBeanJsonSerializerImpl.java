package org.dominokit.domino.datatable.client.views.model;

import java.lang.Class;
import java.lang.Override;
import java.util.List;
import org.dominokit.jacksonapt.JsonSerializationContext;
import org.dominokit.jacksonapt.JsonSerializer;
import org.dominokit.jacksonapt.ser.CollectionJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.AbstractBeanJsonSerializer;
import org.dominokit.jacksonapt.ser.bean.BeanPropertySerializer;

public final class ContactListBeanJsonSerializerImpl extends AbstractBeanJsonSerializer<ContactList> {
  public ContactListBeanJsonSerializerImpl() {
  }

  @Override
  public Class getSerializedType() {
    return ContactList.class;
  }

  @Override
  protected BeanPropertySerializer[] initSerializers() {
    BeanPropertySerializer[] result = new BeanPropertySerializer[1];
    result[0] = new BeanPropertySerializer<ContactList, List<Contact>>("contacts") {
      @Override
      protected JsonSerializer<?> newSerializer() {
        return CollectionJsonSerializer.newInstance(new ContactBeanJsonSerializerImpl());
      }

      @Override
      public List<Contact> getValue(ContactList bean, JsonSerializationContext ctx) {
        return bean.getContacts();
      }
    };
    return result;
  }
}
