/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$2.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl.$2$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BeanPropertyDeserializer = goog.require('org.dominokit.jacksonapt.deser.bean.BeanPropertyDeserializer$impl');

let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let ContactBeanJsonDeserializerImpl = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$impl');
let JsonDeserializationContext = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializationContext$impl');
let JsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.JsonDeserializer$impl');
let IntegerJsonDeserializer = goog.forwardDeclare('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BeanPropertyDeserializer<Contact, Integer>}
  */
class $2 extends BeanPropertyDeserializer {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ContactBeanJsonDeserializerImpl} */
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_2;
  }
  
  /**
   * Factory method corresponding to constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {!$2}
   * @public
   */
  static $create__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    $2.$clinit();
    let $instance = new $2();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_2__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'new BeanPropertyDeserializer(ContactBeanJsonDeserializerImpl)'.
   * @param {ContactBeanJsonDeserializerImpl} $outer_this
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_2__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl($outer_this) {
    this.f_$outer_this__org_dominokit_domino_datatable_client_views_model_ContactBeanJsonDeserializerImpl_2 = $outer_this;
    this.$ctor__org_dominokit_jacksonapt_deser_bean_BeanPropertyDeserializer__();
  }
  
  /**
   * @override
   * @return {JsonDeserializer<?>}
   * @public
   */
  m_newDeserializer__() {
    return IntegerJsonDeserializer.m_getInstance__();
  }
  
  /**
   * @param {Contact} bean
   * @param {Integer} value
   * @param {JsonDeserializationContext} ctx
   * @return {void}
   * @public
   */
  m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_Integer__org_dominokit_jacksonapt_JsonDeserializationContext(bean, value, ctx) {
    bean.m_setIndex__int(value.m_intValue__());
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @param {*} arg1
   * @param {JsonDeserializationContext} arg2
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object__java_lang_Object__org_dominokit_jacksonapt_JsonDeserializationContext(arg0, arg1, arg2) {
    this.m_setValue__org_dominokit_domino_datatable_client_views_model_Contact__java_lang_Integer__org_dominokit_jacksonapt_JsonDeserializationContext(/**@type {Contact} */ ($Casts.$to(arg0, Contact)), /**@type {Integer} */ ($Casts.$to(arg1, Integer)), arg2);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $2;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $2);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $2.$clinit = function() {};
    Integer = goog.module.get('java.lang.Integer$impl');
    Contact = goog.module.get('org.dominokit.domino.datatable.client.views.model.Contact$impl');
    IntegerJsonDeserializer = goog.module.get('org.dominokit.jacksonapt.deser.BaseNumberJsonDeserializer.IntegerJsonDeserializer$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    BeanPropertyDeserializer.$clinit();
  }
  
  
};

$Util.$setClassMetadata($2, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.model.ContactBeanJsonDeserializerImpl$2'));




exports = $2; 
//# sourceMappingURL=ContactBeanJsonDeserializerImpl$2.js.map