/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractObjectMapper = goog.require('org.dominokit.jacksonapt.AbstractObjectMapper');
const _ContactList = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList');
const _ContactListBeanJsonDeserializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonDeserializerImpl');
const _ContactListBeanJsonSerializerImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactListBeanJsonSerializerImpl');
const _JsonDeserializer = goog.require('org.dominokit.jacksonapt.JsonDeserializer');
const _JsonSerializer = goog.require('org.dominokit.jacksonapt.JsonSerializer');


// Re-exports the implementation.
var ContactList__MapperImpl = goog.require('org.dominokit.domino.datatable.client.views.model.ContactList_MapperImpl$impl');
exports = ContactList__MapperImpl;
 