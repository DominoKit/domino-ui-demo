/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Contact = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Contact$impl');
let Gender = goog.forwardDeclare('org.dominokit.domino.datatable.client.views.model.Gender$impl');
let TableDataUpdatedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let InfoBox = goog.forwardDeclare('org.dominokit.domino.ui.infoboxes.InfoBox$impl');
let HoverEffect = goog.forwardDeclare('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @template C_T
 * @implements {IsElement<HTMLElement>}
  */
class ContactsTopPanel extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {InfoBox} */
    this.f_loaded_items_count__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
    /** @public {InfoBox} */
    this.f_totalItemsCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
    /** @public {InfoBox} */
    this.f_femaleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
    /** @public {InfoBox} */
    this.f_maleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
    /** @public {InfoBox} */
    this.f_goodCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
    /** @public {InfoBox} */
    this.f_dangerCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
    /** @public {Row} */
    this.f_row__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContactsTopPanel()'.
   * @template C_T
   * @return {!ContactsTopPanel<C_T>}
   * @public
   */
  static $create__() {
    ContactsTopPanel.$clinit();
    let $instance = new ContactsTopPanel();
    $instance.$ctor__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContactsTopPanel()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel();
    this.f_femaleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getIconElement__().m_style__().m_setProperty__java_lang_String__java_lang_String("bottom", "15px");
    this.f_maleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getIconElement__().m_style__().m_setProperty__java_lang_String__java_lang_String("bottom", "15px");
  }
  
  /**
   * @param {TableDataUpdatedEvent<Contact>} event
   * @return {void}
   * @public
   */
  m_update__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent(event) {
    this.f_loaded_items_count__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getValueElement__().m_setTextContent__java_lang_String(event.m_getData__().size() + "");
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_row__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_asElement__();
  }
  
  /**
   * @param {List<Contact>} contacts
   * @return {void}
   * @public
   */
  m_update__java_util_List(contacts) {
    this.f_totalItemsCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getValueElement__().m_setTextContent__java_lang_String(contacts.size() + "");
    let males = contacts.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Contact */ c) =>{
      return $Objects.m_equals__java_lang_Object__java_lang_Object(Gender.f_male__org_dominokit_domino_datatable_client_views_model_Gender, c.m_getGender__());
    }))).m_count__();
    let females = contacts.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Contact */ c$1$) =>{
      return $Objects.m_equals__java_lang_Object__java_lang_Object(Gender.f_female__org_dominokit_domino_datatable_client_views_model_Gender, c$1$.m_getGender__());
    }))).m_count__();
    let goods = contacts.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Contact */ c$2$) =>{
      return c$2$.m_getDoubleBalance__() >= 2000;
    }))).m_count__();
    let bads = contacts.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Contact */ c$3$) =>{
      return c$3$.m_getDoubleBalance__() < 2000;
    }))).m_count__();
    this.f_femaleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getValueElement__().m_setTextContent__java_lang_String(females + "");
    this.f_maleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getValueElement__().m_setTextContent__java_lang_String(males + "");
    this.f_goodCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getValueElement__().m_setTextContent__java_lang_String(goods + "");
    this.f_dangerCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_.m_getValueElement__().m_setTextContent__java_lang_String(bads + "");
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel() {
    this.f_loaded_items_count__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = InfoBox.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_timelapse__(), "LOADED ITEMS COUNT", "0").m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_removeShadow__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
    this.f_totalItemsCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = InfoBox.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_timelapse__(), "TOTAL ITEMS COUNT", "0").m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color).m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_removeShadow__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
    this.f_femaleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = InfoBox.m_create__elemental2_dom_HTMLElement__java_lang_String__java_lang_String(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas fa-female fa-lg"], j_l_String))), HtmlContentBuilder)).m_asElement__(), "FEMALES", "0").m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color).m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_removeShadow__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
    this.f_maleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = InfoBox.m_create__elemental2_dom_HTMLElement__java_lang_String__java_lang_String(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_i__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["fas fa-male fa-lg"], j_l_String))), HtmlContentBuilder)).m_asElement__(), "MALES", "0").m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color).m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_removeShadow__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
    this.f_goodCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = InfoBox.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_timelapse__(), "GOOD BALANCE ", "0").m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color).m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_removeShadow__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
    this.f_dangerCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = InfoBox.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_timelapse__(), "LOW BALANCE", "0").m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color).m_setIconBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_WHITE__org_dominokit_domino_ui_style_Color).m_removeShadow__().m_setHoverEffect__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect(HoverEffect.f_ZOOM__org_dominokit_domino_ui_infoboxes_InfoBox_HoverEffect);
    this.f_row__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_ = /**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_condenced__(), Row__12)).m_style__().m_setMarginBottom__java_lang_String("0px").m_setMarginLeft__java_lang_String("0px").m_setMarginRight__java_lang_String("0px").m_get__(), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_loaded_items_count__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_totalItemsCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_femaleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_maleCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_goodCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_), Column))), Row__12)).m_addColumn__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(Column.m_span2__().m_condenced__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_dangerCount__org_dominokit_domino_datatable_client_views_ui_ContactsTopPanel_), Column)));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContactsTopPanel;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContactsTopPanel);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContactsTopPanel.$clinit = function() {};
    j_l_String = goog.module.get('java.lang.String$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Gender = goog.module.get('org.dominokit.domino.datatable.client.views.model.Gender$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    InfoBox = goog.module.get('org.dominokit.domino.ui.infoboxes.InfoBox$impl');
    HoverEffect = goog.module.get('org.dominokit.domino.ui.infoboxes.InfoBox.HoverEffect$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContactsTopPanel, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.ContactsTopPanel'));


IsElement.$markImplementor(ContactsTopPanel);


exports = ContactsTopPanel; 
//# sourceMappingURL=ContactsTopPanel.js.map