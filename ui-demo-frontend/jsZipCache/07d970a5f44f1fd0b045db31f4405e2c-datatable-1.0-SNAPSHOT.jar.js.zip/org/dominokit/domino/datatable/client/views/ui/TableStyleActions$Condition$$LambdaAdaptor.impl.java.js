/**
 * @fileoverview transpiled from org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Condition$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Condition = goog.require('org.dominokit.domino.datatable.client.views.ui.TableStyleActions.Condition$impl');


/**
 * @implements {Condition}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * JsConstructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():boolean} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():boolean} */
    this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$LambdaAdaptor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$JsFunction(fn);
  }
  
  /**
   * Initialization from constructor '$LambdaAdaptor($JsFunction)'.
   * @param {?function():boolean} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$LambdaAdaptor__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_check__() {
    let /** ?function():boolean */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_datatable_client_views_ui_TableStyleActions_Condition_$LambdaAdaptor, $function());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.datatable.client.views.ui.TableStyleActions$Condition$$LambdaAdaptor'));


Condition.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=TableStyleActions$Condition$$LambdaAdaptor.js.map