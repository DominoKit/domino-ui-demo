/**
 * @fileoverview transpiled from org.dominokit.domino.components.client.views.ComponentsView.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.components.client.views.ComponentsView$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const View = goog.require('org.dominokit.domino.api.client.mvp.view.View$impl');


/**
 * @interface
 * @extends {View}
 */
class ComponentsView {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    View.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_components_client_views_ComponentsView = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_components_client_views_ComponentsView;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_components_client_views_ComponentsView;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ComponentsView.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ComponentsView, $Util.$makeClassName('org.dominokit.domino.components.client.views.ComponentsView'));


ComponentsView.$markImplementor(/** @type {Function} */ (ComponentsView));


exports = ComponentsView; 
//# sourceMappingURL=ComponentsView.js.map