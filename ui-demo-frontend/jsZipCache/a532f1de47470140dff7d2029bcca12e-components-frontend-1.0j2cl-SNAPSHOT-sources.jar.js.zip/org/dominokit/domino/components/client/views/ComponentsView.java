package org.dominokit.domino.components.client.views;

import org.dominokit.domino.api.client.mvp.view.View;

public interface ComponentsView extends View{
}