/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$DominoOptionsHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let CanSetDominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.CanSetDominoOptions$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class DominoOptionsHandler {
  /**
   * @abstract
   * @param {CanSetDominoOptions} dominoOptions
   * @return {void}
   * @public
   */
  m_onBeforeRun__org_dominokit_domino_api_client_CanSetDominoOptions(dominoOptions) {
  }
  
  /**
   * @param {?function(CanSetDominoOptions):void} fn
   * @return {DominoOptionsHandler}
   * @public
   */
  static $adapt(fn) {
    DominoOptionsHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoOptionsHandler.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DominoOptionsHandler, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$DominoOptionsHandler'));


DominoOptionsHandler.$markImplementor(/** @type {Function} */ (DominoOptionsHandler));


exports = DominoOptionsHandler; 
//# sourceMappingURL=ClientApp$DominoOptionsHandler.js.map