/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.LazyViewLoader.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Objects = goog.forwardDeclare('java.util.Objects$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');


/**
 * @abstract
  */
class LazyViewLoader extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_presenterName__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_;
    /** @public {View} */
    this.f_view__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_;
  }
  
  /**
   * Initialization from constructor 'LazyViewLoader(String)'.
   * @param {?string} presenterName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_view_LazyViewLoader__java_lang_String(presenterName) {
    this.$ctor__java_lang_Object__();
    this.f_presenterName__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_ = presenterName;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPresenterName__() {
    return this.f_presenterName__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_;
  }
  
  /**
   * @return {View}
   * @public
   */
  m_getView__() {
    if (Objects.m_isNull__java_lang_Object(this.f_view__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_)) {
      this.f_view__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_ = this.m_make__();
    }
    return this.f_view__org_dominokit_domino_api_client_mvp_view_LazyViewLoader_;
  }
  
  /**
   * @abstract
   * @return {View}
   * @public
   */
  m_make__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LazyViewLoader;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LazyViewLoader);
  }
  
  /**
   * @public
   */
  static $clinit() {
    LazyViewLoader.$clinit = function() {};
    Objects = goog.module.get('java.util.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(LazyViewLoader, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.LazyViewLoader'));




exports = LazyViewLoader; 
//# sourceMappingURL=LazyViewLoader.js.map