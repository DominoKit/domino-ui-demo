/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasClientRouter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasClientRouter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasClientRouter.$LambdaAdaptor');
const _HasServerRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasServerRouter');
const _RequestRouter = goog.require('org.dominokit.domino.api.client.request.RequestRouter');
const _ServerRequest = goog.require('org.dominokit.domino.api.client.request.ServerRequest');


// Re-exports the implementation.
var HasClientRouter = goog.require('org.dominokit.domino.api.client.ClientApp.HasClientRouter$impl');
exports = HasClientRouter;
 