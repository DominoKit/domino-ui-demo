/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Fail.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.Fail');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.request.Fail.$LambdaAdaptor');
const _FailedResponseBean = goog.require('org.dominokit.domino.api.shared.request.FailedResponseBean');


// Re-exports the implementation.
var Fail = goog.require('org.dominokit.domino.api.client.request.Fail$impl');
exports = Fail;
 