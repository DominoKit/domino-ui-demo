/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.Domino.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.Domino');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Level = goog.require('java.util.logging.Level');
const _Logger = goog.require('java.util.logging.Logger');


// Re-exports the implementation.
var Domino = goog.require('org.dominokit.domino.api.client.Domino$impl');
exports = Domino;
 