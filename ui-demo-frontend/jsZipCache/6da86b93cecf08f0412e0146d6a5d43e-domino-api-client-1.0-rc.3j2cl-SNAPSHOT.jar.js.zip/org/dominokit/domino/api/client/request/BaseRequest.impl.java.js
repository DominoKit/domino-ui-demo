/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.BaseRequest.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.BaseRequest$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const Request = goog.require('org.dominokit.domino.api.client.request.Request$impl');

let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let Presentable = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');
let DefaultRequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext$impl');
let InvalidRequestState = goog.forwardDeclare('org.dominokit.domino.api.client.request.Request.InvalidRequestState$impl');
let RequestState = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestState$impl');
let RequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestStateContext$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @abstract
 * @implements {Request}
  */
class BaseRequest extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_key__org_dominokit_domino_api_client_request_BaseRequest;
    /** @public {RequestState} */
    this.f_state__org_dominokit_domino_api_client_request_BaseRequest;
    /** @public {ClientApp} */
    this.f_clientApp__org_dominokit_domino_api_client_request_BaseRequest;
    /** @public {RequestState<DefaultRequestStateContext>} */
    this.f_ready__org_dominokit_domino_api_client_request_BaseRequest;
    /** @public {RequestState<DefaultRequestStateContext>} */
    this.f_completed__org_dominokit_domino_api_client_request_BaseRequest;
  }
  
  /**
   * Initialization from constructor 'BaseRequest()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_BaseRequest__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_api_client_request_BaseRequest();
    this.f_key__org_dominokit_domino_api_client_request_BaseRequest = this.m_getClass__().m_getCanonicalName__();
    this.f_state__org_dominokit_domino_api_client_request_BaseRequest = this.f_ready__org_dominokit_domino_api_client_request_BaseRequest;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getKey__() {
    return this.f_key__org_dominokit_domino_api_client_request_BaseRequest;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_execute__() {
    if (!$Objects.m_equals__java_lang_Object__java_lang_Object(this.f_state__org_dominokit_domino_api_client_request_BaseRequest, this.f_ready__org_dominokit_domino_api_client_request_BaseRequest)) {
      throw $Exceptions.toJs(InvalidRequestState.$create__java_lang_String(BaseRequest.f_REQUEST_HAVE_ALREADY_BEEN_SENT__org_dominokit_domino_api_client_request_BaseRequest));
    }
    this.f_state__org_dominokit_domino_api_client_request_BaseRequest.m_execute__org_dominokit_domino_api_client_request_RequestStateContext(DefaultRequestStateContext.$create__());
  }
  
  /**
   * @return {Presentable}
   * @public
   */
  m_getRequestPresenter__() {
    return this.f_clientApp__org_dominokit_domino_api_client_request_BaseRequest.m_getPresentersRepository__().m_getPresenter__java_lang_String(this.m_getPresenterName___$p_org_dominokit_domino_api_client_request_BaseRequest());
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getPresenterName___$p_org_dominokit_domino_api_client_request_BaseRequest() {
    return this.f_clientApp__org_dominokit_domino_api_client_request_BaseRequest.m_getRequestRepository__().m_findRequestPresenterWrapper__java_lang_String(this.m_getKey__()).m_getPresenterName__();
  }
  
  /**
   * @override
   * @param {RequestStateContext} context
   * @return {void}
   * @public
   */
  m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(context) {
    this.f_state__org_dominokit_domino_api_client_request_BaseRequest.m_execute__org_dominokit_domino_api_client_request_RequestStateContext(context);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_request_BaseRequest() {
    this.f_clientApp__org_dominokit_domino_api_client_request_BaseRequest = ClientApp.m_make__();
    this.f_ready__org_dominokit_domino_api_client_request_BaseRequest = RequestState.$adapt(((/** DefaultRequestStateContext */ context) =>{
      this.m_startRouting__();
    }));
    this.f_completed__org_dominokit_domino_api_client_request_BaseRequest = RequestState.$adapt(((/** DefaultRequestStateContext */ context$1$) =>{
      throw $Exceptions.toJs(InvalidRequestState.$create__java_lang_String("This request have already been completed!."));
    }));
  }
  
  /**
   * @abstract
   * @override
   * @return {void}
   * @public
   */
  m_startRouting__() {
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseRequest;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseRequest);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseRequest.$clinit = function() {};
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    DefaultRequestStateContext = goog.module.get('org.dominokit.domino.api.client.request.Request.DefaultRequestStateContext$impl');
    InvalidRequestState = goog.module.get('org.dominokit.domino.api.client.request.Request.InvalidRequestState$impl');
    RequestState = goog.module.get('org.dominokit.domino.api.client.request.RequestState$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(BaseRequest, $Util.$makeClassName('org.dominokit.domino.api.client.request.BaseRequest'));


/** @public {?string} @const */
BaseRequest.f_REQUEST_HAVE_ALREADY_BEEN_SENT__org_dominokit_domino_api_client_request_BaseRequest = "Request have already been sent";


Request.$markImplementor(BaseRequest);


exports = BaseRequest; 
//# sourceMappingURL=BaseRequest.js.map