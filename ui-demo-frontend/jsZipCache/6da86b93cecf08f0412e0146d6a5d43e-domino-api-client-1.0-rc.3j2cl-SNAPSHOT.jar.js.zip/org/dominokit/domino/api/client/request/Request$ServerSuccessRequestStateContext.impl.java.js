/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$ServerSuccessRequestStateContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Request.ServerSuccessRequestStateContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext$impl');

let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @implements {RequestStateContext}
  */
class ServerSuccessRequestStateContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {ResponseBean} */
    this.f_responseBean__org_dominokit_domino_api_client_request_Request_ServerSuccessRequestStateContext;
  }
  
  /**
   * Factory method corresponding to constructor 'ServerSuccessRequestStateContext(ResponseBean)'.
   * @param {ResponseBean} responseBean
   * @return {!ServerSuccessRequestStateContext}
   * @public
   */
  static $create__org_dominokit_domino_api_shared_request_ResponseBean(responseBean) {
    ServerSuccessRequestStateContext.$clinit();
    let $instance = new ServerSuccessRequestStateContext();
    $instance.$ctor__org_dominokit_domino_api_client_request_Request_ServerSuccessRequestStateContext__org_dominokit_domino_api_shared_request_ResponseBean(responseBean);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerSuccessRequestStateContext(ResponseBean)'.
   * @param {ResponseBean} responseBean
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Request_ServerSuccessRequestStateContext__org_dominokit_domino_api_shared_request_ResponseBean(responseBean) {
    this.$ctor__java_lang_Object__();
    this.f_responseBean__org_dominokit_domino_api_client_request_Request_ServerSuccessRequestStateContext = responseBean;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerSuccessRequestStateContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerSuccessRequestStateContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerSuccessRequestStateContext.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerSuccessRequestStateContext, $Util.$makeClassName('org.dominokit.domino.api.client.request.Request$ServerSuccessRequestStateContext'));


RequestStateContext.$markImplementor(ServerSuccessRequestStateContext);


exports = ServerSuccessRequestStateContext; 
//# sourceMappingURL=Request$ServerSuccessRequestStateContext.js.map