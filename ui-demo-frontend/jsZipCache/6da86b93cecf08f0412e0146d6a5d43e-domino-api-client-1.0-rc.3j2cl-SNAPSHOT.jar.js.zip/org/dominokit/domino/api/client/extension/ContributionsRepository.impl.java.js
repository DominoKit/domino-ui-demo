/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContributionsRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let Contribution = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');


/**
 * @interface
 */
class ContributionsRepository {
  /**
   * @abstract
   * @param {Class<?>} extensionPoint
   * @param {Contribution} contribution
   * @return {void}
   * @public
   */
  m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(extensionPoint, contribution) {
  }
  
  /**
   * @abstract
   * @param {Class<?>} extensionPoint
   * @return {Set<Contribution>}
   * @public
   */
  m_findExtensionPointContributions__java_lang_Class(extensionPoint) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContributionsRepository = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_extension_ContributionsRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_extension_ContributionsRepository;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContributionsRepository.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ContributionsRepository, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContributionsRepository'));


ContributionsRepository.$markImplementor(/** @type {Function} */ (ContributionsRepository));


exports = ContributionsRepository; 
//# sourceMappingURL=ContributionsRepository.js.map