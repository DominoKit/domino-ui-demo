/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresenterState.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresenterState');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresenterState.$LambdaAdaptor');


// Re-exports the implementation.
var PresenterState = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresenterState$impl');
exports = PresenterState;
 