/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.CanSend.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.CanSend$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.request.CanSend.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CanSend {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_send__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {CanSend}
   * @public
   */
  static $adapt(fn) {
    CanSend.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CanSend = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_CanSend;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_CanSend;
  }
  
  /**
   * @public
   */
  static $clinit() {
    CanSend.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.request.CanSend.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CanSend, $Util.$makeClassName('org.dominokit.domino.api.client.request.CanSend'));


CanSend.$markImplementor(/** @type {Function} */ (CanSend));


exports = CanSend; 
//# sourceMappingURL=CanSend.js.map