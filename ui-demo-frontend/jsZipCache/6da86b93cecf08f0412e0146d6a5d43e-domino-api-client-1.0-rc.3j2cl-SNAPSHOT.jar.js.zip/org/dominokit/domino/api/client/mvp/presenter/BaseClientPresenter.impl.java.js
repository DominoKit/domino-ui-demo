/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.ClientPresenter$impl');
const Presentable = goog.require('org.dominokit.domino.api.client.mvp.presenter.Presentable$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ClientApp = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp$impl');
let AsyncTask = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
let Contributions = goog.forwardDeclare('org.dominokit.domino.api.client.extension.Contributions$impl');
let PresenterState = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresenterState$impl');
let View = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.View$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let DominoHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_V
 * @extends {ClientPresenter<C_V>}
 * @implements {Presentable}
  */
class BaseClientPresenter extends ClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {PresenterState} */
    this.f_initialized__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_;
    /** @public {PresenterState} */
    this.f_uninitialized__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_;
    /** @public {PresenterState} */
    this.f_state__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_;
    /** @public {C_V} */
    this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter;
  }
  
  /**
   * Initialization from constructor 'BaseClientPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_ClientPresenter__();
    this.$init__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter();
  }
  
  /**
   * @override
   * @return {Presentable}
   * @public
   */
  m_init__() {
    this.f_state__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_ = this.f_uninitialized__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_;
    this.m_prepare__();
    return this;
  }
  
  /**
   * @override
   * @return {ClientPresenter<C_V>}
   * @public
   */
  m_prepare__() {
    this.f_state__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_.m_process__();
    return this;
  }
  
  /**
   * @return {C_V}
   * @public
   */
  m_loadView___$p_org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter() {
    return /**@type {C_V} */ ($Casts.$to(ClientApp.m_make__().m_getViewsRepository__().m_getView__java_lang_String(this.m_getName___$p_org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter()), View));
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getConcrete__() {
    return this.m_getClass__().m_getCanonicalName__();
  }
  
  /**
   * @template M_E
   * @param {Class<M_E>} extensionPointInterface
   * @param {M_E} extensionPoint
   * @return {void}
   * @public
   */
  m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPointInterface, extensionPoint) {
    Contributions.m_apply__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPointInterface, extensionPoint);
  }
  
  /**
   * @param {AsyncTask} asyncTask
   * @return {void}
   * @public
   */
  m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(asyncTask) {
    ClientApp.m_make__().m_getAsyncRunner__().m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(asyncTask);
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName___$p_org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter() {
    return ClientApp.m_make__().m_getPresentersRepository__().m_getNameFromConcreteName__java_lang_String(this.m_getConcrete__());
  }
  
  /**
   * @return {DominoHistory}
   * @public
   */
  m_history__() {
    return ClientApp.m_make__().m_getHistory__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter() {
    this.f_initialized__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_ = PresenterState.$adapt((() =>{
      BaseClientPresenter.$f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_.m_info__java_lang_String("Presenter " + j_l_String.m_valueOf__java_lang_Object(this.m_getClass__()) + " Have already been initialized.");
    }));
    this.f_uninitialized__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_ = PresenterState.$adapt((() =>{
      this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter = this.m_loadView___$p_org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter();
      this.m_initView__org_dominokit_domino_api_client_mvp_view_View(this.f_view__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter);
      this.f_state__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_ = this.f_initialized__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_;
    }));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_() {
    return (BaseClientPresenter.$clinit(), BaseClientPresenter.$f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_(value) {
    (BaseClientPresenter.$clinit(), BaseClientPresenter.$f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseClientPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseClientPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    BaseClientPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ClientApp = goog.module.get('org.dominokit.domino.api.client.ClientApp$impl');
    Contributions = goog.module.get('org.dominokit.domino.api.client.extension.Contributions$impl');
    PresenterState = goog.module.get('org.dominokit.domino.api.client.mvp.presenter.PresenterState$impl');
    View = goog.module.get('org.dominokit.domino.api.client.mvp.view.View$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    ClientPresenter.$clinit();
    Presentable.$clinit();
    BaseClientPresenter.$f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(BaseClientPresenter));
  }
  
  
};

$Util.$setClassMetadata(BaseClientPresenter, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter'));


/** @private {Logger} */
BaseClientPresenter.$f_LOGGER__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter_;


Presentable.$markImplementor(BaseClientPresenter);


exports = BaseClientPresenter; 
//# sourceMappingURL=BaseClientPresenter.js.map