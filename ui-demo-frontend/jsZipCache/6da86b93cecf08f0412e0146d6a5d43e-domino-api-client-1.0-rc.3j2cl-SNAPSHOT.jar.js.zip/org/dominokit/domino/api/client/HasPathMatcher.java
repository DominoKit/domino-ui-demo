package org.dominokit.domino.api.client;

public interface HasPathMatcher {
    DynamicServiceRoot serviceRoot(DynamicServiceRoot.HasServiceRoot serviceRoot);
}
