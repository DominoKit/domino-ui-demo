/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.InitialTaskRegistry.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.InitialTaskRegistry');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ClientStartupTask = goog.require('org.dominokit.domino.api.client.ClientStartupTask');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry.$LambdaAdaptor');


// Re-exports the implementation.
var InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
exports = InitialTaskRegistry;
 