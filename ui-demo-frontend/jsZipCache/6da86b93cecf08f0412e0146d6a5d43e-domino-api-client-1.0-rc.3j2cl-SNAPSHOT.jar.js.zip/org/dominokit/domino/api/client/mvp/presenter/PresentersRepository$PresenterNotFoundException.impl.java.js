/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$PresenterNotFoundException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository.PresenterNotFoundException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Long = goog.require('nativebootstrap.Long$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class PresenterNotFoundException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'PresenterNotFoundException(String)'.
   * @param {?string} message
   * @return {!PresenterNotFoundException}
   * @public
   */
  static $create__java_lang_String(message) {
    PresenterNotFoundException.$clinit();
    let $instance = new PresenterNotFoundException();
    $instance.$ctor__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository_PresenterNotFoundException__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'PresenterNotFoundException(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository_PresenterNotFoundException__java_lang_String(message) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PresenterNotFoundException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PresenterNotFoundException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    PresenterNotFoundException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(PresenterNotFoundException, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$PresenterNotFoundException'));


/** @public {!$Long} @const */
PresenterNotFoundException.f_serialVersionUID__org_dominokit_domino_api_client_mvp_presenter_PresentersRepository_PresenterNotFoundException_ = $Long.fromBits(-1180036409, -1502945977) /* -6455103815754837305 */;




exports = PresenterNotFoundException; 
//# sourceMappingURL=PresentersRepository$PresenterNotFoundException.js.map