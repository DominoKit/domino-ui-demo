/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.events.ServerRequestEventFactory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.events.ServerRequestEventFactory$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Throwable = goog.forwardDeclare('java.lang.Throwable$impl');
let Event = goog.forwardDeclare('org.dominokit.domino.api.client.events.Event$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let ResponseBean = goog.forwardDeclare('org.dominokit.domino.api.shared.request.ResponseBean$impl');


/**
 * @interface
 */
class ServerRequestEventFactory {
  /**
   * @abstract
   * @param {ServerRequest} request
   * @param {ResponseBean} responseBean
   * @return {Event}
   * @public
   */
  m_makeSuccess__org_dominokit_domino_api_client_request_ServerRequest__org_dominokit_domino_api_shared_request_ResponseBean(request, responseBean) {
  }
  
  /**
   * @abstract
   * @param {ServerRequest} request
   * @param {Throwable} error
   * @return {Event}
   * @public
   */
  m_makeFailed__org_dominokit_domino_api_client_request_ServerRequest__java_lang_Throwable(request, error) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_ServerRequestEventFactory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_events_ServerRequestEventFactory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_events_ServerRequestEventFactory;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerRequestEventFactory.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ServerRequestEventFactory, $Util.$makeClassName('org.dominokit.domino.api.client.events.ServerRequestEventFactory'));


ServerRequestEventFactory.$markImplementor(/** @type {Function} */ (ServerRequestEventFactory));


exports = ServerRequestEventFactory; 
//# sourceMappingURL=ServerRequestEventFactory.js.map