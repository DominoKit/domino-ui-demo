/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request$ServerResponseReceivedStateContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Request.ServerResponseReceivedStateContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext$impl');


/**
 * @implements {RequestStateContext}
  */
class ServerResponseReceivedStateContext extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {RequestStateContext} */
    this.f_nextContext__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext;
  }
  
  /**
   * Factory method corresponding to constructor 'ServerResponseReceivedStateContext(RequestStateContext)'.
   * @param {RequestStateContext} nextContext
   * @return {!ServerResponseReceivedStateContext}
   * @public
   */
  static $create__org_dominokit_domino_api_client_request_RequestStateContext(nextContext) {
    ServerResponseReceivedStateContext.$clinit();
    let $instance = new ServerResponseReceivedStateContext();
    $instance.$ctor__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext__org_dominokit_domino_api_client_request_RequestStateContext(nextContext);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ServerResponseReceivedStateContext(RequestStateContext)'.
   * @param {RequestStateContext} nextContext
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext__org_dominokit_domino_api_client_request_RequestStateContext(nextContext) {
    this.$ctor__java_lang_Object__();
    this.f_nextContext__org_dominokit_domino_api_client_request_Request_ServerResponseReceivedStateContext = nextContext;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ServerResponseReceivedStateContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ServerResponseReceivedStateContext);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ServerResponseReceivedStateContext.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ServerResponseReceivedStateContext, $Util.$makeClassName('org.dominokit.domino.api.client.request.Request$ServerResponseReceivedStateContext'));


RequestStateContext.$markImplementor(ServerResponseReceivedStateContext);


exports = ServerResponseReceivedStateContext; 
//# sourceMappingURL=Request$ServerResponseReceivedStateContext.js.map