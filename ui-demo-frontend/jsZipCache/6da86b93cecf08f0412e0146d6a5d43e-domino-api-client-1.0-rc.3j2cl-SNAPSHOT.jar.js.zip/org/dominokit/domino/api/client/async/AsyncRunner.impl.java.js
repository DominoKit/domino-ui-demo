/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.async.AsyncRunner.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.async.AsyncRunner$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.$LambdaAdaptor$impl');
let AsyncTask = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @interface
 */
class AsyncRunner {
  /**
   * @abstract
   * @param {AsyncTask} asyncTask
   * @return {void}
   * @public
   */
  m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(asyncTask) {
  }
  
  /**
   * @param {?function(AsyncTask):void} fn
   * @return {AsyncRunner}
   * @public
   */
  static $adapt(fn) {
    AsyncRunner.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner() {
    return (AsyncRunner.$clinit(), AsyncRunner.$f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner(value) {
    (AsyncRunner.$clinit(), AsyncRunner.$f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner = value);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_async_AsyncRunner = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_async_AsyncRunner;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_async_AsyncRunner;
  }
  
  /**
   * @public
   */
  static $clinit() {
    AsyncRunner.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.async.AsyncRunner.$LambdaAdaptor$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    AsyncRunner.$f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AsyncRunner));
  }
  
  
};

$Util.$setClassMetadataForInterface(AsyncRunner, $Util.$makeClassName('org.dominokit.domino.api.client.async.AsyncRunner'));


/** @private {Logger} */
AsyncRunner.$f_LOGGER__org_dominokit_domino_api_client_async_AsyncRunner;


AsyncRunner.$markImplementor(/** @type {Function} */ (AsyncRunner));


exports = AsyncRunner; 
//# sourceMappingURL=AsyncRunner.js.map