package org.dominokit.domino.api.client.events;

public interface Event {
    void fire();
    void process();
}
