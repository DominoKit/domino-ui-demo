/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$AttributeHolder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.AttributeHolder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @template C_AttributeHolder_T
  */
class AttributeHolder extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {C_AttributeHolder_T} */
    this.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_;
  }
  
  /**
   * Factory method corresponding to constructor 'AttributeHolder()'.
   * @template C_AttributeHolder_T
   * @return {!AttributeHolder<C_AttributeHolder_T>}
   * @public
   */
  static $create__() {
    AttributeHolder.$clinit();
    let $instance = new AttributeHolder();
    $instance.$ctor__org_dominokit_domino_api_client_ClientApp_AttributeHolder__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AttributeHolder()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp_AttributeHolder__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {C_AttributeHolder_T} attribute
   * @return {void}
   * @public
   */
  m_hold__java_lang_Object(attribute) {
    this.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_ = attribute;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AttributeHolder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AttributeHolder);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AttributeHolder.$clinit = function() {};
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(AttributeHolder, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp$AttributeHolder'));




exports = AttributeHolder; 
//# sourceMappingURL=ClientApp$AttributeHolder.js.map