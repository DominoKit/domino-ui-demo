/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.DominoOptions.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.DominoOptions$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const CanSetDominoOptions = goog.require('org.dominokit.domino.api.client.CanSetDominoOptions$impl');
const HasDominoOptions = goog.require('org.dominokit.domino.api.client.HasDominoOptions$impl');


/**
 * @interface
 * @extends {HasDominoOptions}
 * @extends {CanSetDominoOptions}
 */
class DominoOptions {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_applyOptions__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    HasDominoOptions.$markImplementor(classConstructor);
    CanSetDominoOptions.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_DominoOptions = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_DominoOptions;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_DominoOptions;
  }
  
  /**
   * @public
   */
  static $clinit() {
    DominoOptions.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(DominoOptions, $Util.$makeClassName('org.dominokit.domino.api.client.DominoOptions'));


DominoOptions.$markImplementor(/** @type {Function} */ (DominoOptions));


exports = DominoOptions; 
//# sourceMappingURL=DominoOptions.js.map