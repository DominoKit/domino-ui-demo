/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.annotations.ClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.annotations.ClientModule$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class ClientModule {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_name__() {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_ClientModule = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_annotations_ClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_annotations_ClientModule;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientModule.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(ClientModule, $Util.$makeClassName('org.dominokit.domino.api.client.annotations.ClientModule'));


ClientModule.$markImplementor(/** @type {Function} */ (ClientModule));


exports = ClientModule; 
//# sourceMappingURL=ClientModule.js.map