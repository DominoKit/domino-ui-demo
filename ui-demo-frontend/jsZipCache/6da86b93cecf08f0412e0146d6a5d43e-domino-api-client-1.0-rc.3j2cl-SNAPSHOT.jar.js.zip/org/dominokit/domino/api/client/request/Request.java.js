/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.request.Request');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _RequestStateContext = goog.require('org.dominokit.domino.api.client.request.RequestStateContext');


// Re-exports the implementation.
var Request = goog.require('org.dominokit.domino.api.client.request.Request$impl');
exports = Request;
 