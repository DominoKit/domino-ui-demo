/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.ViewRegistry.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.ViewRegistry.$LambdaAdaptor$impl');
let LazyViewLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');


/**
 * @interface
 */
class ViewRegistry {
  /**
   * @abstract
   * @param {LazyViewLoader} lazyViewLoader
   * @return {void}
   * @public
   */
  m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader(lazyViewLoader) {
  }
  
  /**
   * @param {?function(LazyViewLoader):void} fn
   * @return {ViewRegistry}
   * @public
   */
  static $adapt(fn) {
    ViewRegistry.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_ViewRegistry = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_ViewRegistry;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_ViewRegistry;
  }
  
  /**
   * @public
   */
  static $clinit() {
    ViewRegistry.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.mvp.ViewRegistry.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ViewRegistry, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.ViewRegistry'));


ViewRegistry.$markImplementor(/** @type {Function} */ (ViewRegistry));


exports = ViewRegistry; 
//# sourceMappingURL=ViewRegistry.js.map