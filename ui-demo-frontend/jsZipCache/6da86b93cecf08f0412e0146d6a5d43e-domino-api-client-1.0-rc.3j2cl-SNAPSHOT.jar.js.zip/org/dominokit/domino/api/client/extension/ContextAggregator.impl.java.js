/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.extension.ContextAggregator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.extension.ContextAggregator$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let LinkedHashSet = goog.forwardDeclare('java.util.LinkedHashSet$impl');
let Set = goog.forwardDeclare('java.util.Set$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let CanWaitForContext = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.CanWaitForContext$impl');
let ContextAggregatorBuilder = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ContextAggregatorBuilder$impl');
let ContextWait = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ContextWait$impl');
let ReadyHandler = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');


class ContextAggregator extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
    /** @public {Set<ContextWait>} */
    this.f_contextsSet__org_dominokit_domino_api_client_extension_ContextAggregator_;
  }
  
  /**
   * Factory method corresponding to constructor 'ContextAggregator(Set, ReadyHandler)'.
   * @param {Set<ContextWait>} contextSet
   * @param {ReadyHandler} handler
   * @return {!ContextAggregator}
   * @public
   */
  static $create__java_util_Set__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(contextSet, handler) {
    ContextAggregator.$clinit();
    let $instance = new ContextAggregator();
    $instance.$ctor__org_dominokit_domino_api_client_extension_ContextAggregator__java_util_Set__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(contextSet, handler);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ContextAggregator(Set, ReadyHandler)'.
   * @param {Set<ContextWait>} contextSet
   * @param {ReadyHandler} handler
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_extension_ContextAggregator__java_util_Set__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler(contextSet, handler) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_api_client_extension_ContextAggregator();
    this.f_contextsSet__org_dominokit_domino_api_client_extension_ContextAggregator_ = contextSet;
    this.f_contextsSet__org_dominokit_domino_api_client_extension_ContextAggregator_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ContextWait */ c) =>{
      c.m_onReady__org_dominokit_domino_api_client_extension_ContextAggregator_ReadyHandler_$pp_org_dominokit_domino_api_client_extension(ReadyHandler.$adapt((() =>{
        this.f_contextsSet__org_dominokit_domino_api_client_extension_ContextAggregator_.remove(c);
        if (this.f_contextsSet__org_dominokit_domino_api_client_extension_ContextAggregator_.isEmpty()) {
          handler.m_onReady__();
        }
      })));
    })));
  }
  
  /**
   * @param {ContextWait} context
   * @return {CanWaitForContext}
   * @public
   */
  static m_waitFor__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context) {
    ContextAggregator.$clinit();
    return ContextAggregatorBuilder.m_waitForContext__org_dominokit_domino_api_client_extension_ContextAggregator_ContextWait(context);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_api_client_extension_ContextAggregator() {
    this.f_contextsSet__org_dominokit_domino_api_client_extension_ContextAggregator_ = /**@type {!LinkedHashSet<ContextWait>} */ (LinkedHashSet.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ContextAggregator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ContextAggregator);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ContextAggregator.$clinit = function() {};
    LinkedHashSet = goog.module.get('java.util.LinkedHashSet$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    ContextAggregatorBuilder = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator.ContextAggregatorBuilder$impl');
    ReadyHandler = goog.module.get('org.dominokit.domino.api.client.extension.ContextAggregator.ReadyHandler$impl');
    j_l_Object.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ContextAggregator, $Util.$makeClassName('org.dominokit.domino.api.client.extension.ContextAggregator'));




exports = ContextAggregator; 
//# sourceMappingURL=ContextAggregator.js.map