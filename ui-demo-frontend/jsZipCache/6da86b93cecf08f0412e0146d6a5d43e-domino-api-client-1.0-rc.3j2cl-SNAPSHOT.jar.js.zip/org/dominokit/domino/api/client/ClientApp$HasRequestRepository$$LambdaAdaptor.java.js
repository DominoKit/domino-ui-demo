/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasRequestRepository$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasRequestRepository.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasRequestRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRepository');
const _HasPresentersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasPresentersRepository');
const _PresentersRepository = goog.require('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRepository.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 