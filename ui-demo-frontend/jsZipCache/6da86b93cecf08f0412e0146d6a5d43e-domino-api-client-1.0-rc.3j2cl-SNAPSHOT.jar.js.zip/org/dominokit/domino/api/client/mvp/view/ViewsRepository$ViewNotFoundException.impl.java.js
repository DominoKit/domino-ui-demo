/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.ViewsRepository$ViewNotFoundException.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.ViewsRepository.ViewNotFoundException$impl');


const RuntimeException = goog.require('java.lang.RuntimeException$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class ViewNotFoundException extends RuntimeException {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ViewNotFoundException(String)'.
   * @param {?string} message
   * @return {!ViewNotFoundException}
   * @public
   */
  static $create__java_lang_String(message) {
    ViewNotFoundException.$clinit();
    let $instance = new ViewNotFoundException();
    $instance.$ctor__org_dominokit_domino_api_client_mvp_view_ViewsRepository_ViewNotFoundException__java_lang_String(message);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ViewNotFoundException(String)'.
   * @param {?string} message
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_mvp_view_ViewsRepository_ViewNotFoundException__java_lang_String(message) {
    this.$ctor__java_lang_RuntimeException__java_lang_String(message);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ViewNotFoundException;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ViewNotFoundException);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ViewNotFoundException.$clinit = function() {};
    RuntimeException.$clinit();
  }
  
  
};

$Util.$setClassMetadata(ViewNotFoundException, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.ViewsRepository$ViewNotFoundException'));




exports = ViewNotFoundException; 
//# sourceMappingURL=ViewsRepository$ViewNotFoundException.js.map