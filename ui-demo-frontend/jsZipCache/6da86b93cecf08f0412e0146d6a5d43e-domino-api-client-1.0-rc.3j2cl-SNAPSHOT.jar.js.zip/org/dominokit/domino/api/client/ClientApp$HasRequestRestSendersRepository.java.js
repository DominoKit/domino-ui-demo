/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp$HasRequestRestSendersRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasHistory = goog.require('org.dominokit.domino.api.client.ClientApp.HasHistory');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository.$LambdaAdaptor');
const _AppHistory = goog.require('org.dominokit.domino.api.shared.history.AppHistory');


// Re-exports the implementation.
var HasRequestRestSendersRepository = goog.require('org.dominokit.domino.api.client.ClientApp.HasRequestRestSendersRepository$impl');
exports = HasRequestRestSendersRepository;
 