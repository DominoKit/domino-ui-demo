/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.mvp.view.View.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.mvp.view.View$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class View {
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_View = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_mvp_view_View;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_mvp_view_View;
  }
  
  /**
   * @public
   */
  static $clinit() {
    View.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(View, $Util.$makeClassName('org.dominokit.domino.api.client.mvp.view.View'));


View.$markImplementor(/** @type {Function} */ (View));


exports = View; 
//# sourceMappingURL=View.js.map