/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.request.Request.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.request.Request$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let RequestStateContext = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestStateContext$impl');


/**
 * @interface
 */
class Request {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_startRouting__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getKey__() {
  }
  
  /**
   * @abstract
   * @param {RequestStateContext} context
   * @return {void}
   * @public
   */
  m_applyState__org_dominokit_domino_api_client_request_RequestStateContext(context) {
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Request = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_request_Request;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_request_Request;
  }
  
  /**
   * @public
   */
  static $clinit() {
    Request.$clinit = function() {};
  }
  
  
};

$Util.$setClassMetadataForInterface(Request, $Util.$makeClassName('org.dominokit.domino.api.client.request.Request'));


Request.$markImplementor(/** @type {Function} */ (Request));


exports = Request; 
//# sourceMappingURL=Request.js.map