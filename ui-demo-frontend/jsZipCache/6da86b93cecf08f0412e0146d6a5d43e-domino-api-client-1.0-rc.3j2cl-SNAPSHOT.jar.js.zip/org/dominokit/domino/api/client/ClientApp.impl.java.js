/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.ClientApp.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.ClientApp$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const InitialTaskRegistry = goog.require('org.dominokit.domino.api.client.InitialTaskRegistry$impl');
const ContributionsRegistry = goog.require('org.dominokit.domino.api.client.extension.ContributionsRegistry$impl');
const PresenterRegistry = goog.require('org.dominokit.domino.api.client.mvp.PresenterRegistry$impl');
const ViewRegistry = goog.require('org.dominokit.domino.api.client.mvp.ViewRegistry$impl');
const CommandRegistry = goog.require('org.dominokit.domino.api.client.request.CommandRegistry$impl');
const RequestRestSendersRegistry = goog.require('org.dominokit.domino.api.client.request.RequestRestSendersRegistry$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let CanSetDominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.CanSetDominoOptions$impl');
let AttributeHolder = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.AttributeHolder$impl');
let DominoOptionsHandler = goog.forwardDeclare('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler$impl');
let ClientStartupTask = goog.forwardDeclare('org.dominokit.domino.api.client.ClientStartupTask$impl');
let DominoOptions = goog.forwardDeclare('org.dominokit.domino.api.client.DominoOptions$impl');
let ModuleConfiguration = goog.forwardDeclare('org.dominokit.domino.api.client.ModuleConfiguration$impl');
let AsyncRunner = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner$impl');
let AsyncTask = goog.forwardDeclare('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
let EventsBus = goog.forwardDeclare('org.dominokit.domino.api.client.events.EventsBus$impl');
let ContributionsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');
let LazyPresenterLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.LazyPresenterLoader$impl');
let PresentersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');
let LazyViewLoader = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.LazyViewLoader$impl');
let ViewsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');
let CommandsRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.CommandsRepository$impl');
let LazyRequestRestSenderLoader = goog.forwardDeclare('org.dominokit.domino.api.client.request.LazyRequestRestSenderLoader$impl');
let PresenterCommand = goog.forwardDeclare('org.dominokit.domino.api.client.request.PresenterCommand$impl');
let RequestHolder = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestHolder$impl');
let RequestRestSendersRepository = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRestSendersRepository$impl');
let RequestRouter = goog.forwardDeclare('org.dominokit.domino.api.client.request.RequestRouter$impl');
let ServerRequest = goog.forwardDeclare('org.dominokit.domino.api.client.request.ServerRequest$impl');
let Contribution = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.Contribution$impl');
let ExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
let MainExtensionPoint = goog.forwardDeclare('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');
let AppHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.AppHistory$impl');
let DominoHistory = goog.forwardDeclare('org.dominokit.domino.api.shared.history.DominoHistory$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {PresenterRegistry}
 * @implements {CommandRegistry}
 * @implements {ViewRegistry}
 * @implements {InitialTaskRegistry}
 * @implements {ContributionsRegistry}
 * @implements {RequestRestSendersRegistry}
  */
class ClientApp extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'ClientApp()'.
   * @return {!ClientApp}
   * @public
   */
  static $create__() {
    ClientApp.$clinit();
    let $instance = new ClientApp();
    $instance.$ctor__org_dominokit_domino_api_client_ClientApp__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ClientApp()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_api_client_ClientApp__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {LazyPresenterLoader} lazyPresenterLoader
   * @return {void}
   * @public
   */
  m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader(lazyPresenterLoader) {
    /**@type {PresentersRepository} */ ($Casts.$to(ClientApp.$f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, PresentersRepository)).m_registerPresenter__org_dominokit_domino_api_client_mvp_presenter_LazyPresenterLoader(lazyPresenterLoader);
  }
  
  /**
   * @override
   * @param {?string} commandName
   * @param {?string} presenterName
   * @return {void}
   * @public
   */
  m_registerCommand__java_lang_String__java_lang_String(commandName, presenterName) {
    /**@type {CommandsRepository} */ ($Casts.$to(ClientApp.$f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, CommandsRepository)).m_registerCommand__org_dominokit_domino_api_client_request_RequestHolder(RequestHolder.$create__java_lang_String__java_lang_String(commandName, presenterName));
  }
  
  /**
   * @override
   * @param {LazyViewLoader} lazyViewLoader
   * @return {void}
   * @public
   */
  m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader(lazyViewLoader) {
    /**@type {ViewsRepository} */ ($Casts.$to(ClientApp.$f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, ViewsRepository)).m_registerView__org_dominokit_domino_api_client_mvp_view_LazyViewLoader(lazyViewLoader);
  }
  
  /**
   * @override
   * @param {Class<?>} extensionPoint
   * @param {Contribution} contribution
   * @return {void}
   * @public
   */
  m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(extensionPoint, contribution) {
    /**@type {ContributionsRepository} */ ($Casts.$to(ClientApp.$f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, ContributionsRepository)).m_registerContribution__java_lang_Class__org_dominokit_domino_api_shared_extension_Contribution(extensionPoint, contribution);
  }
  
  /**
   * @override
   * @param {?string} requestName
   * @param {LazyRequestRestSenderLoader} loader
   * @return {void}
   * @public
   */
  m_registerRequestRestSender__java_lang_String__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader(requestName, loader) {
    /**@type {RequestRestSendersRepository} */ ($Casts.$to(ClientApp.$f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, RequestRestSendersRepository)).m_registerSender__java_lang_String__org_dominokit_domino_api_client_request_LazyRequestRestSenderLoader(requestName, loader);
  }
  
  /**
   * @override
   * @param {ClientStartupTask} task
   * @return {void}
   * @public
   */
  m_registerInitialTask__org_dominokit_domino_api_client_ClientStartupTask(task) {
    /**@type {List<ClientStartupTask>} */ ($Casts.$to(ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, List)).add(task);
  }
  
  /**
   * @return {ClientApp}
   * @public
   */
  static m_make__() {
    ClientApp.$clinit();
    return ClientApp.$f_instance__org_dominokit_domino_api_client_ClientApp_;
  }
  
  /**
   * @return {RequestRouter<PresenterCommand>}
   * @public
   */
  m_getClientRouter__() {
    return /**@type {RequestRouter<PresenterCommand>} */ ($Casts.$to(ClientApp.$f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, RequestRouter));
  }
  
  /**
   * @return {RequestRouter<ServerRequest>}
   * @public
   */
  m_getServerRouter__() {
    return /**@type {RequestRouter<ServerRequest>} */ ($Casts.$to(ClientApp.$f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, RequestRouter));
  }
  
  /**
   * @return {EventsBus}
   * @public
   */
  m_getEventsBus__() {
    return /**@type {EventsBus} */ ($Casts.$to(ClientApp.$f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, EventsBus));
  }
  
  /**
   * @return {CommandsRepository}
   * @public
   */
  m_getRequestRepository__() {
    return /**@type {CommandsRepository} */ ($Casts.$to(ClientApp.$f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, CommandsRepository));
  }
  
  /**
   * @return {PresentersRepository}
   * @public
   */
  m_getPresentersRepository__() {
    return /**@type {PresentersRepository} */ ($Casts.$to(ClientApp.$f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, PresentersRepository));
  }
  
  /**
   * @return {ViewsRepository}
   * @public
   */
  m_getViewsRepository__() {
    return /**@type {ViewsRepository} */ ($Casts.$to(ClientApp.$f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, ViewsRepository));
  }
  
  /**
   * @return {RequestRestSendersRepository}
   * @public
   */
  m_getRequestRestSendersRepository__() {
    return /**@type {RequestRestSendersRepository} */ ($Casts.$to(ClientApp.$f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, RequestRestSendersRepository));
  }
  
  /**
   * @return {AsyncRunner}
   * @public
   */
  m_getAsyncRunner__() {
    return /**@type {AsyncRunner} */ ($Casts.$to(ClientApp.$f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, AsyncRunner));
  }
  
  /**
   * @return {DominoHistory}
   * @public
   */
  m_getHistory__() {
    return /**@type {DominoHistory} */ ($Casts.$to(ClientApp.$f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, DominoHistory));
  }
  
  /**
   * @return {DominoOptions}
   * @public
   */
  m_dominoOptions__() {
    return /**@type {DominoOptions} */ ($Casts.$to(ClientApp.$f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, DominoOptions));
  }
  
  /**
   * @param {ModuleConfiguration} configuration
   * @return {void}
   * @public
   */
  m_configureModule__org_dominokit_domino_api_client_ModuleConfiguration(configuration) {
    configuration.m_registerPresenters__org_dominokit_domino_api_client_mvp_PresenterRegistry(this);
    configuration.m_registerRequests__org_dominokit_domino_api_client_request_CommandRegistry(this);
    configuration.m_registerViews__org_dominokit_domino_api_client_mvp_ViewRegistry(this);
    configuration.m_registerContributions__org_dominokit_domino_api_client_extension_ContributionsRegistry(this);
    configuration.m_registerInitialTasks__org_dominokit_domino_api_client_InitialTaskRegistry(this);
    configuration.m_registerRequestRestSenders__org_dominokit_domino_api_client_request_RequestRestSendersRegistry(this);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_run__() {
    this.m_run__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler(DominoOptionsHandler.$adapt(((/** CanSetDominoOptions */ canSetDominoOptions) =>{
    })));
  }
  
  /**
   * @param {DominoOptionsHandler} dominoOptionsHandler
   * @return {void}
   * @public
   */
  m_run__org_dominokit_domino_api_client_ClientApp_DominoOptionsHandler(dominoOptionsHandler) {
    dominoOptionsHandler.m_onBeforeRun__org_dominokit_domino_api_client_CanSetDominoOptions(this.m_dominoOptions__());
    this.m_dominoOptions__().m_applyOptions__();
    /**@type {List<ClientStartupTask>} */ ($Casts.$to(ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, List)).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ClientStartupTask */ arg0) =>{
      arg0.m_execute__();
    })));
    this.m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(Class.$get(MainExtensionPoint), /**@type {ExtensionPoint} */ ($Casts.$to(ClientApp.$f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, ExtensionPoint)));
  }
  
  /**
   * @param {DominoOptions} dominoOptions
   * @return {void}
   * @public
   */
  m_run__org_dominokit_domino_api_client_DominoOptions(dominoOptions) {
    ClientApp.$f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_ = dominoOptions;
    this.m_dominoOptions__().m_applyOptions__();
    /**@type {List<ClientStartupTask>} */ ($Casts.$to(ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, List)).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ClientStartupTask */ arg0) =>{
      arg0.m_execute__();
    })));
    this.m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(Class.$get(MainExtensionPoint), /**@type {ExtensionPoint} */ ($Casts.$to(ClientApp.$f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, ExtensionPoint)));
  }
  
  /**
   * @param {Class<?>} extensionPointInterface
   * @param {ExtensionPoint} extensionPoint
   * @return {void}
   * @public
   */
  m_applyContributions__java_lang_Class__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPointInterface, extensionPoint) {
    /**@type {ContributionsRepository} */ ($Casts.$to(ClientApp.$f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_.f_attribute__org_dominokit_domino_api_client_ClientApp_AttributeHolder_, ContributionsRepository)).m_findExtensionPointContributions__java_lang_Class(extensionPointInterface).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Contribution */ c) =>{
      this.m_getAsyncRunner__().m_runAsync__org_dominokit_domino_api_client_async_AsyncRunner_AsyncTask(AsyncTask.$adapt((() =>{
        c.m_contribute__org_dominokit_domino_api_shared_extension_ExtensionPoint(extensionPoint);
      })));
    })));
  }
  
  /**
   * @return {AttributeHolder<RequestRouter<PresenterCommand>>}
   * @public
   */
  static get f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<RequestRouter<PresenterCommand>>} value
   * @return {void}
   * @public
   */
  static set f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<RequestRouter<ServerRequest>>}
   * @public
   */
  static get f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<RequestRouter<ServerRequest>>} value
   * @return {void}
   * @public
   */
  static set f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<EventsBus>}
   * @public
   */
  static get f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<EventsBus>} value
   * @return {void}
   * @public
   */
  static set f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<CommandsRepository>}
   * @public
   */
  static get f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<CommandsRepository>} value
   * @return {void}
   * @public
   */
  static set f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<PresentersRepository>}
   * @public
   */
  static get f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<PresentersRepository>} value
   * @return {void}
   * @public
   */
  static set f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<ViewsRepository>}
   * @public
   */
  static get f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<ViewsRepository>} value
   * @return {void}
   * @public
   */
  static set f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<ContributionsRepository>}
   * @public
   */
  static get f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<ContributionsRepository>} value
   * @return {void}
   * @public
   */
  static set f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<RequestRestSendersRepository>}
   * @public
   */
  static get f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<RequestRestSendersRepository>} value
   * @return {void}
   * @public
   */
  static set f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<MainExtensionPoint>}
   * @public
   */
  static get f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<MainExtensionPoint>} value
   * @return {void}
   * @public
   */
  static set f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<AppHistory>}
   * @public
   */
  static get f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<AppHistory>} value
   * @return {void}
   * @public
   */
  static set f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<List<ClientStartupTask>>}
   * @public
   */
  static get f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<List<ClientStartupTask>>} value
   * @return {void}
   * @public
   */
  static set f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<AsyncRunner>}
   * @public
   */
  static get f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<AsyncRunner>} value
   * @return {void}
   * @public
   */
  static set f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {AttributeHolder<DominoOptions>}
   * @public
   */
  static get f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {AttributeHolder<DominoOptions>} value
   * @return {void}
   * @public
   */
  static set f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static get f_initialized__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_initialized__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static set f_initialized__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_initialized__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @return {ClientApp}
   * @public
   */
  static get f_instance__org_dominokit_domino_api_client_ClientApp_() {
    return (ClientApp.$clinit(), ClientApp.$f_instance__org_dominokit_domino_api_client_ClientApp_);
  }
  
  /**
   * @param {ClientApp} value
   * @return {void}
   * @public
   */
  static set f_instance__org_dominokit_domino_api_client_ClientApp_(value) {
    (ClientApp.$clinit(), ClientApp.$f_instance__org_dominokit_domino_api_client_ClientApp_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientApp;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClientApp);
  }
  
  /**
   * @public
   */
  static $clinit() {
    ClientApp.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    List = goog.module.get('java.util.List$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    AttributeHolder = goog.module.get('org.dominokit.domino.api.client.ClientApp.AttributeHolder$impl');
    DominoOptionsHandler = goog.module.get('org.dominokit.domino.api.client.ClientApp.DominoOptionsHandler$impl');
    DominoOptions = goog.module.get('org.dominokit.domino.api.client.DominoOptions$impl');
    AsyncRunner = goog.module.get('org.dominokit.domino.api.client.async.AsyncRunner$impl');
    AsyncTask = goog.module.get('org.dominokit.domino.api.client.async.AsyncRunner.AsyncTask$impl');
    EventsBus = goog.module.get('org.dominokit.domino.api.client.events.EventsBus$impl');
    ContributionsRepository = goog.module.get('org.dominokit.domino.api.client.extension.ContributionsRepository$impl');
    PresentersRepository = goog.module.get('org.dominokit.domino.api.client.mvp.presenter.PresentersRepository$impl');
    ViewsRepository = goog.module.get('org.dominokit.domino.api.client.mvp.view.ViewsRepository$impl');
    CommandsRepository = goog.module.get('org.dominokit.domino.api.client.request.CommandsRepository$impl');
    RequestHolder = goog.module.get('org.dominokit.domino.api.client.request.RequestHolder$impl');
    RequestRestSendersRepository = goog.module.get('org.dominokit.domino.api.client.request.RequestRestSendersRepository$impl');
    RequestRouter = goog.module.get('org.dominokit.domino.api.client.request.RequestRouter$impl');
    ExtensionPoint = goog.module.get('org.dominokit.domino.api.shared.extension.ExtensionPoint$impl');
    MainExtensionPoint = goog.module.get('org.dominokit.domino.api.shared.extension.MainExtensionPoint$impl');
    DominoHistory = goog.module.get('org.dominokit.domino.api.shared.history.DominoHistory$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    j_l_Object.$clinit();
    ClientApp.$f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<RequestRouter<PresenterCommand>>} */ (AttributeHolder.$create__());
    ClientApp.$f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<RequestRouter<ServerRequest>>} */ (AttributeHolder.$create__());
    ClientApp.$f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<EventsBus>} */ (AttributeHolder.$create__());
    ClientApp.$f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<CommandsRepository>} */ (AttributeHolder.$create__());
    ClientApp.$f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<PresentersRepository>} */ (AttributeHolder.$create__());
    ClientApp.$f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<ViewsRepository>} */ (AttributeHolder.$create__());
    ClientApp.$f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<ContributionsRepository>} */ (AttributeHolder.$create__());
    ClientApp.$f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<RequestRestSendersRepository>} */ (AttributeHolder.$create__());
    ClientApp.$f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<MainExtensionPoint>} */ (AttributeHolder.$create__());
    ClientApp.$f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<AppHistory>} */ (AttributeHolder.$create__());
    ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<List<ClientStartupTask>>} */ (AttributeHolder.$create__());
    ClientApp.$f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<AsyncRunner>} */ (AttributeHolder.$create__());
    ClientApp.$f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_ = /**@type {!AttributeHolder<DominoOptions>} */ (AttributeHolder.$create__());
    ClientApp.$f_initialized__org_dominokit_domino_api_client_ClientApp_ = false;
    ClientApp.$f_instance__org_dominokit_domino_api_client_ClientApp_ = ClientApp.$create__();
  }
  
  
};

$Util.$setClassMetadata(ClientApp, $Util.$makeClassName('org.dominokit.domino.api.client.ClientApp'));


/** @private {AttributeHolder<RequestRouter<PresenterCommand>>} */
ClientApp.$f_CLIENT_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<RequestRouter<ServerRequest>>} */
ClientApp.$f_SERVER_ROUTER_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<EventsBus>} */
ClientApp.$f_EVENTS_BUS_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<CommandsRepository>} */
ClientApp.$f_COMMANDS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<PresentersRepository>} */
ClientApp.$f_PRESENTERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<ViewsRepository>} */
ClientApp.$f_VIEWS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<ContributionsRepository>} */
ClientApp.$f_CONTRIBUTIONS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<RequestRestSendersRepository>} */
ClientApp.$f_REQUEST_REST_SENDERS_REPOSITORY_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<MainExtensionPoint>} */
ClientApp.$f_MAIN_EXTENSION_POINT_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<AppHistory>} */
ClientApp.$f_HISTORY_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<List<ClientStartupTask>>} */
ClientApp.$f_INITIAL_TASKS_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<AsyncRunner>} */
ClientApp.$f_ASYNC_RUNNER_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {AttributeHolder<DominoOptions>} */
ClientApp.$f_DOMINO_OPTIONS_HOLDER__org_dominokit_domino_api_client_ClientApp_;


/** @private {boolean} */
ClientApp.$f_initialized__org_dominokit_domino_api_client_ClientApp_ = false;


/** @private {ClientApp} */
ClientApp.$f_instance__org_dominokit_domino_api_client_ClientApp_;


PresenterRegistry.$markImplementor(ClientApp);
CommandRegistry.$markImplementor(ClientApp);
ViewRegistry.$markImplementor(ClientApp);
InitialTaskRegistry.$markImplementor(ClientApp);
ContributionsRegistry.$markImplementor(ClientApp);
RequestRestSendersRegistry.$markImplementor(ClientApp);


exports = ClientApp; 
//# sourceMappingURL=ClientApp.js.map