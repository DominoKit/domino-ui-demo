/**
 * @fileoverview transpiled from org.dominokit.domino.api.client.InitialTaskRegistry.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.api.client.InitialTaskRegistry$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ClientStartupTask = goog.forwardDeclare('org.dominokit.domino.api.client.ClientStartupTask$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.api.client.InitialTaskRegistry.$LambdaAdaptor$impl');


/**
 * @interface
 */
class InitialTaskRegistry {
  /**
   * @abstract
   * @param {ClientStartupTask} task
   * @return {void}
   * @public
   */
  m_registerInitialTask__org_dominokit_domino_api_client_ClientStartupTask(task) {
  }
  
  /**
   * @param {?function(ClientStartupTask):void} fn
   * @return {InitialTaskRegistry}
   * @public
   */
  static $adapt(fn) {
    InitialTaskRegistry.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_api_client_InitialTaskRegistry = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_api_client_InitialTaskRegistry;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_api_client_InitialTaskRegistry;
  }
  
  /**
   * @public
   */
  static $clinit() {
    InitialTaskRegistry.$clinit = function() {};
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.api.client.InitialTaskRegistry.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(InitialTaskRegistry, $Util.$makeClassName('org.dominokit.domino.api.client.InitialTaskRegistry'));


InitialTaskRegistry.$markImplementor(/** @type {Function} */ (InitialTaskRegistry));


exports = InitialTaskRegistry; 
//# sourceMappingURL=InitialTaskRegistry.js.map