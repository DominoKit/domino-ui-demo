/**
 * @fileoverview transpiled from org.dominokit.domino.icons.client.IconsClientModule.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.icons.client.IconsClientModule$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


class IconsClientModule extends j_l_Object {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'IconsClientModule()'.
   * @return {!IconsClientModule}
   * @public
   */
  static $create__() {
    IconsClientModule.$clinit();
    let $instance = new IconsClientModule();
    $instance.$ctor__org_dominokit_domino_icons_client_IconsClientModule__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'IconsClientModule()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_icons_client_IconsClientModule__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onModuleLoad__() {
    IconsClientModule.$f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_.m_info__java_lang_String("Initializing Icons frontend module ...");
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_() {
    return (IconsClientModule.$clinit(), IconsClientModule.$f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_(value) {
    (IconsClientModule.$clinit(), IconsClientModule.$f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IconsClientModule;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IconsClientModule);
  }
  
  /**
   * @public
   */
  static $clinit() {
    IconsClientModule.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    j_l_Object.$clinit();
    IconsClientModule.$f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(IconsClientModule));
  }
  
  
};

$Util.$setClassMetadata(IconsClientModule, $Util.$makeClassName('org.dominokit.domino.icons.client.IconsClientModule'));


/** @private {Logger} */
IconsClientModule.$f_LOGGER__org_dominokit_domino_icons_client_IconsClientModule_;




exports = IconsClientModule; 
//# sourceMappingURL=IconsClientModule.js.map