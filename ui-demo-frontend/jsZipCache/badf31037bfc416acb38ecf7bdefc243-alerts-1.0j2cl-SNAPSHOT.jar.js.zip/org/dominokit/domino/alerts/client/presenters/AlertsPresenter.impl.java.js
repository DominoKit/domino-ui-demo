/**
 * @fileoverview transpiled from org.dominokit.domino.alerts.client.presenters.AlertsPresenter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.alerts.client.presenters.AlertsPresenter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseClientPresenter = goog.require('org.dominokit.domino.api.client.mvp.presenter.BaseClientPresenter$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.alerts.client.presenters.AlertsPresenter.$1$impl');
let AlertsView = goog.forwardDeclare('org.dominokit.domino.alerts.client.views.AlertsView$impl');
let ComponentsContext = goog.forwardDeclare('org.dominokit.domino.components.shared.extension.ComponentsContext$impl');
let Logger = goog.forwardDeclare('org.slf4j.Logger$impl');
let LoggerFactory = goog.forwardDeclare('org.slf4j.LoggerFactory$impl');


/**
 * @extends {BaseClientPresenter<AlertsView>}
  */
class AlertsPresenter extends BaseClientPresenter {
  /**
   * @private
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'AlertsPresenter()'.
   * @return {!AlertsPresenter}
   * @public
   */
  static $create__() {
    AlertsPresenter.$clinit();
    let $instance = new AlertsPresenter();
    $instance.$ctor__org_dominokit_domino_alerts_client_presenters_AlertsPresenter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AlertsPresenter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_alerts_client_presenters_AlertsPresenter__() {
    this.$ctor__org_dominokit_domino_api_client_mvp_presenter_BaseClientPresenter__();
  }
  
  /**
   * @param {ComponentsContext} context
   * @return {void}
   * @public
   */
  m_contributeToComponentsModule__org_dominokit_domino_components_shared_extension_ComponentsContext(context) {
    context.m_getComponentCaseContext__().m_addComponentCase__org_dominokit_domino_componentcase_shared_extension_ComponentCase($1.$create__org_dominokit_domino_alerts_client_presenters_AlertsPresenter(this));
  }
  
  /**
   * @return {Logger}
   * @public
   */
  static get f_LOGGER__org_dominokit_domino_alerts_client_presenters_AlertsPresenter_() {
    return (AlertsPresenter.$clinit(), AlertsPresenter.$f_LOGGER__org_dominokit_domino_alerts_client_presenters_AlertsPresenter_);
  }
  
  /**
   * @param {Logger} value
   * @return {void}
   * @public
   */
  static set f_LOGGER__org_dominokit_domino_alerts_client_presenters_AlertsPresenter_(value) {
    (AlertsPresenter.$clinit(), AlertsPresenter.$f_LOGGER__org_dominokit_domino_alerts_client_presenters_AlertsPresenter_ = value);
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AlertsPresenter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AlertsPresenter);
  }
  
  /**
   * @public
   */
  static $clinit() {
    AlertsPresenter.$clinit = function() {};
    Class = goog.module.get('java.lang.Class$impl');
    $1 = goog.module.get('org.dominokit.domino.alerts.client.presenters.AlertsPresenter.$1$impl');
    LoggerFactory = goog.module.get('org.slf4j.LoggerFactory$impl');
    BaseClientPresenter.$clinit();
    AlertsPresenter.$f_LOGGER__org_dominokit_domino_alerts_client_presenters_AlertsPresenter_ = LoggerFactory.m_getLogger__java_lang_Class(Class.$get(AlertsPresenter));
  }
  
  
};

$Util.$setClassMetadata(AlertsPresenter, $Util.$makeClassName('org.dominokit.domino.alerts.client.presenters.AlertsPresenter'));


/** @private {Logger} */
AlertsPresenter.$f_LOGGER__org_dominokit_domino_alerts_client_presenters_AlertsPresenter_;




exports = AlertsPresenter; 
//# sourceMappingURL=AlertsPresenter.js.map